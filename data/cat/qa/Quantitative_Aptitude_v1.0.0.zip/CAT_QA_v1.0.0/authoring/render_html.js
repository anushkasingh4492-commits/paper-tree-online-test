// Render student/teacher books and sample paper HTML for the CAT QA bank, KaTeX pre-rendered (works offline).
// usage: node render_html.js <records.json> <outdir> <title> <student_name> <teacher_name> [sample_paper.json]
const fs = require('fs');
const path = require('path');
const katex = require(__dirname + '/node_modules/katex');

const [,, recPath, outDir, title, STU, TEA, samplePath] = process.argv;
const KPREFIX = process.env.KATEX_PREFIX || '';
const recs = JSON.parse(fs.readFileSync(recPath, 'utf8'));
const FIGROOT = process.env.FIG_ROOT || path.dirname(recPath);
function figs(r) { return (r.figures || []).map(f => `<figure class="fig">${fs.readFileSync(path.join(FIGROOT, f.file), 'utf8')}</figure>`).join(''); }

function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function tex(s) {
  if (s === null || s === undefined) return '';
  const parts = String(s).split(/(?<!\\)\$/);
  let out = '';
  parts.forEach((p, k) => {
    if (k % 2 === 0) out += esc(p).replace(/\n/g, '<br>');
    else out += katex.renderToString(p, {throwOnError: true, strict: 'ignore', output: 'html'});
  });
  return out;
}

const CSS = `:root{--ink:#1b2a3a;--muted:#5b6f80;--line:#dde5ec;--bg:#f4f6f8;--card:#fff;--brand:#2c4a6e;--key:#e6f4ec;--tita:#fff6e3}
body{font:17px/1.6 Arial,Helvetica,sans-serif;margin:0;background:var(--bg);color:var(--ink)}
header{padding:40px max(20px,calc((100% - 1000px)/2)) 28px;background:var(--brand);color:#fff}h1{font-size:32px;margin:0 0 8px}
header p{max-width:900px;margin:6px 0;opacity:.95}.bar{position:sticky;top:0;z-index:5;background:#fff;padding:12px max(16px,calc((100% - 1000px)/2));display:flex;gap:10px;flex-wrap:wrap;box-shadow:0 2px 10px #0001}
input,select,button{font:inherit;padding:8px 10px;border:1px solid #c9d5df;border-radius:6px;background:#fff}main{max-width:1000px;margin:18px auto;padding:0 16px}
article{background:var(--card);padding:24px 28px;margin:16px 0;border-radius:10px;border:1px solid var(--line);break-inside:avoid}
.meta{font-size:13px;color:var(--muted)}.badge{display:inline-block;font-size:12px;font-weight:bold;padding:1px 8px;border-radius:10px;margin-left:6px;vertical-align:1px}
.b-mcq{background:#e8eef6;color:#2c4a6e}.b-tita{background:#fdebc8;color:#7a4d00}.q{margin:10px 0 6px}
ol{list-style:none;padding:0;margin:8px 0}li{margin:6px 0;padding:4px 8px}li b{display:inline-block;width:30px}li.key{background:var(--key);border-radius:6px}
.box{display:inline-block;min-width:140px;border:1px dashed #b9c6d2;border-radius:6px;padding:8px 12px;color:var(--muted);margin-top:6px;font-size:14px}
details{background:#eef3f9;padding:12px 16px;border-radius:8px;margin-top:10px}summary{cursor:pointer;font-weight:bold}
.trap{background:var(--tita);padding:8px 12px;border-radius:6px;margin-top:8px;font-size:15px}article[hidden]{display:none}
.fig{margin:10px 0}.fig svg{max-width:100%;height:auto;border:1px solid var(--line);border-radius:6px}
.count{align-self:center;color:var(--muted);font-size:14px}h2.sec{margin:28px 0 0;font-size:20px}
@media print{body{background:#fff;font-size:10.5pt}.bar{display:none}header{padding:6mm 0;color:var(--brand);background:#fff}main{margin:0;padding:0}
article{border:0;border-top:1px solid #ddd;margin:0;padding:4mm 0;border-radius:0}details{display:block}details>summary{display:none}}`;

function shell(t, sub, body, filters) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(t)}</title><link rel="stylesheet" href="${KPREFIX}katex/katex.min.css"><style>${CSS}</style></head><body>
<header><h1>${esc(t)}</h1>${sub}</header>${filters || ''}<main id="list">${body}</main>
<script>
const qs=[...document.querySelectorAll('article')];const f=()=>{const g=id=>(document.getElementById(id)||{}).value||'';
const s=g('search'),t=g('topic'),d=g('diff'),m=g('fmt');let n=0;
qs.forEach(a=>{const ok=(!s||a.textContent.toLowerCase().includes(s.toLowerCase()))&&(!t||a.dataset.topic===t)&&(!d||a.dataset.diff===d)&&(!m||a.dataset.fmt===m);a.hidden=!ok;if(ok)n++;});
const c=document.getElementById('count');if(c)c.textContent=n+' shown';};
document.querySelectorAll('.bar input,.bar select').forEach(e=>e.addEventListener('input',f));f();
</script></body></html>`;
}

function filters() {
  const topics = [...new Set(recs.map(r => r.topic))];
  return `<div class="bar"><input id="search" placeholder="Search text or ID"><select id="topic"><option value="">All topics</option>${
    topics.map(t => `<option>${esc(t)}</option>`).join('')}</select><select id="diff"><option value="">All levels</option><option>Easy</option><option>Medium</option><option>Difficult</option></select><select id="fmt"><option value="">MCQ and TITA</option><option>MCQ</option><option>TITA</option></select><button onclick="print()">Print</button><span class="count" id="count"></span></div>`;
}

function article(r, teacher, num) {
  const badge = r.answer_format === 'MCQ' ? '<span class="badge b-mcq">MCQ</span>' : '<span class="badge b-tita">TITA</span>';
  let h = `<article data-topic="${esc(r.topic)}" data-diff="${r.difficulty}" data-fmt="${r.answer_format}"><div class="meta">${num ? 'Q' + num + ' &middot; ' : ''}${r.id} &middot; ${esc(r.topic)} &middot; ${r.difficulty}${badge}</div>`;
  h += `<div class="q">${tex(r.question)}</div>` + figs(r);
  if (r.answer_format === 'MCQ') {
    h += '<ol>';
    for (const L of ['A', 'B', 'C', 'D']) h += `<li class="${teacher && L === r.correct_option ? 'key' : ''}"><b>(${L})</b>${tex(r.options[L])}</li>`;
    h += '</ol>';
  } else if (!teacher) {
    h += '<div class="box">Type your answer (a whole number)</div>';
  }
  if (teacher) {
    const ans = r.answer_format === 'MCQ' ? `(${r.correct_option}) ${tex(r.correct_answer)}` : `${r.tita_answer}`;
    h += `<details open><summary>Answer and solution</summary><p><b>Answer: ${ans}</b></p><p>${tex(r.explanation)}</p>`;
    h += `<p class="meta"><b>Targets:</b> ${tex(r.common_misconception)}<br><b>Why this level:</b> ${tex(r.difficulty_reason)}<br><b>Family:</b> ${esc(r.family_dependencies.join(', '))} &middot; <b>Suits:</b> ${esc(r.exam_tags.join(', '))}</p></details>`;
    if (r.answer_format === 'TITA' && r.tita_common_wrong_entries.length)
      h += `<div class="trap"><b>Common wrong entries:</b> ${r.tita_common_wrong_entries.map(t => `<b>${t.value}</b>: ${tex(t.reason)}`).join(' &middot; ')}</div>`;
  }
  return h + '</article>';
}

fs.mkdirSync(path.join(outDir, 'katex'), {recursive: true});
const nm = recs.filter(r => r.answer_format === 'MCQ').length, nt = recs.length - nm;
const sub = `<p>${recs.length} questions: ${nm} MCQ (four options, one correct, +3 / &minus;1) and ${nt} TITA (type a whole number, +3 / 0). Difficulty labels are editorial estimates on the CAT scale.</p>`;
if (STU !== '-') fs.writeFileSync(path.join(outDir, STU), shell(title + ': Student book', sub, recs.map(r => article(r, false)).join(''), filters()));
if (TEA !== '-') fs.writeFileSync(path.join(outDir, TEA), shell(title + ': Teacher book', sub + '<p>Includes keys, worked solutions, targeted misconceptions and the common wrong entries for TITA questions.</p>', recs.map(r => article(r, true)).join(''), filters()));

if (samplePath) {
  const sp = JSON.parse(fs.readFileSync(samplePath, 'utf8'));
  const byId = Object.fromEntries(recs.map(r => [r.id, r]));
  let qb = '', sb = '';
  sp.questions.forEach((id, i) => { qb += article(byId[id], false, i + 1); sb += article(byId[id], true, i + 1); });
  const ssub = `<p>${esc(sp.description)} Seed ${sp.seed}. ${sp.questions.length} questions, ${sp.time_minutes} minutes, maximum ${sp.max_marks} marks. MCQ +3 / &minus;1, TITA +3 / 0.</p>`;
  fs.writeFileSync(path.join(outDir, 'Sample_Paper.html'), shell(title + ': Sample section', ssub, qb));
  fs.writeFileSync(path.join(outDir, 'Sample_Solutions.html'), shell(title + ': Sample solutions', ssub, sb));
}
console.log('rendered', recs.length);
