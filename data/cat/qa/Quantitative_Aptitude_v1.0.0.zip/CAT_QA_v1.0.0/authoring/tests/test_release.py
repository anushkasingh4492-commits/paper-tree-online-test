# -*- coding: utf-8 -*-
"""Automated test suite for the CAT QA release.

Run from the release's authoring/ folder:  python3 tests/test_release.py
(needs sympy, jsonschema and node; the authoring folder needs node_modules/katex for the KaTeX test)
"""
import copy, glob, json, os, re, subprocess, sys, tempfile, shutil

AUTH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REL = os.path.dirname(AUTH)
sys.path.insert(0, AUTH)
BANK_PATH = sorted(glob.glob(os.path.join(REL, "cat_qa_*.json")))[0]
BANK = json.load(open(BANK_PATH, encoding="utf-8"))
RESULTS = []


def test(fn):
    try:
        fn(); RESULTS.append((fn.__name__, "PASS", ""))
    except AssertionError as e:
        RESULTS.append((fn.__name__, "FAIL", str(e)[:300]))
    except Exception as e:
        RESULTS.append((fn.__name__, "ERROR", f"{type(e).__name__}: {e}"[:300]))
    return fn


@test
def schema_valid():
    import jsonschema
    s = json.load(open(os.path.join(REL, "question_bank_schema.json")))
    jsonschema.validate(BANK, s)


CHS = range(1, 29)


def cfg(c):
    return json.load(open(os.path.join(AUTH, "config", f"C{c:02d}.json")))


@test
def harness_all_drafts_clean():
    for c in CHS:
        for f in cfg(c)["draft_files"]:
            r = subprocess.run([sys.executable, os.path.join(AUTH, "harness.py"), os.path.join(AUTH, f)], capture_output=True, text=True)
            assert r.returncode == 0 and "BLOCKING (0)" in r.stdout, f + r.stdout[-400:]


@test
def rebuild_reproduces_release():
    tmp = tempfile.mkdtemp()
    try:
        shutil.copytree(AUTH, os.path.join(tmp, "a"), ignore=shutil.ignore_patterns("build", "__pycache__"))
        rebuilt = []
        for c in CHS:
            subprocess.run([sys.executable, os.path.join(tmp, "a", "build_chapter.py"), os.path.join(tmp, "a", "config", f"C{c:02d}.json")],
                           check=True, capture_output=True)
            rebuilt += json.load(open(os.path.join(tmp, "a", "build", f"C{c:02d}", "records.json"), encoding="utf-8"))
        assert rebuilt == BANK, "rebuilt records differ from the released bank"
    finally:
        shutil.rmtree(tmp)


@test
def machine_checks_recompute():
    from harness import load, equal
    raw = sum((load(os.path.join(AUTH, f)) for c in CHS for f in cfg(c)["draft_files"]), [])
    assert len(raw) == len(BANK)
    for x, r in zip(raw, BANK):
        got = x["check"]()
        assert equal(got, x["values"][0]), r["id"]
        if r["answer_format"] == "TITA":
            assert r["tita_answer"] == x["tita_answer"], r["id"]


@test
def katex_every_string():
    items = []
    for r in BANK:
        for f in ("question", "explanation", "common_misconception", "difficulty_reason", "correct_answer"):
            items.append({"id": r["id"], "field": f, "text": r[f]})
        for L, t in (r["options"] or {}).items():
            items.append({"id": r["id"], "field": L, "text": t})
        for t in r["tita_common_wrong_entries"]:
            items.append({"id": r["id"], "field": "trap", "text": t["reason"]})
    out = subprocess.run(["node", os.path.join(AUTH, "katex_check.js")], input=json.dumps(items), capture_output=True, text=True)
    assert json.loads(out.stdout) == [], out.stdout[:400]


@test
def exports_parity():
    qo = json.load(open(os.path.join(REL, "questions_only.json"), encoding="utf-8"))
    ae = json.load(open(os.path.join(REL, "answers_and_explanations.json"), encoding="utf-8"))
    jl = [json.loads(l) for l in open(glob.glob(os.path.join(REL, "cat_qa_*.jsonl"))[0], encoding="utf-8")]
    assert jl == BANK
    assert [x["id"] for x in qo] == [x["id"] for x in ae] == [r["id"] for r in BANK]
    for a, r in zip(ae, BANK):
        assert a["correct_option"] == r["correct_option"] and a["tita_answer"] == r["tita_answer"]


@test
def books_complete_and_no_leak():
    for c in CHS:
        stu = open(os.path.join(REL, "books", f"Chapter_{c:02d}_Student.html"), encoding="utf-8").read()
        tea = open(os.path.join(REL, "books", f"Chapter_{c:02d}_Teacher.html"), encoding="utf-8").read()
        rs = [r for r in BANK if r["chapter_number"] == c]
        for r in rs:
            assert r["id"] in stu and r["id"] in tea, r["id"]
            if r["figures"]:
                assert stu.count("<svg") >= 1, r["id"]
        assert "Answer:" not in stu and 'class="key"' not in stu, c
        assert tea.count("<b>Answer: ") == len(rs), c
        assert stu.count('class="fig"') == sum(1 for r in rs if r["figures"]), c
    sp = open(os.path.join(REL, "Sample_Paper.html"), encoding="utf-8").read()
    assert "Answer:" not in sp


@test
def no_meta_commentary_or_dashes():
    for r in BANK:
        for t in [r["question"], r["explanation"]] + list((r["options"] or {}).values()):
            assert not re.search(r"\b(errata|audit|reviewer|erratum|this question has been)\b", t, re.I), r["id"]
            assert "—" not in t and "–" not in t, r["id"]


@test
def verify_release_passes():
    r = subprocess.run([sys.executable, os.path.join(REL, "verify_release.py"), BANK_PATH], capture_output=True, text=True)
    assert r.returncode == 0 and r.stdout.startswith("PASS"), r.stdout[-400:]


@test
def mutation_is_caught():
    tmp = tempfile.mkdtemp()
    try:
        for f in os.listdir(REL):
            if f.endswith((".json", ".py")) or f in ("books", "Sample_Paper.html", "figures"):
                s = os.path.join(REL, f)
                (shutil.copytree if os.path.isdir(s) else shutil.copy)(s, os.path.join(tmp, f))
        bad = copy.deepcopy(BANK)
        m = next(r for r in bad if r["answer_format"] == "MCQ")
        m["options"]["A"] = m["options"]["B"]  # duplicate option
        t = next(r for r in bad if r["answer_format"] == "TITA")
        t["question"] += " Choose from the options."  # TITA mentions options
        bp = os.path.join(tmp, os.path.basename(BANK_PATH))
        json.dump(bad, open(bp, "w"))
        r = subprocess.run([sys.executable, os.path.join(tmp, "verify_release.py"), bp], capture_output=True, text=True)
        assert r.returncode != 0 and "options not distinct" in r.stdout and "TITA mentions options" in r.stdout, r.stdout[-300:]
    finally:
        shutil.rmtree(tmp)


if __name__ == "__main__":
    for name, st, msg in RESULTS:
        print(f"{st:5} {name} {msg}")
    ok = all(s == "PASS" for _, s, _ in RESULTS)
    print(f"{sum(s == 'PASS' for _, s, _ in RESULTS)}/{len(RESULTS)} passed")
    json.dump([dict(test=n, status=s, detail=m) for n, s, m in RESULTS],
              open(os.path.join(REL, "evidence", "test_results.json"), "w"), indent=1)
    sys.exit(0 if ok else 1)
