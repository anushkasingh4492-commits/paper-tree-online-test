# -*- coding: utf-8 -*-
"""Tiny figure library for CAT QA geometry items. Produces clean, exact SVG from coordinates.

Usage inside a drafting file:
    from figlib import Fig
    f = Fig()
    P, Q, R = f.pt("P", 0, 0), f.pt("Q", 6, 0), f.pt("R", 2, 4)
    f.poly(P, Q, R)                    # closed polygon through the points
    f.seg(P, (3, 0), dashed=True)      # any segment (points or (x, y) tuples)
    f.circle((3, 1), 2)                # circle with centre and radius
    f.arc((0, 0), 1, 0, 60)            # arc of radius 1 from 0 to 60 degrees (counter-clockwise)
    f.right_angle(Q, P, R)             # small square at P between rays P->Q and P->R
    f.angle_mark(Q, P, R, "40^\\circ")  # arc at P with a label (plain text; ^\\circ becomes a degree sign)
    f.label_seg(P, Q, "6 cm")          # label at the midpoint of a segment, pushed outward
    f.text((x, y), "text")             # free text
    f.shade([P, Q, R])                 # light grey fill of a polygon region
    svg = f.svg(alt="Triangle PQR with PQ = 6 cm ...")
Then pass figure=dict(svg=svg, alt="...", required=True/False) to q(...).

Coordinates are in mathematical units with y upwards; the SVG is scaled to fit 340 x 260 px.
Draw from the stem's data so the figure is to scale, and never label the unknown that is asked.
"""
import math


class Fig:
    def __init__(self):
        self.items = []      # (kind, data)
        self.pts = []        # all coordinates for bounding box
        self.labels = []

    def _p(self, p):
        if isinstance(p, dict):
            return p["xy"]
        return (float(p[0]), float(p[1]))

    def pt(self, name, x, y, dot=True, offset=None):
        d = {"name": name, "xy": (float(x), float(y)), "dot": dot, "offset": offset}
        self.items.append(("pt", d)); self.pts.append(d["xy"])
        return d

    def seg(self, a, b, dashed=False):
        a, b = self._p(a), self._p(b)
        self.items.append(("seg", (a, b, dashed))); self.pts += [a, b]

    def poly(self, *ps, dashed=False):
        q = [self._p(p) for p in ps]
        self.items.append(("poly", (q, dashed))); self.pts += q

    def shade(self, ps):
        q = [self._p(p) for p in ps]
        self.items.insert(0, ("shade", q)); self.pts += q

    def circle(self, c, r, dashed=False):
        c = self._p(c)
        self.items.append(("circle", (c, float(r), dashed)))
        self.pts += [(c[0] - r, c[1] - r), (c[0] + r, c[1] + r)]

    def arc(self, c, r, a0, a1, dashed=False):
        c = self._p(c)
        self.items.append(("arc", (c, float(r), float(a0), float(a1), dashed)))
        for a in (a0, a1, (a0 + a1) / 2):
            self.pts.append((c[0] + r * math.cos(math.radians(a)), c[1] + r * math.sin(math.radians(a))))

    def right_angle(self, a, v, b, size=None):
        self.items.append(("right", (self._p(a), self._p(v), self._p(b), size)))

    def angle_mark(self, a, v, b, label="", r=None):
        self.items.append(("angle", (self._p(a), self._p(v), self._p(b), label, r)))

    def label_seg(self, a, b, text, side=1):
        self.items.append(("lseg", (self._p(a), self._p(b), text, side)))

    def text(self, xy, text):
        self.items.append(("text", (self._p(xy), text)))

    # ---------- rendering ----------
    def svg(self, alt, W=340, H=260, pad=28):
        xs = [p[0] for p in self.pts]; ys = [p[1] for p in self.pts]
        x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
        sx = (W - 2 * pad) / max(x1 - x0, 1e-9); sy = (H - 2 * pad) / max(y1 - y0, 1e-9)
        s = min(sx, sy)
        ox = pad + ((W - 2 * pad) - s * (x1 - x0)) / 2; oy = pad + ((H - 2 * pad) - s * (y1 - y0)) / 2
        T = lambda p: (ox + (p[0] - x0) * s, H - (oy + (p[1] - y0) * s))
        cx = sum(xs) / len(xs); cy = sum(ys) / len(ys)
        out = []
        stroke = 'stroke="#1b2a3a" stroke-width="1.6" fill="none"'
        dash = ' stroke-dasharray="5 4"'
        esc = lambda t: t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("^\\circ", "°")
        unit = 14.0 / s  # ~14 px in math units
        for kind, d in self.items:
            if kind == "shade":
                pts = " ".join(f"{T(p)[0]:.1f},{T(p)[1]:.1f}" for p in d)
                out.append(f'<polygon points="{pts}" fill="#d9e2ec" stroke="none"/>')
            elif kind == "seg":
                a, b, dsh = d; A, B = T(a), T(b)
                out.append(f'<line x1="{A[0]:.1f}" y1="{A[1]:.1f}" x2="{B[0]:.1f}" y2="{B[1]:.1f}" {stroke}{dash if dsh else ""}/>')
            elif kind == "poly":
                q, dsh = d
                pts = " ".join(f"{T(p)[0]:.1f},{T(p)[1]:.1f}" for p in q)
                out.append(f'<polygon points="{pts}" {stroke}{dash if dsh else ""}/>')
            elif kind == "circle":
                c, r, dsh = d; C = T(c)
                out.append(f'<circle cx="{C[0]:.1f}" cy="{C[1]:.1f}" r="{r * s:.1f}" {stroke}{dash if dsh else ""}/>')
            elif kind == "arc":
                c, r, a0, a1, dsh = d
                P0 = T((c[0] + r * math.cos(math.radians(a0)), c[1] + r * math.sin(math.radians(a0))))
                P1 = T((c[0] + r * math.cos(math.radians(a1)), c[1] + r * math.sin(math.radians(a1))))
                large = 1 if (a1 - a0) % 360 > 180 else 0
                out.append(f'<path d="M{P0[0]:.1f},{P0[1]:.1f} A{r * s:.1f},{r * s:.1f} 0 {large} 0 {P1[0]:.1f},{P1[1]:.1f}" {stroke}{dash if dsh else ""}/>')
            elif kind == "right":
                a, v, b, size = d
                k = size or unit * 0.8
                ua = _unit(v, a); ub = _unit(v, b)
                p1 = (v[0] + ua[0] * k, v[1] + ua[1] * k); p3 = (v[0] + ub[0] * k, v[1] + ub[1] * k)
                p2 = (p1[0] + ub[0] * k, p1[1] + ub[1] * k)
                pts = " ".join(f"{T(p)[0]:.1f},{T(p)[1]:.1f}" for p in (p1, p2, p3))
                out.append(f'<polyline points="{pts}" stroke="#1b2a3a" stroke-width="1.2" fill="none"/>')
            elif kind == "angle":
                a, v, b, label, r = d
                r = r or unit * 1.6
                t0 = math.degrees(math.atan2(a[1] - v[1], a[0] - v[0])); t1 = math.degrees(math.atan2(b[1] - v[1], b[0] - v[0]))
                sweep = (t1 - t0) % 360
                if sweep > 180:
                    t0, t1 = t1, t0; sweep = 360 - sweep
                P0 = T((v[0] + r * math.cos(math.radians(t0)), v[1] + r * math.sin(math.radians(t0))))
                P1 = T((v[0] + r * math.cos(math.radians(t0 + sweep)), v[1] + r * math.sin(math.radians(t0 + sweep))))
                out.append(f'<path d="M{P0[0]:.1f},{P0[1]:.1f} A{r * s:.1f},{r * s:.1f} 0 0 0 {P1[0]:.1f},{P1[1]:.1f}" stroke="#2c4a6e" stroke-width="1.2" fill="none"/>')
                if label:
                    tm = math.radians(t0 + sweep / 2); rl = r + unit * 1.1
                    L = T((v[0] + rl * math.cos(tm), v[1] + rl * math.sin(tm)))
                    out.append(f'<text x="{L[0]:.1f}" y="{L[1] + 4:.1f}" font-size="12" text-anchor="middle" fill="#2c4a6e">{esc(label)}</text>')
            elif kind == "lseg":
                a, b, text, side = d
                m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                nx, ny = -(b[1] - a[1]), (b[0] - a[0]); L = math.hypot(nx, ny) or 1
                nx, ny = nx / L, ny / L
                if (m[0] + nx - cx) ** 2 + (m[1] + ny - cy) ** 2 < (m[0] - cx) ** 2 + (m[1] - cy) ** 2:
                    nx, ny = -nx, -ny
                nx, ny = nx * side, ny * side
                P = T((m[0] + nx * unit, m[1] + ny * unit))
                out.append(f'<text x="{P[0]:.1f}" y="{P[1] + 4:.1f}" font-size="12" text-anchor="middle" fill="#1b2a3a">{esc(text)}</text>')
            elif kind == "text":
                xy, text = d; P = T(xy)
                out.append(f'<text x="{P[0]:.1f}" y="{P[1] + 4:.1f}" font-size="12" text-anchor="middle" fill="#1b2a3a">{esc(text)}</text>')
        for kind, d in self.items:
            if kind == "pt":
                P = T(d["xy"])
                if d["dot"]:
                    out.append(f'<circle cx="{P[0]:.1f}" cy="{P[1]:.1f}" r="2.4" fill="#1b2a3a"/>')
                if d["name"]:
                    if d["offset"]:
                        dx, dy = d["offset"]
                    else:
                        vx, vy = d["xy"][0] - cx, d["xy"][1] - cy; L = math.hypot(vx, vy) or 1
                        dx, dy = vx / L, vy / L
                    out.append(f'<text x="{P[0] + dx * 13:.1f}" y="{P[1] - dy * 13 + 4:.1f}" font-size="13" font-style="italic" text-anchor="middle" fill="#1b2a3a">{esc(d["name"])}</text>')
        body = "".join(out)
        alt_e = esc(alt).replace('"', "&quot;")
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-label="{alt_e}">'
                f'<rect width="{W}" height="{H}" fill="#ffffff"/>{body}</svg>')


def _unit(v, a):
    dx, dy = a[0] - v[0], a[1] - v[1]; L = math.hypot(dx, dy) or 1
    return dx / L, dy / L
