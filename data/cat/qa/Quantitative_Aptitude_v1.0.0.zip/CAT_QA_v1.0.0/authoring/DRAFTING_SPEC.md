# CAT Quantitative Ability bank: drafting spec (read fully before writing)

You are authoring part of a commercial CAT (IIM Common Admission Test) Quantitative Ability
question bank for Paper Tree Educational Studio. It sits beside finished NEET, MHT-CET and JEE Main
banks that went through several rounds of hostile errata audit. Every question you write will be
machine-checked, then re-solved blind by a separate reviewer who does not see your key, then
audited by a hostile editor. Every disagreement costs a correction round, so be exact.

## The exam you are writing for

- CAT QA section: 22 questions in 40 minutes, with a basic on-screen calculator.
- Two formats. **MCQ**: four options, one correct, +3 / -1. **TITA** (type in the answer): the
  candidate types a number, +3 / 0. In this bank every TITA answer is a non-negative integer.
- CAT QA is word-problem heavy. Stems describe a situation (people, vehicles, shops, investments,
  tanks, tracks) and the candidate must model it. Pure "compute this expression" drills are rare.
- The best CAT questions reward insight (ratios, relative motion, symmetry, working backwards,
  option elimination) over brute algebra. Numbers are chosen so a sharp candidate finishes in
  1 to 3 minutes. The calculator exists, but questions must not need heavy arithmetic.

## Output

Write ONE Python file at the path in your brief. Start it with exactly:

```python
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
```

Then call `q(...)` once per question. Read `/home/claude/catqa/qlib.py` for the signature and
`/home/claude/catqa/drafts/_sample.py` for one MCQ and one TITA worked example.
Local IDs are `<PREFIX>-001`, `<PREFIX>-002`, ... in order, with the prefix from your brief.

## The rules that matter most

1. **Exactly one defensible answer.** Under any reasonable reading of the stem there is one
   answer. State every assumption that matters inside the stem: constant speeds, start at the same
   time, same or opposite direction, whether lengths of trains matter, "the first time they
   meet", whether a stoppage counts, simple or compound interest, and so on. Ask yourself: could a
   careful student read this differently and get another value? If yes, fix the stem.
2. **Every question has a machine check.** `check` recomputes the answer FROM THE GIVENS IN THE
   STEM. Prefer an independent route: set up the equations with sympy `solve`, or simulate the
   situation step by step with `Fraction` (positions over time, lap counting, race distances). Do
   not just `return` the number you already know. For MCQ, `values` gives the exact value of each
   option, key first. The harness fails the item if check() differs from the key, or if a
   distractor value equals the key or another distractor. For TITA, `values=[tita_answer]`.
3. **Option text is only the answer** (MCQ). Never hint at why a distractor is wrong. Options are
   parallel in form and units (all "$x$ km/h", all "$x$ minutes", all ratios $a : b$). The key must
   not be the odd one out in form, size or neatness. Do not always make the key the median value.
4. **TITA stems are self-sufficient.** The stem says exactly what number to type, including the
   unit ("in km/h", "in minutes", "in metres"), and the true answer must be a non-negative integer
   in that unit. If the natural answer is a fraction, change the numbers, do not ask for rounding.
   A TITA stem never mentions options. Use `tita_traps` for the two or three most common wrong
   entries with the error that produces each (teachers see these).
5. **Never name option letters** in the explanation. Refer to values.
6. **No meta commentary anywhere in question content.** Stems, options and explanations never
   mention reviews, audits, corrections, versions, "this question", the bank, or the author.

## Lessons from the pilot chapter (apply them)

- Stay strictly inside your brief's scope. Other batches cover the excluded content; overlapping
  models across batches were the most common audit finding in the pilot.
- Within your file, items that use the same method must share one family (max 3). A new family
  needs a genuinely different model, not new numbers or a new setting.
- Do not reproduce well-known textbook or puzzle-book problems with their classic numbers.
- Option forms must be parallel: never one mixed number among integers, never one surd among
  integers. If the key is an ugly number, make the distractors equally ugly or change the numbers.
- An answer that is naturally a fraction (probability, ratio, log value) is an MCQ, not a TITA.
- For counting questions, the check must enumerate (itertools, brute force) where feasible.

## Format split for your batch

Your brief gives the exact number of TITA items. Choose TITA for questions where typing an integer
is natural (counts, times, distances, speeds with integer answers) and MCQ where options add value
(ratios, fractions, expressions, "which is true", answers that are naturally non-integer).
Spread TITA across Easy, Medium and Difficult roughly in proportion.

## Notation and house style (LaTeX, rendered with KaTeX)

- All mathematics inline with `$...$`. Never `$$`. Use Python raw strings `r"..."`.
- Pure ASCII source only. No Unicode symbols, no curly quotes, and **no em dash, en dash or
  double hyphen anywhere** (house rule). Use commas, semicolons, colons or separate sentences.
- Numbers and units: `$54$ km/h`, `$15$ m/s`, `$2$ hours $30$ minutes`, `Rs. $1{,}200$`.
- Clock times: `$9{:}00$ am`, `$3{:}24$ pm` (math-mode time, lower-case am/pm in plain text).
  Put the number in math mode and the unit in plain text after it. Indian digit grouping is fine.
- Ratios `$3 : 5$`. Fractions `$\frac{3}{4}$`. Percent `$20\%$` (escape the percent sign).
- Use people's names (Indian and varied: Ravi, Meera, Arjun, Fatima, Kabir, Sneha, Joseph, Priya,
  Harpreet, Ananya ...) and places P, Q, R, S or real-sounding town names. Never label things in
  an MCQ stem A, B, C or D (they clash with option letters).
- Stems end naturally: a full question with "?", or "... is" / "... equals".

## Difficulty (editorial, CAT scale; not school level)

- **Easy**: one idea, one or two steps, about 1 minute. Still a CAT-style situation with one trap.
- **Medium**: typical CAT question; two or three steps, or two ideas combined; 1.5 to 2.5 min.
- **Difficult**: upper end of CAT; a non-obvious model, casework, multiple stages or a strong trap;
  about 3 to 4 minutes. Must be solvable by hand (with a basic calculator) in that time.

`difficulty_reason` says concretely why. `cognitive`: Recall, Understanding, Application or
Analysis.

## Question types (exact strings)

Single-step computation; Multi-step word problem; Inverse/parameter (find the quantity that
makes a condition true); Conceptual/application (insight or principle, e.g. meeting points,
proportionality); Casework/optimisation (cases, max/min, counting scenarios).

## Distractors (MCQ)

Each distractor is the exact result of a specific, realistic student error (adding speeds instead
of subtracting, forgetting train length, using arithmetic mean for average speed, reporting the
other person's value, unit slip between m/s and km/h, counting the start as a meeting, off-by-one
in laps). Name that error in the rationale and make sure performing it gives exactly that value.
No absurd values, no two options equal. Every distractor satisfies the conditions in the stem.

Banned options: "None of these", "All of the above", "Cannot be determined", "Both ... and ...".

## Variety and families

- `family` (concept_family) is a slug from your brief's prefix, like `C08-trains-crossing-opposite`.
  Items testing the same method share a family. **At most 3 items per family**, and aim for many
  more families than that. The paper generator picks at most one item per family.
- No near-copies. Vary the context, reverse the unknown, combine with another idea, use a
  different trap. Do not write five "two trains cross each other" items with new numbers.
- Write original questions. You may use classic CAT patterns with your own numbers and framing;
  never reproduce a past CAT question.

## Exam reuse tags

`exams` lists the entrance tests the item suits. CAT is always included. Guidance:
- Easy and most Medium items: all six (CAT, XAT, NMAT, SNAP, CMAT, MAH-CET), the default.
- Difficult items and heavy Medium items: usually `("CAT", "XAT")` only, because NMAT, SNAP,
  CMAT and MAH-CET are speed tests with simpler questions.

## Solutions

`explanation`: a real worked solution a strong student would write, 2 to 6 sentences, showing the
key set-up and arithmetic, ideally the fast CAT route. It must reach the keyed value.
`misconception`: the specific error targeted.

## Self-audit (after the harness passes, before reporting)

Go through every record as a hostile editor and fix anything that fails:
1. Explanation: every step true, no missing case, reaches the keyed value.
2. Each distractor or trap rationale: perform the named mistake yourself; it must give exactly that
   value.
3. One defensible answer; all assumptions stated; units consistent between stem and options.
4. TITA: the stem asks for exactly the integer keyed, in the stated unit.
5. Difficulty label fair; scope inside your brief; no near-duplicates inside your file.

## Before reporting back

Run: `cd /home/claude/catqa && python3 harness.py <your file> --easy E --medium M --difficult D --tita T`
with your quotas. Fix everything under BLOCKING. Read every ADVISORY line and fix what is real.

Report back ONLY: the harness summary lines (including the figures count for geometry), any `flags` you set, and any item you are still
unsure about. Do not paste the questions.

## FIGURES (geometry chapters 15 to 20 only)

Use `/home/claude/catqa/figlib.py` (read its docstring). In your drafting file:

```python
from figlib import Fig
f = Fig(); P = f.pt("P", 0, 0); Q = f.pt("Q", 6, 0); R = f.pt("R", 2, 4); f.poly(P, Q, R)
q(..., figure=dict(svg=f.svg(alt="Triangle PQR ..."), alt="Triangle PQR ...", required=False))
```

- Compute coordinates from the stem's data so the figure is to scale and consistent with every
  given (lengths, angles, tangency). Never draw or label the quantity being asked for, and never
  add information that is not in the stem.
- `required=True` only when the stem cannot be solved without the figure (for example "in the
  figure, ..."). Prefer stems that are complete in text, with the figure as support
  (`required=False`). Either way the stem must stand on its own for screen readers via `alt`.
- `alt` is a plain-ASCII description (at least 20 characters) of what the figure shows.
- Labels use the same letters as the stem. Use P, Q, R, S, O, T and so on, never A, B, C, D in MCQs.
