# usage: python3 apply_aliases.py C01 [C02 ...]  -> merges E6 groups from verify/sweep_CNN.json into config alias_groups
import json, sys, re
for ch in sys.argv[1:]:
    sw = json.load(open(f"verify/sweep_{ch}.json"))
    n = 0
    for x in sw:
        if x["category"] != "E6":
            continue
        ids = [i.strip() for i in re.split(r"[,\s]+", x["id"]) if i.strip()]
        ids = [i for i in ids if re.fullmatch(r"C\d{2}-[A-Z]-\d{3}", i)]
        if len(ids) < 2:
            continue
        n += 1
        name = f"ALIAS-{ch}-SW{n:02d}"
        for c in sorted({i[:3] for i in ids}):
            p = f"config/{c}.json"; cfg = json.load(open(p))
            cfg.setdefault("alias_groups", {})[name] = [i for i in ids if i[:3] == c]
            json.dump(cfg, open(p, "w"), indent=1)
    print(ch, n, "groups")
