# -*- coding: utf-8 -*-
"""Assemble one chapter of the CAT QA bank into canonical records.

usage: python3 build_chapter.py config/C08.json
Writes build/C08/records.json and build/C08/evidence/*.json
"""
import hashlib, inspect, json, os, random, sys, textwrap
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sympy as sp  # noqa
from harness import load, equal  # noqa

RELEASE = "1.0.0"
SEED_RELEASE = "1.0.0"
EXAM_REF = "CAT 2026 (IIM Indore), Quantitative Ability section: 22 questions, 40 minutes, MCQ +3/-1, TITA +3/0"


def balance_positions(n, seed_text, letters="ABCD", max_run=3):
    rnd = random.Random(int(hashlib.sha256(seed_text.encode()).hexdigest(), 16) % (2 ** 63))
    base = [letters[i % 4] for i in range(n)]
    for attempt in range(200000):
        rnd.shuffle(base)
        run, ok = 1, True
        for i in range(1, n):
            run = run + 1 if base[i] == base[i - 1] else 1
            if run > max_run:
                ok = False
                break
        s = "".join(base)
        if ok and "ABCD" not in s and "DCBA" not in s:
            return list(base), attempt
    raise RuntimeError("could not balance")


def sval(v):
    try:
        return str(sp.nsimplify(v)) if not isinstance(v, (int,)) else str(v)
    except Exception:
        return str(v)


def main(cfg_path):
    cfg = json.load(open(cfg_path))
    c = cfg["chapter_number"]
    tag = f"C{c:02d}"
    out = os.path.join(HERE, "build", tag)
    os.makedirs(os.path.join(out, "evidence"), exist_ok=True)

    raw = []
    for f in cfg["draft_files"]:
        raw += load(os.path.join(HERE, f))
    assert len(raw) == cfg["count"], (len(raw), cfg["count"])
    order = {t: i for i, t in enumerate(cfg["topic_order"])}
    for x in raw:
        assert x["topic"] in order, (x["local_id"], x["topic"])

    alias_of = {}
    for name, members in cfg.get("alias_groups", {}).items():
        for m in members:
            alias_of.setdefault(m, []).append(name)
    known = {x["local_id"] for x in raw}
    for m in alias_of:
        assert m in known, m

    n_mcq = sum(1 for x in raw if x["answer_format"] == "MCQ")
    letters, attempts = balance_positions(n_mcq, f"CAT-QA-{tag}-{SEED_RELEASE}")
    letters_it = iter(letters)
    rnd = random.Random(f"distractor-order-{tag}")

    records, machine, distractor_review = [], [], []
    for n, x in enumerate(raw, start=1):
        rid = f"CAT-QA-{tag}-{n:03d}"
        got = x["check"]()
        assert equal(got, x["values"][0]), rid
        try:
            src = textwrap.dedent(inspect.getsource(x["check"]))
        except Exception:
            src = "<source unavailable>"
        mrec = dict(id=rid, local_id=x["local_id"], format=x["answer_format"], computed=sval(got),
                    keyed_value=sval(x["values"][0]), match=True, check_source=src)
        if x["answer_format"] == "MCQ":
            key_letter = next(letters_it)
            dis = list(x["distractors"]); dvals = list(x["values"][1:])
            idx = [0, 1, 2]; rnd.shuffle(idx)
            dis = [dis[i] for i in idx]; dvals = [dvals[i] for i in idx]
            slots = [L for L in "ABCD" if L != key_letter]
            options = {key_letter: x["correct"]}
            for L, d in zip(slots, dis):
                options[L] = d["text"]
            options = {L: options[L] for L in "ABCD"}
            assert all(not equal(v, x["values"][0]) for v in dvals), rid
            mrec["distractor_values"] = {L: sval(v) for L, v in zip(slots, dvals)}
            mrec["distractors_differ_from_key"] = True
            distractor_review.append(dict(id=rid, local_id=x["local_id"], format="MCQ",
                                          distractors=[dict(option=L, text=d["text"], value=sval(v), reason=d["rationale"])
                                                       for L, d, v in zip(slots, dis, dvals)]))
            correct_option, tita, correct_answer = key_letter, None, x["correct"]
            marks_wrong = -1
        else:
            options, correct_option, tita = None, None, x["tita_answer"]
            correct_answer = f"${tita}$"
            marks_wrong = 0
            distractor_review.append(dict(id=rid, local_id=x["local_id"], format="TITA",
                                          common_wrong_entries=[dict(value=t["value"], reason=t["rationale"]) for t in x["tita_traps"]]))
        machine.append(mrec)
        figs, freq = [], False
        if x["figure"]:
            os.makedirs(os.path.join(out, "figures"), exist_ok=True)
            fn = f"figures/{rid}.svg"
            open(os.path.join(out, fn), "w", encoding="utf-8").write(x["figure"]["svg"])
            figs = [dict(file=fn, alt_text=x["figure"]["alt"])]
            freq = bool(x["figure"].get("required", True))
        fam = x["concept_family"]
        deps = [fam] + alias_of.get(x["local_id"], [])
        rec = dict(
            id=rid, section=cfg["section"], area=cfg["area"], chapter_number=c, chapter=cfg["chapter"],
            topic=x["topic"], subtopic=x["subtopic"], standard="CAT", exam_tags=x["exams"],
            question=x["question"], answer_format=x["answer_format"],
            options=options, correct_option=correct_option, tita_answer=tita, correct_answer=correct_answer,
            explanation=x["explanation"], common_misconception=x["common_misconception"],
            tita_common_wrong_entries=[dict(value=t["value"], reason=t["rationale"]) for t in x["tita_traps"]],
            difficulty=x["difficulty"], difficulty_reason=x["difficulty_reason"],
            difficulty_basis="Editorial estimate on the CAT scale (steps, ideas combined, trap density); not calibrated against student data",
            cognitive_level=x["cognitive_level"], question_type=x["question_type"],
            concept_family=fam, family_dependencies=deps, max_per_family_per_paper=1,
            set_id=None, figures=figs, figure_required=freq, assumptions=x["assumptions"],
            notation="latex-inline",
            machine_check=dict(method="Independent recomputation from the stated givens (sympy equations or step simulation)",
                               status="match", computed_value=sval(got)),
            marks_correct=3, marks_incorrect=marks_wrong, marks_unattempted=0,
            provenance=dict(kind="Original CAT-style authoring", authoring_batch=x["local_id"].rsplit("-", 1)[0], local_id=x["local_id"]),
            exam_reference=EXAM_REF, release_version=RELEASE, generator_eligible=True,
            validation_status="MACHINE_RECOMPUTED; BLIND_RESOLVED; EDITORIAL_AUDITED; POSTFIX_REVERIFIED",
            human_subject_expert_reviewed=False,
            tags=["CAT", "Quantitative Ability", cfg["area"], cfg["chapter"], x["topic"], x["difficulty"], x["answer_format"]],
        )
        records.append(rec)

    json.dump(records, open(os.path.join(out, "records.json"), "w"), indent=1, ensure_ascii=False)
    json.dump(machine, open(os.path.join(out, "evidence", "machine_checks.json"), "w"), indent=1, ensure_ascii=False)
    json.dump(distractor_review, open(os.path.join(out, "evidence", "distractor_review.json"), "w"), indent=1, ensure_ascii=False)
    json.dump(dict(chapter=tag, seed_text=f"CAT-QA-{tag}-{SEED_RELEASE}", attempts=attempts, mcq_count=n_mcq,
                   sequence="".join(letters), counts=dict(Counter(letters))),
              open(os.path.join(out, "evidence", "key_balance.json"), "w"), indent=1)
    print(tag, len(records), dict(Counter(r["difficulty"] for r in records)),
          dict(Counter(r["answer_format"] for r in records)), dict(Counter(letters)),
          "families", len({r["concept_family"] for r in records}), "aliases", len(cfg.get("alias_groups", {})))


if __name__ == "__main__":
    main(sys.argv[1])
