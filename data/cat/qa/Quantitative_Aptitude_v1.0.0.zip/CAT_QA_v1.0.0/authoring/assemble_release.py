# -*- coding: utf-8 -*-
"""Assemble the full CAT QA release folder (28 chapters) from build/ and verify/.

usage: python3 assemble_release.py            build the release folder
       python3 assemble_release.py --docs     regenerate README / START_HERE / Build_Report only
                                              (run after the tests so the report shows their result)
"""
import csv, glob, html, json, os, shutil, subprocess, sys, tempfile
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
VER = "1.0.0"
NAME = f"CAT_QA_v{VER}"
OUT = os.path.join(HERE, "release", NAME)
BANK = f"cat_qa_v{VER}"
BD = "/home/claude/blind_cat"
DATE = "17 October 2026"

CHAPTERS = [
    (1, "Arithmetic", "Percentages", 175), (2, "Arithmetic", "Profit, Loss and Discount", 175),
    (3, "Arithmetic", "Simple and Compound Interest", 100), (4, "Arithmetic", "Ratio, Proportion, Variation and Partnership", 150),
    (5, "Arithmetic", "Averages", 100), (6, "Arithmetic", "Mixtures and Alligations", 100),
    (7, "Arithmetic", "Time and Work", 150), (8, "Arithmetic", "Time, Speed and Distance", 250),
    (9, "Algebra", "Linear Equations", 140), (10, "Algebra", "Quadratic Equations and Polynomials", 130),
    (11, "Algebra", "Inequalities and Modulus", 120), (12, "Algebra", "Logarithms, Surds and Indices", 110),
    (13, "Algebra", "Progressions and Series", 130), (14, "Algebra", "Functions, Graphs and Maxima/Minima", 120),
    (15, "Geometry", "Lines, Angles and Triangles", 120), (16, "Geometry", "Circles", 90),
    (17, "Geometry", "Quadrilaterals and Polygons", 70), (18, "Geometry", "Mensuration", 90),
    (19, "Geometry", "Coordinate Geometry", 50), (20, "Geometry", "Trigonometry and Heights and Distances", 30),
    (21, "Number System", "Factors, Divisibility, HCF and LCM", 90), (22, "Number System", "Remainders and Modular Arithmetic", 70),
    (23, "Number System", "Unit Digits, Bases and Trailing Zeros", 60), (24, "Number System", "Digits, Integer Solutions and Number Properties", 80),
    (25, "Modern Maths", "Permutations and Combinations", 110), (26, "Modern Maths", "Probability", 80),
    (27, "Modern Maths", "Set Theory and Venn Diagrams", 60), (28, "Modern Maths", "Basic Statistics", 50),
]
AREAS = ["Arithmetic", "Algebra", "Geometry", "Number System", "Modern Maths"]

# Blind re-solve rounds. Pilot (C08) used the original pack names; the other 27 chapters were solved by area.
PILOT_ROUNDS = (("C08 round 1 (all items)", "blind_keymap.json", ["01", "02", "03", "04", "05", "06"]),
                ("C08 round 2 (changed items, solver 1)", "blind_keymap_r2.json", ["07"]),
                ("C08 round 2 (changed items, solver 2)", "blind_keymap_r2.json", ["08"]),
                ("C08 round 3 (post-fix edits)", "blind_keymap_r3.json", ["09"]))
GROUP_ROUNDS = [("ARITH", "Arithmetic C01 to C07, round 1 (all items)"), ("ARITHR2A", "Arithmetic, round 2 (changed items, solver set 1)"),
                ("ARITHR2B", "Arithmetic, round 2 (changed items, solver set 2)"), ("ARITHR3", "Arithmetic, round 3 (sweep edits)"),
                ("ALG", "Algebra C09 to C14, round 1 (all items)"), ("ALGR2A", "Algebra, round 2 (changed items, solver set 1)"),
                ("ALGR2B", "Algebra, round 2 (changed items, solver set 2)"), ("ALGR3", "Algebra, round 3 (sweep edits)"),
                ("GEO", "Geometry C15 to C20, round 1 (all items)"), ("GEOR2A", "Geometry, round 2 (changed items, solver set 1)"),
                ("GEOR2B", "Geometry, round 2 (changed items, solver set 2)"),
                ("NSMM", "Number System and Modern Maths C21 to C28, round 1 (all items)"),
                ("NSMMR2A", "Number System and Modern Maths, round 2 (changed items, solver set 1)"),
                ("NSMMR2B", "Number System and Modern Maths, round 2 (changed items, solver set 2)"),
                ("R3LATE", "Geometry, Number System and Modern Maths, round 3 (sweep edits)")]
ADJUDICATION = [
    "C08 (pilot): one item omitted by a round 1 solver was solved and agreed in round 2; two stems were reworded after solver notes and re-solved.",
    "C01-A-035 (round 1): key 522 retained. The stem asks for the largest amount over all orders; the solver evaluated one order only. Confirmed by a permutation check.",
    "C02-B-018 (round 1): key 40 retained. The solver reported the fraction paid (60) rather than the discount; that value is a listed common wrong entry.",
    "C11-B-002 (round 1): key 8 retained. The solver did not halve the lower bound of the inequality; the stem has one reading.",
    "C15-A-030 (round 1): key retained. The solver dropped a triangle-inequality bound it had written itself.",
    "C17-B-012 (round 2): key confirmed by the second solver set and by the machine check.",
    "C24-A-021 and C28-A-029 (round 1): keys correct; C28-A-029's stem was tightened and both items were re-solved and agreed in round 2.",
    "C23-B-009 (round 2): both solver sets found that the option text did not show the computed answer 111. The option was corrected (and the harness now flags any option whose text differs from its value); round 3 agreed.",
]


def wj(rel, obj, indent=1):
    p = os.path.join(OUT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(obj, open(p, "w", encoding="utf-8"), indent=indent, ensure_ascii=False)


def load_records():
    recs = []
    for c, *_ in CHAPTERS:
        recs += json.load(open(os.path.join(HERE, "build", f"C{c:02d}", "records.json"), encoding="utf-8"))
    return recs


def blind_evidence(recs):
    lid = {r["provenance"]["local_id"]: r["id"] for r in recs}
    rounds = []
    for tag, keyfile, packs in PILOT_ROUNDS:
        km = json.load(open(os.path.join(HERE, "verify", keyfile)))
        rows = []
        for p in packs:
            for a in json.load(open(f"{BD}/answers{p}.json")):
                rows.append(dict(id=lid.get(a["id"]), local_id=a["id"], keyed=km[a["id"]], blind_answer=a["answer"],
                                 agree=str(a["answer"]) == str(km[a["id"]]), confidence=a.get("confidence"), working=a["working"], issue=a["issue"]))
        rounds.append(dict(round=tag, items=len(km) if "round 1" in tag else len(rows), answered=len(rows), agree=sum(r["agree"] for r in rows), results=rows))
    for name, tag in GROUP_ROUNDS:
        km = json.load(open(os.path.join(HERE, "verify", "blind", f"{name}_keymap.json")))
        rows = []
        for f in sorted(glob.glob(f"{BD}/answers_{name}_*.json")):
            for a in json.load(open(f)):
                rows.append(dict(id=lid.get(a["id"]), local_id=a["id"], keyed=km[a["id"]], blind_answer=a["answer"],
                                 agree=str(a["answer"]).strip() == str(km[a["id"]]), confidence=a.get("confidence"), working=a["working"], issue=a["issue"]))
        rounds.append(dict(round=tag, pack_set=name, items=len(km), answered=len(rows), agree=sum(r["agree"] for r in rows), results=rows))
    return rounds


def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    recs = load_records()
    n = len(recs)

    # canonical exports
    wj(BANK + ".json", recs)
    with open(os.path.join(OUT, BANK + ".jsonl"), "w", encoding="utf-8") as f:
        for r in recs:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    cols = list(recs[0].keys())
    with open(os.path.join(OUT, BANK + ".csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(cols)
        for r in recs:
            w.writerow([json.dumps(r[c], ensure_ascii=False) if isinstance(r[c], (dict, list)) or r[c] is None else r[c] for c in cols])
    stu_fields = ["id", "section", "area", "chapter_number", "chapter", "topic", "subtopic", "difficulty", "answer_format",
                  "question", "options", "figures", "marks_correct", "marks_incorrect", "marks_unattempted", "exam_tags"]
    wj("questions_only.json", [{k: r[k] for k in stu_fields} for r in recs])
    wj("answers_and_explanations.json", [dict(id=r["id"], answer_format=r["answer_format"], correct_option=r["correct_option"],
                                              tita_answer=r["tita_answer"], correct_answer=r["correct_answer"], explanation=r["explanation"],
                                              common_misconception=r["common_misconception"],
                                              tita_common_wrong_entries=r["tita_common_wrong_entries"]) for r in recs])
    with open(os.path.join(OUT, "question_index.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "area", "chapter", "topic", "subtopic", "difficulty", "format", "key", "question_type", "concept_family", "exam_tags", "has_figure"])
        for r in recs:
            w.writerow([r["id"], r["area"], r["chapter"], r["topic"], r["subtopic"], r["difficulty"], r["answer_format"],
                        r["correct_option"] or r["tita_answer"], r["question_type"], r["concept_family"], " ".join(r["exam_tags"]),
                        "yes" if r["figures"] else ""])
    # figures
    for c, *_ in CHAPTERS:
        fd = os.path.join(HERE, "build", f"C{c:02d}", "figures")
        if os.path.isdir(fd):
            shutil.copytree(fd, os.path.join(OUT, "figures"), dirs_exist_ok=True)
    # family register
    fams = defaultdict(list); aliases = defaultdict(list)
    for r in recs:
        fams[r["concept_family"]].append(r["id"])
        for d in r["family_dependencies"][1:]:
            aliases[d].append(r["id"])
    wj("family_register.json", dict(rule="A generated paper never contains two questions that share any entry of family_dependencies.",
                                    families={k: v for k, v in sorted(fams.items())},
                                    alias_groups={k: v for k, v in sorted(aliases.items())}))
    # coverage
    by_ch = defaultdict(list)
    for r in recs:
        by_ch[r["chapter_number"]].append(r)
    chap_rows = []
    for k, a, c, p in CHAPTERS:
        rs = by_ch[k]
        chap_rows.append(dict(chapter_number=k, area=a, chapter=c, planned=p, built=len(rs), status="built",
                              difficulty=dict(Counter(r["difficulty"] for r in rs)), formats=dict(Counter(r["answer_format"] for r in rs)),
                              figures=sum(1 for r in rs if r["figures"]), families=len({r["concept_family"] for r in rs}),
                              topics=dict(Counter(r["topic"] for r in rs))))
    wj("coverage_map.json", dict(
        exam="CAT (IIM Common Admission Test), Quantitative Ability",
        plan_total=sum(c[3] for c in CHAPTERS), built_total=n,
        basis="Chapter weights follow CAT 2017 to 2025 QA question counts; Modern Maths is deliberately deeper than its exam share for practice.",
        chapters=chap_rows))
    # evidence
    ev = os.path.join(OUT, "evidence"); os.makedirs(ev, exist_ok=True)
    mc, dr, kb = [], [], []
    for k, *_ in CHAPTERS:
        e = os.path.join(HERE, "build", f"C{k:02d}", "evidence")
        mc += json.load(open(os.path.join(e, "machine_checks.json"), encoding="utf-8"))
        dr += json.load(open(os.path.join(e, "distractor_review.json"), encoding="utf-8"))
        kb.append(json.load(open(os.path.join(e, "key_balance.json"))))
    wj("evidence/machine_checks.json", mc)
    wj("distractor_review.json", dr)
    wj("evidence/key_balance.json", kb)
    rounds = blind_evidence(recs)
    wj("evidence/blind_resolve_results.json", dict(
        note="Blind solvers saw only the stem, any figure and (for MCQ) shuffled options. Letters in 'keyed' refer to the shuffled pack order, not the release order. Round 1 covered every item; later rounds re-solved every item changed after round 1, with two independent solver sets.",
        adjudication=ADJUDICATION, rounds=rounds))
    audits, closures, sweeps = {}, {}, {}
    for f in sorted(glob.glob(os.path.join(HERE, "verify", "audit_*.json"))):
        audits[os.path.basename(f)] = json.load(open(f))
    for f in sorted(glob.glob(os.path.join(HERE, "verify", "closure_*.json"))):
        closures[os.path.basename(f)] = json.load(open(f))
    for f in sorted(glob.glob(os.path.join(HERE, "verify", "sweep_*.json"))):
        sweeps[os.path.basename(f)] = json.load(open(f))
    decisions = {os.path.basename(f): open(f).read() for f in sorted(glob.glob(os.path.join(HERE, "verify", "cross_*.md")))}
    wj("evidence/editorial_audit.json", dict(audits=audits, closures=closures, chapter_sweeps=sweeps, lead_editor_decisions=decisions))
    # schema, generator, verify
    shutil.copy(os.path.join(HERE, "question_bank_schema.json"), OUT)
    for f in ("generate_paper.py", "verify_release.py", "Generator_Contract.md"):
        shutil.copy(os.path.join(HERE, f), OUT)
    # sample paper (seed 42)
    subprocess.run([sys.executable, os.path.join(OUT, "generate_paper.py"), "--bank", os.path.join(OUT, BANK + ".json"),
                    "--seed", "42", "--output", os.path.join(OUT, "sample")], check=True)
    sp_ = json.load(open(os.path.join(OUT, "sample_paper.json")))
    sp_["description"] = "A 22-question CAT-style Quantitative Ability section drawn from the full bank."
    wj("sample_paper.json", sp_)
    # books, one pair per chapter
    os.makedirs(os.path.join(OUT, "books"), exist_ok=True)
    env = dict(os.environ, KATEX_PREFIX="../", FIG_ROOT=OUT)
    tmp = tempfile.mkdtemp()
    for k, a, c, p in CHAPTERS:
        rp = os.path.join(tmp, f"c{k:02d}.json")
        json.dump(by_ch[k], open(rp, "w", encoding="utf-8"), ensure_ascii=False)
        subprocess.run(["node", os.path.join(HERE, "render_html.js"), rp, os.path.join(OUT, "books"),
                        f"CAT QA Chapter {k:02d}, {c}", f"Chapter_{k:02d}_Student.html", f"Chapter_{k:02d}_Teacher.html"],
                       check=True, env=env, capture_output=True)
    shutil.rmtree(tmp, ignore_errors=True)
    shutil.rmtree(os.path.join(OUT, "books", "katex"), ignore_errors=True)
    subprocess.run(["node", os.path.join(HERE, "render_html.js"), os.path.join(OUT, BANK + ".json"), OUT,
                    "CAT QA", "-", "-", os.path.join(OUT, "sample_paper.json")], check=True, env=dict(os.environ, FIG_ROOT=OUT), capture_output=True)
    shutil.rmtree(os.path.join(OUT, "katex"), ignore_errors=True)
    kd = os.path.join(OUT, "katex"); os.makedirs(kd, exist_ok=True)
    shutil.copy(os.path.join(HERE, "node_modules/katex/dist/katex.min.css"), kd)
    shutil.copytree(os.path.join(HERE, "node_modules/katex/dist/fonts"), os.path.join(kd, "fonts"), dirs_exist_ok=True)
    # authoring pipeline
    au = os.path.join(OUT, "authoring"); os.makedirs(au)
    for f in ("qlib.py", "harness.py", "optparse.py", "figlib.py", "katex_check.js", "DRAFTING_SPEC.md", "build_chapter.py",
              "assemble_release.py", "render_html.js", "plan_batches.py", "blindtools.py", "apply_aliases.py"):
        shutil.copy(os.path.join(HERE, f), au)
    for d in ("drafts", "briefs", "config", "prompts", "tests", "tools"):
        if os.path.isdir(os.path.join(HERE, d)):
            shutil.copytree(os.path.join(HERE, d), os.path.join(au, d), ignore=shutil.ignore_patterns("__pycache__"))

    sev = Counter(x["severity"] for v in audits.values() for x in v if isinstance(x, dict) and "severity" in x)
    swsev = Counter(x["severity"] for v in sweeps.values() for x in v if isinstance(x, dict) and "severity" in x)
    act = Counter(x.get("action") for v in closures.values() for x in v if isinstance(x, dict))
    r1 = [r for r in rounds if "round 1" in r["round"]]
    later = [r for r in rounds if "round 1" not in r["round"]]
    summary = dict(release=VER, bank=BANK, exam="CAT Quantitative Ability", scope="Full QA bank: 28 chapters in 5 areas",
                   questions=n, difficulty=dict(Counter(r["difficulty"] for r in recs)), formats=dict(Counter(r["answer_format"] for r in recs)),
                   areas=dict(Counter(r["area"] for r in recs)), figures=sum(1 for r in recs if r["figures"]),
                   mcq_key_counts=dict(sorted(Counter(r["correct_option"] for r in recs if r["correct_option"]).items())),
                   families=len(fams), alias_groups=len(aliases),
                   exam_tags=dict(Counter(" ".join(r["exam_tags"]) for r in recs)),
                   verification=dict(machine_recomputed=n,
                                     blind_round1=dict(items=sum(r["items"] for r in r1), agree=sum(r["agree"] for r in r1)),
                                     blind_later_rounds=dict(solves=sum(r["answered"] for r in later), agree=sum(r["agree"] for r in later)),
                                     audit_findings=dict(sev), sweep_findings=dict(swsev), closure_actions=dict(act)))
    wj("release_summary.json", summary)
    write_docs()
    return summary


# ------------------------------------------------------------------ docs
CSS = """:root{--ink:#1b2a3a;--muted:#5b6f80;--brand:#2c4a6e;--bg:#f4f6f8;--line:#dde5ec}
body{margin:0;font:17px/1.6 Arial,Helvetica,sans-serif;background:var(--bg);color:var(--ink)}
header{background:var(--brand);color:#fff;padding:36px 20px}header div,main{max-width:1000px;margin:0 auto}
h1{margin:0 0 6px;font-size:30px}h2{margin:28px 0 8px;font-size:21px}main{padding:16px 20px 40px}
a.card{display:block;background:#fff;border:1px solid var(--line);border-radius:10px;padding:16px 20px;margin:10px 0;color:inherit;text-decoration:none}
a.card:hover{border-color:var(--brand)}a.card b{color:var(--brand);font-size:18px}.muted{color:var(--muted);font-size:15px}
table{border-collapse:collapse;width:100%;background:#fff;font-size:15px;margin:8px 0}th,td{border:1px solid var(--line);padding:6px 9px;text-align:left}
th{background:#e9eff5}td.n{text-align:right}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:10px}
.grid a{background:#fff;border:1px solid var(--line);border-radius:8px;padding:10px 14px;color:inherit;text-decoration:none}.grid a:hover{border-color:var(--brand)}
.pill{display:inline-block;font-size:13px;padding:0 8px;border-radius:10px;background:#e8eef6;color:var(--brand);margin-left:4px}
.ok{color:#1d7a46;font-weight:bold}.bad{color:#b3261e;font-weight:bold}"""


def page(title, head, body):
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{html.escape(title)}</title><style>{CSS}</style></head><body><header><div>{head}</div></header><main>{body}</main></body></html>')


def write_docs():
    s = json.load(open(os.path.join(OUT, "release_summary.json")))
    cov = json.load(open(os.path.join(OUT, "coverage_map.json")))
    blind = json.load(open(os.path.join(OUT, "evidence", "blind_resolve_results.json")))
    tp = os.path.join(OUT, "evidence", "test_results.json")
    tests = json.load(open(tp)) if os.path.exists(tp) else None
    n, d, f = s["questions"], s["difficulty"], s["formats"]
    v = s["verification"]
    tline = (f"{sum(t['status'] == 'PASS' for t in tests)}/{len(tests)} automated tests pass" if tests else "automated tests: see evidence/test_results.json")

    # START_HERE
    by_area = defaultdict(list)
    for c in cov["chapters"]:
        by_area[c["area"]].append(c)
    body = (f'<a class="card" href="Sample_Paper.html"><b>Sample section</b><br><span class="muted">22 questions in 40 minutes, the CAT QA format (14 MCQ, 8 TITA), drawn across all areas.</span></a>'
            f'<a class="card" href="Sample_Solutions.html"><b>Sample solutions</b><br><span class="muted">Keys and worked solutions for the sample section.</span></a>'
            f'<a class="card" href="Build_Report.html"><b>Build report</b><br><span class="muted">What was built, chapter by chapter, and how every question was verified.</span></a>')
    for a in AREAS:
        cs = by_area[a]
        body += f'<h2>{a} <span class="pill">{sum(c["built"] for c in cs)} questions</span></h2><div class="grid">'
        for c in cs:
            k = c["chapter_number"]
            body += (f'<div style="background:#fff;border:1px solid var(--line);border-radius:8px;padding:10px 14px"><b>{k:02d}</b> {html.escape(c["chapter"])} '
                     f'<span class="pill">{c["built"]}</span><br><a href="books/Chapter_{k:02d}_Student.html" style="border:0;padding:0">Student book</a> &middot; '
                     f'<a href="books/Chapter_{k:02d}_Teacher.html" style="border:0;padding:0">Teacher book</a></div>')
        body += '</div>'
    body += '<p class="muted">Data files, the paper generator and the authoring pipeline are described in README.md.</p>'
    open(os.path.join(OUT, "START_HERE.html"), "w").write(page("CAT QA Bank", f'<h1>CAT Quantitative Ability question bank</h1><p>{n} questions in 28 chapters &middot; {f["MCQ"]} MCQ + {f["TITA"]} TITA &middot; {s["figures"]} with figures &middot; v{VER}</p>', body))

    # Build report
    rows = "".join(f'<tr><td>{c["chapter_number"]:02d}</td><td>{html.escape(c["chapter"])}</td><td>{c["area"]}</td><td class="n">{c["built"]}</td>'
                   f'<td class="n">{c["difficulty"].get("Easy", 0)} / {c["difficulty"].get("Medium", 0)} / {c["difficulty"].get("Difficult", 0)}</td>'
                   f'<td class="n">{c["formats"].get("MCQ", 0)} / {c["formats"].get("TITA", 0)}</td><td class="n">{c["families"]}</td><td class="n">{c["figures"]}</td></tr>'
                   for c in cov["chapters"])
    brows = "".join(f'<tr><td>{html.escape(r["round"])}</td><td class="n">{r["answered"]}</td><td class="n">{r["agree"]}</td></tr>' for r in blind["rounds"])
    adj = "".join(f"<li>{html.escape(x)}</li>" for x in blind["adjudication"])
    tests_html = ("<table><tr><th>Test</th><th>Result</th></tr>" + "".join(
        f'<tr><td>{html.escape(t["test"])}</td><td class="{"ok" if t["status"] == "PASS" else "bad"}">{t["status"]}</td></tr>' for t in tests) + "</table>") if tests else ""
    sev = v["audit_findings"]; sw = v["sweep_findings"]
    body = f"""<h2>What is in the bank</h2>
<p>{n} original CAT-style Quantitative Ability questions: {d["Easy"]} Easy, {d["Medium"]} Medium and {d["Difficult"]} Difficult (30 / 45 / 25 percent),
{f["MCQ"]} MCQ (+3 / &minus;1) and {f["TITA"]} TITA (+3 / 0, whole-number answers), {s["figures"]} geometry questions with code-drawn figures.
MCQ keys are balanced within every chapter (overall {", ".join(f"{k} {c}" for k, c in s["mcq_key_counts"].items())}), with no letter run longer than 3.
{s["families"]} concept families and {s["alias_groups"]} alias groups stop a generated paper from repeating a method.</p>
<table><tr><th>Ch</th><th>Chapter</th><th>Area</th><th>Qs</th><th>E / M / D</th><th>MCQ / TITA</th><th>Families</th><th>Figures</th></tr>{rows}</table>
<h2>How it was verified</h2>
<ol><li><b>Machine check.</b> All {v["machine_recomputed"]} answers are recomputed by code from the givens (sympy equations, simulation or brute-force enumeration), and every MCQ distractor is confirmed to differ from the key and from the other distractors.</li>
<li><b>Blind re-solve.</b> Independent solvers who never saw the keys solved every question: {v["blind_round1"]["agree"]} of {v["blind_round1"]["items"]} agreed in round 1, and every disagreement was adjudicated (below).
Every question changed after round 1 was then solved again by two separate solver sets, and the final edits once more: {v["blind_later_rounds"]["agree"]} of {v["blind_later_rounds"]["solves"]} later solves agreed.</li>
<li><b>Hostile editorial audit</b> of every item ({sev.get("critical", 0)} critical, {sev.get("major", 0)} major, {sev.get("minor", 0)} minor findings, mostly duplicates across batches, weak distractors and difficulty labels),
all closed by correcting authors under lead-editor decisions, then a post-fix sweep of every chapter ({sw.get("critical", 0)} critical, {sw.get("major", 0)} major, {sw.get("minor", 0)} minor), also closed. Remaining near-duplicates became alias groups.</li>
<li><b>Automated tests:</b> {tline}.</li></ol>
<table><tr><th>Blind round</th><th>Solved</th><th>Agreed</th></tr>{brows}</table>
<h2>Adjudicated disagreements</h2><ul>{adj}</ul>
<h2>Automated tests</h2>{tests_html}
<h2>Notes and limits</h2><ul>
<li>Difficulty labels are editorial estimates on the CAT scale, not calibrated against student data. Recalibrate after the first cohort's attempt data.</li>
<li>No human subject expert has reviewed the bank; the field <code>human_subject_expert_reviewed</code> is false on every record.</li>
<li>Questions are original; none reproduces a past CAT paper. Easy and most Medium items also suit XAT, NMAT, SNAP, CMAT and MAH-CET; harder items are tagged CAT and XAT.</li>
<li>Next phases: VARC, then DILR (sets with code-drawn charts), on the same pipeline.</li></ul>"""
    open(os.path.join(OUT, "Build_Report.html"), "w").write(page("CAT QA Build Report", f"<h1>CAT QA v{VER}: build report</h1><p>Paper Tree Educational Studio &middot; {DATE}</p>", body))

    # README
    t = "\n".join(f"| {c['chapter_number']:02d} | {c['chapter']} | {c['area']} | {c['built']} | {c['formats'].get('TITA', 0)} | {c['figures']} |" for c in cov["chapters"])
    md = f"""# CAT Quantitative Ability question bank v{VER}

Prepared {DATE} by Paper Tree Educational Studio. The complete CAT QA bank: {n} original CAT-style
questions in 28 chapters across Arithmetic, Algebra, Geometry, Number System and Modern Maths.

Extract the whole folder and open **START_HERE.html**. Keep the `katex` and `figures` folders where
they are; the books use them offline.

## At a glance

- {f["MCQ"]} MCQ (four options, one correct, +3 / -1) and {f["TITA"]} TITA (type a whole number, +3 / 0): the 35 percent TITA share of the CAT QA section.
- {d["Easy"]} Easy / {d["Medium"]} Medium / {d["Difficult"]} Difficult (30 / 45 / 25 percent), labelled on the CAT scale.
- {s["figures"]} geometry questions carry an SVG figure drawn to scale from the stem's data (never showing the unknown).
- MCQ keys balanced within each chapter, no letter run longer than 3.
- {s["families"]} concept families plus {s["alias_groups"]} alias groups, so a generated paper never repeats a method.
- Exam reuse tags on every item (CAT always; XAT, NMAT, SNAP, CMAT, MAH-CET where suitable).

| Ch | Chapter | Area | Questions | TITA | Figures |
|---|---|---|---:|---:|---:|
{t}

## Files

- `{BANK}.json`, `.jsonl` and `.csv`: the canonical bank (schema v2). In the CSV, nested fields are JSON-encoded. Mathematics is LaTeX inline between `$...$`.
- `questions_only.json` and `answers_and_explanations.json`: the student and teacher exports.
- `books/Chapter_NN_Student.html` and `books/Chapter_NN_Teacher.html`: a searchable, filterable, printable pair for every chapter. The teacher book shows keys, worked solutions, the misconception each item targets and, for TITA, the common wrong entries.
- `figures/`: the SVG figure files referenced by the `figures` field of each record.
- `Sample_Paper.html` and `Sample_Solutions.html`: a 22-question, 40-minute CAT-style section (seed 42).
- `generate_paper.py` and `Generator_Contract.md`: the paper generator. Example:
  `python generate_paper.py --bank {BANK}.json --seed 7 --output practice7`.
  Options: `--questions`, `--tita`, `--chapter 8`, `--area Algebra`, `--exam XAT`, `--minutes`.
- `question_bank_schema.json`: schema v2 (MCQ and TITA, exam tags, figures, and a `set_id` reserved for VARC passages and DILR sets).
- `coverage_map.json`, `family_register.json`, `question_index.csv`, `distractor_review.json` (the error behind every wrong option and every common TITA wrong entry).
- `evidence/`: machine checks with source code, all blind re-solve rounds with adjudication, the editorial audits, closures, chapter sweeps and lead-editor decisions, key balancing and the automated test results.
- `authoring/`: the full pipeline (drafting spec, briefs, draft sources, harness, figure library, build scripts, prompts, tests), so the bank can be extended or corrected the same way.
- `Build_Report.html`: chapter table and verification summary.
- `verify_release.py`: reproduces the structural checks with the Python standard library only.

## How it was verified

1. Every answer is recomputed by code from the givens in the stem, and every MCQ distractor is confirmed distinct from the key.
2. Blind re-solve of all {v["blind_round1"]["items"]} questions by solvers who never saw the keys ({v["blind_round1"]["agree"]} agreed in round 1; every disagreement adjudicated in `evidence/blind_resolve_results.json`). Every changed item was solved again by two separate solver sets and the final edits once more ({v["blind_later_rounds"]["agree"]}/{v["blind_later_rounds"]["solves"]} agreed).
3. Hostile editorial audit of every item, correction under lead-editor decisions, then a post-fix sweep of every chapter for changed items and duplicates.
4. {tline} (`authoring/tests/test_release.py`): schema, full rebuild reproducibility, harness on every draft, machine checks, KaTeX rendering of every string, export parity, no answer leakage, 200 generator seeds, and a mutation test.

## Conventions

- Units are those stated in each stem; TITA stems always name the unit. Areas and volumes are written cm$^2$, m$^3$ and so on.
- Clock times are written like 9:00 am. Money is written Rs. 1,200.
- Unless a question says otherwise, rates and speeds are constant and people start at the same time.
- Difficulty labels are editorial estimates; recalibrate them with student attempt data.
"""
    open(os.path.join(OUT, "README.md"), "w").write(md)


if __name__ == "__main__":
    if "--docs" in sys.argv:
        write_docs()
    else:
        print(json.dumps(main(), indent=1))
