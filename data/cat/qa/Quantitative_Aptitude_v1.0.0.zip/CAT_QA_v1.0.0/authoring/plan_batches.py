# -*- coding: utf-8 -*-
"""Chapter and batch plan for the full CAT QA bank. Generates briefs/CNN-X.md and config/CNN.json.

Quotas: the whole bank is exactly 900 Easy / 1350 Medium / 750 Difficult and 1050 TITA.
Chapter 08 (pilot) is fixed at 75/113/62 and 88 TITA; the rest are allocated by largest remainder.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))

CH = {}  # num -> dict(name, area, topics[list], conventions, batches=[(letter, n, topics_subset, scope_text)])


def chap(num, name, area, topics, conventions, batches):
    CH[num] = dict(name=name, area=area, topics=topics, conventions=conventions, batches=batches)


GEN = "Unless a stem says otherwise: "

chap(1, "Percentages", "Arithmetic",
     ["Percentage basics and conversions", "Successive percentage change", "Population and depreciation",
      "Price, consumption and expenditure", "Elections and examinations", "Income, expenditure and savings",
      "Percentage word problems"],
     "Percentage points versus percent must be stated precisely. Do not use profit/loss/discount or interest settings (other chapters).",
     [("A", 45, ["Percentage basics and conversions", "Successive percentage change"],
       "- Fractions and percentages, x% of y, 'x% more than' versus 'x% less than', reverse percentages (finding the original after a change).\n- Successive changes: net effect of +a% then -b%, three-stage changes, finding a missing change for a target net change, percentage points versus percent."),
      ("B", 45, ["Population and depreciation", "Price, consumption and expenditure"],
       "- Population growth or decline over several years with year-wise different rates, births/deaths/migration as percentages, machine or vehicle depreciation (no interest/loan settings).\n- Product constancy: price rises so consumption must fall to keep expenditure fixed; expenditure change when price and consumption both change; percentage change in area or volume when dimensions change."),
      ("C", 45, ["Elections and examinations", "Income, expenditure and savings"],
       "- Elections: votes polled, invalid votes, margin of victory, two- and three-candidate contests, voters who switched.\n- Examinations: pass marks, percentage failing in subjects (no Venn-diagram-heavy items; those are chapter 27), marks needed.\n- Income, expenditure and savings: salary components, changes in income and expenditure and their effect on savings, households with two earners."),
      ("D", 40, ["Percentage word problems"],
       "- Harder multi-variable percentage puzzles in CAT style: organisations with departments, students in streams, product sales across years, comparisons of groups, percentage of a percentage, finding the base when several conditions interlock, ranges of possible values.\nEXCLUDE: anything that is mainly profit/loss, interest, mixtures or Venn-diagram counting.")])

chap(2, "Profit, Loss and Discount", "Arithmetic",
     ["Cost price, selling price and profit", "Marked price and discount", "Successive discounts and offers",
      "Dishonest dealers and false weights", "Chains of sellers", "Multiple transactions and optimisation"],
     GEN + "profit and loss percentages are on cost price; discount percentages are on marked price. State any other basis explicitly.",
     [("A", 45, ["Cost price, selling price and profit"],
       "- Profit and loss percentages, profit as a percentage of selling price versus cost price (stated explicitly), buying x articles for Rs. y and selling z for Rs. w, two articles sold at the same price with gain and loss, break-even."),
      ("B", 45, ["Marked price and discount", "Successive discounts and offers"],
       "- Marked price, discount and profit together, mark-up needed for a target profit after discount.\n- Successive discounts and their single equivalent, buy-n-get-m-free offers, cashback, comparing two offers."),
      ("C", 45, ["Dishonest dealers and false weights", "Chains of sellers"],
       "- False weights or measures, cheating both when buying and when selling, adulteration only as a cheating device (mixture-pricing questions belong to chapter 06).\n- Manufacturer to wholesaler to retailer chains with profit at each stage, final price to customer, sales tax added on selling price where stated."),
      ("D", 40, ["Multiple transactions and optimisation"],
       "- Harder CAT-style items: goods sold in lots at different prices, overall profit with some goods spoiled, price-demand trade-offs (profit maximisation with integer price steps), repeated buying and selling of the same item, finding cost from two scenarios.")])

chap(3, "Simple and Compound Interest", "Arithmetic",
     ["Simple interest", "Compound interest", "Instalments and present value"],
     GEN + "interest is compounded annually; rates are per annum. State half-yearly or quarterly compounding explicitly.",
     [("A", 35, ["Simple interest"],
       "- SI basics, finding rate or time, sums lent in parts at different rates, interest earned on a sum that doubles, amounts after different periods, comparing SI deals."),
      ("B", 35, ["Compound interest"],
       "- CI basics, half-yearly and quarterly compounding, difference between CI and SI for 2 and 3 years, sums that multiply over time, different rates in successive years, effective annual rate."),
      ("C", 30, ["Instalments and present value"],
       "- Equal annual instalments under SI and CI, present value of a future payment, choosing between payment plans, loans partly repaid, investments split between SI and CI schemes.")])

chap(4, "Ratio, Proportion, Variation and Partnership", "Arithmetic",
     ["Ratio basics", "Proportion and variation", "Partnership", "Ratio puzzles"],
     "Do not write mixture or alligation items (chapter 06) or age problems (chapter 09).",
     [("A", 40, ["Ratio basics"],
       "- Combining ratios (a:b and b:c), dividing a sum in a ratio, coins and notes in a ratio, ratio of quantities after equal additions or subtractions, compounded and duplicate ratios."),
      ("B", 40, ["Proportion and variation"],
       "- Direct, inverse and joint variation, partly fixed and partly variable costs, mean and third proportional, variation word problems (costs, speeds, resources)."),
      ("C", 35, ["Partnership"],
       "- Profit sharing by capital multiplied by time, partners joining or withdrawing, working partner's salary or commission before division, changes in investment midway."),
      ("D", 35, ["Ratio puzzles"],
       "- Harder CAT-style ratio problems: ratios that change after transfers between groups, three-group ratios with integer constraints, ratios of incomes and expenditures, ranges of possible values.")])

chap(5, "Averages", "Arithmetic",
     ["Averages basics", "Weighted averages and groups", "Averages puzzles"],
     "Do not ask for median, mode or standard deviation (chapter 28).",
     [("A", 35, ["Averages basics"],
       "- Averages of sets, adding, removing or replacing members, average age of a group over time, average of consecutive numbers and arithmetic sequences."),
      ("B", 35, ["Weighted averages and groups"],
       "- Weighted averages of groups, combined class averages, batting and bowling averages, average speed is chapter 08 (exclude), salaries across departments."),
      ("C", 30, ["Averages puzzles"],
       "- Harder: maximum or minimum possible value of a member given averages and constraints, distinct integers with a given average, averages that change after a correction, multi-step CAT puzzles.")])

chap(6, "Mixtures and Alligations", "Arithmetic",
     ["Alligation", "Replacement", "Multi-vessel mixtures"],
     "Concentrations are by volume unless stated.",
     [("A", 35, ["Alligation"],
       "- Mixing two varieties to a target price or concentration, alligation applied to averages, profit when selling a mixture, mixing to a target ratio."),
      ("B", 35, ["Replacement"],
       "- Repeated removal and replacement (milk and water), quantity after n operations, finding the volume removed each time, replacement with a different liquid."),
      ("C", 30, ["Multi-vessel mixtures"],
       "- Three or more vessels, transfers between vessels, three-component mixtures, harder CAT-style items with integer or range answers.")])

chap(7, "Time and Work", "Arithmetic",
     ["Work and efficiency", "Pipes and cisterns", "Work and wages", "Work puzzles"],
     GEN + "every worker or pipe works at a constant rate.",
     [("A", 40, ["Work and efficiency"],
       "- Combined work, efficiency ratios, total-work-as-LCM method, one worker leaving or joining, work done on alternate days."),
      ("B", 40, ["Pipes and cisterns"],
       "- Inlets and outlets, leaks, pipes opened at different times or closed after some time, tanks with capacity changes."),
      ("C", 35, ["Work and wages"],
       "- Man-days, men, women and children with different rates, wages shared by work done, contract completion with workforce changes."),
      ("D", 35, ["Work puzzles"],
       "- Harder: variable efficiency, workers joining in a pattern, minimising time or cost, integer constraints on the number of workers, multi-stage projects.")])

chap(9, "Linear Equations", "Algebra",
     ["Systems of linear equations", "Ages and everyday linear problems", "Integer-constrained linear problems"],
     "Digit-based problems are chapter 24; keep them out.",
     [("A", 45, ["Systems of linear equations"],
       "- Two and three variable systems from word problems (tickets, purchases, scores), consistency, unique, no or infinitely many solutions, parameter values for which a system has a given type of solution."),
      ("B", 45, ["Ages and everyday linear problems"],
       "- Age problems (present, past, future, ratios of ages), coins and notes, puzzles about people and items, working backwards."),
      ("C", 50, ["Integer-constrained linear problems"],
       "- Word problems whose unknowns must be whole numbers (buying items with exact money, chickens and cows style, seats in buses), number of possible solutions, maximum or minimum of one unknown.")])

chap(10, "Quadratic Equations and Polynomials", "Algebra",
     ["Roots and coefficients", "Quadratic word problems and conditions", "Polynomials"],
     GEN + "coefficients are real.",
     [("A", 45, ["Roots and coefficients"],
       "- Sum and product of roots, symmetric functions of roots, forming equations with transformed roots, nature of roots, integer roots."),
      ("B", 45, ["Quadratic word problems and conditions"],
       "- Word problems leading to quadratics, conditions on roots (both positive, opposite signs, one root in an interval), common roots, parameter ranges."),
      ("C", 40, ["Polynomials"],
       "- Remainder and factor theorems, cubic and quartic roots via Vieta, polynomial identities, values of polynomials at points, number of real roots of simple higher-degree equations.")])

chap(11, "Inequalities and Modulus", "Algebra",
     ["Linear and quadratic inequalities", "Modulus", "Inequality-based optimisation"],
     "",
     [("A", 40, ["Linear and quadratic inequalities"],
       "- Solving linear, quadratic and rational inequalities, counting integer solutions, the wavy-curve method, systems of inequalities."),
      ("B", 40, ["Modulus"],
       "- Equations and inequalities with |x|, sums of moduli and their minimum, number of solutions of modulus equations, piecewise reasoning."),
      ("C", 40, ["Inequality-based optimisation"],
       "- AM-GM and similar bounds, maximum or minimum of expressions under constraints, integer optimisation with inequalities.")])

chap(12, "Logarithms, Surds and Indices", "Algebra",
     ["Indices", "Surds", "Logarithms"],
     "log without a base means base 10; write natural log as $\\log_e$ if needed.",
     [("A", 40, ["Indices"],
       "- Laws of exponents, exponential equations, comparing large powers, simplifying expressions with powers."),
      ("B", 35, ["Surds"],
       "- Rationalising, nested radicals, comparing surds, sums of conjugate surds, simplification."),
      ("C", 35, ["Logarithms"],
       "- Laws of logarithms, logarithmic equations and their domains, change of base, number of digits via logarithms, comparing logarithms.")])

chap(13, "Progressions and Series", "Algebra",
     ["Arithmetic progressions", "Geometric progressions", "Special series"],
     "",
     [("A", 45, ["Arithmetic progressions"],
       "- nth term, sums, terms common to two APs, word problems (savings, seats in rows), number of terms satisfying a condition, AP with integer constraints."),
      ("B", 45, ["Geometric progressions"],
       "- nth term and sums of GPs, infinite GPs, mixed AP and GP conditions, word problems (bouncing ball, doubling)."),
      ("C", 40, ["Special series"],
       "- Sums of squares and cubes, telescoping sums, arithmetico-geometric series, recurrence-defined sequences, patterns.")])

chap(14, "Functions, Graphs and Maxima/Minima", "Algebra",
     ["Functions", "Graphs", "Maxima and minima"],
     "Graphs are described in words or equations; no figures in this chapter.",
     [("A", 40, ["Functions"],
       "- Domain and range, composition, inverse, functional equations f(x+y) type, even and odd, iterated functions, functions defined on integers."),
      ("B", 40, ["Graphs"],
       "- Transformations of graphs, number of intersection points of two curves, area of a region bounded by simple lines (no calculus), behaviour of |f(x)| and f(|x|)."),
      ("C", 40, ["Maxima and minima"],
       "- Max/min of quadratics and of max/min-type functions, piecewise functions, word optimisation with algebra (no calculus), min of max(...) expressions.")])

chap(15, "Lines, Angles and Triangles", "Geometry",
     ["Lines and angles", "Similarity and congruence", "Triangle properties and centres"],
     "Figures allowed (see the spec's figure section).",
     [("A", 40, ["Lines and angles"],
       "- Parallel lines and transversals, angle sums, exterior angles, isosceles and equilateral triangles, triangle inequality, number of triangles with integer sides."),
      ("B", 40, ["Similarity and congruence"],
       "- Similar triangles, basic proportionality theorem, angle bisector theorem, ratio of areas, triangles in trapeziums and shadows."),
      ("C", 40, ["Triangle properties and centres"],
       "- Pythagoras and triples, 30-60-90 and 45-45-90 triangles, Heron's formula, medians (Apollonius), centroid, incentre and circumcentre, inradius and circumradius.")])

chap(16, "Circles", "Geometry",
     ["Chords, tangents and angles", "Circle combinations"],
     "Figures allowed.",
     [("A", 45, ["Chords, tangents and angles"],
       "- Chord properties, angles subtended, cyclic quadrilaterals, tangent-chord angle, tangent lengths from a point, intersecting chords and secants."),
      ("B", 45, ["Circle combinations"],
       "- Two or more circles (common tangents, touching circles), circles inscribed in or circumscribed about polygons, arcs, sectors and segments, shaded regions.")])

chap(17, "Quadrilaterals and Polygons", "Geometry",
     ["Quadrilaterals", "Polygons"],
     "Figures allowed.",
     [("A", 35, ["Quadrilaterals"],
       "- Parallelograms, rhombuses, rectangles, squares and trapeziums: sides, diagonals, angles and areas; quadrilaterals formed by midpoints."),
      ("B", 35, ["Polygons"],
       "- Regular polygons: interior and exterior angles, number of diagonals, regular hexagon and octagon areas, polygons from cutting corners, composite figures.")])

chap(18, "Mensuration", "Geometry",
     ["Plane mensuration", "Solid mensuration"],
     "Use $\\pi$ symbolically unless a stem gives $\\pi = \\frac{22}{7}$. Figures allowed.",
     [("A", 45, ["Plane mensuration"],
       "- Areas and perimeters of composite plane figures, paths around fields, shaded regions combining squares, triangles and circular parts."),
      ("B", 45, ["Solid mensuration"],
       "- Cubes, cuboids, cylinders, cones, spheres and hemispheres, frustums, melting and recasting, water level changes, painted-cube counting, diagonals of cuboids.")])

chap(19, "Coordinate Geometry", "Geometry",
     ["Coordinate geometry"],
     "Figures allowed.",
     [("A", 50, ["Coordinate geometry"],
       "- Distance and section formulae, area of a triangle or polygon from vertices, slopes, equations of lines, distance from a point to a line, reflections, lattice points on a segment or inside a region, area of regions defined by inequalities such as $|x| + |y| \\le k$, basic circle equations.")])

chap(20, "Trigonometry and Heights and Distances", "Geometry",
     ["Trigonometry and heights and distances"],
     "Angles in degrees. Figures allowed.",
     [("A", 30, ["Trigonometry and heights and distances"],
       "- Standard angle values, simple identities, heights and distances with angles of elevation and depression (towers, buildings, poles), two observers, moving observers.")])

chap(21, "Factors, Divisibility, HCF and LCM", "Number System",
     ["Factors and divisibility", "HCF and LCM"],
     "",
     [("A", 45, ["Factors and divisibility"],
       "- Number, sum and product of factors, odd/even/perfect-square factors, divisibility rules, numbers with exactly k factors."),
      ("B", 45, ["HCF and LCM"],
       "- HCF and LCM properties, word problems (bells tolling together, tiles, largest measuring length), numbers with given HCF and LCM, counting pairs.")])

chap(22, "Remainders and Modular Arithmetic", "Number System",
     ["Remainders", "Modular arithmetic theorems"],
     "",
     [("A", 35, ["Remainders"],
       "- Remainders of sums and products, cyclicity of remainders, remainders of powers by small divisors, successive division, numbers leaving given remainders."),
      ("B", 35, ["Modular arithmetic theorems"],
       "- Fermat's little theorem, Euler's totient, Wilson's theorem, Chinese remainder style problems, remainders of large expressions.")])

chap(23, "Unit Digits, Bases and Trailing Zeros", "Number System",
     ["Unit and last digits", "Bases and factorials"],
     "",
     [("A", 30, ["Unit and last digits"],
       "- Unit digit of powers, products and sums, last two digits of powers."),
      ("B", 30, ["Bases and factorials"],
       "- Number bases (conversion and arithmetic), trailing zeros of n!, highest power of a prime or composite dividing n!, trailing zeros in other bases.")])

chap(24, "Digits, Integer Solutions and Number Properties", "Number System",
     ["Digit problems", "Integer solutions and number properties"],
     "",
     [("A", 40, ["Digit problems"],
       "- Two- and three-digit numbers with digit conditions, reversing digits, sum of digits, counting numbers with digit properties, forming numbers from given digits (divisibility conditions)."),
      ("B", 40, ["Integer solutions and number properties"],
       "- Integer solutions of linear and simple non-linear equations (not word problems), perfect squares and cubes, primes, parity, consecutive integers, number puzzles.")])

chap(25, "Permutations and Combinations", "Modern Maths",
     ["Arrangements", "Selections and distributions", "Advanced counting"],
     "Check every count by brute-force enumeration in code where feasible.",
     [("A", 40, ["Arrangements"],
       "- Permutations with restrictions, arranging letters of words, people in rows with conditions, numbers formed from digits (counts only)."),
      ("B", 35, ["Selections and distributions"],
       "- Combinations with restrictions, committees, distributing identical and distinct objects into boxes, selections from groups."),
      ("C", 35, ["Advanced counting"],
       "- Circular arrangements, derangements, grid paths, non-negative integer solutions of equations, counting triangles/rectangles in figures described in words, handshakes and matches.")])

chap(26, "Probability", "Modern Maths",
     ["Basic probability", "Conditional and compound probability"],
     "Answers as exact fractions; TITA only when the asked quantity is an integer (for example a count or $100p$ when integral).",
     [("A", 40, ["Basic probability"],
       "- Coins, dice, cards, balls from bags, selections, complementary counting, numbers with properties."),
      ("B", 40, ["Conditional and compound probability"],
       "- Independent events, conditional probability, at least one, sequential draws, simple expected values, games with turns.")])

chap(27, "Set Theory and Venn Diagrams", "Modern Maths",
     ["Two- and three-set problems", "Maximum and minimum overlaps"],
     "",
     [("A", 30, ["Two- and three-set problems"],
       "- Surveys with two or three sets, exactly one, exactly two, none, union and intersection counts."),
      ("B", 30, ["Maximum and minimum overlaps"],
       "- Maximum and minimum possible values of intersections or of 'none', constraints from percentages, harder CAT-style Venn puzzles.")])

chap(28, "Basic Statistics", "Modern Maths",
     ["Basic statistics"],
     "",
     [("A", 50, ["Basic statistics"],
       "- Mean, median, mode and range of data sets, effect of adding, removing or changing values, standard deviation and variance basics (effect of shifting and scaling), finding missing values from conditions.")])


def allocate():
    batches = []
    for num in sorted(CH):
        for (L, n, tp, sc) in CH[num]["batches"]:
            batches.append([num, L, n])
    total = sum(b[2] for b in batches)
    assert total == 2750, total
    targets = {"Easy": 825, "Medium": 1237, "Difficult": 688, "TITA": 962}

    def lr(key, frac):
        raw = [b[2] * frac for b in batches]
        base = [int(x) for x in raw]
        rem = targets[key] - sum(base)
        order = sorted(range(len(batches)), key=lambda i: -(raw[i] - base[i]))
        for i in order[:rem]:
            base[i] += 1
        return base
    E = lr("Easy", 825 / 2750); D = lr("Difficult", 688 / 2750); T = lr("TITA", 962 / 2750)
    out = []
    for b, e, d, t in zip(batches, E, D, T):
        m = b[2] - e - d
        out.append(dict(ch=b[0], letter=b[1], n=b[2], easy=e, medium=m, difficult=d, tita=t))
    assert sum(x["medium"] for x in out) == 1237
    return out


def main():
    os.makedirs(os.path.join(HERE, "briefs"), exist_ok=True)
    os.makedirs(os.path.join(HERE, "config"), exist_ok=True)
    alloc = allocate()
    json.dump(alloc, open(os.path.join(HERE, "config", "batch_plan.json"), "w"), indent=1)
    for a in alloc:
        c = CH[a["ch"]]
        L = a["letter"]
        b = [x for x in c["batches"] if x[0] == L][0]
        tag = f"C{a['ch']:02d}"
        others = [f"{tag}-{x[0]}: {', '.join(x[2])}" for x in c["batches"] if x[0] != L]
        fig = c["area"] == "Geometry"
        text = f"""# Brief {tag}-{L}: {c['name']} ({', '.join(b[2])})

Chapter {a['ch']:02d} of the CAT QA bank: {c['name']} (area: {c['area']}).

- Output file: `/home/claude/catqa/drafts/{tag.lower()}_{L.lower()}.py`
- Local ID prefix: `{tag}-{L}` (IDs `{tag}-{L}-001` ... `{tag}-{L}-{a['n']:03d}`)
- Family slug prefix: `{tag}{L}-` (for example `{tag}{L}-some-method-name`)
- topic field: exactly one of: {'; '.join(b[2])}. subtopic: a precise one-line description of the item.

## Quotas (exact)
- Total {a['n']} questions: Easy {a['easy']}, Medium {a['medium']}, Difficult {a['difficult']}.
- TITA: exactly {a['tita']} of the {a['n']}; the rest MCQ. Spread TITA across difficulty levels.
- At least {max(10, a['n'] // 3)} distinct families; at most 3 items per family.
- Use a mix of question types; at least 4 "Conceptual/application" and at least 4 "Casework/optimisation" or "Inverse/parameter" items.

## Scope
{b[3]}

Other batches of this chapter (do NOT write their content): {'; '.join(others) if others else 'none'}.

## Chapter conventions
{c['conventions'] or 'None beyond the spec.'}
{'' if not fig else chr(10) + '## Figures' + chr(10) + 'This is a geometry chapter. Read the FIGURES section of the spec and /home/claude/catqa/figlib.py. Give a figure to roughly 30 to 40 percent of your items, where a CAT paper would show one. A figure must be drawn from the stem data and must never show the unknown being asked for.' + chr(10)}
## Harness command
`cd /home/claude/catqa && python3 harness.py drafts/{tag.lower()}_{L.lower()}.py --easy {a['easy']} --medium {a['medium']} --difficult {a['difficult']} --tita {a['tita']}`
"""
        open(os.path.join(HERE, "briefs", f"{tag}-{L}.md"), "w").write(text)
    for num, c in CH.items():
        tag = f"C{num:02d}"
        cfg = dict(chapter_number=num, chapter=c["name"], area=c["area"], section="Quantitative Ability",
                   count=sum(x[1] for x in c["batches"]),
                   draft_files=[f"drafts/{tag.lower()}_{x[0].lower()}.py" for x in c["batches"]],
                   topic_order=c["topics"], alias_groups={})
        p = os.path.join(HERE, "config", f"{tag}.json")
        if os.path.exists(p):
            old = json.load(open(p)); cfg["alias_groups"] = old.get("alias_groups", {})
        json.dump(cfg, open(p, "w"), indent=1)
    print(len(alloc), "batches")


if __name__ == "__main__":
    main()
