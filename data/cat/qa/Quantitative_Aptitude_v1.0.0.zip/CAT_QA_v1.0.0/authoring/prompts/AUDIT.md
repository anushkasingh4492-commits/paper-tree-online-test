You are a hostile senior editor auditing one drafting file of a commercial CAT Quantitative Ability bank (chapter: Time, Speed and Distance). Your job is to find every real defect before students do. You are told a batch letter X.

Read /home/claude/catqa/DRAFTING_SPEC.md and /home/claude/catqa/briefs/C08-X.md, then audit every question in /home/claude/catqa/drafts/c08_x.py (lower-case x). You may load the questions with:
  cd /home/claude/catqa && python3 -c "import sys;sys.path.insert(0,'.');from harness import load;import json;qs=load('drafts/c08_x.py');print(len(qs))"
You may also skim the other drafts/c08_*.py files, but only to spot near-duplicates of items in your file.

For EVERY item, independently re-solve it (use python3 to verify), then check:
- E1 key: is the key right? Is there exactly one defensible answer? Any missing assumption (direction, simultaneous start, train lengths, first meeting, whether the start counts, etc.) that allows another answer?
- E2 distractors/traps: does each named error really produce exactly that value? Is any distractor absurd, or does it violate a condition in the stem? Is the key the odd one out in form? Are options parallel in units and form?
- E3 house style: no em/en dashes or double hyphens, LaTeX units style ($54$ km/h), no option letters named in explanations, no A/B/C/D labels in MCQ stems, no meta commentary (reviews, corrections, "this question"), TITA stems state the unit and ask for an integer, TITA stems never mention options.
- E4 difficulty and scope: is the Easy/Medium/Difficult label fair on the CAT scale in the spec? Is the item inside the brief's scope? Is it CAT-like (a situation, not a drill)? Are the exam reuse tags sensible (Difficult items usually CAT and XAT only)?
- E5 explanation: is every step true and does it reach the key? Is it clear?
- E6 duplicates: near-copies within the file or against other C08 files (same model, numbers only changed) that do NOT already share a family.

Do NOT edit any draft file. Write your findings to /home/claude/catqa/verify/audit_X.json (upper-case X) as a JSON list of objects:
{"id": "<local id>", "category": "E1".."E6", "severity": "critical"|"major"|"minor", "finding": "<concrete description>", "fix": "<concrete proposed fix: new stem text, new option and value, new label, etc.>"}
critical = wrong key or two defensible answers; major = misleading distractor rationale, missing assumption a reasonable student would trip on, explanation error, wrong difficulty by two levels, scope violation, true duplicate; minor = style or polish. Do not pad with trivia, but do not miss real issues. An empty list is acceptable only if the file is truly clean.

Report back in one line: counts of critical / major / minor findings.
