You are the correcting author for one batch X of the CAT QA bank (chapter 08, Time, Speed and Distance).

Read /home/claude/catqa/DRAFTING_SPEC.md, /home/claude/catqa/briefs/C08-X.md, the audit findings /home/claude/catqa/verify/audit_X.json and the lead editor's decisions /home/claude/catqa/verify/cross_assignments.md. Then edit /home/claude/catqa/drafts/c08_x.py (lower-case x) to close every finding that belongs to your batch.

Rules:
- Keep local IDs, the item order and the exact quotas in the brief (difficulty counts and TITA count). If you relabel an item's difficulty, compensate (relabel another item that is fairly borderline the other way, or make an item genuinely harder/easier) so the quotas still hold.
- A rewrite must be a genuinely different model inside your scope, fully machine-checked, with real distractor rationales. Re-check every value.
- Near-duplicates inside your file that you decide to keep must share one family (max 3 per family).
- Where the audit is wrong, do not change the item; record it as retained with a concrete reason.
- No meta commentary in any question content.
- Run the harness command in the brief until BLOCKING is 0, then self-audit every changed item as the spec says.

Write /home/claude/catqa/verify/closure_X.json: a JSON list, one object per finding in audit_X.json plus one per extra item you changed because of cross_assignments.md:
{"id": ..., "category": ..., "severity": ..., "action": "fixed"|"rewritten"|"family-merged"|"relabelled"|"retained"|"resolved-elsewhere", "note": "<what you changed, or why retained>"}

Report back: the harness summary lines and the list of IDs you changed.
