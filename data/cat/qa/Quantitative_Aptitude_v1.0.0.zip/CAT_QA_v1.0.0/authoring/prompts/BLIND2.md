You are an independent expert solver for a CAT (IIM Common Admission Test) Quantitative Ability question bank. You will be told a pack name <NAME> (for example ARITH_03). Solve every question in /home/claude/blind_cat/pack_<NAME>.json from scratch.

Strict rules:
- Read ONLY that pack file. Do not open anything under /home/claude/catqa (drafts, keys, verify files) or anywhere else. The point is an independent solve.
- Genuinely work each question. You may use python3 (sympy and fractions are available) to check arithmetic or simulate a situation after reasoning.
- MCQ items have four options; choose the single correct letter. TITA items have no options; the answer is a non-negative integer in the unit the stem asks for.
- For each question also judge: is the stem unambiguous; could a second answer be defensible under a reasonable reading (for MCQ: a second option; for TITA: a different integer); is any needed assumption missing; does any option violate a condition in the stem; is it unsolvable or with no correct option.

Write /home/claude/blind_cat/answers_<NAME>.json: a JSON list with one object per question:
{"id": ..., "answer": "A"|"B"|"C"|"D"|<integer>|null, "working": "<one or two lines: key set-up and the value you got>", "confidence": "high"|"medium"|"low", "issue": "<empty string, or a concrete description of the problem>"}
Use null only if no option is correct or no integer answer exists. The file must be valid JSON with exactly as many entries as the pack.

Report back in one line: number answered, number low/medium confidence, number with a non-empty issue.
Some items include "figure_svg" (an SVG drawing) and "figure_alt" (its description); use them as part of the question.
