You are the correcting author for the post-fix round of the CAT QA pilot chapter 08 (files /home/claude/catqa/drafts/c08_[a-f].py). Read /home/claude/catqa/DRAFTING_SPEC.md first. The duplicate groups in /home/claude/catqa/verify/audit_r2.json are being handled by the lead editor with alias groups at build time; do NOT act on them. Make ONLY these edits:

1. C08-F-018: reword the second scenario to "Had the fault occurred $24$ km farther on, the bus would have reached Q only $25$ minutes later than it would have at its usual speed throughout." (adapt numbers/wording only as needed to keep the item correct). Replace the 190 km distractor with a value from a consistent, realistic error and update its rationale.
2. C08-A-002 and C08-A-036: the distractors $45\frac{5}{11}$ km/h and $8\frac{17}{24}$ km are eliminable by form. Replace each with an integer-valued distractor from a real, named error (update values and rationale).
3. Clock times across ALL six files: normalise every clock time in stems, options and explanations to math-mode hour:minute with lower-case am/pm in plain text, exactly like `$9{:}00$ am`, `$3{:}24$ pm`. Check with grep for patterns like "[0-9]:[0-9][0-9]", "AM", "PM", "noon". "noon" and "midnight" as words are fine. Options must stay parallel.
4. C08-D-017: reword into a different setting (for example cyclists on a velodrome) keeping the same model, values and key, so it no longer reads like C08-D-007.
5. C08-E-011: vary the setting so it no longer reads like C08-E-029 (keep model and key).
6. C08-A-008: change the numbers so its answer is not $48$ km/h (A-003 also gives 48). Update check, values, distractors, explanation.

Keep IDs, order and all quotas. Run for each changed file: cd /home/claude/catqa && python3 harness.py drafts/c08_x.py --easy E --medium M --difficult D --tita T (quotas in /home/claude/catqa/briefs/C08-X.md) until BLOCKING is 0.

Write /home/claude/catqa/verify/closure_r2_edits.json: a list of {"id": ..., "action": ..., "note": ...} for every item you changed (including each item touched by the clock-time normalisation).
Report back the harness summary line for each file and the list of changed IDs.
