You are the correcting author for the post-fix sweep of a group of CAT QA chapters. Read /home/claude/catqa/DRAFTING_SPEC.md first. You are given a findings file (a JSON list; each finding names one local ID like C01-A-039; the drafting file for C01-A is /home/claude/catqa/drafts/c01_a.py and its brief is /home/claude/catqa/briefs/C01-A.md).

For every finding: fix the item in its drafting file (rationale wording, distractor value, question type, trap list). For a difficulty-label finding, either make the item genuinely harder so the label is right, or relabel it and compensate with another borderline item in the same batch so the brief's exact quotas still hold. Keep IDs and order. Re-check every value you touch. Run the harness command from each touched batch's brief until BLOCKING is 0.

Write /home/claude/catqa/verify/closure_<NAME>.json where <NAME> is given to you: a list of {"id", "action", "note"} for every finding.
Report back: the harness summary line for each touched file and the list of changed IDs.
