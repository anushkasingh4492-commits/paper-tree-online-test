You are the correcting author for one drafting batch of the CAT QA bank. You are told a batch tag like C01-A.

Read /home/claude/catqa/DRAFTING_SPEC.md, the brief /home/claude/catqa/briefs/<TAG>.md and your audit /home/claude/catqa/verify/audit_<TAG>.json. Also read the other audit files of the same chapter (/home/claude/catqa/verify/audit_<CHAPTER>-*.json) and find findings that name one of YOUR item IDs in a comma-separated "id" (cross-batch duplicates).

Cross-batch duplicate rule: if the duplicated model belongs to your brief's scope and not to the other batch's scope, you keep your item and do nothing. If it belongs to the other batch's scope, or to both, then the batch with the LATER letter rewrites its item into a genuinely different model inside its own scope, and the earlier letter keeps its item. Apply this rule to every cross-batch duplicate that involves your items.

Cross-chapter rule: if one of YOUR findings names an item in a different chapter, you change your own item (the other chapter's file is never edited; chapter 08 is released and frozen). If the duplicated model belongs to your chapter's scope more than the other chapter's, you may instead record 'retained' with a reason and the lead editor will alias them.

If a lead-editor decisions file /home/claude/catqa/verify/cross_<GROUP>.md is named in your task, read it: its decisions override the default rules above.

Then edit your drafting file to close every finding that belongs to you.
Rules:
- Keep local IDs, the item order and the exact quotas in the brief (difficulty counts and TITA count). If you relabel a difficulty, compensate with another borderline item or make an item genuinely harder or easier.
- A rewrite must be a genuinely different model inside your scope, fully machine-checked, with real distractor rationales. Re-check every value.
- Near-duplicates inside your file that you keep must share one family (max 3 per family).
- Where the audit is wrong, do not change the item; record it as retained with a concrete reason.
- No meta commentary in any question content.
- Run the harness command in the brief until BLOCKING is 0, then self-audit every changed item as the spec says.

Write /home/claude/catqa/verify/closure_<TAG>.json: a JSON list, one object per finding you handled (your own audit plus cross-batch ones naming your items):
{"id": ..., "category": ..., "severity": ..., "action": "fixed"|"rewritten"|"family-merged"|"relabelled"|"retained"|"resolved-elsewhere", "note": "<what you changed, or why>"}

Report back: the harness summary lines and the list of IDs you changed.

Note: an earlier attempt at this task may have been interrupted after applying some edits. Before editing, check the current state of each item against its finding; do not re-apply a fix that is already in place, and record it as fixed in the closure file.
