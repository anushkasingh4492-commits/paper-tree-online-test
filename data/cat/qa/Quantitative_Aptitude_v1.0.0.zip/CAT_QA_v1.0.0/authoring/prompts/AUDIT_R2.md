You are a hostile senior editor doing the post-fix review of the CAT QA pilot chapter (08, Time, Speed and Distance), 250 items in /home/claude/catqa/drafts/c08_[a-f].py. Read /home/claude/catqa/DRAFTING_SPEC.md first.

Load all items with:
  cd /home/claude/catqa && python3 -c "import sys;sys.path.insert(0,'.');from harness import load;qs=sum((load(f'drafts/c08_{b}.py') for b in 'abcdef'),[]);print(len(qs))"

Task 1 (changed items): the IDs in /home/claude/catqa/verify/changed_r1.json were rewritten or corrected after the first audit. For each, re-solve independently with python3 and check E1 key and uniqueness, E2 every distractor/trap rationale reproduces its value and no option violates the stem, E3 house style (no dashes, units in LaTeX style, no meta commentary, TITA states the unit), E4 difficulty fairness and scope, E5 explanation correctness.

Task 2 (whole chapter duplicate sweep): across all 250 items, find pairs or groups that use the same model with only numbers or context changed AND sit in different families (so one generated paper could contain both). Same family is fine. Also flag any two items whose stems are near-identical.

Do NOT edit drafts. Write /home/claude/catqa/verify/audit_r2.json as a JSON list of {"id": ..., "category": "E1".."E6", "severity": "critical"|"major"|"minor", "finding": ..., "fix": ...}. For a duplicate group, put the IDs comma-separated in "id" and propose either a shared alias group or a rewrite.

Report back one line: counts of critical / major / minor.
