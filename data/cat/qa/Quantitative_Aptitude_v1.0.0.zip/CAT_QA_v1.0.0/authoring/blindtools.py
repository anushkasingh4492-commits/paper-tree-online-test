# -*- coding: utf-8 -*-
"""Make blind packs and score blind answers.
make:  python3 blindtools.py make <name> <npacks> <ids-json-or-'-'> <draft files...>
score: python3 blindtools.py score <name>
"""
import glob, json, os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from harness import load
BD = "/home/claude/blind_cat"
VD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "verify", "blind")


def make(name, npacks, idfile, files):
    os.makedirs(BD, exist_ok=True); os.makedirs(VD, exist_ok=True)
    qs = sum((load(f) for f in files), [])
    if idfile != "-":
        want = set(json.load(open(idfile)))
        qs = [x for x in qs if x["local_id"] in want]
    rnd = random.Random(name)
    rnd.shuffle(qs)
    km = {}
    for p in range(npacks):
        items = []
        for x in qs[p::npacks]:
            if x["answer_format"] == "MCQ":
                opts = [(x["correct"], "K")] + [(d["text"], "D") for d in x["distractors"]]; rnd.shuffle(opts)
                it = dict(id=x["local_id"], format="MCQ", question=x["question"], options={L: t for L, (t, _) in zip("ABCD", opts)})
                km[x["local_id"]] = [L for L, (t, k) in zip("ABCD", opts) if k == "K"][0]
            else:
                it = dict(id=x["local_id"], format="TITA", question=x["question"]); km[x["local_id"]] = x["tita_answer"]
            if x["figure"]:
                it["figure_svg"] = x["figure"]["svg"]; it["figure_alt"] = x["figure"]["alt"]
            items.append(it)
        json.dump(items, open(f"{BD}/pack_{name}_{p + 1:02d}.json", "w"), indent=1)
    json.dump(km, open(f"{VD}/{name}_keymap.json", "w"), indent=1)
    print(name, len(qs), "items in", npacks, "packs")


def score(name):
    km = json.load(open(f"{VD}/{name}_keymap.json"))
    seen, bad, issues = set(), [], []
    for f in sorted(glob.glob(f"{BD}/answers_{name}_*.json")):
        for a in json.load(open(f)):
            seen.add(a["id"])
            if str(a["answer"]).strip() != str(km.get(a["id"])):
                bad.append(dict(id=a["id"], keyed=km.get(a["id"]), blind=a["answer"], working=a["working"], issue=a["issue"]))
            elif a.get("issue"):
                issues.append(dict(id=a["id"], issue=a["issue"]))
    missing = sorted(set(km) - seen)
    res = dict(name=name, items=len(km), answered=len(seen & set(km)), agree=len(seen & set(km)) - len(bad), disagreements=bad, issues=issues, missing=missing)
    json.dump(res, open(f"{VD}/{name}_score.json", "w"), indent=1)
    print(name, "items", len(km), "answered", res["answered"], "agree", res["agree"], "disagree", len(bad), "issues", len(issues), "missing", len(missing))
    return res


if __name__ == "__main__":
    if sys.argv[1] == "make":
        make(sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5:])
    else:
        score(sys.argv[2])
