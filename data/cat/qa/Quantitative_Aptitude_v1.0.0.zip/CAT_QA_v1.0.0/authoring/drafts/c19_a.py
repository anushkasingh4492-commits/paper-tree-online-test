import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig

T = "Coordinate geometry"
CX = ("CAT", "XAT")
x, y, k, c, t, a, b = symbols('x y k c t a b', real=True)
R_ = Rational


# ---------------------------------------------------------------- helpers
def _dist(P, Q):
    return sqrt((Q[0] - P[0])**2 + (Q[1] - P[1])**2)


def _area(*V):
    s = 0
    n = len(V)
    for i in range(n):
        x1, y1 = V[i]; x2, y2 = V[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return Abs(R_(s, 2)) if isinstance(s, int) else Abs(s) / 2


def _line_sl(eq):
    # returns (slope, intercept) of a non-vertical line given as sympy expression = 0
    sol = solve(eq, y)[0]
    sl = diff(sol, x)
    return (simplify(sl), simplify(sol.subs(x, 0)))


def _reflect(P, A, B, C):
    # image of P in line Ax + By + C = 0
    d = R_(A * P[0] + B * P[1] + C, A * A + B * B)
    return (P[0] - 2 * A * d, P[1] - 2 * B * d)


def _axes(f, x0, x1, y0, y1, origin=True):
    span = max(x1 - x0, y1 - y0)
    e = 0.05 * span
    f.seg((x0, 0), (x1, 0)); f.seg((0, y0), (0, y1))
    f.text((x1 + e, -e), "x"); f.text((-e, y1 + e * 0.6), "y")
    if origin:
        f.text((-e, -e), "O")


# ================================================================= EASY
# ---------------------------------------------------------------- 001
def _c001():
    P, Q = (2, -3), (10, 12)
    return _dist(P, Q) * 50
q("C19-A-001", T, "Distance between two points on a scaled map", "Easy",
  "Single-step computation",
  r"On a city map drawn on a coordinate grid, $1$ unit represents $50$ m. Ravi's house is at $P(2, -3)$ and his school is at $Q(10, 12)$. What is the straight-line distance, in metres, between his house and his school?",
  "TITA",
  r"$PQ = \sqrt{(10 - 2)^2 + (12 - (-3))^2} = \sqrt{64 + 225} = \sqrt{289} = 17$ units. Since $1$ unit is $50$ m, the distance is $17 \times 50 = 850$ m.",
  "Adding the horizontal and vertical differences (grid distance) instead of using the distance formula, or forgetting the map scale.",
  "C19A-distance-two-points", "Distance formula with a negative coordinate and one scaling step.",
  tita_answer=850, check=_c001, cognitive="Application",
  tita_traps=[(1150, r"Adds the differences $8 + 15 = 23$ units instead of using the distance formula."),
              (17, "Reports the distance in map units without applying the scale.")])

# ---------------------------------------------------------------- 002
def _c002():
    sol = solve(Eq((x - 2)**2 + 5**2, (x - 8)**2 + 3**2), x)
    return sol[0]
q("C19-A-002", T, "Point on the x-axis equidistant from two given points", "Easy",
  "Inverse/parameter",
  r"Two houses stand at $P(2, 5)$ and $Q(8, 3)$. A water tank is to be placed on a straight road that runs along the $x$-axis so that the tank is equally far from both houses. At which point on the road should the tank be placed?",
  "MCQ",
  r"Let the tank be at $(x, 0)$. Then $(x - 2)^2 + 25 = (x - 8)^2 + 9$, so $x^2 - 4x + 29 = x^2 - 16x + 73$. This gives $12x = 44$, so $x = \frac{11}{3}$ and the point is $\left(\frac{11}{3}, 0\right)$.",
  "Taking the point below the midpoint of PQ, which is correct only when P and Q are at the same height.",
  "C19A-equidistant-point", "One equation from equal distances; linear after expansion.",
  correct=r"$\left(\frac{11}{3}, 0\right)$",
  distractors=[(r"$(5, 0)$", r"Takes the point directly below the midpoint of $PQ$, ignoring that the houses are at different heights."),
               (r"$\left(\frac{29}{6}, 0\right)$", r"Forgets to square the $y$-differences: $(x-2)^2 + 5 = (x-8)^2 + 3$ gives $12x = 58$."),
               (r"$\left(-\frac{11}{3}, 0\right)$", r"Sign slip when collecting terms: writes $-4x + 29 = -16x + 73$ as $12x = -44$.")],
  check=_c002, values=[R_(11, 3), 5, R_(29, 6), R_(-11, 3)], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    P, Q = (R_(-4), R_(10)), (R_(8), R_(-2))
    m, n = 1, 3  # PR : RQ
    return ((m * Q[0] + n * P[0]) / (m + n), (m * Q[1] + n * P[1]) / (m + n))
q("C19-A-003", T, "Internal division of a segment in a given ratio", "Easy",
  "Single-step computation",
  r"A straight cable runs from $P(-4, 10)$ to $Q(8, -2)$. A support pole stands at a point $R$ on the cable such that $PR$ is one-third of $RQ$. What are the coordinates of $R$?",
  "MCQ",
  r"$PR : RQ = 1 : 3$, so $R$ is $\frac{1}{4}$ of the way from $P$ to $Q$. $Q - P = (12, -12)$, so $R = (-4 + 3, 10 - 3) = (-1, 7)$.",
  "Reading 'PR is one-third of RQ' as 'PR is one-third of PQ'.",
  "C19A-section-internal", "Single application of the section formula; trap in translating the ratio.",
  correct=r"$(-1, 7)$",
  distractors=[(r"$(0, 6)$", r"Takes $PR$ as one-third of $PQ$, that is $R = P + \frac{1}{3}(12, -12)$."),
               (r"$(5, 1)$", r"Reverses the ratio and places $R$ with $PR : RQ = 3 : 1$."),
               (r"$(-10, 16)$", r"Uses the external division formula $\frac{1 \cdot Q - 3 \cdot P}{1 - 3}$.")],
  check=_c003, values=[(-1, 7), (0, 6), (5, 1), (-10, 16)], cognitive="Application")

# ---------------------------------------------------------------- 004
def _c004():
    return _area((1, 2), (7, 4), (3, 10)) * 10 * 10
f = Fig()
P = f.pt("P(1, 2)", 1, 2); Q = f.pt("Q(7, 4)", 7, 4, offset=(2.6, 0)); R = f.pt("R(3, 10)", 3, 10)
f.poly(P, Q, R)
_alt = "Triangle with corners P(1, 2), Q(7, 4) and R(3, 10) drawn on map coordinates."
q("C19-A-004", T, "Area of a triangle from its vertices, with a map scale", "Easy",
  "Multi-step word problem",
  r"A triangular plot of land is drawn on a map in which $1$ unit represents $10$ m. Its corners are at $P(1, 2)$, $Q(7, 4)$ and $R(3, 10)$. What is the actual area of the plot?",
  "MCQ",
  r"Map area $= \frac{1}{2}\left|1(4 - 10) + 7(10 - 2) + 3(2 - 4)\right| = \frac{1}{2}\left|-6 + 56 - 6\right| = 22$ square units. Each square unit is $10 \times 10 = 100$ m$^2$, so the area is $2{,}200$ m$^2$.",
  "Scaling an area by the linear scale factor instead of its square, or dropping the factor one-half.",
  "C19A-triangle-area-vertices", "Shoelace formula plus squaring the scale.",
  correct=r"$2{,}200$ m$^2$",
  distractors=[(r"$4{,}400$ m$^2$", r"Drops the factor $\frac{1}{2}$ in the area formula: $44 \times 100$."),
               (r"$220$ m$^2$", r"Multiplies the area by the linear scale $10$ instead of $100$."),
               (r"$440$ m$^2$", r"Drops the $\frac{1}{2}$ and also scales by $10$: $44 \times 10$.")],
  check=_c004, values=[2200, 4400, 220, 440], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 005
def _c005():
    return _area((0, 0), (8, 0), (10, 6), (2, 9))
f = Fig()
P = f.pt("P(0, 0)", 0, 0, offset=(0, -1.2)); Q = f.pt("Q(8, 0)", 8, 0, offset=(0, -1.2)); R = f.pt("R(10, 6)", 10, 6, offset=(0, 1.2)); S = f.pt("S(2, 9)", 2, 9, offset=(-2.6, 0))
f.poly(P, Q, R, S)
_alt = "Quadrilateral park PQRS with corners P(0, 0), Q(8, 0), R(10, 6) and S(2, 9), in metres."
q("C19-A-005", T, "Area of a quadrilateral by the shoelace formula", "Easy",
  "Single-step computation",
  r"A park is in the shape of a quadrilateral $PQRS$ whose corners, taken in order, are $P(0, 0)$, $Q(8, 0)$, $R(10, 6)$ and $S(2, 9)$, with coordinates in metres. What is the area of the park, in m$^2$?",
  "TITA",
  r"By the shoelace formula, $\sum (x_i y_{i+1} - x_{i+1} y_i) = 0 + (8 \cdot 6 - 10 \cdot 0) + (10 \cdot 9 - 2 \cdot 6) + (2 \cdot 0 - 0 \cdot 9) = 48 + 78 = 126$. The area is $\frac{126}{2} = 63$ m$^2$.",
  "Forgetting to halve the shoelace sum, or listing the vertices out of order.",
  "C19A-polygon-area-shoelace", "Direct shoelace computation on four vertices.",
  tita_answer=63, check=_c005, cognitive="Application",
  tita_traps=[(126, "Forgets to halve the shoelace sum."),
              (12, r"Takes the vertices in the order $P, R, Q, S$, which is not the boundary order: $\frac{1}{2}|0 - 48 + 72 + 0| = 12$.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 006
def _c006():
    m = -1 / R_(3, 4)  # perpendicular to 3x - 4y + 7 = 0 (slope 3/4)
    line = y - 3 - m * (x - 2)
    return _line_sl(line)
q("C19-A-006", T, "Line through a point perpendicular to a given line", "Easy",
  "Single-step computation",
  r"A straight pipeline is to be laid through the point $P(2, 3)$, perpendicular to the line $3x - 4y + 7 = 0$. The equation of the pipeline is",
  "MCQ",
  r"The given line has slope $\frac{3}{4}$, so the pipeline has slope $-\frac{4}{3}$. Through $(2, 3)$: $y - 3 = -\frac{4}{3}(x - 2)$, that is $3y - 9 = -4x + 8$, or $4x + 3y = 17$.",
  "Taking the reciprocal of the slope without changing its sign, or changing the sign without taking the reciprocal.",
  "C19A-line-perpendicular-through-point", "One slope rule and point-slope form.",
  correct=r"$4x + 3y = 17$",
  distractors=[(r"$3x - 4y + 6 = 0$", r"Writes the line through $P$ parallel to the given line instead of perpendicular."),
               (r"$4x - 3y + 1 = 0$", r"Uses slope $\frac{4}{3}$, the reciprocal without the change of sign."),
               (r"$3x + 4y = 18$", r"Uses slope $-\frac{3}{4}$, changing the sign but not taking the reciprocal.")],
  check=_c006, values=[(R_(-4, 3), R_(17, 3)), (R_(3, 4), R_(3, 2)), (R_(4, 3), R_(1, 3)), (R_(-3, 4), R_(9, 2))],
  cognitive="Application")

# ---------------------------------------------------------------- 007
def _c007():
    V = [(2, 7), (-4, 1), (11, 4)]
    G = (R_(sum(v[0] for v in V), 3), R_(sum(v[1] for v in V), 3))
    return _dist((0, 0), G)
q("C19-A-007", T, "Centroid of a triangle and its distance from the origin", "Easy",
  "Multi-step word problem",
  r"Three friends live at $P(2, 7)$, $Q(-4, 1)$ and $R(11, 4)$ on a map whose units are kilometres. They agree to meet at the centroid of triangle $PQR$. How far, in km, is the meeting point from the origin?",
  "TITA",
  r"The centroid is $\left(\frac{2 - 4 + 11}{3}, \frac{7 + 1 + 4}{3}\right) = (3, 4)$. Its distance from the origin is $\sqrt{9 + 16} = 5$ km.",
  "Adding the coordinates of the vertices without dividing by 3.",
  "C19A-centroid", "Centroid formula followed by one distance.",
  tita_answer=5, check=_c007, cognitive="Application",
  tita_traps=[(15, r"Uses the coordinate sums $(9, 12)$ without dividing by $3$."),
              (7, r"Adds the centroid's coordinates $3 + 4$ instead of using the distance formula.")])

# ---------------------------------------------------------------- 008
def _c008():
    sol = solve(Eq((5 - (-1)) * (k - 1), (11 - (-1)) * (4 - 1)), k)
    return sol[0]
q("C19-A-008", T, "Collinearity of three points with one unknown coordinate", "Easy",
  "Inverse/parameter",
  r"Three lamp posts stand in a straight line at $P(1, -1)$, $Q(4, 5)$ and $R(k, 11)$. What is the value of $k$?",
  "MCQ",
  r"The slope of $PQ$ is $\frac{5 - (-1)}{4 - 1} = 2$. For $R$ to be on the same line, $\frac{11 - (-1)}{k - 1} = 2$, so $k - 1 = 6$ and $k = 7$.",
  "Inverting the slope (run over rise) or mishandling the negative coordinate.",
  "C19A-collinearity-parameter", "One slope equality; sign trap with the negative coordinate.",
  correct=r"$7$",
  distractors=[(r"$25$", r"Writes the slope of $PR$ as run over rise but keeps the slope of $PQ$ as rise over run: $\frac{k - 1}{12} = 2$, so $k = 25$."),
               (r"$6$", r"Takes the rise from $P$ to $R$ as $11 - 1 = 10$, so $10 = 2(k - 1)$."),
               (r"$-5$", r"Uses slope $-2$ after a sign slip: $12 = -2(k - 1)$.")],
  check=_c008, values=[7, 25, 6, -5], cognitive="Application")

# ---------------------------------------------------------------- 009
def _c009():
    A, B, C0 = 6, 8, -15
    X = (3, -2)
    return Abs(A * X[0] + B * X[1] + C0) / sqrt(A * A + B * B)
q("C19-A-009", T, "Perpendicular distance from a point to a line", "Easy",
  "Single-step computation",
  r"A straight canal runs along the line $6x + 8y = 15$, where all distances are in km. A farmhouse is at the point $(3, -2)$. What is the shortest distance from the farmhouse to the canal?",
  "MCQ",
  r"Write the line as $6x + 8y - 15 = 0$. The distance is $\frac{|6(3) + 8(-2) - 15|}{\sqrt{36 + 64}} = \frac{|18 - 16 - 15|}{10} = \frac{13}{10} = 1.3$ km.",
  "Not moving the constant to the left side before substituting, or forgetting to divide by the square root of the sum of squares.",
  "C19A-point-line-distance", "Direct use of the distance formula with one sign trap.",
  correct=r"$1.3$ km",
  distractors=[(r"$1.7$ km", r"Substitutes into $6x + 8y + 15$, keeping the constant on the wrong side: $\frac{17}{10}$."),
               (r"$1.9$ km", r"Takes $y = +2$: $\frac{|18 + 16 - 15|}{10} = 1.9$."),
               (r"$13$ km", r"Forgets to divide by $\sqrt{6^2 + 8^2} = 10$.")],
  check=_c009, values=[R_(13, 10), R_(17, 10), R_(19, 10), 13], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    P, Q = (-6, 4), (30, 28)
    cnt = 0
    dx, dy = Q[0] - P[0], Q[1] - P[1]
    for X in range(P[0], Q[0] + 1):
        num = (X - P[0]) * dy
        if num % dx == 0:
            cnt += 1
    return cnt
q("C19-A-010", T, "Lattice points on a segment using the gcd of the differences", "Easy",
  "Conceptual/application",
  r"A straight fence runs from $(-6, 4)$ to $(30, 28)$, with coordinates in metres. A post is fixed at every point of the fence both of whose coordinates are integers, including the two ends. How many posts are there?",
  "TITA",
  r"The differences are $36$ and $24$, with $\gcd(36, 24) = 12$. The lattice points are spaced at steps of $\left(\frac{36}{12}, \frac{24}{12}\right) = (3, 2)$, so there are $12$ steps and $12 + 1 = 13$ posts.",
  "Counting the gcd itself (the number of gaps) or excluding the end points.",
  "C19A-lattice-segment", "Single gcd idea with a fence-post count.",
  tita_answer=13, check=_c010, cognitive="Understanding",
  tita_traps=[(12, r"Reports $\gcd(36, 24) = 12$, the number of gaps, not posts."),
              (11, "Excludes both end points.")])

# ---------------------------------------------------------------- 011
def _c011():
    K = 6
    # integrate the width of the region over x
    return integrate(2 * (K - Abs(x)), (x, -K, K))
q("C19-A-011", T, "Area of the region |x| + |y| <= k", "Easy",
  "Conceptual/application",
  r"A flower bed is laid out as the set of all points $(x, y)$ satisfying $|x| + |y| \le 6$, with $x$ and $y$ in metres. What is the area of the flower bed?",
  "MCQ",
  r"The boundary $|x| + |y| = 6$ is a square with vertices $(\pm 6, 0)$ and $(0, \pm 6)$. Its diagonals are both $12$ m, so the area is $\frac{12 \times 12}{2} = 72$ m$^2$.",
  "Treating the vertex distance 6 as the side of the square, or the diagonal 12 as the side.",
  "C19A-mod-region-area", "Recognising a tilted square and using its diagonals.",
  correct=r"$72$ m$^2$",
  distractors=[(r"$36$ m$^2$", r"Takes the square's side as $6$, the distance from the centre to a vertex."),
               (r"$144$ m$^2$", r"Takes the square's side as the diagonal $12$."),
               (r"$18$ m$^2$", r"Computes only the first-quadrant triangle $\frac{6 \times 6}{2}$.")],
  check=_c011, values=[72, 36, 144, 18], cognitive="Understanding")

# ---------------------------------------------------------------- 012
def _c012():
    expr = x**2 + y**2 - 6*x + 8*y - 24
    g, h = -Rational(expr.coeff(x, 1), 2), -Rational(expr.coeff(y, 1), 2)
    r = sqrt(g**2 + h**2 - expr.subs({x: 0, y: 0}))
    return _dist((0, 0), (g, h)) + r
q("C19-A-012", T, "Farthest point of a circle from a given point", "Easy",
  "Multi-step word problem",
  r"The edge of a circular pond is the circle $x^2 + y^2 - 6x + 8y - 24 = 0$, with distances in metres. A floating buoy is at the origin. What is the distance, in metres, from the buoy to the farthest point on the edge of the pond?",
  "TITA",
  r"Completing squares, $(x - 3)^2 + (y + 4)^2 = 9 + 16 + 24 = 49$, so the centre is $(3, -4)$ and the radius is $7$. The centre is $\sqrt{9 + 16} = 5$ m from the buoy. The farthest point lies on the line through the buoy and the centre, beyond the centre: $5 + 7 = 12$ m.",
  "Reporting the nearest distance (radius minus centre distance) or just the radius.",
  "C19A-circle-centre-radius", "Completing squares and one distance; two short steps.",
  tita_answer=12, check=_c012, cognitive="Application",
  tita_traps=[(2, r"Gives the nearest distance $7 - 5$."),
              (7, "Reports the radius.")])

# ---------------------------------------------------------------- 013
def _c013():
    return _reflect((3, 8), 1, 1, -5)
q("C19-A-013", T, "Reflection of a point in the line x + y = c", "Easy",
  "Single-step computation",
  r"A straight mirror lies along the line $x + y = 5$. What is the mirror image of the point $P(3, 8)$ in this line?",
  "MCQ",
  r"For the line $x + y = 5$, the image of $(x, y)$ is $(5 - y, 5 - x)$, because the midpoint of the point and its image must lie on the line and the joining segment has slope $1$. So the image of $(3, 8)$ is $(5 - 8, 5 - 3) = (-3, 2)$.",
  "Using the rule for y = x, or forgetting to swap the coordinates.",
  "C19A-reflection-point-line", "Single reflection in a line of slope -1.",
  correct=r"$(-3, 2)$",
  distractors=[(r"$(8, 3)$", r"Reflects in the line $y = x$ instead of $x + y = 5$."),
               (r"$(2, -3)$", r"Writes the image as $(5 - x, 5 - y)$ without swapping coordinates."),
               (r"$(-8, -3)$", r"Ignores the constant and reflects in $x + y = 0$.")],
  check=_c013, values=[(-3, 2), (8, 3), (2, -3), (-8, -3)], cognitive="Application")

# ---------------------------------------------------------------- 014
def _c014():
    P, Q, R = Matrix([1, 5]), Matrix([3, 1]), Matrix([13, 3])
    # S is the fourth corner of parallelogram PQRS: diagonals PR and QS bisect each other
    sx, sy = symbols('sx sy')
    s = solve([Eq((P[0] + R[0]) / 2, (Q[0] + sx) / 2), Eq((P[1] + R[1]) / 2, (Q[1] + sy) / 2)], [sx, sy])
    S = (s[sx], s[sy])
    assert (Matrix(S) - R) == (P - Q)   # PS parallel and equal to QR, so PQRS is a parallelogram
    return _dist((Q[0], Q[1]), S)
f = Fig()
P = f.pt("P(1, 5)", 1, 5, offset=(1.8, 0.4)); Q = f.pt("Q(3, 1)", 3, 1, offset=(0, -1.1)); R = f.pt("R(13, 3)", 13, 3, offset=(0.4, -1.1))
f.seg(P, Q); f.seg(Q, R)
_alt = "Three corners of a parallelogram park: P(1, 5), Q(3, 1) and R(13, 3), with sides PQ and QR drawn; the fourth corner S is not shown."
q("C19-A-014", T, "Fourth vertex of a parallelogram and the length of a diagonal", "Easy",
  "Multi-step word problem",
  r"A park is in the shape of a parallelogram $PQRS$, with its corners taken in that order. Three of the corners are $P(1, 5)$, $Q(3, 1)$ and $R(13, 3)$, with coordinates in metres. A straight path is laid along the diagonal from $Q$ to the fourth corner $S$. What is the length of the path, in metres?",
  "TITA",
  r"The diagonals of a parallelogram bisect each other, so $P + R = Q + S$ and $S = (1 + 13 - 3, 5 + 3 - 1) = (11, 7)$. Then $QS = \sqrt{(11 - 3)^2 + (7 - 1)^2} = \sqrt{64 + 36} = 10$ m.",
  "Reporting the distance from Q to the centre (half the diagonal), or adding the coordinate differences.",
  "C19A-parallelogram-fourth-vertex", "One idea (diagonals bisect each other) followed by one distance.",
  tita_answer=10, check=_c014, cognitive="Application",
  tita_traps=[(5, r"Finds the centre $(7, 4)$ as the midpoint of $PR$ and reports its distance from $Q$, which is only half the diagonal."),
              (14, r"Adds the differences $8 + 6$ instead of using the distance formula.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 015
def _c015():
    sol = solve(Eq(2 * (k - 1) + k * 3, 0), k)  # a1 a2 + b1 b2 = 0
    return sol[0]
q("C19-A-015", T, "Parameter that makes two lines perpendicular", "Easy",
  "Inverse/parameter",
  r"For what value of $k$ are the lines $2x + ky = 5$ and $(k - 1)x + 3y = 2$ perpendicular to each other?",
  "MCQ",
  r"Lines $a_1 x + b_1 y = c_1$ and $a_2 x + b_2 y = c_2$ are perpendicular when $a_1 a_2 + b_1 b_2 = 0$. Here $2(k - 1) + 3k = 0$, so $5k = 2$ and $k = \frac{2}{5}$.",
  "Using the parallel condition, or slipping when solving the linear equation.",
  "C19A-perp-parallel-parameter", "One condition on coefficients, one linear equation.",
  correct=r"$\frac{2}{5}$",
  distractors=[(r"$3$", r"Uses the parallel condition $2 \cdot 3 = k(k - 1)$, whose positive root is $3$."),
               (r"$-2$", r"Uses the parallel condition $k^2 - k - 6 = 0$ and takes the root $-2$."),
               (r"$\frac{5}{2}$", r"Solves $5k = 2$ as $k = \frac{5}{2}$.")],
  check=_c015, values=[R_(2, 5), 3, -2, R_(5, 2)], cognitive="Application")

# ================================================================= MEDIUM
# ---------------------------------------------------------------- 016
def _c016():
    bb = symbols('bb', nonzero=True)
    sol = [s for s in solve(Eq(R_(4) / (2 * bb) + R_(3) / bb, 1), bb) if s > 0]
    b0 = sol[0]
    return Abs(2 * b0 * b0) / 2
q("C19-A-016", T, "Line through a point with intercepts in a given ratio", "Medium",
  "Multi-step word problem",
  r"A straight line passes through the point $(4, 3)$, and its $x$-intercept is twice its $y$-intercept, both intercepts being positive. What is the area, in square units, of the triangle that the line forms with the coordinate axes?",
  "TITA",
  r"Let the $y$-intercept be $b$, so the line is $\frac{x}{2b} + \frac{y}{b} = 1$. Substituting $(4, 3)$: $\frac{2}{b} + \frac{3}{b} = 1$, so $b = 5$ and the $x$-intercept is $10$. The area is $\frac{1}{2} \times 10 \times 5 = 25$ square units.",
  "Swapping which intercept is twice the other, or forgetting the factor one-half.",
  "C19A-line-intercept-form", "Intercept form with a ratio condition, then a triangle area.",
  tita_answer=25, check=_c016, cognitive="Application",
  tita_traps=[(50, "Forgets the factor one-half in the triangle area."),
              (15, r"Adds the intercepts $10 + 5$ instead of finding the area.")])

# ---------------------------------------------------------------- 017
def _c017():
    P, Q = (-4, 7), (6, -3)
    X = (P[0] + t * (Q[0] - P[0]), P[1] + t * (Q[1] - P[1]))
    tt = solve(Eq(2 * X[0] + X[1], 5), t)[0]
    return tt / (1 - tt)
q("C19-A-017", T, "Ratio in which a line divides a segment", "Medium",
  "Inverse/parameter",
  r"The segment joining $P(-4, 7)$ and $Q(6, -3)$ is cut by the line $2x + y = 5$ at the point $R$. What is the ratio $PR : RQ$?",
  "MCQ",
  r"Let $L(x, y) = 2x + y - 5$. Then $L(P) = -8 + 7 - 5 = -6$ and $L(Q) = 12 - 3 - 5 = 4$. The line divides $PQ$ in the ratio $PR : RQ = |L(P)| : |L(Q)| = 6 : 4 = 3 : 2$. (Check: $R = P + \frac{3}{5}(10, -10) = (2, 1)$, and $2(2) + 1 = 5$.)",
  "Reversing the ratio, or ignoring the constant term of the line.",
  "C19A-section-ratio-by-line", "Needs the ratio from values of the line expression at the end points; reversal trap.",
  correct=r"$3 : 2$",
  distractors=[(r"$2 : 3$", r"Reverses the ratio, giving $RQ : PR$."),
               (r"$1 : 9$", r"Ignores the constant and uses $2x + y$: $|{-1}| : |9|$."),
               (r"$3 : 5$", r"Reports $PR : PQ$ instead of $PR : RQ$.")],
  check=_c017, values=[R_(3, 2), R_(2, 3), R_(1, 9), R_(3, 5)], cognitive="Application")

# ---------------------------------------------------------------- 018
def _c018():
    expr = k * (5 - 1) + 3 * (1 - 2) + 7 * (2 - 5)
    sols = solve(Eq(expr, 32), k) + solve(Eq(expr, -32), k)
    return max(sols) - min(sols)
q("C19-A-018", T, "Two possible positions of a vertex from a given triangle area", "Medium",
  "Inverse/parameter",
  r"The vertices of a triangle are $P(k, 2)$, $Q(3, 5)$ and $R(7, 1)$, and its area is $16$ square units. There are two possible values of $k$. What is the positive difference between them?",
  "MCQ",
  r"Area $= \frac{1}{2}\left|k(5 - 1) + 3(1 - 2) + 7(2 - 5)\right| = \frac{1}{2}|4k - 24| = 2|k - 6|$. Setting $2|k - 6| = 16$ gives $k - 6 = \pm 8$, so $k = 14$ or $k = -2$. The difference is $16$.",
  "Dropping the factor one-half, or losing the factor 2 in 2|k - 6|.",
  "C19A-triangle-area-vertices", "Area formula in terms of a parameter with an absolute value giving two cases.",
  correct=r"$16$",
  distractors=[(r"$8$", r"Drops the $\frac{1}{2}$: $|4k - 24| = 16$ gives $k = 10$ or $k = 2$."),
               (r"$32$", r"Simplifies the area to $|k - 6|$, losing the factor $2$: $k = 22$ or $k = -10$."),
               (r"$14$", r"Reports the larger value of $k$ instead of the difference.")],
  check=_c018, values=[16, 8, 32, 14], cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    sol = solve(Eq(Abs(3 * x - 12), 4 * 5), x)
    return FiniteSet(*sol)
q("C19-A-019", T, "Points on an axis at a given distance from a line", "Medium",
  "Inverse/parameter",
  r"A straight boundary wall runs along the line $3x + 4y = 12$, with distances in metres. Two lamps are to be placed on a road along the $x$-axis so that each lamp is exactly $4$ m from the wall. What are the $x$-coordinates of the two lamps?",
  "MCQ",
  r"For $(x, 0)$, the distance to $3x + 4y - 12 = 0$ is $\frac{|3x - 12|}{5} = 4$, so $3x - 12 = \pm 20$. This gives $x = \frac{32}{3}$ or $x = -\frac{8}{3}$.",
  "Forgetting to divide by the square root of the sum of squares of the coefficients.",
  "C19A-point-line-distance", "Distance formula set equal to a value, two cases from the absolute value.",
  correct=r"$\frac{32}{3}$ and $-\frac{8}{3}$",
  distractors=[(r"$\frac{16}{3}$ and $\frac{8}{3}$", r"Forgets the denominator $5$: $|3x - 12| = 4$."),
               (r"$8$ and $-2$", r"Uses the $y$-coefficient in place of the $x$-coefficient: $|4x - 12| = 20$."),
               (r"$\frac{8}{3}$ and $-\frac{32}{3}$", r"Sign slip on the constant: $|3x + 12| = 20$.")],
  check=_c019, values=[FiniteSet(R_(32, 3), R_(-8, 3)), FiniteSet(R_(16, 3), R_(8, 3)), FiniteSet(8, -2), FiniteSet(R_(8, 3), R_(-32, 3))],
  cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    # bring 6x - 8y - 32 = 0 to 3x - 4y - 16 = 0
    a1, b1, c1 = 3, -4, 9
    a2, b2, c2 = R_(6, 2), R_(-8, 2), R_(-32, 2)
    assert (a1, b1) == (a2, b2)
    return Abs(c1 - c2) / sqrt(a1**2 + b1**2) * 100
q("C19-A-020", T, "Distance between two parallel lines", "Medium",
  "Multi-step word problem",
  r"Two straight, parallel railway tracks run along the lines $3x - 4y + 9 = 0$ and $6x - 8y - 32 = 0$ on a map in which $1$ unit represents $100$ m. What is the actual distance between the two tracks?",
  "MCQ",
  r"Divide the second equation by $2$: $3x - 4y - 16 = 0$. Now both lines have the same coefficients, so the distance is $\frac{|9 - (-16)|}{\sqrt{9 + 16}} = \frac{25}{5} = 5$ units, that is $500$ m.",
  "Applying the parallel-line formula before making the x and y coefficients identical.",
  "C19A-parallel-lines-distance", "Normalising one equation, then the formula and a scale.",
  correct=r"$500$ m",
  distractors=[(r"$410$ m", r"Subtracts the constants $9$ and $-32$ directly and divides by $\sqrt{6^2 + 8^2} = 10$."),
               (r"$140$ m", r"Sign slip when halving: writes $3x - 4y + 16 = 0$, giving $\frac{|9 - 16|}{5}$."),
               (r"$250$ m", r"Halves the constant correctly but divides by $10$ from the unhalved equation: $\frac{25}{10}$.")],
  check=_c020, values=[500, 410, 140, 250], cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    P, Q = (2, 7), (26, 25)
    Pp = (P[0], -P[1])
    best = _dist(Pp, Q)
    # numeric sanity: no point on the x-axis gives a shorter path
    fnum = lambda s: math.hypot(s - 2, 7) + math.hypot(26 - s, 25)
    assert min(fnum(i / 10) for i in range(-100, 400)) >= float(best) - 1e-9
    return best
f = Fig()
_axes(f, -2, 30, -2, 27)
f.pt("P(2, 7)", 2, 7, offset=(2.6, 0)); f.pt("Q(26, 25)", 26, 25, offset=(-3.0, 0))
f.text((15, -1.6), "stream")
_alt = "The x-axis represents a straight stream. Point P(2, 7) and point Q(26, 25) lie above it, on the same side."
q("C19-A-021", T, "Shortest path touching a line, by reflection", "Medium",
  "Conceptual/application",
  r"Meera's tent is at $P(2, 7)$ and her friend's tent is at $Q(26, 25)$, with coordinates in metres. A straight stream runs along the $x$-axis, and both tents are on the same side of it. Meera walks in a straight line from her tent to a point on the stream, fills a bucket there, and then walks in a straight line to her friend's tent. What is the least total distance she can walk?",
  "MCQ",
  r"Reflect $P$ in the $x$-axis to $P'(2, -7)$. For any point $X$ on the stream, $PX = P'X$, so $PX + XQ = P'X + XQ \ge P'Q$, with equality when $X$ lies on segment $P'Q$. $P'Q = \sqrt{24^2 + 32^2} = 40$ m.",
  "Using the direct distance PQ, which does not touch the stream.",
  "C19A-reflection-shortest-path", "Needs the reflection trick; direct distance is a tempting trap.",
  correct=r"$40$ m",
  distractors=[(r"$30$ m", r"Gives the direct distance $PQ = \sqrt{24^2 + 18^2}$, which never touches the stream."),
               (r"$50$ m", r"Walks to the point of the stream directly below $Q$: $\sqrt{24^2 + 7^2} + 25 = 25 + 25$."),
               (r"$56$ m", r"Adds the legs $24 + 32$ of the right triangle instead of finding its hypotenuse.")],
  check=_c021, values=[40, 30, 50, 56], cognitive="Analysis",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 022
def _c022():
    P = (4, 1)
    # solve: midpoint on the line and segment perpendicular to the line
    u, v = symbols('u v')
    s = solve([2 * (P[0] + u) / 2 - (P[1] + v) / 2 + 3, (v - P[1]) * 2 + (u - P[0]) * 1], [u, v])
    return (s[u], s[v])
q("C19-A-022", T, "Image of a point in a slanted line", "Medium",
  "Multi-step word problem",
  r"A long straight mirror stands along the line $2x - y + 3 = 0$. A lamp is placed at $P(4, 1)$. At what point is the image of the lamp formed?",
  "MCQ",
  r"The image $P'$ satisfies $P' = P - \frac{2(2 \cdot 4 - 1 + 3)}{2^2 + 1^2}(2, -1) = (4, 1) - 4(2, -1) = (-4, 5)$. Check: the midpoint $(0, 3)$ lies on the line, and $PP'$ has slope $-\frac{1}{2}$, perpendicular to the mirror's slope $2$.",
  "Stopping at the foot of the perpendicular, or moving in the wrong direction from P.",
  "C19A-reflection-point-line", "Reflection in a slanted line; needs foot or formula plus a direction check.",
  correct=r"$(-4, 5)$",
  distractors=[(r"$(0, 3)$", r"Gives the foot of the perpendicular from $P$ instead of the image."),
               (r"$(12, -3)$", r"Moves $4(2, -1)$ away from the mirror instead of across it."),
               (r"$(-4, -3)$", r"Sign slip in the $y$-coordinate: $1 - 4$ instead of $1 + 4$.")],
  check=_c022, values=[(-4, 5), (0, 3), (12, -3), (-4, -3)], cognitive="Application")

# ---------------------------------------------------------------- 023
def _c023():
    cnt = 0
    for X in range(0, 13):
        for Y in range(0, 10):
            if X > 0 and Y > 0 and 9 * X + 12 * Y < 108:
                cnt += 1
    return cnt
f = Fig()
_axes(f, -1, 14, -1, 10.5, origin=False)
P = f.pt("(0, 0)", 0, 0, offset=(-1.2, -0.8)); Q = f.pt("(12, 0)", 12, 0, offset=(0.4, -1.2)); R = f.pt("(0, 9)", 0, 9, offset=(-1.8, 0.2))
f.shade([P, Q, R]); f.poly(P, Q, R)
_alt = "Right triangle lawn with corners at (0, 0), (12, 0) and (0, 9), with its legs along the coordinate axes."
q("C19-A-023", T, "Lattice points strictly inside a right triangle", "Medium",
  "Casework/optimisation",
  r"A triangular lawn has corners at $(0, 0)$, $(12, 0)$ and $(0, 9)$, with coordinates in metres. A sprinkler is to be placed at every point strictly inside the lawn (not on its boundary) both of whose coordinates are integers. How many sprinklers are needed?",
  "TITA",
  r"By Pick's theorem, area $= I + \frac{B}{2} - 1$. The area is $54$. Boundary lattice points: $12 + 9 + \gcd(12, 9) = 24$. So $I = 54 - 12 + 1 = 43$. (Directly: the hypotenuse is $3x + 4y = 36$; counting $y$ for $x = 1, \dots, 11$ gives $8 + 7 + 6 + 5 + 5 + 4 + 3 + 2 + 2 + 1 + 0 = 43$.)",
  "Including boundary points, or forgetting the lattice points on the slanted side.",
  "C19A-lattice-inside-region", "Pick's theorem or row-by-row counting with a slanted boundary.",
  tita_answer=43, check=_c023, cognitive="Analysis",
  tita_traps=[(67, r"Includes the $24$ boundary points."),
              (54, "Reports the area as the number of points.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 024
def _c024():
    V = [(0, 0), (8, 0), (15, 5), (0, 8)]          # P, Q, R, S in order
    # exact intersection of the diagonals PR and QS
    s = solve([y * 15 - x * 5, (y - 0) * (0 - 8) - (x - 8) * (8 - 0)], [x, y])
    X = (s[x], s[y])
    tot = lambda u, v: sum(math.hypot(u - a, v - b) for a, b in V)
    best = tot(float(X[0]), float(X[1]))
    # brute-force search: no grid point does better
    assert min(tot(i / 20, j / 20) for i in range(0, 301) for j in range(0, 161)) >= best - 1e-9
    return X
f = Fig()
_axes(f, -1, 16.5, -1, 9, origin=False)
f.pt("P(0, 0)", 0, 0, offset=(-1.4, -0.9)); f.pt("Q(8, 0)", 8, 0, offset=(0, -1.0))
f.pt("R(15, 5)", 15, 5, offset=(0, 1.0)); f.pt("S(0, 8)", 0, 8, offset=(1.8, 0.4))
_alt = "Four villages P(0, 0), Q(8, 0), R(15, 5) and S(0, 8) shown as points on coordinate axes."
q("C19-A-024", T, "Point minimising the sum of distances to four points (intersection of the diagonals)", "Difficult",
  "Conceptual/application",
  r"Four villages are at $P(0, 0)$, $Q(8, 0)$, $R(15, 5)$ and $S(0, 8)$, with coordinates in km. A clinic is to be built at the point for which the sum of its straight-line distances from the four villages is as small as possible. Where should the clinic be built?",
  "MCQ",
  r"$PQRS$ is a convex quadrilateral. For any point $X$, $XP + XR \ge PR$ and $XQ + XS \ge QS$, with equality only when $X$ lies on both diagonals. So the best point is where $PR$ (the line $x = 3y$) meets $QS$ (the line $x + y = 8$): $4y = 8$, so $y = 2$, $x = 6$. The clinic should be at $(6, 2)$.",
  "Taking the average of the four points, which minimises the sum of squared distances, not the sum of distances.",
  "C19A-min-sum-distances-four-points", "Needs the triangle inequality on both diagonals, then an intersection of lines; the centroid is a strong trap.",
  correct=r"$(6, 2)$",
  distractors=[(r"$\left(\frac{23}{4}, \frac{13}{4}\right)$", r"Takes the average of the four villages, $\left(\frac{0 + 8 + 15 + 0}{4}, \frac{0 + 0 + 5 + 8}{4}\right)$."),
               (r"$\left(\frac{15}{2}, \frac{5}{2}\right)$", r"Takes the midpoint of the diagonal $PR$ instead of the point where the diagonals cross."),
               (r"$(4, 4)$", r"Takes the midpoint of the diagonal $QS$ instead of the point where the diagonals cross.")],
  check=_c024, values=[(6, 2), (R_(23, 4), R_(13, 4)), (R_(15, 2), R_(5, 2)), (4, 4)], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 025
def _c025():
    P, Q, G = (2, 9), (-4, 3), (3, 4)
    rx, ry = symbols('rx ry')
    s = solve([Eq((P[0] + Q[0] + rx) / 3, G[0]), Eq((P[1] + Q[1] + ry) / 3, G[1])], [rx, ry])
    return _area(P, Q, (s[rx], s[ry]))
f = Fig()
f.pt("P(2, 9)", 2, 9, offset=(0, 1.0)); f.pt("Q(-4, 3)", -4, 3, offset=(-1.6, -0.6)); f.pt("G(3, 4)", 3, 4, offset=(1.6, 0.4))
f.seg((2, 9), (-4, 3))
_alt = "Two survey stones P(2, 9) and Q(-4, 3) joined by a segment, and the centroid G(3, 4) of the triangle; the third stone R is not shown."
q("C19-A-025", T, "Missing vertex from the centroid, then the area of the triangle", "Medium",
  "Multi-step word problem",
  r"Three survey stones $P$, $Q$ and $R$ mark the corners of a triangular plot. Stones $P(2, 9)$ and $Q(-4, 3)$ are still in place, but $R$ has been lost. The records show that the centroid of triangle $PQR$ is $G(3, 4)$, with all coordinates in metres. What is the area of the plot, in m$^2$?",
  "TITA",
  r"The centroid is the average of the vertices, so $R = 3G - P - Q = (9 - 2 + 4, 12 - 9 - 3) = (11, 0)$. Then the area is $\frac{1}{2}\left|2(3 - 0) + (-4)(0 - 9) + 11(9 - 3)\right| = \frac{1}{2}(6 + 36 + 66) = 54$ m$^2$.",
  "Forgetting the factor one-half, or finding the area of triangle PQG instead of PQR.",
  "C19A-centroid", "Inverting the centroid formula, then a shoelace area; two stages.",
  tita_answer=54, check=_c025, cognitive="Application",
  tita_traps=[(108, "Forgets the factor one-half in the area formula."),
              (18, r"Finds the area of triangle $PQG$ with the centroid as the third corner, which is one-third of the plot.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 026
def _c026():
    expr = x**2 + y**2 - 4*x - 6*y - 12
    g, h = -R_(expr.coeff(x, 1), 2), -R_(expr.coeff(y, 1), 2)
    r = sqrt(g**2 + h**2 - expr.subs({x: 0, y: 0}))
    return FiniteSet(*solve(Eq(Abs(3 * g + 4 * h - c), 5 * r), c))
q("C19-A-026", T, "Tangent line condition for a circle in general form", "Medium",
  "Inverse/parameter",
  r"For which values of $c$ is the line $3x + 4y = c$ a tangent to the circle $x^2 + y^2 - 4x - 6y - 12 = 0$?",
  "MCQ",
  r"The circle is $(x - 2)^2 + (y - 3)^2 = 25$: centre $(2, 3)$, radius $5$. Tangency needs $\frac{|3(2) + 4(3) - c|}{5} = 5$, so $|18 - c| = 25$ and $c = -7$ or $c = 43$.",
  "Forgetting the denominator 5, or taking the centre as (-2, -3).",
  "C19A-circle-tangent-line", "Completing squares and the tangency condition with two cases.",
  correct=r"$-7$ or $43$",
  distractors=[(r"$13$ or $23$", r"Forgets to multiply by the denominator: $|18 - c| = 5$."),
               (r"$7$ or $-43$", r"Takes the centre as $(-2, -3)$: $|{-18} - c| = 25$."),
               (r"$-17$ or $53$", r"Divides by $3 + 4 = 7$ instead of $\sqrt{3^2 + 4^2} = 5$: $|18 - c| = 35$.")],
  check=_c026, values=[FiniteSet(-7, 43), FiniteSet(13, 23), FiniteSet(7, -43), FiniteSet(-17, 53)],
  cognitive="Application")

# ---------------------------------------------------------------- 027
def _c027():
    pts = solve([x**2 + y**2 - 169, 5*x + 12*y - 65], [x, y])
    km = _dist(pts[0], pts[1])
    return km / 720 * 3600          # time in seconds at 720 km/h
f = Fig()
f.circle((0, 0), 13)
O = f.pt("O", 0, 0, offset=(-0.8, -0.8))
# line 5x + 12y = 65 from x = -16 to x = 20
f.seg((-16, (65 + 80) / 12), (20, (65 - 100) / 12))
f.text((-13.5, 13.2), "5x + 12y = 65")
_alt = "Radar range circle x^2 + y^2 = 169 with the radar station O at the origin, crossed by the straight flight path 5x + 12y = 65."
q("C19-A-027", T, "Time an aircraft on a straight path spends inside a radar circle (chord length)", "Medium",
  "Multi-step word problem",
  r"A radar station at the origin detects every aircraft inside the circle $x^2 + y^2 = 169$, with distances in km. An aircraft flies at a constant speed of $720$ km/h along the straight line $5x + 12y = 65$. For how many seconds is the aircraft inside the radar's range?",
  "TITA",
  r"The distance of the station $(0, 0)$ from the flight path is $\frac{65}{\sqrt{25 + 144}} = \frac{65}{13} = 5$ km. The half-chord is $\sqrt{13^2 - 5^2} = 12$ km, so the aircraft covers a chord of $24$ km inside the range. At $720$ km/h, that is $200$ m/s, this takes $\frac{24{,}000}{200} = 120$ seconds.",
  "Using the half-chord, or the diameter of the range, as the distance flown inside it.",
  "C19A-circle-chord-length", "Distance from the centre, a right triangle for the chord, then a speed conversion.",
  tita_answer=120, check=_c027, cognitive="Application",
  tita_traps=[(60, r"Uses the half-chord $12$ km as the distance flown inside the range."),
              (130, r"Uses the diameter $26$ km of the range as the distance flown.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 028
def _c028():
    D, E, F = symbols('D E F')
    s = solve([F, 64 + 8 * D + F, 36 + 6 * E + F], [D, E, F])
    return (s[D], s[E], s[F])
q("C19-A-028", T, "Circle through three points forming a right angle", "Medium",
  "Conceptual/application",
  r"Three lamp posts stand at $O(0, 0)$, $P(8, 0)$ and $Q(0, 6)$. A circular walkway is to pass through all three posts. Its equation is",
  "MCQ",
  r"Angle $POQ$ is a right angle, so $PQ$ is a diameter. The centre is the midpoint $(4, 3)$ and the radius is $\frac{PQ}{2} = 5$. So $(x - 4)^2 + (y - 3)^2 = 25$, which expands to $x^2 + y^2 - 8x - 6y = 0$.",
  "Mishandling the general form x^2 + y^2 + 2gx + 2fy + c = 0 when expanding.",
  "C19A-circle-through-points", "Right angle at O makes PQ a diameter; then expansion.",
  correct=r"$x^2 + y^2 - 8x - 6y = 0$",
  distractors=[(r"$x^2 + y^2 + 8x + 6y = 0$", r"Takes the centre as $(-4, -3)$ by a sign slip in $(x - h)^2$."),
               (r"$x^2 + y^2 - 4x - 3y = 0$", r"Uses $-h$ and $-k$ as the coefficients of $x$ and $y$ instead of $-2h$ and $-2k$."),
               (r"$x^2 + y^2 - 8x - 6y - 25 = 0$", r"Moves $r^2 = 25$ across without cancelling the $16 + 9$ from the expansion.")],
  check=_c028, values=[(-8, -6, 0), (8, 6, 0), (-4, -3, 0), (-8, -6, -25)], cognitive="Understanding")

# ---------------------------------------------------------------- 029
def _c029():
    M = solve([x + 2*y - 7, 3*x - y - 7], [x, y])
    m = -R_(4, 3)
    return _line_sl(y - M[y] - m * (x - M[x]))
q("C19-A-029", T, "Line through the intersection of two lines, parallel to a third", "Medium",
  "Multi-step word problem",
  r"Two straight roads along $x + 2y = 7$ and $3x - y = 7$ cross at a junction. A new straight road is to pass through the junction, parallel to a railway line along $4x + 3y = 5$. The equation of the new road is",
  "MCQ",
  r"From $3x - y = 7$, $y = 3x - 7$; then $x + 6x - 14 = 7$ gives $x = 3$, $y = 2$. A line parallel to $4x + 3y = 5$ is $4x + 3y = c$; through $(3, 2)$, $c = 12 + 6 = 18$. So the road is $4x + 3y = 18$.",
  "Writing the perpendicular instead of the parallel line, or swapping the coefficients.",
  "C19A-line-perpendicular-through-point", "Solve a pair of lines, then a parallel line through the point.",
  correct=r"$4x + 3y = 18$",
  distractors=[(r"$3x - 4y = 1$", r"Writes the line through $(3, 2)$ perpendicular to the railway."),
               (r"$3x + 4y = 17$", r"Swaps the coefficients of $x$ and $y$ and then fits $(3, 2)$."),
               (r"$4x - 3y = 6$", r"Sign slip in the $y$-coefficient, then fits $(3, 2)$.")],
  check=_c029, values=[(R_(-4, 3), 6), (R_(3, 4), R_(-1, 4)), (R_(-3, 4), R_(17, 4)), (R_(4, 3), -2)],
  cognitive="Application")

# ---------------------------------------------------------------- 030
def _c030():
    P, Q = (1, 2), (5, 4)
    Qp = (Q[0], -Q[1])
    line = (y - P[1]) * (Qp[0] - P[0]) - (x - P[0]) * (Qp[1] - P[1])
    return solve(line.subs(y, 0), x)[0]
f = Fig()
_axes(f, -1, 7, -1, 5.5)
f.pt("P(1, 2)", 1, 2, offset=(2.6, 0)); f.pt("Q(5, 4)", 5, 4, offset=(2.6, 0))
f.text((6.2, 0.45), "mirror")
_alt = "A mirror along the x-axis, with point P(1, 2) and point Q(5, 4) above it."
q("C19-A-030", T, "Point of incidence of a light ray reflected in an axis", "Medium",
  "Conceptual/application",
  r"A ray of light from the point $P(1, 2)$ strikes a mirror lying along the $x$-axis and, after reflection, passes through the point $Q(5, 4)$. At what point does the ray strike the mirror?",
  "MCQ",
  r"The reflected ray, extended backwards, passes through the image $Q'(5, -4)$ of $Q$. So the point is where $PQ'$ meets the $x$-axis. Along $PQ'$, $y$ falls from $2$ to $-4$, and $y = 0$ is reached one-third of the way, so $x = 1 + \frac{1}{3}(4) = \frac{7}{3}$. The point is $\left(\frac{7}{3}, 0\right)$.",
  "Joining P and Q directly, or splitting the horizontal gap in the reversed ratio of heights.",
  "C19A-reflection-shortest-path", "Reflection principle and the ratio of heights.",
  correct=r"$\left(\frac{7}{3}, 0\right)$",
  distractors=[(r"$(3, 0)$", r"Assumes the ray strikes midway between the two points, ignoring their different heights."),
               (r"$(-3, 0)$", r"Extends the line $PQ$ itself to meet the $x$-axis."),
               (r"$\left(\frac{11}{3}, 0\right)$", r"Splits the horizontal gap $4$ in the ratio $4 : 2$ instead of $2 : 4$.")],
  check=_c030, values=[R_(7, 3), 3, -3, R_(11, 3)], cognitive="Analysis",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 031
def _c031():
    return sum(1 for X in range(-9, 10) for Y in range(-9, 10) if X * X + Y * Y == 65)
q("C19-A-031", T, "Lattice points on a circle centred at the origin", "Medium",
  "Casework/optimisation",
  r"How many points with both coordinates integers lie on the circle $x^2 + y^2 = 65$?",
  "TITA",
  r"We need $65$ as a sum of two squares: $65 = 1 + 64 = 16 + 49$. The pair $\{1, 8\}$ gives $(\pm 1, \pm 8)$ and $(\pm 8, \pm 1)$: $8$ points. The pair $\{4, 7\}$ gives another $8$ points. Total $16$.",
  "Finding only one representation of 65 as a sum of squares, or ignoring signs and order.",
  "C19A-lattice-on-circle", "Two different representations, each with sign and order cases.",
  tita_answer=16, check=_c031, cognitive="Analysis",
  tita_traps=[(8, r"Uses only one representation, $1 + 64$."),
              (4, r"Counts only the first-quadrant points $(1, 8), (8, 1), (4, 7), (7, 4)$.")])

# ---------------------------------------------------------------- 032
def _c032():
    P, R = Matrix([1, 2]), Matrix([7, 4])
    M = (P + R) / 2
    h = (R - P) / 2
    rot = Matrix([-h[1], h[0]])
    Q1, S1 = M + rot, M - rot
    # verify square: equal sides and right angle
    assert (Q1 - P).dot(S1 - P) == 0 and (Q1 - P).norm() == (S1 - P).norm()
    return FiniteSet(Tuple(Q1[0], Q1[1]), Tuple(S1[0], S1[1]))
q("C19-A-032", T, "Remaining vertices of a square from two opposite vertices", "Medium",
  "Multi-step word problem",
  r"$P(1, 2)$ and $R(7, 4)$ are opposite vertices of a square $PQRS$. What are the coordinates of the other two vertices $Q$ and $S$ (in some order)?",
  "MCQ",
  r"The centre is the midpoint $(4, 3)$, and the half-diagonal from the centre to $R$ is $(3, 1)$. The other diagonal is perpendicular and of equal length, so the half-diagonal to $Q$ or $S$ is $(-1, 3)$ or $(1, -3)$. The vertices are $(4 - 1, 3 + 3) = (3, 6)$ and $(4 + 1, 3 - 3) = (5, 0)$.",
  "Rotating the half-diagonal incorrectly, or rotating about P instead of the centre.",
  "C19A-square-vertices", "Needs centre plus a 90 degree rotation of the half-diagonal.",
  correct=r"$(3, 6)$ and $(5, 0)$",
  distractors=[(r"$(5, 6)$ and $(3, 0)$", r"Swaps the components $(3, 1) \to (1, 3)$ without changing a sign, which is not a rotation."),
               (r"$(0, 5)$ and $(2, -1)$", r"Adds the rotated half-diagonal $(\mp 1, \pm 3)$ to $P$ instead of to the centre."),
               (r"$(1, 4)$ and $(7, 2)$", r"Negates one component of $(3, 1)$ without swapping, using $(\mp 3, \pm 1)$ from the centre.")],
  check=_c032,
  values=[FiniteSet(Tuple(3, 6), Tuple(5, 0)), FiniteSet(Tuple(5, 6), Tuple(3, 0)), FiniteSet(Tuple(0, 5), Tuple(2, -1)), FiniteSet(Tuple(1, 4), Tuple(7, 2))],
  cognitive="Application")

# ---------------------------------------------------------------- 033
def _c033():
    P, Q = (1, 2), (7, 8)
    s = solve([Eq((x - P[0])**2 + (y - P[1])**2, (x - Q[0])**2 + (y - Q[1])**2), Eq(y, 3 * x - 3)], [x, y])
    return _area(P, Q, (s[x], s[y]))
q("C19-A-033", T, "Point on a line equidistant from two points, then a triangle area", "Medium",
  "Multi-step word problem",
  r"Two villages are at $P(1, 2)$ and $Q(7, 8)$, with coordinates in km. A well $R$ is to be dug on a straight canal that runs along the line $y = 3x - 3$, so that $R$ is equally far from both villages. What is the area, in km$^2$, of triangle $PQR$?",
  "TITA",
  r"Points equidistant from $P$ and $Q$ lie on the perpendicular bisector of $PQ$: it passes through the midpoint $(4, 5)$ with slope $-1$, so it is $x + y = 9$. With $y = 3x - 3$: $4x - 3 = 9$, so $R = (3, 6)$. Area $= \frac{1}{2}\left|1(8 - 6) + 7(6 - 2) + 3(2 - 8)\right| = \frac{1}{2}|2 + 28 - 18| = 6$ km$^2$.",
  "Forgetting the half in the area formula, or taking the bisector with slope +1.",
  "C19A-equidistant-point", "Perpendicular bisector, intersection with a line, then an area.",
  tita_answer=6, check=_c033, cognitive="Application",
  tita_traps=[(12, "Forgets the factor one-half in the area."),
              (24, r"Sign slip in the last shoelace term, writing $3(8 - 2)$ for $3(2 - 8)$: $\frac{1}{2}|2 + 28 + 18| = 24$.")])

# ---------------------------------------------------------------- 034
def _c034():
    p1, p2, q1, q2, r1, r2 = symbols('p1 p2 q1 q2 r1 r2')
    s = solve([q1 + r1 - 10, q2 + r2 - 8, r1 + p1 - 2, r2 + p2 - 4, p1 + q1 - 6, p2 + q2 - 16],
              [p1, p2, q1, q2, r1, r2])
    return (s[p1], s[p2])
q("C19-A-034", T, "Vertex of a triangle from the midpoints of its sides", "Medium",
  "Multi-step word problem",
  r"The midpoints of the sides $QR$, $RP$ and $PQ$ of triangle $PQR$ are $(5, 4)$, $(1, 2)$ and $(3, 8)$ respectively. What are the coordinates of the vertex $P$?",
  "MCQ",
  r"The three midpoints form a triangle whose sides are parallel to and half of the sides of $PQR$, so $P = M_{RP} + M_{PQ} - M_{QR}$. Hence $P = (1 + 3 - 5, 2 + 8 - 4) = (-1, 6)$. (Check: $Q = (7, 10)$, $R = (3, -2)$, and the midpoint of $QR$ is $(5, 4)$.)",
  "Using the wrong combination of midpoints, which gives another vertex.",
  "C19A-centroid-midpoints", "Needs the midpoint triangle relation and careful matching of labels.",
  correct=r"$(-1, 6)$",
  distractors=[(r"$(7, 10)$", r"Uses $M_{PQ} + M_{QR} - M_{RP}$, which is the vertex $Q$."),
               (r"$(3, -2)$", r"Uses $M_{QR} + M_{RP} - M_{PQ}$, which is the vertex $R$."),
               (r"$(2, 5)$", r"Takes $P$ as the midpoint of the two midpoints on sides through $P$.")],
  check=_c034, values=[(-1, 6), (7, 10), (3, -2), (2, 5)], cognitive="Application")

# ---------------------------------------------------------------- 035
def _c035():
    m = symbols('m')
    m0 = 2                                   # slope of 2x - y = 3
    V = (1, 2)
    slopes = solve(Eq((m - m0)**2, (1 + m * m0)**2), m)   # tan 45 = 1: |m - m0| = |1 + m m0|
    # confirm each line really makes 45 degrees with the road
    for sl in slopes:
        ang = abs(math.degrees(math.atan(float(sl)) - math.atan(m0)))
        assert abs(min(ang, 180 - ang) - 45) < 1e-9
    return FiniteSet(*[Tuple(sl, V[1] - sl * V[0]) for sl in slopes])
f = Fig()
_axes(f, -3, 6, -3.5, 6, origin=False)
f.seg((0, -3), (4.5, 6))
f.text((5.3, 4.4), "2x - y = 3")
f.pt("V(1, 2)", 1, 2, offset=(0, 0.8))
_alt = "A straight road along the line 2x - y = 3 and a village V(1, 2) lying off the road."
q("C19-A-035", T, "Lines through a point making a given angle with a given line", "Medium",
  "Inverse/parameter",
  r"A straight highway runs along the line $2x - y = 3$. A new straight road is to pass through the village $V(1, 2)$ and make an angle of $45^\circ$ with the highway. The two possible roads lie along the lines",
  "MCQ",
  r"The highway has slope $2$. A road of slope $m$ makes $45^\circ$ with it when $\left|\frac{m - 2}{1 + 2m}\right| = 1$. So $m - 2 = 1 + 2m$, giving $m = -3$, or $m - 2 = -(1 + 2m)$, giving $m = \frac{1}{3}$. Through $(1, 2)$: $y - 2 = -3(x - 1)$, that is $3x + y = 5$, and $y - 2 = \frac{1}{3}(x - 1)$, that is $x - 3y = -5$.",
  "Using 1 - m1 m2 in the denominator of the angle formula, or misreading the slope of the given line.",
  "C19A-angle-between-lines", "Angle formula with an absolute value giving two slopes, then two lines through a point.",
  correct=r"$3x + y = 5$ and $x - 3y = -5$",
  distractors=[(r"$x - y = -1$ and $x + y = 3$", r"Writes the denominator as $1 - 2m$: $|m - 2| = |1 - 2m|$ gives $m = 1$ or $m = -1$."),
               (r"$3x - y = 1$ and $x + 3y = 7$", r"Reads the slope of $2x - y = 3$ as $-2$: $|m + 2| = |1 - 2m|$ gives $m = 3$ or $m = -\frac{1}{3}$."),
               (r"$3x - y = 1$ and $x - y = -1$", r"Drops the denominator and solves $|m - 2| = 1$, giving $m = 3$ or $m = 1$.")],
  check=_c035,
  values=[FiniteSet(Tuple(-3, 5), Tuple(R_(1, 3), R_(5, 3))), FiniteSet(Tuple(1, 1), Tuple(-1, 3)),
          FiniteSet(Tuple(3, -1), Tuple(R_(-1, 3), R_(7, 3))), FiniteSet(Tuple(3, -1), Tuple(1, 1))],
  cognitive="Application", figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 036
def _c036():
    xi = solve((3*x + 4*y - 24).subs(y, 0), x)[0]
    yi = solve((3*x + 4*y - 24).subs(x, 0), y)[0]
    return _area((xi, 0), (0, yi), (1, 1))
q("C19-A-036", T, "Triangle area using distance from a point to a line", "Medium",
  "Multi-step word problem",
  r"The line $3x + 4y = 24$ meets the $x$-axis at $M$ and the $y$-axis at $N$. What is the area of the triangle with vertices $M$, $N$ and $P(1, 1)$?",
  "MCQ",
  r"$M = (8, 0)$, $N = (0, 6)$, so $MN = 10$. The height is the distance of $P$ from the line: $\frac{|3 + 4 - 24|}{5} = \frac{17}{5}$. Area $= \frac{1}{2} \times 10 \times \frac{17}{5} = 17$.",
  "Forgetting the half, or using the triangle with the origin instead of P.",
  "C19A-point-line-distance", "Intercepts, a perpendicular distance and a triangle area.",
  correct=r"$17$",
  distractors=[(r"$34$", r"Forgets the half: $10 \times \frac{17}{5}$."),
               (r"$24$", r"Gives the area of triangle $OMN$ with the origin instead of $P$."),
               (r"$31$", r"Sign slip in the distance: $\frac{|3 + 4 + 24|}{5} = \frac{31}{5}$, then halves $10 \times \frac{31}{5}$.")],
  check=_c036, values=[17, 34, 24, 31], cognitive="Application")

# ---------------------------------------------------------------- 037
def _c037():
    P, Q, R, S = [Matrix(v) for v in [(1, 1), (5, 2), (6, 6), (2, 5)]]
    sides = [Q - P, R - Q, S - R, P - S]
    para = (sides[0] + sides[2]).norm() == 0 and (sides[1] + sides[3]).norm() == 0
    equal_sides = len(set(s.dot(s) for s in sides)) == 1
    right = sides[0].dot(sides[1]) == 0
    if para and equal_sides and not right:
        return 1   # rhombus, not square
    if para and equal_sides and right:
        return 2   # square
    if para and right:
        return 3   # rectangle
    return 4
q("C19-A-037", T, "Classifying a quadrilateral from its vertices using slopes and lengths", "Medium",
  "Conceptual/application",
  r"The vertices of a quadrilateral, taken in order, are $P(1, 1)$, $Q(5, 2)$, $R(6, 6)$ and $S(2, 5)$. The quadrilateral $PQRS$ is",
  "MCQ",
  r"$PQ$ and $RS$ both have slope $\frac{1}{4}$; $QR$ and $SP$ both have slope $4$, so $PQRS$ is a parallelogram. Every side has length $\sqrt{17}$, so it is a rhombus. Adjacent slopes $\frac{1}{4}$ and $4$ have product $1$, not $-1$, so the angles are not right angles. It is a rhombus that is not a square.",
  "Concluding square from equal sides (or from perpendicular diagonals) without checking an angle.",
  "C19A-quadrilateral-classification", "Needs slopes and lengths together and a check of the angle.",
  correct=r"a rhombus that is not a square",
  distractors=[(r"a square", r"Sees four equal sides and perpendicular diagonals and assumes a square."),
               (r"a rectangle that is not a square", r"Checks only the slopes, wrongly treats the reciprocal slopes $\frac{1}{4}$ and $4$ as perpendicular, and never compares side lengths."),
               (r"a parallelogram that is neither a rectangle nor a rhombus", r"Checks only the slopes and does not compare side lengths.")],
  check=_c037, values=[1, 2, 3, 4], cognitive="Analysis")

# ================================================================= DIFFICULT
# ---------------------------------------------------------------- 038
def _c038():
    aa = symbols('aa', positive=True)
    bb = 4 * aa / (aa - 3)       # from 3/a + 4/b = 1, a > 3
    area = aa * bb / 2
    crit = [s for s in solve(diff(area, aa), aa) if s > 3]
    return simplify(area.subs(aa, crit[0]))
q("C19-A-038", T, "Least area of the triangle cut off by a line through a fixed point", "Medium",
  "Casework/optimisation",
  r"A straight line passes through the point $(3, 4)$ and meets the positive $x$-axis and the positive $y$-axis. What is the least possible area, in square units, of the triangle that the line forms with the coordinate axes?",
  "TITA",
  r"Let the intercepts be $p$ and $q$, so $\frac{3}{p} + \frac{4}{q} = 1$. By AM-GM, $1 = \frac{3}{p} + \frac{4}{q} \ge 2\sqrt{\frac{12}{pq}}$, so $pq \ge 48$, with equality when $\frac{3}{p} = \frac{4}{q} = \frac{1}{2}$, that is $p = 6$, $q = 8$. The least area is $\frac{48}{2} = 24$ square units.",
  "Stopping at the minimum of pq without halving, or using the rectangle 3 by 4.",
  "C19A-line-intercept-form", "Optimisation over a family of lines through one AM-GM step; a standard Medium item on the CAT scale.",
  tita_answer=24, check=_c038, cognitive="Analysis", exams=CX,
  tita_traps=[(48, r"Reports the minimum of $pq$ without halving."),
              (12, r"Takes the area of the rectangle with corner $(3, 4)$.")])

# ---------------------------------------------------------------- 039
def _c039():
    V = [(-4, 2), (8, -1), (11, 9), (1, 12)]
    def side(a, b, p):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
    cnt = 0
    for X in range(-5, 13):
        for Y in range(-2, 14):
            s = [side(V[i], V[(i + 1) % 4], (X, Y)) for i in range(4)]
            if all(v > 0 for v in s) or all(v < 0 for v in s):
                cnt += 1
    return cnt
f = Fig()
K = f.pt("K(-4, 2)", -4, 2, offset=(-0.6, -1.0)); L = f.pt("L(8, -1)", 8, -1, offset=(0.6, -1.0))
M = f.pt("M(11, 9)", 11, 9, offset=(1.6, 0.4)); N = f.pt("N(1, 12)", 1, 12, offset=(-0.6, 1.0))
f.shade([K, L, M, N]); f.poly(K, L, M, N)
_alt = "Quadrilateral orchard KLMN with corners K(-4, 2), L(8, -1), M(11, 9) and N(1, 12), shaded."
q("C19-A-039", T, "Lattice points strictly inside a slanted quadrilateral (shoelace and Pick's theorem)", "Difficult",
  "Casework/optimisation",
  r"An orchard is the quadrilateral $KLMN$ whose corners, taken in order, are $K(-4, 2)$, $L(8, -1)$, $M(11, 9)$ and $N(1, 12)$, with coordinates in metres. A tree is planted at every point strictly inside the orchard (not on its boundary) both of whose coordinates are integers. How many trees are planted?",
  "TITA",
  r"Shoelace: $(-4)(-1) - 8 \cdot 2 = -12$, $8 \cdot 9 - 11(-1) = 83$, $11 \cdot 12 - 1 \cdot 9 = 123$, $1 \cdot 2 - (-4)(12) = 50$; the sum is $244$, so the area is $122$. Boundary lattice points: the sides have differences $(12, 3)$, $(3, 10)$, $(10, 3)$, $(5, 10)$ with gcds $3, 1, 1, 5$, so $B = 10$. Pick's theorem, area $= I + \frac{B}{2} - 1$, gives $I = 122 - 5 + 1 = 118$.",
  "Counting the boundary points as well, or using the area as the number of points.",
  "C19A-lattice-inside-region", "Shoelace on four slanted sides, four gcds and Pick's theorem; no side lies along a grid line.",
  tita_answer=118, check=_c039, cognitive="Analysis", exams=CX,
  tita_traps=[(128, r"Counts all $I + B$ points, including the $10$ on the boundary."),
              (122, "Reports the area as the number of points."),
              (113, r"Uses $I = \text{area} - B + 1$, forgetting to halve $B$.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 040
def _c040():
    # area of {x >= 0, y >= 0, |x - 1| + |y + 2| <= 5}: for y >= 0, y <= 3 - |x - 1|
    return integrate(Max(0, 3 - Abs(x - 1)), (x, 0, 10))
f = Fig()
_axes(f, -5, 7.5, -7.5, 4.5, origin=False)
f.poly((6, -2), (1, 3), (-4, -2), (1, -7))
f.pt("(1, -2)", 1, -2, offset=(0.9, -0.6))
_alt = "The square |x - 1| + |y + 2| = 5 with centre (1, -2) and vertices (6, -2), (1, 3), (-4, -2) and (1, -7), drawn with the coordinate axes."
q("C19-A-040", T, "Part of a shifted |x| + |y| region lying in the first quadrant", "Difficult",
  "Casework/optimisation",
  r"What is the area of the part of the region $|x - 1| + |y + 2| \le 5$ that lies in the first quadrant, that is, where $x \ge 0$ and $y \ge 0$?",
  "MCQ",
  r"The region is a square with centre $(1, -2)$ and vertices $(6, -2)$, $(1, 3)$, $(-4, -2)$, $(1, -7)$. For $y \ge 0$ the condition becomes $y \le 3 - |x - 1|$, so the part above the $x$-axis is the triangle with vertices $(-2, 0)$, $(4, 0)$, $(1, 3)$. Restricting to $x \ge 0$ leaves the quadrilateral $(0, 0)$, $(4, 0)$, $(1, 3)$, $(0, 2)$. By shoelace, its area is $\frac{1}{2}(12 + 2) = 7$.",
  "Taking the whole part above the x-axis, or missing the strip between x = 0 and the apex.",
  "C19A-mod-region-area", "Shifted region clipped by two half-planes; corner points must be found carefully.",
  correct=r"$7$",
  distractors=[(r"$9$", r"Takes the whole triangle above the $x$-axis, $\frac{1}{2} \times 6 \times 3$, ignoring $x \ge 0$."),
               (r"$14$", r"Forgets the half in the shoelace formula."),
               (r"$6$", r"Uses the triangle $(0, 0)$, $(4, 0)$, $(1, 3)$ and misses the part between the $y$-axis and the apex.")],
  check=_c040, values=[7, 9, 14, 6], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 041
def _c041():
    P, Q = (6, 4), (3, 8)
    Pp, Qp = (P[0], -P[1]), (-Q[0], Q[1])  # P in x-axis, Q in y-axis
    L = _dist(Pp, Qp)
    # the straight segment P'Q' must cross the positive x-axis before the positive y-axis
    t1 = R_(-Pp[1], Qp[1] - Pp[1]); t2 = R_(Pp[0], Pp[0] - Qp[0])
    X = Pp[0] + t1 * (Qp[0] - Pp[0]); Y = Pp[1] + t2 * (Qp[1] - Pp[1])
    assert t1 < t2 and X >= 0 and Y >= 0
    path = _dist(P, (X, 0)) + _dist((X, 0), (0, Y)) + _dist((0, Y), Q)
    assert simplify(path - L) == 0
    g = lambda s, u: math.hypot(6 - s, 4) + math.hypot(s, u) + math.hypot(3, 8 - u)
    assert min(g(i / 4, j / 4) for i in range(0, 41) for j in range(0, 41)) >= float(L) - 1e-9
    return path
f = Fig()
_axes(f, -1, 8, -1, 9.5)
f.pt("P(6, 4)", 6, 4, offset=(2.6, 0)); f.pt("Q(3, 8)", 3, 8, offset=(2.6, 0))
f.text((6.8, 0.5), "fence"); f.text((0.9, 9.0), "fence")
_alt = "First quadrant with straight fences along the x-axis and the y-axis; Kabir starts at P(6, 4) and must end at Q(3, 8)."
q("C19-A-041", T, "Shortest path touching two perpendicular lines, by double reflection", "Difficult",
  "Conceptual/application",
  r"Kabir stands at $P(6, 4)$ in a field, with coordinates in metres. There is a straight fence along the $x$-axis and another along the $y$-axis. He must walk in straight segments, first touching the fence on the $x$-axis, then touching the fence on the $y$-axis, and then reaching $Q(3, 8)$. What is the least total distance he must walk?",
  "MCQ",
  r"Reflect $P$ in the $x$-axis to $P'(6, -4)$ and $Q$ in the $y$-axis to $Q'(-3, 8)$. The path length equals $P'X + XY + YQ'$, which is at least $P'Q' = \sqrt{9^2 + 12^2} = 15$. The segment $P'Q'$ meets the $x$-axis at $(3, 0)$ and then the $y$-axis at $(0, 4)$, in the required order, so $15$ m is achieved.",
  "Measuring the direct distance, or walking straight to the nearest point of each fence.",
  "C19A-reflection-shortest-path", "Two reflections and a check that the touching points come in the required order.",
  correct=r"$15$ m",
  distractors=[(r"$17$ m", r"Walks straight down to $(6, 0)$, then to $(0, 8)$, then across: $4 + 10 + 3$."),
               (r"$21$ m", r"Adds the legs $9 + 12$ of the right triangle instead of taking its hypotenuse."),
               (r"$5$ m", r"Gives the direct distance $PQ$, which touches neither fence.")],
  check=_c041, values=[15, 17, 21, 5], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 042
def _c042():
    expr = x**2 + y**2 - 6*x + 4*y - 12
    g, h = -R_(expr.coeff(x, 1), 2), -R_(expr.coeff(y, 1), 2)
    r = sqrt(g**2 + h**2 - expr.subs({x: 0, y: 0}))
    cnt = 0
    for cc in range(-200, 201):
        if Abs(3 * g - 4 * h - cc) / 5 < r:
            cnt += 1
    return cnt
q("C19-A-042", T, "Counting integer parameters for which a line cuts a circle in two points", "Difficult",
  "Casework/optimisation",
  r"For how many integer values of $c$ does the line $3x - 4y = c$ meet the circle $x^2 + y^2 - 6x + 4y - 12 = 0$ at two distinct points?",
  "MCQ",
  r"The circle is $(x - 3)^2 + (y + 2)^2 = 25$: centre $(3, -2)$, radius $5$. Two distinct points need the centre's distance from the line to be less than $5$: $\frac{|9 + 8 - c|}{5} < 5$, so $|17 - c| < 25$, that is $-8 < c < 42$. The integers $-7, -6, \dots, 41$ number $49$.",
  "Including the two tangent values, or forgetting to multiply by the denominator.",
  "C19A-circle-tangent-line", "Distance condition as a strict inequality and an integer count with end-point trap.",
  correct=r"$49$",
  distractors=[(r"$51$", r"Uses $\le$ and includes the tangent values $c = -8$ and $c = 42$."),
               (r"$9$", r"Forgets the denominator $5$: $|17 - c| < 5$ gives $13 \le c \le 21$."),
               (r"$11$", r"Forgets the denominator and also includes the tangent values: $|17 - c| \le 5$.")],
  check=_c042, values=[49, 51, 9, 11], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 043
def _c043():
    def pts(n):
        g = math.gcd(n, 36)
        return sum(1 for X in range(0, n + 1) if (X * 36) % n == 0)
    return sum(1 for n in range(1, 101) if pts(n) == 3)
q("C19-A-043", T, "Counting segments with a given number of lattice points", "Difficult",
  "Casework/optimisation",
  r"For how many integers $n$ with $1 \le n \le 100$ does the segment joining $(0, 0)$ and $(n, 36)$ contain exactly $3$ points with integer coordinates, counting both end points?",
  "TITA",
  r"The segment from $(0, 0)$ to $(n, 36)$ contains $\gcd(n, 36) + 1$ lattice points, so we need $\gcd(n, 36) = 2$: $n$ even, not divisible by $4$, and not divisible by $3$. Numbers $n \equiv 2 \pmod 4$ up to $100$: $2, 6, \dots, 98$, which is $25$ numbers. Those divisible by $3$ are $6, 18, \dots, 90$, which is $8$ numbers. So $25 - 8 = 17$.",
  "Forgetting to exclude multiples of 3, or setting the gcd equal to 3 instead of 2.",
  "C19A-lattice-segment", "Lattice count turns into a gcd condition and an inclusion-exclusion count.",
  tita_answer=17, check=_c043, cognitive="Analysis", exams=CX,
  tita_traps=[(25, r"Counts all $n \equiv 2 \pmod 4$ and forgets to exclude multiples of $3$."),
              (11, r"Sets $\gcd(n, 36) = 3$ (points $=$ gcd): odd multiples of $3$ not divisible by $9$.")])

# ---------------------------------------------------------------- 044
def _c044():
    P, Q, R = (0, 0), (12, 0), (4, 8)
    tot = _area(P, Q, R)
    S = (Q[0] + t * (R[0] - Q[0]), Q[1] + t * (R[1] - Q[1]))
    # area PQS is linear in t for 0 <= t <= 1: 1/2 * 12 * 8t
    tt = solve(Eq(R_(1, 2) * 12 * 8 * t, tot / 3), t)[0]
    S = (Q[0] + tt * (R[0] - Q[0]), Q[1] + tt * (R[1] - Q[1]))
    return S[1] / S[0]   # slope of PS through the origin
f = Fig()
P = f.pt("P(0, 0)", 0, 0, offset=(1.4, -1.2)); Q = f.pt("Q(12, 0)", 12, 0, offset=(-1.4, -1.2)); R = f.pt("R(4, 8)", 4, 8)
f.poly(P, Q, R)
_alt = "Triangle with vertices P(0, 0), Q(12, 0) and R(4, 8)."
q("C19-A-044", T, "Line from a vertex dividing a triangle's area in a given ratio", "Difficult",
  "Multi-step word problem",
  r"A triangular field has corners $P(0, 0)$, $Q(12, 0)$ and $R(4, 8)$. A straight fence is built from $P$ to a point $S$ on side $QR$, dividing the field into two parts whose areas are in the ratio $1 : 2$, with triangle $PQS$ being the smaller part. The fence lies along the line",
  "MCQ",
  r"Triangles $PQS$ and $PSR$ share the height from $P$, so their areas are in the ratio $QS : SR = 1 : 2$. Hence $S = Q + \frac{1}{3}(R - Q) = \left(12 - \frac{8}{3}, \frac{8}{3}\right) = \left(\frac{28}{3}, \frac{8}{3}\right)$. The line $PS$ has slope $\frac{8}{28} = \frac{2}{7}$, so it is $2x - 7y = 0$.",
  "Measuring the one-third from R instead of Q, or using squares of ratios for areas.",
  "C19A-area-ratio-section", "Converts an area ratio into a section ratio, then a line equation.",
  correct=r"$2x - 7y = 0$",
  distractors=[(r"$4x - 5y = 0$", r"Measures from $R$: $S = Q + \frac{2}{3}(R - Q) = \left(\frac{20}{3}, \frac{16}{3}\right)$, which makes $PQS$ the larger part."),
               (r"$x - 2y = 0$", r"Takes $S$ as the midpoint $(8, 4)$ of $QR$."),
               (r"$2x - 13y = 0$", r"Squares the ratio as for similar figures, using $QS : SR = 1 : 4$, so $S = \left(\frac{52}{5}, \frac{8}{5}\right)$.")],
  check=_c044, values=[R_(2, 7), R_(4, 5), R_(1, 2), R_(2, 13)], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 045
def _c045():
    W = [(-3, 9), (6, 12), (13, 3), (3, -4)]      # K, L, M, N in order (convex)
    P, Q = (1, 1), (9, 7)
    tri = lambda Rp: _area(P, Q, Rp)
    best = max(tri(w) for w in W)
    # brute force over a fine grid of points of the field (inside or on the boundary)
    def side(a, b, p):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
    W10 = [(10 * u, 10 * v) for u, v in W]; P10, Q10 = (10, 10), (90, 70)
    for i in range(-30, 131):
        for j in range(-40, 121):
            pt = (i, j)
            if all(side(W10[k], W10[(k + 1) % 4], pt) <= 0 for k in range(4)):
                assert abs(side(P10, Q10, pt)) <= 200 * best   # twice the area, scaled by 100
    return best
f = Fig()
K = f.pt("K(-3, 9)", -3, 9, offset=(-0.6, 1.0)); L = f.pt("L(6, 12)", 6, 12, offset=(0, 1.0))
M = f.pt("M(13, 3)", 13, 3, offset=(2.3, 0)); N = f.pt("N(3, -4)", 3, -4, offset=(0, -1.0))
f.poly(K, L, M, N)
f.pt("P(1, 1)", 1, 1, offset=(2.0, 0.2)); f.pt("Q(9, 7)", 9, 7, offset=(-2.0, -0.2))
_alt = "Quadrilateral field KLMN with corners K(-3, 9), L(6, 12), M(13, 3) and N(3, -4), with two stakes P(1, 1) and Q(9, 7) inside it."
q("C19-A-045", T, "Largest triangle with a fixed base and third vertex anywhere in a convex polygon", "Difficult",
  "Casework/optimisation",
  r"A field is the quadrilateral $KLMN$ whose corners, taken in order, are $K(-3, 9)$, $L(6, 12)$, $M(13, 3)$ and $N(3, -4)$, with coordinates in metres. Two stakes stand inside the field at $P(1, 1)$ and $Q(9, 7)$. A third stake $R$ may be placed at any point of the field, inside or on its boundary. What is the largest possible area of triangle $PQR$, in m$^2$?",
  "TITA",
  r"$PQ = 10$ and line $PQ$ is $3x - 4y + 1 = 0$, so the area is $\frac{1}{2} \times 10 \times \frac{|3x - 4y + 1|}{5} = |3x - 4y + 1|$. This absolute value of a linear expression is largest over the convex field at a corner, on either side of $PQ$. At the corners it is $|-44| = 44$, $|-29| = 29$, $|28| = 28$ and $|26| = 26$. The largest area is $44$ m$^2$, with $R$ at $K$.",
  "Checking only the corners on one side of PQ, or picking the corner that looks farthest without computing.",
  "C19A-max-area-over-polygon", "Area as a linear expression in R, maximised over a convex region with casework on both sides of PQ.",
  tita_answer=44, check=_c045, cognitive="Analysis", exams=CX,
  tita_traps=[(28, r"Maximises $3x - 4y + 1$ without the absolute value, so only checks the corners below $PQ$ and picks $M$."),
              (29, r"Picks the highest corner $L(6, 12)$ as the one farthest from $PQ$."),
              (88, "Forgets the factor one-half in the triangle area.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 046
def _c046():
    pts = solve([x**2 + y**2 - 25, x**2 + y**2 - 12*x - 16*y + 35], [x, y])
    return _dist(pts[0], pts[1])
f = Fig()
f.circle((0, 0), 5); f.circle((6, 8), math.sqrt(65))
f.pt("O", 0, 0, offset=(-1, -0.6)); f.pt("(6, 8)", 6, 8, offset=(1.4, 0.6))
_alt = "Two intersecting circles: x^2 + y^2 = 25 centred at the origin O, and a larger circle x^2 + y^2 - 12x - 16y + 35 = 0 centred at (6, 8)."
q("C19-A-046", T, "Length of the common chord of two intersecting circles", "Difficult",
  "Multi-step word problem",
  r"Two circles are $x^2 + y^2 = 25$ and $x^2 + y^2 - 12x - 16y + 35 = 0$. What is the length, in units, of their common chord?",
  "TITA",
  r"Subtracting the equations gives the line of the common chord: $12x + 16y - 35 = 25$, that is $3x + 4y = 15$. Its distance from the centre $(0, 0)$ of the first circle is $\frac{15}{5} = 3$, so the half-chord is $\sqrt{25 - 9} = 4$ and the chord is $8$.",
  "Reporting the half-chord, or using the distance between the centres.",
  "C19A-circle-chord-length", "Two circles reduced to a line, then chord from distance; several stages.",
  tita_answer=8, check=_c046, cognitive="Analysis", exams=CX,
  tita_traps=[(4, "Reports the half-chord."),
              (10, r"Gives the distance between the centres $(0, 0)$ and $(6, 8)$.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 047
def _c047():
    # mirror 2x - y = 0; incident ray along y = 4, travelling towards decreasing x
    M = solve([y - 4, y - 2 * x], [x, y]); Mp = (M[x], M[y])        # point of incidence
    A = (10, 4)                                                    # a point on the incident ray before it hits
    Ap = _reflect(A, 2, -1, 0)                                     # its image lies on the reflected ray
    line = (y - Mp[1]) * (Ap[0] - Mp[0]) - (x - Mp[0]) * (Ap[1] - Mp[1])
    # independent check by reflecting the direction vector (-1, 0) in the mirror direction (1, 2)
    u = Matrix([1, 2]) / sqrt(5); v = Matrix([-1, 0])
    w = 2 * (v.dot(u)) * u - v
    assert simplify(w[1] / w[0] - diff(solve(line, y)[0], x)) == 0
    return _line_sl(line)
f = Fig()
_axes(f, -1, 9, -1, 9.5, origin=False)
f.seg((-0.4, -0.8), (4.6, 9.2))
f.text((5.9, 8.6), "y = 2x")
f.seg((8.5, 4), (2, 4))
f.text((7.2, 4.6), "y = 4")
_alt = "A mirror along the line y = 2x, and an incident ray along the horizontal line y = 4 coming from the right towards the mirror."
q("C19-A-047", T, "Equation of the reflected ray from a slanted mirror", "Difficult",
  "Conceptual/application",
  r"A plane mirror lies along the line $y = 2x$. A ray of light travels along the line $y = 4$ in the direction of decreasing $x$, strikes the mirror and is reflected. Along which line does the reflected ray travel?",
  "MCQ",
  r"The ray meets the mirror at $(2, 4)$. Take a point $(10, 4)$ on the incident ray; its image in $2x - y = 0$ is $(10, 4) - \frac{2(20 - 4)}{5}(2, -1) = \left(-\frac{14}{5}, \frac{52}{5}\right)$, and it lies on the reflected ray. The slope through $(2, 4)$ and this image is $\frac{32/5}{-24/5} = -\frac{4}{3}$, so the reflected ray is $y - 4 = -\frac{4}{3}(x - 2)$, that is $4x + 3y = 20$.",
  "Taking the reflected ray along the normal to the mirror, or slipping a sign when reflecting a point in a slanted line.",
  "C19A-reflected-ray-equation", "Point of incidence, reflection of a point in a slanted line and a line through two points; several traps.",
  correct=r"$4x + 3y = 20$",
  distractors=[(r"$4x - 3y = -4$", r"Sign slip in the image: uses $\left(-\frac{14}{5}, -\frac{12}{5}\right)$, giving slope $\frac{4}{3}$ through $(2, 4)$."),
               (r"$x + 2y = 10$", r"Sends the reflected ray along the normal to the mirror at $(2, 4)$."),
               (r"$4x - y = 4$", r"Thinks the reflected ray doubles the mirror's slope, using slope $4$ through $(2, 4)$.")],
  check=_c047, values=[(R_(-4, 3), R_(20, 3)), (R_(4, 3), R_(4, 3)), (R_(-1, 2), 5), (4, -4)], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 048
def _c048():
    P, Q = (2, 4), (5, 2)
    best, arg = -1, None
    for i in range(-400, 1201):
        X = R_(i, 40)
        v = abs(float(_dist(P, (X, 0)) - _dist(Q, (X, 0))))
        if v > best + 1e-12:
            best, arg = v, X
    assert abs(best - float(_dist(P, Q))) < 1e-9
    # exact point where line PQ meets y = 0
    xs = solve((y - P[1]) * (Q[0] - P[0]) - (x - P[0]) * (Q[1] - P[1]), x)[0].subs(y, 0)
    assert abs(float(xs) - float(arg)) < 1e-9
    return xs
f = Fig()
_axes(f, -1, 9.5, -1, 5)
f.pt("P(2, 4)", 2, 4, offset=(-0.4, 1)); f.pt("Q(5, 2)", 5, 2, offset=(2.6, 0))
_alt = "Coordinate axes with points P(2, 4) and Q(5, 2) above the x-axis."
q("C19-A-048", T, "Point on an axis that maximises the difference of distances", "Difficult",
  "Casework/optimisation",
  r"Points $P(2, 4)$ and $Q(5, 2)$ are given. A point $R$ moves along the $x$-axis. At which position of $R$ is $|RP - RQ|$ the largest?",
  "MCQ",
  r"By the triangle inequality, $|RP - RQ| \le PQ$, with equality exactly when $R$ is on line $PQ$ outside the segment $PQ$. Line $PQ$ has slope $-\frac{2}{3}$: $y - 4 = -\frac{2}{3}(x - 2)$. At $y = 0$, $x - 2 = 6$, so $R = (8, 0)$, and the largest value is $PQ = \sqrt{13}$.",
  "Using the reflection method, which minimises the sum RP + RQ, instead of the collinearity condition for the difference.",
  "C19A-max-difference-collinear", "Triangle inequality in the reverse direction; strong trap from the reflection method.",
  correct=r"$(8, 0)$",
  distractors=[(r"$(4, 0)$", r"Uses the reflection method, which gives the point minimising $RP + RQ$."),
               (r"$\left(\frac{3}{2}, 0\right)$", r"Uses the perpendicular bisector of $PQ$, where $RP = RQ$ and the difference is smallest."),
               (r"$(5, 0)$", r"Takes the foot of the perpendicular from the lower point $Q$.")],
  check=_c048, values=[8, 4, R_(3, 2), 5], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 049
def _c049():
    cnt = 0
    for X in range(-5, 6):
        for Y in range(-5, 6):
            if _area((0, 0), (6, 8), (X, Y)) == 10:
                cnt += 1
    return cnt
q("C19-A-049", T, "Counting lattice points that give a triangle of fixed area", "Difficult",
  "Casework/optimisation",
  r"Let $P = (0, 0)$ and $Q = (6, 8)$. How many points $R(x, y)$ with integer coordinates satisfying $-5 \le x \le 5$ and $-5 \le y \le 5$ make triangle $PQR$ have area exactly $10$?",
  "MCQ",
  r"Area $= \frac{1}{2}|6y - 8x| = 10$ gives $|4x - 3y| = 10$. For $4x - 3y = 10$: $x \equiv 1 \pmod 3$, giving $(1, -2)$ and $(4, 2)$ in range ($(-2, -6)$ and $(-5, -10)$ fail on $y$). For $4x - 3y = -10$: $x \equiv 2 \pmod 3$, giving $(-1, 2)$ and $(-4, -2)$ ($(2, 6)$ and $(5, 10)$ fail). So there are $4$ points.",
  "Using only one of the two parallel lines, or forgetting to apply the bound on y.",
  "C19A-lattice-area-condition", "Area condition becomes two linear Diophantine equations with bounds; casework.",
  correct=r"$4$",
  distractors=[(r"$2$", r"Uses only $4x - 3y = 10$ and forgets the line on the other side of $PQ$."),
               (r"$6$", r"Drops the $\frac{1}{2}$, solving $|4x - 3y| = 5$ instead."),
               (r"$8$", r"Applies the bound $-5 \le x \le 5$ but not the bound on $y$.")],
  check=_c049, values=[4, 2, 6, 8], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 050
def _c050():
    total = 0
    for cc in (5 + 4 * 5, 5 - 4 * 5):
        sol = solve([x**2 + y**2 - 25, 3*x + 4*y - cc], [x, y])
        total += len([s for s in sol if all(v.is_real for v in s)])
    # sanity: these are exactly the lines at distance 4 from 3x + 4y = 5
    return total
f = Fig()
f.circle((0, 0), 5)
f.pt("O", 0, 0, offset=(-0.9, -0.7))
f.seg((-7, (5 + 21) / 4), (7, (5 - 21) / 4))
f.text((6.4, -5.0), "3x + 4y = 5")
_alt = "Circle x^2 + y^2 = 25 centred at the origin O, crossed by the straight line 3x + 4y = 5."
q("C19-A-050", T, "Number of points on a circle at a given distance from a line", "Difficult",
  "Conceptual/application",
  r"How many points on the circle $x^2 + y^2 = 25$ are at a perpendicular distance of exactly $4$ units from the line $3x + 4y = 5$?",
  "MCQ",
  r"Such points lie on the two lines parallel to $3x + 4y = 5$ at distance $4$: $3x + 4y = 5 \pm 20$, that is $3x + 4y = 25$ and $3x + 4y = -15$. Their distances from the centre are $\frac{25}{5} = 5$ (equal to the radius, so tangent: $1$ point) and $\frac{15}{5} = 3$ (less than the radius: $2$ points). Total $3$.",
  "Assuming both parallel lines cut the circle twice, or considering only one side of the line.",
  "C19A-circle-line-position", "Locus as two parallel lines, each compared with the radius; tangent case is the trap.",
  correct=r"$3$",
  distractors=[(r"$4$", r"Assumes each parallel line meets the circle at two points, missing that $3x + 4y = 25$ is a tangent."),
               (r"$2$", r"Considers only the parallel line $3x + 4y = -15$ on one side."),
               (r"$1$", r"Considers only the parallel line $3x + 4y = 25$, the tangent.")],
  check=_c050, values=[3, 4, 2, 1], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))
