import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T_MP = "Marked price and discount"
T_SD = "Successive discounts and offers"
CX = ("CAT", "XAT")


def pct(x):
    return F(x, 100)


def _bill_partitions(items):
    """Yield every assignment of items to labelled bills (bill index per item)."""
    n = len(items)
    for labels in itertools.product(range(n), repeat=n):
        # canonical form: first occurrence order 0,1,2,...
        seen, ok = {}, True
        for l in labels:
            if l not in seen:
                if l != len(seen):
                    ok = False
                    break
                seen[l] = True
        if not ok:
            continue
        groups = {}
        for it, l in zip(items, labels):
            groups.setdefault(l, []).append(it)
        yield list(groups.values())


# ================================================================ EASY (14)

def _c1():
    C = symbols('C', positive=True)
    return solve(Eq(1500 * (1 - pct(12)), C * (1 + pct(10))), C)[0]
q("C02-B-001", T_MP, "Cost price from marked price, discount and profit percentage", "Easy",
  "Multi-step word problem",
  r"A water cooler is marked at Rs. $1{,}500$. Sneha's shop sells it at a discount of $12\%$ on the marked price and still makes a profit of $10\%$ on its cost price. What did the cooler cost the shop?",
  "MCQ",
  r"Selling price $= 1500 \times 0.88 = 1320$. Since this is $110\%$ of the cost price, cost price $= \frac{1320}{1.1} = 1200$. So the cooler cost Rs. $1{,}200$.",
  "Combining the discount and the profit percentages additively on the marked price, or taking the profit as a percentage of the selling price.",
  "C02B-mp-discount-profit-find-price", "Two linked percentages on different bases; the trap is mixing the bases.",
  correct=r"Rs. $1{,}200$",
  distractors=[(r"Rs. $1{,}170$", r"Subtracts $12\% + 10\% = 22\%$ of the marked price: $1500 \times 0.78 = 1170$."),
               (r"Rs. $1{,}188$", r"Removes $10\%$ of the selling price as profit: $1320 \times 0.9 = 1188$."),
               (r"Rs. $1{,}320$", r"Stops at the selling price $1500 \times 0.88 = 1320$ and reports it as the cost.")],
  check=_c1, values=[1200, 1170, 1188, 1320], cognitive="Application")


def _c2():
    C = 100
    sp = C * (1 + pct(40)) * (1 - pct(15))
    return (sp - C) / C * 100
q("C02-B-002", T_MP, "Net profit percentage from a mark-up and a discount", "Easy",
  "Multi-step word problem",
  r"Arjun marks every toy in his shop $40\%$ above its cost price and then allows a discount of $15\%$ on the marked price. What is his profit percentage?",
  "MCQ",
  r"Take cost price $= 100$. Marked price $= 140$ and selling price $= 140 \times 0.85 = 119$. Profit $= 19$ on a cost of $100$, that is $19\%$. (Directly: $40 - 15 - \frac{40 \times 15}{100} = 19$.)",
  "Subtracting the discount percentage from the mark-up percentage, ignoring that the discount is on the larger marked price.",
  "C02B-markup-discount-net-profit", "One mark-up and one discount on different bases; the trap is simple subtraction.",
  correct=r"$19\%$",
  distractors=[(r"$25\%$", r"Subtracts the percentages directly: $40 - 15 = 25$."),
               (r"$31\%$", r"Uses the combination rule with the wrong sign on the product term: $40 - 15 + \frac{40 \times 15}{100} = 31$."),
               (r"$34\%$", r"Takes $15\%$ of the $40\%$ mark-up only: $40 - 0.15 \times 40 = 34$.")],
  check=_c2, values=[19, 25, 31, 34], cognitive="Application")


def _c3():
    paid = (1 - pct(25)) * (1 - pct(12))
    return (1 - paid) * 100
q("C02-B-003", T_SD, "Single discount equivalent to two successive discounts", "Easy",
  "Single-step computation",
  r"During a clearance sale, a store gives a discount of $25\%$ on the marked price of a sofa and then a further discount of $12\%$ on the reduced price. What single discount, as a percentage of the marked price, is equivalent to these two discounts? Type the percentage as a number.",
  "TITA",
  r"The customer pays $0.75 \times 0.88 = 0.66$ of the marked price, so the single equivalent discount is $1 - 0.66 = 0.34$, that is $34\%$. (Or $25 + 12 - \frac{25 \times 12}{100} = 34$.)",
  "Adding successive discounts as if both were on the marked price.",
  "C02B-successive-equivalent", "One product of two factors; the trap is adding the rates.",
  tita_answer=34, check=_c3,
  tita_traps=[(37, r"Adds the two discounts: $25 + 12 = 37$."),
              (66, r"Reports the fraction of the marked price that is paid, $66\%$, as the discount.")],
  cognitive="Understanding")


def _c4():
    M = 8000
    single = M * (1 - pct(30))
    succ = M * (1 - pct(20)) * (1 - pct(10))
    return succ - single
q("C02-B-004", T_SD, "Rupee gap between a single discount and successive discounts of the same total", "Easy",
  "Multi-step word problem",
  r"A refrigerator is marked at Rs. $8{,}000$. Shop P offers a single discount of $30\%$, while shop Q offers successive discounts of $20\%$ and $10\%$ (the second on the reduced price). How much more does Ravi pay if he buys it from shop Q instead of shop P?",
  "MCQ",
  r"Shop P: $8000 \times 0.70 = 5600$. Shop Q: $8000 \times 0.8 \times 0.9 = 5760$. Ravi pays Rs. $160$ more at shop Q. (The successive pair equals only $28\%$, and the missing $2\%$ of $8000$ is $160$.)",
  r"Treating successive discounts of $20\%$ and $10\%$ as a single $30\%$ discount.",
  "C02B-successive-vs-single", "Two short computations; the trap is assuming the two offers are equal.",
  correct=r"Rs. $160$",
  distractors=[(r"Rs. $0$", r"Adds the successive discounts to $30\%$ and concludes the offers are identical."),
               (r"Rs. $128$", r"Finds the $2\%$ gap but applies it to the price after the first discount: $2\%$ of $6400 = 128$."),
               (r"Rs. $640$", r"Reports the second discount, $10\%$ of $6400$, as the extra amount.")],
  check=_c4, values=[160, 0, 128, 640], cognitive="Application")


def _c5():
    M = 1
    paid = 4 * M
    total = 5 * M
    return (total - paid) * 100 / total
q("C02-B-005", T_SD, "Effective discount of a buy-4-get-1-free offer", "Easy",
  "Conceptual/application",
  r"A shop runs the offer 'buy $4$ shirts, get $1$ more free' on shirts that all have the same marked price, with no other discount. Kabir takes home $5$ shirts under this offer. What is his effective discount, as a percentage of the total marked price of the $5$ shirts?",
  "TITA",
  r"He pays for $4$ shirts and receives $5$. The discount is $1$ shirt's price out of $5$ shirts' price, that is $\frac{1}{5} = 20\%$.",
  "Dividing the free quantity by the paid quantity instead of by the total quantity received.",
  "C02B-buy-get-free-effective-discount", "One ratio; the trap is the wrong denominator.",
  tita_answer=20, check=_c5,
  tita_traps=[(25, r"Divides the free shirt by the $4$ paid shirts: $\frac{1}{4} = 25\%$."),
              (80, r"Reports the fraction paid, $\frac{4}{5} = 80\%$, as the discount.")],
  cognitive="Understanding")


def _c6():
    M = 25000
    paid = M * (1 - pct(10))
    cb = min(paid * pct(5), 1000)
    return paid - cb
q("C02-B-006", T_SD, "Instant discount followed by a capped cashback", "Easy",
  "Multi-step word problem",
  r"A phone is marked at Rs. $25{,}000$. An online store gives an instant discount of $10\%$ on the marked price, and the bank then credits a cashback of $5\%$ of the amount paid, subject to a maximum cashback of Rs. $1{,}000$. What is the effective cost of the phone to the buyer after the cashback?",
  "MCQ",
  r"Amount paid $= 25000 \times 0.9 = 22500$. Five percent of this is $1125$, which exceeds the cap, so the cashback is Rs. $1{,}000$. Effective cost $= 22500 - 1000 = 21500$, that is Rs. $21{,}500$.",
  "Ignoring the cap on the cashback, or adding the two percentages.",
  "C02B-cashback", "Two steps with a cap; the trap is overlooking the maximum.",
  correct=r"Rs. $21{,}500$",
  distractors=[(r"Rs. $21{,}375$", r"Ignores the cap and subtracts the full $1125$: $22500 - 1125 = 21375$."),
               (r"Rs. $21{,}250$", r"Adds the percentages to $15\%$ of the marked price: $25000 \times 0.85 = 21250$."),
               (r"Rs. $21{,}600$", r"Takes the capped cashback first ($5\%$ of $25000$ capped at $1000$) and then the $10\%$ discount on $24000$: $21600$.")],
  check=_c6, values=[21500, 21375, 21250, 21600], cognitive="Application")


def _c7():
    d = symbols('d', positive=True)
    return solve(Eq(2000 * (1 - d / 100), 1600 * (1 + pct(10))), d)[0]
q("C02-B-007", T_MP, "Largest discount that keeps a required profit", "Easy",
  "Inverse/parameter",
  r"A bicycle costs a dealer Rs. $1{,}600$ and is marked at Rs. $2{,}000$. What is the largest discount, as a percentage of the marked price, that the dealer can give and still make a profit of at least $10\%$ on cost? Type the percentage as a number.",
  "TITA",
  r"The selling price must be at least $1600 \times 1.1 = 1760$. The largest discount is $2000 - 1760 = 240$, which is $\frac{240}{2000} = 12\%$ of the marked price.",
  "Subtracting the required profit percentage from the mark-up percentage.",
  "C02B-max-discount-for-profit", "One minimum selling price and one division; the trap is subtracting percentages.",
  tita_answer=12, check=_c7,
  tita_traps=[(15, r"Subtracts percentages: mark-up $25\%$ minus profit $10\%$ gives $15$."),
              (88, r"Reports the minimum selling price as a percentage of the marked price, $\frac{1760}{2000} = 88\%$.")],
  cognitive="Application")


def _c8():
    M, C = symbols('M C', positive=True)
    sol = solve(Eq(M * (1 - pct(25)), C * (1 + pct(20))), M)[0]
    return simplify(sol / C)
q("C02-B-008", T_MP, "Ratio of marked price to cost price from discount and profit percentages", "Easy",
  "Inverse/parameter",
  r"Fatima allows a discount of $25\%$ on the marked price of a handbag and still earns a profit of $20\%$ on its cost price. What is the ratio of the marked price to the cost price?",
  "MCQ",
  r"Selling price $= 0.75M = 1.2C$, so $\frac{M}{C} = \frac{1.2}{0.75} = \frac{8}{5}$. The ratio is $8 : 5$.",
  r"Undoing a $25\%$ discount by adding $25\%$ back, or adding the two percentages.",
  "C02B-mp-cp-ratio", "One equation in two prices; the trap is reversing a percentage decrease.",
  correct=r"$8 : 5$",
  distractors=[(r"$3 : 2$", r"Undoes the discount by adding $25\%$ to the selling price: $1.2 \times 1.25 = 1.5$."),
               (r"$29 : 20$", r"Adds the percentages to a $45\%$ mark-up: $1.45 = \frac{29}{20}$."),
               (r"$5 : 3$", r"Takes the profit as $20\%$ of the selling price: $SP = 1.25C$ and $M = \frac{1.25C}{0.75}$.")],
  check=_c8, values=[F(8, 5), F(3, 2), F(29, 20), F(5, 3)], cognitive="Application")


def _c9():
    C = 1
    M = C * (1 + pct(80))
    revenue = 4 * M
    cost = 5 * C
    return (revenue - cost) / cost * 100
q("C02-B-009", T_SD, "Seller's profit percentage under a buy-4-get-1-free offer", "Easy",
  "Conceptual/application",
  r"A stationer marks his notebooks $80\%$ above cost price and runs the offer 'buy $4$, get $1$ free' with no other discount. What is his profit percentage on a customer who takes home $5$ notebooks under the offer?",
  "MCQ",
  r"Take cost $= 1$ per notebook, so marked price $= 1.8$. He receives $4 \times 1.8 = 7.2$ for $5$ notebooks costing $5$. Profit $= \frac{2.2}{5} = 44\%$.",
  r"Treating the free item as a $25\%$ discount, or subtracting percentages.",
  "C02B-buy-get-free-seller-profit", "Revenue on paid items against cost of all items; the trap is the denominator of the free share.",
  correct=r"$44\%$",
  distractors=[(r"$60\%$", r"Sees the offer as $20\%$ off and subtracts: $80 - 20 = 60$."),
               (r"$35\%$", r"Treats the offer as $25\%$ off (one free per four paid): $1.8 \times 0.75 = 1.35$."),
               (r"$55\%$", r"Subtracts $25$ (one free per four paid) from $80$.")],
  check=_c9, values=[44, 60, 35, 55], cognitive="Application")


def _c10():
    M = symbols('M', positive=True)
    return solve(Eq(M * (1 - pct(15)), 1700 * (1 + pct(20))), M)[0]
q("C02-B-010", T_MP, "Marked price needed for a target profit after a fixed discount", "Easy",
  "Inverse/parameter",
  r"A pressure cooker costs a retailer Rs. $1{,}700$. He wants to give a discount of $15\%$ on the marked price and still make a profit of $20\%$ on cost. What should the marked price be?",
  "MCQ",
  r"Required selling price $= 1700 \times 1.2 = 2040$. This is $85\%$ of the marked price, so marked price $= \frac{2040}{0.85} = 2400$, that is Rs. $2{,}400$.",
  r"Adding the discount percentage to the profit percentage, or adding $15\%$ to the selling price.",
  "C02B-mp-discount-profit-find-price", "Two percentage steps on different bases; the trap is reversing the discount by adding.",
  correct=r"Rs. $2{,}400$",
  distractors=[(r"Rs. $2{,}295$", r"Adds the percentages: $1700 \times 1.35 = 2295$."),
               (r"Rs. $2{,}346$", r"Adds $15\%$ to the selling price: $2040 \times 1.15 = 2346$."),
               (r"Rs. $2{,}000$", r"Divides the cost by $0.85$ and leaves out the profit: $\frac{1700}{0.85} = 2000$.")],
  check=_c10, values=[2400, 2295, 2346, 2000], cognitive="Application")


def _c11():
    B, r, c = 2500, pct(20), 300
    a = B * (1 - r) - c
    b = (B - c) * (1 - r)
    return abs(a - b)
q("C02-B-011", T_SD, "Order of a percentage discount and a flat coupon", "Easy",
  "Conceptual/application",
  r"Meera's shopping bill at marked prices is Rs. $2{,}500$. The store gives a $20\%$ discount, and she also has a coupon for a flat Rs. $300$ off. The store applies both, one after the other, in whichever order the customer chooses. How many rupees does she save by choosing the better order rather than the other order?",
  "TITA",
  r"Discount first: $2500 \times 0.8 - 300 = 1700$. Coupon first: $(2500 - 300) \times 0.8 = 1760$. The better order saves $1760 - 1700 = 60$ rupees. (In general the gap is $20\%$ of the coupon, $0.2 \times 300 = 60$.)",
  "Assuming the order of a percentage discount and a flat coupon makes no difference.",
  "C02B-coupon-order", "Two short computations; the trap is assuming the operations commute.",
  tita_answer=60, check=_c11,
  tita_traps=[(0, r"Assumes the order does not matter."),
              (1700, r"Reports the lower bill instead of the saving.")],
  cognitive="Understanding")


def _c12():
    M, n = 900, 3
    p = n * M * (1 - pct(30))
    qq = (n - n // 3) * M
    return abs(p - qq)
q("C02-B-012", T_SD, "Comparing a percentage discount with a buy-2-get-1-free offer", "Easy",
  "Multi-step word problem",
  r"Harpreet needs $3$ identical table lamps, each marked Rs. $900$. Shop P gives $30\%$ off the marked price, and shop Q offers 'buy $2$, get $1$ free' with no other discount. She buys all $3$ lamps from the cheaper shop. How many rupees does she save compared with buying all $3$ from the other shop?",
  "TITA",
  r"Shop P: $2700 \times 0.7 = 1890$. Shop Q: she pays for $2$ lamps, $1800$. Shop Q is cheaper by $1890 - 1800 = 90$ rupees, because 'buy $2$, get $1$ free' is a $33\frac{1}{3}\%$ discount.",
  r"Reading 'buy 2, get 1 free' as a $50\%$ discount.",
  "C02B-compare-offers", "Two quick totals; the trap is converting the free offer to a percentage.",
  tita_answer=90, check=_c12,
  tita_traps=[(540, r"Treats 'buy $2$, get $1$ free' as $50\%$ off: $1890 - 1350 = 540$."),
              (810, r"Reports shop P's discount, $30\%$ of $2700$.")],
  cognitive="Application")


def _c13():
    x = symbols('x', positive=True)
    return solve(Eq(2500 * (1 - pct(20)) * (1 - x / 100), 1600), x)[0]
q("C02-B-013", T_SD, "Unknown second discount from the final price", "Easy",
  "Inverse/parameter",
  r"A wristwatch marked at Rs. $2{,}500$ is sold after a discount of $20\%$ followed by a second discount on the reduced price. The customer finally pays Rs. $1{,}600$. What is the second discount rate?",
  "MCQ",
  r"After the first discount the price is $2500 \times 0.8 = 2000$. The second discount takes it from $2000$ to $1600$, a reduction of $400$, which is $\frac{400}{2000} = 20\%$ of the reduced price.",
  "Measuring the second discount on the final price, or subtracting percentages.",
  "C02B-successive-unknown-rate", "One intermediate price; the trap is the base of the second discount.",
  correct=r"$20\%$",
  distractors=[(r"$25\%$", r"Divides the second reduction by the final price: $\frac{400}{1600} = 25\%$."),
               (r"$16\%$", r"Finds the overall discount $36\%$ and subtracts the first: $36 - 20 = 16$."),
               (r"$36\%$", r"Reports the overall discount $\frac{900}{2500} = 36\%$.")],
  check=_c13, values=[20, 25, 16, 36], cognitive="Application")


def _c14():
    C = 1
    sp = C * (1 + pct(25)) * (1 - pct(4))
    gift = C * pct(10)
    return (sp - C - gift) / C * 100
q("C02-B-014", T_MP, "Profit after discount when a free gift is also given", "Easy",
  "Multi-step word problem",
  r"Joseph marks a mixer grinder $25\%$ above its cost price and sells it at a discount of $4\%$ on the marked price. With each mixer grinder he also gives a free steel jar that costs him $10\%$ of the mixer grinder's cost price. What is his overall profit, as a percentage of the cost price of the mixer grinder?",
  "MCQ",
  r"Take cost $= 100$. Marked price $= 125$, selling price $= 125 \times 0.96 = 120$. The jar costs $10$, so the net receipt is $110$ on a cost of $100$: profit $10\%$.",
  "Subtracting the three percentages, or valuing the gift on the selling price.",
  "C02B-discount-with-free-gift", "Three small steps; the trap is the base of each percentage.",
  correct=r"$10\%$",
  distractors=[(r"$11\%$", r"Subtracts percentages: $25 - 4 - 10 = 11$."),
               (r"$20\%$", r"Leaves out the cost of the free jar."),
               (r"$8\%$", r"Values the jar at $10\%$ of the selling price: $120 - 12 = 108$.")],
  check=_c14, values=[10, 11, 20, 8], cognitive="Application")


# ================================================================ MEDIUM (20)

def _c15():
    m = symbols('m', positive=True)
    sol = solve(Eq((1 + m / 100) * (1 - pct(20)) * (1 - pct(25)), 1 + pct(20)), m)
    return sol[0]
q("C02-B-015", T_SD, "Mark-up needed for a target profit after two successive discounts", "Medium",
  "Inverse/parameter",
  r"A furniture dealer plans to sell a dining set at successive discounts of $20\%$ and $25\%$ on the marked price and still make a profit of $20\%$ on cost. By what percentage above the cost price must he mark the set?",
  "MCQ",
  r"The customer pays $0.8 \times 0.75 = 0.6$ of the marked price. We need $0.6M = 1.2C$, so $M = 2C$: the set must be marked $100\%$ above cost.",
  "Adding the discounts and the profit, or reversing each discount by adding it back.",
  "C02B-markup-for-target", "Two discounts compounded and then inverted; several plausible shortcuts fail.",
  correct=r"$100\%$",
  distractors=[(r"$65\%$", r"Adds $20 + 25 + 20 = 65$."),
               (r"$80\%$", r"Reverses each discount by adding it: $1.2 \times 1.2 \times 1.25 = 1.8$."),
               (r"$50\%$", r"Allows only for the first discount: $\frac{1.2}{0.8} = 1.5$.")],
  check=_c15, values=[100, 65, 80, 50], cognitive="Application")


def _c16():
    x = symbols('x', positive=True)
    return solve(Eq((1 + pct(50)) * (1 - pct(10)) * (1 - x / 100), 1 + pct(8)), x)[0]
q("C02-B-016", T_MP, "Largest extra discount on a reduced price that keeps a profit target", "Medium",
  "Inverse/parameter",
  r"A trader marks a jacket $50\%$ above cost price and already offers a $10\%$ discount on the marked price. At the end of the season he wants to give a further discount on this reduced price while still making a profit of at least $8\%$ on cost. What is the largest further discount he can give, as a percentage of the reduced price?",
  "MCQ",
  r"Take cost $= 100$: marked price $150$, reduced price $135$. The final price must be at least $108$, so the further discount is at most $135 - 108 = 27$, which is $\frac{27}{135} = 20\%$ of the reduced price.",
  "Measuring the further discount against the cost price or the marked price, or subtracting percentages.",
  "C02B-max-discount-for-profit", "Requires tracking which price each percentage is based on across three levels.",
  correct=r"$20\%$",
  distractors=[(r"$27\%$", r"Measures the $27$ rupee room against the cost price of $100$."),
               (r"$32\%$", r"Subtracts percentages: $50 - 10 - 8 = 32$."),
               (r"$18\%$", r"Measures the $27$ rupee room against the marked price: $\frac{27}{150} = 18\%$.")],
  check=_c16, values=[20, 27, 32, 18], cognitive="Analysis")


def _c17():
    x = symbols('x', positive=True)
    sols = solve(Eq((1 - pct(10)) * (1 - pct(20)) * (1 - x / 100), 1 - pct(46)), x)
    sols = [s for s in sols if 0 < s < 100]
    assert len(sols) == 1
    return sols[0]
q("C02-B-017", T_SD, "Third of three successive discounts from their single equivalent", "Medium",
  "Inverse/parameter",
  r"In a festive sale, a showroom gives three successive discounts on the marked price of a television, each on the price left after the previous one. The first two are $10\%$ and $20\%$. The three discounts together are equivalent to a single discount of $46\%$. The rate of the third discount is",
  "MCQ",
  r"After the first two discounts the customer would pay $0.9 \times 0.8 = 0.72$ of the marked price; in the end the customer pays $1 - 0.46 = 0.54$ of it. The third discount leaves $\frac{0.54}{0.72} = 0.75$ of the reduced price, so its rate is $25\%$.",
  "Subtracting discount percentages instead of dividing the fractions paid.",
  "C02B-successive-unknown-rate", "Combine two discounts, then invert the third factor; additive shortcuts give tempting values.",
  correct=r"$25\%$",
  distractors=[(r"$16\%$", r"Subtracts the given discounts from the total: $46 - 10 - 20 = 16$."),
               (r"$18\%$", r"Combines the first two correctly to $28\%$ and then subtracts: $46 - 28 = 18$."),
               (r"$40\%$", r"Allows only for the first discount: $\frac{0.54}{0.9} = 0.6$, so $40\%$.")],
  check=_c17, values=[25, 16, 18, 40], cognitive="Application")


def _c18():
    M = 1
    paid = 3 * M * (1 - pct(20))
    return (4 * M - paid) / (4 * M) * 100
q("C02-B-018", T_SD, "Effective discount when a free-item offer is combined with a percentage discount", "Medium",
  "Conceptual/application",
  r"A store runs 'buy $3$, get $1$ free' on identical T-shirts. On festival days it also gives $20\%$ off the billed amount, that is, the amount for the $3$ T-shirts paid for. Priya takes home $4$ T-shirts on a festival day. What is her effective discount, as a percentage of the total marked price of the $4$ T-shirts?",
  "TITA",
  r"Let each T-shirt be marked $1$. She pays $3 \times 0.8 = 2.4$ for $4$ T-shirts worth $4$. The effective discount is $\frac{4 - 2.4}{4} = 0.4$, that is $40\%$. (Equivalently, successive discounts of $25\%$ and $20\%$.)",
  r"Adding the two offers as $25\% + 20\%$.",
  "C02B-buy-get-free-effective-discount", "Two offers must be compounded, not added.",
  tita_answer=40, check=_c18,
  tita_traps=[(45, r"Adds $25\%$ (one free in four) and $20\%$."),
              (60, r"Reports the fraction paid, $\frac{2.4}{4} = 60\%$, as the discount.")],
  cognitive="Application")


def _c19():
    m = symbols('m', positive=True)
    return solve(Eq(4 * (1 + m / 100), 5 * (1 + pct(20))), m)[0]
q("C02-B-019", T_SD, "Mark-up needed to keep a profit under a buy-4-get-1-free offer", "Medium",
  "Inverse/parameter",
  r"A dealer runs the offer 'buy $4$, get $1$ free' on identical pairs of socks, with no other discount. He wants a profit of $20\%$ on the total cost of all the pairs he hands over. By what percentage above cost price must he mark each pair?",
  "MCQ",
  r"For every $5$ pairs he is paid for $4$. With cost $1$ per pair and marked price $M$: $4M = 5 \times 1.2 = 6$, so $M = 1.5$. He must mark $50\%$ above cost.",
  r"Reading the offer as $25\%$ off, or adding the profit to the size of the offer.",
  "C02B-buy-get-free-seller-profit", "Inverse of the free-offer profit relation; several additive shortcuts fail.",
  correct=r"$50\%$",
  distractors=[(r"$60\%$", r"Treats the offer as $25\%$ off: $\frac{1.2}{0.75} = 1.6$."),
               (r"$40\%$", r"Adds the required $20\%$ profit to the $20\%$ given free."),
               (r"$45\%$", r"Adds the $20\%$ profit to $25\%$ (one free per four paid).")],
  check=_c19, values=[50, 60, 40, 45], cognitive="Application")


def _c20():
    first, second = 6000, 4000
    voucher = first * pct(25)
    paid = first + (second - voucher)
    return (first + second - paid) * 100 / (first + second)
q("C02-B-020", T_SD, "Effective discount when cashback is a voucher for the next purchase", "Medium",
  "Multi-step word problem",
  r"Ananya buys clothes for Rs. $6{,}000$ at marked price and receives a voucher worth $25\%$ of this bill, redeemable on her next purchase. A week later she buys shoes marked Rs. $4{,}000$, uses the full voucher and pays the rest in cash. There are no other discounts. Taking both purchases together, what is her effective discount as a percentage of the total marked price?",
  "TITA",
  r"The voucher is worth $0.25 \times 6000 = 1500$. Total marked price $= 6000 + 4000 = 10000$, and she pays $6000 + 2500 = 8500$. Effective discount $= \frac{1500}{10000} = 15\%$.",
  "Taking the headline voucher percentage as the effective discount.",
  "C02B-cashback", "The saving must be spread over both purchases.",
  tita_answer=15, check=_c20,
  tita_traps=[(25, r"Takes the headline $25\%$ as the effective discount.")],
  cognitive="Application")


def _c21():
    n, price = 4, 625
    B = n * price
    costs = {
        "succ": B * (1 - pct(20)) * (1 - pct(12)),
        "single": B * (1 - pct(29)),
        "b3g1": (n - n // 4) * price,
        "flat": B - 700 if B >= 2000 else B,
    }
    best = min(costs, key=costs.get)
    assert list(costs.values()).count(costs[best]) == 1
    return costs[best]
q("C02-B-021", T_SD, "Choosing the best of four offers for a fixed purchase", "Medium",
  "Casework/optimisation",
  r"Kabir needs $4$ identical water bottles, each marked Rs. $625$, and will buy all $4$ in a single bill. Four stores sell them at the same marked price, each with one of the offers below (offers cannot be combined). Under which offer does he pay the least?",
  "MCQ",
  r"The bill at marked price is $2500$. Successive $20\%$ and $12\%$: $2500 \times 0.8 \times 0.88 = 1760$. Single $29\%$: $1775$. 'Buy $3$, get $1$ free': he pays for $3$, $1875$. Rs. $700$ off: $1800$. The successive discounts, worth $29.6\%$, give the lowest price, Rs. $1{,}760$.",
  "Assuming successive discounts are always worse than a comparable single discount, or valuing a flat rebate against the wrong base.",
  "C02B-compare-offers", "Four offers in different forms must be brought to a common base.",
  correct=r"Successive discounts of $20\%$ and $12\%$",
  distractors=[(r"A single discount of $29\%$", r"Assumes successive discounts always lose to a single discount close to their sum, without computing $29.6\%$."),
               (r"Buy $3$, get $1$ free", r"Reads the offer as one-third off rather than one-quarter off."),
               (r"Rs. $700$ off on bills of Rs. $2{,}000$ or more", r"Measures the Rs. $700$ against the Rs. $2{,}000$ threshold, $35\%$, instead of against the Rs. $2{,}500$ bill.")],
  check=_c21, values=[1760, 1775, 1875, 1800], cognitive="Analysis", exams=CX)


def _c22():
    M, C = symbols('M C', positive=True)
    Mv = solve(Eq(M * (1 - pct(10)), C * (1 + pct(17))), M)[0]
    return simplify((Mv * (1 - pct(20)) - C) / C * 100)
q("C02-B-022", T_MP, "Profit at a new discount from profit at a known discount", "Medium",
  "Multi-step word problem",
  r"When Sneha sells a suitcase at a discount of $10\%$ on its marked price, she makes a profit of $17\%$ on cost. If she instead sells it at a discount of $20\%$ on the same marked price, what will be the result?",
  "MCQ",
  r"$0.9M = 1.17C$ gives $M = 1.3C$. At a $20\%$ discount the price is $0.8 \times 1.3C = 1.04C$, a profit of $4\%$.",
  "Subtracting the extra discount percentage directly from the profit percentage.",
  "C02B-two-discount-scenarios", "Recover the mark-up from one scenario and apply it to another.",
  correct=r"A profit of $4\%$",
  distractors=[(r"A profit of $7\%$", r"Subtracts the extra $10$ percentage points of discount from the $17\%$ profit."),
               (r"A loss of $3\%$", r"Subtracts the full $20\%$ discount from the $17\%$ profit."),
               (r"A profit of $10\%$", r"Finds the $30\%$ mark-up and subtracts the $20\%$ discount from it.")],
  check=_c22, values=[4, 7, -3, 10], cognitive="Application")


def _c23():
    M, C = symbols('M C', positive=True)
    sol = solve([Eq(C - M * (1 - pct(15)), 60), Eq(M * (1 - pct(5)) - C, 90)], [M, C], dict=True)[0]
    return sol[C]
q("C02-B-023", T_MP, "Cost price from a loss at one discount and a profit at another", "Medium",
  "Multi-step word problem",
  r"If a shopkeeper sells an air fryer at a discount of $15\%$ on its marked price, he loses Rs. $60$; if he sells it at a discount of $5\%$ on the marked price, he gains Rs. $90$. What is the cost price of the air fryer, in rupees?",
  "TITA",
  r"The two selling prices differ by $10\%$ of the marked price, and also by $60 + 90 = 150$ rupees. So $0.1M = 150$, $M = 1500$. At a $15\%$ discount the price is $1275$, and cost $= 1275 + 60 = 1335$.",
  "Reporting the marked price, or using the difference of the rupee amounts instead of their sum.",
  "C02B-two-discount-scenarios", "Two scenarios must be linked through the marked price.",
  tita_answer=1335, check=_c23,
  tita_traps=[(1500, r"Stops at the marked price."),
              (1275, r"Reports the selling price at the $15\%$ discount.")],
  cognitive="Application")


def _c24():
    x = symbols('x', positive=True)
    sols = solve(Eq((1 - x / 100) * (1 - x / 200), 1 - pct(28)), x)
    sols = [s for s in sols if 0 < s < 100]
    assert len(sols) == 1
    return sols[0]
q("C02-B-024", T_SD, "First of two linked successive discounts from their single equivalent", "Medium",
  "Inverse/parameter",
  r"A store offers two successive discounts on a microwave oven, the second (on the reduced price) being exactly half the rate of the first. Together they are equivalent to a single discount of $28\%$. What is the rate of the first discount, in percent?",
  "TITA",
  r"Let the first rate be $x\%$. Then $(1 - \frac{x}{100})(1 - \frac{x}{200}) = 0.72$. Trying $x = 20$: $0.8 \times 0.9 = 0.72$. The other root of the quadratic exceeds $100$, so the first discount is $20\%$.",
  "Reporting the second rate, or splitting $28$ in the ratio $2 : 1$ additively.",
  "C02B-successive-unknown-rate", "A quadratic in the rate, best solved by spotting the factors.",
  tita_answer=20, check=_c24,
  tita_traps=[(10, r"Reports the second discount instead of the first.")],
  cognitive="Application")


def _c25():
    B, r, c, thr = 2400, pct(20), 250, 2000
    # discount first
    a = B * (1 - r)
    if a >= thr:
        a -= c
    # coupon first
    b = B
    if b >= thr:
        b -= c
    b = b * (1 - r)
    return min(a, b)
q("C02-B-025", T_SD, "Order of discount and coupon when the coupon has a minimum bill condition", "Medium",
  "Casework/optimisation",
  r"Fatima's bill at marked prices is Rs. $2{,}400$. The store gives a $20\%$ discount, and she has a coupon for Rs. $250$ off that can be used only if the bill amount at the moment the coupon is applied is at least Rs. $2{,}000$. The customer may choose the order in which the discount and the coupon are applied. What is the least amount she can pay?",
  "MCQ",
  r"Discount first: $2400 \times 0.8 = 1920$, which is below Rs. $2{,}000$, so the coupon cannot be used and she pays $1920$. Coupon first: $2400 - 250 = 2150$, then $2150 \times 0.8 = 1720$. The least amount is Rs. $1{,}720$.",
  "Using the usually better order (discount first) without checking the coupon condition.",
  "C02B-coupon-order", "The usual rule for ordering fails because of the condition; both cases must be checked.",
  correct=r"Rs. $1{,}720$",
  distractors=[(r"Rs. $1{,}670$", r"Applies the discount first and then the coupon, ignoring that $1920 < 2000$."),
               (r"Rs. $1{,}920$", r"Uses only the discount-first order, where the coupon fails."),
               (r"Rs. $1{,}620$", r"Knows the two orders differ by $20\%$ of Rs. $250$ but subtracts the Rs. $50$ from $1670$ instead of adding it.")],
  check=_c25, values=[1720, 1670, 1920, 1620], cognitive="Analysis", exams=CX)


def _c26():
    items = [1200, 900, 800, 700, 600]
    best = None
    for groups in _bill_partitions(items):
        pay = sum(sum(g) - (500 if sum(g) >= 2000 else 0) for g in groups)
        best = pay if best is None else min(best, pay)
    return best
q("C02-B-026", T_SD, "Splitting a purchase into bills to use a per-bill flat discount", "Medium",
  "Casework/optimisation",
  r"A store gives Rs. $500$ off on every bill of Rs. $2{,}000$ or more (one such discount per bill). Ananya wants to buy five items marked Rs. $1{,}200$, Rs. $900$, Rs. $800$, Rs. $700$ and Rs. $600$, and she may split them into as many separate bills as she likes. What is the least total amount, in rupees, she must pay for all five items?",
  "TITA",
  r"The total is $4200$, so at most two bills can reach Rs. $2{,}000$. Two such bills are possible: $1200 + 800 = 2000$ and $900 + 700 + 600 = 2200$. She pays $4200 - 2 \times 500 = 3200$.",
  "Putting everything in one bill, or not checking that two qualifying bills can actually be formed.",
  "C02B-split-bills-threshold", "Needs a bound on the number of qualifying bills and a partition achieving it.",
  tita_answer=3200, check=_c26,
  tita_traps=[(3700, r"Pays in a single bill and gets only one Rs. $500$ discount.")],
  cognitive="Analysis", exams=CX)


def _c27():
    price = 60
    def bill(k):
        o1 = price * (k - k // 4)
        o2 = F(price * k * 80, 100) if k >= 5 else price * k
        return min(o1, o2, price * k)
    best = {0: 0}
    for total in range(1, 11):
        best[total] = min(best[total - k] + bill(k) for k in range(1, total + 1))
    return best[10]
q("C02-B-027", T_SD, "Cheapest way to buy a fixed quantity using two per-bill offers", "Medium",
  "Casework/optimisation",
  r"Notebooks are marked Rs. $60$ each. A shop offers two schemes, and only one scheme can be used on any one bill: (i) 'buy $3$, get $1$ free' on each group of $4$ notebooks in the bill; (ii) $20\%$ off the bill if the bill has $5$ or more notebooks. Joseph may split his purchase into several bills. What is the least amount he must pay to take home exactly $10$ notebooks?",
  "MCQ",
  r"A notebook costs $45$ only inside a full group of $4$ under scheme (i), $48$ only in a scheme (ii) bill of $5$ or more, and $60$ otherwise. With no full group of $4$ under scheme (i), every notebook costs at least $48$: at least $480$. With two such groups ($8$ notebooks, $360$), the other $2$ cannot form a scheme (ii) bill and cost $120$: $480$. With exactly one group ($180$), the other $6$ cost at least $6 \times 48 = 288$, and one scheme (ii) bill of $6$ achieves this: $468$. So the least he pays is Rs. $468$.",
  "Using a single scheme throughout, or applying scheme (ii) to a bill with fewer than $5$ notebooks.",
  "C02B-bundle-optimise", "Needs comparison of per-unit rates and attention to the leftover notebooks.",
  correct=r"Rs. $468$",
  distractors=[(r"Rs. $480$", r"Uses only one scheme for all $10$ notebooks."),
               (r"Rs. $450$", r"Treats 'buy $3$, get $1$ free' as $25\%$ off all $10$ notebooks: $600 \times 0.75$."),
               (r"Rs. $456$", r"Uses scheme (i) for $8$ notebooks ($360$) and scheme (ii) on the last $2$ ($96$), although that bill has fewer than $5$.")],
  check=_c27, values=[468, 480, 450, 456], cognitive="Analysis", exams=CX)


def _c28():
    M, C = symbols('M C', positive=True)
    d = pct(20)
    sol = solve(Eq(d * M, M * (1 - d) - C), M)[0]
    return simplify(sol / C)
q("C02-B-028", T_MP, "Ratio of marked price to cost when the discount amount equals the profit amount", "Medium",
  "Conceptual/application",
  r"Ravi sells a carpet at a discount of $20\%$ on its marked price. The discount he gives, in rupees, is exactly equal to the profit he makes, in rupees. What is the ratio of the marked price to the cost price?",
  "MCQ",
  r"Let the marked price be $M$. Discount $= 0.2M$ and selling price $= 0.8M$, so profit $= 0.8M - C = 0.2M$, giving $C = 0.6M$. Hence $M : C = 1 : 0.6 = 5 : 3$.",
  "Equating the percentages instead of the rupee amounts.",
  "C02B-mp-cp-ratio", "Equal amounts on different bases; the trap is equating percentages.",
  correct=r"$5 : 3$",
  distractors=[(r"$3 : 2$", r"Takes the profit percentage equal to the discount percentage: $0.8M = 1.2C$."),
               (r"$5 : 4$", r"Leaves out the profit and sets the selling price equal to the cost: $0.8M = C$."),
               (r"$7 : 5$", r"Assumes a $20\%$ profit and adds it to the $20\%$ discount for a $40\%$ mark-up.")],
  check=_c28, values=[F(5, 3), F(3, 2), F(5, 4), F(7, 5)], cognitive="Analysis")


def _c29():
    paid = 1 - pct(20)
    qty = 1 + pct(25)
    return (1 - paid / qty) * 100
q("C02-B-029", T_SD, "Extra quantity combined with a price discount, as a fall in price per kg", "Medium",
  "Conceptual/application",
  r"A $1$ kg pack of detergent normally sells at its marked price. During a promotion the company puts $25\%$ extra detergent in the pack ($1.25$ kg) and also sells it at $20\%$ off the marked price. By what percentage has the price per kg fallen?",
  "MCQ",
  r"The customer now pays $0.8$ of the old price for $1.25$ times the quantity. Price per kg $= \frac{0.8}{1.25} = 0.64$ of the old, a fall of $36\%$.",
  "Adding the extra quantity percentage to the discount percentage.",
  "C02B-extra-quantity-offer", "Extra quantity must be converted to a price fall before combining.",
  correct=r"$36\%$",
  distractors=[(r"$45\%$", r"Adds $25\%$ extra and $20\%$ off."),
               (r"$40\%$", r"Converts $25\%$ extra correctly to $20\%$ but then adds the second $20\%$."),
               (r"$64\%$", r"Reports the new price per kg as a fraction of the old, $0.64$, as the fall.")],
  check=_c29, values=[36, 45, 40, 64], cognitive="Understanding")


def _c30():
    price = 1 + pct(60)
    n = 0
    while price >= 1:
        price *= 1 - pct(10)
        n += 1
    return n
q("C02-B-030", T_SD, "Number of repeated percentage cuts until the price falls below cost", "Medium",
  "Inverse/parameter",
  r"A boutique marks a dress $60\%$ above its cost price. Every Monday, if the dress is unsold, the boutique cuts its current price by $10\%$ of that current price. After how many such cuts is the dress priced below its cost price for the first time?",
  "TITA",
  r"After $n$ cuts the price is $1.6 \times 0.9^n$ times the cost. $0.9^4 = 0.6561$ gives $1.6 \times 0.6561 \approx 1.05$, still above cost; $0.9^5 = 0.59049$ gives about $0.945$, below cost. So after $5$ cuts.",
  "Treating the cuts as $10$ percentage points of the cost each time.",
  "C02B-repeated-markdown", "Compounded decreases must be tracked step by step against a threshold.",
  tita_answer=5, check=_c30,
  tita_traps=[(6, r"Treats each cut as removing $10$ points of the $60\%$ mark-up: $\frac{60}{10} = 6$."),
              (4, r"Gives the last cut after which the dress is still above cost.")],
  cognitive="Application")


def _c31():
    C0 = 1
    M0 = C0 * (1 + pct(50))
    C1 = C0 * (1 + pct(20))
    M1 = M0 * (1 + pct(20))
    sp = M1 * (1 - pct(20))
    return (sp - C1) / C1 * 100
q("C02-B-031", T_MP, "Profit after cost, marked price and discount all change", "Medium",
  "Multi-step word problem",
  r"Last year a retailer marked a mobile cover $50\%$ above its cost price and gave a $10\%$ discount on it. This year his cost price has gone up by $20\%$, he has raised the marked price by $20\%$, and he now gives a $20\%$ discount on the new marked price. What is his profit percentage this year, on this year's cost price?",
  "MCQ",
  r"Take last year's cost as $100$, so the marked price was $150$. This year the cost is $120$ and the marked price $180$, still $50\%$ above cost. Selling price $= 180 \times 0.8 = 144$, so profit $= \frac{24}{120} = 20\%$.",
  "Measuring the profit against last year's cost, or subtracting the discount from the mark-up.",
  "C02B-price-revision", "Several changes at once; only the new mark-up and discount matter, on the new base.",
  correct=r"$20\%$",
  distractors=[(r"$35\%$", r"Assumes that equal $20\%$ rises in cost and marked price leave last year's $35\%$ profit unchanged, overlooking the new discount."),
               (r"$30\%$", r"Subtracts the new discount from the mark-up: $50 - 20 = 30$."),
               (r"$44\%$", r"Measures the selling price $144$ against last year's cost of $100$.")],
  check=_c31, values=[20, 35, 30, 44], cognitive="Analysis")


def _c32():
    M = 50000
    p = M * (1 - pct(10))
    p -= p * pct(5)
    qq = M * (1 - pct(8)) * (1 - pct(7))
    return abs(p - qq)
q("C02-B-032", T_SD, "Discount plus cashback against two successive discounts", "Medium",
  "Multi-step word problem",
  r"A laptop is marked Rs. $50{,}000$ at two stores. Store P gives $10\%$ off and then a cashback of $5\%$ of the amount paid. Store Q gives successive discounts of $8\%$ and $7\%$. Treat cashback as reducing the cost. How many rupees less is the effective cost at the cheaper store?",
  "TITA",
  r"Store P: $50000 \times 0.9 = 45000$, cashback $2250$, effective cost $42750$. Store Q: $50000 \times 0.92 \times 0.93 = 42780$. Store P is cheaper by $30$ rupees.",
  "Adding the percentages at both stores and concluding the costs are equal.",
  "C02B-cashback", "Two compounded pairs with a small gap; additive shortcuts give a tie.",
  tita_answer=30, check=_c32,
  tita_traps=[(0, r"Adds $10 + 5$ and $8 + 7$, gets $15\%$ at both stores and concludes they are equal."),
              (280, r"Adds the percentages at store P only ($42500$) and compares with the correct $42780$.")],
  cognitive="Application")


def _c33():
    price = 1200
    rates = [0, 30, 60]
    total = sum(price * (1 - pct(rates[i % 3])) for i in range(5))
    return (5 * price - total) * 100 / (5 * price)
q("C02-B-033", T_SD, "Effective discount for a tiered 'second at 30%, third at 60% off' offer", "Medium",
  "Multi-step word problem",
  r"A store bills identical shirts, each marked Rs. $1{,}200$, in blocks of $3$: in each block the first shirt is at full price, the second at $30\%$ off and the third at $60\%$ off. A final incomplete block is billed the same way as far as it goes. Ravi buys $5$ shirts in one bill. What is his effective discount, as a percentage of the total marked price?",
  "MCQ",
  r"The first block costs $1200 + 840 + 480 = 2520$; the incomplete block of $2$ costs $1200 + 840 = 2040$. Total $= 4560$ against $6000$, a saving of $1440$, that is $24\%$.",
  "Averaging the block discounts over all shirts, or mishandling the incomplete block.",
  "C02B-tiered-item-offer", "Block structure with an incomplete block; averaging shortcuts fail.",
  correct=r"$24\%$",
  distractors=[(r"$30\%$", r"Averages the block discounts $\frac{0 + 30 + 60}{3} = 30\%$ over all $5$ shirts."),
               (r"$18\%$", r"Applies the offer only to the first block and bills the last $2$ shirts at full price."),
               (r"$36\%$", r"Continues the pattern across blocks, billing the fourth shirt at $30\%$ off and the fifth at $60\%$ off.")],
  check=_c33, values=[24, 30, 18, 36], cognitive="Application")


def _c34():
    M = symbols('M', positive=True)
    p = (1 - pct(30)) * (1 - pct(20)) * M
    qq = (M - 2000) * (1 - pct(40))
    return solve(Eq(p, qq), M)[0]
q("C02-B-034", T_SD, "Break-even marked price between successive discounts and a flat-then-percentage offer", "Medium",
  "Inverse/parameter",
  r"For any item, shop P gives successive discounts of $30\%$ and $20\%$ on the marked price, while shop Q first takes Rs. $2{,}000$ off the marked price and then gives $40\%$ off the reduced amount. Both shops use the same marked price. Shop P is cheaper exactly when the marked price is more than",
  "MCQ",
  r"Shop P charges $0.7 \times 0.8M = 0.56M$. Shop Q charges $0.6(M - 2000) = 0.6M - 1200$. Shop P is cheaper when $0.56M < 0.6M - 1200$, that is $0.04M > 1200$, so $M > 30000$: Rs. $30{,}000$.",
  "Adding the successive discounts, or applying shop Q's steps in the wrong order.",
  "C02B-successive-vs-single", "Two linear cost expressions and an inequality; two distinct traps.",
  correct=r"Rs. $30{,}000$",
  distractors=[(r"Rs. $12{,}000$", r"Treats shop P's discounts as a single $50\%$: $0.5M < 0.6M - 1200$."),
               (r"Rs. $50{,}000$", r"Applies shop Q's $40\%$ first and then the Rs. $2{,}000$: $0.56M < 0.6M - 2000$."),
               (r"Rs. $20{,}000$", r"Makes both slips: $0.5M < 0.6M - 2000$.")],
  check=_c34, values=[30000, 12000, 50000, 20000], cognitive="Analysis", exams=CX)


# ================================================================ DIFFICULT (11)

def _c35():
    M, C, x = symbols('M C x', positive=True)
    sol = solve([Eq(M * (1 - pct(25)) - C, 300),
                 Eq(M * (1 - pct(20)) - C, 480),
                 Eq(M * (1 - pct(10)) * (1 - x / 100), C * (1 + pct(8)))], [M, C, x], dict=True)
    sol = [s for s in sol if 0 < s[x] < 100]
    assert len(sol) == 1
    return sol[0][x]
q("C02-B-035", T_SD, "Unknown second successive discount after recovering marked and cost prices from two rupee profits", "Difficult",
  "Multi-step word problem",
  r"If a sofa is sold at a single discount of $25\%$ on its marked price, the seller makes a profit of Rs. $300$; at a single discount of $20\%$ on the marked price, the profit is Rs. $480$. If instead the sofa is sold at a discount of $10\%$ on the marked price followed by a second discount of $x\%$ on the reduced price, the seller makes a profit of $8\%$ on cost. What is the value of $x$?",
  "TITA",
  r"The two single-discount prices differ by $5\%$ of the marked price and by $480 - 300 = 180$ rupees, so $M = 3600$ and $C = 0.75 \times 3600 - 300 = 2400$. An $8\%$ profit means a final price of $1.08 \times 2400 = 2592$. After the first discount the price is $3240$, and $\frac{2592}{3240} = 0.8$, so the second discount is $20\%$ and $x = 20$.",
  r"Measuring the second discount on the marked price, or subtracting percentages.",
  "C02B-two-discount-scenarios", "Three stages: recover the marked price from two rupee profits, then the cost, then invert a successive discount on the reduced price.",
  tita_answer=20, check=_c35,
  tita_traps=[(18, r"Finds the overall discount $\frac{3600 - 2592}{3600} = 28\%$ and subtracts the first $10\%$."),
              (28, r"Reports the overall discount from the marked price instead of the second discount."),
              (2400, r"Stops at the cost price.")],
  cognitive="Analysis", exams=CX)


def _c36():
    items = [2000, 1500, 1400, 900, 600]
    best = None
    for groups in _bill_partitions(items):
        pay = 0
        for g in groups:
            amt = F(sum(g)) * (1 - pct(10))
            if amt >= 2800:
                amt -= 400
            pay += amt
        best = pay if best is None else min(best, pay)
    return best
q("C02-B-036", T_SD, "Splitting bills when the flat discount depends on the amount after a percentage discount", "Difficult",
  "Casework/optimisation",
  r"A store gives $10\%$ off on everything. In addition, any bill whose amount after the $10\%$ discount is at least Rs. $2{,}800$ gets a further Rs. $400$ off (one such reduction per bill). Kabir wants five items marked Rs. $2{,}000$, Rs. $1{,}500$, Rs. $1{,}400$, Rs. $900$ and Rs. $600$, and may split them into as many bills as he likes. What is the least total amount he must pay?",
  "MCQ",
  r"A bill qualifies only if its marked total is at least $\frac{2800}{0.9} \approx 3111$. The marked total is $6400$, so two qualifying bills need a split with both parts above $3111$, that is, parts between $3112$ and $3288$. The possible part sums near $3200$ are $2900$, $3000$, $3400$ and $3500$, so no such split exists. Only one bill can qualify: $6400 \times 0.9 - 400 = 5360$, that is Rs. $5{,}360$.",
  "Checking the threshold against the marked total instead of the discounted amount.",
  "C02B-split-bills-threshold", "A threshold on the discounted amount, and a partition argument showing two qualifying bills are impossible.",
  correct=r"Rs. $5{,}360$",
  distractors=[(r"Rs. $4{,}960$", r"Checks the Rs. $2{,}800$ threshold on marked totals, finds two qualifying bills (for example $3400$ and $3000$) and takes Rs. $800$ off $5760$."),
               (r"Rs. $5{,}400$", r"Takes the Rs. $400$ off the marked total before the $10\%$ discount: $(6400 - 400) \times 0.9$."),
               (r"Rs. $5{,}040$", r"Makes both slips: two reductions taken before the discount, $(6400 - 800) \times 0.9$.")],
  check=_c36, values=[5360, 4960, 5400, 5040], cognitive="Analysis", exams=CX)


def _c37():
    best = None
    for a in range(0, 4):
        for k in range(0, 41):
            if 12 * a + k >= 27:
                cost = 230 * a + 25 * (k - k // 5)
                best = cost if best is None else min(best, cost)
    return best
q("C02-B-037", T_SD, "Least cost for at least a given quantity using packs and a free-item offer", "Difficult",
  "Casework/optimisation",
  r"A shop sells pens loose at Rs. $25$ each, with the offer 'buy $4$, get $1$ free' on loose pens (for every $4$ loose pens paid for, one more is free). It also sells sealed packets of $12$ pens at Rs. $230$ per packet; the offer does not apply to packets. Priya needs at least $27$ pens. What is the least amount, in rupees, she must spend?",
  "TITA",
  r"Loose pens bought in fives cost $100$ for $5$, that is $20$ per pen; a packet costs $\frac{230}{12} \approx 19.2$ per pen. Two packets ($24$ pens, $460$) plus $3$ loose pens ($75$) cost $535$. One packet plus three fives ($12 + 15 = 27$ pens) costs $230 + 300 = 530$. No packets: $5$ fives and $2$ more pens cost $550$; three packets cost $690$. The least is $530$ rupees.",
  "Greedily buying as many of the cheapest-per-pen packets as possible.",
  "C02B-bundle-optimise", "The greedy choice fails; the leftover quantity decides the optimum.",
  tita_answer=530, check=_c37,
  tita_traps=[(535, r"Buys two packets greedily and pays for $3$ loose pens."),
              (550, r"Uses only loose pens with the offer.")],
  cognitive="Analysis", exams=CX)


def _c38():
    d, m = symbols('d m', positive=True)
    sols = solve([Eq(m * (1 - d), F(6, 5)), Eq(m * F(11, 10) * (1 - d - F(5, 100)), F(12375, 10000))], [d, m], dict=True)
    sols = [s for s in sols if 0 < s[d] < 1]
    assert len(sols) == 1
    return sols[0][d] * 100
q("C02-B-038", T_MP, "Original discount from the effect of raising both marked price and discount", "Difficult",
  "Inverse/parameter",
  r"A trader sells a lamp at a certain discount on its marked price and makes a profit of $20\%$ on cost. Had he marked the lamp $10\%$ higher and given a discount larger by $5$ percentage points, his profit would have been $23.75\%$ on cost. What was the original discount, in percent?",
  "TITA",
  r"Let the marked price be $mC$ and the discount $d$. Then $m(1 - d) = 1.2$ and $1.1m(0.95 - d) = 1.2375$. Dividing, $\frac{1.1(0.95 - d)}{1 - d} = \frac{1.2375}{1.2} = 1.03125$, so $1.045 - 1.1d = 1.03125 - 1.03125d$, giving $0.06875d = 0.01375$ and $d = 0.2$. The original discount was $20\%$ (with a $50\%$ mark-up).",
  "Solving for the mark-up and reporting it, or reporting the new discount.",
  "C02B-markup-discount-perturbation", "Two scenarios with two unknowns; the ratio of the equations removes the mark-up.",
  tita_answer=20, check=_c38,
  tita_traps=[(50, r"Reports the mark-up percentage instead of the discount."),
              (25, r"Reports the new, larger discount.")],
  cognitive="Analysis", exams=CX)


def _c39():
    C = 1
    M = C * (1 + pct(50))
    paid_price = M * (1 - pct(10))
    n = 1
    while n * paid_price < (1 + pct(20)) * C * (n + 1):
        n += 1
    return n
q("C02-B-039", T_SD, "Smallest n in a buy-n-get-1-free offer that keeps a profit target", "Difficult",
  "Inverse/parameter",
  r"A shop marks its candles $50\%$ above cost and gives $10\%$ off the marked price on every candle paid for. It also wants to add the offer 'buy $n$, get $1$ free'. For the shop's profit on each such deal ($n$ candles paid for, $n + 1$ handed over) to be at least $20\%$ of the cost of all candles handed over, what is the smallest possible value of $n$?",
  "MCQ",
  r"Each paid candle brings $1.5 \times 0.9 = 1.35$ (cost $1$ per candle). We need $1.35n \ge 1.2(n + 1)$, that is $0.15n \ge 1.2$, so $n \ge 8$. At $n = 8$ the profit is exactly $20\%$, so the smallest value is $8$.",
  r"Ignoring the $10\%$ discount, or measuring the profit against the revenue.",
  "C02B-buy-get-free-seller-profit", "A linear inequality in $n$ built from three percentage effects; several base errors are tempting.",
  correct=r"$8$",
  distractors=[(r"$9$", r"Counts all candles handed over, $n + 1 = 9$, as the answer."),
               (r"$4$", r"Ignores the $10\%$ discount: $1.5n \ge 1.2(n + 1)$ gives $n \ge 4$."),
               (r"$13$", r"Takes the $20\%$ profit on revenue: $0.8 \times 1.35n \ge n + 1$ gives $n \ge 12.5$.")],
  check=_c39, values=[8, 9, 4, 13], cognitive="Analysis", exams=CX)


def _c40():
    M = 30000
    p = M * (1 - pct(12))
    p -= min(p * pct(10), 2000)
    qq = M * (1 - pct(12)) * (1 - pct(7))
    r = M * (1 - pct(5)) - 4150  # flat reduction on the reduced price
    s = M * (1 - pct(20)) + 1600
    costs = [r, p, qq, s]
    assert min(costs) == r and costs.count(r) == 1
    return r
q("C02-B-040", T_SD, "Choosing the cheapest of four phone offers involving a cap, a fee and a flat reduction", "Difficult",
  "Casework/optimisation",
  r"A phone is marked Rs. $30{,}000$. Four stores offer it on different terms. The effective cost is the amount paid, minus any cashback received, plus any fee charged. Which offer gives the lowest effective cost?",
  "MCQ",
  r"Cashback offer: $26400$, and $10\%$ of it is $2640$, capped at $2000$, giving $24400$. Successive $12\%$ and $7\%$: $30000 \times 0.88 \times 0.93 = 24552$. Flat-reduction offer: $28500 - 4150 = 24350$. Fee offer: $24000 + 1600 = 25600$. The offer of $5\%$ off followed by Rs. $4{,}150$ off is cheapest at Rs. $24{,}350$.",
  "Ignoring the cashback cap, adding successive discounts, or ignoring the fee.",
  "C02B-compare-offers", "Four offers with a different trap each; any single slip changes the winner.",
  correct=r"$5\%$ off, then a further flat Rs. $4{,}150$ off the reduced price",
  distractors=[(r"$12\%$ off, then $10\%$ cashback (maximum Rs. $2{,}000$)", r"Ignores the cap and takes the full $2640$ cashback, getting $23760$."),
               (r"Successive discounts of $12\%$ and $7\%$", r"Adds the discounts to $19\%$, getting $24300$."),
               (r"$20\%$ off, with a processing fee of Rs. $1{,}600$", r"Ignores the fee and sees $24000$.")],
  check=_c40, values=[24350, 24400, 24552, 25600], cognitive="Analysis", exams=CX)


def _c41():
    C, p_, K = 4800, pct(20), 480
    target = C * (1 + p_)
    M = symbols('M', positive=True)
    found = []
    for capped in (False, True):
        paid = M * (1 - pct(20)) * (1 - pct(20))
        cb = K if capped else paid * pct(10)
        for m in solve(Eq(paid - cb, target), M):
            pv = m * F(64, 100)
            if (pv * pct(10) >= K) == capped:
                found.append(m)
    assert len(found) == 1
    return found[0]
q("C02-B-041", T_SD, "Marked price for a target profit when the seller funds a capped cashback after successive discounts", "Difficult",
  "Inverse/parameter",
  r"A dealer buys an air purifier for Rs. $4{,}800$. He sells it at successive discounts of $20\%$ and $20\%$ on the marked price, and he himself pays the buyer a cashback of $10\%$ of the amount paid, subject to a maximum cashback of Rs. $480$. At what marked price will his profit, after paying the cashback, be exactly $20\%$ on cost?",
  "MCQ",
  r"He must keep $1.2 \times 4800 = 5760$. The buyer pays $0.8 \times 0.8 = 0.64$ of the marked price $M$. If the cap did not bind, $0.64M \times 0.9 = 5760$ would give $M = 10000$, but then $10\%$ of $6400$ is $640$, above the cap. So the cap binds: $0.64M - 480 = 5760$, $M = 9750$. Check: the buyer pays $6240$, $10\%$ of which is $624 \ge 480$. The marked price is Rs. $9{,}750$.",
  "Ignoring the cap on the cashback, ignoring the cashback, or adding the successive discounts.",
  "C02B-markup-for-target", "Casework on whether the cap binds; the uncapped answer must be tested and rejected.",
  correct=r"Rs. $9{,}750$",
  distractors=[(r"Rs. $10{,}000$", r"Ignores the cap: $0.64M \times 0.9 = 5760$."),
               (r"Rs. $9{,}000$", r"Ignores the cashback: $0.64M = 5760$."),
               (r"Rs. $10{,}400$", r"Adds the discounts to $40\%$ and applies the cap: $0.6M - 480 = 5760$.")],
  check=_c41, values=[9750, 10000, 9000, 10400], cognitive="Analysis", exams=CX)


def _c42():
    items = [1450, 1050, 850, 450, 350]
    best = 0
    # each item: 0 = bill one, 1 = bill two, 2 = no cashback bill
    for labels in itertools.product(range(3), repeat=len(items)):
        cb = 0
        for b in (0, 1):
            amt = sum(it for it, l in zip(items, labels) if l == b)
            cb += min(F(amt, 10), 200)
        best = max(best, cb)
    return best
q("C02-B-042", T_SD, "Maximising capped cashback over two bills when no split reaches the cap twice", "Difficult",
  "Casework/optimisation",
  r"A card gives $10\%$ cashback on each bill, with a maximum of Rs. $200$ per bill, and only $2$ bills in a month earn cashback. Joseph must buy five items marked Rs. $1{,}450$, Rs. $1{,}050$, Rs. $850$, Rs. $450$ and Rs. $350$ this month, and may group them into bills as he likes (any items outside the $2$ cashback bills are paid for separately with no cashback). What is the largest total cashback he can earn?",
  "MCQ",
  r"Rs. $400$ needs two separate bills of at least Rs. $2{,}000$ each from a total of $4150$, so one of them would lie between $2000$ and $2150$; but no group of these items sums to anything in that range (the group sums nearest to it are $1900$ and $2250$). So at most one bill earns $200$, and the other earns $10\%$ of a total below $2000$, at most $190$ (from a group of $1900$, such as $1050 + 850$, leaving $1450 + 450 + 350 = 2250$ for the capped bill): $390$. If neither bill reaches $2000$, the cashback is at most $10\%$ of $1900 + 1900$, that is $380$. The largest cashback is Rs. $390$.",
  "Assuming both caps can be reached, ignoring the caps, or keeping both bills below the cap.",
  "C02B-split-bills-threshold", "Needs a proof that two capped bills are impossible, then an optimal capped-plus-uncapped split.",
  correct=r"Rs. $390$",
  distractors=[(r"Rs. $400$", r"Assumes two bills of at least Rs. $2{,}000$ can be formed and takes two full caps."),
               (r"Rs. $415$", r"Takes $10\%$ of the full Rs. $4{,}150$, ignoring the cap and the two-bill limit."),
               (r"Rs. $380$", r"Keeps both bills below Rs. $2{,}000$ to avoid the cap: $1900 + 1900$, cashback $190 + 190$.")],
  check=_c42, values=[390, 400, 415, 380], cognitive="Analysis", exams=CX)


def _c43():
    c = 1  # cost per gram
    normal_price = 500 * c * (1 + pct(60))
    offer_price = normal_price * (1 - pct(10))
    offer_cost = 600 * c
    return (offer_price - offer_cost) / offer_cost * 100
q("C02-B-043", T_SD, "Seller's profit when extra quantity and a discount are given together", "Difficult",
  "Multi-step word problem",
  r"A company normally sells a $500$ g jar of jam at its marked price, making a profit of $60\%$ on cost. In a promotion it sells a jar containing $20\%$ extra jam ($600$ g) at $10\%$ off the same marked price. Assume the cost of a jar of jam is proportional to the quantity of jam in it. What is the company's profit percentage on the promotional jar?",
  "MCQ",
  r"Let $500$ g cost $100$, so the marked price is $160$. The promotional jar sells for $160 \times 0.9 = 144$ and costs $120$. Profit $= \frac{24}{120} = 20\%$.",
  "Ignoring the extra quantity, or measuring the profit against the old cost.",
  "C02B-extra-quantity-offer", "The cost base changes with the extra quantity; three effects combine.",
  correct=r"$20\%$",
  distractors=[(r"$30\%$", r"Subtracts percentages: $60 - 20 - 10 = 30$."),
               (r"$44\%$", r"Ignores the extra jam: $1.6 \times 0.9 = 1.44$."),
               (r"$24\%$", r"Finds the profit of $24$ but divides by the old cost of $100$.")],
  check=_c43, values=[20, 30, 44, 24], cognitive="Analysis", exams=CX)


def _c44():
    items = [1500, 1200, 1000, 900, 800, 600]
    best = None
    for combo in itertools.combinations(range(6), 3):
        g1 = [items[i] for i in combo]
        g2 = [items[i] for i in range(6) if i not in combo]
        pay = sum(items) - min(g1) - min(g2)
        best = pay if best is None else min(best, pay)
    return best
q("C02-B-044", T_SD, "Grouping items to maximise a cheapest-item-free offer", "Difficult",
  "Casework/optimisation",
  r"A store's offer is 'buy $2$, get $1$ free': in every bill of exactly $3$ shirts, the cheapest shirt in that bill is free. Ravi buys six shirts marked Rs. $1{,}500$, Rs. $1{,}200$, Rs. $1{,}000$, Rs. $900$, Rs. $800$ and Rs. $600$, in two bills of $3$ shirts each, grouping them as he likes. What is the least total amount he can pay?",
  "MCQ",
  r"The Rs. $600$ shirt is the cheapest in whichever bill it is in, so it is always free. The other free shirt is the cheapest of the remaining bill, which is at most the third most expensive shirt, Rs. $1{,}000$. Grouping $\{1500, 1200, 1000\}$ and $\{900, 800, 600\}$ achieves this, so he pays $6000 - 1000 - 600 = 4400$, that is Rs. $4{,}400$.",
  "Spreading the expensive shirts across both bills, or treating the offer as a flat one-third off.",
  "C02B-cheapest-free-grouping", "Needs the insight that the costliest shirts should be grouped together, with a bounding argument.",
  correct=r"Rs. $4{,}400$",
  distractors=[(r"Rs. $4{,}600$", r"Spreads the expensive shirts, for example $\{1500, 1000, 800\}$ and $\{1200, 900, 600\}$, freeing only $800 + 600$."),
               (r"Rs. $4{,}000$", r"Treats 'buy $2$, get $1$ free' as one-third off the total of $6000$."),
               (r"Rs. $4{,}200$", r"Groups correctly but takes the Rs. $800$ shirt as free in the second bill, overlooking that the Rs. $600$ shirt is the cheapest there.")],
  check=_c44, values=[4400, 4600, 4000, 4200], cognitive="Analysis", exams=CX)


def _c45():
    M, d = symbols('M d', positive=True)
    C = 400
    sols = solve([Eq(M * (1 - d), C * (1 + d)), Eq(d * M - (M * (1 - d) - C), 40)], [M, d], dict=True)
    sols = [s for s in sols if 0 < s[d] < 1 and s[M] > C]
    assert len(sols) == 1
    return sols[0][M]
q("C02-B-045", T_MP, "Marked price when discount and profit percentages are equal and their rupee amounts differ by a given sum", "Difficult",
  "Inverse/parameter",
  r"A bag costs a shopkeeper Rs. $400$. He sells it at a discount on its marked price such that his profit percentage on cost equals his discount percentage on the marked price. The discount, in rupees, is Rs. $40$ more than the profit, in rupees. What is the marked price of the bag, in rupees?",
  "TITA",
  r"Let the marked price be $M$ and the common rate $d$. Profit $= 400d$ and discount $= Md$, so $d(M - 400) = 40$. Also $M(1 - d) = 400(1 + d)$, so $M - 400 = d(M + 400)$. Hence $(M - 400)^2 = 40(M + 400)$, that is $M^2 - 840M + 144000 = 0 = (M - 600)(M - 240)$. Since $M > 400$, $M = 600$ (rate $20\%$: discount $120$, profit $80$).",
  "Adding Rs. $40$ to the cost, or keeping the root below the cost price.",
  "C02B-mp-cp-ratio", "Two conditions give a quadratic in the marked price; one root must be rejected.",
  tita_answer=600, check=_c45,
  tita_traps=[(440, r"Takes the marked price as the cost plus Rs. $40$."),
              (240, r"Keeps the other root of the quadratic, which lies below the cost price.")],
  cognitive="Analysis", exams=CX)
