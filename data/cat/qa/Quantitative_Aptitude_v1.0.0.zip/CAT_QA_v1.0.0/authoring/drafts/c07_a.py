import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Work and efficiency"
CX = ("CAT", "XAT")


def _sim(rate_on_day, total=Fraction(1), maxdays=100000):
    """Day-by-day simulation. rate_on_day(d) is the work done on full day d (d = 0, 1, 2, ...).
    Returns the exact time (in days) at which the cumulative work reaches total."""
    done = Fraction(0)
    for d in range(maxdays):
        r = Fraction(rate_on_day(d))
        if r > 0 and done + r >= total:
            return d + (total - done) / r
        done += r
    raise RuntimeError("not finished")


def _pos(sol):
    return [s for s in sol if s > 0]


# ---------------------------------------------------------------- EASY

def _c1():
    t = _sim(lambda d: Fraction(1, 12) + Fraction(1, 18))
    return t * 60  # minutes
q("C07-A-001", T, "Combined time of two workers from their individual times", "Easy",
  "Single-step computation",
  r"Meera can paint a fence alone in $12$ hours and Kabir can paint the same fence alone in $18$ hours. If they work together from the start, how long will they take to paint the fence?",
  "MCQ",
  r"Take the work as $36$ units (LCM of $12$ and $18$). Meera paints $3$ units per hour and Kabir $2$ units per hour, so together they paint $5$ units per hour. Time $= \frac{36}{5} = 7.2$ hours, that is $7$ hours $12$ minutes.",
  "Averaging or adding the individual times instead of adding the rates.",
  "C07A-combined-from-individual-times", "One idea: add the hourly rates.",
  correct=r"$7$ hours $12$ minutes",
  distractors=[(r"$14$ hours $24$ minutes", "Takes the harmonic mean $\\frac{2 \\times 12 \\times 18}{30} = 14.4$ hours as the joint time, which is the time each would need if both were equally fast."),
               (r"$15$ hours", "Takes the arithmetic mean of $12$ and $18$ hours."),
               (r"$6$ hours", "Subtracts the times: $18 - 12 = 6$.")],
  check=_c1, values=[432, 864, 900, 360], cognitive="Application")


def _c2():
    return _sim(lambda d: Fraction(1, 9) + Fraction(1, 12) + Fraction(1, 18))
q("C07-A-002", T, "Combined time of three machines from their individual times", "Easy",
  "Single-step computation",
  r"Three printing machines can each print a batch of booklets alone in $9$ hours, $12$ hours and $18$ hours respectively. If all three machines run together from the start, in how many hours will the batch be printed? (Enter the number of hours.)",
  "TITA",
  r"Take the batch as $36$ units. The machines print $4$, $3$ and $2$ units per hour, a total of $9$ units per hour. Time $= \frac{36}{9} = 4$ hours.",
  "Averaging the times of the machines instead of adding their rates.",
  "C07A-combined-from-individual-times", "Direct sum of three rates using the LCM.",
  tita_answer=4, check=_c2,
  tita_traps=[(13, "Takes the arithmetic mean of $9$, $12$ and $18$."), (39, "Adds the three times.")],
  cognitive="Application")


def _c3():
    r = Fraction(1, 30)
    a = r * Fraction(3, 2)  # 50% more efficient
    return _sim(lambda d: r + a)
q("C07-A-003", T, "Percentage efficiency converted to time, then combined", "Easy",
  "Multi-step word problem",
  r"Arjun is $50\%$ more efficient than Ravi. Ravi alone can finish a piece of work in $30$ days. In how many days can Arjun and Ravi together finish the work?",
  "MCQ",
  r"Efficiency ratio Arjun : Ravi $= 3 : 2$, so Arjun needs $30 \times \frac{2}{3} = 20$ days. Taking the work as $60$ units, Arjun does $3$ and Ravi $2$ units a day, $5$ together. Time $= \frac{60}{5} = 12$ days.",
  "Treating 50% more efficient as taking 50% less time.",
  "C07A-efficiency-ratio-to-time", "One conversion from efficiency to time, then a combined rate.",
  correct=r"$12$ days",
  distractors=[(r"$10$ days", "Reads $50\\%$ more efficient as $50\\%$ less time, so Arjun takes $15$ days and together $\\frac{1}{\\frac{1}{30}+\\frac{1}{15}} = 10$ days."),
               (r"$18$ days", "Inverts the relation, making Arjun take $45$ days; together $\\frac{1}{\\frac{1}{30}+\\frac{1}{45}} = 18$ days."),
               (r"$20$ days", "Stops at Arjun's time alone.")],
  check=_c3, values=[12, 10, 18, 20], cognitive="Application")


def _c4():
    s = symbols('s', positive=True)
    return _pos(solve(Eq(Rational(1, 15) + 1 / s, Rational(1, 10)), s))[0]
q("C07-A-004", T, "Finding one worker's time from the joint time and the partner's time", "Easy",
  "Inverse/parameter",
  r"Priya and Sneha together can type a manuscript in $10$ hours. Priya alone can type it in $15$ hours. In how many hours can Sneha alone type the manuscript? (Enter the number of hours.)",
  "TITA",
  r"Take the work as $30$ units. Together they type $3$ units per hour and Priya alone $2$ units per hour, so Sneha types $1$ unit per hour. Sneha needs $30$ hours.",
  "Subtracting the times instead of the rates.",
  "C07A-find-partner-from-joint-time", "One subtraction of rates.",
  tita_answer=30, check=_c4,
  tita_traps=[(5, "Subtracts times: $15 - 10$."), (25, "Adds times: $15 + 10$.")],
  cognitive="Application")


def _c5():
    s = symbols('s', positive=True)
    return _pos(solve(Eq(Rational(1, 12) + Rational(1, 18) + 1 / s, Rational(1, 6)), s))[0]
q("C07-A-005", T, "Third worker's time from the joint time of three and two individual times", "Easy",
  "Inverse/parameter",
  r"Arjun, Kabir and Ravi together can complete a job in $6$ days. Arjun alone can complete it in $12$ days and Kabir alone in $18$ days. In how many days can Ravi alone complete the job?",
  "MCQ",
  r"Take the job as $36$ units. All three together do $6$ units a day, Arjun $3$ and Kabir $2$, so Ravi does $6 - 3 - 2 = 1$ unit a day. Ravi needs $36$ days.",
  "Subtracting only one partner's rate, or assuming the three share the job equally.",
  "C07A-find-partner-from-joint-time", "One subtraction of rates, with three workers.",
  correct=r"$36$ days",
  distractors=[(r"$12$ days", "Subtracts only Arjun's rate: $\\frac{1}{6} - \\frac{1}{12} = \\frac{1}{12}$."),
               (r"$9$ days", "Subtracts only Kabir's rate: $\\frac{1}{6} - \\frac{1}{18} = \\frac{1}{9}$."),
               (r"$18$ days", "Assumes the three share the job equally, so Ravi does $\\frac{1}{3}$ of it in $6$ days and would need $3 \\times 6 = 18$ days alone.")],
  check=_c5, values=[36, 12, 9, 18], cognitive="Application")


def _c6():
    j, f = Fraction(1, 20), Fraction(1, 30)
    t = _sim(lambda d: j if d < 8 else f)
    return t - 8
q("C07-A-006", T, "One worker does part of the job, the other finishes it", "Easy",
  "Multi-step word problem",
  r"Joseph can build a wall alone in $20$ days and Fatima can build it alone in $30$ days. Joseph works alone for $8$ days and then leaves; Fatima completes the rest of the wall alone. For how many days does Fatima work? (Enter the number of days.)",
  "TITA",
  r"In $8$ days Joseph builds $\frac{8}{20} = \frac{2}{5}$ of the wall. The remaining $\frac{3}{5}$ takes Fatima $\frac{3}{5} \times 30 = 18$ days.",
  "Subtracting days directly, or finding Fatima's time for Joseph's share.",
  "C07A-partial-work-then-finish", "Two short steps: fraction done, then time for the remainder.",
  tita_answer=18, check=_c6,
  tita_traps=[(22, "Subtracts days: $30 - 8$."), (12, "Computes Fatima's time for the $\\frac{2}{5}$ Joseph built.")],
  cognitive="Application")


def _c7():
    p = symbols('p', positive=True)
    return _pos(solve(Eq(Rational(5, 15) + 12 / p, 1), p))[0]
q("C07-A-007", T, "Second worker's time from the remainder they finished", "Easy",
  "Inverse/parameter",
  r"Kabir can finish a job alone in $15$ days. He works on it alone for $5$ days and then leaves. Priya, working alone, completes the remaining work in $12$ days. In how many days could Priya alone have done the whole job?",
  "MCQ",
  r"Kabir does $\frac{5}{15} = \frac{1}{3}$ of the job, so Priya does $\frac{2}{3}$ of it in $12$ days. The whole job takes her $12 \div \frac{2}{3} = 18$ days.",
  "Treating the days Priya worked as her time for the whole job, or using the wrong fraction.",
  "C07A-partial-work-then-finish", "Two steps: Kabir's fraction, then scale Priya's days.",
  correct=r"$18$ days",
  distractors=[(r"$12$ days", "Treats the $12$ days Priya worked as her time for the whole job."),
               (r"$36$ days", "Divides $12$ by Kabir's fraction $\\frac{1}{3}$ rather than by the remaining $\\frac{2}{3}$."),
               (r"$24$ days", "Assumes Kabir did half the job, so $12$ days is half of Priya's time.")],
  check=_c7, values=[18, 12, 36, 24], cognitive="Application")


def _c8():
    s, k = Fraction(1, 18), Fraction(1, 27)
    return _sim(lambda d: s + k if d < 6 else k)
q("C07-A-008", T, "Two work together, one leaves after a fixed number of days", "Easy",
  "Multi-step word problem",
  r"Sneha can complete a project alone in $18$ days and Kabir alone in $27$ days. They start together, and after $6$ days Sneha leaves. Kabir completes the remaining work alone. In how many days, from the start, is the project completed?",
  "MCQ",
  r"Take the project as $54$ units: Sneha does $3$ and Kabir $2$ units a day. In $6$ days together they do $30$ units, leaving $24$ units, which Kabir does in $12$ days. Total $= 6 + 12 = 18$ days.",
  "Reporting only Kabir's extra days or ignoring Sneha's work in the first phase.",
  "C07A-leaves-after-fixed-days", "Two phases with an LCM unit; one trap of reporting only the second phase.",
  correct=r"$18$ days",
  distractors=[(r"$12$ days", "Reports only the days Kabir works alone after Sneha leaves."),
               (r"$14$ days", "Lets Sneha (not Kabir) finish the remaining $\\frac{4}{9}$: $\\frac{4}{9} \\times 18 = 8$, total $14$."),
               (r"$27$ days", "Ignores Sneha's work in the first $6$ days: Kabir's $6$ days give $\\frac{2}{9}$, the remaining $\\frac{7}{9}$ takes $21$ days, total $27$.")],
  check=_c8, values=[18, 12, 14, 27], cognitive="Application")


def _c9():
    a, k = Fraction(1, 12), Fraction(1, 6)
    return _sim(lambda d: a if d % 2 == 0 else k)
q("C07-A-009", T, "Two workers on alternate days, job ends on a full cycle", "Easy",
  "Multi-step word problem",
  r"Arjun can finish a job alone in $12$ days and Kabir alone in $6$ days. They work on alternate days, with Arjun working on the first day, Kabir on the second, Arjun on the third, and so on; only one of them works on any day. In how many days is the job completed? (Enter the number of days.)",
  "TITA",
  r"Take the job as $12$ units: Arjun does $1$ unit and Kabir $2$ units a day. Every $2$-day cycle completes $3$ units, so $4$ cycles complete $12$ units in $8$ days.",
  "Treating alternate-day work as joint work.",
  "C07A-alternate-days-two-workers", "One cycle idea; the job ends exactly at the end of a cycle.",
  tita_answer=8, check=_c9,
  tita_traps=[(4, "Assumes they work together every day."), (9, "Takes the average of $12$ and $6$.")],
  cognitive="Application")


def _c10():
    k = Fraction(1, 12)
    a = Fraction(1, 8) - k          # Ananya's rate from the joint time
    t = _sim(lambda d: k + a)       # = 8 days
    return a * t                    # Ananya's share
q("C07-A-010", T, "Fraction of the job done by the helper in a joint effort", "Easy",
  "Conceptual/application",
  r"Kabir alone can complete a job in $12$ days. With Ananya helping him from the start, the two of them complete it in $8$ days. What fraction of the job is done by Ananya?",
  "MCQ",
  r"In $8$ days Kabir alone does $\frac{8}{12} = \frac{2}{3}$ of the job, because his rate does not change when Ananya helps. The rest, $\frac{1}{3}$, is Ananya's share.",
  "Assuming equal shares or reporting a daily rate instead of a share.",
  "C07A-share-of-work-done", "One idea: Kabir's share is his time worked over his solo time.",
  correct=r"$\frac{1}{3}$",
  distractors=[(r"$\frac{2}{3}$", "Reports Kabir's share."),
               (r"$\frac{1}{2}$", "Assumes they share the job equally because they worked the same days."),
               (r"$\frac{1}{24}$", "Reports Ananya's daily rate $\\frac{1}{8} - \\frac{1}{12} = \\frac{1}{24}$.")],
  check=_c10, values=[Rational(1, 3), Rational(2, 3), Rational(1, 2), Rational(1, 24)], cognitive="Understanding")


def _c11():
    t = symbols('t', positive=True)  # Fatima's time; Joseph takes 3t
    tf = _pos(solve(Eq(3 * t - t, 24), t))[0]
    return 1 / (1 / tf + 1 / (3 * tf))
q("C07-A-011", T, "Efficiency multiple and gap in solo times give the joint time", "Easy",
  "Conceptual/application",
  r"Fatima is three times as efficient as Joseph, and so she takes $24$ days fewer than Joseph to finish a certain job alone. In how many days can the two of them, working together, finish the job?",
  "MCQ",
  r"If Fatima takes $t$ days, Joseph takes $3t$ days, so $3t - t = 24$ and $t = 12$. Joseph takes $36$ days. Rates $\frac{1}{12} + \frac{1}{36} = \frac{4}{36} = \frac{1}{9}$, so together they need $9$ days.",
  "Splitting the 24-day gap by the efficiency ratio instead of finding each time.",
  "C07A-efficiency-multiple-and-time-gap", "Times are inversely proportional to efficiency; one linear step then a combined rate.",
  correct=r"$9$ days",
  distractors=[(r"$12$ days", "Stops at Fatima's time alone."),
               (r"$6$ days", "Divides the $24$-day gap by $3 + 1$."),
               (r"$36$ days", "Reports Joseph's time alone.")],
  check=_c11, values=[9, 12, 6, 36], cognitive="Application")


def _c12():
    k, m = Fraction(1, 24), Fraction(1, 12)
    return _sim(lambda d: k if d < 6 else k + m)
q("C07-A-012", T, "Second worker joins after a fixed number of days", "Easy",
  "Multi-step word problem",
  r"Kabir can finish a job alone in $24$ days and Meera alone in $12$ days. Kabir starts the job alone, and Meera joins him after $6$ days; they then work together until the job is finished. In how many days, from the start, is the job finished?",
  "MCQ",
  r"In $6$ days Kabir does $\frac{6}{24} = \frac{1}{4}$ of the job. Together they do $\frac{1}{24} + \frac{1}{12} = \frac{1}{8}$ a day, so the remaining $\frac{3}{4}$ takes $6$ days. Total $= 6 + 6 = 12$ days.",
  "Adding the full joint time to the head start, or reporting only the joint phase.",
  "C07A-joins-after-fixed-days", "Two phases; trap of adding the full joint time.",
  correct=r"$12$ days",
  distractors=[(r"$6$ days", "Reports only the days they work together."),
               (r"$14$ days", "Adds the full joint time of $8$ days to the $6$ days Kabir worked alone."),
               (r"$8$ days", "Gives the joint time as if both had started together.")],
  check=_c12, values=[12, 6, 14, 8], cognitive="Application")

# ---------------------------------------------------------------- MEDIUM

def _c13():
    s, p = symbols('s p', positive=True)
    sol = solve([Eq(3 * s, 5 * p), Eq(15 * (s + p), 1)], [s, p], dict=True)[0]
    return 1 / sol[s]
q("C07-A-013", T, "Equal-work statement gives the efficiency ratio; joint time gives individual time", "Medium",
  "Multi-step word problem",
  r"The amount of work Sneha does in $3$ days, Priya does in $5$ days. Working together, they finish a job in $15$ days. In how many days can Sneha alone finish the job?",
  "MCQ",
  r"Rates are inversely proportional to the days for equal work, so Sneha : Priya $= 5 : 3$. Together they do $8$ units a day for $15$ days, so the job is $120$ units. Sneha alone needs $\frac{120}{5} = 24$ days.",
  "Inverting the efficiency ratio or scaling the joint time by the ratio itself.",
  "C07A-efficiency-ratio-to-time", "Must convert an equal-work statement into a rate ratio, then use the joint time.",
  correct=r"$24$ days",
  distractors=[(r"$40$ days", "Inverts the ratio (or reports Priya's time): $\\frac{120}{3} = 40$."),
               (r"$25$ days", "Multiplies the joint time by $\\frac{5}{3}$ instead of $\\frac{8}{5}$."),
               (r"$30$ days", "Assumes equal efficiency, so each alone takes twice the joint time.")],
  check=_c13, values=[24, 40, 25, 30], cognitive="Application")


def _c14():
    f = Fraction(1)
    j = f * Fraction(80, 100)
    k = j * Fraction(125, 100)
    work = (f + k) * 16
    return work / j
q("C07-A-014", T, "Chained percentage efficiencies across three workers", "Medium",
  "Multi-step word problem",
  r"Kabir is $25\%$ more efficient than Joseph, and Joseph is $20\%$ less efficient than Fatima. Fatima and Kabir, working together, can finish a job in $16$ days. In how many days can Joseph alone finish the job? (Enter the number of days.)",
  "TITA",
  r"Let Fatima's daily work be $5$ units. Then Joseph does $0.8 \times 5 = 4$ units and Kabir $1.25 \times 4 = 5$ units. Fatima and Kabir do $10$ units a day, so the job is $160$ units. Joseph alone needs $\frac{160}{4} = 40$ days.",
  "Reporting Fatima's or Kabir's time, or chaining percentages on the wrong base.",
  "C07A-efficiency-ratio-to-time", "Two percentage links on different bases, then a joint rate.",
  tita_answer=40, check=_c14,
  tita_traps=[(32, "Reports Fatima's (equally Kabir's) time $\\frac{160}{5}$.")],
  cognitive="Application")


def _c15():
    r, m, k = symbols('r m k', positive=True)
    sol = solve([Eq(r + m, Rational(1, 10)), Eq(m + k, Rational(1, 12)), Eq(k + r, Rational(1, 15))], [r, m, k], dict=True)[0]
    return 1 / sol[k]
q("C07-A-015", T, "Individual time from three pairwise joint times", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera together can finish a job in $10$ days, Meera and Kabir together in $12$ days, and Kabir and Ravi together in $15$ days. In how many days can Kabir alone finish the job?",
  "MCQ",
  r"Take the job as $120$ units. The pairs do $12$, $10$ and $8$ units a day; adding counts each person twice, so $2(\text{all}) = 30$ and all three do $15$ units a day. Kabir $= 15 - (\text{Ravi} + \text{Meera}) = 15 - 12 = 3$ units a day, so Kabir needs $40$ days.",
  "Forgetting to halve the sum of pair rates, or subtracting the wrong pair.",
  "C07A-pairwise-times-lcm", "Needs the halving step and the right pair to subtract.",
  correct=r"$40$ days",
  distractors=[(r"$20$ days", "Computes $\\frac{1}{12} + \\frac{1}{15} - \\frac{1}{10}$, which is twice Kabir's rate, and treats it as Kabir's rate."),
               (r"$24$ days", "Subtracts the Meera and Kabir pair, obtaining Ravi's rate $15 - 10 = 5$ units, so $24$ days."),
               (r"$8$ days", "Stops at the time for all three together.")],
  check=_c15, values=[40, 20, 24, 8], cognitive="Application")


def _c16():
    p, qq, r = symbols('p q r', positive=True)
    sol = solve([Eq(p + qq, Rational(1, 10)), Eq(qq + r, Rational(1, 12)), Eq(p + qq + r, Rational(1, 8))], [p, qq, r], dict=True)[0]
    return 1 / (sol[p] + sol[r])
q("C07-A-016", T, "Time of an unlisted pair from two pairs and the trio", "Medium",
  "Multi-step word problem",
  r"Machines P and Q together can fill an order in $10$ hours, machines Q and R together in $12$ hours, and all three machines together in $8$ hours. In how many hours can machines P and R together fill the order? (Enter the number of hours.)",
  "TITA",
  r"Take the order as $120$ units. All three make $15$ units an hour, P and Q make $12$, Q and R make $10$. So R $= 15 - 12 = 3$ and P $= 15 - 10 = 5$ units an hour. P and R make $8$ units an hour and need $\frac{120}{8} = 15$ hours.",
  "Reporting a single machine's time or combining the given pair times directly.",
  "C07A-pairwise-times-lcm", "Two subtractions from the trio rate, then a new pair.",
  tita_answer=15, check=_c16,
  tita_traps=[(40, "Reports R's time alone."), (24, "Reports P's time alone.")],
  cognitive="Application")


def _c17():
    t = symbols('t', positive=True)
    return _pos(solve(Eq(t / 30 + (t - 3) / 15, 1), t))[0]
q("C07-A-017", T, "One worker leaves a fixed number of days before completion", "Medium",
  "Multi-step word problem",
  r"Harpreet can finish a job alone in $15$ days and Ananya alone in $30$ days. They start working together, but Harpreet leaves $3$ days before the job is finished, and Ananya works until the end. In how many days, from the start, is the job finished?",
  "MCQ",
  r"Let the job take $T$ days. Ananya works all $T$ days and Harpreet works $T - 3$ days: $\frac{T}{30} + \frac{T - 3}{15} = 1$, so $T + 2T - 6 = 30$ and $T = 12$ days.",
  "Reading 3 days before completion as after 3 days, or adding 3 to the joint time.",
  "C07A-leaves-before-completion", "Counting from the unknown end; easily misread as leaving after 3 days.",
  correct=r"$12$ days",
  distractors=[(r"$24$ days", "Reads it as Harpreet leaving after $3$ days: $3 \\times \\frac{1}{10} = \\frac{3}{10}$, then Ananya needs $21$ days, total $24$."),
               (r"$10$ days", "Ignores the departure and gives the joint time."),
               (r"$13$ days", "Adds $3$ days to the joint time of $10$ days.")],
  check=_c17, values=[12, 24, 10, 13], cognitive="Application")


def _c18():
    x = symbols('x', positive=True)
    return _pos(solve(Eq(Rational(10, 24) + (10 - x) / 12, 1), x))[0]
q("C07-A-018", T, "Find how early a worker left, given the total time", "Medium",
  "Inverse/parameter",
  r"Priya can complete a job alone in $12$ days and Sneha alone in $24$ days. They start together, Sneha works until the job is complete, and Priya leaves some days before completion. The job takes $10$ days in all. How many days before the completion of the job did Priya leave?",
  "MCQ",
  r"Sneha works all $10$ days and does $\frac{10}{24} = \frac{5}{12}$ of the job. Priya does the remaining $\frac{7}{12}$, which takes her $7$ days. So she leaves after day $7$, that is $10 - 7 = 3$ days before completion.",
  "Swapping the roles of the two workers or reporting the days Priya worked.",
  "C07A-leaves-before-completion", "Reverse problem: requires deciding who worked the full period.",
  correct=r"$3$ days",
  distractors=[(r"$6$ days", "Swaps the roles: lets Priya work all $10$ days and Sneha leave early."),
               (r"$7$ days", "Reports the number of days Priya worked."),
               (r"$2$ days", "Subtracts the joint time of $8$ days from $10$ days.")],
  check=_c18, values=[3, 6, 7, 2], cognitive="Analysis")


def _c19():
    r, m, k = Fraction(1, 30), Fraction(1, 20), Fraction(1, 12)
    return _sim(lambda d: r + (m if d >= 5 else 0) + (k if d >= 7 else 0))
q("C07-A-019", T, "Three workers joining one after another", "Medium",
  "Multi-step word problem",
  r"Ravi, Meera and Kabir can each finish a job alone in $30$, $20$ and $12$ days respectively. Ravi starts the job alone. Meera joins him after $5$ days, and Kabir joins them $2$ days after Meera joins. Once a person joins, he or she works until the job is finished. In how many days, from the start, is the job finished?",
  "MCQ",
  r"Take the job as $60$ units: Ravi does $2$, Meera $3$, Kabir $5$ units a day. First $5$ days: $10$ units. Next $2$ days (Ravi and Meera): $10$ units. The remaining $40$ units at $10$ units a day take $4$ days. Total $= 5 + 2 + 4 = 11$ days.",
  "Ignoring the staggered start, or adding the full trio time to the head start.",
  "C07A-joins-after-fixed-days", "Three phases with different teams.",
  correct=r"$11$ days",
  distractors=[(r"$6$ days", "Gives the time if all three worked together from the start."),
               (r"$4$ days", "Reports only the days all three worked together."),
               (r"$13$ days", "Adds the trio time of $6$ days to the $7$ days before Kabir joined, ignoring the $20$ units already done.")],
  check=_c19, values=[11, 6, 4, 13], cognitive="Application")


def _c20():
    a = Fraction(1, 18); m = a / 2
    t_together = _sim(lambda d: a + m)
    for x in range(0, 40):
        t = _sim(lambda d: m if d < x else a + m)
        if t - t_together == 6:
            return x
q("C07-A-020", T, "Delay in a helper joining from the extra time taken", "Medium",
  "Inverse/parameter",
  r"Arjun is twice as efficient as Meera, and Arjun alone can finish a job in $18$ days. Meera starts the job alone, and Arjun joins her after some days; from then on both work until the job is finished. The job is finished $6$ days later than it would have been had both worked together from the start. After how many days did Arjun join? (Enter the number of days.)",
  "TITA",
  r"Meera takes $36$ days and the two together take $12$ days. If Arjun joins after $x$ days, Meera does $\frac{x}{36}$ and the rest takes $\frac{1 - \frac{x}{36}}{\frac{1}{12}} = 12 - \frac{x}{3}$ days, so the total is $12 + \frac{2x}{3}$. Setting $\frac{2x}{3} = 6$ gives $x = 9$. (Quick view: each day Arjun is absent costs $\frac{2}{3}$ of a day, his share of the joint rate.)",
  "Equating the delay with the number of days Arjun was absent.",
  "C07A-joins-after-fixed-days", "Reverse problem; the delay is only a fraction of the absent days.",
  tita_answer=9, check=_c20,
  tita_traps=[(6, "Equates the $6$-day delay with the days Arjun was absent."), (18, "Reports the total time $12 + 6$.")],
  cognitive="Analysis")


def _c21():
    p, s = Fraction(1, 8), Fraction(1, 12)
    return _sim(lambda d: p if d % 2 == 0 else s)
q("C07-A-021", T, "Alternate days with a fractional final day", "Medium",
  "Multi-step word problem",
  r"Priya can finish a job alone in $8$ days and Sneha alone in $12$ days. They work on alternate days, Priya on the first day, Sneha on the second, and so on, with only one of them working on any day. In how many days is the job finished?",
  "MCQ",
  r"Take the job as $24$ units: Priya does $3$, Sneha $2$ units a day, so each $2$-day cycle does $5$ units. After $4$ cycles ($8$ days) $20$ units are done. Day $9$ (Priya) brings it to $23$ units. On day $10$ Sneha needs $1$ of her $2$ units, half a day. Total $9\frac{1}{2}$ days.",
  "Wrong person on the last day, wrong starter, or doubling the joint time.",
  "C07A-alternate-days-two-workers", "Cycle counting plus a careful last day.",
  correct=r"$9\frac{1}{2}$ days",
  distractors=[(r"$9\frac{2}{3}$ days", "Lets Sneha start: after $9$ days $22$ units, Priya then needs $\\frac{2}{3}$ of day $10$."),
               (r"$9\frac{3}{5}$ days", "Doubles the joint time $\\frac{24}{5} = 4\\frac{4}{5}$ days."),
               (r"$9\frac{1}{3}$ days", "Lets Priya also work day $10$, finishing the last unit in $\\frac{1}{3}$ of a day.")],
  check=_c21, values=[Fraction(19, 2), Fraction(29, 3), Fraction(48, 5), Fraction(28, 3)], cognitive="Application")


def _c22():
    rates = [Fraction(1, 10), Fraction(1, 15), Fraction(1, 20)]
    t = _sim(lambda d: rates[d % 3])
    return math.ceil(t)
q("C07-A-022", T, "Three workers in daily rotation: the day on which work ends", "Medium",
  "Multi-step word problem",
  r"Meera, Ravi and Kabir can each finish a job alone in $10$, $15$ and $20$ days respectively. They work one at a time in daily rotation: Meera on day $1$, Ravi on day $2$, Kabir on day $3$, Meera on day $4$, and so on. On which day is the job completed? (Enter the day number; for example, enter $3$ for day $3$.)",
  "TITA",
  r"Take the job as $60$ units: Meera $6$, Ravi $4$, Kabir $3$ units a day, $13$ units per $3$-day cycle. After $4$ cycles ($12$ days) $52$ units are done. Day $13$ (Meera) makes $58$. Ravi needs only $2$ more units on day $14$, so the job is completed on day $14$.",
  "Stopping at the end of the last full day before completion, or using the joint rate.",
  "C07A-rotation-three-workers", "Cycle counting with a partial cycle at the end.",
  tita_answer=14, check=_c22,
  tita_traps=[(13, "Assumes Meera's day $13$ completes the job."), (5, "Uses the joint rate: $\\frac{60}{13} \\approx 4.6$, so day $5$.")],
  cognitive="Application")


def _c23():
    rates = [Fraction(1, 6), Fraction(1, 8), Fraction(1, 12)]
    return _sim(lambda d: rates[d % 3])
q("C07-A-023", T, "Three workers in daily rotation: exact completion time", "Medium",
  "Multi-step word problem",
  r"Fatima, Joseph and Ananya can each finish a job alone in $6$, $8$ and $12$ days respectively. They work one at a time in daily rotation, in the order Fatima, Joseph, Ananya, Fatima, and so on, starting with Fatima on day $1$. In how many days is the job completed?",
  "MCQ",
  r"Take the job as $24$ units: Fatima $4$, Joseph $3$, Ananya $2$ units a day, $9$ per cycle. After $2$ cycles ($6$ days) $18$ units are done; day $7$ (Fatima) makes $22$. Joseph needs $2$ of his $3$ units on day $8$, that is $\frac{2}{3}$ of a day. Total $7\frac{2}{3}$ days.",
  "Wrong worker on the final day, reversed order, or counting the last partial day as full.",
  "C07A-rotation-three-workers", "Rotation with a fractional final day; order matters.",
  correct=r"$7\frac{2}{3}$ days",
  distractors=[(r"$7\frac{1}{2}$ days", "Puts Fatima on day $8$ as well: $\\frac{2}{4} = \\frac{1}{2}$."),
               (r"$8\frac{1}{4}$ days", "Uses the reverse order Ananya, Joseph, Fatima: $23$ units after $8$ days, Fatima needs $\\frac{1}{4}$ day."),
               (r"$8\frac{2}{3}$ days", "Adds the final $\\frac{2}{3}$ to $8$ full days rather than $7$.")],
  check=_c23, values=[Fraction(23, 3), Fraction(15, 2), Fraction(33, 4), Fraction(26, 3)], cognitive="Application")


def _c24():
    t = symbols('t', positive=True)
    return _pos(solve(Eq(1 / (t + 4) + 1 / (t + 16), 1 / t), t))[0]
q("C07-A-024", T, "Joint time from each worker's excess over the joint time", "Medium",
  "Conceptual/application",
  r"Working together, Joseph and Ananya finish a job in a certain number of days. Joseph alone would take $4$ days more than that, and Ananya alone would take $16$ days more than that. In how many days do they finish the job together?",
  "MCQ",
  r"If the joint time is $T$, then $\frac{1}{T+4} + \frac{1}{T+16} = \frac{1}{T}$. Cross-multiplying, $T(2T + 20) = (T+4)(T+16)$, so $T^2 = 64$ and $T = 8$ days. In general the joint time is the geometric mean of the two excesses: $\sqrt{4 \times 16} = 8$.",
  "Using the arithmetic mean, sum or difference of the excesses.",
  "C07A-excess-over-joint-time", "Needs the identity $T^2 = ab$ or a careful quadratic.",
  correct=r"$8$ days",
  distractors=[(r"$10$ days", "Takes the arithmetic mean of $4$ and $16$."),
               (r"$20$ days", "Adds the two excesses."),
               (r"$12$ days", "Takes the difference of the two excesses.")],
  check=_c24, values=[8, 10, 20, 12], cognitive="Understanding")


def _c25():
    t = symbols('t', positive=True)
    T0 = _pos(solve(Eq(1 / (t + 3) + 1 / (t + 27), 1 / t), t))[0]
    return T0 + 3
q("C07-A-025", T, "Individual time from excesses over the joint time", "Medium",
  "Conceptual/application",
  r"Two machines, P and Q, working together finish a task in a certain number of hours. Machine P alone takes $3$ hours more than that, and machine Q alone takes $27$ hours more than that. How many hours does machine P alone take to finish the task?",
  "MCQ",
  r"Let the joint time be $T$. Then $\frac{1}{T+3} + \frac{1}{T+27} = \frac{1}{T}$ simplifies to $T^2 = 3 \times 27 = 81$, so $T = 9$ hours. Machine P alone takes $9 + 3 = 12$ hours (and Q takes $36$ hours; check: $\frac{1}{12} + \frac{1}{36} = \frac{1}{9}$).",
  "Stopping at the joint time, or averaging the excesses.",
  "C07A-excess-over-joint-time", "Two steps: the product identity, then add the excess.",
  correct=r"$12$ hours",
  distractors=[(r"$9$ hours", "Stops at the joint time."),
               (r"$36$ hours", "Reports machine Q's time."),
               (r"$18$ hours", "Takes the joint time as the average excess $15$, then adds $3$.")],
  check=_c25, values=[12, 9, 36, 18], cognitive="Application")


def _c26():
    m, a = Fraction(1, 12), Fraction(1, 24)
    return _sim(lambda d: m if d < 3 else (a if d < 9 else m + a))
q("C07-A-026", T, "Each works alone in turn, then both finish together", "Medium",
  "Multi-step word problem",
  r"Meera can finish a job alone in $12$ days and Arjun alone in $24$ days. Meera works alone for the first $3$ days, then Arjun works alone for the next $6$ days, and after that the two work together until the job is finished. In how many days, from the start, is the job finished? (Enter the number of days.)",
  "TITA",
  r"Meera's $3$ days do $\frac{3}{12} = \frac{1}{4}$ and Arjun's $6$ days do $\frac{6}{24} = \frac{1}{4}$, leaving $\frac{1}{2}$. Together they do $\frac{1}{12} + \frac{1}{24} = \frac{1}{8}$ a day, so the half takes $4$ days. Total $= 3 + 6 + 4 = 13$ days.",
  "Adding the full joint time instead of the time for the remaining half.",
  "C07A-partial-work-then-finish", "Three phases; trap of using the full joint time.",
  tita_answer=13, check=_c26,
  tita_traps=[(17, "Adds the full joint time of $8$ days to the first $9$ days."), (4, "Reports only the joint phase.")],
  cognitive="Application")


def _c27():
    a, r, p = Fraction(1, 10), Fraction(1, 15), Fraction(1, 30)
    return _sim(lambda d: p + (a if d < 2 else 0) + (r if d < 4 else 0))
q("C07-A-027", T, "Three start together; two leave at different fixed times", "Medium",
  "Multi-step word problem",
  r"Arjun, Ravi and Priya can each finish a job alone in $10$, $15$ and $30$ days respectively. All three start together. Arjun leaves after $2$ days, Ravi leaves $2$ days after Arjun leaves, and Priya finishes the remaining work alone. In how many days, from the start, is the job finished?",
  "MCQ",
  r"Take the job as $30$ units: Arjun $3$, Ravi $2$, Priya $1$ unit a day. First $2$ days: $12$ units. Next $2$ days (Ravi and Priya): $6$ units, total $18$. Priya does the remaining $12$ units in $12$ days. Total $= 2 + 2 + 12 = 16$ days.",
  "Reporting only Priya's solo phase or keeping Ravi in the last phase.",
  "C07A-leaves-after-fixed-days", "Three phases with shrinking teams.",
  correct=r"$16$ days",
  distractors=[(r"$12$ days", "Reports only Priya's solo days."),
               (r"$5$ days", "Ignores the departures and gives the time for all three together."),
               (r"$8$ days", "Keeps Ravi working after day $4$: the remaining $12$ units at $3$ units a day take $4$ more days.")],
  check=_c27, values=[16, 12, 5, 8], cognitive="Application")


def _c28():
    r, p = Fraction(1, 12), Fraction(1, 18)
    # Ravi works the first 2 days; Priya stops 3 days before the finish; Joseph works throughout.
    # Search Joseph's solo time and Priya's stop day; keep the cases where Joseph's work equals the other two combined.
    found = []
    for t in range(1, 200):
        j = Fraction(1, t)
        for stop in range(2, 200):
            T = _sim(lambda d: j + (r if d < 2 else 0) + (p if d < stop else 0))
            if T - stop == 3 and j * T == 1 - j * T:
                found.append(t)
    assert len(found) == 1
    return found[0]
q("C07-A-028", T, "Unknown solo time of a worker from his share when one partner leaves early and another leaves before completion", "Difficult",
  "Inverse/parameter",
  r"Ravi and Priya can each finish a job alone in $12$ and $18$ days respectively. Ravi, Priya and Joseph start the job together. Ravi leaves after $2$ days, Priya leaves $3$ days before the job is finished, and Joseph works until the end. Joseph turns out to have done exactly as much of the job as Ravi and Priya together. In how many days can Joseph alone finish the whole job?",
  "MCQ",
  r"Joseph does half the job, so Ravi and Priya together do the other half. Ravi does $\frac{2}{12} = \frac{1}{6}$, so Priya does $\frac{1}{2} - \frac{1}{6} = \frac{1}{3}$, which takes her $\frac{1}{3} \times 18 = 6$ days. She leaves $3$ days before the end, so the job takes $6 + 3 = 9$ days. Joseph does half the job in $9$ days, so alone he needs $18$ days.",
  "Ignoring one of the departures when converting shares into days, or reporting the duration of the job instead of Joseph's solo time.",
  "C07A-share-of-work-done", "Works backwards through four linked stages: Joseph's share from the equality, Priya's share after removing Ravi's fixed part, the total time from her departure counted from the unknown finish, and finally Joseph's rate.",
  correct=r"$18$ days",
  distractors=[(r"$24$ days", r"Ignores Ravi's work, so Priya and Joseph each do half: Priya works $9$ days, the job takes $12$ days and Joseph's half in $12$ days means $24$ days alone."),
               (r"$12$ days", r"Finds Priya's $6$ days but forgets that she leaves $3$ days before the end, taking the job as $6$ days, so Joseph's half in $6$ days means $12$ days alone."),
               (r"$9$ days", r"Finds the duration of the job, $9$ days, and reports it as Joseph's solo time.")],
  check=_c28, values=[18, 24, 12, 9], cognitive="Analysis", exams=CX)


def _c29():
    t = symbols('t', positive=True)  # Joseph's time; Ravi 2t
    return _pos(solve(Eq(2 * t - 1 / (1 / t + 1 / (2 * t)), 16), t))[0]
q("C07-A-029", T, "Time ratio and the days saved by working together", "Medium",
  "Inverse/parameter",
  r"Ravi takes twice as long as Joseph to do a certain job alone. Working together, they finish the job $16$ days earlier than Ravi would working alone. In how many days can Joseph alone finish the job?",
  "MCQ",
  r"Let Joseph take $t$ days; Ravi takes $2t$. Together their rate is $\frac{1}{t} + \frac{1}{2t} = \frac{3}{2t}$, so they take $\frac{2t}{3}$ days. Then $2t - \frac{2t}{3} = \frac{4t}{3} = 16$, so $t = 12$ days.",
  "Stopping at the joint time or equating the saving with Joseph's time.",
  "C07A-efficiency-multiple-and-time-gap", "Reverse set-up linking a ratio of times to a saving.",
  correct=r"$12$ days",
  distractors=[(r"$8$ days", "Reports the joint time $\\frac{2t}{3}$."),
               (r"$24$ days", "Reports Ravi's time."),
               (r"$16$ days", "Equates the $16$ days saved with Joseph's time.")],
  check=_c29, values=[12, 8, 24, 16], cognitive="Application")


def _c30():
    p, s = symbols('p s', positive=True)
    sol = solve([Eq(4 * p + 6 * s, 1), Eq(6 * p + 3 * s, 1)], [p, s], dict=True)[0]
    return 1 / sol[s]
q("C07-A-030", T, "Two completion schedules give each worker's rate", "Medium",
  "Inverse/parameter",
  r"A job is completed if Priya works on it for $4$ days and Sneha for $6$ days. The same job is also completed if Priya works for $6$ days and Sneha for $3$ days. In how many days can Sneha alone complete the job? (Enter the number of days.)",
  "TITA",
  r"Comparing the schedules, $2$ extra days of Priya replace $3$ days of Sneha, so $1$ Priya-day $= 1.5$ Sneha-days. The first schedule is then $4 \times 1.5 + 6 = 12$ Sneha-days, so Sneha alone needs $12$ days (and Priya $8$ days).",
  "Reporting Priya's time or adding the days in one schedule.",
  "C07A-two-schedules-same-job", "Two linear equations; the exchange-rate view is the fast route.",
  tita_answer=12, check=_c30,
  tita_traps=[(8, "Reports Priya's time."), (9, "Adds the days of the second schedule.")],
  cognitive="Application")

# ---------------------------------------------------------------- DIFFICULT

def _c31():
    a, h, j = symbols('a h j', positive=True)
    sol = solve([Eq(a + h, Rational(1, 20)), Eq(h + j, Rational(1, 30)), Eq(j + a, Rational(1, 24))], [a, h, j], dict=True)[0]
    A, H, J = (Fraction(int(numer(sol[x])), int(denom(sol[x]))) for x in (a, h, j))
    return _sim(lambda d: J + (A if d < 8 else 0) + (H if d < 17 else 0))
q("C07-A-031", T, "Pairwise times, then a three-stage schedule with departures", "Difficult",
  "Multi-step word problem",
  r"Ananya and Harpreet together can finish a job in $20$ days, Harpreet and Joseph together in $30$ days, and Joseph and Ananya together in $24$ days. All three start the job together. After $8$ days Ananya leaves; after $9$ more days Harpreet leaves; Joseph completes the remaining work alone. In how many days, from the start, is the job completed? (Enter the number of days.)",
  "TITA",
  r"Take the job as $240$ units. Pair rates are $12$, $8$ and $10$ units a day; halving their sum gives the trio rate $15$. So Ananya $= 15 - 8 = 7$, Harpreet $= 15 - 10 = 5$, Joseph $= 15 - 12 = 3$. First $8$ days: $120$ units. Next $9$ days (Harpreet and Joseph): $72$ units, total $192$. Joseph does the last $48$ units in $16$ days. Total $= 8 + 9 + 16 = 33$ days.",
  "Not halving the sum of pair rates, or keeping Harpreet in the last stage.",
  "C07A-pairwise-times-lcm", "Individual rates from pair data, then three stages with different teams.",
  tita_answer=33, check=_c31, exams=CX,
  tita_traps=[(8, "Does not halve the pair sum, so the trio rate is $\\frac{1}{8}$ and the job seems done in $8$ days."), (23, "Lets Harpreet and Joseph finish everything after day $8$: $120 \\div 8 = 15$ more days.")],
  cognitive="Analysis")


def _c32():
    r, j = symbols('r j', positive=True)
    # Ravi first: R J R ... R on day 13, exactly done: 7r + 6j = 1
    # Joseph first: after 13 days 7j + 6r; day 14 is Ravi, half a day: 7j + 6r + r/2 = 1
    sol = solve([Eq(7 * r + 6 * j, 1), Eq(7 * j + 6 * r + r / 2, 1)], [r, j], dict=True)[0]
    R = Fraction(int(numer(sol[r])), int(denom(sol[r]))); J = Fraction(int(numer(sol[j])), int(denom(sol[j])))
    assert _sim(lambda d: R if d % 2 == 0 else J) == 13
    assert _sim(lambda d: J if d % 2 == 0 else R) == Fraction(27, 2)
    return 1 / (R + J)
q("C07-A-032", T, "Alternate-day completion times for both starting orders give the joint time", "Difficult",
  "Inverse/parameter",
  r"Ravi and Joseph work on a job on alternate days, only one of them working on any day. If Ravi works on the first day, the job is finished exactly at the end of the $13$th day. If Joseph works on the first day, the job takes $13\frac{1}{2}$ days. In how many days would Ravi and Joseph finish the job working together every day?",
  "MCQ",
  r"With Ravi first, Ravi works $7$ days and Joseph $6$: $7r + 6j = 1$. With Joseph first, after $13$ days Joseph has $7$ days and Ravi $6$, and Ravi finishes on half of day $14$: $7j + 6r + \frac{r}{2} = 1$. Equating, $7r + 6j = 7j + 6.5r$, so $j = \frac{r}{2}$. Then $10r = 1$, $r = \frac{1}{10}$, $j = \frac{1}{20}$, and together they take $\frac{1}{\frac{3}{20}} = 6\frac{2}{3}$ days.",
  "Halving the alternate-day time, or giving the final half day to the wrong person.",
  "C07A-alternate-days-two-workers", "Must model both orders, including who works the final half day.",
  correct=r"$6\frac{2}{3}$ days",
  distractors=[(r"$6\frac{1}{2}$ days", "Halves the $13$ days of the first schedule."),
               (r"$6\frac{3}{4}$ days", "Halves the $13\\frac{1}{2}$ days of the second schedule."),
               (r"$6\frac{3}{5}$ days", "Gives the final half day to Joseph: $7.5j + 6r = 1$ leads to $r = \\frac{1}{11}$, $j = \\frac{2}{33}$ and a joint time of $\\frac{33}{5}$.")],
  check=_c32, values=[Fraction(20, 3), Fraction(13, 2), Fraction(27, 4), Fraction(33, 5)], cognitive="Analysis", exams=CX)


def _c33():
    r, j = symbols('r j', positive=True)
    sol = solve([Eq(3 * (r + j) + 15 * r, 1), Eq(8 * (r + j) + 10 * j, 1)], [r, j], dict=True)[0]
    R = Fraction(int(numer(sol[r])), int(denom(sol[r]))); J = Fraction(int(numer(sol[j])), int(denom(sol[j])))
    assert _sim(lambda d: R + J if d < 3 else R) == 18
    assert _sim(lambda d: R + J if d < 8 else J) == 18
    return 1 / (sol[r] + sol[j])
q("C07-A-033", T, "Joint time from two finishing scenarios with different joint periods", "Difficult",
  "Inverse/parameter",
  r"Ravi and Joseph start a job together. If Joseph leaves after $3$ days, Ravi alone needs $15$ more days to finish the job. If instead the two work together for $8$ days and then Ravi leaves, Joseph alone needs $10$ more days to finish it. In how many days can Ravi and Joseph together finish the whole job?",
  "MCQ",
  r"Let Ravi and Joseph do $r$ and $j$ of the job a day. Ravi works $18$ days and Joseph $3$ in the first scenario; Ravi works $8$ days and Joseph $18$ in the second: $18r + 3j = 1$ and $8r + 18j = 1$. Six times the first gives $108r + 18j = 6$; subtracting the second, $100r = 5$, so $r = \frac{1}{20}$ and $j = \frac{1 - \frac{18}{20}}{3} = \frac{1}{30}$. The joint rate is $\frac{1}{20} + \frac{1}{30} = \frac{1}{12}$, so together they take $12$ days.",
  "Treating the leftover work as the same in both scenarios although the joint periods differ.",
  "C07A-two-schedules-same-job", "The joint periods differ, so the leftover work is not common to both scenarios and the familiar shortcut fails; a two-variable system with careful day counts is needed.",
  correct=r"$12$ days",
  distractors=[(r"$9$ days", "Treats the leftover as common: the leftover takes $\\frac{15 \\times 10}{15 + 10} = 6$ days together, plus the first $3$ days."),
               (r"$14$ days", "Treats the leftover as common: $6$ days together for the leftover, plus the $8$ days of the second scenario."),
               (r"$20$ days", "Reports Ravi's time alone.")],
  check=_c33, values=[12, 9, 14, 20], cognitive="Analysis", exams=CX)


def _c34():
    P, S = Fraction(1, 9), Fraction(1, 12)
    target = Fraction(39, 4)

    def finish(first, k):
        # alternate days until Sneha has worked k days, then Priya every day
        done, d, sk = Fraction(0), 0, 0
        while True:
            if sk < k:
                who = first if d % 2 == 0 else ("S" if first == "P" else "P")
            else:
                who = "P"
            r = P if who == "P" else S
            if done + r >= 1:
                return None if sk < k else d + (1 - done) / r
            done += r; d += 1
            if who == "S":
                sk += 1
    ks = {k for first in "PS" for k in range(1, 20) if finish(first, k) == target}
    assert len(ks) == 1
    return ks.pop()
q("C07-A-034", T, "Alternate-day work until one worker quits; days worked from the total time", "Medium",
  "Conceptual/application",
  r"Priya can finish a job alone in $9$ days and Sneha alone in $12$ days. They work on it on alternate days, only one of them working on any day, and either of them may take the first day. At the end of one of her working days Sneha stops working on the job for good, and from the next day Priya works every day until the job is done. The job is finished $9\frac{3}{4}$ days after it was started. On how many days did Sneha work? (Enter the number of days.)",
  "TITA",
  r"Whoever starts, exactly one of them works at any moment until the end, so if Sneha worked $k$ days, Priya worked $9\frac{3}{4} - k$ days. Take the job as $36$ units: Priya does $4$ and Sneha $3$ units a day, so $4\left(9\frac{3}{4} - k\right) + 3k = 36$, that is $39 - k = 36$ and $k = 3$. (For example, with Priya first: Sneha works days $2, 4, 6$, and Priya works days $1, 3, 5, 7, 8, 9$ and $\frac{3}{4}$ of day $10$.)",
  "Treating the fractional final day as a full day, or thinking the starting order changes the answer.",
  "C07A-alternate-days-then-quit", "One insight (every elapsed day belongs to exactly one worker) replaces casework on the starter and on the quitting day.",
  tita_answer=3, check=_c34,
  tita_traps=[(4, "Treats the job as ending at the end of day $10$: $4(10 - k) + 3k = 36$ gives $k = 4$."),
              (5, "Assumes Sneha kept alternating for the whole $10$ calendar days, so she worked half of them.")],
  cognitive="Analysis")


def _c35():
    u = symbols('u', positive=True)  # Joseph's daily work; Kabir 1.25u
    U = _pos(solve(Eq(10 * u + 12 * Rational(5, 4) * u, 1), u))[0]
    J = Fraction(int(numer(U)), int(denom(U))); K = J * Fraction(5, 4)
    assert _sim(lambda d: (J if d < 10 else 0) + (K if d >= 4 else 0)) == 16
    return 1 / K
q("C07-A-035", T, "Late joining, early leaving and an efficiency percentage combined", "Difficult",
  "Inverse/parameter",
  r"Kabir is $25\%$ more efficient than Joseph. Joseph starts a job alone; Kabir joins him after $4$ days; Joseph leaves $6$ days before the job is finished, and Kabir works until the end. The whole job takes $16$ days. In how many days can Kabir alone finish the job? (Enter the number of days.)",
  "TITA",
  r"Joseph works days $1$ to $10$ ($10$ days) and Kabir works days $5$ to $16$ ($12$ days). Let Joseph do $4$ units a day; Kabir does $5$. Total work $= 10 \times 4 + 12 \times 5 = 100$ units. Kabir alone needs $\frac{100}{5} = 20$ days.",
  "Off-by-one in counting each worker's days, or reporting Joseph's time.",
  "C07A-join-late-leave-early", "Two boundary conditions counted from opposite ends plus an efficiency ratio.",
  tita_answer=20, check=_c35, exams=CX,
  tita_traps=[(25, "Reports Joseph's time alone."), (19, "Counts Kabir's days as $16 - 4 - 1 = 11$: work $= 40 + 55 = 95$ units.")],
  cognitive="Analysis")


def _c36():
    r, m, k = symbols('r m k', positive=True)
    sol = solve([Eq(3 * r, 2 * (m + k)), Eq(5 * m, 3 * (r + k)), Eq(9 * (r + m + k), 1)], [r, m, k], dict=True)[0]
    return 1 / sol[k]
q("C07-A-036", T, "Equal-work statements among three workers give individual times", "Difficult",
  "Inverse/parameter",
  r"The work Ravi does in $3$ days, Meera and Kabir together do in $2$ days. The work Meera does in $5$ days, Ravi and Kabir together do in $3$ days. All three working together finish a job in $9$ days. In how many days can Kabir alone finish the job? (Enter the number of days.)",
  "TITA",
  r"Let $s$ be the trio's daily rate. $3r = 2(s - r)$ gives $r = \frac{2s}{5}$; $5m = 3(s - m)$ gives $m = \frac{3s}{8}$. Then $k = s\left(1 - \frac{2}{5} - \frac{3}{8}\right) = \frac{9s}{40}$. With $s = \frac{1}{9}$, $k = \frac{1}{40}$, so Kabir alone needs $40$ days.",
  "Turning an equal-work statement into the wrong ratio, or reporting another worker's time.",
  "C07A-equal-work-statements-system", "Two non-obvious ratio statements must be turned into shares of the trio rate.",
  tita_answer=40, check=_c36, exams=CX,
  tita_traps=[(24, "Reports Meera's time alone."), (9, "Gives the trio's time.")],
  cognitive="Analysis")


def _c37():
    a = symbols('a', positive=True)
    return _pos(solve(Eq(6 / a + 12 / (a + 5), 1), a))[0]
q("C07-A-037", T, "Quadratic from a time gap with one worker leaving", "Difficult",
  "Inverse/parameter",
  r"Arjun alone takes $5$ days fewer than Meera alone to finish a job. They work together for $6$ days, after which Arjun leaves and Meera finishes the remaining work in $6$ more days. In how many days can Arjun alone finish the job?",
  "MCQ",
  r"Let Arjun take $a$ days and Meera $a + 5$. Arjun works $6$ days and Meera $12$: $\frac{6}{a} + \frac{12}{a+5} = 1$. So $6(a+5) + 12a = a(a+5)$, i.e. $a^2 - 13a - 30 = 0 = (a - 15)(a + 2)$. Hence $a = 15$ days (Meera $20$; check: $\frac{6}{15} + \frac{12}{20} = 1$).",
  "Counting only Meera's final 6 days, or reporting Meera's time.",
  "C07A-time-gap-quadratic-leaver", "Sets up a quadratic from the time gap with correct day counts for each worker.",
  correct=r"$15$ days",
  distractors=[(r"$20$ days", "Reports Meera's time alone."),
               (r"$10$ days", "Counts only Meera's last $6$ days: $\\frac{6}{a} + \\frac{6}{a+5} = 1$ gives $a = 10$."),
               (r"$12$ days", "Assumes each did half the job, so Arjun's $6$ days are half his time.")],
  check=_c37, values=[15, 20, 10, 12], cognitive="Analysis", exams=CX)


def _c38():
    k = symbols('k', positive=True)
    m, r = Rational(1, 8), Rational(1, 24)
    # days 1..11: Meera days 1,4,7,10; Ravi 2,5,8,11; Kabir 3,6,9
    K = _pos(solve(Eq(4 * m + 4 * r + 3 * k, 1), k))[0]
    rates = [Fraction(1, 8), Fraction(1, 24), Fraction(int(numer(K)), int(denom(K)))]
    assert _sim(lambda d: rates[d % 3]) == 11
    return 1 / K
q("C07-A-038", T, "Rotation ending mid-cycle gives the third worker's time", "Difficult",
  "Inverse/parameter",
  r"Meera, Ravi and Kabir work on a job one at a time in daily rotation: Meera on day $1$, Ravi on day $2$, Kabir on day $3$, Meera on day $4$, and so on. Meera alone could finish the job in $8$ days and Ravi alone in $24$ days. The job is finished exactly at the end of day $11$. In how many days could Kabir alone finish the job?",
  "MCQ",
  r"In $11$ days Meera works on days $1, 4, 7, 10$ and Ravi on days $2, 5, 8, 11$ (four days each), while Kabir works on days $3, 6, 9$ (three days). Meera does $\frac{4}{8} = \frac{1}{2}$ and Ravi $\frac{4}{24} = \frac{1}{6}$, so Kabir's three days do $\frac{1}{3}$ of the job. Kabir alone needs $9$ days.",
  "Miscounting each worker's days in the incomplete cycle.",
  "C07A-rotation-three-workers", "Counting days per worker in an incomplete cycle, then a reverse calculation.",
  correct=r"$9$ days",
  distractors=[(r"$12$ days", "Gives Kabir $4$ days as well: $4k = \\frac{1}{3}$."),
               (r"$8$ days", "Gives Ravi only $3$ days: $3k = 1 - \\frac{1}{2} - \\frac{1}{8} = \\frac{3}{8}$."),
               (r"$6$ days", "Leaves out Ravi's work: $3k = \\frac{1}{2}$.")],
  check=_c38, values=[9, 12, 8, 6], cognitive="Analysis", exams=CX)


def _c39():
    a, h = symbols('a h', positive=True)
    sol = solve([Eq(9 * a + 4 * h, 1), Eq(6 * (a + h), 1)], [a, h], dict=True)[0]
    A = Fraction(int(numer(sol[a])), int(denom(sol[a]))); H = Fraction(int(numer(sol[h])), int(denom(sol[h])))
    assert _sim(lambda d: A + (H if d % 2 == 1 else 0)) == 9
    return 1 / sol[h]
q("C07-A-039", T, "Helper on alternate days: individual time from two completion facts", "Difficult",
  "Inverse/parameter",
  r"Ananya works on a job every day, and Harpreet helps her only on the even-numbered days (day $2$, day $4$, and so on). Working this way, they finish the job exactly at the end of day $9$. Had both worked every day from the start, they would have finished it in $6$ days. In how many days can Harpreet alone finish the job?",
  "MCQ",
  r"In $9$ days Ananya works $9$ days and Harpreet $4$ days (days $2, 4, 6, 8$): $9a + 4h = 1$. Also $a + h = \frac{1}{6}$. Substituting, $9a + \frac{4}{6} - 4a = 1$, so $a = \frac{1}{15}$ and $h = \frac{1}{6} - \frac{1}{15} = \frac{1}{10}$. Harpreet alone needs $10$ days.",
  "Miscounting Harpreet's days in a 9-day span, or reporting Ananya's time.",
  "C07A-alternate-day-helper", "Day counting in an odd-length span plus a two-equation system.",
  correct=r"$10$ days",
  distractors=[(r"$15$ days", "Reports Ananya's time alone."),
               (r"$8$ days", "Counts $5$ days for Harpreet: $9a + 5h = 1$ gives $h = \\frac{1}{8}$."),
               (r"$9$ days", "Counts $4.5$ days for Harpreet: $9a + 4.5h = 1$ gives $h = \\frac{1}{9}$.")],
  check=_c39, values=[10, 15, 8, 9], cognitive="Analysis", exams=CX)


def _c40():
    t = symbols('t', positive=True)
    return _pos(solve(Eq(t / 60 + (t - 3) / 30 + (t - 4) / 20, 1), t))[0]
q("C07-A-040", T, "Two of three workers leave at different times before completion", "Difficult",
  "Multi-step word problem",
  r"Ravi, Joseph and Fatima can each finish a job alone in $20$, $30$ and $60$ days respectively. All three start together. Joseph leaves $3$ days before the job is finished and Ravi leaves $4$ days before it is finished; Fatima works until the end. In how many days, from the start, is the job finished?",
  "MCQ",
  r"Take the job as $60$ units: Ravi $3$, Joseph $2$, Fatima $1$ unit a day. If the job takes $T$ days, Fatima works $T$, Joseph $T - 3$, Ravi $T - 4$ days: $T + 2(T - 3) + 3(T - 4) = 60$, so $6T = 78$ and $T = 13$ days. (Check: $13 + 20 + 27 = 60$.)",
  "Ignoring the departures, adding the larger gap to the joint time, or a sign slip.",
  "C07A-leaves-before-completion", "Two departures counted back from an unknown end; several tempting shortcuts fail.",
  correct=r"$13$ days",
  distractors=[(r"$10$ days", "Ignores the departures and gives the joint time."),
               (r"$14$ days", "Adds the larger gap of $4$ days to the joint time."),
               (r"$7$ days", "Sign slip: $6T = 60 - 6 - 12 = 42$.")],
  check=_c40, values=[13, 10, 14, 7], cognitive="Analysis", exams=CX)
