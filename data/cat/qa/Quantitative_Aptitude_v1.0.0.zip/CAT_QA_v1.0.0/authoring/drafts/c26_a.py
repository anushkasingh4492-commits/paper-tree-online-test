import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from itertools import product as _prod, combinations as _comb, permutations as _perm

T = "Basic probability"
CX = ("CAT", "XAT")
F = Fraction


def _prob(space, cond):
    space = list(space)
    return F(sum(1 for s in space if cond(s)), len(space))


DICE = range(1, 7)
SUITS = "SHDC"
RANKS = list(range(1, 14))  # 1 = ace, 11 J, 12 Q, 13 K
DECK = [(r, s) for s in SUITS for r in RANKS]


def _red(c):
    return c[1] in "HD"


# 1
def _c1():
    return _prob(_prod("HT", repeat=4), lambda s: s.count("H") == 2)
q("C26-A-001", T, "Exactly two heads when four coins are tossed", "Easy",
  "Single-step computation",
  r"Kabir tosses four fair coins at the same time. What is the probability that he gets exactly two heads?",
  "MCQ",
  r"There are $2^4 = 16$ equally likely outcomes. Exactly two heads can occur in $\binom{4}{2} = 6$ ways (choose which two coins show heads). The probability is $\frac{6}{16} = \frac{3}{8}$.",
  "Treating the number of heads (0 to 4) as five equally likely outcomes, or counting only one arrangement of two heads.",
  r"C26A-coins-count-heads", "One binomial count over a $16$-outcome sample space.",
  correct=r"$\frac{3}{8}$",
  distractors=[(r"$\frac{1}{5}$", r"Treats the five head counts $0, 1, 2, 3, 4$ as equally likely outcomes."),
               (r"$\frac{11}{16}$", r"Finds at least two heads: $\frac{6 + 4 + 1}{16} = \frac{11}{16}$."),
               (r"$\frac{1}{16}$", r"Counts only one arrangement such as HHTT and ignores the $\binom{4}{2} = 6$ orders.")],
  check=_c1, values=[F(3, 8), F(1, 5), F(11, 16), F(1, 16)], cognitive="Application")

# 2
def _c2():
    from sympy import isprime
    return _prob(_prod(DICE, repeat=2), lambda s: isprime(s[0] + s[1]))
q("C26-A-002", T, "Sum of two dice is prime", "Easy",
  "Single-step computation",
  r"Priya rolls two fair six-sided dice. What is the probability that the sum of the two numbers shown is a prime number?",
  "MCQ",
  r"Of the $36$ equally likely ordered outcomes, the prime sums are $2$ ($1$ way), $3$ ($2$ ways), $5$ ($4$ ways), $7$ ($6$ ways) and $11$ ($2$ ways), a total of $15$. The probability is $\frac{15}{36} = \frac{5}{12}$.",
  "Treating the eleven possible sums as equally likely, or missing one of the prime sums.",
  "C26A-dice-sum", "Listing prime sums and counting ordered outcomes for each.",
  correct=r"$\frac{5}{12}$",
  distractors=[(r"$\frac{5}{11}$", r"Treats the $11$ sums $2$ to $12$ as equally likely; $5$ of them are prime."),
               (r"$\frac{13}{36}$", r"Misses the sum $11$: $1 + 2 + 4 + 6 = 13$ outcomes."),
               (r"$\frac{7}{18}$", r"Misses the sum $2$: $2 + 4 + 6 + 2 = 14$ outcomes, giving $\frac{14}{36}$.")],
  check=_c2, values=[F(5, 12), F(5, 11), F(13, 36), F(7, 18)], cognitive="Application")

# 3
def _c3():
    return _prob(_prod(DICE, repeat=2), lambda s: (s[0] * s[1]) % 2 == 0) * 100
q("C26-A-003", T, "Product of two dice is even, via the complement", "Easy",
  "Single-step computation",
  r"Joseph rolls two fair six-sided dice. If $p$ is the probability that the product of the two numbers shown is even, what is the value of $100p$?",
  "TITA",
  r"The product is odd only when both numbers are odd: $3 \times 3 = 9$ of the $36$ outcomes. So $p = 1 - \frac{9}{36} = \frac{3}{4}$ and $100p = 75$.",
  "Assuming an even product is as likely as an odd one, or requiring both numbers to be even.",
  "C26A-dice-parity", "One complementary count.",
  tita_answer=75, check=_c3, values=[75],
  tita_traps=[(50, "Assumes even and odd products are equally likely."),
              (25, r"Counts only outcomes where both numbers are even: $\frac{9}{36}$.")],
  cognitive="Application")

# 4
def _c4():
    return _prob(DECK, lambda c: c[0] >= 11 or c[1] == "S")
q("C26-A-004", T, "Single card is a face card or a spade", "Easy",
  "Single-step computation",
  r"A card is drawn at random from a well-shuffled standard deck of $52$ playing cards. What is the probability that it is a face card (jack, queen or king) or a spade?",
  "MCQ",
  r"There are $12$ face cards and $13$ spades, and $3$ cards (the spade jack, queen and king) are both. By inclusion and exclusion the favourable count is $12 + 13 - 3 = 22$, so the probability is $\frac{22}{52} = \frac{11}{26}$.",
  "Adding the two counts without removing the three cards that are both a face card and a spade.",
  "C26A-cards-single-union", "One inclusion and exclusion step on a single draw.",
  correct=r"$\frac{11}{26}$",
  distractors=[(r"$\frac{25}{52}$", r"Adds $12 + 13$ and does not subtract the $3$ spade face cards."),
               (r"$\frac{3}{13}$", r"Counts only the $12$ face cards."),
               (r"$\frac{19}{52}$", r"Leaves out the $3$ spade face cards altogether: $9 + 10 = 19$.")],
  check=_c4, values=[F(11, 26), F(25, 52), F(3, 13), F(19, 52)], cognitive="Application")

# 5
def _c5():
    bag = ["R"] * 5 + ["B"] * 3
    return _prob(_comb(range(8), 2), lambda s: bag[s[0]] == bag[s[1]])
q("C26-A-005", T, "Two balls drawn together are of the same colour", "Easy",
  "Single-step computation",
  r"A bag contains $5$ red balls and $3$ blue balls. Fatima draws two balls at random at the same time. What is the probability that both balls are of the same colour?",
  "MCQ",
  r"There are $\binom{8}{2} = 28$ equally likely pairs. Both red: $\binom{5}{2} = 10$; both blue: $\binom{3}{2} = 3$. The probability is $\frac{10 + 3}{28} = \frac{13}{28}$.",
  "Treating the draw as if the first ball were replaced, or counting only one colour.",
  "C26A-bag-colour-draw", "Two combination counts added over one sample space.",
  correct=r"$\frac{13}{28}$",
  distractors=[(r"$\frac{17}{32}$", r"Treats the draw as with replacement: $\frac{25 + 9}{64} = \frac{34}{64}$."),
               (r"$\frac{5}{14}$", r"Counts only the pairs that are both red: $\frac{10}{28}$."),
               (r"$\frac{15}{28}$", r"Finds the probability of different colours, $\frac{5 \times 3}{28}$.")],
  check=_c5, values=[F(13, 28), F(17, 32), F(5, 14), F(15, 28)], cognitive="Application")

# 6
def _c6():
    people = ["Ravi", "Meera", "p3", "p4", "p5", "p6"]
    return _prob(_comb(people, 3), lambda s: "Ravi" in s and "Meera" in s) * 100
q("C26-A-006", T, "Two specified people both included in a random selection", "Easy",
  "Single-step computation",
  r"Six students, including Ravi and Meera, have applied for a quiz team of three. The three members are chosen at random from the six. If $p$ is the probability that both Ravi and Meera are chosen, what is the value of $100p$?",
  "TITA",
  r"There are $\binom{6}{3} = 20$ equally likely teams. A team containing both Ravi and Meera needs one more member from the remaining $4$, so there are $4$ such teams. Thus $p = \frac{4}{20} = \frac{1}{5}$ and $100p = 20$.",
  "Multiplying the separate chances of Ravi and Meera as though the two selections were independent.",
  "C26A-selection-specific-members", "Fix the two required members and choose the rest.",
  tita_answer=20, check=_c6, values=[20],
  tita_traps=[(25, r"Multiplies $P(\text{Ravi}) = \frac{1}{2}$ by $P(\text{Meera}) = \frac{1}{2}$ as if independent."),
              (50, r"Finds only the probability that Ravi is chosen, $\frac{3}{6}$.")],
  cognitive="Application")

# 7
def _c7():
    return _prob(range(1, 101), lambda n: n % 4 == 0 or n % 6 == 0)
q("C26-A-007", T, "Random integer divisible by 4 or by 6", "Easy",
  "Single-step computation",
  r"An integer is chosen at random from $1$ to $100$, both inclusive. What is the probability that it is divisible by $4$ or by $6$?",
  "MCQ",
  r"Multiples of $4$: $25$. Multiples of $6$: $16$. Numbers divisible by both are multiples of $\text{lcm}(4, 6) = 12$: $8$. The favourable count is $25 + 16 - 8 = 33$, so the probability is $\frac{33}{100}$.",
  r"Taking the overlap as multiples of $4 \times 6 = 24$ instead of the lcm $12$, or not removing the overlap.",
  "C26A-numbers-divisibility-union", "Inclusion and exclusion with an lcm trap.",
  correct=r"$\frac{33}{100}$",
  distractors=[(r"$\frac{41}{100}$", r"Adds $25 + 16$ without removing the common multiples."),
               (r"$\frac{37}{100}$", r"Removes multiples of $24$ ($4$ of them) instead of multiples of $12$: $25 + 16 - 4$."),
               (r"$\frac{17}{100}$", r"Counts multiples of $4$ that are not multiples of $6$ only: $25 - 8$.")],
  check=_c7, values=[F(33, 100), F(41, 100), F(37, 100), F(17, 100)], cognitive="Application")

# 8
def _c8():
    ppl = ["Kabir", "Ananya", "x", "y", "z"]
    return _prob(_perm(ppl), lambda p: abs(p.index("Kabir") - p.index("Ananya")) == 2) * 100
q("C26-A-008", T, "Two specified people seated with exactly one chair between them in a random row", "Easy",
  "Conceptual/application",
  r"Kabir, Ananya and three other friends take the five chairs in a row at random, one person per chair. If $p$ is the probability that exactly one chair lies between Kabir's chair and Ananya's chair, what is the value of $100p$?",
  "TITA",
  r"Fast route: Kabir and Ananya occupy one of the $\binom{5}{2} = 10$ equally likely pairs of chairs. Pairs with exactly one chair between them are (1, 3), (2, 4) and (3, 5), so $p = \frac{3}{10}$ and $100p = 30$. (Counting arrangements: $\frac{3 \times 2 \times 3!}{5!} = \frac{36}{120}$, the same.)",
  "Forgetting that the two people can swap seats, or answering for adjacent seats instead.",
  "C26A-arrangement-seat-gap", "One pair-of-seats count with a swap trap.",
  tita_answer=30, check=_c8, values=[30],
  tita_traps=[(15, r"Uses $\frac{3 \times 3!}{5!}$, forgetting that Kabir and Ananya can swap seats."),
              (40, "Finds the probability that they sit in adjacent chairs.")],
  cognitive="Understanding")

# 9
def _c9():
    g = symbols('g', positive=True, integer=True)
    return int(solve(Eq(Rational(6) / (6 + g), Rational(2, 5)), g)[0])
q("C26-A-009", T, "Number of balls of the other colour from a single-draw probability", "Easy",
  "Inverse/parameter",
  r"A bag contains only red and green balls, $6$ of which are red. When one ball is drawn at random, the probability that it is red is $\frac{2}{5}$. How many green balls are in the bag?",
  "TITA",
  r"If there are $g$ green balls, $\frac{6}{6 + g} = \frac{2}{5}$, so $6 + g = 15$ and $g = 9$.",
  r"Reporting the total number of balls, or reading $\frac{2}{5}$ as the chance of green.",
  "C26A-bag-inverse-count", "One linear equation from a single draw.",
  tita_answer=9, check=_c9, values=[9],
  tita_traps=[(15, "Reports the total number of balls."),
              (4, r"Treats $\frac{2}{5}$ as the chance of green, so red is $\frac{3}{5}$ of $10$ balls and green is $4$.")],
  cognitive="Application")

# 10
def _c10():
    return _prob(_comb(DECK, 2), lambda s: _red(s[0]) and _red(s[1]))
q("C26-A-010", T, "Two cards drawn together are both red", "Easy",
  "Single-step computation",
  r"Two cards are drawn together at random from a well-shuffled standard deck of $52$ playing cards. What is the probability that both cards are red?",
  "MCQ",
  r"The number of ways to choose $2$ red cards is $\binom{26}{2} = 325$ out of $\binom{52}{2} = 1326$. The probability is $\frac{325}{1326} = \frac{25}{102}$ (equivalently $\frac{26}{52} \times \frac{25}{51}$).",
  r"Treating the second card as drawn from a full deck, which gives $\frac{1}{4}$.",
  "C26A-cards-colour-draw", "One combination ratio; the trap is replacement.",
  correct=r"$\frac{25}{102}$",
  distractors=[(r"$\frac{1}{4}$", r"Treats the draws as with replacement: $\frac{1}{2} \times \frac{1}{2}$."),
               (r"$\frac{25}{104}$", r"Reduces the red count but not the deck: $\frac{26}{52} \times \frac{25}{52}$."),
               (r"$\frac{13}{51}$", r"Reduces the deck but not the red count: $\frac{26}{52} \times \frac{26}{51}$.")],
  check=_c10, values=[F(25, 102), F(1, 4), F(25, 104), F(13, 51)], cognitive="Application")

# 11
def _c11():
    return _prob(_prod("HT", repeat=5), lambda s: s.count("H") > s.count("T"))
q("C26-A-011", T, "More heads than tails in an odd number of tosses, by symmetry", "Easy",
  "Conceptual/application",
  r"Meera tosses a fair coin $5$ times. What is the probability that she gets more heads than tails?",
  "MCQ",
  r"With $5$ tosses a tie is impossible, so every outcome has either more heads or more tails. Swapping H and T in every toss pairs each outcome of the first kind with one of the second kind, so the two events are equally likely and the probability is $\frac{1}{2}$. (Check: $\frac{10 + 5 + 1}{32} = \frac{16}{32}$.)",
  "Counting only the outcome with exactly three heads, or forgetting the all-heads outcome.",
  "C26A-coins-count-heads", "Symmetry gives the answer at once; direct counting also works quickly.",
  correct=r"$\frac{1}{2}$",
  distractors=[(r"$\frac{5}{16}$", r"Counts only exactly $3$ heads: $\frac{10}{32}$."),
               (r"$\frac{15}{32}$", r"Counts $3$ or $4$ heads and misses $5$ heads: $\frac{10 + 5}{32}$."),
               (r"$\frac{11}{16}$", r"Computes $1 - P(\text{exactly } 2 \text{ heads}) = 1 - \frac{10}{32}$, overlooking that $0$ or $1$ heads also give more tails.")],
  check=_c11, values=[F(1, 2), F(5, 16), F(15, 32), F(11, 16)], cognitive="Understanding")

# 12
def _c12():
    sq = {k * k for k in range(1, 11)}
    cu = {k ** 3 for k in range(1, 6)}
    return _prob(range(10, 100), lambda n: n in sq or n in cu)
q("C26-A-012", T, "Random two-digit number is a perfect square or a perfect cube", "Easy",
  "Single-step computation",
  r"A two-digit number is chosen at random. What is the probability that it is a perfect square or a perfect cube?",
  "MCQ",
  r"There are $90$ two-digit numbers ($10$ to $99$). Squares: $16, 25, 36, 49, 64, 81$ ($6$). Cubes: $27, 64$ ($2$). The number $64$ is both, so the favourable count is $6 + 2 - 1 = 7$ and the probability is $\frac{7}{90}$.",
  r"Counting $64$ twice, or miscounting how many two-digit numbers there are.",
  "C26A-numbers-squares-cubes", "Small listing with one overlap.",
  correct=r"$\frac{7}{90}$",
  distractors=[(r"$\frac{4}{45}$", r"Counts $64$ twice: $\frac{8}{90}$."),
               (r"$\frac{1}{15}$", r"Counts only the $6$ squares: $\frac{6}{90}$."),
               (r"$\frac{7}{89}$", r"Takes the number of two-digit numbers as $99 - 10 = 89$.")],
  check=_c12, values=[F(7, 90), F(4, 45), F(1, 15), F(7, 89)], cognitive="Application")

# 13
def _c13():
    n = 1
    while F(sum(1 for k in range(1, n + 1) if int(k ** 0.5 + 0.5) ** 2 == k), n) >= F(1, 10):
        n += 1
    return n
q("C26-A-013", T, "Least range size for which a random integer is a perfect square with probability below one tenth", "Medium",
  "Inverse/parameter",
  r"An integer is chosen at random from $1, 2, 3, \ldots, n$. What is the least value of $n$ for which the probability that the chosen integer is a perfect square is less than $\frac{1}{10}$?",
  "TITA",
  r"If $k^2 \le n < (k+1)^2$, there are $k$ squares, and we need $\frac{k}{n} < \frac{1}{10}$, that is $n > 10k$. For $k \le 8$ the largest $n$ in the block is $(k+1)^2 - 1 = k^2 + 2k$, which is at most $10k$ (since $k \le 8$), so no $n$ works; for $n = 1, 2, 3$ the probability is at least $\frac{1}{3}$. For $k = 9$ ($81 \le n \le 99$) we need $n > 90$, so the least value is $n = 91$.",
  r"Treating the boundary $\frac{9}{90} = \frac{1}{10}$ as already below the threshold, or assuming the answer must exceed $100$.",
  "C26A-numbers-inverse-range", r"Block-by-block check of the count of squares against $\frac{n}{10}$.",
  tita_answer=91, check=_c13, values=[91],
  tita_traps=[(90, r"Uses $n = 90$, where the probability is exactly $\frac{9}{90} = \frac{1}{10}$, not less."),
              (101, r"Assumes the threshold is first crossed just after $100$, where $\frac{10}{101} < \frac{1}{10}$, missing $81 \le n \le 99$.")],
  cognitive="Analysis")

# 14
def _c14():
    r, w = symbols('r w', positive=True)
    s = solve([Eq(5 * r, 3 * w), Eq(r + 4, w)], [r, w], dict=True)[0]
    return int(s[r] + s[w])
q("C26-A-014", T, "Original bag size from odds before and after adding balls", "Medium",
  "Inverse/parameter",
  r"A bag contains only red and white balls. The odds in favour of drawing a red ball at random are $3 : 5$. When $4$ more red balls are added to the bag, the odds in favour of drawing a red ball become $1 : 1$. How many balls were in the bag originally?",
  "TITA",
  r"Odds in favour of red $3 : 5$ means red : white $= 3 : 5$; let them be $3k$ and $5k$. After adding $4$ red balls, $3k + 4 = 5k$, so $k = 2$: $6$ red and $10$ white. The bag originally held $16$ balls.",
  r"Treating odds $3 : 5$ as a probability of $\frac{3}{5}$, or reporting the count after the addition.",
  "C26A-odds-inverse", "Converting odds to a ratio of counts, then one linear equation.",
  tita_answer=16, check=_c14, values=[16],
  tita_traps=[(20, "Reports the number of balls after the $4$ red balls are added."),
              (6, "Reports only the number of red balls.")],
  cognitive="Application")

# 15
def _c15():
    return _prob(_prod(DICE, repeat=2), lambda s: max(s) == 5)
q("C26-A-015", T, "Larger of two dice equals a given value", "Medium",
  "Multi-step word problem",
  r"Two fair six-sided dice are rolled. What is the probability that the larger of the two numbers shown is $5$? (If both dice show the same number, that number is taken as the larger.)",
  "MCQ",
  r"The larger number is at most $5$ in $5^2 = 25$ outcomes and at most $4$ in $4^2 = 16$ outcomes. So it equals $5$ in $25 - 16 = 9$ outcomes, and the probability is $\frac{9}{36} = \frac{1}{4}$.",
  r"Forgetting the outcome $(5, 5)$ or counting each unordered pair once.",
  "C26A-dice-max-min", "Uses the at-most difference trick; direct listing has two traps.",
  correct=r"$\frac{1}{4}$",
  distractors=[(r"$\frac{2}{9}$", r"Counts $(5, x)$ and $(x, 5)$ for $x < 5$ but misses $(5, 5)$: $\frac{8}{36}$."),
               (r"$\frac{5}{36}$", r"Counts only outcomes with the first die showing $5$ and the second at most $5$."),
               (r"$\frac{25}{36}$", r"Finds the probability that the larger number is at most $5$.")],
  check=_c15, values=[F(1, 4), F(2, 9), F(5, 36), F(25, 36)], cognitive="Application")

# 16
def _c16():
    return _prob(_prod(DICE, repeat=3), lambda s: sum(s) <= 6)
q("C26-A-016", T, "Sum of three dice at most a given value", "Medium",
  "Multi-step word problem",
  r"Sneha rolls three fair six-sided dice. What is the probability that the total of the three numbers is at most $6$?",
  "MCQ",
  r"There are $6^3 = 216$ outcomes. Ordered triples of positive integers with sum $s$ number $\binom{s-1}{2}$, and no die can exceed $6$ here. Sums $3, 4, 5, 6$ give $1 + 3 + 6 + 10 = 20$ outcomes (equivalently $\binom{6}{3} = 20$). The probability is $\frac{20}{216} = \frac{5}{54}$.",
  "Treating the sixteen totals as equally likely, or counting unordered triples.",
  "C26A-dice-sum", "Needs ordered counting of compositions across four sums.",
  correct=r"$\frac{5}{54}$",
  distractors=[(r"$\frac{1}{4}$", r"Treats the $16$ totals $3$ to $18$ as equally likely; $4$ of them are at most $6$."),
               (r"$\frac{5}{108}$", r"Counts totals less than $6$ only: $\frac{1 + 3 + 6}{216}$."),
               (r"$\frac{7}{216}$", r"Counts unordered triples ($111, 112, 113, 122, 114, 123, 222$) as single outcomes.")],
  check=_c16, values=[F(5, 54), F(1, 4), F(5, 108), F(7, 216)], cognitive="Application")

# 17
def _c17():
    nonface = lambda c: c[0] <= 10
    return _prob(_comb(DECK, 2), lambda s: nonface(s[0]) and nonface(s[1]) and s[0][1] != s[1][1])
q("C26-A-017", T, "Two cards drawn together are non-face cards of different suits", "Medium",
  "Conceptual/application",
  r"Two cards are drawn together at random from a well-shuffled standard deck of $52$ playing cards. The face cards are the jacks, queens and kings. What is the probability that neither card is a face card and the two cards belong to different suits?",
  "MCQ",
  r"There are $52 - 12 = 40$ non-face cards, $10$ in each suit. Pairs of non-face cards: $\binom{40}{2} = 780$; of these, $4 \times \binom{10}{2} = 180$ are from the same suit, leaving $600$. The probability is $\frac{600}{1326} = \frac{100}{221}$. (Fixing the first card: $\frac{40}{52} \times \frac{30}{51}$, the same.)",
  r"Removing all same-suit pairs instead of only the non-face ones, or treating the second card as drawn from a full deck.",
  "C26A-cards-colour-draw", "Two conditions: restrict to non-face cards, then remove same-suit pairs within that restricted set.",
  correct=r"$\frac{100}{221}$",
  distractors=[(r"$\frac{75}{169}$", r"Treats the second card as drawn from the full deck: $\frac{40}{52} \times \frac{30}{52}$."),
               (r"$\frac{10}{17}$", r"Finds only that neither card is a face card, $\frac{780}{1326}$, and ignores the suit condition."),
               (r"$\frac{6}{17}$", r"Removes all $4 \times \binom{13}{2} = 312$ same-suit pairs from the $780$ non-face pairs: $\frac{468}{1326}$.")],
  check=_c17, values=[F(100, 221), F(75, 169), F(10, 17), F(6, 17)], cognitive="Analysis")

# 18
def _c18():
    return _prob(_comb(DECK, 3), lambda s: len({c[1] for c in s}) == 3)
q("C26-A-018", T, "Three cards drawn together are of three different suits", "Medium",
  "Multi-step word problem",
  r"Three cards are drawn together at random from a well-shuffled standard deck of $52$ playing cards. What is the probability that the three cards belong to three different suits?",
  "MCQ",
  r"Choose the three suits in $\binom{4}{3} = 4$ ways and one card from each in $13^3 = 2197$ ways: $8788$ selections. Total selections: $\binom{52}{3} = 22100$. The probability is $\frac{8788}{22100} = \frac{169}{425}$ (equivalently $\frac{39}{51} \times \frac{26}{50}$).",
  "Forgetting to choose which three suits appear, or treating the draws as with replacement.",
  "C26A-cards-colour-draw", "Choose suits, then one card per suit, over a three-card sample space.",
  correct=r"$\frac{169}{425}$",
  distractors=[(r"$\frac{3}{8}$", r"Treats the draws as with replacement: $1 \times \frac{3}{4} \times \frac{2}{4}$."),
               (r"$\frac{169}{1700}$", r"Forgets the $\binom{4}{3} = 4$ choices of suits: $\frac{2197}{22100}$."),
               (r"$\frac{22}{425}$", r"Finds the probability that all three are of one suit, $\frac{4 \times \binom{13}{3}}{22100}$.")],
  check=_c18, values=[F(169, 425), F(3, 8), F(169, 1700), F(22, 425)], cognitive="Application")

# 19
def _c19():
    bag = ["R"] * 4 + ["W"] * 3 + ["K"] * 5
    return _prob(_comb(range(12), 3), lambda s: len({bag[i] for i in s}) == 3)
q("C26-A-019", T, "Three balls drawn together are one of each colour", "Medium",
  "Multi-step word problem",
  r"A bag contains $4$ red, $3$ white and $5$ black balls. Harpreet draws three balls at random at the same time. What is the probability that she gets one ball of each colour?",
  "MCQ",
  r"Favourable selections: $4 \times 3 \times 5 = 60$. Total selections: $\binom{12}{3} = 220$. The probability is $\frac{60}{220} = \frac{3}{11}$.",
  "Mixing ordered and unordered counts, or treating the draw as with replacement.",
  "C26A-bag-colour-draw", "One product of counts against a combination total; order traps.",
  correct=r"$\frac{3}{11}$",
  distractors=[(r"$\frac{5}{24}$", r"Treats the draw as with replacement: $3! \times \frac{4 \times 3 \times 5}{12^3} = \frac{360}{1728}$."),
               (r"$\frac{1}{22}$", r"Divides the unordered count $60$ by the ordered total $12 \times 11 \times 10 = 1320$."),
               (r"$\frac{5}{144}$", r"Uses replacement and also omits the $3!$ orders: $\frac{60}{1728}$.")],
  check=_c19, values=[F(3, 11), F(5, 24), F(1, 22), F(5, 144)], cognitive="Application")

# 20
def _c20():
    res = []
    for r in range(6, 11):
        bag = ["R"] * r + ["B"] * (10 - r)
        if _prob(_comb(range(10), 2), lambda s: bag[s[0]] != bag[s[1]]) == F(8, 15):
            res.append(r)
    assert len(res) == 1
    return res[0]
q("C26-A-020", T, "Number of red balls from the probability of a mixed pair", "Medium",
  "Inverse/parameter",
  r"A box contains $10$ balls, each either red or blue, with more red balls than blue balls. Two balls are drawn together at random. If the probability that they are of different colours is $\frac{8}{15}$, how many red balls are in the box?",
  "TITA",
  r"With $r$ red balls, $\frac{r(10 - r)}{\binom{10}{2}} = \frac{r(10 - r)}{45} = \frac{8}{15}$, so $r(10 - r) = 24$, giving $r = 4$ or $r = 6$. Since red balls outnumber blue ones, $r = 6$.",
  "Reporting the other root of the quadratic, which is the number of blue balls.",
  "C26A-bag-two-colour-equation", "Sets up a quadratic from a combination ratio and uses a side condition.",
  tita_answer=6, check=_c20, values=[6],
  tita_traps=[(4, r"Takes the root $r = 4$, ignoring that red balls outnumber blue ones.")],
  cognitive="Application")

# 21
def _c21():
    ppl = ["M"] * 7 + ["W"] * 3
    return _prob(_comb(range(10), 4), lambda s: any(ppl[i] == "W" for i in s))
q("C26-A-021", T, "Random committee includes at least one woman", "Medium",
  "Multi-step word problem",
  r"A committee of $4$ is chosen at random from $7$ men and $3$ women. What is the probability that the committee includes at least one woman?",
  "MCQ",
  r"Use the complement. An all-men committee can be chosen in $\binom{7}{4} = 35$ ways out of $\binom{10}{4} = 210$. The required probability is $1 - \frac{35}{210} = \frac{5}{6}$.",
  "Counting only one or two of the cases for the number of women, or reporting the complement.",
  "C26A-selection-complement-at-least", "Complement avoids three separate cases.",
  correct=r"$\frac{5}{6}$",
  distractors=[(r"$\frac{1}{6}$", r"Reports the probability of an all-men committee, $\frac{35}{210}$."),
               (r"$\frac{1}{2}$", r"Counts only exactly one woman: $\frac{3 \times 35}{210}$."),
               (r"$\frac{4}{5}$", r"Counts one or two women, $105 + 63 = 168$, and misses the case of three women.")],
  check=_c21, values=[F(5, 6), F(1, 6), F(1, 2), F(4, 5)], cognitive="Application")

# 22
def _c22():
    return _prob(range(1, 201), lambda n: (n * n + 1) % 5 == 0) * 100
q("C26-A-022", T, "Random integer n with n squared plus 1 divisible by 5, via last digits", "Medium",
  "Conceptual/application",
  r"An integer $n$ is chosen at random from $1$ to $200$, both inclusive. If $p$ is the probability that $n^2 + 1$ is divisible by $5$, what is the value of $100p$?",
  "TITA",
  r"$n^2 + 1$ is divisible by $5$ exactly when $n^2$ ends in $4$ or $9$, which happens when $n$ ends in $2, 8, 3$ or $7$. These are $4$ of every $10$ consecutive integers, and $1$ to $200$ is $20$ complete blocks of ten, so $p = \frac{80}{200} = \frac{2}{5}$ and $100p = 40$.",
  r"Considering only squares ending in $9$, which is the condition for divisibility by $10$.",
  "C26A-numbers-residue-property", "Reduces to a last-digit pattern that repeats every ten integers.",
  tita_answer=40, check=_c22, values=[40],
  tita_traps=[(20, r"Counts only $n$ ending in $3$ or $7$ (squares ending in $9$), missing squares ending in $4$.")],
  cognitive="Analysis")

# 23
def _c23():
    return _prob(range(100, 1000), lambda n: len(set(str(n))) == 3) * 100
q("C26-A-023", T, "Random three-digit number has all digits different", "Medium",
  "Multi-step word problem",
  r"A three-digit number is chosen at random. If $p$ is the probability that all three of its digits are different, what is the value of $100p$?",
  "TITA",
  r"There are $900$ three-digit numbers. With distinct digits, the hundreds digit has $9$ choices (not $0$), the tens digit $9$ (any except the first) and the units digit $8$, giving $648$. So $p = \frac{648}{900} = \frac{18}{25}$ and $100p = 72$.",
  r"Allowing $0$ as the leading digit, or excluding $0$ from every position.",
  "C26A-numbers-digit-property", "Position-by-position counting with the leading-zero restriction.",
  tita_answer=72, check=_c23, values=[72],
  tita_traps=[(80, r"Counts $10 \times 9 \times 8 = 720$, allowing a leading $0$."),
              (56, r"Excludes $0$ from every position: $9 \times 8 \times 7 = 504$.")],
  cognitive="Application")

# 24
def _c24():
    return _prob(_perm("1234567"), lambda p: int("".join(p)) % 11 == 0)
q("C26-A-024", T, "Random arrangement of seven digits gives a multiple of 11", "Difficult",
  "Casework/optimisation",
  r"The digits $1, 2, 3, 4, 5, 6, 7$ are arranged in a random order, each used exactly once, to form a seven-digit number. What is the probability that the number is divisible by $11$?",
  "MCQ",
  r"Let $S$ be the sum of the four digits in the 1st, 3rd, 5th and 7th places; the other three sum to $28 - S$. Divisibility by $11$ needs $S - (28 - S) = 2S - 28$ to be a multiple of $11$. Since $10 \le S \le 22$, $2S - 28$ is even and lies between $-8$ and $16$, so it must be $0$ and $S = 14$. The four-digit sets with sum $14$ are $\{1,2,4,7\}, \{1,2,5,6\}, \{1,3,4,6\}, \{2,3,4,5\}$. Each gives $4! \times 3! = 144$ numbers, so $576$ of the $5040$ arrangements work and the probability is $\frac{576}{5040} = \frac{4}{35}$.",
  "Assuming one number in eleven is a multiple of $11$, or not arranging the digits in the even places.",
  "C26A-digits-arranged-divisibility", "Alternating-sum rule, a range argument to force $S = 14$, and a subset listing.",
  correct=r"$\frac{4}{35}$",
  distractors=[(r"$\frac{1}{11}$", r"Assumes one number in eleven is divisible by $11$, as for consecutive integers."),
               (r"$\frac{3}{35}$", r"Misses one of the four sets with sum $14$: $\frac{3 \times 144}{5040}$."),
               (r"$\frac{2}{105}$", r"Arranges only the four digits in the odd places: $\frac{4 \times 4!}{5040} = \frac{96}{5040}$.")],
  check=_c24, values=[F(4, 35), F(1, 11), F(3, 35), F(2, 105)], cognitive="Analysis", exams=CX)

# 25
def _c25():
    weekend = {5, 6}
    return _prob(_prod(range(7), repeat=4), lambda s: len(set(s)) == 4 and bool(set(s) & weekend))
q("C26-A-025", T, "Four people pick different days of the week, at least one of them a weekend day", "Medium",
  "Multi-step word problem",
  r"Four friends, Kabir, Priya, Arjun and Fatima, each pick one day of the week for a solo trek, independently and at random, with all seven days equally likely for each. What is the probability that no two of them pick the same day and at least one of them picks Saturday or Sunday?",
  "MCQ",
  r"There are $7^4 = 2401$ equally likely ways for the four to pick. Picks on four different days: $7 \times 6 \times 5 \times 4 = 840$. Among these, picks on four different weekdays: $5 \times 4 \times 3 \times 2 = 120$. So the favourable count is $840 - 120 = 720$ and the probability is $\frac{720}{2401}$.",
  "Dropping the distinct-days condition when taking the complement, or counting sets of days instead of ordered picks.",
  r"C26A-distinct-choices", "Two ideas: an ordered count of distinct picks, then a complement inside it for the weekend condition.",
  correct=r"$\frac{720}{2401}$",
  distractors=[(r"$\frac{215}{2401}$", r"Subtracts all-weekday picks without requiring them to differ: $840 - 5^4 = 215$."),
               (r"$\frac{1776}{2401}$", r"Ignores the distinct-days condition and finds only at least one weekend pick: $2401 - 5^4 = 1776$."),
               (r"$\frac{30}{2401}$", r"Counts sets of days instead of ordered picks: $\binom{7}{4} - \binom{5}{4} = 30$.")],
  check=_c25, values=[F(720, 2401), F(215, 2401), F(1776, 2401), F(30, 2401)], cognitive="Application")

# 26
def _c26():
    def ok(s):
        cnt = sorted(s.count(d) for d in set(s))
        return cnt == [1, 1, 2]
    return _prob(_prod(range(10), repeat=4), ok)
q("C26-A-026", T, "Random four-digit PIN has exactly one pair of equal digits and two other different digits", "Medium",
  "Casework/optimisation",
  r"A bank generates a $4$-digit PIN by choosing each of the four digits independently and at random from $0$ to $9$ (so the PIN may start with $0$). What is the probability that exactly one digit appears exactly twice in the PIN and the other two digits are different from each other and from it (as in $3053$)?",
  "MCQ",
  r"Choose the two places for the repeated digit in $\binom{4}{2} = 6$ ways and the repeated digit in $10$ ways. Fill the other two places, in order, with two different digits that differ from it: $9 \times 8 = 72$ ways. Favourable PINs: $6 \times 10 \times 72 = 4320$ out of $10^4$, so the probability is $\frac{4320}{10000} = \frac{54}{125}$.",
  "Not ordering the two single digits, or letting the two single digits be equal.",
  "C26A-pin-digit-pattern", "Places, repeated digit, then an ordered fill of the remaining places.",
  correct=r"$\frac{54}{125}$",
  distractors=[(r"$\frac{27}{125}$", r"Chooses the two single digits as a set, $\binom{9}{2} = 36$, without ordering them: $\frac{6 \times 10 \times 36}{10000}$."),
               (r"$\frac{243}{500}$", r"Fills the other two places with $9 \times 9$ choices, allowing them to be equal: $\frac{4860}{10000}$."),
               (r"$\frac{108}{125}$", r"Arranges the pattern in $4! = 24$ ways, treating the two equal digits as different: $\frac{10 \times 36 \times 24}{10000}$.")],
  check=_c26, values=[F(54, 125), F(27, 125), F(243, 500), F(108, 125)], cognitive="Application")

# 27
def _c27():
    return _prob(_prod(range(3), repeat=4), lambda s: len(set(s)) == 2)
q("C26-A-027", T, "Four marbles land in three boxes, exactly one box empty", "Medium",
  "Casework/optimisation",
  r"Kabir drops four marbles of different colours, one at a time, into three boxes. Each marble lands in any one of the three boxes with equal probability, independently of the others. What is the probability that exactly one box is left empty?",
  "MCQ",
  r"There are $3^4 = 81$ equally likely outcomes. Choose the empty box in $3$ ways; the four marbles then go into the other two boxes in $2^4 = 16$ ways, of which $2$ put all marbles in one box. So the favourable count is $3 \times 14 = 42$ and the probability is $\frac{42}{81} = \frac{14}{27}$.",
  "Forgetting to remove the cases where all marbles fall into a single box.",
  "C26A-balls-into-boxes", "Requires removing an inner overlap after choosing the empty box.",
  correct=r"$\frac{14}{27}$",
  distractors=[(r"$\frac{4}{9}$", r"Finds the probability that no box is empty, $\frac{36}{81}$."),
               (r"$\frac{16}{27}$", r"Uses $3 \times 2^4 = 48$ without removing outcomes where every marble lands in one box."),
               (r"$\frac{1}{27}$", r"Finds the probability that exactly two boxes are empty, $\frac{3}{81}$.")],
  check=_c27, values=[F(14, 27), F(4, 9), F(16, 27), F(1, 27)], cognitive="Analysis")

# 28
def _c28():
    def ap(s):
        a, b, c = sorted(s)
        return b - a == c - b
    return _prob(_prod(DICE, repeat=3), ap)
q("C26-A-028", T, "Numbers on three dice can be arranged into an arithmetic progression", "Medium",
  "Casework/optimisation",
  r"Three fair six-sided dice are rolled. What is the probability that the three numbers shown can be arranged in some order to form an arithmetic progression? (A progression with common difference $0$, such as $4, 4, 4$, counts.)",
  "MCQ",
  r"Out of $216$ outcomes: common difference $0$ gives $6$ outcomes. Difference $1$ gives the sets $\{1,2,3\}, \ldots, \{4,5,6\}$ ($4$ sets) and difference $2$ gives $\{1,3,5\}, \{2,4,6\}$ ($2$ sets); each set of three different numbers appears in $3! = 6$ orders, giving $36$ outcomes. The total is $42$, so the probability is $\frac{42}{216} = \frac{7}{36}$.",
  r"Leaving out the constant progressions, or not multiplying by the $3!$ orders.",
  "C26A-ap-arrangeable", "Casework on the common difference plus ordering.",
  correct=r"$\frac{7}{36}$",
  distractors=[(r"$\frac{1}{6}$", r"Leaves out the $6$ constant outcomes: $\frac{36}{216}$."),
               (r"$\frac{1}{12}$", r"Counts only outcomes already in progression order as rolled: $\frac{6 + 8 + 4}{216}$."),
               (r"$\frac{1}{18}$", r"Counts each set of numbers once instead of in all its orders: $\frac{6 + 6}{216}$.")],
  check=_c28, values=[F(7, 36), F(1, 6), F(1, 12), F(1, 18)], cognitive="Analysis")

# 29
def _c29():
    return _prob(_comb(range(1, 21), 2), lambda s: (s[0] + s[1]) % 3 == 0)
q("C26-A-029", T, "Two numbered cards drawn together have a sum divisible by 3", "Medium",
  "Multi-step word problem",
  r"Twenty cards are numbered $1$ to $20$, one number on each card. Joseph draws two cards together at random. What is the probability that the sum of the two numbers is divisible by $3$?",
  "MCQ",
  r"Sort the numbers by remainder on division by $3$: remainder $0$ has $6$ numbers ($3, 6, \ldots, 18$), remainder $1$ has $7$ ($1, 4, \ldots, 19$) and remainder $2$ has $7$ ($2, 5, \ldots, 20$). The sum is a multiple of $3$ when both cards have remainder $0$, $\binom{6}{2} = 15$ pairs, or one has remainder $1$ and the other remainder $2$, $7 \times 7 = 49$ pairs. The probability is $\frac{64}{190} = \frac{32}{95}$.",
  "Missing the case of two multiples of $3$, or assuming one pair in three works.",
  "C26A-numbered-cards-residue-sum", "Residue classes with unequal sizes and two cases.",
  correct=r"$\frac{32}{95}$",
  distractors=[(r"$\frac{1}{3}$", r"Assumes one pair in three has a sum divisible by $3$."),
               (r"$\frac{49}{190}$", r"Counts only the pairs with remainders $1$ and $2$, missing two multiples of $3$."),
               (r"$\frac{67}{200}$", r"Treats the draw as with replacement: $\frac{6^2 + 2 \times 7 \times 7}{400} = \frac{134}{400}$.")],
  check=_c29, values=[F(32, 95), F(1, 3), F(49, 190), F(67, 200)], cognitive="Application")

# 30
def _c30():
    return _prob(_comb(range(1, 21), 3), lambda s: sum(s) % 2 == 0) * 100
q("C26-A-030", T, "Three numbers drawn from 1 to 20 have an even sum, by symmetry", "Medium",
  "Conceptual/application",
  r"Three different numbers are chosen at random from $1, 2, 3, \ldots, 20$. If $p$ is the probability that their sum is even, what is the value of $100p$?",
  "TITA",
  r"An even sum needs all three even or exactly two odd: $\binom{10}{3} + \binom{10}{2} \times 10 = 120 + 450 = 570$ of the $\binom{20}{3} = 1140$ choices, so $p = \frac{1}{2}$ and $100p = 50$. Fast route: replacing each chosen number $x$ by $21 - x$ flips the parity of all three, so it turns every even-sum choice into an odd-sum choice and back, making the two equally likely.",
  "Counting only the all-even case, or missing the two-odd-one-even case.",
  "C26A-numbered-cards-parity", "Parity casework, or a symmetry argument for the quick answer.",
  tita_answer=50, check=_c30, values=[50],
  tita_traps=[],
  cognitive="Analysis")

# 31
def _c31():
    import sympy as sp
    pts = [(sp.cos(sp.pi * k / 4), sp.sin(sp.pi * k / 4)) for k in range(8)]
    def cr(o, a, b):
        return sp.nsimplify(sp.expand((a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])))
    O = (0, 0)
    def inside(s):
        a, b, c = (pts[i] for i in s)
        d = [cr(a, b, O), cr(b, c, O), cr(c, a, O)]
        return all(x > 0 for x in d) or all(x < 0 for x in d)
    return _prob(_comb(range(8), 3), inside)
q("C26-A-031", T, "Triangle from random octagon vertices contains the centre in its interior", "Difficult",
  "Casework/optimisation",
  r"Three of the eight vertices of a regular octagon are chosen at random. What is the probability that the centre of the octagon lies strictly inside the triangle formed by them?",
  "MCQ",
  r"The centre is strictly inside exactly when each of the three arcs between consecutive chosen vertices is shorter than half the circle, that is, spans at most $3$ of the $8$ equal steps. The gaps $(a, b, c)$ in steps satisfy $a + b + c = 8$ with each between $1$ and $3$: the patterns are $(3, 3, 2)$ in some order. Each triangle with gaps $3, 3, 2$ is fixed by the position of its gap of $2$, giving $8$ triangles. The probability is $\frac{8}{56} = \frac{1}{7}$. (A gap of $4$ means a diameter is a side, putting the centre on the triangle.)",
  "Counting right triangles, whose hypotenuse passes through the centre, as containing it, or using the result for points anywhere on a circle.",
  "C26A-polygon-vertex-selection", "Needs the semicircle criterion on a discrete set, with the diameter boundary case.",
  correct=r"$\frac{1}{7}$",
  distractors=[(r"$\frac{4}{7}$", r"Also counts the $24$ right triangles, whose hypotenuse is a diameter through the centre: $\frac{8 + 24}{56}$."),
               (r"$\frac{1}{4}$", r"Uses the answer for three points chosen anywhere on a circle."),
               (r"$\frac{3}{7}$", r"Finds the probability that the triangle is right-angled, $\frac{4 \times 6}{56}$.")],
  check=_c31, values=[F(1, 7), F(4, 7), F(1, 4), F(3, 7)], cognitive="Analysis", exams=CX)

# 32
def _c32():
    x = symbols('x')
    def ok(s):
        b, c = s
        rts = solve(x ** 2 - b * x + c, x)
        return all(r.is_integer for r in rts)
    return _prob(_prod(DICE, repeat=2), ok)
q("C26-A-032", T, "Quadratic with dice coefficients has integer roots", "Difficult",
  "Casework/optimisation",
  r"Two fair six-sided dice are rolled, showing $b$ and $c$. What is the probability that both roots of the equation $x^2 - bx + c = 0$ are integers? (A repeated root counts as both roots.)",
  "MCQ",
  r"If the roots are integers $u \le v$, then $u + v = b$ and $uv = c$ are positive, so $u, v \ge 1$ with $u + v \le 6$ and $uv \le 6$. The pairs are $(1,1), (1,2), (1,3), (1,4), (1,5), (2,2), (2,3)$, each giving one outcome $(b, c)$. So $7$ of the $36$ outcomes work and the probability is $\frac{7}{36}$.",
  "Testing only whether the roots are real, or counting each root pair in both orders.",
  "C26A-dice-quadratic-roots", "Turning the condition into integer pairs via sum and product is the non-obvious step.",
  correct=r"$\frac{7}{36}$",
  distractors=[(r"$\frac{5}{36}$", r"Leaves out the repeated-root cases $(1,1)$ and $(2,2)$."),
               (r"$\frac{1}{3}$", r"Counts ordered root pairs, so $(1,2)$ and $(2,1)$ are taken as different outcomes: $\frac{12}{36}$."),
               (r"$\frac{19}{36}$", r"Counts outcomes with real roots, $b^2 \ge 4c$, which number $19$.")],
  check=_c32, values=[F(7, 36), F(5, 36), F(1, 3), F(19, 36)], cognitive="Analysis", exams=CX)

# 33
def _c33():
    return _prob(_prod("HT", repeat=6), lambda s: "HH" not in "".join(s))
q("C26-A-033", T, "No two consecutive heads in six tosses", "Difficult",
  "Casework/optimisation",
  r"Arjun tosses a fair coin $6$ times. What is the probability that no two consecutive tosses both show heads?",
  "MCQ",
  r"Let $f(n)$ be the number of length-$n$ sequences with no two adjacent heads. A valid sequence ends in T (preceded by any valid sequence of length $n - 1$) or in TH (preceded by any valid sequence of length $n - 2$), so $f(n) = f(n-1) + f(n-2)$ with $f(1) = 2$, $f(2) = 3$. Then $f(3) = 5$, $f(4) = 8$, $f(5) = 13$, $f(6) = 21$. The probability is $\frac{21}{64}$.",
  "Shifting the recursion by one place, or reporting the complement.",
  "C26A-coins-no-consecutive", "Needs a recursive count; direct casework is slow.",
  correct=r"$\frac{21}{64}$",
  distractors=[(r"$\frac{13}{64}$", r"Uses $f(5) = 13$, one step short in the recursion."),
               (r"$\frac{17}{32}$", r"Uses $f(7) = 34$, one step too far: $\frac{34}{64}$."),
               (r"$\frac{43}{64}$", "Finds the probability that some two consecutive tosses are both heads.")],
  check=_c33, values=[F(21, 64), F(13, 64), F(17, 32), F(43, 64)], cognitive="Analysis", exams=CX)

# 34
def _c34():
    return _prob(_prod("HT", repeat=7), lambda s: s[:4].count("H") > s[4:].count("H"))
q("C26-A-034", T, "Player with one extra coin gets strictly more heads", "Difficult",
  "Conceptual/application",
  r"Harpreet tosses $4$ fair coins and Joseph tosses $3$ fair coins. What is the probability that Harpreet gets strictly more heads than Joseph?",
  "MCQ",
  r"Compare Harpreet's first $3$ coins with Joseph's $3$: by symmetry $P(\text{more}) = P(\text{fewer}) = q$ and $P(\text{tie}) = 1 - 2q$. Harpreet ends strictly ahead if he is already ahead, or if they tie and his fourth coin is a head: $q + \frac{1}{2}(1 - 2q) = \frac{1}{2}$. (Direct count: $64$ of the $128$ outcomes.)",
  "Reporting the chance of a tie, or of Joseph being ahead, or using the share of coins tossed.",
  "C26A-coins-compare-players", "The symmetry argument with one extra coin is non-obvious; direct counting takes longer.",
  correct=r"$\frac{1}{2}$",
  distractors=[(r"$\frac{35}{128}$", r"Finds the probability of equal heads: $\frac{1 + 12 + 18 + 4}{128}$."),
               (r"$\frac{29}{128}$", r"Finds the probability that Joseph gets more heads than Harpreet."),
               (r"$\frac{4}{7}$", r"Uses Harpreet's share of the $7$ coins.")],
  check=_c34, values=[F(1, 2), F(35, 128), F(29, 128), F(4, 7)], cognitive="Analysis", exams=CX)

# 35
def _c35():
    return _prob(range(1, 1001), lambda n: sum(int(d) for d in str(n)) == 10) * 1000
q("C26-A-035", T, "Random integer up to 1000 with digit sum 10", "Difficult",
  "Casework/optimisation",
  r"An integer is chosen at random from $1$ to $1000$, both inclusive. If $p$ is the probability that the sum of its digits is $10$, what is the value of $1000p$?",
  "TITA",
  r"Write numbers below $1000$ as $abc$ with leading zeros, $0 \le a, b, c \le 9$; $1000$ has digit sum $1$. Solutions of $a + b + c = 10$ in non-negative integers: $\binom{12}{2} = 66$. Remove those with a digit equal to $10$: $(10,0,0), (0,10,0), (0,0,10)$, leaving $63$. So $p = \frac{63}{1000}$ and $1000p = 63$.",
  r"Forgetting that a digit cannot exceed $9$.",
  "C26A-numbers-digit-sum", "Stars and bars with an upper-bound correction.",
  tita_answer=63, check=_c35, values=[63],
  tita_traps=[(66, r"Uses $\binom{12}{2} = 66$ without removing the three solutions with a digit equal to $10$."),
              (54, r"Counts only three-digit numbers (leading digit at least $1$): $\binom{11}{2} - 1 = 54$, missing $19, 28, \ldots, 91$.")],
  cognitive="Analysis", exams=CX)

# 36
def _c36():
    n = 4
    while True:
        bag = ["W"] * 3 + ["K"] * (n - 3)
        if _prob(_comb(range(n), 2), lambda s: bag[s[0]] == "K" and bag[s[1]] == "K") > F(1, 2):
            return n
        n += 1
q("C26-A-036", T, "Least bag size so that two drawn balls are both black with probability above one half", "Medium",
  "Inverse/parameter",
  r"A bag contains exactly $3$ white balls, and all the other balls in it are black. Two balls are drawn together at random. What is the least total number of balls the bag must contain for the probability that both drawn balls are black to be more than $\frac{1}{2}$?",
  "TITA",
  r"With $n$ balls, $P = \frac{(n-3)(n-4)}{n(n-1)}$. The condition $2(n-3)(n-4) > n(n-1)$ simplifies to $n^2 - 13n + 24 > 0$, whose larger root is $\frac{13 + \sqrt{73}}{2} \approx 10.8$. So $n \ge 11$. Check: $n = 10$ gives $\frac{42}{90} < \frac{1}{2}$; $n = 11$ gives $\frac{56}{110} > \frac{1}{2}$. The answer is $11$.",
  "Reporting the number of black balls, or rounding the boundary root down.",
  "C26A-bag-two-colour-equation", "One quadratic inequality from a pair-draw ratio, then an integer check; a typical two-step CAT item.",
  tita_answer=11, check=_c36, values=[11],
  tita_traps=[(8, "Reports the number of black balls for $n = 11$."),
              (10, r"Rounds the root $10.8$ down; $n = 10$ gives only $\frac{42}{90}$.")],
  cognitive="Analysis", exams=CX)

# 37
def _c37():
    people = [(c, k) for c in range(5) for k in range(2)]
    return _prob(_comb(people, 4), lambda s: len({p[0] for p in s}) == 4)
q("C26-A-037", T, "Random group of four from five couples contains no couple", "Difficult",
  "Casework/optimisation",
  r"Four people are chosen at random from five married couples (ten people). What is the probability that no married couple is among the four chosen?",
  "MCQ",
  r"Choose $4$ of the $5$ couples to be represented, in $\binom{5}{4} = 5$ ways, and one person from each, in $2^4 = 16$ ways: $80$ groups. Total groups: $\binom{10}{4} = 210$. The probability is $\frac{80}{210} = \frac{8}{21}$.",
  r"Counting groups with a couple as $5 \times \binom{8}{2}$, which counts groups with two couples twice.",
  "C26A-selection-no-couple", "Direct construction beats the error-prone complement; the trap is double counting.",
  correct=r"$\frac{8}{21}$",
  distractors=[(r"$\frac{13}{21}$", "Finds the probability that at least one couple is chosen."),
               (r"$\frac{1}{3}$", r"Uses $1 - \frac{5 \times \binom{8}{2}}{210} = 1 - \frac{140}{210}$, counting groups with two couples twice."),
               (r"$\frac{4}{7}$", r"Finds the probability of exactly one couple: $\frac{5 \times \binom{4}{2} \times 4}{210} = \frac{120}{210}$.")],
  check=_c37, values=[F(8, 21), F(13, 21), F(1, 3), F(4, 7)], cognitive="Analysis", exams=CX)

# 38
def _c38():
    divs = [d for d in range(1, 10001) if 10000 % d == 0]
    def sq(m):
        r = int(round(m ** 0.5)); return r * r == m
    def cu(m):
        r = int(round(m ** (1 / 3))); return r ** 3 == m
    return _prob(divs, lambda d: sq(d) or cu(d)) * 100
q("C26-A-038", T, "Random divisor of a power of 10 is a perfect square or a perfect cube", "Difficult",
  "Casework/optimisation",
  r"A positive divisor of $10^4$ is chosen at random, all divisors being equally likely. If $p$ is the probability that the chosen divisor is a perfect square or a perfect cube (the number $1$ is both), what is the value of $100p$?",
  "TITA",
  r"$10^4 = 2^4 \cdot 5^4$, so a divisor is $2^a 5^b$ with $0 \le a, b \le 4$: $25$ divisors. Squares need $a, b \in \{0, 2, 4\}$: $9$. Cubes need $a, b \in \{0, 3\}$: $4$. Both (sixth powers) need $a = b = 0$: $1$. Favourable: $9 + 4 - 1 = 12$, so $p = \frac{12}{25}$ and $100p = 48$.",
  r"Not removing the divisor $1$, which is counted among both squares and cubes.",
  "C26A-numbers-divisor-property", "Exponent counting for divisors with inclusion and exclusion.",
  tita_answer=48, check=_c38, values=[48],
  tita_traps=[(52, r"Adds $9 + 4 = 13$ without removing the divisor $1$ counted twice."),
              (36, r"Counts only the $9$ square divisors.")],
  cognitive="Analysis", exams=CX)

# 39
def _c39():
    res = []
    for r in range(1, 30):
        for g in range(r + 1, 30):
            n = r + g
            if 20 <= n <= 30:
                bag = ["R"] * r + ["G"] * g
                if _prob(_comb(range(n), 2), lambda s: bag[s[0]] != bag[s[1]]) == F(1, 2):
                    res.append(r)
    assert len(res) == 1
    return res[0]
q("C26-A-039", T, "Bag size and composition from a mixed pair probability of exactly one half", "Difficult",
  "Inverse/parameter",
  r"A box contains only red and green balls, with more green balls than red ones and between $20$ and $30$ balls in all. When two balls are drawn together at random, the probability that they are of different colours is exactly $\frac{1}{2}$. How many red balls are in the box?",
  "TITA",
  r"With $r$ red and $g$ green balls and $n = r + g$, $\frac{rg}{\binom{n}{2}} = \frac{1}{2}$ gives $4rg = n^2 - n$. Since $n^2 = (r + g)^2$, this becomes $(g - r)^2 = n$. The only perfect square from $20$ to $30$ is $25$, so $g - r = 5$ and $g + r = 25$, giving $r = 10$.",
  "Reporting the number of green balls, or the difference between the two colours.",
  r"C26A-bag-two-colour-equation", "Rewriting the condition as $(g - r)^2 = n$ is the key insight.",
  tita_answer=10, check=_c39, values=[10],
  tita_traps=[(15, "Reports the number of green balls."),
              (5, "Reports the difference $g - r$.")],
  cognitive="Analysis", exams=CX)

# 40
def _c40():
    def ap(s):
        a, b, c = sorted(s)
        return b - a == c - b
    return _prob(_comb(range(1, 21), 3), ap)
q("C26-A-040", T, "Three numbers chosen from 1 to 20 can form an arithmetic progression", "Difficult",
  "Conceptual/application",
  r"Three different numbers are chosen at random from $1, 2, 3, \ldots, 20$. What is the probability that they can be arranged to form an arithmetic progression?",
  "MCQ",
  r"Three numbers $a < b < c$ form a progression exactly when $b = \frac{a + c}{2}$, that is when $a$ and $c$ have the same parity; then $b$ is fixed. Pairs $(a, c)$ of the same parity: $\binom{10}{2} + \binom{10}{2} = 90$. Total choices: $\binom{20}{3} = 1140$. The probability is $\frac{90}{1140} = \frac{3}{38}$.",
  "Miscounting starting positions for each common difference, or counting each progression in both directions.",
  "C26A-ap-arrangeable", "The same-parity insight replaces a sum over common differences.",
  correct=r"$\frac{3}{38}$",
  distractors=[(r"$\frac{9}{76}$", r"Takes $20 - d$ starting values for each difference $d = 1, \ldots, 9$: $\frac{135}{1140}$."),
               (r"$\frac{3}{19}$", r"Counts each progression twice, increasing and decreasing: $\frac{180}{1140}$."),
               (r"$\frac{9}{19}$", r"Divides the $90$ same-parity end pairs by the $\binom{20}{2} = 190$ pairs, ignoring the middle term.")],
  check=_c40, values=[F(3, 38), F(9, 76), F(3, 19), F(9, 19)], cognitive="Analysis", exams=CX)
