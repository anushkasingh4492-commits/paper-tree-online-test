import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Ratio basics"
CX = ("CAT", "XAT")


def _int_solve(eq, var):
    return [s for s in solve(eq, var) if s.is_real and s > 0]


# ================================================================ EASY (12)

def _c1():
    a, m, k = symbols('a m k', positive=True)
    sol = solve([Eq(5 * a, 4 * m), Eq(7 * m, 3 * k)], [a, k], dict=True)[0]
    return simplify(sol[a] / sol[k])
q("C04-A-001", T, "Combining two ratios through a common middle term to relate the outer terms", "Easy",
  "Single-step computation",
  r"The monthly savings of Arjun and Meera are in the ratio $4 : 5$, and the monthly savings of Meera and Kabir are in the ratio $3 : 7$. What is the ratio of Arjun's monthly savings to Kabir's monthly savings?",
  "MCQ",
  r"Arjun $= \frac{4}{5}$ of Meera and Kabir $= \frac{7}{3}$ of Meera, so Arjun : Kabir $= \frac{4}{5} : \frac{7}{3} = 12 : 35$. Equivalently, make Meera's term $15$ in both: $12 : 15$ and $15 : 35$.",
  "Placing the outer terms of the two ratios side by side without equalising the common term.",
  "C04A-chain-two-ratios", "One step of equalising the common term; the trap is reading off $4 : 7$ directly.",
  correct=r"$12 : 35$",
  distractors=[(r"$4 : 7$", r"Takes the first term of one ratio and the last term of the other without making Meera's terms equal."),
               (r"$28 : 15$", r"Divides the ratios, $\frac{4}{5} \div \frac{3}{7} = \frac{28}{15}$, instead of multiplying them."),
               (r"$15 : 28$", r"Inverts the first ratio before multiplying: $\frac{5}{4} \times \frac{3}{7} = \frac{15}{28}$.")],
  check=_c1, values=[F(12, 35), F(4, 7), F(28, 15), F(15, 28)], cognitive="Understanding")


def _c2():
    total, r = 7200, (3, 4, 5)
    shares = [F(total * x, sum(r)) for x in r]
    return shares[2] - shares[0]
q("C04-A-002", T, "Difference between two shares when a sum is divided in a three-term ratio", "Easy",
  "Single-step computation",
  r"Rs. $7{,}200$ is divided among Sneha, Ravi and Fatima in the ratio $3 : 4 : 5$. By how many rupees does Fatima's share exceed Sneha's share?",
  "TITA",
  r"There are $3 + 4 + 5 = 12$ parts, so one part is $\frac{7200}{12} = 600$ rupees. Fatima's share exceeds Sneha's by $5 - 3 = 2$ parts $= 1200$ rupees.",
  "Reporting one of the shares instead of the difference asked for.",
  "C04A-divide-sum-basic", "One division into parts and one subtraction.",
  tita_answer=1200, check=_c2,
  tita_traps=[(3000, r"Reports Fatima's share, $5 \times 600$."), (1800, r"Reports Sneha's share, $3 \times 600$.")],
  cognitive="Application")


def _c3():
    # number of coins Re 1 : 50 p : 25 p = 5 : 6 : 8, total value Rs 210 (21000 paise)
    for n in range(1, 1000):
        if 5 * n * 100 + 6 * n * 50 + 8 * n * 25 == 21000:
            return 6 * n
q("C04-A-003", T, "Number of coins of one kind from a count ratio and the total value", "Easy",
  "Multi-step word problem",
  r"A bag contains only Re $1$ coins, $50$ paise coins and $25$ paise coins, and the numbers of these coins are in the ratio $5 : 6 : 8$. The total value of the coins is Rs. $210$. How many $50$ paise coins are there in the bag?",
  "TITA",
  r"Take $5n$, $6n$ and $8n$ coins. Their value is $5n(1) + 6n(0.5) + 8n(0.25) = 5n + 3n + 2n = 10n$ rupees. So $10n = 210$, $n = 21$, and the number of $50$ paise coins is $6 \times 21 = 126$.",
  "Treating the count ratio as a ratio of values, or reporting the rupee value of the coins instead of their number.",
  "C04A-coins-count-from-value", "Converting a count ratio into value per set; one trap is reporting rupees instead of coins.",
  tita_answer=126, check=_c3,
  tita_traps=[(63, r"Reports the value in rupees of the $50$ paise coins, $126 \times 0.5$."),
              (21, r"Reports the number of sets $n$ instead of $6n$.")],
  cognitive="Application")


def _c4():
    return (F(3, 4) ** 2) * sqrt(Rational(64, 9))
q("C04-A-004", T, "Ratio compounded of a duplicate ratio and a sub-duplicate ratio", "Easy",
  "Single-step computation",
  r"What is the ratio compounded of the duplicate ratio of $3 : 4$ and the sub-duplicate ratio of $64 : 9$?",
  "MCQ",
  r"The duplicate ratio of $3 : 4$ is $9 : 16$ and the sub-duplicate ratio of $64 : 9$ is $8 : 3$. Compounding means multiplying: $\frac{9}{16} \times \frac{8}{3} = \frac{72}{48} = \frac{3}{2}$, that is $3 : 2$.",
  "Doubling the terms for a duplicate ratio or halving them for a sub-duplicate ratio, instead of squaring or taking square roots.",
  "C04A-duplicate-subduplicate", "Two definitions and one multiplication; the trap is the meaning of duplicate and sub-duplicate.",
  correct=r"$3 : 2$",
  distractors=[(r"$2 : 1$", r"Treats the duplicate ratio as doubling the terms, $6 : 8 = 3 : 4$, and then multiplies by $8 : 3$ to get $24 : 12$."),
               (r"$4 : 1$", r"Treats the sub-duplicate ratio as halving the terms, which leaves $64 : 9$, and multiplies by $9 : 16$."),
               (r"$17 : 19$", r"Adds the corresponding terms of $9 : 16$ and $8 : 3$ instead of multiplying them.")],
  check=_c4, values=[F(3, 2), 2, 4, F(17, 19)], cognitive="Recall")


def _c5():
    x = symbols('x', positive=True)
    s = _int_solve(Eq((5 * x + 40) * 9, (7 * x + 40) * 7), x)[0]
    return 5 * s
q("C04-A-005", T, "Original quantity when an equal addition changes a ratio", "Easy",
  "Multi-step word problem",
  r"Two water tanks hold water in the ratio $5 : 7$. When $40$ litres of water is poured into each tank, the ratio becomes $7 : 9$. How many litres of water did the first tank hold originally?",
  "TITA",
  r"Let the tanks hold $5x$ and $7x$ litres. Then $\frac{5x + 40}{7x + 40} = \frac{7}{9}$, so $45x + 360 = 49x + 280$, giving $x = 20$. The first tank held $5 \times 20 = 100$ litres.",
  "Assuming that adding the same amount to both quantities keeps the ratio unchanged, or reporting the quantity after the addition.",
  "C04A-equal-addition", "One linear equation from the new ratio.",
  tita_answer=100, check=_c5,
  tita_traps=[(140, r"Reports the first tank's content after the addition, $100 + 40$ (which also equals the second tank's original content)."),
              (20, r"Reports the multiplier $x$ instead of $5x$.")],
  cognitive="Application")


def _c6():
    p1, p2, w1, w2 = 5, 4, 3, 7
    return F(p1 * w1, p2 * w2)
q("C04-A-006", T, "Compounded ratio of price per kg and quantity to get amount spent", "Easy",
  "Conceptual/application",
  r"A grocer buys two varieties of rice. The prices per kg of the two varieties are in the ratio $5 : 4$, and the quantities bought (in kg) are in the ratio $3 : 7$. What is the ratio of the amounts spent on the two varieties?",
  "MCQ",
  r"Amount spent $=$ price per kg $\times$ quantity, so the required ratio is the compounded ratio $(5 \times 3) : (4 \times 7) = 15 : 28$.",
  "Adding or dividing the two ratios instead of compounding (multiplying) them.",
  "C04A-compounded-ratio", "A single compounding step; the trap is choosing the wrong operation.",
  correct=r"$15 : 28$",
  distractors=[(r"$8 : 11$", r"Adds the corresponding terms, $(5 + 3) : (4 + 7)$."),
               (r"$35 : 12$", r"Divides the price ratio by the quantity ratio, $\frac{5}{4} \div \frac{3}{7}$."),
               (r"$12 : 35$", r"Divides the quantity ratio by the price ratio, $\frac{3}{7} \div \frac{5}{4}$.")],
  check=_c6, values=[F(15, 28), F(8, 11), F(35, 12), F(12, 35)], cognitive="Understanding")


def _c7():
    p, qq, r = symbols('p q r', positive=True)
    sol = solve([Eq(3 * p, 2 * qq), Eq(5 * qq, 4 * r), Eq(p + qq + r, 70)], [p, qq, r], dict=True)[0]
    return sol[r]
q("C04-A-007", T, "Share of a total after combining two linked ratios", "Easy",
  "Multi-step word problem",
  r"Three parcels P, Q and R together weigh $70$ kg. The weights of P and Q are in the ratio $2 : 3$, and the weights of Q and R are in the ratio $4 : 5$. What is the weight of parcel R?",
  "MCQ",
  r"Make Q's term common: $2 : 3 = 8 : 12$ and $4 : 5 = 12 : 15$, so P : Q : R $= 8 : 12 : 15$, a total of $35$ parts. One part is $2$ kg, so R weighs $15 \times 2 = 30$ kg.",
  "Writing the three-term ratio as $2 : 3 : 5$ without equalising Q's terms.",
  "C04A-chain-two-ratios", "One equalisation of the common term and one division into parts.",
  correct=r"$30$ kg",
  distractors=[(r"$35$ kg", r"Joins the ratios as $2 : 3 : 5$ and gives R $\frac{5}{10} \times 70$."),
               (r"$24$ kg", r"Reports Q's weight, $12 \times 2$."),
               (r"$25$ kg", r"Adds all four given terms, $2 + 3 + 4 + 5 = 14$, and gives R $\frac{5}{14} \times 70$.")],
  check=_c7, values=[30, 35, 24, 25], cognitive="Application")


def _c8():
    t = symbols('t', positive=True)
    return solve(Eq(F(7, 11) * t - F(4, 11) * t, 1350), t)[0]
q("C04-A-008", T, "Total sum from the difference of two shares in a given ratio", "Easy",
  "Inverse/parameter",
  r"A sum of money is divided between Harpreet and Joseph in the ratio $7 : 4$. Harpreet receives Rs. $1{,}350$ more than Joseph. What is the total sum?",
  "MCQ",
  r"The difference of $7 - 4 = 3$ parts is Rs. $1{,}350$, so one part is Rs. $450$. The total is $11 \times 450 =$ Rs. $4{,}950$.",
  "Treating the difference as one part, or reporting one person's share.",
  "C04A-divide-difference-given", "One part value from the difference, then the total.",
  correct=r"Rs. $4{,}950$",
  distractors=[(r"Rs. $3{,}150$", r"Reports Harpreet's share, $7 \times 450$."),
               (r"Rs. $1{,}800$", r"Reports Joseph's share, $4 \times 450$."),
               (r"Rs. $14{,}850$", r"Takes Rs. $1{,}350$ as one part and multiplies by $11$.")],
  check=_c8, values=[4950, 3150, 1800, 14850], cognitive="Application")


def _c9():
    x = symbols('x', positive=True)
    s = _int_solve(Eq(7 * x - 15, 2 * (4 * x - 15)), x)[0]
    return 11 * s
q("C04-A-009", T, "Original total when an equal removal changes a ratio", "Easy",
  "Multi-step word problem",
  r"Two shelves in a library hold books in the ratio $7 : 4$. When $15$ books are removed from each shelf, the ratio becomes $2 : 1$. How many books were there on the two shelves together originally?",
  "MCQ",
  r"Let the shelves hold $7x$ and $4x$ books. Then $7x - 15 = 2(4x - 15)$, so $x = 15$. The shelves held $105$ and $60$ books, a total of $165$. Check: $90 : 45 = 2 : 1$.",
  "Reporting the total after the removal, or one shelf's count.",
  "C04A-equal-subtraction", "One linear equation from the new ratio.",
  correct=r"$165$",
  distractors=[(r"$135$", r"Reports the total after removing $15$ books from each shelf, $165 - 30$."),
               (r"$105$", r"Reports only the first shelf's original count."),
               (r"$60$", r"Reports only the second shelf's original count.")],
  check=_c9, values=[165, 135, 105, 60], cognitive="Application")


def _c10():
    vals = (3, 5, 4)
    denom = (2, 5, 10)
    cnt = [F(v, d) for v, d in zip(vals, denom)]
    g = cnt[2]
    return tuple(c / g for c in cnt)  # (15/4, 5/2, 1) -> compare as ratio 15:10:4
def _c10v():
    a, b, c = _c10()
    return F(a, c), F(b, c)
q("C04-A-010", T, "Ratio of numbers of coins from the ratio of their values", "Easy",
  "Conceptual/application",
  r"A piggy bank contains only Rs. $2$, Rs. $5$ and Rs. $10$ coins. The total values of the Rs. $2$ coins, the Rs. $5$ coins and the Rs. $10$ coins are in the ratio $3 : 5 : 4$. What is the ratio of the numbers of Rs. $2$, Rs. $5$ and Rs. $10$ coins?",
  "MCQ",
  r"Number of coins $=$ value $\div$ denomination, so the counts are in the ratio $\frac{3}{2} : \frac{5}{5} : \frac{4}{10} = 1.5 : 1 : 0.4 = 15 : 10 : 4$.",
  "Taking the value ratio as the count ratio, or multiplying by the denominations instead of dividing.",
  "C04A-coins-value-to-count", "One conversion per term; the trap is multiplying instead of dividing.",
  correct=r"$15 : 10 : 4$",
  distractors=[(r"$3 : 5 : 4$", r"Takes the ratio of values as the ratio of numbers of coins."),
               (r"$6 : 25 : 40$", r"Multiplies each value term by its denomination: $3 \times 2 : 5 \times 5 : 4 \times 10$."),
               (r"$4 : 6 : 15$", r"Divides each denomination by its value term: $\frac{2}{3} : \frac{5}{5} : \frac{10}{4}$.")],
  check=lambda: _c10v(), values=[(F(15, 4), F(5, 2)), (F(3, 4), F(5, 4)), (F(6, 40), F(25, 40)), (F(4, 15), F(6, 15))],
  cognitive="Understanding")


def _c11():
    a, k, p = symbols('a k p', positive=True)
    sol = solve([Eq(2 * a, 3 * k), Eq(3 * k, 4 * p), Eq(a + k + p, 5850)], [a, k, p], dict=True)[0]
    return sol[k]
q("C04-A-011", T, "Division of a sum so that given multiples of the shares are equal", "Easy",
  "Conceptual/application",
  r"Rs. $5{,}850$ is divided among Ananya, Kabir and Priya so that twice Ananya's share, three times Kabir's share and four times Priya's share are all equal. How many rupees does Kabir receive?",
  "TITA",
  r"If $2A = 3K = 4P$, the shares are in the ratio $\frac{1}{2} : \frac{1}{3} : \frac{1}{4} = 6 : 4 : 3$, a total of $13$ parts. One part is $\frac{5850}{13} = 450$, so Kabir receives $4 \times 450 = 1800$ rupees.",
  "Dividing in the ratio $2 : 3 : 4$ of the multipliers instead of their reciprocals.",
  "C04A-reciprocal-ratio-division", "One reciprocal-ratio conversion; the trap is using the multipliers directly.",
  tita_answer=1800, check=_c11,
  tita_traps=[(1950, r"Divides in the ratio $2 : 3 : 4$: Kabir gets $\frac{3}{9} \times 5850$."),
              (1350, r"Reports Priya's share, $3 \times 450$.")],
  cognitive="Understanding")


def _c12():
    x = symbols('x', positive=True)
    return _int_solve(Eq(4 * (18 + x), 3 * (30 + x)), x)[0]
q("C04-A-012", T, "Equal addition needed to reach a target ratio", "Easy",
  "Inverse/parameter",
  r"Two coaching batches have $18$ and $30$ students. The same number of new students joins each batch, after which the numbers of students in the two batches are in the ratio $3 : 4$. How many new students joined each batch?",
  "MCQ",
  r"The difference of $12$ students does not change. In the ratio $3 : 4$ the difference is $1$ part, so $1$ part $= 12$ and the first batch now has $36$ students. Hence $36 - 18 = 18$ students joined each batch. Check: $36 : 48 = 3 : 4$.",
  "Adding the new students to the simplified ratio terms instead of to the actual numbers.",
  "C04A-equal-addition", "One idea (the difference is unchanged) and one subtraction.",
  correct=r"$18$",
  distractors=[(r"$3$", r"Simplifies $18 : 30$ to $3 : 5$ and solves $\frac{3 + x}{5 + x} = \frac{3}{4}$, which gives $x = 3$."),
               (r"$36$", r"Reports the new size of the first batch."),
               (r"$12$", r"Finds that one part equals the unchanged difference of $12$ and reports that part value.")],
  check=_c12, values=[18, 3, 36, 12], cognitive="Application")


# ================================================================ MEDIUM (18)

def _c13():
    f, n, r = symbols('f n r', positive=True)
    sol = solve([Eq(3 * f, 5 * n), Eq(n, 4 * r), Eq(f - r, 340)], [f, n, r], dict=True)[0]
    return sol[n]
q("C04-A-013", T, "Chain of two ratios with a given difference of the outer terms", "Medium",
  "Multi-step word problem",
  r"In a library, the numbers of fiction and non-fiction books are in the ratio $5 : 3$, and the numbers of non-fiction and reference books are in the ratio $4 : 1$. There are $340$ more fiction books than reference books. How many non-fiction books are there?",
  "TITA",
  r"Make the non-fiction term common: $5 : 3 = 20 : 12$ and $4 : 1 = 12 : 3$, so fiction : non-fiction : reference $= 20 : 12 : 3$. Fiction exceeds reference by $17$ parts $= 340$, so one part is $20$ and there are $12 \times 20 = 240$ non-fiction books.",
  "Joining the two ratios as $5 : 3 : 1$ without equalising the common term.",
  "C04A-chain-two-ratios", "Combining the ratios and then using a difference of parts; two linked steps.",
  tita_answer=240, check=_c13,
  tita_traps=[(255, r"Joins the ratios as $5 : 3 : 1$; the difference of $4$ parts gives one part $= 85$ and non-fiction $= 255$."),
              (400, r"Reports the number of fiction books, $20 \times 20$.")],
  cognitive="Application")


def _c14():
    m, a, b, o = symbols('m a b o', positive=True)
    sol = solve([Eq(2 * m, 3 * a), Eq(4 * a, 5 * b), Eq(3 * b, 2 * o)], [m, a, b], dict=True)[0]
    return simplify(20 * sol[m] / o)
q("C04-A-014", T, "Chain of three price equivalences to compare the first and last items", "Medium",
  "Conceptual/application",
  r"At a fruit stall, $2$ mangoes cost as much as $3$ apples, $4$ apples cost as much as $5$ bananas, and $3$ bananas cost as much as $2$ oranges. For the price of $20$ mangoes, how many oranges can be bought?",
  "TITA",
  r"Price of $1$ mango $= \frac{3}{2}$ apples $= \frac{3}{2} \times \frac{5}{4}$ bananas $= \frac{3}{2} \times \frac{5}{4} \times \frac{2}{3} = \frac{5}{4}$ oranges. So $20$ mangoes cost as much as $20 \times \frac{5}{4} = 25$ oranges.",
  "Inverting the exchange rates, that is taking the ratio of prices to be the ratio of the numbers of fruits.",
  "C04A-chain-many-links", "Three links must be chained in the right direction; inverting them is the trap.",
  tita_answer=25, check=_c14,
  tita_traps=[(16, r"Inverts every link: $20 \times \frac{2}{3} \times \frac{4}{5} \times \frac{3}{2} = 16$."),
              (30, r"Stops after the first link and reports $30$ apples.")],
  cognitive="Application")


def _c15():
    r, s, j = symbols('r s j', positive=True)
    sol = solve([Eq(r, Rational(3, 4) * s), Eq(s, Rational(2, 3) * j), Eq(r + s + j, 6500)], [r, s, j], dict=True)[0]
    return sol[r]
q("C04-A-015", T, "Shares linked by fractions of one another converted to a ratio", "Medium",
  "Multi-step word problem",
  r"Rs. $6{,}500$ is divided among Ravi, Sneha and Joseph so that Ravi gets $\frac{3}{4}$ of what Sneha gets, and Sneha gets $\frac{2}{3}$ of what Joseph gets. How many rupees does Ravi get?",
  "TITA",
  r"Take Joseph's share as $6$ units. Sneha gets $\frac{2}{3} \times 6 = 4$ units and Ravi gets $\frac{3}{4} \times 4 = 3$ units, so the ratio is $3 : 4 : 6$, a total of $13$ units. One unit is $500$ rupees, so Ravi gets $1500$ rupees.",
  "Converting the fractional relations to a ratio carelessly, or reporting the wrong person's share.",
  "C04A-fraction-of-another-share", "Two fractional relations must be turned into one three-term ratio.",
  tita_answer=1500, check=_c15,
  tita_traps=[(2000, r"Reports Sneha's share, $4 \times 500$."),
              (3000, r"Reports Joseph's share, $6 \times 500$.")],
  cognitive="Application")


def _c16():
    p, k, m = symbols('p k m', positive=True)
    sol = solve([Eq(p, (k + m) / 2), Eq(k, (p + m) / 3), Eq(p + k + m, 9600)], [p, k, m], dict=True)[0]
    return sol[m]
q("C04-A-016", T, "Shares given as fractions of the combined shares of the others", "Medium",
  "Conceptual/application",
  r"Rs. $9{,}600$ is divided among Priya, Kabir and Meera. Priya's share is half of the combined shares of Kabir and Meera, and Kabir's share is one-third of the combined shares of Priya and Meera. What is Meera's share?",
  "MCQ",
  r"If Priya's share is half of the other two, it is $\frac{1}{3}$ of the total: $3200$. If Kabir's share is one-third of the other two, it is $\frac{1}{4}$ of the total: $2400$. Meera gets $9600 - 3200 - 2400 = 4000$.",
  "Taking 'half of the others' as half of the total.",
  "C04A-fraction-of-the-rest", r"Needs the insight that $x = \frac{1}{n}$ of the rest means $x = \frac{1}{n+1}$ of the total.",
  correct=r"Rs. $4{,}000$",
  distractors=[(r"Rs. $1{,}600$", r"Takes Priya as $\frac{1}{2}$ and Kabir as $\frac{1}{3}$ of the total: $9600(1 - \frac{1}{2} - \frac{1}{3})$."),
               (r"Rs. $3{,}200$", r"Gets Priya right as $\frac{1}{3}$ of the total but also takes Kabir as $\frac{1}{3}$ of the total."),
               (r"Rs. $2{,}400$", r"Reports Kabir's share.")],
  check=_c16, values=[4000, 1600, 3200, 2400], cognitive="Analysis")


def _c17():
    x = symbols('x', positive=True)
    s = solve(Eq(8 * x - (3 * x + 5 * x + 8 * x) / 3, 1200), x)[0]
    return 16 * s
q("C04-A-017", T, "Total sum from how far one share exceeds the average share", "Medium",
  "Inverse/parameter",
  r"A sum of money is divided among Ananya, Ravi and Meera in the ratio $3 : 5 : 8$. Meera's share exceeds the average of the three shares by Rs. $1{,}200$. What is the total sum?",
  "MCQ",
  r"With shares $3x$, $5x$ and $8x$, the average is $\frac{16x}{3}$. So $8x - \frac{16x}{3} = \frac{8x}{3} = 1200$, giving $x = 450$. The total is $16 \times 450 =$ Rs. $7{,}200$.",
  "Comparing with the average of the other two shares instead of the average of all three.",
  "C04A-divide-sum-basic", "Average of shares in terms of parts, then the total; two steps with a fraction of a part.",
  correct=r"Rs. $7{,}200$",
  distractors=[(r"Rs. $4{,}800$", r"Uses the average of the other two shares, $4x$, so $4x = 1200$ and the total is $16 \times 300$."),
               (r"Rs. $3{,}600$", r"Finds $x = 450$ correctly but reports Meera's share, $8 \times 450$."),
               (r"Rs. $7{,}680$", r"Averages only the smallest and largest shares, $5.5x$, so $2.5x = 1200$, $x = 480$ and the total is $16 \times 480$.")],
  check=_c17, values=[7200, 4800, 3600, 7680], cognitive="Application")


def _c18():
    workers, days = (2, 3, 4), (5, 4, 3)
    w = [a * b for a, b in zip(workers, days)]
    return F(10200 * w[2], sum(w))
q("C04-A-018", T, "Dividing a sum in a ratio compounded of two ratios", "Medium",
  "Conceptual/application",
  r"A contractor pays a total of Rs. $10{,}200$ to three teams P, Q and R. Every worker earns the same daily wage. The numbers of workers in P, Q and R are in the ratio $2 : 3 : 4$, and the numbers of days they worked are in the ratio $5 : 4 : 3$. How much does team R receive?",
  "MCQ",
  r"Payment is proportional to workers $\times$ days, so the shares are in the compounded ratio $(2 \times 5) : (3 \times 4) : (4 \times 3) = 10 : 12 : 12 = 5 : 6 : 6$. One part is $\frac{10200}{17} = 600$, so R receives $6 \times 600 =$ Rs. $3{,}600$.",
  "Adding the two ratios term by term instead of compounding them, or using only one of them.",
  "C04A-compounded-ratio", "The compounded ratio must be recognised and then used to divide a sum.",
  correct=r"Rs. $3{,}600$",
  distractors=[(r"Rs. $3{,}400$", r"Adds the ratios term by term, $7 : 7 : 7$, and gives each team one-third."),
               (r"Rs. $2{,}550$", r"Uses only the days ratio $5 : 4 : 3$: R gets $\frac{3}{12} \times 10200$."),
               (r"Rs. $3{,}000$", r"Reports team P's share, $5 \times 600$.")],
  check=_c18, values=[3600, 3400, 2550, 3000], cognitive="Application")


def _c19():
    times = (10, 12, 15)
    w = [F(1, t) for t in times]
    return 11100 * w[2] / sum(w)
q("C04-A-019", T, "Dividing a prize in the inverse ratio of finishing times", "Medium",
  "Conceptual/application",
  r"A prize of Rs. $11{,}100$ is shared by Meera, Joseph and Fatima in the inverse ratio of the times they took to finish a puzzle, which were $10$, $12$ and $15$ minutes respectively. How much does Fatima receive?",
  "MCQ",
  r"The inverse ratio is $\frac{1}{10} : \frac{1}{12} : \frac{1}{15}$. Multiplying by $60$ gives $6 : 5 : 4$, a total of $15$ parts. One part is $740$, so Fatima receives $4 \times 740 =$ Rs. $2{,}960$.",
  "Reversing the order of the times instead of taking reciprocals, or using the direct ratio.",
  "C04A-reciprocal-ratio-division", "Inverse ratio of three terms needs an LCM step; reversing the order is a tempting shortcut that fails.",
  correct=r"Rs. $2{,}960$",
  distractors=[(r"Rs. $4{,}500$", r"Divides in the direct ratio $10 : 12 : 15$: Fatima gets $\frac{15}{37} \times 11100$."),
               (r"Rs. $3{,}000$", r"Writes the inverse ratio as the reversed order $15 : 12 : 10$: Fatima gets $\frac{10}{37} \times 11100$."),
               (r"Rs. $4{,}440$", r"Reports Meera's share, $6 \times 740$.")],
  check=_c19, values=[2960, 4500, 3000, 4440], cognitive="Application")


def _c20():
    x = symbols('x', positive=True)
    s = solve(Eq(9 * x - 4 * x, 2400), x)[0]
    return 20 * s / 3
q("C04-A-020", T, "Equal division of a sum found from the difference of ratio shares", "Medium",
  "Multi-step word problem",
  r"A sum of money is divided among Sneha, Arjun and Kabir in the ratio $4 : 7 : 9$, and Kabir's share is Rs. $2{,}400$ more than Sneha's. If the same sum had instead been divided equally among the three, how many rupees would Arjun have received?",
  "TITA",
  r"The difference $9 - 4 = 5$ parts is $2400$, so one part is $480$ and the sum is $20 \times 480 = 9600$. Divided equally, each person, including Arjun, gets $\frac{9600}{3} = 3200$ rupees.",
  "Reporting Arjun's share under the ratio division instead of the equal division.",
  "C04A-divide-difference-given", "Part value from a difference, then the total, then a new division.",
  tita_answer=3200, check=_c20,
  tita_traps=[(3360, r"Reports Arjun's share under the ratio $4 : 7 : 9$, $7 \times 480$."),
              (4320, r"Reports Kabir's share under the ratio, $9 \times 480$.")],
  cognitive="Application")


def _c21():
    m, j, f, k = symbols('m j f k', positive=True)
    sol = solve([Eq(m - 200, 3 * k), Eq(j - 500, 4 * k), Eq(f - 300, 5 * k), Eq(m + j + f, 10600)], [m, j, f, k], dict=True)[0]
    return sol[j]
q("C04-A-021", T, "Shares that fall into a ratio after unequal fixed deductions", "Medium",
  "Multi-step word problem",
  r"Rs. $10{,}600$ is divided among Meera, Joseph and Fatima in such a way that if Rs. $200$, Rs. $500$ and Rs. $300$ are deducted from their respective shares, the amounts left are in the ratio $3 : 4 : 5$. What is Joseph's share?",
  "MCQ",
  r"The amounts left total $10600 - (200 + 500 + 300) = 9600$, which is $12$ parts, so one part is $800$. Joseph has $4 \times 800 = 3200$ left, so his share is $3200 + 500 =$ Rs. $3{,}700$.",
  "Forgetting to add back the deduction, or adjusting it in the wrong direction.",
  "C04A-divide-after-deductions", "Adjust the total, divide, then adjust back; two reversals in sequence.",
  correct=r"Rs. $3{,}700$",
  distractors=[(r"Rs. $3{,}200$", r"Stops at the amount left, $4 \times 800$, without adding back Rs. $500$."),
               (r"Rs. $2{,}700$", r"Subtracts the deduction again from the amount left: $3200 - 500$."),
               (r"Rs. $4{,}300$", r"Reports Fatima's share, $5 \times 800 + 300$.")],
  check=_c21, values=[3700, 3200, 2700, 4300], cognitive="Application")


def _c22():
    for n in range(1, 1000):
        five, two, one = 8 * n, 12 * n, 15 * n
        if 5 * five + 2 * two + one == 1659:
            return five + two + one
q("C04-A-022", T, "Total number of coins from two linked count ratios and a total value", "Medium",
  "Multi-step word problem",
  r"A cash box contains only Rs. $5$, Rs. $2$ and Re $1$ coins. The numbers of Rs. $5$ and Rs. $2$ coins are in the ratio $2 : 3$, and the numbers of Rs. $2$ and Re $1$ coins are in the ratio $4 : 5$. The total value of the coins is Rs. $1{,}659$. How many coins are there in the box altogether?",
  "MCQ",
  r"Combining, the counts are $8 : 12 : 15$. One set of $8 + 12 + 15 = 35$ coins is worth $40 + 24 + 15 = 79$ rupees. There are $\frac{1659}{79} = 21$ sets, so $35 \times 21 = 735$ coins.",
  "Joining the count ratios without equalising the common term, or confusing coins per set with value per set.",
  "C04A-coins-count-from-value", "Chain the count ratios, then value per set; two ideas combined.",
  correct=r"$735$",
  distractors=[(r"$790$", r"Joins the ratios as $2 : 3 : 5$; a set of $10$ coins is worth $21$ rupees, giving $79$ sets and $790$ coins."),
               (r"$315$", r"Reports only the number of Re $1$ coins, $15 \times 21$."),
               (r"$252$", r"Reports only the number of Rs. $2$ coins, $12 \times 21$.")],
  check=_c22, values=[735, 790, 315, 252], cognitive="Application")


def _c23():
    for n in range(1, 211):
        # counts of 25 p, 50 p, Re 1 with equal values (in paise)
        for m in range(1, 211):
            k = 210 - n - m
            if k >= 1 and 25 * n == 50 * m == 100 * k:
                return n
q("C04-A-023", T, "Numbers of coins when every denomination has the same total value", "Medium",
  "Conceptual/application",
  r"A collection of $210$ coins consists only of $25$ paise, $50$ paise and Re $1$ coins. The total value of the $25$ paise coins, the total value of the $50$ paise coins and the total value of the Re $1$ coins are all equal. How many $25$ paise coins are there?",
  "MCQ",
  r"Equal values mean the counts are inversely proportional to the denominations: $\frac{1}{25} : \frac{1}{50} : \frac{1}{100} = 4 : 2 : 1$. The $7$ parts are $210$ coins, so one part is $30$ and there are $4 \times 30 = 120$ coins of $25$ paise.",
  "Assuming equal values means equal numbers of coins, or taking counts in the ratio of the denominations.",
  "C04A-coins-value-to-count", "Needs the inverse relation between count and denomination for a fixed value.",
  correct=r"$120$",
  distractors=[(r"$70$", r"Assumes equal values mean equal numbers of coins: $\frac{210}{3}$."),
               (r"$30$", r"Takes the counts in the ratio of the denominations, $1 : 2 : 4$, giving $\frac{1}{7} \times 210$."),
               (r"$60$", r"Reports the number of $50$ paise coins, $2 \times 30$.")],
  check=_c23, values=[120, 70, 30, 60], cognitive="Understanding")


def _c24():
    k, f = 1800, 3000
    for m in range(0, 100):
        if F(k + 200 * m, f + 200 * m) == F(5, 7):
            return m
q("C04-A-024", T, "Number of equal deposits after which two balances reach a target ratio", "Medium",
  "Inverse/parameter",
  r"Kabir and Fatima have Rs. $1{,}800$ and Rs. $3{,}000$ in their piggy banks. At the end of every month each of them puts exactly Rs. $200$ more into their own piggy bank, and nothing is ever taken out. After how many months will the amounts in their piggy banks be in the ratio $5 : 7$?",
  "TITA",
  r"The difference of Rs. $1{,}200$ never changes, and in the ratio $5 : 7$ it is $2$ parts, so one part is $600$ and Kabir must reach $5 \times 600 = 3000$. He needs $3000 - 1800 = 1200$ more, which takes $\frac{1200}{200} = 6$ months. Check: $3000 : 4200 = 5 : 7$.",
  "Answering with the rupee amount added instead of the number of months.",
  "C04A-equal-addition", "Uses the constant difference with an equal addition expressed per month; two steps.",
  tita_answer=6, check=_c24,
  tita_traps=[(1200, r"Reports the total amount Kabir adds instead of the number of months."),
              (21, r"Treats the constant difference of Rs. $1{,}200$ as one part, so Kabir's target is $5 \times 1200 = 6000$ and he needs $\frac{4200}{200}$ months.")],
  cognitive="Application")


def _c25():
    x = symbols('x', positive=True)
    s = _int_solve(Eq(9 * x - 12, 2 * (5 * x - 12)), x)[0]
    return F(int(9 * s - 24), int(5 * s - 24))
q("C04-A-025", T, "New ratio after a different equal removal, once the quantities are fixed", "Medium",
  "Conceptual/application",
  r"Two godowns hold bags of rice in the ratio $9 : 5$. If $12$ bags were removed from each godown, the ratio would become $2 : 1$. What would the ratio be if instead $24$ bags were removed from each godown?",
  "MCQ",
  r"Let the godowns hold $9x$ and $5x$ bags. Then $9x - 12 = 2(5x - 12)$ gives $x = 12$, so they hold $108$ and $60$ bags. Removing $24$ from each leaves $84$ and $36$, and $84 : 36 = 7 : 3$.",
  "Assuming the ratio changes by equal steps for equal removals, or applying the second removal on top of the first.",
  "C04A-equal-subtraction", "The actual quantities must be found first; the ratio does not change linearly with the amount removed.",
  correct=r"$7 : 3$",
  distractors=[(r"$11 : 5$", r"Assumes the ratio value rises by equal steps: $1.8$ to $2$ for $12$ bags, so $2.2$ for $24$ bags."),
               (r"$3 : 1$", r"Removes $24$ more bags after the first $12$, that is $36$ in all: $72 : 24$."),
               (r"$7 : 5$", r"Removes $24$ bags only from the first godown: $84 : 60$.")],
  check=_c25, values=[F(7, 3), F(11, 5), 3, F(7, 5)], cognitive="Analysis")


def _c26():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(6 * (a + 6), 5 * (b + 6)), Eq(4 * (a - 6), 3 * (b - 6))], [a, b], dict=True)[0]
    return sol[a]
q("C04-A-026", T, "Two quantities fixed by one equal addition and one equal subtraction", "Medium",
  "Multi-step word problem",
  r"Ananya and Ravi each have some stamps. If each of them received $6$ more stamps, their numbers of stamps would be in the ratio $5 : 6$. If instead each of them gave away $6$ stamps, the ratio would be $3 : 4$. How many stamps does Ananya have?",
  "MCQ",
  r"The difference $d$ between their counts never changes, and it is $1$ part in both $5 : 6$ and $3 : 4$. So Ananya $+ 6 = 5d$ and Ananya $- 6 = 3d$. Subtracting, $12 = 2d$, so $d = 6$ and Ananya has $5 \times 6 - 6 = 24$ stamps (Ravi has $30$; check $30 : 36 = 5 : 6$ and $18 : 24 = 3 : 4$).",
  "Taking the gap between the two scenarios as $6$ instead of $12$.",
  "C04A-addition-and-subtraction-conditions", "Two conditions must be combined; the constant difference gives a fast route.",
  correct=r"$24$",
  distractors=[(r"$9$", r"Takes the gap between the two scenarios as $6$, so $2d = 6$, $d = 3$ and Ananya $= 5 \times 3 - 6$."),
               (r"$30$", r"Reports Ravi's number of stamps."),
               (r"$18$", r"Reports Ananya's number after giving away $6$ stamps.")],
  check=_c26, values=[24, 9, 30, 18], cognitive="Application")


def _c27():
    x = symbols('x', positive=True)
    s = _int_solve(Eq(25 * (30 - x), 9 * (46 - x)), x)
    return [v for v in s if v < 30][0]
q("C04-A-027", T, "Equal subtraction that makes two quantities fall in a duplicate ratio", "Medium",
  "Inverse/parameter",
  r"Two ropes are $30$ m and $46$ m long. The same length is cut off from each rope, and the remaining lengths are then in the duplicate ratio of $3 : 5$. How many metres were cut off from each rope?",
  "TITA",
  r"The duplicate ratio of $3 : 5$ is $9 : 25$. The difference of $16$ m is unchanged and equals $25 - 9 = 16$ parts, so one part is $1$ m and the remaining lengths are $9$ m and $25$ m. Hence $30 - 9 = 21$ m was cut off from each rope.",
  "Using the ratio $3 : 5$ itself instead of its duplicate.",
  "C04A-duplicate-subduplicate", "Combines the duplicate ratio with an equal subtraction.",
  tita_answer=21, check=_c27,
  tita_traps=[(6, r"Uses $3 : 5$ instead of $9 : 25$: the difference $16$ is $2$ parts, the pieces left are $24$ and $40$ m, so $6$ m is cut."),
              (9, r"Reports the remaining length of the shorter rope instead of the length cut off.")],
  cognitive="Application")


def _c28():
    t = symbols('t', positive=True)
    tot = solve(Eq(F(5, 12) * t - F(3, 12) * t, 1800), t)[0]
    return F(5, 12) * tot
q("C04-A-028", T, "Amount received when a sum is divided in the reversed ratio by mistake", "Medium",
  "Multi-step word problem",
  r"A sum of money was to be divided among Ravi, Sneha and Kabir in the ratio $5 : 4 : 3$, but by mistake it was divided in the ratio $3 : 4 : 5$. As a result, Ravi received Rs. $1{,}800$ less than he should have. How much did Kabir receive?",
  "MCQ",
  r"Ravi's share fell from $\frac{5}{12}$ to $\frac{3}{12}$ of the sum, a loss of $\frac{2}{12}$ of the sum $=$ Rs. $1{,}800$. So the sum is Rs. $10{,}800$ and Kabir received $\frac{5}{12} \times 10800 =$ Rs. $4{,}500$.",
  "Taking the loss as one part, or reporting Kabir's intended share.",
  "C04A-ratio-changed-by-mistake", "Compare two divisions of the same sum and work back to the total.",
  correct=r"Rs. $4{,}500$",
  distractors=[(r"Rs. $2{,}700$", r"Reports Kabir's intended share, $\frac{3}{12} \times 10800$."),
               (r"Rs. $9{,}000$", r"Takes Rs. $1{,}800$ as one part and gives Kabir $5 \times 1800$."),
               (r"Rs. $3{,}600$", r"Reports Sneha's share, which is $\frac{4}{12} \times 10800$ under both ratios.")],
  check=_c28, values=[4500, 2700, 9000, 3600], cognitive="Application")


def _c29():
    for n in range(1, 2000):
        # values: Rs 100 notes, Rs 50 notes, Rs 10 notes
        h, f = 3 * n, 5 * n
        v100, v50 = 100 * h, 50 * f
        v10 = F(2, 5) * v50
        if v100 + v50 + v10 == 13000:
            return v10 / 10
q("C04-A-029", T, "Number of notes when one ratio is of counts and the other is of values", "Medium",
  "Multi-step word problem",
  r"A cash box has only Rs. $100$, Rs. $50$ and Rs. $10$ notes. The numbers of Rs. $100$ and Rs. $50$ notes are in the ratio $3 : 5$, while the total values of the Rs. $50$ notes and the Rs. $10$ notes are in the ratio $5 : 2$. The total value of all the notes is Rs. $13{,}000$. How many Rs. $10$ notes are there?",
  "MCQ",
  r"Counts $3 : 5$ for Rs. $100$ and Rs. $50$ notes mean values $300 : 250 = 6 : 5$. With the Rs. $50$ to Rs. $10$ value ratio $5 : 2$, the values are $6 : 5 : 2$, a total of $13$ parts, so one part is Rs. $1{,}000$. The Rs. $10$ notes are worth Rs. $2{,}000$, which is $200$ notes.",
  "Treating the count ratio as a value ratio, so that the two ratios are joined directly.",
  "C04A-notes-count-and-value", "One ratio is of counts and the other of values; they must be put on the same basis before combining.",
  correct=r"$200$",
  distractors=[(r"$260$", r"Treats $3 : 5$ as a value ratio, so the values are $3 : 5 : 2$ and the Rs. $10$ notes are worth $\frac{2}{10} \times 13000 = 2600$ rupees."),
               (r"$100$", r"Reports the number of Rs. $50$ notes, worth Rs. $5{,}000$."),
               (r"$60$", r"Reports the number of Rs. $100$ notes, worth Rs. $6{,}000$.")],
  check=_c29, values=[200, 260, 100, 60], cognitive="Analysis")


def _c30():
    x, y, z = symbols('x y z', positive=True)
    xy = Rational(27, 64) ** Rational(1, 3)
    yz = sqrt(Rational(25, 36))
    return nsimplify(xy * yz)
q("C04-A-030", T, "Recovering ratios from triplicate and duplicate ratios, then combining", "Medium",
  "Multi-step word problem",
  r"For positive numbers $x$, $y$ and $z$, the triplicate ratio of $x : y$ is $27 : 64$ and the duplicate ratio of $y : z$ is $25 : 36$. What is $x : z$?",
  "MCQ",
  r"Taking cube roots, $x : y = 3 : 4$; taking square roots, $y : z = 5 : 6$. Then $\frac{x}{z} = \frac{3}{4} \times \frac{5}{6} = \frac{15}{24} = \frac{5}{8}$, so $x : z = 5 : 8$.",
  "Combining the given ratios without first taking the roots, or dividing instead of multiplying.",
  "C04A-duplicate-subduplicate", "Two root extractions and a chain; each step has its own trap.",
  correct=r"$5 : 8$",
  distractors=[(r"$1 : 2$", r"Places the outer terms of $3 : 4$ and $5 : 6$ side by side as $3 : 6$."),
               (r"$75 : 256$", r"Multiplies the given ratios $27 : 64$ and $25 : 36$ without taking roots."),
               (r"$9 : 10$", r"Divides instead of multiplying: $\frac{3}{4} \div \frac{5}{6} = \frac{9}{10}$.")],
  check=_c30, values=[F(5, 8), F(1, 2), F(75, 256), F(9, 10)], cognitive="Application")


# ================================================================ DIFFICULT (10)

def _c31():
    # brute force over the original count on Q and the number added to each shelf
    for qq in range(1, 400):
        if (2 * qq) % 3 or (5 * qq) % 4:
            continue
        p, r = 2 * qq // 3, 5 * qq // 4      # P is two-thirds of Q, R is 25% more than Q
        for x in range(1, 400):
            if F(p + x, r + x) == F(2, 3) and p + qq + r + 3 * x == 159:
                return qq
q("C04-A-031", T, "Three-term chain from fraction and percentage links, then an unknown equal addition fixed by the new total", "Difficult",
  "Multi-step word problem",
  r"Three shelves P, Q and R hold books. Shelf P holds two-thirds as many books as shelf Q, and shelf R holds $25\%$ more books than shelf Q. The same number of books is then added to each shelf, after which the numbers of books on P and R are in the ratio $2 : 3$ and the three shelves together hold $159$ books. How many books were on shelf Q before the addition?",
  "TITA",
  r"P : Q $= 2 : 3$ and R : Q $= 5 : 4$; making Q common gives P, Q, R $= 8k$, $12k$, $15k$. Adding the same number to each shelf leaves R $-$ P $= 7k$ unchanged, and in $2 : 3$ this is $1$ part, so P becomes $14k$ and R becomes $21k$: $6k$ books were added to each shelf. The new total is $35k + 3(6k) = 53k = 159$, so $k = 3$ and Q held $12k = 36$ books (check: $42 : 63 = 2 : 3$ and $42 + 54 + 63 = 159$).",
  "Forgetting that the total of $159$ includes the books added to all three shelves, or reporting Q's count after the addition.",
  "C04A-chain-then-equal-addition", "Fraction and percentage links must be chained through Q, the unknown equal addition is found from the constant difference, and the new total then fixes the scale; four stages.",
  tita_answer=36, check=_c31,
  tita_traps=[(54, r"Reports Q's count after the addition, $12k + 6k$."),
              (18, r"Reports the number of books added to each shelf, $6k$.")],
  exams=CX, cognitive="Analysis")


def _c32():
    m, a, p = symbols('m a p', positive=True)
    sol = solve([Eq(F(4, 5) * m, F(3, 4) * a), Eq(F(3, 4) * a, F(1, 2) * p), Eq(F(1, 2) * p - F(1, 5) * m, 1800)], [m, a, p], dict=True)[0]
    return sol[m] + sol[a] + sol[p]
q("C04-A-032", T, "Total sum when equal remainders after different percentage spends fix the ratio", "Difficult",
  "Conceptual/application",
  r"A sum of money is divided among Meera, Arjun and Priya. Meera spends $20\%$ of her share, Arjun spends $25\%$ of his and Priya spends $50\%$ of hers, and the three amounts left over are then equal. Priya spent Rs. $1{,}800$ more than Meera. What was the total sum?",
  "MCQ",
  r"Equal remainders give $0.8M = 0.75A = 0.5P$, so $M : A : P = \frac{1}{0.8} : \frac{1}{0.75} : \frac{1}{0.5} = 15 : 16 : 24$. Since the amounts left are equal, the difference in spending equals the difference in shares: $24 - 15 = 9$ parts $= 1800$, so one part is $200$. The total is $55 \times 200 =$ Rs. $11{,}000$.",
  "Reporting the money left or spent instead of the total, or taking shares in the direct ratio of the percentages.",
  "C04A-reciprocal-ratio-division", "Needs the reciprocal ratio of the retained fractions and the insight that spending differences equal share differences.",
  correct=r"Rs. $11{,}000$",
  distractors=[(r"Rs. $7{,}200$", r"Reports the total left over, $3 \times 2400$, instead of the total sum."),
               (r"Rs. $4{,}800$", r"Reports Priya's share, $24 \times 200$."),
               (r"Rs. $3{,}800$", r"Reports the total amount spent, $600 + 800 + 2400$.")],
  check=_c32, values=[11000, 7200, 4800, 3800], exams=CX, cognitive="Analysis")


def _c33():
    count = 0
    for n in range(1, 400):
        d = 8 + n
        shares = [F(360 * t, d) for t in (3, 5, n)]
        if all(s.denominator == 1 for s in shares):
            count += 1
    return count
q("C04-A-033", T, "Counting the ratio terms that give whole-number shares", "Difficult",
  "Casework/optimisation",
  r"A teacher distributes $360$ pencils among three groups in the ratio $3 : 5 : n$, where $n$ is a positive integer, and every group receives a whole number of pencils. How many values of $n$ are possible?",
  "TITA",
  r"With $d = 8 + n$, the shares are $\frac{1080}{d}$, $\frac{1800}{d}$ and $\frac{360n}{d}$. If the first two are integers, so is their difference $\frac{720}{d}$, and then $\frac{1080}{d} - \frac{720}{d} = \frac{360}{d}$ is an integer; conversely, if $d$ divides $360$, all three shares are integers. So $d$ must be a divisor of $360$ with $d \geq 9$. Now $360$ has $24$ divisors, of which $1, 2, 3, 4, 5, 6, 8$ are below $9$, leaving $17$ values of $n$.",
  "Counting all divisors of $360$, or allowing $n = 0$.",
  "C04A-divide-integer-shares-casework", r"Divisibility casework on a parametrised ratio; the condition $d \mid 360$ must be justified and the range handled.",
  tita_answer=17, check=_c33,
  tita_traps=[(24, r"Counts every divisor of $360$ without requiring $8 + n \geq 9$."),
              (18, r"Allows $n = 0$, which adds the divisor $d = 8$.")],
  exams=CX, cognitive="Analysis")


def _c34():
    ms = set()
    for k in range(1, 200):
        for m in range(1, 200):
            if 3 * k * 1 + 2 * k * 2 + 5 * m == 490:
                ms.add(m)
    return len(ms)
q("C04-A-034", T, "Counting possible coin compositions under a count ratio and a total value", "Difficult",
  "Casework/optimisation",
  r"A collection contains only Re $1$, Rs. $2$ and Rs. $5$ coins, with at least one coin of each kind. The numbers of Re $1$ and Rs. $2$ coins are in the ratio $3 : 2$, and the total value of the collection is Rs. $490$. How many different values are possible for the number of Rs. $5$ coins?",
  "TITA",
  r"Let there be $3k$ Re $1$ coins, $2k$ Rs. $2$ coins and $m$ Rs. $5$ coins. Then $3k + 4k + 5m = 490$, so $7k + 5m = 490$. Since $490$ and $5m$ are multiples of $5$, $k$ must be a multiple of $5$; also $m \geq 1$ needs $7k < 490$, so $k < 70$. Thus $k = 5, 10, \ldots, 65$, which is $13$ values, each giving a different $m = 98 - \frac{7k}{5}$.",
  "Forgetting the 'at least one of each' condition, which wrongly admits $k = 70$ with no Rs. $5$ coin.",
  "C04A-coins-casework", "A linear Diophantine condition with a divisibility step and boundary casework.",
  tita_answer=13, check=_c34,
  tita_traps=[(14, r"Allows $k = 70$, which gives $m = 0$ Rs. $5$ coins."),
              (70, r"Counts every $k$ from $1$ to $70$ without the divisibility condition.")],
  exams=CX, cognitive="Analysis")


def _c35():
    a, b, c, k, m = symbols('a b c k m', positive=True)
    sol = solve([Eq(a - 300, 2 * k), Eq(b - 300, 3 * k), Eq(c - 300, 5 * k),
                 Eq(a + 600, 4 * m), Eq(b + 600, 5 * m), Eq(c + 600, 7 * m)], [a, b, c, k, m], dict=True)[0]
    return sol[a] + sol[b] + sol[c]
q("C04-A-035", T, "Three shares fixed by an equal reduction and an equal increase", "Difficult",
  "Multi-step word problem",
  r"A sum of money is divided among Ananya, Joseph and Harpreet. If each share were reduced by Rs. $300$, the shares would be in the ratio $2 : 3 : 5$. If instead each share were increased by Rs. $600$, they would be in the ratio $4 : 5 : 7$. What is the total sum?",
  "MCQ",
  r"Differences between shares never change. In $2 : 3 : 5$ Joseph exceeds Ananya by $1$ part, and in $4 : 5 : 7$ also by $1$ part, so the parts are equal, say $k$. Then Ananya $- 300 = 2k$ and Ananya $+ 600 = 4k$, so $900 = 2k$ and $k = 450$. The shares are $1200$, $1650$ and $2550$, a total of Rs. $5{,}400$ (check: $900 : 1350 : 2250 = 2 : 3 : 5$ and $1800 : 2250 : 3150 = 4 : 5 : 7$).",
  "Taking the gap between the two scenarios as Rs. $300$ or Rs. $600$ instead of Rs. $900$.",
  "C04A-addition-and-subtraction-conditions", "Must see that both ratios share the same part size, then bridge a gap of $900$; several stages.",
  correct=r"Rs. $5{,}400$",
  distractors=[(r"Rs. $2{,}400$", r"Uses a gap of Rs. $300$: $2k = 300$, $k = 150$, shares $600, 750, 1050$."),
               (r"Rs. $3{,}900$", r"Uses a gap of Rs. $600$: $2k = 600$, $k = 300$, shares $900, 1200, 1800$."),
               (r"Rs. $4{,}500$", r"Reports the total after the reduction, $10k = 4500$.")],
  check=_c35, values=[5400, 2400, 3900, 4500], exams=CX, cognitive="Analysis")


def _c36():
    rp, rq, op, oq = symbols('rp rq op oq', positive=True)
    ov_q, hr_q, dy_q = 10, 6, 5
    ov_p, hr_p, dy_p = F(4, 5) * ov_q, F(7, 6) * hr_q, F(6, 5) * dy_q
    sol = solve([Eq(op + oq, 11340), Eq(5 * op, 4 * oq),
                 Eq(op, ov_p * hr_p * dy_p * rp), Eq(oq, ov_q * hr_q * dy_q * rq)],
                [rp, rq, op, oq], dict=True)[0]
    return sol[rp]
q("C04-A-036", T, "Actual rate at one unit from component ratios, a weekly output ratio and a combined total", "Difficult",
  "Inverse/parameter",
  r"Bakery Q has $10$ ovens, each run for $6$ hours a day, $5$ days a week. Bakery P is compared with Q as follows: the numbers of ovens at P and Q are in the ratio $4 : 5$, the numbers of hours per day for which each oven runs are in the ratio $7 : 6$, and the numbers of working days per week are in the ratio $6 : 5$. Every oven at P bakes the same number of loaves per hour, and so does every oven at Q. In a week the two bakeries together bake $11{,}340$ loaves, and their weekly outputs are in the ratio $4 : 5$. How many loaves does each oven at P bake per hour?",
  "MCQ",
  r"From the ratios, P has $8$ ovens running $7$ hours a day for $6$ days, that is $8 \times 7 \times 6 = 336$ oven-hours a week (Q has $300$). Splitting $11{,}340$ in the ratio $4 : 5$ gives P a weekly output of $5040$ loaves. So each oven at P bakes $\frac{5040}{336} = 15$ loaves per hour. (Equivalently, the oven-hour ratio is $28 : 25$, so the rate ratio is $\frac{4}{5} \div \frac{28}{25} = 5 : 7$, and Q's rate is $\frac{6300}{300} = 21$.)",
  "Leaving out one of the component ratios when building P's oven-hours, or reporting Q's rate.",
  "C04A-compounded-ratio", "Three ratios must be turned into P's actual oven-hours, a combined total split in a second ratio, and the two results divided; each omitted factor gives a plausible wrong rate.",
  correct=r"$15$",
  distractors=[(r"$18$", r"Leaves out the days ratio and takes P's working week as $5$ days: $\frac{5040}{8 \times 7 \times 5} = \frac{5040}{280}$."),
               (r"$12$", r"Leaves out the ovens ratio and gives P $10$ ovens: $\frac{5040}{10 \times 7 \times 6} = \frac{5040}{420}$."),
               (r"$21$", r"Reports the rate at Q, $\frac{6300}{300}$, instead of the rate at P.")],
  check=_c36, values=[15, 18, 12, 21], exams=CX, cognitive="Analysis")


def _c37():
    t = symbols('t', positive=True)
    intended = [F(1, 2), F(1, 3), F(1, 4)]
    si = sum(intended)
    actual = [F(2, 9), F(3, 9), F(4, 9)]
    tot = solve(Eq(intended[0] / si * t - actual[0] * t, 1120), t)[0]
    return actual[2] * tot - intended[2] / si * tot
q("C04-A-037", T, "Gain of one person when a reciprocal ratio is replaced by the direct ratio", "Difficult",
  "Multi-step word problem",
  r"A sum of money was to be divided among Arjun, Sneha and Kabir in the ratio $\frac{1}{2} : \frac{1}{3} : \frac{1}{4}$, but by mistake it was divided in the ratio $2 : 3 : 4$. Arjun received Rs. $1{,}120$ less than he should have. How much more than his due did Kabir receive?",
  "MCQ",
  r"The intended ratio is $6 : 4 : 3$, so Arjun was due $\frac{6}{13}$ of the sum but got $\frac{2}{9}$. His loss is $\frac{54 - 26}{117} = \frac{28}{117}$ of the sum $=$ Rs. $1{,}120$, so the sum is Rs. $4{,}680$. Kabir was due $\frac{3}{13} \times 4680 = 1080$ and got $\frac{4}{9} \times 4680 = 2080$, a gain of Rs. $1{,}000$.",
  "Assuming Kabir gained exactly what Arjun lost, or reporting what Kabir received.",
  "C04A-ratio-changed-by-mistake", "Converting a reciprocal ratio, comparing two divisions with different part totals, and working back to the sum.",
  correct=r"Rs. $1{,}000$",
  distractors=[(r"Rs. $1{,}120$", r"Assumes Kabir's gain equals Arjun's loss, ignoring that Sneha's share also changed."),
               (r"Rs. $2{,}080$", r"Reports the amount Kabir actually received, $\frac{4}{9} \times 4680$."),
               (r"Rs. $1{,}080$", r"Reports Kabir's intended share, $\frac{3}{13} \times 4680$.")],
  check=_c37, values=[1000, 1120, 2080, 1080], exams=CX, cognitive="Analysis")


def _c38():
    for k in range(1, 1000):
        two, five = 5 * k, 2 * k
        for x in range(1, five):
            if two - x == 3 * (five - x) and 200 * (two - x) + 500 * (five - x) == 115500:
                return 2 * x
q("C04-A-038", T, "Notes paid out in equal numbers that change a count ratio, with the remaining value given", "Difficult",
  "Multi-step word problem",
  r"A cash drawer holds only Rs. $200$ and Rs. $500$ notes, and the numbers of these notes are in the ratio $5 : 2$. The cashier pays out the same number of notes of each denomination. Afterwards the numbers of Rs. $200$ and Rs. $500$ notes are in the ratio $3 : 1$, and the notes left in the drawer are worth Rs. $1{,}15{,}500$. How many notes did the cashier pay out in all?",
  "MCQ",
  r"Let there be $5k$ and $2k$ notes and let $x$ of each be paid out. Then $5k - x = 3(2k - x)$ gives $x = \frac{k}{2}$, leaving $4.5k$ and $1.5k$ notes worth $200(4.5k) + 500(1.5k) = 1650k$. So $1650k = 115500$, $k = 70$ and $x = 35$. The cashier paid out $35$ notes of each kind, $70$ notes in all.",
  "Counting the notes of only one denomination, or reporting a count of notes left.",
  "C04A-notes-equal-removal", "Equal removal changes a count ratio, and the remaining value must then be built from both denominations; three stages.",
  correct=r"$70$",
  distractors=[(r"$35$", r"Reports the notes paid out of one denomination only."),
               (r"$140$", r"Reports $2k$, the original number of Rs. $500$ notes."),
               (r"$105$", r"Reports the number of Rs. $500$ notes left, $140 - 35$.")],
  check=_c38, values=[70, 35, 140, 105], exams=CX, cognitive="Analysis")


def _c39():
    # simulate the three stages for each candidate sum and test the final condition
    for s in range(15, 100001, 15):
        ravi, kabir = F(3, 5) * s, F(2, 5) * s
        ananya, meera = F(5, 9) * ravi, F(4, 9) * ravi
        priya = kabir / 3
        gift = meera / 4
        meera, priya = meera - gift, priya + gift
        if ananya - priya == 1600:
            return s
q("C04-A-039", T, "Successive division of a sum across two generations followed by a transfer between cousins", "Difficult",
  "Multi-step word problem",
  r"Mr. Joseph divides a sum of money between his sons Ravi and Kabir in the ratio $3 : 2$. Ravi divides his entire part between his daughters Ananya and Meera in the ratio $5 : 4$, and Kabir divides his entire part equally among his three children, one of whom is Priya. Meera then gives one-quarter of the money she received to Priya. After this, Ananya has Rs. $1{,}600$ more than Priya. What was the sum, in rupees, that Mr. Joseph divided?",
  "TITA",
  r"Let the sum be $S$. Ravi gets $\frac{3S}{5}$, so Ananya gets $\frac{5}{9} \times \frac{3S}{5} = \frac{S}{3}$ and Meera gets $\frac{4S}{15}$. Kabir gets $\frac{2S}{5}$, so Priya gets $\frac{2S}{15}$. Meera gives $\frac{1}{4} \times \frac{4S}{15} = \frac{S}{15}$ to Priya, who then has $\frac{3S}{15} = \frac{S}{5}$. So $\frac{S}{3} - \frac{S}{5} = \frac{2S}{15} = 1600$, giving $S = 12000$.",
  r"Ignoring Meera's gift to Priya, or taking Ananya's part as $\frac{5}{9}$ of the whole sum instead of $\frac{5}{9}$ of Ravi's part.",
  "C04A-successive-division", "Fractions of fractions over two generations, a transfer that changes one cousin's amount, then a difference equation; four stages.",
  tita_answer=12000, check=_c39,
  tita_traps=[(8000, r"Ignores Meera's gift: $\frac{S}{3} - \frac{2S}{15} = \frac{S}{5} = 1600$."),
              (7200, r"Reports Ravi's part, $\frac{3}{5} \times 12000$."),
              (4800, r"Reports Kabir's part, $\frac{2}{5} \times 12000$.")],
  exams=CX, cognitive="Analysis")


def _c40():
    for k in range(1, 200):
        red, white = 7 * k, 5 * k
        for x in range(1, white):
            if F(red - x, white - x) != F(3, 2):
                continue
            for y in range(1, white - x):
                if F(red - x - y, white - x - y) == 2 and 2 * (x + y) == 60:
                    return red + white
q("C04-A-040", T, "Two successive equal removals and a total removed, to find the original stock", "Difficult",
  "Multi-step word problem",
  r"A florist has red and white roses in the ratio $7 : 5$. She first sells the same number of roses of each colour, after which the ratio is $3 : 2$. She then again sells the same number of roses of each colour, after which the ratio is $2 : 1$. In the two sales together she sold $60$ roses. How many roses did she have at the start?",
  "MCQ",
  r"Let her start with $7k$ red and $5k$ white, and sell $x$ of each, then $y$ of each. The difference $2k$ never changes. In $3 : 2$ it is $1$ part, so the roses become $6k$ and $4k$, giving $x = k$. In $2 : 1$ it is again $1$ part, so they become $4k$ and $2k$, giving $y = 2k$. The total sold is $2x + 2y = 6k = 60$, so $k = 10$ and she started with $12k = 120$ roses.",
  "Treating $60$ as the number sold of each colour, or using only the first sale.",
  "C04A-equal-subtraction", "Two successive equal removals tracked through a constant difference, then a total condition; three stages.",
  correct=r"$120$",
  distractors=[(r"$240$", r"Takes $60$ as the number sold of each colour: $x + y = 3k = 60$, $k = 20$."),
               (r"$60$", r"Reports the number of roses left after both sales, $120 - 60$."),
               (r"$360$", r"Uses only the first sale as the $60$ roses: $2x = 2k = 60$, $k = 30$.")],
  check=_c40, values=[120, 240, 60, 360], exams=CX, cognitive="Analysis")
