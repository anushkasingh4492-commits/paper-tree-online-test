import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from sympy.calculus.util import function_range

T = "Geometric progressions"
CX = ("CAT", "XAT")
R = Rational
F = Fraction


def _real(sols):
    return [s for s in sols if all(v.is_real for v in s.values())]


# ================================================================ EASY (13)

def _e1():
    a, r = symbols('a r', real=True)
    sols = _real(solve([a * r**2 - 18, a * r**5 - 486], [a, r], dict=True))
    vals = {simplify(s[a] * s[r]**7) for s in sols}
    assert len(vals) == 1
    return vals.pop()
q("C13-B-001", T, "Eighth term from the third and sixth terms", "Easy",
  "Single-step computation",
  r"In a geometric progression of real numbers, the third term is $18$ and the sixth term is $486$. What is the eighth term?",
  "MCQ",
  r"Dividing the two given terms, $r^3 = \frac{486}{18} = 27$, so $r = 3$. The eighth term is two steps after the sixth: $486 \times r^2 = 486 \times 9 = 4374$.",
  "Miscounting how many factors of $r$ separate two terms, or treating the sequence as arithmetic.",
  "C13B-nth-term-from-two-terms", "One division gives $r$, then one multiplication; the only trap is counting the steps between terms.",
  correct=r"$4374$",
  distractors=[(r"$1458$", r"Multiplies the sixth term by $r$ only once, giving the seventh term $486 \times 3$."),
               (r"$13122$", r"Multiplies the sixth term by $r^3$, giving the ninth term $486 \times 27$."),
               (r"$798$", r"Treats the terms as an AP: $3d = 486 - 18$, $d = 156$, eighth term $486 + 2 \times 156 = 798$.")],
  check=_e1, values=[4374, 1458, 13122, 798], cognitive="Application")


def _e2():
    knows, new = 1, 0
    for day in range(1, 6):
        new = 4 if day == 1 else 4 * new
        knows += new
    return knows
q("C13-B-002", T, "Chain message: total people reached in five days", "Easy",
  "Multi-step word problem",
  r"Kabir starts a message on day $1$ by telling it to $4$ friends. On each later day, every person who first heard the message on the previous day tells it to $4$ new people who have not heard it, and nobody else passes it on. Counting Kabir himself, how many people know the message at the end of day $5$?",
  "TITA",
  r"The numbers of new hearers on days $1$ to $5$ are $4, 16, 64, 256, 1024$, a GP with ratio $4$. Their sum is $\frac{4(4^5 - 1)}{4 - 1} = \frac{4 \times 1023}{3} = 1364$. Adding Kabir gives $1365$.",
  "Leaving out the person who started the chain, or counting only the newest hearers.",
  "C13B-finite-gp-sum-word", "A five-term GP sum set in a story; the trap is whether to include the starter.",
  tita_answer=1365, check=_e2,
  tita_traps=[(1364, "Adds the five days of new hearers but leaves out Kabir."),
              (1024, "Counts only the people who first heard it on day $5$."),
              (341, "Stops at day $4$: $1 + 4 + 16 + 64 + 256$.")],
  cognitive="Application")


def _e3():
    return sum(50 * 2**k for k in range(8))
q("C13-B-003", T, "Doubling monthly savings: total after eight months", "Easy",
  "Multi-step word problem",
  r"Meera saves Rs. $50$ in the first month and, in every later month, saves twice what she saved in the month before. What is the total amount she has saved at the end of $8$ months?",
  "MCQ",
  r"The monthly savings $50, 100, 200, \ldots$ form a GP with first term $50$ and ratio $2$. The total for $8$ months is $50(2^8 - 1) = 50 \times 255 = 12{,}750$ rupees.",
  "Using $2^8$ in place of $2^8 - 1$, or reporting a single month's saving.",
  "C13B-finite-gp-sum-word", "Direct use of the finite GP sum with ratio $2$; the trap is the $-1$ in the formula.",
  correct=r"Rs. $12{,}750$",
  distractors=[(r"Rs. $12{,}800$", r"Computes $50 \times 2^8$, dropping the $-1$ in $2^n - 1$."),
               (r"Rs. $6{,}400$", r"Reports only the eighth month's saving $50 \times 2^7$."),
               (r"Rs. $6{,}350$", r"Sums only seven months: $50(2^7 - 1)$.")],
  check=_e3, values=[12750, 12800, 6400, 6350], cognitive="Application")


def _e4():
    k = symbols('k', integer=True, positive=True)
    return 120 + 2 * Sum(120 * R(3, 4)**k, (k, 1, oo)).doit()
q("C13-B-004", T, "Bouncing ball: total distance with rebound ratio three quarters", "Easy",
  "Multi-step word problem",
  r"A ball is dropped from a height of $120$ m onto a hard floor. After each impact it rises to $\frac{3}{4}$ of the height from which it last fell. Assuming it keeps bouncing in this way indefinitely, what is the total vertical distance, in metres, that it travels?",
  "TITA",
  r"The rebound heights are $90, 67.5, \ldots$, an infinite GP with sum $\frac{90}{1 - \frac{3}{4}} = 360$ m. Each rebound height is covered twice (up and down), and the first drop of $120$ m once. Total $= 120 + 2 \times 360 = 840$ m.",
  "Covering the initial drop twice, or covering each rebound only once.",
  "C13B-bouncing-ball", "One infinite GP sum; the trap is counting the first drop once and each rebound twice.",
  tita_answer=840, check=_e4,
  tita_traps=[(960, "Doubles every height including the first drop: $2 \\times \\frac{120}{1/4}$."),
              (480, "Counts only the downward journeys: $\\frac{120}{1/4}$.")],
  cognitive="Application")


def _e5():
    r = symbols('r')
    sol = solve(Eq(12 / (1 - r), 18), r)
    assert len(sol) == 1 and abs(sol[0]) < 1
    return 12 * sol[0]
q("C13-B-005", T, "Second term of an infinite GP from its first term and sum", "Easy",
  "Single-step computation",
  r"An infinite geometric progression has first term $12$ and sum $18$. What is its second term?",
  "MCQ",
  r"From $\frac{12}{1 - r} = 18$, $1 - r = \frac{2}{3}$, so $r = \frac{1}{3}$. The second term is $12 \times \frac{1}{3} = 4$.",
  "Reading $1 - r$ as $r$, or taking the sum minus the first term as the second term.",
  "C13B-infinite-gp-basic", "One equation from the sum formula; the trap is mixing up $r$ and $1 - r$.",
  correct=r"$4$",
  distractors=[(r"$8$", r"Takes $r = \frac{2}{3}$, the value of $1 - r$, so the second term is $12 \times \frac{2}{3}$."),
               (r"$6$", r"Assumes the sum minus the first term, $18 - 12$, is the second term."),
               (r"$-4$", r"Writes the sum as $\frac{a}{1 + r}$, getting $r = -\frac{1}{3}$.")],
  check=_e5, values=[4, 8, 6, -4], cognitive="Application")


def _e6():
    t, r = symbols('t r', real=True)
    sols = _real(solve([t**3 * r**3 - 216, t * (1 + r + r**2) - 19], [t, r], dict=True))
    tops = {max(s[t], s[t] * s[r], s[t] * s[r]**2) for s in sols}
    assert len(tops) == 1
    return tops.pop()
q("C13-B-006", T, "Three numbers in GP from their product and sum", "Easy",
  "Conceptual/application",
  r"Three real numbers are in geometric progression. Their product is $216$ and their sum is $19$. The largest of the three numbers is",
  "MCQ",
  r"Write the numbers as $\frac{m}{r}, m, mr$. The product is $m^3 = 216$, so $m = 6$. Then $\frac{6}{r} + 6 + 6r = 19$ gives $6r^2 - 13r + 6 = 0$, so $r = \frac{3}{2}$ or $\frac{2}{3}$. Either way the numbers are $4, 6, 9$, and the largest is $9$.",
  "Stopping at the middle term from the product, or reporting the sum of the outer terms.",
  "C13B-three-terms-product-sum", "Symmetric choice of terms makes the product give the middle term at once; one quadratic finishes it.",
  correct=r"$9$",
  distractors=[(r"$6$", r"Stops at the middle term $m = 6$ found from the product."),
               (r"$4$", r"Solves correctly but reports the smallest number."),
               (r"$13$", r"Reports $19 - 6 = 13$, the sum of the two outer numbers.")],
  check=_e6, values=[9, 6, 4, 13], cognitive="Application")


def _e7():
    total, day, add = 0, 0, 5
    while total < 5115:
        day += 1
        total += add
        add *= 2
    assert total == 5115
    return day
q("C13-B-007", T, "Number of days for a doubling collection to reach a given total", "Easy",
  "Inverse/parameter",
  r"Joseph starts an empty stamp album and adds $5$ stamps on day $1$, $10$ stamps on day $2$, $20$ stamps on day $3$, and so on, doubling the number added each day. At the end of which day does the album hold exactly $5115$ stamps? Type the day number.",
  "TITA",
  r"After $n$ days the album holds $5(2^n - 1)$ stamps. Setting $5(2^n - 1) = 5115$ gives $2^n - 1 = 1023$, so $2^n = 1024 = 2^{10}$ and $n = 10$.",
  "Typing the power $2^n$ or $2^n - 1$ in place of $n$.",
  "C13B-number-of-terms", "Finite GP sum inverted for $n$; a single power of $2$ to recognise.",
  tita_answer=10, check=_e7,
  tita_traps=[(1024, "Types the value of $2^n$ rather than $n$."),
              (1023, "Types the value of $2^n - 1$.")],
  cognitive="Application")


def _e8():
    r = symbols('r', positive=True)
    rr = solve(Eq(2 * r**4, 162), r)
    assert len(rr) == 1
    rr = rr[0]
    return 2 * rr + 2 * rr**2 + 2 * rr**3
q("C13-B-008", T, "Sum of three positive geometric means between two numbers", "Easy",
  "Single-step computation",
  r"Three positive numbers are inserted between $2$ and $162$ so that the five numbers, in order, form a geometric progression. What is the sum of the three inserted numbers?",
  "MCQ",
  r"The fifth term is $2r^4 = 162$, so $r^4 = 81$ and, since the terms are positive, $r = 3$. The inserted numbers are $6, 18, 54$, with sum $78$.",
  "Including the end numbers, inserting arithmetic means, or treating the GP like an AP when summing the means.",
  "C13B-geometric-means-insertion", "One root extraction and three terms; the trap is mixing up AP and GP means.",
  correct=r"$78$",
  distractors=[(r"$242$", r"Adds the end numbers too: $2 + 6 + 18 + 54 + 162$."),
               (r"$246$", r"Inserts arithmetic means $42, 82, 122$ in place of geometric means."),
               (r"$54$", r"Uses the AP shortcut (three means sum to three times the middle one): $3 \times 18$.")],
  check=_e8, values=[78, 242, 246, 54], cognitive="Application")


def _e9():
    r = symbols('r', positive=True)
    rr = solve(Eq(4 * r**3, 108), r)[0]
    return sum(4 * rr**k for k in range(5))
q("C13-B-009", T, "Sum of five terms given the first and fourth terms", "Easy",
  "Single-step computation",
  r"The first term of a geometric progression of positive terms is $4$ and its fourth term is $108$. What is the sum of its first five terms?",
  "TITA",
  r"$4r^3 = 108$ gives $r^3 = 27$, so $r = 3$. Then $S_5 = \frac{4(3^5 - 1)}{3 - 1} = 2 \times 242 = 484$. (Check: $4 + 12 + 36 + 108 + 324 = 484$.)",
  "Summing the wrong number of terms or dropping the $-1$ in $r^n - 1$.",
  "C13B-nth-term-from-two-terms", "Find $r$ from two terms, then one sum formula.",
  tita_answer=484, check=_e9,
  tita_traps=[(160, "Sums only four terms: $4 + 12 + 36 + 108$."),
              (486, "Computes $\\frac{4 \\times 3^5}{2}$, dropping the $-1$.")],
  cognitive="Application")


def _e10():
    k = symbols('k', integer=True, nonnegative=True)
    side = 12
    area_ratio = (1 / sqrt(2))**2
    return simplify(Sum(side**2 * area_ratio**k, (k, 0, oo)).doit())
q("C13-B-010", T, "Nested squares by joining midpoints: total area", "Easy",
  "Conceptual/application",
  r"A square has side $12$ cm. A second square is drawn by joining the midpoints of the sides of the first, a third by joining the midpoints of the sides of the second, and so on without end. What is the sum of the areas of all the squares, including the first?",
  "MCQ",
  r"Joining midpoints gives a square whose side is $\frac{1}{\sqrt{2}}$ times the previous side, so each area is half the previous one. The areas form a GP $144, 72, 36, \ldots$ with sum $\frac{144}{1 - \frac{1}{2}} = 288$ cm$^2$.",
  "Taking the new side as half the old side, or excluding the first square.",
  "C13B-nested-figures-infinite", "Needs the area ratio $\\frac{1}{2}$ from the midpoint construction, then an infinite sum.",
  correct=r"$288$ cm$^2$",
  distractors=[(r"$192$ cm$^2$", r"Takes each new side as half the old, so the area ratio is $\frac{1}{4}$: $\frac{144}{3/4} = 192$."),
               (r"$216$ cm$^2$", r"Takes the area ratio as $\frac{1}{3}$, so the sum is $\frac{144}{1 - 1/3} = \frac{144}{2/3} = 216$."),
               (r"$576$ cm$^2$", r"Thinks one quarter of the area is cut off each time, ratio $\frac{3}{4}$: $\frac{144}{1/4} = 576$.")],
  check=_e10, values=[288, 192, 216, 576], cognitive="Understanding")


def _e11():
    a, d = symbols('a d', nonzero=True)
    sols = [s for s in solve(Eq((a + d)**2, a * (a + 4 * d)), d) if s != 0]
    assert len(sols) == 1
    return simplify((a + sols[0]) / a)
q("C13-B-011", T, "AP whose first, second and fifth terms are in GP", "Easy",
  "Inverse/parameter",
  r"In an arithmetic progression with a non-zero common difference, the first, second and fifth terms, in that order, are in geometric progression. What is the common ratio of this geometric progression?",
  "MCQ",
  r"With first term $a$ and difference $d$: $(a + d)^2 = a(a + 4d)$ gives $d^2 = 2ad$, and as $d \neq 0$, $d = 2a$. The three terms are $a, 3a, 9a$, so the common ratio is $3$.",
  "Reporting $\\frac{d}{a}$ or $r^2$, or miscounting the position of the fifth term.",
  "C13B-ap-terms-in-gp", "One quadratic condition linking $a$ and $d$; the trap is what to report.",
  correct=r"$3$",
  distractors=[(r"$2$", r"Stops at $d = 2a$ and reports $\frac{d}{a}$."),
               (r"$9$", r"Reports the ratio of the fifth term to the first, which is $r^2$."),
               (r"$4$", r"Writes the fifth term as $a + 5d$, getting $d = 3a$ and terms $a, 4a, 16a$.")],
  check=_e11, values=[3, 2, 9, 4], cognitive="Application")


def _e12():
    r = symbols('r', positive=True)
    a = 3 / r**3
    p = 1
    for k in range(7):
        p *= a * r**k
    return simplify(p)
q("C13-B-012", T, "Product of seven terms from the middle term", "Easy",
  "Conceptual/application",
  r"The fourth term of a geometric progression is $3$. What is the product of its first seven terms?",
  "TITA",
  r"Terms equidistant from the fourth term multiply to its square: $t_1 t_7 = t_2 t_6 = t_3 t_5 = t_4^2 = 9$. So the product is $9^3 \times 3 = 3^7 = 2187$.",
  "Multiplying the middle term by the number of terms, or forgetting the middle term itself.",
  "C13B-product-of-terms", "One symmetry idea (pairing terms around the middle) replaces finding $a$ and $r$.",
  tita_answer=2187, check=_e12,
  tita_traps=[(21, "Multiplies $3$ by $7$, as if summing an AP."),
              (729, "Pairs the six outer terms to get $9^3$ but forgets the middle term.")],
  cognitive="Understanding")


def _e13():
    t, n = F(1, 10), 0
    while t <= 1000:
        t *= 2
        n += 1
    return n
q("C13-B-013", T, "Folding paper: least number of doublings to pass a thickness", "Easy",
  "Inverse/parameter",
  r"A sheet of paper is $0.1$ mm thick. Each time it is folded in half, its thickness doubles. What is the least number of folds after which the thickness exceeds $1$ m?",
  "MCQ",
  r"$1$ m $= 1000$ mm, so we need $0.1 \times 2^n > 1000$, that is $2^n > 10{,}000$. Since $2^{13} = 8192$ and $2^{14} = 16{,}384$, the least $n$ is $14$.",
  "Taking the last power below the target, or slipping when converting metres to millimetres.",
  "C13B-doubling-threshold", "Unit conversion followed by locating a power of $2$; trap at the boundary.",
  correct=r"$14$",
  distractors=[(r"$13$", r"Takes the largest $n$ with $2^n < 10{,}000$, that is $2^{13} = 8192$."),
               (r"$10$", r"Uses $1$ m $= 100$ mm, so $2^n > 1000$ and $n = 10$."),
               (r"$17$", r"Uses $1$ m $= 10{,}000$ mm, so $2^n > 100{,}000$ and $n = 17$.")],
  check=_e13, values=[14, 13, 10, 17], cognitive="Application")


# ================================================================ MEDIUM (21)

def _m1():
    a, r = symbols('a r')
    S = lambda n: sum(a * r**k for k in range(n))
    sols = [s for s in solve(Eq(S(6), 28 * S(3)), r) if s.is_real and s != 1]
    vals = {simplify(s**6) for s in sols}
    assert len(vals) == 1
    return vals.pop()
q("C13-B-014", T, "Ratio of the seventh term to the first from S6 = 28 S3", "Medium",
  "Conceptual/application",
  r"In a geometric progression of real numbers, the sum of the first six terms is $28$ times the sum of the first three terms. The seventh term is how many times the first term?",
  "MCQ",
  r"The terms $4$ to $6$ are the terms $1$ to $3$ each multiplied by $r^3$, so $S_6 = S_3(1 + r^3)$. Hence $1 + r^3 = 28$, $r^3 = 27$, $r = 3$. The seventh term is $r^6 = 729$ times the first.",
  "Equating $r^3$ to the full ratio $\\frac{S_6}{S_3}$, or miscounting the power of $r$ for the seventh term.",
  "C13B-ratio-of-partial-sums", "Needs the block idea $S_6 = S_3(1 + r^3)$ rather than two sum formulas.",
  correct=r"$729$",
  distractors=[(r"$784$", r"Sets $r^3 = \frac{S_6}{S_3} = 28$, so $r^6 = 784$."),
               (r"$243$", r"Takes the seventh term as $a r^5$, giving $3^5$."),
               (r"$2187$", r"Takes the seventh term as $a r^7$, giving $3^7$.")],
  check=_m1, values=[729, 784, 243, 2187], cognitive="Understanding")


def _m2():
    a, r = symbols('a r', positive=True)
    S = lambda n: sum(a * r**k for k in range(n))
    sols = solve([S(4) - 40, S(8) - 3280], [a, r], dict=True)
    vals = {s[a] * s[r]**5 for s in sols}
    assert len(vals) == 1
    return vals.pop()
q("C13-B-015", T, "Sixth term from the sums of four and eight terms", "Medium",
  "Multi-step word problem",
  r"A geometric progression has positive terms. The sum of its first four terms is $40$ and the sum of its first eight terms is $3280$. What is its sixth term?",
  "TITA",
  r"$S_8 = S_4(1 + r^4)$, so $1 + r^4 = 82$, $r^4 = 81$ and $r = 3$ (positive terms). Then $a(1 + 3 + 9 + 27) = 40$ gives $a = 1$. The sixth term is $3^5 = 243$.",
  "Miscounting the power of $r$ in the sixth term.",
  "C13B-ratio-of-partial-sums", "Two sums combined through $S_8 = S_4(1 + r^4)$, then back-substitution.",
  tita_answer=243, check=_m2,
  tita_traps=[(81, "Takes the sixth term as $a r^4$."),
              (729, "Takes the sixth term as $a r^6$.")],
  cognitive="Application")


def _m3():
    a, r = symbols('a r', real=True)
    sols = [s for s in solve([a / (1 - r) - 20, a**2 / (1 - r**2) - 100], [a, r], dict=True) if abs(s[r]) < 1]
    assert len(sols) == 1
    return sols[0][a]
q("C13-B-016", T, "First term of an infinite GP from its sum and the sum of squares", "Medium",
  "Multi-step word problem",
  r"The sum of an infinite geometric progression is $20$ and the sum of the squares of its terms is $100$. What is its first term?",
  "MCQ",
  r"$\frac{a}{1 - r} = 20$ and the squares form a GP with ratio $r^2$, so $\frac{a^2}{1 - r^2} = 100$. Dividing, $\frac{a}{1 + r} = 5$. So $20(1 - r) = 5(1 + r)$, giving $r = \frac{3}{5}$ and $a = 20 \times \frac{2}{5} = 8$.",
  "Using $1 - r$ in place of $1 - r^2$ for the squares, or confusing the first term with a sum.",
  "C13B-infinite-gp-squares", "Two infinite sums divided to eliminate one unknown.",
  correct=r"$8$",
  distractors=[(r"$5$", r"Writes the sum of squares as $\frac{a^2}{1 - r}$; dividing by $\frac{a}{1 - r}$ then gives $a = 5$."),
               (r"$12$", r"Reports $20 - 8 = 12$, the sum of all the terms after the first."),
               (r"$10$", r"Takes the first term as $\sqrt{100}$.")],
  check=_m3, values=[8, 5, 12, 10], cognitive="Application")


def _m5():
    H = symbols('H', positive=True)
    dist, h, strikes = H, H, 1
    while strikes < 4:
        h = h * R(2, 3)
        dist += 2 * h
        strikes += 1
    return solve(Eq(dist, 206), H)[0]
q("C13-B-017", T, "Bouncing ball: initial height from distance up to the fourth impact", "Medium",
  "Inverse/parameter",
  r"A ball is dropped from a height of $H$ metres. After each impact it rises to $\frac{2}{3}$ of the height from which it last fell. When it strikes the ground for the fourth time, it has travelled a total distance of $206$ m. What is $H$, in metres?",
  "TITA",
  r"Up to the fourth impact the ball makes the first drop $H$ and three complete rebounds (up and down) of heights $\frac{2}{3}H, \frac{4}{9}H, \frac{8}{27}H$. Distance $= H + 2H \cdot \frac{18 + 12 + 8}{27} = H + \frac{76}{27}H = \frac{103}{27}H$. Setting this to $206$ gives $H = 54$.",
  "Counting the wrong number of rebounds before the fourth impact.",
  "C13B-bouncing-ball", "Must count impacts against rebounds correctly, then invert a partial GP sum.",
  tita_answer=54, check=_m5,
  tita_traps=[(36, "Solves for $H = 54$ correctly but types the first rebound height $54 \\times \\frac{2}{3}$."),
              (24, "Solves for $H = 54$ correctly but types the second rebound height $54 \\times \\frac{4}{9}$.")],
  cognitive="Analysis")


def _m6():
    d = symbols('d', real=True)
    good = []
    for dv in solve(Eq((11 - d) * (15 + d), 144), d):
        nums = [10 - dv, 10, 10 + dv]
        if nums[0] < nums[1] < nums[2]:
            g = [nums[0] + 1, nums[1] + 2, nums[2] + 5]
            assert g[1] ** 2 == g[0] * g[2] and g[0] != 0
            good.append(max(nums))
    assert len(good) == 1
    return good[0]
q("C13-B-018", T, "Increasing AP that becomes a GP after adding fixed numbers", "Medium",
  "Casework/optimisation",
  r"Three numbers are in increasing arithmetic progression and their sum is $30$. If $1$, $2$ and $5$ are added to them respectively, the resulting numbers are in geometric progression. What is the largest of the original three numbers?",
  "MCQ",
  r"Take the numbers as $10 - d, 10, 10 + d$. After adding, $11 - d, 12, 15 + d$ are in GP: $(11 - d)(15 + d) = 144$, so $d^2 + 4d - 21 = 0$, giving $d = 3$ or $d = -7$. The root $d = -7$ gives the decreasing progression $17, 10, 3$, which the stem rules out. So $d = 3$, the numbers are $7, 10, 13$ (becoming $8, 12, 18$), and the largest is $13$.",
  "Keeping the root that gives a decreasing progression, since both roots give positive numbers.",
  "C13B-ap-modified-to-gp", "Quadratic with two roots that both give valid-looking numbers; only the word increasing selects one.",
  correct=r"$13$",
  distractors=[(r"$17$", r"Uses the root $d = -7$; the numbers $17, 10, 3$ (becoming $18, 12, 8$) also give a GP, but the progression is decreasing."),
               (r"$18$", r"Reports the largest term of the new GP $8, 12, 18$."),
               (r"$12$", r"Reports the middle term of the new GP $8, 12, 18$.")],
  check=_m6, values=[13, 17, 18, 12], cognitive="Analysis")


def _m8():
    n = 0
    while True:
        n += 1
        if 2**n - 1 > 10000 * n:
            return n
q("C13-B-019", T, "Doubling payments overtaking a fixed daily payment", "Medium",
  "Inverse/parameter",
  r"Arjun can choose between two payment plans that run day by day. Under Plan P he receives Rs. $10{,}000$ every day. Under Plan Q he receives Rs. $1$ on day $1$, Rs. $2$ on day $2$, Rs. $4$ on day $3$, and so on, the daily amount doubling each day. At the end of which day does his total under Plan Q first exceed his total under Plan P? Type the day number.",
  "TITA",
  r"After $n$ days, Plan Q has paid $1 + 2 + \cdots + 2^{n-1} = 2^n - 1$ and Plan P has paid $10{,}000n$. At $n = 17$: $131{,}071 < 170{,}000$. At $n = 18$: $262{,}143 > 180{,}000$. For smaller $n$, Plan Q is even further behind (at $n = 16$ it is $65{,}535$ against $160{,}000$). So the answer is day $18$.",
  "Comparing the daily payments rather than the running totals.",
  "C13B-growth-comparison", "Compares a GP sum with a linear total; needs testing near the crossover.",
  tita_answer=18, check=_m8,
  tita_traps=[(15, "Compares daily amounts: $2^{14} = 16{,}384$ is the first daily payment above $10{,}000$, paid on day $15$."),
              (17, "Takes Plan Q's total after $n$ days as $2^{n+1} - 1$.")],
  cognitive="Analysis")


def _m9():
    ap = set(range(5, 2**20 + 1, 3))
    return sum(1 for k in range(1, 21) if 2**k in ap)
q("C13-B-020", T, "Terms common to a GP of powers of 2 and an AP", "Medium",
  "Casework/optimisation",
  r"Consider the $20$ terms $2, 4, 8, \ldots, 2^{20}$ of a geometric progression, and the arithmetic progression $5, 8, 11, 14, \ldots$ continued indefinitely. How many of the $20$ terms of the geometric progression are also terms of the arithmetic progression?",
  "TITA",
  r"The AP consists of the numbers from $5$ upward that leave remainder $2$ on division by $3$. Since $2 \equiv -1 \pmod 3$, $2^k$ leaves remainder $2$ exactly when $k$ is odd. Odd $k$ from $1$ to $19$ give $10$ values, but $2^1 = 2$ is below $5$. So $9$ terms are common.",
  "Counting $2$ itself, which is smaller than the first term of the AP.",
  "C13B-common-terms-ap-gp", "Needs a remainder pattern of powers of $2$ plus a check at the start of the AP.",
  tita_answer=9, check=_m9,
  tita_traps=[(10, "Counts every odd power, including $2^1 = 2$, which is not in the AP."),
              (19, "Counts every power from $2^2$ to $2^{20}$ as lying in the AP.")],
  cognitive="Analysis")


def _m10():
    r = symbols('r', real=True)
    roots = set()
    for n in (2, 4, 6, 8):
        allsum = sum(r**k for k in range(n))
        odd = sum(r**k for k in range(0, n, 2))
        roots |= set(solve(Eq(allsum, 5 * odd), r))
    assert len(roots) == 1
    return roots.pop()
q("C13-B-021", T, "Common ratio from total sum versus odd-position sum", "Medium",
  "Conceptual/application",
  r"A geometric progression of real numbers has an even number of terms. The sum of all its terms is $5$ times the sum of the terms in the odd positions (first, third, fifth, and so on). What is its common ratio?",
  "MCQ",
  r"Pair each odd-position term with the term after it: every even-position term is $r$ times the odd-position term before it, and there are equally many of each. So the even-position sum is $r$ times the odd-position sum, and the total is $(1 + r)$ times the odd-position sum. Hence $1 + r = 5$ and $r = 4$.",
  "Equating the even-position sum (rather than the total) to five times the odd sum, or inverting the relation.",
  "C13B-odd-even-placed-terms", "Insight that the even-position terms are the odd-position terms scaled by $r$.",
  correct=r"$4$",
  distractors=[(r"$5$", r"Reads the condition as the even-position sum being $5$ times the odd-position sum."),
               (r"$\frac{1}{4}$", r"Writes the odd-position sum as $r$ times the even-position sum, so $1 + \frac{1}{r} = 5$."),
               (r"$2$", r"Takes the even-position sum as $r^2$ times the odd-position sum, so $1 + r^2 = 5$.")],
  check=_m10, values=[4, 5, R(1, 4), 2], cognitive="Understanding")


def _m11():
    a, r = symbols('a r', real=True)
    sols = [s for s in solve([a / (1 - r) - 36, a / (1 - r**2) - 27], [a, r], dict=True) if abs(s[r]) < 1]
    assert len(sols) == 1
    return sols[0][a]
q("C13-B-022", T, "Infinite GP: first term from total and odd-position sums", "Medium",
  "Conceptual/application",
  r"The sum of an infinite geometric progression is $36$, and the sum of its terms in the odd positions (first, third, fifth, and so on) is $27$. What is the first term of the progression?",
  "TITA",
  r"The even-position terms are the odd-position terms each multiplied by $r$, so the total is $(1 + r) \times 27 = 36$, giving $r = \frac{1}{3}$. Then $a = 36(1 - r) = 36 \times \frac{2}{3} = 24$.",
  "Using the ratio $r$ instead of $r^2$ for the odd-position terms.",
  "C13B-odd-even-placed-terms", "Split of an infinite GP into two GPs with ratio $r^2$; two short steps.",
  tita_answer=24, check=_m11,
  tita_traps=[(9, "Reports $36 - 27$, the sum of the even-position terms."),
              (18, "Writes the odd-position sum as $\\frac{a}{1 - r}$ with $r = \\frac{1}{3}$, so $a = 27 \\times \\frac{2}{3}$.")],
  cognitive="Understanding")


def _m12():
    a, r = symbols('a r', positive=True)
    aa = 189 * (r - 1) / (r**6 - 1)
    poly = Poly(numer(together(aa**2 * r**5 - 288)), r)
    vals = set()
    for root in real_roots(poly):
        if root > 0 and root != 1:
            av = aa.subs(r, root)
            terms = [av * root**k for k in range(6)]
            assert abs(N(sum(terms) - 189)) < 1e-9
            vals.add(nsimplify(N(sum(1 / t for t in terms), 40)))
    assert len(vals) == 1
    return vals.pop()
q("C13-B-023", T, "Sum of reciprocals from the sum and first-last product", "Medium",
  "Conceptual/application",
  r"A geometric progression of positive terms has $6$ terms. Their sum is $189$ and the product of the first and last terms is $288$. What is the sum of the reciprocals of the six terms?",
  "MCQ",
  r"In a GP, $t_k \cdot t_{7-k} = t_1 t_6 = 288$ for each $k$, so $\frac{1}{t_k} = \frac{t_{7-k}}{288}$. Adding over all six terms, the sum of reciprocals is $\frac{189}{288} = \frac{21}{32}$. (The GP is $3, 6, 12, 24, 48, 96$.)",
  "Dividing the sum by the wrong quantity.",
  "C13B-reciprocal-sum", "The identity (sum of reciprocals) $= \\frac{S}{t_1 t_n}$ avoids solving for $a$ and $r$.",
  correct=r"$\frac{21}{32}$",
  distractors=[(r"$\frac{32}{21}$", r"Divides the product by the sum: $\frac{288}{189}$."),
               (r"$\frac{21}{11}$", r"Solves for the terms and divides the sum by $t_1 + t_6 = 3 + 96 = 99$: $\frac{189}{99}$."),
               (r"$\frac{63}{32}$", r"Divides the sum by the last term $96$ alone: $\frac{189}{96}$.")],
  check=_m12, values=[R(21, 32), R(32, 21), R(21, 11), R(63, 32)], cognitive="Understanding")


def _m13():
    r = symbols('r', positive=True)
    rr = solve(Eq(r**3, 64), r)[0]
    t, count = rr, 0
    while t < 4096:
        count += 1
        t *= rr
    assert t == 4096
    return count
q("C13-B-024", T, "Number of geometric means from one known mean", "Medium",
  "Inverse/parameter",
  r"Some positive numbers are inserted between $1$ and $4096$ so that all the numbers, in order, form a geometric progression. The third of the inserted numbers is $64$. How many numbers are inserted?",
  "MCQ",
  r"The inserted numbers are $r, r^2, r^3, \ldots$, so $r^3 = 64$ and $r = 4$. Since $4096 = 4^6$, the progression is $4^0, 4^1, \ldots, 4^6$, and the inserted numbers are $4^1$ to $4^5$: $5$ numbers.",
  "Counting the end numbers, or treating $64$ as the third term of the whole progression.",
  "C13B-geometric-means-insertion", "Two inferences: ratio from one mean, then count of terms; the trap is counting.",
  correct=r"$5$",
  distractors=[(r"$6$", r"Counts the steps $4^0 \to 4^6$ (six multiplications by $r$) as the number of inserted numbers."),
               (r"$7$", r"Counts all terms $4^0$ to $4^6$, including the ends."),
               (r"$3$", r"Treats $64$ as the third term overall, so $r^2 = 64$, $r = 8$, $4096 = 8^4$, giving $3$ inserted numbers.")],
  check=_m13, values=[5, 6, 7, 3], cognitive="Application")


def _m14():
    r = symbols('r')
    roots = solve(Eq(7 * (1 + r + r**2), 91), r)
    return sum(7 * x**3 for x in roots)
q("C13-B-025", T, "Two possible ratios from the sum of three terms", "Medium",
  "Casework/optimisation",
  r"The first term of a geometric progression of real numbers is $7$ and the sum of its first three terms is $91$. What is the sum of all possible values of its fourth term?",
  "MCQ",
  r"$7(1 + r + r^2) = 91$ gives $r^2 + r - 12 = 0$, so $r = 3$ or $r = -4$. The fourth term $7r^3$ is $189$ or $-448$. Their sum is $-259$.",
  "Ignoring the negative ratio, which also satisfies every condition.",
  "C13B-ratio-from-partial-sum", "Quadratic in $r$ with two valid roots; the trap is discarding the negative ratio.",
  correct=r"$-259$",
  distractors=[(r"$189$", r"Keeps only the positive ratio $r = 3$."),
               (r"$-448$", r"Keeps only the negative ratio $r = -4$."),
               (r"$637$", r"Adds the sizes $189 + 448$, dropping the sign of $(-4)^3$.")],
  check=_m14, values=[-259, 189, -448, 637], cognitive="Analysis")


def _m15():
    total, day, amt = F(0), 0, F(1600)
    while total <= 50000:
        day += 1
        total += amt
        amt *= F(3, 2)
    return day
q("C13-B-026", T, "Day on which a growing collection's running total passes a target", "Medium",
  "Multi-step word problem",
  r"A charity drive collects Rs. $1{,}600$ on day $1$, and on each later day collects $1.5$ times the amount collected the previous day. On which day does the total collected first exceed Rs. $50{,}000$? Type the day number.",
  "TITA",
  r"The total after $n$ days is $\frac{1600(1.5^n - 1)}{0.5} = 3200(1.5^n - 1)$. This exceeds $50{,}000$ when $1.5^n > 16.625$. Since $1.5^6 \approx 11.39$ and $1.5^7 \approx 17.09$, the answer is day $7$ (running totals: $33{,}250$ after day $6$, $51{,}475$ after day $7$).",
  "Comparing a single day's collection with the target instead of the running total.",
  "C13B-number-of-terms", "Finite GP sum with ratio $\\frac{3}{2}$ compared with a target; powers of $1.5$ must be bracketed.",
  tita_answer=7, check=_m15,
  tita_traps=[(10, "Compares the day's collection $1600 \\times 1.5^{n-1}$ with $50{,}000$."),
              (6, "Uses $1.5^{n+1}$ in the sum formula.")],
  cognitive="Application")


def _m16():
    k = symbols('k', integer=True, nonnegative=True)
    return simplify(Sum(80 * (1 / sqrt(2))**k, (k, 0, oo)).doit())
q("C13-B-027", T, "Nested squares by joining midpoints: total perimeter", "Medium",
  "Multi-step word problem",
  r"A square has side $20$ cm. A second square is formed by joining the midpoints of its sides, a third by joining the midpoints of the sides of the second, and so on without end. What is the sum of the perimeters of all the squares, including the first?",
  "MCQ",
  r"Each new side is $\frac{1}{\sqrt{2}}$ times the previous side, so the perimeters $80, \frac{80}{\sqrt{2}}, \ldots$ form a GP with ratio $\frac{1}{\sqrt{2}}$. The sum is $\frac{80}{1 - \frac{1}{\sqrt{2}}} = \frac{80\sqrt{2}}{\sqrt{2} - 1} = 80\sqrt{2}(\sqrt{2} + 1) = 160 + 80\sqrt{2}$ cm.",
  "Slips in rationalising, or using the sum formula with the wrong sign.",
  "C13B-nested-figures-infinite", "Infinite GP with a surd ratio; rationalising the answer is where errors occur.",
  correct=r"$(160 + 80\sqrt{2})$ cm",
  distractors=[(r"$(80 + 80\sqrt{2})$ cm", r"Leaves out the first square: $\frac{80/\sqrt{2}}{1 - 1/\sqrt{2}} = \frac{80}{\sqrt{2} - 1}$."),
               (r"$(80 + 40\sqrt{2})$ cm", r"Multiplies the numerator by $1 + \frac{1}{\sqrt{2}}$ but does not divide by the new denominator $\frac{1}{2}$."),
               (r"$(160 + 160\sqrt{2})$ cm", r"Writes $1 - \frac{1}{\sqrt{2}}$ as $\frac{\sqrt{2} - 1}{2}$, so the sum becomes $\frac{160}{\sqrt{2} - 1} = 160(\sqrt{2} + 1)$.")],
  check=_m16, values=[160 + 80 * sqrt(2), 80 + 80 * sqrt(2), 80 + 40 * sqrt(2), 160 + 160 * sqrt(2)],
  cognitive="Application")


def _m17():
    d = symbols('d')
    a = 4
    ds = [x for x in solve(Eq((a + 6 * d)**2, (a + 2 * d) * (a + 14 * d)), d) if x != 0]
    assert len(ds) == 1
    dv = ds[0]
    return sum(a + k * dv for k in range(20))
q("C13-B-028", T, "AP whose third, seventh and fifteenth terms are in GP", "Medium",
  "Multi-step word problem",
  r"An arithmetic progression has first term $4$ and a non-zero common difference. Its third, seventh and fifteenth terms, in that order, are in geometric progression. What is the sum of the first $20$ terms of the arithmetic progression?",
  "TITA",
  r"$(4 + 6d)^2 = (4 + 2d)(4 + 14d)$ gives $16 + 48d + 36d^2 = 16 + 64d + 28d^2$, so $8d^2 = 16d$ and $d = 2$. (The terms are $8, 16, 32$.) Then $S_{20} = \frac{20}{2}(2 \times 4 + 19 \times 2) = 10 \times 46 = 460$.",
  "Expansion slips in the GP condition.",
  "C13B-ap-terms-in-gp", "GP condition on AP terms gives $d$, then an AP sum; two linked stages.",
  tita_answer=460, check=_m17,
  tita_traps=[(270, "Drops the $8d$ cross term when expanding $(4 + 2d)(4 + 14d)$, getting $d = 1$."),
              (80, "Takes $d = 0$, which the stem rules out.")],
  cognitive="Application")


def _m18():
    x = symbols('x', real=True)
    r = (2 * x - 1) / 3
    conv = solve_univariate_inequality(Abs(r) < 1, x, relational=False)
    return function_range(1 / (1 - r), x, conv)
q("C13-B-029", T, "Set of possible sums of an infinite GP with a variable ratio", "Medium",
  "Conceptual/application",
  r"For real $x$, consider the infinite series $1 + \frac{2x - 1}{3} + \left(\frac{2x - 1}{3}\right)^2 + \left(\frac{2x - 1}{3}\right)^3 + \cdots$. Taken over all values of $x$ for which the series converges, the set of all possible values of its sum is",
  "MCQ",
  r"The ratio $r = \frac{2x - 1}{3}$ must satisfy $-1 < r < 1$, that is $-1 < x < 2$, and $r$ then takes every value in $(-1, 1)$. The sum is $\frac{1}{1 - r}$ with $1 - r$ ranging over $(0, 2)$, so the sum ranges over $\left(\frac{1}{2}, \infty\right)$. The value $\frac{1}{2}$ would need $r = -1$, which is excluded.",
  "Including the endpoint $r = -1$, or reporting the range of $x$ instead of the range of the sum.",
  "C13B-infinite-gp-convergence", "Needs the convergence condition and the map from $r$ to $\\frac{1}{1-r}$, including open endpoints.",
  correct=r"$\left(\frac{1}{2}, \infty\right)$",
  distractors=[(r"$\left[\frac{1}{2}, \infty\right)$", r"Allows $r = -1$, where the series does not converge, to include $\frac{1}{2}$."),
               (r"$(0, \infty)$", r"Assumes the sum can be any positive number."),
               (r"$(-1, 2)$", r"Reports the set of $x$ for which the series converges.")],
  check=_m18, values=[Interval.open(R(1, 2), oo), Interval(R(1, 2), oo), Interval.open(0, oo), Interval.open(-1, 2)],
  cognitive="Understanding")


def _m19():
    r = symbols('r')
    rr = solve(Eq(9 / (1 - r), 6), r)[0]
    assert abs(rr) < 1
    return sum(9 * rr**k for k in range(4))
q("C13-B-030", T, "Sum of four terms of an infinite GP with negative ratio", "Medium",
  "Multi-step word problem",
  r"An infinite geometric progression has first term $9$ and sum $6$. What is the sum of its first four terms?",
  "MCQ",
  r"$\frac{9}{1 - r} = 6$ gives $1 - r = \frac{3}{2}$, so $r = -\frac{1}{2}$. Then $S_4 = \frac{9(1 - r^4)}{1 - r} = 6\left(1 - \frac{1}{16}\right) = \frac{45}{8}$. (Terms: $9 - 4.5 + 2.25 - 1.125$.)",
  "Missing that the ratio is negative, or sign slips with $r^4$.",
  "C13B-infinite-gp-basic", "The sum smaller than the first term forces a negative ratio; then a partial sum.",
  correct=r"$\frac{45}{8}$",
  distractors=[(r"$\frac{51}{8}$", r"Computes $6\left(1 + \frac{1}{16}\right)$, a sign slip with $r^4$."),
               (r"$\frac{135}{8}$", r"Takes $r = +\frac{1}{2}$: $\frac{9(1 - 1/16)}{1/2}$."),
               (r"$\frac{27}{4}$", r"Sums only three terms: $9 - 4.5 + 2.25$.")],
  check=_m19, values=[R(45, 8), R(51, 8), R(135, 8), R(27, 4)], cognitive="Application")


def _m20():
    stake, net = 50, 0
    for rnd in range(1, 8):
        if rnd <= 6:
            net -= stake
            stake *= 2
        else:
            net += stake
    return net
q("C13-B-031", T, "Doubling the stake after each loss: net result", "Medium",
  "Conceptual/application",
  r"Priya plays a game in rounds. In each round she stakes some money: if she loses the round she loses her stake, and if she wins she gets back her stake plus an equal amount. She stakes Rs. $50$ in round $1$ and, after every loss, doubles her stake for the next round. She loses rounds $1$ to $6$, wins round $7$, and then stops. What is her net gain?",
  "MCQ",
  r"Her losses are $50 + 100 + \cdots + 1600 = 50(2^6 - 1) = 3150$. In round $7$ she stakes $50 \times 2^6 = 3200$ and wins, gaining $3200$. Net gain $= 3200 - 3150 = 50$ rupees, which is just the first stake.",
  "Counting the returned stake as profit, or forgetting the earlier losses.",
  "C13B-doubling-strategy", "Compare a power of $2$ with the GP sum of all earlier powers.",
  correct=r"Rs. $50$",
  distractors=[(r"Rs. $3{,}250$", r"Counts the full amount received in round $7$, $6400$, as gain and subtracts only the losses $3150$."),
               (r"Rs. $3{,}200$", r"Counts the winning gain of round $7$ and ignores the six losses."),
               (r"Rs. $0$", r"Takes the total of the six losses as $50 \times 2^6 = 3200$.")],
  check=_m20, values=[50, 3250, 3200, 0], cognitive="Understanding")


def _m21():
    a, r = symbols('a r', positive=True)
    sols = [s for s in solve([a - 6 * a * r / (1 - r), a + a * r - 48], [a, r], dict=True) if s[r] < 1]
    assert len(sols) == 1
    s = sols[0]
    return s[a] / (1 - s[r])
q("C13-B-032", T, "Each term a fixed multiple of the sum of the terms after it", "Medium",
  "Multi-step word problem",
  r"In an infinite geometric progression of positive terms, every term is $6$ times the sum of all the terms that follow it. The sum of the first two terms is $48$. What is the sum of all the terms of the progression?",
  "MCQ",
  r"For the first term, $a = 6 \cdot \frac{ar}{1 - r}$, so $1 - r = 6r$ and $r = \frac{1}{7}$. Then $a\left(1 + \frac{1}{7}\right) = 48$ gives $a = 42$, and the sum is $\frac{42}{6/7} = 49$. (Quick route: the second term is $6$, so all terms after it add to $\frac{6}{6} = 1$, and the total is $48 + 1$.)",
  "Treating the given two-term sum as the first term, or misjudging the tail after the second term.",
  "C13B-term-vs-tail-sum", "Translating 'term equals 6 times the tail' into $r$, then a two-term condition.",
  correct=r"$49$",
  distractors=[(r"$54$", r"Takes the tail after the second term to be equal to the second term $6$, so the total is $48 + 6$."),
               (r"$55$", r"Takes the tail after the second term as $\frac{42}{6} = 7$, using the first term's rule, and adds it to $48$."),
               (r"$56$", r"Treats $48$ as the first term: $\frac{48}{1 - 1/7}$.")],
  check=_m21, values=[49, 54, 55, 56], cognitive="Application")


def _m22():
    ananya, joseph, score, rnd = 0, 1000, 2, 0
    while True:
        rnd += 1
        ananya += score
        score *= 3
        joseph *= 2
        if ananya > joseph:
            return rnd
q("C13-B-033", T, "Growing GP total overtaking a doubling total in a game", "Medium",
  "Inverse/parameter",
  r"In a game, Ananya scores $2$ points in round $1$, $6$ points in round $2$, $18$ points in round $3$, and so on, each round's score being $3$ times the previous round's score; her points add up from round to round. Joseph starts the game with $1{,}000$ points and scores nothing, but his total is doubled at the end of every round. After which round does Ananya's total first exceed Joseph's total?",
  "MCQ",
  r"After $n$ rounds, Ananya has $2(1 + 3 + \cdots + 3^{n-1}) = 3^n - 1$ points and Joseph has $1000 \cdot 2^n$. So we need $3^n - 1 > 1000 \cdot 2^n$, essentially $1.5^n > 1000$. Since $1.5^{17} \approx 985$ and $1.5^{18} \approx 1478$, check the boundary: after round $17$, $129{,}140{,}162 < 131{,}072{,}000$; after round $18$, $387{,}420{,}488 > 262{,}144{,}000$. The answer is round $18$.",
  "Comparing Ananya's single-round score with Joseph's total, or doubling Joseph's total one round late.",
  "C13B-growth-comparison", "A GP sum compared with a term of another GP; reduces to a power of $1.5$ that must be bracketed at the boundary.",
  correct=r"round $18$",
  distractors=[(r"round $19$", r"Compares Ananya's score in the round, $2 \cdot 3^{n-1}$, with Joseph's total: $1.5^{n-1} > 1000$ first holds for $n = 19$."),
               (r"round $16$", r"Takes Joseph's total after round $n$ as $1000 \cdot 2^{n-1}$, so $3^n - 1 > 500 \cdot 2^n$, which first holds for $n = 16$."),
               (r"round $17$", r"Reports the last round after which Ananya is still behind.")],
  check=_m22, values=[18, 19, 16, 17], cognitive="Application")


def _m23():
    r = symbols('r')
    rs = [x for x in solve(Eq(4095 * (r - 1), 3072 * r - 3), r) if x != 1]
    assert len(rs) == 1
    rr, t, n, S = rs[0], 3, 1, 3
    while t < 3072:
        t *= rr
        n += 1
        S += t
    assert t == 3072 and S == 4095
    return n
q("C13-B-034", T, "Number of terms from the first term, last term and sum", "Medium",
  "Inverse/parameter",
  r"A geometric progression has first term $3$ and last term $3072$, and the sum of all its terms is $4095$. How many terms does it have?",
  "MCQ",
  r"With last term $l$, the sum is $\frac{lr - a}{r - 1}$, so $4095(r - 1) = 3072r - 3$, giving $1023r = 4092$ and $r = 4$. Then $3 \cdot 4^{n-1} = 3072$ gives $4^{n-1} = 1024 = 4^5$, so $n = 6$. (Terms: $3, 12, 48, 192, 768, 3072$.)",
  "Writing the last term as $ar^n$, or reading the exponent in the wrong base.",
  "C13B-number-of-terms", "Uses the sum in terms of the last term to get $r$ without knowing $n$.",
  correct=r"$6$",
  distractors=[(r"$5$", r"Writes the last term as $ar^n$, so $4^n = 1024$ gives $n = 5$."),
               (r"$4$", r"Stops at the common ratio $r = 4$."),
               (r"$11$", r"From $4^{n-1} = 1024 = 2^{10}$ takes $n - 1 = 10$ without changing to base $4$.")],
  check=_m23, values=[6, 5, 4, 11], cognitive="Application")


# ================================================================ DIFFICULT (11)

def _d1():
    cnt = 0
    for x, y, z in itertools.combinations(range(1, 51), 3):
        if y * y == x * z:
            cnt += 1
    return cnt
q("C13-B-035", T, "Counting three-term GPs with terms from 1 to 50", "Difficult",
  "Casework/optimisation",
  r"In how many ways can three distinct numbers be chosen from $\{1, 2, 3, \ldots, 50\}$ so that, arranged in some order, they form a geometric progression?",
  "TITA",
  r"Arrange the chosen numbers as $x < y < z$ with $y^2 = xz$. Write the ratio as $\frac{q}{p}$ in lowest terms with $q > p \geq 1$; then $x = kp^2$, $y = kpq$, $z = kq^2$ for a positive integer $k$, with $kq^2 \leq 50$. For each $q$, multiply the number of $p < q$ coprime to $q$ by $\lfloor 50/q^2 \rfloor$: $q = 2$: $1 \times 12$; $q = 3$: $2 \times 5$; $q = 4$: $2 \times 3$; $q = 5$: $4 \times 2$; $q = 6$: $2 \times 1$; $q = 7$: $6 \times 1$. Total $12 + 10 + 6 + 8 + 2 + 6 = 44$.",
  "Allowing only integer ratios, or counting increasing and decreasing orders separately.",
  "C13B-counting-integer-gps", "Requires parametrising GPs with rational ratio and a careful case count by denominator.",
  tita_answer=44, check=_d1,
  tita_traps=[(24, "Counts only integer ratios: $12 + 5 + 3 + 2 + 1 + 1$."),
              (88, "Counts each set twice, once increasing and once decreasing.")],
  exams=CX, cognitive="Analysis")


def _d2():
    cnt = 0
    for b in range(-200, 201):
        if b == 0:
            continue
        s = 21 - b
        if s * s - 4 * b * b >= 0:
            cnt += 1
    return cnt
q("C13-B-036", T, "Integer values of the middle term of a GP with fixed sum", "Difficult",
  "Casework/optimisation",
  r"Three non-zero real numbers $a$, $b$, $c$ are in geometric progression in that order (the common ratio may be any non-zero real number, including $1$ or a negative number), and $a + b + c = 21$. How many integer values can $b$ take?",
  "TITA",
  r"Here $a + c = 21 - b$ and $ac = b^2$, so $a$ and $c$ are the roots of $t^2 - (21 - b)t + b^2 = 0$. They are real exactly when $(21 - b)^2 \geq 4b^2$, that is $(21 - 3b)(21 + b) \geq 0$, so $-21 \leq b \leq 7$. Both roots are non-zero because their product is $b^2 \neq 0$. The integers from $-21$ to $7$ number $29$; excluding $b = 0$ leaves $28$.",
  "Including $b = 0$, or forgetting the negative range given by negative ratios.",
  "C13B-middle-term-range", "Turns the GP into a quadratic with a reality condition; the negative branch is easy to miss.",
  tita_answer=28, check=_d2,
  tita_traps=[(29, "Counts all integers from $-21$ to $7$, including $0$."),
              (7, "Allows only positive values $1$ to $7$.")],
  exams=CX, cognitive="Analysis")


def _d3():
    a, r = symbols('a r', positive=True)
    res = set()
    for n in (1, 2, 3):
        sols = solve([sum(a * r**k for k in range(n)) - 12,
                      sum(a * r**k for k in range(3 * n)) - 156], [a, r], dict=True)
        for s in sols:
            if s[r] != 1:
                res.add(nsimplify(N(sum(s[a] * s[r]**k for k in range(4 * n)), 40)))
    assert len(res) == 1
    return res.pop()
q("C13-B-037", T, "Sum of 4n terms from the sums of n and 3n terms", "Difficult",
  "Conceptual/application",
  r"A geometric progression has positive terms. The sum of its first $n$ terms is $12$ and the sum of its first $3n$ terms is $156$. What is the sum of its first $4n$ terms?",
  "TITA",
  r"Split the terms into blocks of $n$. Each block is the previous block with every term multiplied by $x = r^n$, so the block sums are $12, 12x, 12x^2, 12x^3, \ldots$. Then $12(1 + x + x^2) = 156$ gives $x^2 + x - 12 = 0$, so $x = 3$ or $x = -4$; positive terms force $r > 0$, so $x = 3$. The fourth block is $12 \times 27 = 324$, and $S_{4n} = 156 + 324 = 480$.",
  "Not seeing that the block sums form a GP, or using the wrong power of $r^n$ for the fourth block.",
  "C13B-ratio-of-partial-sums", "The unknowns $a$, $r$, $n$ cannot be found; the block-sum insight leads to a quadratic in $r^n$ with a root to reject before a fourth block is added.",
  tita_answer=480, check=_d3,
  tita_traps=[(324, "Reports only the fourth block of $n$ terms."),
              (264, "Takes the fourth block as $12x^2 = 108$ instead of $12x^3$: $156 + 108$.")],
  exams=CX, cognitive="Analysis")


def _d4():
    cnt = 0
    for a in range(-1000, 1001):
        r = 1 - R(a, 72)
        if -1 < r < 1 and r != 0 and (a * r).q == 1:
            cnt += 1
    return cnt
q("C13-B-038", T, "Infinite GP with fixed sum whose first two terms are integers", "Difficult",
  "Casework/optimisation",
  r"An infinite geometric progression has a non-zero common ratio and its sum is $72$. Its first term and its second term are both integers. How many different values can its first term take?",
  "TITA",
  r"From $\frac{a}{1 - r} = 72$, $a = 72(1 - r)$; convergence needs $-1 < r < 1$ and $r \neq 0$, so $0 < a < 144$ with $a \neq 72$. The second term is $ar = a - \frac{a^2}{72}$, an integer exactly when $72 = 2^3 \times 3^2$ divides $a^2$, that is when $2^2 \times 3 = 12$ divides $a$. The multiples of $12$ in $(0, 144)$ are $12, 24, \ldots, 132$, which is $11$ values; removing $72$ leaves $10$.",
  "Forgetting negative ratios, allowing $r = 0$, or mishandling the divisibility of $a^2$.",
  "C13B-infinite-gp-convergence", "Combines the open interval for the first term (negative ratios included, one point removed) with a divisibility condition on $a^2$.",
  tita_answer=10, check=_d4,
  tita_traps=[(11, "Allows $r = 0$, so includes $a = 72$."),
              (5, "Allows only positive ratios, so $a$ lies in $(0, 72)$: $12, 24, 36, 48, 60$."),
              (22, "Takes $72 \\mid a^2$ to mean $6 \\mid a$: the $23$ multiples of $6$ in $(0, 144)$ minus $72$.")],
  exams=CX, cognitive="Analysis")


def _d5():
    a, r = symbols('a r', real=True)
    sols = [s for s in solve([a / (1 - r) - 2, a**2 / (1 - r**2) - 12], [a, r], dict=True) if abs(s[r]) < 1]
    assert len(sols) == 1
    s = sols[0]
    k = symbols('k', integer=True, nonnegative=True)
    return Sum((s[a] * s[r]**k)**3, (k, 0, oo)).doit()
q("C13-B-039", T, "Sum of cubes of an infinite GP from its sum and sum of squares", "Difficult",
  "Multi-step word problem",
  r"An infinite geometric progression has sum $2$, and the sum of the squares of its terms is $12$. What is the sum of the cubes of its terms?",
  "MCQ",
  r"$\frac{a}{1 - r} = 2$ and $\frac{a^2}{1 - r^2} = 12$; dividing, $\frac{a}{1 + r} = 6$. So $2(1 - r) = 6(1 + r)$, giving $r = -\frac{1}{2}$ and $a = 3$. The cubes form a GP with first term $27$ and ratio $-\frac{1}{8}$, so their sum is $\frac{27}{1 + \frac{1}{8}} = 24$.",
  "Using the wrong ratio for the cubes, or not expecting a negative ratio when the sum of squares exceeds the sum.",
  "C13B-infinite-gp-squares", "Two infinite sums give a negative ratio; then a third GP with ratio $r^3$.",
  correct=r"$24$",
  distractors=[(r"$8$", r"Cubes the sum: $2^3$."),
               (r"$18$", r"Uses ratio $r$ for the cubes: $\frac{27}{1 - (-1/2)}$."),
               (r"$36$", r"Uses ratio $r^2$ for the cubes: $\frac{27}{1 - 1/4}$.")],
  check=_d5, values=[24, 8, 18, 36], exams=CX, cognitive="Analysis")


def _d6():
    H, total = 125, 500
    r = symbols('r')
    rr = [x for x in solve(Eq(H * (1 + r) / (1 - r), total), r) if 0 < x < 1][0]
    h, k = Rational(H), 0
    while True:
        h *= rr
        k += 1
        if h < 10:
            return k
q("C13-B-040", T, "Bouncing ball: rebound ratio from total distance, then first rebound under 10 m", "Difficult",
  "Multi-step word problem",
  r"A ball is dropped from a height of $125$ m. After each impact it rises to a fixed fraction of the height from which it last fell, and it keeps bouncing indefinitely. The total vertical distance it travels is $500$ m. Which rebound is the first one to reach a height of less than $10$ m?",
  "MCQ",
  r"With rebound fraction $r$, the total distance is $125 + \frac{2 \times 125r}{1 - r} = \frac{125(1 + r)}{1 - r} = 500$, so $1 + r = 4 - 4r$ and $r = \frac{3}{5}$. The rebound heights are $75, 45, 27, 16.2, 9.72, \ldots$ m, so the first one below $10$ m is the $5$th rebound.",
  "Using $\\frac{H}{1 - r}$ for the total distance, or counting the initial drop as a rebound.",
  "C13B-bouncing-ball", "Invert the total-distance formula for $r$, then iterate the GP; two traps in counting.",
  correct=r"the $5$th",
  distractors=[(r"the $4$th", r"Reports the last rebound still at least $10$ m high ($16.2$ m)."),
               (r"the $9$th", r"Uses $\frac{125}{1 - r} = 500$, so $r = \frac{3}{4}$; the heights first drop below $10$ m at the $9$th rebound."),
               (r"the $6$th", r"Counts the initial $125$ m drop as the first rebound.")],
  check=_d6, values=[5, 4, 9, 6], exams=CX, cognitive="Analysis")


def _d7():
    r = symbols('r')
    m = 2  # middle term from the product
    assert m**5 == 32
    terms = lambda rv: [m / rv**2, m / rv, m, m * rv, m * rv**2]
    eq = numer(together(sum(terms(r)) - R(31, 2)))
    vals = set()
    for rv in real_roots(Poly(eq, r)):
        ts = terms(rv)
        assert abs(N(prod(ts) - 32)) < 1e-9
        vals.add(nsimplify(N(sum(1 / t for t in ts), 40)))
    assert len(vals) == 1
    return vals.pop()
q("C13-B-041", T, "Reciprocal sum of five GP terms from product and sum", "Difficult",
  "Conceptual/application",
  r"Five real numbers are in geometric progression. Their product is $32$ and their sum is $\frac{31}{2}$. What is the sum of their reciprocals?",
  "MCQ",
  r"Let the middle term be $m$. The product of five GP terms is $m^5 = 32$, so $m = 2$. Terms equidistant from the middle multiply to $m^2 = 4$, so $\frac{1}{t_k} = \frac{t_{6-k}}{4}$ for each $k$. Hence the sum of reciprocals is $\frac{1}{4} \times \frac{31}{2} = \frac{31}{8}$, without finding the ratio.",
  "Dividing the sum by the middle term or by the product rather than by the square of the middle term.",
  "C13B-reciprocal-sum", "Direct solving leads to a quartic in $r$; the pairing insight is needed.",
  correct=r"$\frac{31}{8}$",
  distractors=[(r"$\frac{31}{4}$", r"Divides the sum by the middle term $2$ rather than by its square."),
               (r"$\frac{31}{64}$", r"Divides the sum by the product $32$."),
               (r"$\frac{8}{31}$", r"Inverts the result.")],
  check=_d7, values=[R(31, 8), R(31, 4), R(31, 64), R(8, 31)], exams=CX, cognitive="Analysis")


def _d8():
    k = symbols('k', integer=True, nonnegative=True)
    z = Sum((I / 2)**k, (k, 0, oo)).doit()
    return simplify(Abs(z))
q("C13-B-042", T, "Spiral walk with halving legs: distance from the start", "Difficult",
  "Conceptual/application",
  r"Starting from a point P, Sneha walks $1$ km east, then $\frac{1}{2}$ km north, then $\frac{1}{4}$ km west, then $\frac{1}{8}$ km south, then $\frac{1}{16}$ km east, and so on, turning $90^\circ$ left after each leg and halving the length each time. Her position approaches a point T as she continues forever. What is the distance PT?",
  "MCQ",
  r"East displacement: $1 - \frac{1}{4} + \frac{1}{16} - \cdots = \frac{1}{1 + 1/4} = \frac{4}{5}$ km. North displacement: $\frac{1}{2} - \frac{1}{8} + \cdots = \frac{1/2}{1 + 1/4} = \frac{2}{5}$ km. So $PT = \sqrt{\frac{16}{25} + \frac{4}{25}} = \frac{\sqrt{20}}{5} = \frac{2\sqrt{5}}{5}$ km.",
  "Ignoring that alternate legs along the same axis point in opposite directions.",
  "C13B-zigzag-walk-infinite", "Splits one path into two alternating infinite GPs, then combines them with Pythagoras.",
  correct=r"$\frac{2\sqrt{5}}{5}$ km",
  distractors=[(r"$\frac{2\sqrt{5}}{3}$ km", r"Adds all east-west legs and all north-south legs as positive: $\frac{4}{3}$ and $\frac{2}{3}$."),
               (r"$\frac{6}{5}$ km", r"Adds the two net displacements $\frac{4}{5} + \frac{2}{5}$."),
               (r"$2$ km", r"Gives the total length walked, $\frac{1}{1 - 1/2}$.")],
  check=_d8, values=[2 * sqrt(5) / 5, 2 * sqrt(5) / 3, R(6, 5), 2], exams=CX, cognitive="Analysis")


def _d9():
    a, r = symbols('a r', real=True)
    sols = solve([a * (1 + r + r**2) - 65, 2 * (a * r - 3) - (a - 1) - (a * r**2 - 25)], [a, r], dict=True)
    good = []
    for s in sols:
        g = [s[a], s[a] * s[r], s[a] * s[r]**2]
        if g[0] < g[1] < g[2]:
            ap = [g[0] - 1, g[1] - 3, g[2] - 25]
            assert ap[1] - ap[0] == ap[2] - ap[1]
            good.append(ap[1] - ap[0])
    assert len(good) == 1
    return good[0]
q("C13-B-043", T, "Increasing GP that becomes an AP after subtracting fixed numbers", "Difficult",
  "Casework/optimisation",
  r"Three numbers form an increasing geometric progression and their sum is $65$. If $1$, $3$ and $25$ are subtracted from them respectively, the results form an arithmetic progression. What is the common difference of this arithmetic progression?",
  "MCQ",
  r"Let the numbers be $a, ar, ar^2$. The AP condition $2(ar - 3) = (a - 1) + (ar^2 - 25)$ simplifies to $a(r - 1)^2 = 20$. Dividing $a(1 + r + r^2) = 65$ by this gives $4(1 + r + r^2) = 13(r - 1)^2$, that is $3r^2 - 10r + 3 = 0$, so $r = 3$ or $\frac{1}{3}$. Since $a = \frac{20}{(r-1)^2} > 0$, an increasing GP needs $r = 3$, $a = 5$: the numbers $5, 15, 45$ become $4, 12, 20$, with common difference $8$.",
  "Keeping the root that gives a decreasing progression.",
  "C13B-gp-modified-to-ap", "Ratio of two equations gives a reciprocal pair of roots; the monotonicity condition selects one.",
  correct=r"$8$",
  distractors=[(r"$-32$", r"Uses $r = \frac{1}{3}$: $45, 15, 5$ become $44, 12, -20$."),
               (r"$12$", r"Reports the middle term of the AP, $15 - 3 = 12$, instead of its common difference."),
               (r"$16$", r"Reports $20 - 4$, the difference between the last and first AP terms.")],
  check=_d9, values=[8, -32, 12, 16], exams=CX, cognitive="Analysis")


def _d10():
    lasts = set()
    for r in range(2, 364):
        for n in range(3, 12):
            terms = [r**k for k in range(n)]
            if sum(terms) == 364:
                lasts.add(terms[-1])
    assert len(lasts) == 1
    return lasts.pop()
q("C13-B-044", T, "GP from 1 with integer ratio and a given sum: last term", "Difficult",
  "Casework/optimisation",
  r"A geometric progression has first term $1$, an integer common ratio $r > 1$, and at least $3$ terms. The sum of all its terms is $364$. What is its last term?",
  "MCQ",
  r"With $n$ terms, $1 + r + \cdots + r^{n-1} = 364$, which is even. If $r$ is even the sum is odd, so $r$ is odd; then each term is odd and the sum has the parity of $n$, so $n$ is even. For $n = 4$: $r(r^2 + r + 1) = 363$; $r = 3$ gives $39$ and $r = 11$ gives $1463$, so no solution. For $n = 6$: $r = 3$ gives $1 + 3 + 9 + 27 + 81 + 243 = 364$, while $r \geq 5$ is far too large. For $n \geq 8$ even $r = 3$ gives at least $3280$. So the progression ends at $243$.",
  "Reporting the next power after solving $\\frac{3^n - 1}{2} = 364$, or ignoring the condition of at least $3$ terms.",
  "C13B-repunit-gp-sum", "Casework on the number of terms using parity and bounding; nearby ratios (such as $18$ or $19$ with three terms) just miss.",
  correct=r"$243$",
  distractors=[(r"$729$", r"Solves $\frac{3^n - 1}{2} = 364$ and reports $3^n = 729$ as the last term instead of $3^{n-1}$."),
               (r"$363$", r"Ignores the condition of at least $3$ terms and takes the progression $1, 363$."),
               (r"$81$", r"Takes $243 = 3^5$, the largest power of $3$ below $364$, as giving $n = 5$ terms and reports the last term as $3^{n-1} = 81$.")],
  check=_d10, values=[243, 729, 363, 81], exams=CX, cognitive="Analysis")


def _d11():
    a, r = symbols('a r', real=True)
    sols = solve([a * (r**3 - 1) - 210, a * r * (r - 1) - 60], [a, r], dict=True)
    good = [s for s in sols if s[a] > 0 and s[r] > 0]
    assert len(good) == 1
    s = good[0]
    return sum(s[a] * s[r]**k for k in range(5))
q("C13-B-045", T, "GP from two term differences: sum of five terms", "Difficult",
  "Casework/optimisation",
  r"A geometric progression has positive terms. Its fourth term exceeds its first term by $210$, and its third term exceeds its second term by $60$. What is the sum of its first five terms?",
  "MCQ",
  r"$a(r^3 - 1) = 210$ and $ar(r - 1) = 60$. Dividing, $\frac{r^2 + r + 1}{r} = \frac{7}{2}$, so $2r^2 - 5r + 2 = 0$ and $r = 2$ or $\frac{1}{2}$. With $r = \frac{1}{2}$, $a(r^3 - 1) = 210$ forces $a = -240$, which is not allowed. So $r = 2$, $a = 30$, and $S_5 = 30(2^5 - 1) = 930$.",
  "Not rejecting the root that gives negative terms, or summing the wrong number of terms.",
  "C13B-ratio-from-term-differences", "Dividing two conditions gives a reciprocal pair of roots; positivity rejects one.",
  correct=r"$930$",
  distractors=[(r"$465$", r"Uses $r = \frac{1}{2}$ and drops the sign of $a = -240$: $240 \times \frac{31/32}{1/2} = 465$."),
               (r"$450$", r"Sums only four terms: $30 + 60 + 120 + 240$."),
               (r"$1890$", r"Sums six terms: $30(2^6 - 1)$.")],
  check=_d11, values=[930, 465, 450, 1890], exams=CX, cognitive="Analysis")
