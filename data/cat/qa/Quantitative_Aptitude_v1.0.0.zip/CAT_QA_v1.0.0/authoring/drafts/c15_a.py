import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
import math as _m

T_ = "Lines and angles"
TWO = ("CAT", "XAT")


# ---------- small geometry helpers (degrees, float coordinates) ----------
def _dir(deg):
    return (_m.cos(_m.radians(deg)), _m.sin(_m.radians(deg)))


def _add(p, d, t=1.0):
    return (p[0] + d[0] * t, p[1] + d[1] * t)


def _ang(a, v, b):
    t1 = _m.atan2(a[1] - v[1], a[0] - v[0]); t2 = _m.atan2(b[1] - v[1], b[0] - v[0])
    d = abs(_m.degrees(t1 - t2)) % 360
    return min(d, 360 - d)


def _meet(p, d, q, e):
    # intersection of p + t d and q + s e
    det = d[0] * (-e[1]) - d[1] * (-e[0])
    rx, ry = q[0] - p[0], q[1] - p[1]
    t = (rx * (-e[1]) - ry * (-e[0])) / det
    return (p[0] + d[0] * t, p[1] + d[1] * t)


def _dist(a, b):
    return _m.hypot(a[0] - b[0], a[1] - b[1])


def _r(x):
    return round(x, 6)


def _amark(f, a, v, b, label, r, frac=0.5, lr=None):
    # angle arc without the built-in label, label placed at a chosen fraction of the sweep
    f.angle_mark(a, v, b, "", r=r)
    t0 = _m.degrees(_m.atan2(a[1] - v[1], a[0] - v[0])); t1 = _m.degrees(_m.atan2(b[1] - v[1], b[0] - v[0]))
    sw = (t1 - t0) % 360
    if sw > 180:
        t0, sw = t1, 360 - sw
    f.text(_add(v, _dir(t0 + sw * frac), lr if lr else 1.7 * r), label)


def _subscript_labels(svg, names):
    for n in names:
        svg = svg.replace(">%s</text>" % n, '>%s<tspan dy="3" font-size="9">%s</tspan></text>' % (n[0], n[1:]))
    return svg


def _tris(p, strict=True):
    out = []
    for a in range(1, p):
        for b in range(a, p):
            c = p - a - b
            if c >= b and ((a + b > c) if strict else (a + b >= c)):
                out.append((a, b, c))
    return out


# =====================================================================
# EASY
# =====================================================================

# 001
def _c001():
    x = symbols('x')
    s = solve(Eq((3 * x + 10) + (2 * x + 20), 180), x)[0]
    return max(3 * s + 10, 2 * s + 20)

_f = Fig()
_P = (0.0, 3.0); _Q = _add(_P, _dir(-100), 3 / _m.sin(_m.radians(100)))
_f.seg((-3.5, 3), (3.5, 3)); _f.seg((-3.5, 0), (3.5, 0))
_f.seg(_add(_P, _dir(-100), -0.9), _add(_Q, _dir(-100), 0.9))
_f.pt("P", *_P, offset=(-0.7, 0.7)); _f.pt("Q", *_Q, offset=(-0.7, -0.7))
_f.text((3.8, 3), "l"); _f.text((3.8, 0), "m")
_f.angle_mark(_add(_P, (1, 0)), _P, _Q, r"(3x+10)^\circ", r=0.45)
_f.angle_mark(_add(_Q, (1, 0)), _Q, _P, r"(2x+20)^\circ", r=0.45)
_alt = "Two horizontal parallel lines l (top) and m (bottom) cut by a slanting transversal at P on l and Q on m. Between the lines, to the right of the transversal, the angle at P is marked (3x+10) degrees and the angle at Q is marked (2x+20) degrees."
q("C15-A-001", T_, "Co-interior angles given as linear expressions in x", "Easy",
  "Single-step computation",
  r"A straight footpath crosses two parallel roads $l$ and $m$ at points $P$ and $Q$ respectively. Between the two roads, on the same side of the footpath, the angle at $P$ measures $(3x + 10)^\circ$ and the angle at $Q$ measures $(2x + 20)^\circ$. What is the measure of the larger of these two angles?",
  "MCQ",
  r"The two angles are co-interior angles between parallel lines, so they add up to $180^\circ$: $(3x + 10) + (2x + 20) = 180$, giving $5x = 150$ and $x = 30$. The angles are $3(30) + 10 = 100^\circ$ and $2(30) + 20 = 80^\circ$, so the larger is $100^\circ$.",
  "Treating co-interior angles as equal (as if they were alternate angles), or slips in solving the linear equation.",
  "C15A-parallel-angle-algebra", "One co-interior equation in one unknown; the trap is equating the angles.",
  correct=r"$100^\circ$",
  distractors=[(r"$140^\circ$", r"Equates the two angles as if they were alternate: $3x + 10 = 2x + 20$ gives $x = 10$ and $40^\circ$, then reports the obtuse supplement $180^\circ - 40^\circ$."),
               (r"$136^\circ$", r"Moves the constant with the wrong sign: $5x + 30 = 180$ becomes $5x = 210$, so $x = 42$ and the larger angle is $3(42) + 10 = 136^\circ$."),
               (r"$118^\circ$", r"Drops the constants when forming the equation: $3x + 2x = 180$ gives $x = 36$, and the larger angle is $3(36) + 10 = 118^\circ$.")],
  check=_c001, values=[100, 140, 136, 118], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 002
def _c002():
    # a transversal on parallel lines gives only two angle sizes, a and 180 - a
    for a in range(1, 180):
        b = 180 - a
        if a != b and b == 4 * a:
            return max(a, b)

q("C15-A-002", T_, "Ratio of the two distinct angle sizes formed by a transversal", "Easy",
  "Single-step computation",
  r"A transversal cuts two parallel lines, forming eight angles. One of these eight angles is four times another of them that is not equal to it. Find the measure of the obtuse angle among the eight angles, in degrees.",
  "TITA",
  r"A transversal across two parallel lines forms only two different angle sizes, and these are supplementary. If the sizes are $a$ and $4a$, then $a + 4a = 180$, so $a = 36$. The obtuse angle is $4 \times 36 = 144^\circ$.",
  "Assuming the two unequal angles are complementary, or reporting the acute angle.",
  "C15A-parallel-angle-algebra", "One fact (only two angle sizes, supplementary) and one equation.",
  tita_answer=144, check=_c002, cognitive="Understanding",
  tita_traps=[(36, "Reports the acute angle $a = 36^\\circ$."),
              (72, "Takes the two angles as complementary: $5a = 90$ gives $a = 18$ and reports $4a = 72$.")])


# 003
def _c003():
    X = (0.0, 0.0)
    P = _add(X, _dir(140), 2 / _m.sin(_m.radians(40)))   # PX descends at 40 deg to l
    Q = _add(X, _dir(245), 2 / _m.sin(_m.radians(65)))   # QX ascends at 65 deg to m
    return _r(_ang(P, X, Q))

_f = Fig()
_X = (0.0, 0.0)
_P = _add(_X, _dir(140), 2 / _m.sin(_m.radians(40)))
_Q = _add(_X, _dir(245), 2 / _m.sin(_m.radians(65)))
_f.seg((-3.6, 2), (1.6, 2)); _f.seg((-3.6, -2), (1.6, -2))
_f.seg(_P, _X); _f.seg(_X, _Q)
_f.pt("P", *_P, offset=(0, 1)); _f.pt("Q", *_Q, offset=(0, -1)); _f.pt("X", *_X, offset=(1, 0))
_f.text((1.9, 2), "l"); _f.text((1.9, -2), "m")
_f.angle_mark(_add(_P, (1, 0)), _P, _X, r"40^\circ", r=0.5)
_f.angle_mark(_X, _Q, _add(_Q, (1, 0)), r"65^\circ", r=0.5)
_alt = "Parallel lines l (top) and m (bottom). Point X lies between them to the right. Segment PX goes from P on l down to X, making 40 degrees with l on the right of P. Segment QX goes from Q on m up to X, making 65 degrees with m on the right of Q."
q("C15-A-003", T_, "Angle at a bend between two parallel lines", "Easy",
  "Conceptual/application",
  r"Lines $l$ and $m$ are parallel. Point $X$ lies between them. Points $P$ on $l$ and $Q$ on $m$ both lie to the left of $X$. Segment $PX$ makes an angle of $40^\circ$ with the part of $l$ to the right of $P$, and segment $QX$ makes an angle of $65^\circ$ with the part of $m$ to the right of $Q$. What is the measure of angle $PXQ$?",
  "MCQ",
  r"Draw the line through $X$ parallel to $l$ and $m$. By alternate angles it makes $40^\circ$ with $XP$ and $65^\circ$ with $XQ$, on opposite sides of itself. Hence angle $PXQ = 40^\circ + 65^\circ = 105^\circ$.",
  "Subtracting the given angles, treating an alternate pair as co-interior, or reporting the supplement.",
  "C15A-bent-line-parallels", "One auxiliary parallel line and two alternate-angle pairs.",
  correct=r"$105^\circ$",
  distractors=[(r"$75^\circ$", r"Finds $105^\circ$ and then reports its supplement $180^\circ - 105^\circ$."),
               (r"$25^\circ$", r"Subtracts the given angles: $65^\circ - 40^\circ$."),
               (r"$155^\circ$", r"Treats the lower part of the bend and the $65^\circ$ angle at $Q$ as co-interior, taking that part as $180^\circ - 65^\circ = 115^\circ$, and adds $40^\circ$.")],
  check=_c003, values=[105, 75, 25, 155], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 004
def _c004():
    k = Fraction(180, 2 + 3 + 7)
    a, b, c = 2 * k, 3 * k, 7 * k
    return c - (a + b)

q("C15-A-004", T_, "Angles of a triangle in a given ratio", "Easy",
  "Single-step computation",
  r"The three angles of a triangular plot of land are in the ratio $2 : 3 : 7$. By how many degrees does the largest angle exceed the sum of the other two angles?",
  "MCQ",
  r"The angles are $2k, 3k, 7k$ with $12k = 180$, so $k = 15$ and the angles are $30^\circ, 45^\circ, 105^\circ$. The largest exceeds the sum of the other two by $105 - (30 + 45) = 30^\circ$.",
  "Answering a different comparison (largest minus smallest) or reporting the largest angle itself.",
  "C15A-triangle-angle-ratio", "Direct use of the angle sum with a ratio.",
  correct=r"$30^\circ$",
  distractors=[(r"$75^\circ$", "Computes largest minus smallest: $105 - 30$."),
               (r"$60^\circ$", "Computes largest minus the middle angle: $105 - 45$."),
               (r"$105^\circ$", "Reports the largest angle itself.")],
  check=_c004, values=[30, 75, 60, 105], cognitive="Application")


# 005
def _c005():
    a, d = symbols('a d')
    s = solve([Eq((a - d) + a + (a + d), 180), Eq(a + d, 3 * (a - d))], [a, d], dict=True)[0]
    return s[a] + s[d]

q("C15-A-005", T_, "Triangle angles in arithmetic progression", "Easy",
  "Multi-step word problem",
  r"The three angles of a triangle are in arithmetic progression, and the largest angle is three times the smallest. Find the largest angle of the triangle, in degrees.",
  "TITA",
  r"Write the angles as $a - d, a, a + d$. Their sum $3a = 180$ gives $a = 60$. Then $60 + d = 3(60 - d)$ gives $4d = 120$, so $d = 30$ and the largest angle is $90^\circ$.",
  r"Reporting the middle term of the progression, which is always $60^\circ$.",
  "C15A-triangle-angle-ratio", r"Two short equations; the middle angle being $60^\circ$ is the key step.",
  tita_answer=90, check=_c005, cognitive="Application",
  tita_traps=[(60, "Reports the middle angle $a = 60^\\circ$."), (30, "Reports the smallest angle or the common difference.")])


# 006
def _c006():
    k = symbols('k', positive=True)
    kv = solve(Eq(3 * k + 5 * k, 120), k)[0]   # exterior angle = sum of interior opposite angles
    return 5 * kv

_f = Fig()
_Qp = (0.0, 0.0); _Rp = (5.0, 0.0)
_Pp = _meet(_Qp, _dir(75), _Rp, _dir(120))
_Sp = (8.0, 0.0)
_f.poly(_Pp, _Qp, _Rp); _f.seg(_Rp, _Sp)
_f.pt("P", *_Pp); _f.pt("Q", *_Qp, offset=(-1, -0.3)); _f.pt("R", *_Rp, offset=(0, -1)); _f.pt("S", *_Sp, offset=(0.6, -0.8))
_f.angle_mark(_Sp, _Rp, _Pp, r"120^\circ", r=0.7)
_alt = "Triangle PQR with side QR horizontal and extended beyond R to S. The exterior angle PRS at R is marked 120 degrees."
q("C15-A-006", T_, "Exterior angle equals the sum of the interior opposite angles, with a ratio", "Easy",
  "Single-step computation",
  r"In triangle $PQR$, side $QR$ is extended beyond $R$ to a point $S$, and angle $PRS = 120^\circ$. If angle $QPR$ : angle $PQR = 3 : 5$, what is the measure of angle $PQR$?",
  "MCQ",
  r"The exterior angle $PRS$ equals the sum of the two interior opposite angles, so angle $P$ + angle $Q = 120^\circ$. With the ratio $3 : 5$, angle $Q = \frac{5}{8} \times 120^\circ = 75^\circ$.",
  "Splitting the exterior angle in the wrong way, or reporting the other angle.",
  "C15A-exterior-angle-theorem", "Exterior angle theorem plus a ratio split.",
  correct=r"$75^\circ$",
  distractors=[(r"$45^\circ$", "Reports angle $QPR = \\frac{3}{8} \\times 120^\\circ$."),
               (r"$60^\circ$", "Splits $120^\\circ$ equally between the two angles."),
               (r"$105^\circ$", "Reports the exterior angle at $Q$, $180^\\circ - 75^\\circ$.")],
  check=_c006, values=[75, 45, 60, 105], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 007
def _c007():
    return sum(1 for x in range(1, 100) if 6 + 13 > x and 6 + x > 13 and 13 + x > 6)

q("C15-A-007", T_, "Integer values of the third side from the triangle inequality", "Easy",
  "Casework/optimisation",
  r"Priya has two straight sticks of lengths $6$ cm and $13$ cm. She wants a third stick whose length is a whole number of centimetres so that the three sticks form a triangle. How many different lengths are possible for the third stick?",
  "TITA",
  r"The third side $x$ must satisfy $13 - 6 < x < 13 + 6$, that is $7 < x < 19$. The integers $8, 9, \ldots, 18$ work, which is $11$ lengths.",
  "Including the end values $7$ or $19$, where the sticks lie flat in a line.",
  "C15A-third-side-range", "One double inequality and a count; the trap is the strict inequality.",
  tita_answer=11, check=_c007, cognitive="Application",
  tita_traps=[(13, "Includes both $7$ and $19$ (uses $\\le$)."), (12, "Includes one end value.")])


# 008
def _c008():
    per = set()
    for eq, other in ((5, 11), (11, 5)):
        a, b, c = sorted((eq, eq, other))
        if a + b > c:
            per.add(a + b + c)
    assert len(per) == 1
    return per.pop()

q("C15-A-008", T_, "Isosceles triangle with two given side lengths", "Easy",
  "Conceptual/application",
  r"An isosceles triangle has two of its sides equal to $5$ cm and $11$ cm (not necessarily the two equal sides). What is its perimeter?",
  "MCQ",
  r"Either the equal sides are $5$ cm, giving sides $5, 5, 11$, or they are $11$ cm, giving $11, 11, 5$. The first fails the triangle inequality since $5 + 5 < 11$. So the sides are $11, 11, 5$ and the perimeter is $27$ cm.",
  "Not testing the case $5, 5, 11$ against the triangle inequality.",
  "C15A-isosceles-side-ambiguity", "Two cases, one eliminated by the triangle inequality.",
  correct=r"$27$ cm",
  distractors=[(r"$21$ cm", "Uses the sides $5, 5, 11$, which cannot form a triangle."),
               (r"$16$ cm", "Adds only the two given sides, $5 + 11$."),
               (r"$22$ cm", "Adds only the two equal sides $11 + 11$, leaving out the base.")],
  check=_c008, values=[27, 21, 16, 22], cognitive="Understanding")


# 009
def _c009():
    Q = (0.0, 0.0); R = (1.0, 0.0); P = (0.5, _m.sqrt(3) / 2)
    S = (R[0] + _dist(R, P), 0.0)
    return _r(_ang(Q, P, S))

_f = Fig()
_Q9 = (0.0, 0.0); _R9 = (2.0, 0.0); _P9 = (1.0, _m.sqrt(3)); _S9 = (4.0, 0.0)
_f.poly(_P9, _Q9, _R9); _f.seg(_R9, _S9); _f.seg(_P9, _S9)
_f.pt("P", *_P9, offset=(0, 1)); _f.pt("Q", *_Q9, offset=(-1, -0.3)); _f.pt("R", *_R9, offset=(0, -1)); _f.pt("S", *_S9, offset=(1, -0.3))
_alt = "Equilateral triangle PQR with base QR. QR is extended beyond R to S, with RS equal to RP, and P is joined to S."
q("C15-A-009", T_, "Equilateral triangle with a side extended by an equal length", "Easy",
  "Multi-step word problem",
  r"$PQR$ is an equilateral triangle. Side $QR$ is extended beyond $R$ to a point $S$ such that $RS = RP$. What is the measure of angle $QPS$?",
  "MCQ",
  r"The exterior angle $PRS = 180^\circ - 60^\circ = 120^\circ$. Triangle $PRS$ is isosceles with $RP = RS$, so angle $RPS = \frac{180^\circ - 120^\circ}{2} = 30^\circ$. Hence angle $QPS = 60^\circ + 30^\circ = 90^\circ$.",
  r"Using the interior angle $60^\circ$ at $R$ for triangle $PRS$ instead of the exterior angle $120^\circ$.",
  "C15A-equilateral-angle-chase", "Exterior angle plus one isosceles triangle.",
  correct=r"$90^\circ$",
  distractors=[(r"$120^\circ$", "Takes angle $PRS$ as $60^\\circ$, so angle $RPS = 60^\\circ$ and $QPS = 60^\\circ + 60^\\circ$."),
               (r"$30^\circ$", "Reports angle $RPS$ only."),
               (r"$150^\circ$", "Adds the exterior angle $PRS = 120^\\circ$ to angle $RPS = 30^\\circ$.")],
  check=_c009, values=[90, 120, 30, 150], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 010
def _c010():
    x = symbols('x')
    xv = solve(Eq(x + (3 * x - 20) + (2 * x + 20), 180), x)[0]
    three = [xv, 3 * xv - 20, 2 * xv + 20]
    six = three + three   # vertically opposite angles repeat
    assert sum(six) == 360
    return max(six)

q("C15-A-010", T_, "Three concurrent lines and the six angles around the point", "Easy",
  "Multi-step word problem",
  r"Three straight roads cross at a single point $O$, forming six angles around $O$. Three consecutive angles among them measure $x^\circ$, $(3x - 20)^\circ$ and $(2x + 20)^\circ$. What is the largest of the six angles, in degrees?",
  "TITA",
  r"Three consecutive angles formed by three concurrent lines together make a straight angle, so $x + (3x - 20) + (2x + 20) = 180$, giving $6x = 180$ and $x = 30$. The three angles are $30^\circ, 70^\circ, 80^\circ$, and the other three are their vertically opposite equals. The largest is $80^\circ$.",
  r"Setting the three consecutive angles equal to $360^\circ$ instead of $180^\circ$.",
  "C15A-concurrent-lines", "Straight angle and vertical angles; one linear equation.",
  tita_answer=80, check=_c010, cognitive="Application",
  tita_traps=[(160, "Uses $6x = 360$, so $x = 60$ and the angles become $60, 160, 140$."), (30, "Reports $x$.")])


# 011
def _c011():
    angO = 180 - 50 - 65            # angle POQ in triangle OPQ
    angS = 180 - 72 - angO          # vertically opposite angle ROS = POQ
    # coordinate confirmation
    O = (0.0, 0.0)
    P = _add(O, _dir(180), _m.sin(_m.radians(65)))
    Q = _add(O, _dir(180 - angO), _m.sin(_m.radians(50)))
    R = _add(O, _dir(360 - angO), 1.2 * _m.sin(_m.radians(angS)))
    S = _add(O, _dir(0), 1.2 * _m.sin(_m.radians(72)))
    assert abs(_ang(O, P, Q) - 50) < 1e-6 and abs(_ang(O, Q, P) - 65) < 1e-6 and abs(_ang(O, R, S) - 72) < 1e-6
    return _r(_ang(O, S, R))

_f = Fig()
_O = (0.0, 0.0)
_P11 = _add(_O, _dir(180), _m.sin(_m.radians(65))); _Q11 = _add(_O, _dir(115), _m.sin(_m.radians(50)))
_R11 = _add(_O, _dir(295), 1.2 * _m.sin(_m.radians(43))); _S11 = _add(_O, _dir(0), 1.2 * _m.sin(_m.radians(72)))
_f.seg(_P11, _S11); _f.seg(_Q11, _R11); _f.seg(_P11, _Q11); _f.seg(_R11, _S11)
for _n, _pp in (("P", _P11), ("Q", _Q11), ("R", _R11), ("S", _S11), ("O", _O)):
    _f.pt(_n, *_pp)
_f.angle_mark(_O, _P11, _Q11, r"50^\circ", r=0.18)
_f.angle_mark(_P11, _Q11, _O, r"65^\circ", r=0.18)
_f.angle_mark(_S11, _R11, _O, r"72^\circ", r=0.18)
_alt = "Segments PS and QR cross at O. Triangle OPQ lies on the left with angle at P marked 50 degrees and angle at Q marked 65 degrees. Triangle ORS lies on the right with angle at R marked 72 degrees."
q("C15-A-011", T_, "Two triangles sharing vertically opposite angles", "Easy",
  "Conceptual/application",
  r"Segments $PS$ and $QR$ intersect at $O$. In triangle $OPQ$, angle $OPQ = 50^\circ$ and angle $OQP = 65^\circ$. In triangle $ORS$, angle $ORS = 72^\circ$. What is the measure of angle $OSR$?",
  "MCQ",
  r"Angles $POQ$ and $ROS$ are vertically opposite, so they are equal. Hence $50^\circ + 65^\circ = 72^\circ + \angle OSR$, which gives $\angle OSR = 43^\circ$.",
  "Assuming the two triangles have equal corresponding angles at $P$ and $S$ or at $Q$ and $S$.",
  "C15A-vertical-angle-bowtie", "Vertical angles make the two remaining-angle sums equal.",
  correct=r"$43^\circ$",
  distractors=[(r"$65^\circ$", "Reports angle $POQ = 180^\\circ - 50^\\circ - 65^\\circ$, which equals angle $ROS$, not angle $OSR$."),
               (r"$50^\circ$", "Assumes $PQ$ is parallel to $RS$ and equates the alternate angles at $P$ and $S$."),
               (r"$58^\circ$", "Takes angle $ROS$ equal to angle $OPQ = 50^\\circ$ instead of angle $POQ$: $180 - 72 - 50$.")],
  check=_c011, values=[43, 65, 50, 58], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 012
def _c012():
    k = Fraction(360, 4 + 5 + 6)
    ext = [4 * k, 5 * k, 6 * k]
    return min(180 - e for e in ext)

q("C15-A-012", T_, "Exterior angles of a triangle in a ratio", "Easy",
  "Multi-step word problem",
  r"Taking one exterior angle at each vertex, the three exterior angles of a triangle are in the ratio $4 : 5 : 6$. What is the smallest interior angle of the triangle?",
  "MCQ",
  r"One exterior angle at each vertex gives a total of $360^\circ$, so the exterior angles are $96^\circ, 120^\circ, 144^\circ$. The interior angles are $84^\circ, 60^\circ, 36^\circ$, and the smallest is $36^\circ$, the one beside the largest exterior angle.",
  r"Using $180^\circ$ as the sum of exterior angles, stopping at one ratio part, or reporting the wrong interior angle.",
  "C15A-exterior-angle-sum", r"Exterior sum $360^\circ$ and the link interior $= 180^\circ -$ exterior.",
  correct=r"$36^\circ$",
  distractors=[(r"$60^\circ$", "Finds the interior angles correctly but reports the middle one, $180^\\circ - 120^\\circ$."),
               (r"$48^\circ$", "Uses $180^\\circ$ as the exterior total: $\\frac{4}{15} \\times 180^\\circ = 48^\\circ$, and reports it."),
               (r"$24^\circ$", "Stops at one part of the ratio, $\\frac{360^\\circ}{4 + 5 + 6} = 24^\\circ$.")],
  check=_c012, values=[36, 60, 48, 24], cognitive="Application")


# =====================================================================
# MEDIUM
# =====================================================================

# 013
def _c013():
    x, y = symbols('x y')
    s = solve([Eq(2 * x + y, 3 * x - 2 * y), Eq((2 * x + y) + (x + 2 * y), 180)], [x, y], dict=True)[0]
    a = (2 * x + y).subs(s); b = (x + 2 * y).subs(s)
    return min(a, b)

q("C15-A-013", T_, "Alternate and co-interior conditions in two unknowns", "Medium",
  "Inverse/parameter",
  r"A transversal cuts parallel lines $l$ and $m$ at $P$ and $Q$. An interior angle at $P$ measures $(2x + y)^\circ$. Its alternate interior angle at $Q$ measures $(3x - 2y)^\circ$, and the other interior angle at $Q$, on the same side of the transversal as the angle at $P$, measures $(x + 2y)^\circ$. What is the acute angle between the transversal and the parallel lines?",
  "MCQ",
  r"Alternate angles are equal: $2x + y = 3x - 2y$, so $x = 3y$. Co-interior angles are supplementary: $(2x + y) + (x + 2y) = 180$, so $x + y = 60$. Hence $y = 15$, $x = 45$, the angles are $105^\circ$ and $75^\circ$, and the acute angle is $75^\circ$.",
  "Treating the alternate pair as supplementary, or reporting the obtuse angle or the value of $x$.",
  "C15A-parallel-angle-algebra", "Two angle relations give two linear equations in two unknowns.",
  correct=r"$75^\circ$",
  distractors=[(r"$105^\circ$", "Solves correctly but reports the obtuse angle $2x + y$."),
               (r"$80^\circ$", "Treats the alternate angles as supplementary: $5x - y = 180$ with $x + y = 60$ gives $x = 40$, $y = 20$, angles $100^\\circ$ and $80^\\circ$."),
               (r"$45^\circ$", "Reports the value of $x$.")],
  check=_c013, values=[75, 105, 80, 45], cognitive="Application")


# 014
def _zig():
    H = 4.502
    P = (0.0, H)
    X = _add(P, _dir(-30), 2)
    Y = _add(X, _dir(260), 2)            # angle PXY = 110 with Y to the left of X
    Q = _add(Y, _dir(-50), (Y[1]) / _m.sin(_m.radians(50)))
    return P, X, Y, Q

def _c014():
    P, X, Y, Q = _zig()
    assert abs(_ang(X, P, _add(P, (1, 0))) - 30) < 1e-6
    assert abs(_ang(P, X, Y) - 110) < 1e-6
    assert abs(_ang(Y, Q, _add(Q, (-1, 0))) - 50) < 1e-6 and abs(Q[1]) < 1e-9
    assert Y[0] < X[0] and Y[0] < Q[0] and X[0] > P[0]
    return _r(_ang(X, Y, Q))

_f = Fig()
_P14, _X14, _Y14, _Q14 = _zig()
_f.seg((-1.2, _P14[1]), (4.2, _P14[1])); _f.seg((-1.2, 0), (4.2, 0))
_f.seg(_P14, _X14); _f.seg(_X14, _Y14); _f.seg(_Y14, _Q14)
_f.pt("P", *_P14, offset=(0, 1)); _f.pt("X", *_X14, offset=(1, 0)); _f.pt("Y", *_Y14, offset=(-1, 0)); _f.pt("Q", *_Q14, offset=(0, -1))
_f.text((4.5, _P14[1]), "l"); _f.text((4.5, 0), "m")
_f.angle_mark(_add(_P14, (1, 0)), _P14, _X14, r"30^\circ", r=0.55)
_f.angle_mark(_P14, _X14, _Y14, r"110^\circ", r=0.4)
_f.angle_mark(_Y14, _Q14, _add(_Q14, (-1, 0)), r"50^\circ", r=0.55)
_alt = "Parallel lines l (top) and m (bottom). A zigzag path runs from P on l down-right to X, then down-left to Y, then down-right to Q on m. PX makes 30 degrees with l to the right of P, angle PXY is 110 degrees, and QY makes 50 degrees with m to the left of Q."
q("C15-A-014", T_, "Zigzag path with two bends between parallel lines", "Medium",
  "Conceptual/application",
  r"Lines $l$ and $m$ are parallel, with $l$ above $m$. A path runs from $P$ on $l$ to $X$, then to $Y$, then to $Q$ on $m$, where $X$ and $Y$ lie between the lines, $X$ is to the right of both $P$ and $Y$, and $Y$ is to the left of $Q$. Segment $PX$ makes an angle of $30^\circ$ with the part of $l$ to the right of $P$, angle $PXY = 110^\circ$, and segment $QY$ makes an angle of $50^\circ$ with the part of $m$ to the left of $Q$. What is the measure of angle $XYQ$?",
  "MCQ",
  r"Draw lines through $X$ and $Y$ parallel to $l$. At $X$ the angle $110^\circ$ splits into $30^\circ$ (alternate to the angle at $P$) and $80^\circ$ below the parallel. At $Y$ the angle $XYQ$ splits into $80^\circ$ (alternate to that part) and $50^\circ$ (alternate to the angle at $Q$). So angle $XYQ = 80^\circ + 50^\circ = 130^\circ$; equivalently, the angles opening to the left ($110^\circ$ and $50^\circ$) and to the right ($30^\circ$ and $XYQ$) have equal sums.",
  "Applying the single-bend rule to the wrong pair of angles or treating the figure as a quadrilateral.",
  "C15A-bent-line-parallels", "Two bends; the parallel line through each bend must be used in turn.",
  correct=r"$130^\circ$",
  distractors=[(r"$170^\circ$", "Treats the four angles as a quadrilateral summing to $360^\\circ$: $360 - 30 - 110 - 50$."),
               (r"$90^\circ$", "Pairs the angles on the wrong sides: $110 + 30 - 50$."),
               (r"$80^\circ$", "Ignores the bend at $X$ and adds the angles at $P$ and $Q$: $30 + 50$.")],
  check=_c014, values=[130, 170, 90, 80], cognitive="Analysis",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 015
def _bis_par(angP, H=3.0):
    P = (0.0, H)
    Q = _add(P, _dir(-angP), H / _m.sin(_m.radians(angP)))
    R = _meet(P, _dir(-angP / 2), Q, _dir((180 - angP) / 2))
    return P, Q, R

def _c015():
    P, Q, R = _bis_par(64)
    assert abs(_ang(_add(P, (1, 0)), P, Q) - 64) < 1e-6
    return _r(_ang(P, R, Q))

_f = Fig()
_P15, _Q15, _R15 = _bis_par(64)
_f.seg((-1.0, 3), (4.0, 3)); _f.seg((-1.0, 0), (4.0, 0))
_f.seg(_add(_P15, _dir(-64), -0.6), _add(_Q15, _dir(-64), 0.6))
_f.seg(_P15, _R15); _f.seg(_Q15, _R15)
_f.pt("P", *_P15, offset=(-1.3, 0.8)); _f.pt("Q", *_Q15, offset=(-0.6, -0.8)); _f.pt("R", *_R15, offset=(1, 0))
_f.text((4.3, 3), "l"); _f.text((4.3, 0), "m")
_amark(_f, _add(_P15, (1, 0)), _P15, _Q15, r"64^\circ", r=0.9, frac=0.82, lr=1.55)
_alt = "Parallel lines l (top) and m (bottom) cut by a transversal at P and Q. The interior angle at P on the right of the transversal is marked 64 degrees. The bisectors of the interior angles at P and at Q on that side meet at R between the lines."
q("C15-A-015", T_, "Bisectors of co-interior angles meet at a fixed angle", "Medium",
  "Conceptual/application",
  r"A transversal cuts parallel lines $l$ and $m$ at $P$ and $Q$. On one side of the transversal, the interior angle at $P$ is $64^\circ$. The bisectors of the two interior angles on that side, at $P$ and at $Q$, meet at $R$. What is the measure of angle $PRQ$?",
  "MCQ",
  r"The interior angles on that side are $64^\circ$ and $116^\circ$, since co-interior angles are supplementary. Their halves are $32^\circ$ and $58^\circ$, which are the angles of triangle $PQR$ at $P$ and $Q$. So angle $PRQ = 180^\circ - 32^\circ - 58^\circ = 90^\circ$; it is $90^\circ$ for any transversal.",
  r"Using the alternate angle $64^\circ$ at $Q$ instead of the co-interior angle $116^\circ$, or halving only one angle.",
  "C15A-bisectors-angle-sum", "Needs co-interior supplement plus a triangle sum; the answer is independent of the given angle.",
  correct=r"$90^\circ$",
  distractors=[(r"$116^\circ$", "Takes the interior angle at $Q$ as $64^\\circ$ (alternate, not co-interior), so $180 - 32 - 32 = 116$."),
               (r"$58^\circ$", "Bisects only the angle at $Q$: $180 - 64 - 58 = 58$."),
               (r"$32^\circ$", "Bisects only the angle at $P$: $180 - 32 - 116 = 32$.")],
  check=_c015, values=[90, 116, 58, 32], cognitive="Analysis",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 016
def _bis_iso(angP=70, L=12.0):
    H = L * _m.sin(_m.radians(angP))
    P = (0.0, H)
    Q = _add(P, _dir(-angP), L)
    Tt = _meet(P, _dir(-angP / 2), (0.0, 0.0), (1.0, 0.0))
    return P, Q, Tt

def _c016():
    P, Q, Tt = _bis_iso()
    assert abs(_dist(P, Q) - 12) < 1e-9
    return _r(_dist(Q, Tt))

q("C15-A-016", T_, "Bisector of an interior angle meets the other parallel: hidden isosceles triangle", "Medium",
  "Conceptual/application",
  r"A transversal meets parallel lines $l$ and $m$ at $P$ and $Q$ respectively, with $PQ = 12$ cm. The interior angle at $P$ on one side of the transversal is $70^\circ$, and the bisector of this angle meets $m$ at $T$. Find the length of $QT$, in cm.",
  "TITA",
  r"The bisector makes $35^\circ$ with $PQ$ and $35^\circ$ with $l$. By alternate angles, angle $PTQ = 35^\circ$. So in triangle $PQT$ the angles at $P$ and $T$ are equal, the triangle is isosceles and $QT = QP = 12$ cm.",
  "Trying to use trigonometry or halving the length instead of spotting the isosceles triangle.",
  "C15A-bisector-alternate-isosceles", "Requires spotting alternate angles that create an isosceles triangle.",
  tita_answer=12, check=_c016, cognitive="Analysis", exams=TWO,
  tita_traps=[(6, "Assumes the bisector of the angle also bisects the length, giving half of $PQ$.")])


# 017
def _ext_bis(angP=64, angQ=70):
    angR = 180 - angP - angQ
    Q = (0.0, 0.0); R = (6.0, 0.0)
    P = _meet(Q, _dir(angQ), R, _dir(180 - angR))
    Tt = _meet(Q, _dir(angQ / 2), R, _dir((180 - angR) / 2))
    return P, Q, R, Tt

def _c017():
    vals = set()
    for aq in (70, 50, 90, 100):
        P, Q, R, Tt = _ext_bis(64, aq)
        assert abs(_ang(Q, P, R) - 64) < 1e-6
        vals.add(_r(_ang(Q, Tt, R)))
    assert len(vals) == 1
    return vals.pop()

_f = Fig()
_P17, _Q17, _R17, _T17 = _ext_bis()
_S17 = (_T17[0] + 1.0, 0.0)
_f.poly(_P17, _Q17, _R17); _f.seg(_R17, _S17); _f.seg(_Q17, _T17); _f.seg(_R17, _T17)
_f.pt("P", *_P17); _f.pt("Q", *_Q17, offset=(-1, -0.3)); _f.pt("R", *_R17, offset=(0, -1)); _f.pt("S", *_S17, offset=(0.7, -0.7)); _f.pt("T", *_T17, offset=(0.7, 0.7))
_f.angle_mark(_Q17, _P17, _R17, r"64^\circ", r=0.8)
_alt = "Triangle PQR with angle P marked 64 degrees. QR is extended beyond R to S. The bisector of angle PQR from Q and the bisector of exterior angle PRS from R meet at T, outside the triangle beyond side PR."
q("C15-A-017", T_, "Bisectors of an interior angle and an exterior angle of a triangle", "Medium",
  "Conceptual/application",
  r"In triangle $PQR$, angle $QPR = 64^\circ$. Side $QR$ is extended beyond $R$ to a point $S$. The bisector of angle $PQR$ and the bisector of angle $PRS$ meet at $T$. Find the measure of angle $QTR$, in degrees.",
  "TITA",
  r"Let angle $PQR = 2b$. By the exterior angle theorem in triangle $PQR$, angle $PRS = 64^\circ + 2b$, so angle $TRS = 32^\circ + b$. In triangle $TQR$, angle $TRS$ is exterior, so $32^\circ + b = b + \angle QTR$, giving $\angle QTR = 32^\circ$.",
  r"Mixing up this configuration with the meeting point of two internal bisectors ($90^\circ + \frac{P}{2}$) or two external bisectors ($90^\circ - \frac{P}{2}$).",
  "C15A-exterior-angle-theorem", "Exterior angle theorem applied twice with an unknown angle that cancels.",
  tita_answer=32, check=_c017, cognitive="Analysis",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False),
  tita_traps=[(122, "Uses the internal-bisector result $90 + \\frac{64}{2}$."),
              (58, "Uses the two-external-bisector result $90 - \\frac{64}{2}$."),
              (64, "Assumes angle $QTR$ equals angle $P$.")])


# 018
def _iso18():
    Q = (0.0, 0.0); R = (4.0, 0.0); P = (2.0, 2.0 * _m.tan(_m.radians(40)))
    # S on QR with angle QPS = 40: rotate ray PQ by 40 deg towards R
    dPQ = _m.degrees(_m.atan2(Q[1] - P[1], Q[0] - P[0]))
    S = _meet(P, _dir(dPQ + 40), Q, (1.0, 0.0))
    u = ((R[0] - P[0]) / _dist(P, R), (R[1] - P[1]) / _dist(P, R))
    Tt = _add(P, u, _dist(P, S))
    return P, Q, R, S, Tt

def _c018():
    P, Q, R, S, Tt = _iso18()
    assert abs(_ang(P, Q, R) - 40) < 1e-6 and abs(_ang(Q, P, S) - 40) < 1e-6 and 0 < S[0] < R[0]
    return _r(_ang(R, S, Tt))

_f = Fig()
_P18, _Q18, _R18, _S18, _T18 = _iso18()
_f.poly(_P18, _Q18, _R18); _f.seg(_P18, _S18); _f.seg(_S18, _T18)
_f.pt("P", *_P18, offset=(0, 1)); _f.pt("Q", *_Q18, offset=(-1, -0.3)); _f.pt("R", *_R18, offset=(1, -0.3)); _f.pt("S", *_S18, offset=(0, -1)); _f.pt("T", *_T18, offset=(1, 0.4))
_f.angle_mark(_R18, _Q18, _P18, r"40^\circ", r=0.5)
_f.angle_mark(_Q18, _P18, _S18, r"40^\circ", r=0.45)
_alt = "Isosceles triangle PQR with PQ = PR and base QR. Angle PQR is marked 40 degrees. Point S on QR is joined to P with angle QPS marked 40 degrees. Point T on PR is joined to S."
q("C15-A-018", T_, "Isosceles triangle with an equal-length cevian construction", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, $PQ = PR$ and angle $PQR = 40^\circ$. Point $S$ on side $QR$ is such that angle $QPS = 40^\circ$, and point $T$ on side $PR$ is such that $PT = PS$. What is the measure of angle $RST$?",
  "MCQ",
  r"Angle $QPR = 180^\circ - 80^\circ = 100^\circ$, so angle $SPR = 60^\circ$. In isosceles triangle $PST$, angle $PST = \frac{180^\circ - 60^\circ}{2} = 60^\circ$. Angle $PSR$ is exterior to triangle $PQS$, so it equals $40^\circ + 40^\circ = 80^\circ$. Hence angle $RST = 80^\circ - 60^\circ = 20^\circ$.",
  "Reporting an intermediate angle, or using the wrong apex angle in triangle $PST$.",
  "C15A-isosceles-angle-chase", "Three linked steps: apex angle, an isosceles triangle, an exterior angle.",
  correct=r"$20^\circ$",
  distractors=[(r"$60^\circ$", "Stops at angle $PST$."),
               (r"$80^\circ$", "Stops at angle $PSR$."),
               (r"$10^\circ$", "Uses $40^\\circ$ as the apex angle of triangle $PST$, so $PST = 70^\\circ$ and $80 - 70 = 10$.")],
  check=_c018, values=[20, 60, 80, 10], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 019
def _c019():
    x = symbols('x', positive=True)
    xv = solve(Eq(180 - x - 2 * x, 105), x)[0]       # Q = x, R = 2x
    angSPR = 180 - 2 * (2 * xv)
    # numeric confirmation of the lengths QS = SP = PR
    Q = (0.0, 0.0); R = (5.0, 0.0)
    P = _meet(Q, _dir(float(xv)), R, _dir(180 - 2 * float(xv)))
    dPQ = _m.degrees(_m.atan2(Q[1] - P[1], Q[0] - P[0]))
    S = _meet(Q, (1.0, 0.0), P, _dir(dPQ + float(xv)))
    assert abs(_dist(Q, S) - _dist(S, P)) < 1e-9 and abs(_dist(S, P) - _dist(P, R)) < 1e-9
    assert abs(_ang(S, P, R) - float(angSPR)) < 1e-6
    return angSPR

q("C15-A-019", T_, "Chain of two isosceles triangles on one side", "Medium",
  "Inverse/parameter",
  r"In triangle $PQR$, point $S$ lies on side $QR$ such that $QS = SP = PR$. If angle $QPR = 105^\circ$, what is the measure of angle $SPR$?",
  "MCQ",
  r"Let angle $PQR = x$. Since $SQ = SP$, angle $SPQ = x$, and the exterior angle $PSR = 2x$. Since $PS = PR$, angle $PRS = 2x$. In triangle $PQR$: $x + 2x + 105 = 180$, so $x = 25^\circ$. Then angle $SPR = 105^\circ - 25^\circ = 80^\circ$.",
  "Subtracting the wrong angle from angle $QPR$ or stopping at an intermediate angle.",
  "C15A-isosceles-angle-chase", "Two isosceles triangles and an exterior angle give one equation.",
  correct=r"$80^\circ$",
  distractors=[(r"$50^\circ$", "Reports angle $PSR = 2x$."),
               (r"$25^\circ$", "Reports angle $PQR = x$."),
               (r"$55^\circ$", "Subtracts angle $PSR$ instead of angle $QPS$: $105 - 50$.")],
  check=_c019, values=[80, 50, 25, 55], cognitive="Application")


# 020
def _c020():
    largest = set()
    for apex_mult, base_mult in ((4, 1), (1, 4)):
        # angles: apex = apex_mult*t, two base angles = base_mult*t each
        t = Fraction(180, apex_mult + 2 * base_mult)
        angs = [apex_mult * t, base_mult * t, base_mult * t]
        assert sum(angs) == 180 and any(a == 4 * b for a in angs for b in angs)
        largest.add(max(angs))
    return int(sum(largest))

q("C15-A-020", T_, "Isosceles triangle with one angle a multiple of another: two cases", "Medium",
  "Casework/optimisation",
  r"In an isosceles triangle, one angle is four times another angle. Find the sum of all possible values of the largest angle of the triangle, in degrees.",
  "TITA",
  r"Case 1: the two equal angles are $x$ and the third is $4x$: $6x = 180$, angles $30^\circ, 30^\circ, 120^\circ$, largest $120^\circ$. Case 2: the two equal angles are $4x$ and the third is $x$: $9x = 180$, angles $80^\circ, 80^\circ, 20^\circ$, largest $80^\circ$. The sum is $120 + 80 = 200$.",
  "Considering only the case in which the unequal angle is the larger one.",
  "C15A-isosceles-angle-cases", "Two cases must be set up and both survive.",
  tita_answer=200, check=_c020, cognitive="Analysis",
  tita_traps=[(120, "Considers only angles $x, x, 4x$."), (80, "Considers only angles $4x, 4x, x$.")])


# 021
def _sq_eq():
    P = (0.0, 0.0); Q = (1.0, 0.0); R = (1.0, 1.0); S = (0.0, 1.0)
    Tt = (1.0 + _m.sqrt(3) / 2, 0.5)
    return P, Q, R, S, Tt

def _c021():
    P, Q, R, S, Tt = _sq_eq()
    assert abs(_dist(Q, Tt) - 1) < 1e-12 and abs(_dist(R, Tt) - 1) < 1e-12
    return _r(_ang(P, Tt, S))

_f = Fig()
_P21, _Q21, _R21, _S21, _T21 = _sq_eq()
_f.poly(_P21, _Q21, _R21, _S21); _f.poly(_Q21, _T21, _R21); _f.seg(_P21, _T21); _f.seg(_S21, _T21)
_f.pt("P", *_P21); _f.pt("Q", *_Q21, offset=(0.2, -1)); _f.pt("R", *_R21, offset=(0.2, 1)); _f.pt("S", *_S21); _f.pt("T", *_T21, offset=(1, 0))
_alt = "Square PQRS with P bottom left, Q bottom right, R top right, S top left. Equilateral triangle QRT is drawn outside the square on side QR. T is joined to P and to S."
q("C15-A-021", T_, "Square with an external equilateral triangle", "Medium",
  "Multi-step word problem",
  r"$PQRS$ is a square. An equilateral triangle $QRT$ is drawn on side $QR$, outside the square. What is the measure of angle $PTS$?",
  "MCQ",
  r"$QT = QR = QP$, so triangle $PQT$ is isosceles with apex angle $PQT = 90^\circ + 60^\circ = 150^\circ$; hence angle $QTP = 15^\circ$. By symmetry angle $RTS = 15^\circ$. So angle $PTS = 60^\circ - 15^\circ - 15^\circ = 30^\circ$.",
  "Forgetting that triangles $PQT$ and $SRT$ are isosceles, or drawing the triangle inside the square.",
  "C15A-equilateral-angle-chase", "Spot two isosceles triangles and subtract from $60^\\circ$.",
  correct=r"$30^\circ$",
  distractors=[(r"$15^\circ$", "Reports angle $QTP$."),
               (r"$60^\circ$", "Assumes angle $PTS$ equals angle $QTR$ of the equilateral triangle."),
               (r"$150^\circ$", "Draws the triangle inside the square, where the angle at $T$ is $150^\\circ$.")],
  check=_c021, values=[30, 15, 60, 150], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 022
def _c022():
    return len(_tris(20))

q("C15-A-022", T_, "Integer-sided triangles with a fixed perimeter (matchsticks)", "Medium",
  "Casework/optimisation",
  r"Kabir has $20$ identical matchsticks. He uses all of them to make a triangle, with each side a straight row of whole matchsticks laid end to end, and no matchstick broken. How many non-congruent triangles can he make?",
  "TITA",
  r"Let the sides be $a \le b \le c$ with $a + b + c = 20$ and $a + b > c$, so $c < 10$, and $c \ge 7$. For $c = 9$: $(2,9), (3,8), (4,7), (5,6)$; for $c = 8$: $(4,8), (5,7), (6,6)$; for $c = 7$: $(6,7)$. That is $4 + 3 + 1 = 8$ triangles.",
  "Allowing $a + b = c$ (a flat triangle), or counting only scalene triangles.",
  "C15A-integer-perimeter-count", "Casework on the longest side with the strict inequality.",
  tita_answer=8, check=_c022, cognitive="Analysis",
  tita_traps=[(13, "Allows $a + b = c$, adding the five flat cases with $c = 10$."),
              (4, "Counts only scalene triangles.")])


# 023
def _c023():
    return sum(1 for (a, b, c) in _tris(50) if a == b or b == c)

q("C15-A-023", T_, "Isosceles triangles with integer sides and fixed perimeter", "Medium",
  "Casework/optimisation",
  r"How many non-congruent isosceles triangles have integer side lengths (in cm) and a perimeter of $50$ cm?",
  "TITA",
  r"Let the equal sides be $a$ and the third side $b = 50 - 2a$. We need $b > 0$, so $a \le 24$, and $b < 2a$, so $50 - 2a < 2a$, giving $a \ge 13$. So $a = 13, 14, \ldots, 24$: $12$ triangles (none is equilateral since $3 \nmid 50$).",
  "Ignoring the triangle inequality, or allowing a zero base.",
  "C15A-isosceles-integer-count", "Two inequalities on the equal side; the triangle inequality is the binding one.",
  tita_answer=12, check=_c023, cognitive="Application",
  tita_traps=[(24, "Takes $a = 1, \\ldots, 24$, ignoring the triangle inequality."),
              (13, "Also counts $a = 25$, where the base is $0$.")])


# 024
def _c024():
    cnt = 0
    for x in range(-50, 60):
        s = sorted((x + 2, 2 * x - 3, 15 - x))
        if s[0] > 0 and s[0] + s[1] > s[2]:
            cnt += 1
    return cnt

q("C15-A-024", T_, "Triangle inequality with sides given as expressions", "Medium",
  "Inverse/parameter",
  r"The sides of a triangle are $(x + 2)$ cm, $(2x - 3)$ cm and $(15 - x)$ cm, where $x$ is an integer. How many values of $x$ are possible?",
  "MCQ",
  r"The three inequalities are: $(x + 2) + (2x - 3) > 15 - x$, giving $x > 4$; $(x + 2) + (15 - x) > 2x - 3$, giving $x < 10$; and $(2x - 3) + (15 - x) > x + 2$, giving $12 > 2$, always true. All sides are then positive. So $x = 5, 6, 7, 8, 9$: $5$ values.",
  "Using non-strict inequalities, or checking only some of the three conditions.",
  "C15A-triangle-inequality-algebraic", "Three inequalities to set up; one is vacuous and the strictness matters.",
  correct=r"$5$",
  distractors=[(r"$7$", "Uses $\\ge$ in the inequalities, allowing $x = 4$ and $x = 10$ (flat triangles)."),
               (r"$8$", "Drops the condition $x > 4$ and only requires positive sides, so $x = 2, \\ldots, 9$."),
               (r"$10$", "Drops the condition $x < 10$, so $x = 5, \\ldots, 14$.")],
  check=_c024, values=[5, 7, 8, 10], cognitive="Application")


# 025
def _c025():
    t = _tris(30)
    cs = [c for (a, b, c) in t]
    return (min(cs), max(cs))

q("C15-A-025", T_, "Range of the longest side for a fixed integer perimeter", "Medium",
  "Inverse/parameter",
  r"A triangle has integer side lengths and a perimeter of $30$ cm. If $c$ denotes its longest side in cm, which of the following gives exactly all the possible values of $c$?",
  "MCQ",
  r"The longest side is at least the average side, so $3c \ge 30$ and $c \ge 10$ (the case $10, 10, 10$ works). The triangle inequality gives $c < 30 - c$, so $c < 15$ and $c \le 14$ (for example $8, 8, 14$). Every value in between occurs, so $10 \le c \le 14$.",
  "Allowing $c = 15$ from a non-strict triangle inequality, or excluding the equilateral case $c = 10$.",
  "C15A-longest-side-bounds", "Two bounds from different principles (average and triangle inequality).",
  correct=r"$10 \le c \le 14$",
  distractors=[(r"$10 \le c \le 15$", r"Uses $c \le 30 - c$, allowing the flat triangle $c = 15$."),
               (r"$11 \le c \le 14$", "Requires $c$ to be strictly longer than the other sides, excluding $10, 10, 10$."),
               (r"$11 \le c \le 15$", "Makes both of the above slips.")],
  check=_c025, values=[(10, 14), (10, 15), (11, 14), (11, 15)], cognitive="Analysis")


# 026
def _c026():
    return sum(1 for a, b, c in itertools.combinations(range(2, 9), 3) if a + b > c)

q("C15-A-026", T_, "Choosing three sticks from a set to form a triangle", "Difficult",
  "Casework/optimisation",
  r"Fatima has seven sticks of lengths $2, 3, 4, 5, 6, 7$ and $8$ cm, one of each. In how many ways can she choose three of the sticks so that they form a triangle?",
  "TITA",
  r"With $a < b < c$ the only condition is $a + b > c$. Count by the longest stick $c$: $c = 4$: $(2,3)$ gives $1$; $c = 5$: $(2,4),(3,4)$ gives $2$; $c = 6$: $(2,5),(3,4),(3,5),(4,5)$ gives $4$; $c = 7$: $(2,6),(3,5),(3,6),(4,5),(4,6),(5,6)$ gives $6$; $c = 8$: $(3,6),(3,7),(2,7),(4,5),(4,6),(4,7),(5,6),(5,7),(6,7)$ gives $9$. Total $1 + 2 + 4 + 6 + 9 = 22$.",
  "Counting triples with $a + b = c$ as triangles, or counting all choices of three sticks.",
  "C15A-sticks-triangle-count", "Five cases on the longest stick with up to nine pairs in a case; the strict inequality removes six flat triples that are easy to miss.",
  tita_answer=22, check=_c026, cognitive="Analysis", exams=TWO,
  tita_traps=[(28, "Counts the $6$ flat triples with $a + b = c$ as triangles."),
              (35, "Counts all $\\binom{7}{3}$ choices.")])


# 027
def _c027():
    sols = []
    for th in range(1, 180):
        O = (0.0, 0.0)
        A = (5.0, 0.0)
        d1 = _dir(150)                       # reflected ray from A makes 30 deg with AO
        u = _dir(th)
        # intersection with ray ON
        det = d1[0] * (-u[1]) - d1[1] * (-u[0])
        if abs(det) < 1e-12:
            continue
        rx, ry = O[0] - A[0], O[1] - A[1]
        t = (rx * (-u[1]) - ry * (-u[0])) / det
        s = (d1[0] * ry - d1[1] * rx) / det
        if t <= 0 or s <= 0:
            continue
        # reflect d1 about the line of ON
        dot = d1[0] * u[0] + d1[1] * u[1]
        d2 = (2 * dot * u[0] - d1[0], 2 * dot * u[1] - d1[1])
        if abs(d2[1]) < 1e-9:                # parallel to OM (the x-axis)
            sols.append(th)
    assert len(sols) == 1
    return sols[0]

q("C15-A-027", T_, "Angle between two mirrors from a parallel exit ray", "Medium",
  "Inverse/parameter",
  r"Two plane mirrors $OM$ and $ON$ meet at $O$. A ray of light in the plane $MON$ strikes mirror $OM$ at a point $X$, and the reflected ray travels towards $ON$ making an angle of $30^\circ$ with $XO$. After reflecting from $ON$, the ray travels parallel to $OM$. What is the measure of angle $MON$?",
  "MCQ",
  r"Let the reflected ray from $X$ meet $ON$ at $Y$ and let angle $MON = \theta$. In triangle $OXY$, angle $XYO = 180^\circ - 30^\circ - \theta = 150^\circ - \theta$. By the law of reflection the outgoing ray also makes $150^\circ - \theta$ with $ON$, and for it to be parallel to $OM$ this angle must equal the angle $\theta$ between $ON$ and $OM$ (corresponding angles). So $150 - \theta = \theta$, giving $\theta = 75^\circ$.",
  "Confusing 'parallel to the mirror' with 'parallel to the incident ray', or assuming the angle with the second mirror is again $30^\\circ$.",
  "C15A-mirror-reflection", "Combines the law of reflection, a triangle sum and parallel-line angles.",
  correct=r"$75^\circ$",
  distractors=[(r"$90^\circ$", "Uses the retro-reflection fact (two mirrors at $90^\\circ$ send a ray back parallel to itself) as if the exit ray had to be parallel to the incoming ray."),
               (r"$120^\circ$", "Assumes the ray meets $ON$ at $30^\\circ$ again: $150 - \\theta = 30$."),
               (r"$105^\circ$", "Finds $75^\\circ$ and reports its supplement.")],
  check=_c027, values=[75, 90, 120, 105], cognitive="Analysis", exams=TWO)


# 028
def _star_tip_sum(n, step=2, jitter=0.06, seed=3):
    import random
    rnd = random.Random(seed)
    V = []
    for i in range(n):
        a = 2 * _m.pi * i / n + rnd.uniform(-jitter, jitter)
        r = 1 + rnd.uniform(-jitter, jitter)
        V.append((r * _m.cos(a), r * _m.sin(a)))
    tot = 0.0
    for i in range(n):
        a0, a1, a2, a3 = V[(i - 1) % n], V[i], V[(i + 1) % n], V[(i + 2) % n]
        X = _meet(a0, (a1[0] - a0[0], a1[1] - a0[1]), a3, (a2[0] - a3[0], a2[1] - a3[1]))
        tot += _ang(a1, X, a2)
    return tot

def _c028():
    s = _r(_star_tip_sum(5))
    return int(round(s)) - (26 + 34 + 38 + 42)

q("C15-A-028", T_, "Tip angles of a five-pointed star from an irregular pentagon", "Medium",
  "Conceptual/application",
  r"The sides of a convex pentagon are extended so that, for each side, the two sides adjacent to it are extended beyond it until they meet, forming a five-pointed star. Four of the five angles at the points of the star measure $26^\circ$, $34^\circ$, $38^\circ$ and $42^\circ$. What is the measure of the fifth angle?",
  "MCQ",
  r"Each point of the star is the apex of a small triangle standing on one side of the pentagon, whose base angles are the exterior angles of the pentagon at the ends of that side. So the tip angles add to $5 \times 180^\circ - 2 \times 360^\circ = 180^\circ$, whatever the pentagon. The fifth angle is $180^\circ - (26 + 34 + 38 + 42)^\circ = 180^\circ - 140^\circ = 40^\circ$.",
  r"Assuming the regular-star value or an average without finding the fixed tip-angle sum, or confusing a tip angle with an exterior angle of the pentagon.",
  "C15A-star-angle-sum", "Needs the star tip-sum result, derived from exterior angles.",
  correct=r"$40^\circ$",
  distractors=[(r"$36^\circ$", "Uses the tip angle of a regular five-pointed star, $\\frac{180^\\circ}{5}$, ignoring the given angles."),
               (r"$35^\circ$", "Assumes the fifth tip equals the average of the other four: $\\frac{140^\\circ}{4}$."),
               (r"$72^\circ$", "Confuses a tip angle with an exterior angle of a regular pentagon, $\\frac{360^\\circ}{5}$.")],
  check=_c028, values=[40, 36, 35, 72], cognitive="Understanding")


# 029
def _quad29(angP=90, angQ=86, angR=110, angS=74, a=5.0, b=3.0):
    P = (0.0, 0.0); Q = (a, 0.0)
    hQ = 180 - angQ                       # heading of QR
    R = _add(Q, _dir(hQ), b)
    hR = hQ + (180 - angR)                # heading of RS
    hS = hR + (180 - angS)                # heading of SP
    S = _meet(R, _dir(hR), P, _dir(hS + 180))
    Tt = _meet(P, _dir(angP / 2), Q, _dir(180 - angQ / 2))
    return P, Q, R, S, Tt

def _c029():
    vals = set()
    for ap, aq in ((90, 86), (80, 96), (100, 76)):
        P, Q, R, S, Tt = _quad29(ap, aq)
        assert abs(_ang(Q, R, S) - 110) < 1e-6 and abs(_ang(R, S, P) - 74) < 1e-6 and abs(_ang(S, P, Q) - ap) < 1e-6
        vals.add(_r(_ang(P, Tt, Q)))
    assert len(vals) == 1
    return vals.pop()

_f = Fig()
_P29, _Q29, _R29, _S29, _T29 = _quad29()
_f.poly(_P29, _Q29, _R29, _S29); _f.seg(_P29, _T29); _f.seg(_Q29, _T29)
_f.pt("P", *_P29); _f.pt("Q", *_Q29); _f.pt("R", *_R29); _f.pt("S", *_S29); _f.pt("T", *_T29, offset=(0, 1))
_f.angle_mark(_S29, _R29, _Q29, r"110^\circ", r=0.5)
_f.angle_mark(_P29, _S29, _R29, r"74^\circ", r=0.5)
_alt = "Convex quadrilateral PQRS with PQ at the bottom. Angle QRS is marked 110 degrees and angle RSP is marked 74 degrees. The bisectors of angles P and Q meet at T inside the quadrilateral."
q("C15-A-029", T_, "Angle between bisectors of two adjacent angles of a quadrilateral", "Medium",
  "Conceptual/application",
  r"In a convex quadrilateral $PQRS$, angle $QRS = 110^\circ$ and angle $RSP = 74^\circ$. The bisectors of angles $SPQ$ and $PQR$ meet at $T$. What is the measure of angle $PTQ$?",
  "MCQ",
  r"Angles $P$ and $Q$ together make $360^\circ - 110^\circ - 74^\circ = 176^\circ$. In triangle $PTQ$ the angles at $P$ and $Q$ are halves of these, adding to $88^\circ$. So angle $PTQ = 180^\circ - 88^\circ = 92^\circ$, which is half of $110^\circ + 74^\circ$.",
  "Stopping at the sum of the half-angles, not halving, or carrying over the triangle bisector formula.",
  "C15A-bisectors-angle-sum", "Quadrilateral angle sum plus a triangle with two half-angles.",
  correct=r"$92^\circ$",
  distractors=[(r"$88^\circ$", "Reports the sum of the half-angles at $P$ and $Q$ instead of the third angle of triangle $PTQ$."),
               (r"$176^\circ$", "Reports angle $P$ + angle $Q$ without halving or completing the triangle."),
               (r"$127^\circ$", "Carries over the triangle result for two internal bisectors, $90^\\circ + \\frac{1}{2} \\times$ the remaining angle, using angle $RSP = 74^\\circ$: $90^\\circ + 37^\\circ$.")],
  check=_c029, values=[92, 88, 176, 127], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 030
def _c030():
    ok = [d for d in range(1, 60)
          if 5 + 9 > d and 5 + d > 9 and 9 + d > 5 and 7 + 13 > d and 7 + d > 13 and 13 + d > 7]
    return len(ok)

q("C15-A-030", T_, "A diagonal shared by two triangles: combined triangle inequalities", "Medium",
  "Inverse/parameter",
  r"Four villages $P$, $Q$, $R$, $S$, no three of them in a straight line, are joined by straight roads $PQ = 5$ km, $QR = 9$ km, $RS = 7$ km and $SP = 13$ km. A straight road is to be built from $P$ to $R$, and its length is a whole number of kilometres. How many lengths are possible for road $PR$?",
  "MCQ",
  r"Triangle $PQR$ needs $9 - 5 < PR < 9 + 5$, that is $4 < PR < 14$. Triangle $PRS$ needs $13 - 7 < PR < 13 + 7$, that is $6 < PR < 20$. Both hold for $7 \le PR \le 13$, which gives $7$ lengths.",
  "Using only one of the two triangles, or excluding a boundary value twice.",
  "C15A-triangle-inequality-diagonal", "Intersection of two triangle-inequality ranges.",
  correct=r"$7$",
  distractors=[(r"$9$", "Uses only triangle $PQR$: $PR = 5, \\ldots, 13$."),
               (r"$13$", "Uses only triangle $PRS$: $PR = 7, \\ldots, 19$."),
               (r"$5$", "Takes the overlap as $7 < PR < 13$, dropping both end values $7$ and $13$.")],
  check=_c030, values=[7, 9, 13, 5], cognitive="Application")


# =====================================================================
# DIFFICULT
# =====================================================================

# 031
def _c031():
    th = 12.0
    rays = [_dir(0), _dir(th)]
    last_t = [0.0, 0.0]          # distance of last marked point on each ray (O counts as 0)
    cur = (0.0, 0.0)
    count = 0
    # first point P1 on OX at distance 1
    cur = (1.0, 0.0); last_t[0] = 1.0; count = 1; side = 1
    while True:
        u = rays[side]
        b = cur[0] * u[0] + cur[1] * u[1]
        disc = b * b - (cur[0] ** 2 + cur[1] ** 2) + 1
        if disc < 0:
            break
        t = b + _m.sqrt(disc)
        if t <= last_t[side] + 1e-9:
            break
        cur = (u[0] * t, u[1] * t); last_t[side] = t; count += 1; side = 1 - side
        if count > 100:
            break
    return count

_f = Fig()
_O31 = (0.0, 0.0)
_f.seg(_O31, _add(_O31, _dir(0), 5.2)); _f.seg(_O31, _add(_O31, _dir(12), 5.2))
_p1 = (1.0, 0.0); _p2 = _add(_O31, _dir(12), 2 * _m.cos(_m.radians(12)))
_bb = _p2[0] * 1.0; _p3 = (_bb + _m.sqrt(_bb * _bb - (_p2[0] ** 2 + _p2[1] ** 2) + 1), 0.0)
_f.seg(_p1, _p2); _f.seg(_p2, _p3)
_f.pt("O", *_O31, offset=(-1, 0)); _f.pt("P1", *_p1, offset=(0, -1)); _f.pt("P2", *_p2, offset=(0, 1)); _f.pt("P3", *_p3, offset=(0, -1))
_f.text(_add(_O31, _dir(0), 5.5), "X"); _f.text(_add(_O31, _dir(12), 5.5), "Y")
_amark(_f, (1, 0), _O31, _dir(12), r"12^\circ", r=3.6, frac=0.5, lr=4.25)
_alt = "Two rays OX and OY from O with a 12 degree angle between them. The first three points of the construction are shown: P sub 1 on OX, P sub 2 on OY and P sub 3 on OX, with OP sub 1, P sub 1 P sub 2 and P sub 2 P sub 3 equal segments."
q("C15-A-031", T_, "Equal segments zigzagging between two rays: chain of isosceles triangles", "Difficult",
  "Casework/optimisation",
  r"Rays $OX$ and $OY$ make an angle of $12^\circ$. Points $P_1, P_2, P_3, \ldots$ are marked alternately on $OX$ and $OY$ ($P_1$ on $OX$, $P_2$ on $OY$, $P_3$ on $OX$, and so on) so that $OP_1 = P_1P_2 = P_2P_3 = \cdots = 1$ cm, and each new point is farther from $O$ than the point marked before it on the same ray. What is the largest number of points that can be marked?",
  "TITA",
  r"Triangle $OP_1P_2$ is isosceles with base angles $12^\circ$. Each next triangle $P_{k-1}P_kP_{k+1}$ is isosceles with base angles $12k^\circ$, by the exterior angle theorem applied to the previous triangle. A new point $P_{k+1}$ farther from $O$ exists only while $12k < 90$, that is $k \le 7$. So $P_1, \ldots, P_8$ can be marked: $8$ points.",
  "Counting only the triangles or dividing $180$ by the angle.",
  "C15A-isosceles-chain", "Needs the pattern of base angles $12^\\circ, 24^\\circ, 36^\\circ, \\ldots$ and the correct stopping rule.",
  tita_answer=8, check=_c031, cognitive="Analysis", exams=TWO,
  figure=dict(svg=_subscript_labels(_f.svg(alt=_alt), ("P1", "P2", "P3")), alt=_alt, required=False),
  tita_traps=[(7, "Counts the isosceles triangles $OP_1P_2, P_1P_2P_3, \\ldots, P_6P_7P_8$ instead of the points."),
              (15, "Uses $\\frac{180}{12}$.")])


# 032
def _c032():
    cnt = 0
    for a in range(1, 179):
        for b in range(a, 179):
            c = 180 - a - b
            if c >= b and c == 2 * a:
                cnt += 1
    return cnt

q("C15-A-032", T_, "Counting triangles with integer angles under a ratio condition", "Medium",
  "Casework/optimisation",
  r"How many triangles, no two of them similar, have all three angles equal to a whole number of degrees, with the largest angle exactly twice the smallest angle?",
  "TITA",
  r"Let the angles be $x \le y \le 2x$, so $y = 180 - 3x$. The condition $x \le 180 - 3x$ gives $x \le 45$, and $180 - 3x \le 2x$ gives $x \ge 36$. So $x = 36, 37, \ldots, 45$, which gives $10$ triangles; the ends are $36^\circ, 72^\circ, 72^\circ$ and $45^\circ, 45^\circ, 90^\circ$.",
  "Excluding the isosceles end cases or miscounting the inclusive range.",
  "C15A-integer-angle-triangles", "Two linear inequalities on one variable and an inclusive count; the end cases are easy to drop.",
  tita_answer=10, check=_c032, cognitive="Analysis", exams=TWO,
  tita_traps=[(8, "Excludes both isosceles end cases $x = 36$ and $x = 45$."),
              (9, "Excludes one end case, or computes $45 - 36$.")])


# 033
def _c033():
    found = set()
    for s in itertools.product(range(1, 11), repeat=3):
        a, b, c = sorted(s)
        if a + b > c and len({a, b, c}) == 2 and a + b + c <= 24:
            found.add((a, b, c))
    return len(found)

q("C15-A-033", T_, "Isosceles (not equilateral) integer triangles with capped sides and capped perimeter", "Difficult",
  "Casework/optimisation",
  r"A craft kit contains straight rods of every whole-number length from $1$ cm to $10$ cm, with as many rods of each length as needed. Meera joins three rods end to end to make a triangle in which exactly two sides are equal, and the total length of the three rods must not exceed $24$ cm. How many non-congruent such triangles can she make?",
  "TITA",
  r"Let the equal sides be $a$ and the third side $b \ne a$, with $1 \le a, b \le 10$. The conditions are $b < 2a$ (triangle), $b \le 10$ (rod length) and $2a + b \le 24$ (total length). For $a = 1$ none. For $a = 2, 3, 4, 5$ the triangle inequality binds: $b = 1, \ldots, 2a - 1$ except $b = a$, giving $2, 4, 6, 8$. For $a = 6, 7$ the rod cap binds: $b = 1, \ldots, 10$ except $b = a$, giving $9$ each. For $a = 8, 9, 10$ the total length binds: $b \le 8, 6, 4$, giving $7$ (excluding $b = 8$), $6$ and $4$. Total $20 + 18 + 7 + 6 + 4 = 55$.",
  "Ignoring one of the three binding conditions, counting the equilateral triangles, or treating 'not exceed' as strict.",
  "C15A-isosceles-bounded-sides", "Casework on the equal side with three regimes (triangle inequality, rod cap, total-length cap binding in turn) and an exclusion.",
  tita_answer=55, check=_c033, cognitive="Analysis", exams=TWO,
  tita_traps=[(65, "Ignores the total-length condition, keeping $9$ triangles for each of $a = 8, 9, 10$."),
              (63, "Includes the $8$ equilateral triangles with sides $1$ to $8$ cm, whose total length is at most $24$ cm."),
              (52, "Treats 'must not exceed $24$ cm' as less than $24$ cm, losing $(7, 7, 10)$, $(9, 9, 6)$ and $(10, 10, 4)$.")])


# 034
def _c034():
    return sum(1 for (a, b, c) in _tris(36) if a < b < c)

q("C15-A-034", T_, "Scalene integer-sided triangles with a fixed perimeter", "Difficult",
  "Casework/optimisation",
  r"A fencing contractor has a wire of length $36$ m and must bend it into a triangle whose sides are whole numbers of metres, all three different. How many non-congruent triangles are possible?",
  "TITA",
  r"With $a < b < c$, $a + b + c = 36$ and $a + b > c$, we need $c \le 17$ and, since the sides are distinct, $c \ge 13$. For each $c$, count $b$ with $\frac{36 - c}{2} < b < c$ and $a = 36 - c - b < b$: $c = 17$ gives $b = 10, \ldots, 16$ ($7$); $c = 16$: $b = 11, \ldots, 15$ ($5$); $c = 15$: $b = 11, \ldots, 14$ ($4$); $c = 14$: $b = 12, 13$ ($2$); $c = 13$: $b = 12$ ($1$). Total $7 + 5 + 4 + 2 + 1 = 19$.",
  "Including isosceles and equilateral triangles in the count.",
  "C15A-integer-perimeter-count", "Casework over the longest side with distinctness and strict triangle inequality.",
  tita_answer=19, check=_c034, cognitive="Analysis", exams=TWO,
  tita_traps=[(27, "Counts all integer triangles with perimeter $36$, including the $8$ with two equal sides."),
              (8, "Counts only the triangles with two equal sides.")])


# 035
def _c035():
    P = (0.0, 0.0); Q = (8.0, 0.0); R = (0.0, 6.0)
    f = lambda x, y: _m.hypot(x, y) + _m.hypot(x - 8, y) + _m.hypot(x, y - 6)
    fmin, N = 1e9, 400
    for i in range(1, N):
        for j in range(1, N - i):
            x, y = 8 * i / N, 6 * j / N
            fmin = min(fmin, f(x, y))
    sup = max(f(*P), f(*Q), f(*R))      # convex function: supremum over the open region is the vertex maximum
    options = [15, 12, 24, 26]
    ok = [v for v in options if fmin - 1e-6 <= v < sup]
    assert fmin > 13 and sup == 18
    assert len(ok) == 1
    return ok[0]

q("C15-A-035", T_, "Sum of distances from an interior point bounded by triangle inequalities", "Difficult",
  "Conceptual/application",
  r"A triangular park $PQR$ has $PQ = 8$ m, $PR = 6$ m and $QR = 10$ m. A lamp post $L$ stands strictly inside the park (not on its boundary). Which of the following could be the value of $LP + LQ + LR$?",
  "MCQ",
  r"Adding the triangle inequalities $LP + LQ > PQ$, $LQ + LR > QR$, $LR + LP > RP$ gives $2(LP + LQ + LR) > 24$, so the sum exceeds $12$. For an interior point, $LP + LQ < RP + RQ$, and similarly for the other two pairs; adding gives $2(LP + LQ + LR) < 48$, so the sum is less than $24$. This rules out $12$, $24$ and $26$. The sum is about $13.8$ at the centroid and approaches $QP + QR = 18$ near $Q$, so by continuity it takes the value $15$ at some interior point; $15$ m is possible.",
  "Treating the bounds (semi-perimeter, sum of two sides, perimeter) as values that can actually be reached.",
  "C15A-triangle-inequality-interior-point", "Needs two different triangle-inequality bounds and strictness for an interior point.",
  correct=r"$15$ m",
  distractors=[(r"$12$ m", "Takes the lower bound, the semi-perimeter, as attainable."),
               (r"$24$ m", "Takes the upper bound, the perimeter, as attainable."),
               (r"$26$ m", "Uses the cruder bound $(LP + LQ) + LR < (RP + RQ) + \\max(RP, RQ) = 16 + 10$ and takes this limit as attainable.")],
  check=_c035, values=[15, 12, 24, 26], cognitive="Analysis", exams=TWO)


# 036
def _c036():
    c = 12
    return sum(1 for a in range(1, c + 1) for b in range(a, c + 1) if a + b > c)

q("C15-A-036", T_, "Counting integer triangles with a given longest side", "Difficult",
  "Casework/optimisation",
  r"How many non-congruent triangles with integer side lengths have their longest side equal to $12$ units? (Other sides may also equal $12$.)",
  "MCQ",
  r"With sides $a \le b \le 12$ and $a + b > 12$: for $b = 12$, $a = 1, \ldots, 12$ ($12$); $b = 11$: $a = 2, \ldots, 11$ ($10$); $b = 10$: $8$; $b = 9$: $6$; $b = 8$: $4$; $b = 7$: $a = 6, 7$ ($2$). Total $12 + 10 + 8 + 6 + 4 + 2 = 42$.",
  "Counting ordered pairs, excluding $b = 12$, or counting only scalene triangles.",
  "C15A-integer-triangles-longest-side", "Casework on the middle side; several easy-to-make counting slips.",
  correct=r"$42$",
  distractors=[(r"$30$", "Requires the middle side to be less than $12$, dropping the $12$ triangles with $b = 12$."),
               (r"$78$", "Counts ordered pairs $(a, b)$ with $a, b \\le 12$ and $a + b > 12$: $144 - 66$."),
               (r"$25$", "Counts only scalene triangles with $a < b < 12$.")],
  check=_c036, values=[42, 30, 78, 25], cognitive="Analysis", exams=TWO)


# 037
def _eq37(theta):
    Q = (0.0, 0.0); R = (1.0, 0.0); P = (0.5, _m.sqrt(3) / 2)
    S = _add(R, _dir(180 + theta), 1.0)   # below QR, RS = RQ, angle QRS = theta
    return P, Q, R, S

def _c037():
    sols = []
    for th in range(1, 180):
        if th == 120:
            continue                      # P, R, S collinear
        P, Q, R, S = _eq37(th)
        assert S[1] < 0 and abs(_ang(Q, R, S) - th) < 1e-6
        if abs(_ang(R, S, Q) - 4 * _ang(R, S, P)) < 1e-7:
            sols.append(th)
    assert sols == [100, 132]
    return sum(sols)

q("C15-A-037", T_, "Equilateral triangle with an isosceles triangle on one side: two positions satisfy an angle ratio", "Difficult",
  "Casework/optimisation",
  r"$PQR$ is an equilateral triangle. Point $S$ lies on the opposite side of line $QR$ from $P$, with $RS = RQ$, and $P$, $R$, $S$ are not in a straight line. Angle $RSQ$ is four times angle $RSP$. What is the sum of all possible values of angle $QRS$?",
  "MCQ",
  r"Let angle $QRS = \theta$. In isosceles triangle $QRS$, angle $RSQ = \frac{180^\circ - \theta}{2}$. Triangle $PRS$ is isosceles with $RP = RS$. If $\theta < 120^\circ$, angle $PRS = 60^\circ + \theta$ and angle $RSP = \frac{120^\circ - \theta}{2}$, so $180 - \theta = 4(120 - \theta)$ and $\theta = 100^\circ$. If $\theta > 120^\circ$, the non-reflex angle $PRS = 360^\circ - 60^\circ - \theta = 300^\circ - \theta$ and angle $RSP = \frac{\theta - 120^\circ}{2}$, so $180 - \theta = 4(\theta - 120)$ and $\theta = 132^\circ$. Both work (angles $40^\circ, 10^\circ$ and $24^\circ, 6^\circ$), so the sum is $100^\circ + 132^\circ = 232^\circ$.",
  r"Assuming angle $PRS = 60^\circ + \theta$ in every position of $S$, so missing the case $\theta > 120^\circ$, or reversing the ratio.",
  "C15A-equilateral-angle-chase", r"Two isosceles triangles sharing vertex $R$, and the position of $S$ splits into two cases that both give valid answers.",
  correct=r"$232^\circ$",
  distractors=[(r"$100^\circ$", "Uses angle $PRS = 60^\\circ + \\theta$ only, finding just the case $\\theta < 120^\\circ$."),
               (r"$132^\circ$", "Finds only the case in which $S$ is beyond the extension of $PR$, $\\theta > 120^\\circ$."),
               (r"$168^\circ$", "Reads the ratio the other way round, angle $RSP = 4 \\times$ angle $RSQ$; only $\\theta > 120^\\circ$ then works: $\\theta - 120 = 4(180 - \\theta)$ gives $168^\\circ$.")],
  check=_c037, values=[232, 100, 132, 168], cognitive="Analysis", exams=TWO)


# 038
def _c038():
    from functools import lru_cache
    N = 100

    @lru_cache(maxsize=None)
    def ext(a, b):        # longest continuation after the two largest chosen lengths a < b
        best = 0
        for c in range(a + b, N + 1):
            best = max(best, 1 + ext(b, c))
        return best
    return max(2 + ext(a, b) for a in range(1, N + 1) for b in range(a + 1, N + 1))

q("C15-A-038", T_, "Largest set of rod lengths with no three forming a triangle", "Difficult",
  "Casework/optimisation",
  r"Ananya has a collection of rods whose lengths are different whole numbers of centimetres, each at most $100$ cm. No three of the rods can be joined end to end to form a triangle. What is the largest possible number of rods in her collection?",
  "MCQ",
  r"If the lengths in increasing order are $a_1 < a_2 < \cdots$, no triangle means $a_i + a_j \le a_k$ for all $i < j < k$; it is enough that $a_k \ge a_{k-1} + a_{k-2}$. To fit the most rods, start as small as possible and grow as slowly as possible: $1, 2, 3, 5, 8, 13, 21, 34, 55, 89$. The next would be $144 > 100$, so the maximum is $10$ rods.",
  "Treating three rods with $a + b = c$ as forming a triangle, or ignoring the condition that lengths are different.",
  "C15A-no-triangle-max-sticks", "Needs the reverse use of the triangle inequality and a Fibonacci-type extremal argument.",
  correct=r"$10$",
  distractors=[(r"$11$", "Ignores 'different lengths' and starts $1, 1, 2, 3, \\ldots, 89$."),
               (r"$9$", "Treats $a + b = c$ as a triangle, forcing $a_k \\ge a_{k-1} + a_{k-2} + 1$: $1, 2, 4, 7, 12, 20, 33, 54, 88$."),
               (r"$7$", "Requires each rod to be at least twice the previous one: $1, 2, 4, \\ldots, 64$.")],
  check=_c038, values=[10, 11, 9, 7], cognitive="Analysis", exams=TWO)


# 039
def _c039():
    best = 0
    for a in range(1, 37):
        for b in range(a + 1, 180):
            if a + 4 * b + 6 > 180:
                break
            for c in range(b + 1, 180):
                if a + b + 3 * c + 3 > 180:
                    break
                for d in range(c + 1, 180):
                    e = 180 - a - b - c - d
                    if e <= d:
                        break
                    best = max(best, a)
    return best

q("C15-A-039", T_, "Five concurrent lines with distinct integer angles: maximise the smallest", "Difficult",
  "Casework/optimisation",
  r"Five distinct straight lines pass through a point $O$ and divide the plane around $O$ into $10$ angles. Each of these angles is a whole number of degrees, and no two of them are equal except pairs of vertically opposite angles. What is the largest possible measure of the smallest of the $10$ angles?",
  "MCQ",
  r"Going round $O$, the $10$ angles are $\theta_1, \ldots, \theta_5$ followed by the same five again (vertically opposite), and $\theta_1 + \cdots + \theta_5 = 180^\circ$. These five are distinct integers, so if the smallest is $x$ their sum is at least $x + (x+1) + (x+2) + (x+3) + (x+4) = 5x + 10$. Hence $5x + 10 \le 180$, $x \le 34$, and $34, 35, 36, 37, 38$ (sum $180$) shows $34^\circ$ is achievable.",
  "Ignoring the distinctness condition, or treating all ten angles as distinct.",
  "C15A-concurrent-lines", "Requires modelling the ten angles as five vertical pairs and an extremal argument.",
  correct=r"$34^\circ$",
  distractors=[(r"$36^\circ$", "Ignores distinctness and takes five equal angles of $\\frac{180}{5}$."),
               (r"$31^\circ$", "Treats all $10$ angles as distinct integers summing to $360$: $10x + 45 \\le 360$."),
               (r"$33^\circ$", "Uses the strict inequality $5x + 10 < 180$.")],
  check=_c039, values=[34, 36, 31, 33], cognitive="Analysis", exams=TWO)


# 040
def _c040():
    return int(round(_star_tip_sum(7, jitter=0.04, seed=11)))

q("C15-A-040", T_, "Tip angles of a seven-pointed star built on a convex heptagon", "Difficult",
  "Conceptual/application",
  r"The sides of a convex heptagon are extended so that, for each side, the two sides adjacent to it are extended beyond it until they meet, forming the tip of a seven-pointed star (all seven tips are formed). What is the sum of the seven tip angles of the star?",
  "MCQ",
  r"Each tip is the apex of a triangle whose base is a side of the heptagon and whose base angles are the exterior angles of the heptagon at the two ends of that side. So the sum of tip angles is $7 \times 180^\circ - 2 \times (\text{sum of exterior angles}) = 1260^\circ - 720^\circ = 540^\circ$.",
  "Carrying over the five-pointed star total, or using the heptagon's interior or exterior angle sum.",
  "C15A-star-angle-sum", "Needs a general argument via exterior angles rather than a remembered result.",
  correct=r"$540^\circ$",
  distractors=[(r"$180^\circ$", "Uses the five-pointed star result for the seven-pointed star."),
               (r"$900^\circ$", "Uses the interior angle sum of a heptagon, $5 \\times 180^\\circ$."),
               (r"$360^\circ$", "Uses the exterior angle sum of a polygon.")],
  check=_c040, values=[540, 180, 900, 360], cognitive="Analysis", exams=TWO)
