import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Work puzzles"
HARD = ("CAT", "XAT")


# ---------------------------------------------------------------- EASY ----------

def _c1():
    total, day, rate = 0, 0, 9
    while total < 84:
        day += 1
        total += rate
        rate += 1
    return day
q("C07-D-001", T, "Daily output in arithmetic progression; days to finish a fixed length", "Easy",
  "Multi-step word problem",
  r"Ritu is painting a boundary wall $84$ m long. She paints $9$ m on the first day, and on every later day she paints $1$ m more than she painted on the previous day. In how many days will she finish painting the wall?",
  "MCQ",
  r"The daily lengths $9, 10, 11, \dots$ form an arithmetic progression, so after $n$ days she has painted $\frac{n}{2}\left(2 \times 9 + (n - 1)\right) = \frac{n(n + 17)}{2}$ m. Setting this equal to $84$ gives $n(n + 17) = 168 = 7 \times 24$, so $n = 7$ days. Check: $9 + 10 + \dots + 15 = 84$.",
  "Treating the first day's output as a constant daily rate.",
  "C07D-ap-daily-efficiency", "One arithmetic-series sum set equal to the total; a single factorisation.",
  correct=r"$7$", distractors=[
      (r"$10$", "Ignores the daily increase: $\\frac{84}{9} = 9.33$, rounded up to $10$."),
      (r"$6$", "Multiplies the number of days by the last day's output: $n(n + 8) = 84$ gives $n = 6$."),
      (r"$4$", "Omits the halving in the series sum: $n(18 + (n - 1)) = 84$, that is $n(n + 17) = 84$, gives $n = 4$.")],
  check=_c1, values=[7, 10, 6, 4], cognitive="Application")


def _c2():
    a, d = symbols('a d')
    s = solve([Eq(Rational(10, 2) * (2 * a + 9 * d), 300), Eq(a + 9 * d, 4 * a)], [a, d], dict=True)[0]
    assert s[a].is_integer and s[d].is_integer
    return s[a]
q("C07-D-002", T, "Arithmetic growth of daily output; recover the first-day output", "Easy",
  "Inverse/parameter",
  r"A new packer at a warehouse packs more boxes each day than on the previous day, the daily increase being the same every day. In her first $10$ days she packs $300$ boxes in all, and on the $10$th day she packs $4$ times as many boxes as on the $1$st day. How many boxes did she pack on the $1$st day?",
  "MCQ",
  r"The daily counts form an arithmetic progression, so the average over the $10$ days is the average of the first and last days: $\frac{a + 4a}{2} = \frac{5a}{2}$. Then $10 \times \frac{5a}{2} = 25a = 300$, so $a = 12$ boxes (and the daily increase is $\frac{48 - 12}{9} = 4$ boxes).",
  "Taking the average daily output as the first-day output.",
  "C07D-ap-daily-efficiency", "Uses the first-and-last-term average of an AP in one step.",
  correct=r"$12$", distractors=[
      (r"$30$", "Takes the average daily output $\\frac{300}{10} = 30$ as the first-day output."),
      (r"$6$", "Writes the total as $10 \\times (a + 4a) = 300$, omitting the halving, so $a = 6$."),
      (r"$48$", "Solves correctly but reports the tenth-day output $4 \\times 12 = 48$.")],
  check=_c2, values=[12, 30, 6, 48], cognitive="Application")


def _c3():
    rem, n = Fraction(1), 0
    while rem > Fraction(1, 5):
        n += 1
        rem -= rem / 3
    return n
q("C07-D-003", T, "Each day a fixed fraction of the remaining work is done; days to reach a target", "Easy",
  "Multi-step word problem",
  r"A cleaning crew working on a flooded basement manages, each day, to clear exactly one-third of the mud that remains at the start of that day. What is the minimum number of days after which at least $80\%$ of the original mud has been cleared? Type the number of days.",
  "TITA",
  r"After each day $\frac{2}{3}$ of the previous amount remains, so after $n$ days $\left(\frac{2}{3}\right)^n$ remains. We need $\left(\frac{2}{3}\right)^n \le \frac{1}{5}$: $\left(\frac{2}{3}\right)^3 = \frac{8}{27} \approx 0.30$ is too large and $\left(\frac{2}{3}\right)^4 = \frac{16}{81} \approx 0.198$ works. The answer is $4$ days.",
  "Taking one-third of the original amount each day, so that three days clear everything.",
  "C07D-fraction-of-remaining", "Repeated multiplication by $\\frac{2}{3}$ and one comparison.",
  tita_answer=4, check=_c3, tita_traps=[
      (3, "Takes one-third of the original mud each day, so $3$ days clear all of it."),
      (1, "Applies the $80\\%$ condition to the mud remaining instead of the mud cleared: $\\frac{2}{3} \\le 0.8$ after $1$ day.")],
  cognitive="Application")


def _c4():
    done, day = 0, 0
    while done < 36:
        day += 1
        done += day
    return day
q("C07-D-004", T, "One worker joins every day; days to finish", "Easy",
  "Multi-step word problem",
  r"A job would take one worker $36$ days. A contractor puts one worker on the job on day $1$, and at the start of every later day one more worker of the same efficiency joins, so there are $2$ workers on day $2$, $3$ on day $3$, and so on. On which day is the job completed? Type the day number.",
  "TITA",
  r"The job is $36$ worker-days. After $n$ days the work done is $1 + 2 + \dots + n = \frac{n(n+1)}{2}$ worker-days. $\frac{n(n+1)}{2} = 36$ gives $n(n+1) = 72$, so $n = 8$: the job is completed exactly at the end of day $8$.",
  "Mixing up the number of workers on day $n$ with $n - 1$, or using $n^2$ for the total.",
  "C07D-joining-pattern", "Triangular-number sum equal to the total; one factorisation.",
  tita_answer=8, check=_c4, tita_traps=[
      (6, "Sets $n^2 = 36$ instead of $\\frac{n(n+1)}{2} = 36$."),
      (9, "Uses $\\frac{n(n-1)}{2} = 36$, treating day $n$ as having $n - 1$ workers.")],
  cognitive="Application")


def _c5():
    for x in range(1, 100):
        if sum(x + 4 * k for k in range(5)) == 90:
            return x
q("C07-D-005", T, "Workforce grows by a fixed number daily; find the starting workforce", "Easy",
  "Inverse/parameter",
  r"A road repair needs $90$ worker-days of work. The contractor starts with some workers on day $1$ and, at the start of each later day, adds $4$ more workers of the same efficiency. The repair is completed exactly at the end of day $5$. How many workers were there on day $1$?",
  "MCQ",
  r"With $x$ workers on day $1$, the daily workforce is $x, x+4, x+8, x+12, x+16$, totalling $5x + 40$ worker-days. So $5x + 40 = 90$ and $x = 10$.",
  "Adding the extra workers from day $1$ itself.",
  "C07D-joining-pattern", "One linear equation after summing a short arithmetic sequence.",
  correct=r"$10$", distractors=[
      (r"$6$", "Adds $4$ workers on day $1$ as well, so the workforce is $x+4, \\dots, x+20$ and $5x + 60 = 90$."),
      (r"$18$", "Ignores the added workers and divides $90$ by $5$."),
      (r"$26$", "Solves correctly but reports the day-$5$ workforce $10 + 16$.")],
  check=_c5, values=[10, 6, 18, 26], cognitive="Application")


def _c6():
    work = 6 * 14
    n = 1
    while n * 9 < work:
        n += 1
    return n - 6
q("C07-D-006", T, "Minimum whole number of extra workers to meet a deadline", "Easy",
  "Inverse/parameter",
  r"A team of $6$ identical workers can complete a job in $14$ days. The job must now be completed in at most $9$ days. Identical workers can be added only at the start, and all of them stay until the job is finished. What is the minimum number of workers that must be added? Type the number of additional workers.",
  "TITA",
  r"The job is $6 \times 14 = 84$ worker-days. In $9$ days a team of $n$ does $9n$ worker-days, so $9n \ge 84$ gives $n \ge 9.33$, hence $n = 10$. The number to be added is $10 - 6 = 4$.",
  "Rounding $9.33$ down, or reporting the size of the whole team.",
  "C07D-integer-workforce-deadline", "One division followed by rounding up to a whole number of workers.",
  tita_answer=4, check=_c6, tita_traps=[
      (3, "Rounds $\\frac{84}{9} = 9.33$ down to $9$ workers."),
      (10, "Reports the total team size instead of the number added.")],
  cognitive="Application")


def _c7():
    flat_rate = Fraction(12, 12)            # km per day on flat ground
    hill_rate = flat_rate / 2
    sections = [(Fraction(4), flat_rate), (Fraction(6), hill_rate), (Fraction(5), flat_rate)]
    t = Fraction(0)
    for length, rate in sections:           # stages done one after the other
        t += length / rate
    return t
q("C07-D-007", T, "Multi-stage project where the crew's rate depends on the stage", "Easy",
  "Multi-step word problem",
  r"A road crew can lay $12$ km of road on flat ground in $12$ days. On hilly ground it lays road at only half its flat-ground rate. A new $15$ km road is laid from one end to the other: the first $4$ km are flat, the next $6$ km are hilly and the last $5$ km are flat. How many days does the crew take to lay the whole road?",
  "MCQ",
  r"On flat ground the crew lays $1$ km a day and on hilly ground $\frac{1}{2}$ km a day. The $9$ km of flat road take $9$ days and the $6$ km of hilly road take $\frac{6}{1/2} = 12$ days. Total $= 9 + 12 = 21$ days.",
  "Averaging the two rates without weighting them by the work done at each rate.",
  "C07D-efficiency-change-midway", "Two rates applied to known amounts of work; one division each.",
  correct=r"$21$ days", distractors=[
      (r"$20$ days", "Uses the simple average of the two rates, $\\frac{1 + 0.5}{2} = 0.75$ km a day: $\\frac{15}{0.75}$."),
      (r"$18$ days", "Takes half the rate to mean $50\\%$ more time on the hilly part: $9 + 6 \\times 1.5$."),
      (r"$15$ days", "Ignores the slower rate on hilly ground: $15$ km at $1$ km a day.")],
  check=_c7, values=[21, 20, 18, 15], cognitive="Application")


def _c8():
    rate = 40 * Fraction(3, 4)
    return 480 / rate
q("C07-D-008", T, "Effective rate when a fixed share of output must be redone", "Easy",
  "Single-step computation",
  r"A typist types at a steady $40$ pages per hour, but on average one page in every four that she types has to be discarded and typed again; only the other pages are accepted. Treating her rate of producing accepted pages as steady, how many hours will she take to produce $480$ accepted pages? Type the number of hours.",
  "TITA",
  r"Three of every four pages typed are accepted, so she produces $40 \times \frac{3}{4} = 30$ accepted pages per hour. Time $= \frac{480}{30} = 16$ hours.",
  "Ignoring the discarded pages and dividing by the raw typing speed.",
  "C07D-rework-effective-rate", "One effective-rate computation and one division.",
  tita_answer=16, check=_c8, tita_traps=[
      (12, "Ignores the discarded pages: $\\frac{480}{40} = 12$."),
      (15, "Adds $25\\%$ to the page count instead of dividing by $\\frac{3}{4}$: $\\frac{480 \\times 1.25}{40} = \\frac{600}{40} = 15$.")],
  cognitive="Application")


def _c9():
    times = {"Priya": {"fence": 2, "lawn": 3}, "Arjun": {"fence": 3, "lawn": 6}}
    best = None
    for perm in itertools.permutations(["fence", "lawn"]):
        m = max(times["Priya"][perm[0]], times["Arjun"][perm[1]])
        best = m if best is None else min(best, m)
    return best
q("C07-D-009", T, "Assigning two indivisible tasks to two people to finish earliest", "Easy",
  "Casework/optimisation",
  r"Priya can paint a fence in $2$ hours or mow a lawn in $3$ hours. Arjun can paint the same fence in $3$ hours or mow the same lawn in $6$ hours. Each of them takes exactly one of the two tasks and does it alone, and both start at the same time. What is the least time in which both tasks can be finished?",
  "MCQ",
  r"There are only two assignments. Priya on the fence and Arjun on the lawn finishes in $\max(2, 6) = 6$ hours. Priya on the lawn and Arjun on the fence finishes in $\max(3, 3) = 3$ hours. The least time is $3$ hours.",
  "Letting the faster person take the task at which she is fastest, without checking the other person's time.",
  "C07D-assign-indivisible-tasks", "Two cases to compare; the trap is the greedy choice.",
  correct=r"$3$ hours", distractors=[
      (r"$6$ hours", "Gives Priya her quickest task (the fence), leaving Arjun the lawn."),
      (r"$2$ hours", "Reports the smallest single time in the data."),
      (r"$5$ hours", "Has Priya do both tasks, $2 + 3$.")],
  check=_c9, values=[3, 6, 2, 5], cognitive="Analysis")


def _c10():
    length, clear, slide = 34, 7, 3
    cleared, day = 0, 0
    while True:
        day += 1
        cleared = min(length, cleared + clear)
        if cleared >= length:
            return day
        cleared -= slide                    # overnight slide
q("C07-D-010", T, "Daily progress partly undone overnight; day of completion", "Easy",
  "Conceptual/application",
  r"A crew is clearing a $34$ m stretch of road buried by a landslide. Each day the crew clears $7$ m of debris, but each night loose debris slides back and buries $3$ m of the cleared part again. As soon as the whole stretch is clear at the end of a day's work, the road is opened and no more debris slides onto it. On which day is the road opened?",
  "MCQ",
  r"The net gain over a full day and night is $7 - 3 = 4$ m, but on the final day there is no slide afterwards. At the end of day $k$ the cleared length is $4(k - 1) + 7 = 4k + 3$ m. We need $4k + 3 \ge 34$, so $k \ge 7.75$ and $k = 8$. (At the end of day $7$ only $31$ m are clear.) The road is opened on day $8$.",
  "Using the net daily gain all the way to the end, forgetting that the last day's work is not undone.",
  "C07D-net-progress-setback", "One net-rate idea plus the final-day trap.",
  correct=r"Day $8$", distractors=[
      (r"Day $9$", "Uses the net gain of $4$ m every day: $\\frac{34}{4} = 8.5$, rounded up to $9$."),
      (r"Day $5$", "Ignores the overnight slide: $\\frac{34}{7} = 4.86$, rounded up to $5$."),
      (r"Day $7$", "Leaves $7$ m for the last day, so needs $\\frac{34 - 7}{4} = 6.75$ net days, rounds to $7$ and forgets to add the final day.")],
  check=_c10, values=[8, 9, 5, 7], cognitive="Analysis")


def _c11():
    n = 1
    while n * 6 < 100:
        n += 1
    return n
q("C07-D-011", T, "Training day with no output; minimum whole workforce", "Easy",
  "Inverse/parameter",
  r"A job needs $100$ worker-days of productive work and must be finished within $7$ days. All workers are hired together at the start, and every newly hired worker spends the first day in training and does no productive work that day; from day $2$ onward each does one worker-day of work per day. What is the minimum number of workers that must be hired?",
  "MCQ",
  r"Each worker is productive on only $6$ of the $7$ days, so $n$ workers give $6n$ worker-days. $6n \ge 100$ needs $n \ge 16.67$, so $n = 17$.",
  "Forgetting the unproductive training day, or rounding down.",
  "C07D-integer-workforce-deadline", "One inequality with a whole-number round-up and a lost day.",
  correct=r"$17$", distractors=[
      (r"$15$", "Ignores the training day: $\\frac{100}{7} = 14.3$, rounded up."),
      (r"$16$", "Accounts for the training day but rounds $16.67$ down."),
      (r"$14$", "Ignores the training day and rounds $14.3$ down.")],
  check=_c11, values=[17, 15, 16, 14], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM --------

def _c12():
    rem = Fraction(200)
    day, p, s = 0, 20, 4
    while True:
        day += 1
        r = p + s
        if r >= rem:
            return (day - 1) * 6 + rem / r * 6
        rem -= r
        p -= 2
        s += 2
q("C07-D-012", T, "One worker's output falls and the other's rises by the same amount daily", "Medium",
  "Conceptual/application",
  r"Pooja and Sameer start together on a job of $200$ units. On day $1$ Pooja does $20$ units and each later day she does $2$ units fewer than the day before. On day $1$ Sameer does $4$ units and each later day he does $2$ units more than the day before. They work $6$ hours a day, and within any day each works at a uniform rate. Counting only the hours of working time that pass (for example, a job finished $3$ hours into day $2$ ends $9$ working hours after the start), how many working hours after the start is the job finished? Type the number of hours.",
  "TITA",
  r"Pooja's loss of $2$ units a day is exactly Sameer's gain, so together they do $20 + 4 = 24$ units every day. In $8$ days they do $192$ units; the remaining $8$ units take $\frac{8}{24} = \frac{1}{3}$ of day $9$, which is $2$ hours. Total $= 8 \times 6 + 2 = 50$ hours.",
  "Rounding up to whole days, or dropping the part-day at the end.",
  "C07D-ap-daily-efficiency", "Spotting that the combined rate is constant, then converting a part-day into hours.",
  tita_answer=50, check=_c12, tita_traps=[
      (54, "Counts the last part-day as a full $6$-hour day: $9 \\times 6$."),
      (48, "Counts only the $8$ full days, $8 \\times 6$, and overlooks the $8$ units still left for day $9$.")],
  cognitive="Analysis")


def _c13():
    for W in range(1, 2000):
        rem = Fraction(W)
        ok = True
        for day in (1, 2, 3):
            d = rem / 2 + 10
            if day < 3:
                if d >= rem:
                    ok = False
                    break
                rem -= d
            else:
                ok = ok and d == rem
        if ok:
            return W
q("C07-D-013", T, "Half the remaining work plus a fixed amount each day; work backwards", "Medium",
  "Conceptual/application",
  r"Each day, a data-entry team completes half of the forms remaining at the start of that day and then $10$ more forms. Working this way, the team completes all the forms exactly at the end of the $3$rd day. How many forms were there at the start?",
  "MCQ",
  r"Work backwards. If $R$ forms remain at the start of a day and none remain after it, then $\frac{R}{2} + 10 = R$, so $R = 20$ at the start of day $3$. At the start of each earlier day the count is $2 \times (\text{next count} + 10)$: start of day $2$ is $2(20 + 10) = 60$, start of day $1$ is $2(60 + 10) = 140$.",
  "Undoing the steps in the wrong order when working backwards.",
  "C07D-fraction-of-remaining", "Reversing a two-operation daily rule over three days.",
  correct=r"$140$", distractors=[
      (r"$70$", "Reverses the operations in the wrong order: doubles first and then adds $10$, giving $10, 30, 70$."),
      (r"$60$", "Stops one step early and reports the count at the start of day $2$."),
      (r"$100$", "Takes the work on the last day to be only $10$ forms, so $10$ remain at the start of day $3$; then $40$ and $100$.")],
  check=_c13, values=[140, 70, 60, 100], cognitive="Analysis")


def _c14():
    h = symbols('h', positive=True)
    robot = 96 + 48 + 24
    return solve(Eq(robot + 3 * h, 300), h)[0]
q("C07-D-014", T, "Machine output halves daily; constant helper rate needed for a deadline", "Medium",
  "Inverse/parameter",
  r"A new printing machine prints $96$ thousand pages on day $1$, and on each later day it prints half as many pages as on the previous day. An older machine prints the same number of pages every day. Together, starting on day $1$, they must print $300$ thousand pages within $3$ days. What is the least daily output of the older machine, in thousand pages, that makes this possible?",
  "MCQ",
  r"In $3$ days the new machine prints $96 + 48 + 24 = 168$ thousand pages. The older machine must print the remaining $132$ thousand in $3$ days, so at least $\frac{132}{3} = 44$ thousand pages a day.",
  "Treating the falling output as constant, or halving from day $1$ itself.",
  "C07D-geometric-daily-output", "A short geometric sum followed by an inverse division.",
  correct=r"$44$", distractors=[
      (r"$4$", "Treats the new machine as printing $96$ thousand every day: $\\frac{300 - 288}{3}$."),
      (r"$72$", "Halves the output on day $1$ itself, using $48 + 24 + 12 = 84$: $\\frac{216}{3}$."),
      (r"$40$", "Uses the average of the first and last days, $\\frac{96 + 24}{2} = 60$ a day, so $180$ in total: $\\frac{120}{3}$.")],
  check=_c14, values=[44, 4, 72, 40], cognitive="Application")


def _c15():
    done, day, w = 0, 0, 20
    while done < 110:
        day += 1
        done += w
        w -= 2
    return day
q("C07-D-015", T, "Workers leave every day; day of completion", "Medium",
  "Multi-step word problem",
  r"A job requires $110$ worker-days of work. A team of $20$ identical workers starts it, and at the end of every day $2$ workers leave, so $18$ work on day $2$, $16$ on day $3$, and so on. On which day is the job completed? Type the day number.",
  "TITA",
  r"After $n$ days the work done is $20 + 18 + \dots + (22 - 2n) = 20n - n(n-1) = 21n - n^2$. Setting $21n - n^2 = 110$ gives $n^2 - 21n + 110 = 0$, so $n = 10$ or $n = 11$. The job is finished as soon as $110$ is reached, which happens at the end of day $10$ (on day $11$ no workers would remain). The answer is $10$.",
  "Choosing the wrong root of the quadratic or ignoring the falling workforce.",
  "C07D-leaving-pattern", "Quadratic in the number of days with a root to reject.",
  tita_answer=10, check=_c15, tita_traps=[
      (11, "Takes the larger root of $n^2 - 21n + 110 = 0$."),
      (6, "Ignores the departures: $\\frac{110}{20} = 5.5$, rounded up.")],
  cognitive="Analysis")


def _c16():
    best = None
    for i in range(0, 121):
        a = Fraction(i, 120)            # Ravi's share of time on wiring
        for j in range(0, 121):
            b = Fraction(j, 120)        # Sita's share of time on wiring
            wr = a / 3 + b / 4
            pr = (1 - a) / 6 + (1 - b) / 4
            if wr == 0 or pr == 0:
                continue
            t = max(1 / wr, 1 / pr)
            best = t if best is None else min(best, t)
    return best * 60
q("C07-D-016", T, "Sharing two divisible tasks between two workers to minimise time", "Medium",
  "Casework/optimisation",
  r"A room needs painting and wiring, two independent tasks that can go on at the same time. Ravi alone can paint the room in $6$ hours or wire it in $3$ hours; Sita alone can paint it in $4$ hours or wire it in $4$ hours. Both start together, either of them may work on either task and switch at any moment, and both may work on the same task together. What is the least time in which both tasks can be completed?",
  "MCQ",
  r"Compared with Sita, Ravi is relatively better at wiring ($2$ rooms' worth of wiring per room of painting against Sita's $1$), so Ravi should wire and Sita should paint. Ravi wires the room in $3$ hours, when Sita has painted $\frac{3}{4}$ of it. Both then paint the last $\frac{1}{4}$ at $\frac{1}{6} + \frac{1}{4} = \frac{5}{12}$ per hour, taking $\frac{3}{5}$ hour $= 36$ minutes. Total $= 3$ hours $36$ minutes $= 216$ minutes.",
  "Assigning tasks without letting the early finisher help, or assigning them the wrong way round.",
  "C07D-split-divisible-tasks", "Needs comparative advantage and then a help phase.",
  correct=r"$216$ minutes", distractors=[
      (r"$240$ minutes", "Ravi wires and Sita paints, but Ravi does not help after finishing: $\\max(3, 4)$ hours."),
      (r"$288$ minutes", "Ravi paints and Sita wires, with help afterwards: after $4$ hours $\\frac{1}{3}$ of the painting is left, taking $\\frac{4}{5}$ hour more."),
      (r"$180$ minutes", "Stops the clock when Ravi finishes the wiring.")],
  check=_c16, values=[216, 240, 288, 180], cognitive="Analysis")


def _c17():
    t = {"Joseph": (2, 4, 5), "Fatima": (3, 9, 9), "Harpreet": (6, 5, 6)}
    ppl = list(t)
    return min(sum(t[p][k] for p, k in zip(ppl, perm)) for perm in itertools.permutations(range(3)))
q("C07-D-017", T, "One task per person; minimise total person-hours", "Medium",
  "Casework/optimisation",
  r"Three jobs in a flat (wiring, plumbing and painting) are to be given to Joseph, Fatima and Harpreet, one job each, and each job is done by its assignee alone. The hours each person needs for each job are: Joseph: wiring $2$, plumbing $4$, painting $5$; Fatima: wiring $3$, plumbing $9$, painting $9$; Harpreet: wiring $6$, plumbing $5$, painting $6$. What is the least possible total number of person-hours used for the three jobs?",
  "MCQ",
  r"List the six assignments (Joseph, Fatima, Harpreet). Wiring, plumbing, painting: $2 + 9 + 6 = 17$; wiring, painting, plumbing: $2 + 9 + 5 = 16$; plumbing, wiring, painting: $4 + 3 + 6 = 13$; plumbing, painting, wiring: $4 + 9 + 6 = 19$; painting, wiring, plumbing: $5 + 3 + 5 = 13$; painting, plumbing, wiring: $5 + 9 + 6 = 20$. The least total is $13$ person-hours. Giving Joseph his quickest job (wiring) forces Fatima onto a $9$-hour job.",
  "Greedily giving the overall quickest pairing first.",
  "C07D-assign-indivisible-tasks", "Six cases; the greedy choice is a deliberate trap.",
  correct=r"$13$", distractors=[
      (r"$16$", "Greedy: gives Joseph wiring ($2$), then Harpreet plumbing ($5$), leaving Fatima painting ($9$)."),
      (r"$10$", "Adds each person's own fastest time, $2 + 3 + 5$, though Joseph and Fatima would both be wiring."),
      (r"$11$", "Adds the fastest time for each job, $2 + 4 + 5$, though Joseph would do two jobs.")],
  check=_c17, values=[13, 16, 10, 11], cognitive="Analysis")


def _c18():
    # simulate: Kabir on P (6 h alone), Sneha on Q (4 h alone), Sneha helps on P after Q (12 h alone on P)
    p_rem = Fraction(1)
    t = Fraction(4)
    p_rem -= t / 6
    t += p_rem / (Fraction(1, 6) + Fraction(1, 12))
    return t * 60
q("C07-D-018", T, "Early finisher joins the other's unfinished task", "Medium",
  "Multi-step word problem",
  r"Kabir starts sanding a floor and Sneha starts varnishing a door at the same moment. Kabir alone takes $6$ hours to sand the floor; Sneha alone takes $4$ hours to varnish the door and would take $12$ hours to sand the floor alone. As soon as Sneha finishes the door she joins Kabir on the floor. How many minutes after the start is the floor finished? Type the number of minutes.",
  "TITA",
  r"In the first $4$ hours Kabir sands $\frac{4}{6} = \frac{2}{3}$ of the floor, leaving $\frac{1}{3}$. Together they sand $\frac{1}{6} + \frac{1}{12} = \frac{1}{4}$ of the floor per hour, so the rest takes $\frac{1/3}{1/4} = \frac{4}{3}$ hours $= 80$ minutes. Total $= 240 + 80 = 320$ minutes.",
  "Ignoring the help, or giving Sneha Kabir's sanding rate.",
  "C07D-finish-then-help", "Two phases with a change in the team on one task.",
  tita_answer=320, check=_c18, tita_traps=[
      (360, "Ignores Sneha's help: Kabir alone takes $6$ hours."),
      (300, "Gives Sneha Kabir's sanding rate, so the last $\\frac{1}{3}$ takes $60$ minutes.")],
  cognitive="Application")


def _c19():
    best = None
    for s in range(0, 10):
        for t in range(0, 15):
            if 3 * s + 2 * t >= 25:
                c = 900 * s + 500 * t
                best = c if best is None else min(best, c)
    return best
q("C07-D-019", T, "Cheapest whole-number mix of two worker types for a daily output", "Medium",
  "Casework/optimisation",
  r"A site must turn out at least $25$ units of work every day. A mason does $3$ units a day and is paid Rs. $900$ a day; a helper does $2$ units a day and is paid Rs. $500$ a day. Any whole number of masons and helpers can be hired. What is the least possible daily wage bill?",
  "MCQ",
  r"Per unit, a helper costs Rs. $250$ and a mason Rs. $300$, so helpers are cheaper, but $25$ is odd and helpers give only even totals. All helpers needs $13$ helpers (Rs. $6{,}500$, $26$ units). One mason plus $11$ helpers gives exactly $3 + 22 = 25$ units for $900 + 5{,}500 =$ Rs. $6{,}400$. More masons cost more ($3$ masons and $8$ helpers cost Rs. $6{,}700$), so the minimum is Rs. $6{,}400$.",
  "Using the cheaper rate per unit without respecting whole workers.",
  "C07D-integer-mix-min-cost", "Integer constraint overturns the cheapest-per-unit rule.",
  correct=r"Rs. $6{,}400$", distractors=[
      (r"Rs. $6{,}250$", "Allows $12.5$ helpers: $25 \\times 250$."),
      (r"Rs. $6{,}500$", "Uses only helpers, the cheaper per unit, needing $13$ of them."),
      (r"Rs. $8{,}100$", "Uses only masons, needing $9$ of them.")],
  check=_c19, values=[6400, 6250, 6500, 8100], cognitive="Analysis")


def _c20():
    best = None
    for i in range(0, 51):
        tp = Fraction(i, 10)                    # hours the faster machine runs
        frac_q = 1 - tp / 6
        if frac_q < 0:
            continue
        tq = frac_q * 9
        if tq > 5:
            continue
        c = 500 * tp + 400 * tq
        best = c if best is None else min(best, c)
    return best
q("C07-D-020", T, "Cheapest use of two machines under a deadline", "Medium",
  "Casework/optimisation",
  r"Machine P alone can finish a job in $6$ hours and costs Rs. $500$ for each hour it runs. Machine Q alone can finish the same job in $9$ hours and costs Rs. $400$ for each hour it runs. The machines can work on the job at the same time, and each may be run for any length of time. If the job must be finished within $5$ hours, what is the least possible running cost?",
  "MCQ",
  r"For the whole job P costs $6 \times 500 =$ Rs. $3{,}000$ and Q costs $9 \times 400 =$ Rs. $3{,}600$, so P should do as much as possible. In $5$ hours P does $\frac{5}{6}$ of the job (Rs. $2{,}500$). Q does the remaining $\frac{1}{6}$ in $1.5$ hours (Rs. $600$), alongside P. Least cost $=$ Rs. $3{,}100$.",
  "Ignoring the deadline, or running both machines for the whole time.",
  "C07D-cost-time-tradeoff", "Cheapest machine per job first, then the deadline forces a top-up.",
  correct=r"Rs. $3{,}100$", distractors=[
      (r"Rs. $3{,}000$", "Uses P alone and overlooks that it needs $6$ hours, beyond the $5$-hour limit."),
      (r"Rs. $3{,}240$", "Runs both from the start until done: $3.6$ hours at Rs. $900$ per hour."),
      (r"Rs. $4{,}500$", "Runs both machines for the full $5$ hours.")],
  check=_c20, values=[3100, 3000, 3240, 4500], cognitive="Analysis")


def _trench(t, pts):
    # piecewise-linear trench length through points (time, length)
    for (t0, l0), (t1, l1) in zip(pts, pts[1:]):
        if t <= t1:
            return l0 + (l1 - l0) * (t - t0) / (t1 - t0)
    return pts[-1][1]


def _pipe_finish(pts, rate, start, L):
    dt = Fraction(1, 10)
    t, p = Fraction(start), Fraction(0)
    while p < L:
        t += dt
        p = min(p + rate * dt, _trench(t, pts))
    return t


def _c21():
    pts = [(0, 0), (6, 600), (16, 1200)]
    return _pipe_finish(pts, 150, 2, 1200)
q("C07-D-021", T, "Second stage limited by the first stage's progress; catch-up", "Medium",
  "Conceptual/application",
  r"A crew digs a $1200$ m trench: the first $600$ m at $100$ m per day and the remaining $600$ m, through harder soil, at $60$ m per day. A second crew lays pipe at $150$ m per day, but can lay pipe only in trench already dug; whenever it catches up with the diggers it continues at their pace. The pipe crew starts $2$ days after the diggers. How many days after the diggers start is the pipe laying completed?",
  "MCQ",
  r"The trench reaches $600$ m at day $6$. The pipe crew, starting at day $2$, has also laid $150 \times 4 = 600$ m by day $6$, so it catches up exactly then. After that the diggers move at only $60$ m per day and the pipe crew must follow at that pace, finishing with them. The remaining $600$ m of trench takes $10$ days, so the pipe is completed at day $16$.",
  "Ignoring the dependency, or assuming the digging rate never changes.",
  "C07D-dependent-stages", "Needs to see that the faster follower is capped by the slower leader.",
  correct=r"$16$", distractors=[
      (r"$10$", "Ignores the trench: $2 + \\frac{1200}{150}$."),
      (r"$24$", "Waits for the whole trench ($16$ days) and then lays all the pipe ($8$ days)."),
      (r"$12$", "Uses $100$ m per day for the whole trench, so both finish at day $12$.")],
  check=_c21, values=[16, 10, 24, 12], cognitive="Analysis")


def _c22():
    done, day, w = 0, 0, 1
    total = sum(2 ** k for k in range(10))
    while 2 * done < total:
        day += 1
        done += w
        w *= 2
    return day
q("C07-D-022", T, "Workforce doubles daily; when half the work is done", "Medium",
  "Conceptual/application",
  r"A volunteer drive starts with $1$ volunteer on day $1$, and the number of volunteers doubles every day ($2$ on day $2$, $4$ on day $3$, and so on). All volunteers work at the same rate, and the work is completed exactly at the end of day $10$. What is the smallest $n$ such that, at the end of day $n$, at least half of the work has been completed? Type $n$.",
  "TITA",
  r"Measure work in volunteer-days. By the end of day $n$ the work done is $1 + 2 + \dots + 2^{n-1} = 2^n - 1$, so the whole job is $2^{10} - 1 = 1023$ and half is $511.5$. At the end of day $9$ only $2^9 - 1 = 511$ is done, just short of half; day $10$ alone contributes $512$. So $n = 10$.",
  "Assuming that, because the workforce doubles, exactly half the work is done one day before the end.",
  "C07D-doubling-workforce", "Overturns the tempting one-day-before-the-end answer with an exact count.",
  tita_answer=10, check=_c22, tita_traps=[
      (9, "Assumes that, since the workforce doubles each day, the work done by the end of day $9$ is exactly half the total."),
      (5, "Takes half of the $10$ days.")],
  cognitive="Analysis")


def _c23():
    work = Fraction(38 * 8)
    per_day = 8 + 2 * Fraction(3, 4)
    return work / per_day
q("C07-D-023", T, "Longer working day with lower efficiency in the extra hours", "Medium",
  "Multi-step word problem",
  r"A team working $8$ hours a day would complete a job in $38$ days. Instead, the team works $10$ hours a day, but in the last $2$ hours of each day it works at only $75\%$ of its normal efficiency. In how many days does it complete the job? Type the number of days.",
  "TITA",
  r"The job is $38 \times 8 = 304$ normal hours. Each new day gives $8 + 2 \times 0.75 = 9.5$ normal hours, so it takes $\frac{304}{9.5} = 32$ days.",
  "Ignoring the reduced efficiency, or applying it to the whole day.",
  "C07D-overtime-efficiency", "Converting a mixed-efficiency day into equivalent normal hours.",
  tita_answer=32, check=_c23, tita_traps=[
      (31, "Ignores the lower efficiency: $\\frac{304}{10} = 30.4$, rounded up."),
      (41, "Applies $75\\%$ to all $10$ hours: $\\frac{304}{7.5} = 40.5$, rounded up.")],
  cognitive="Application")


def _c24():
    units, times = 5, (2, 3, 1)
    free = [0, 0, 0]
    for u in range(units):
        t = 0
        for s in range(3):
            start = max(t, free[s])
            t = start + times[s]
            free[s] = t
    return free[2]
q("C07-D-024", T, "Pipeline of three stages with one specialist per stage", "Medium",
  "Conceptual/application",
  r"A firm makes $5$ identical kiosks. Each kiosk is designed by Ananya ($2$ days), then built by Joseph ($3$ days), then tested by Meera ($1$ day), strictly in that order. Each of them handles only one kiosk at a time, and a kiosk can move to the next stage as soon as its current stage is finished. What is the least number of days in which all $5$ kiosks can be designed, built and tested?",
  "MCQ",
  r"Building is the slowest stage, so Joseph is the bottleneck. He can start the first kiosk only after day $2$ and then builds back to back: $5 \times 3 = 15$ days, finishing at day $17$ (Ananya always has the next design ready, since $2 < 3$). The last kiosk is then tested in $1$ day. Total $= 2 + 15 + 1 = 18$ days.",
  "Running the kiosks one after another, or forgetting the lead-in and the last test.",
  "C07D-pipeline-stages", "Identifying the bottleneck stage and adding the lead-in and tail.",
  correct=r"$18$", distractors=[
      (r"$30$", "Makes the kiosks one at a time: $5 \\times (2 + 3 + 1)$."),
      (r"$15$", "Counts only the bottleneck stage, $5 \\times 3$."),
      (r"$14$", "Treats design as the bottleneck: $5 \\times 2 + 3 + 1$.")],
  check=_c24, values=[18, 30, 15, 14], cognitive="Analysis")


def _c25():
    dur = {"P": 4, "Q": 3, "R": 5, "S": 2, "T": 6}
    pre = {"Q": ("P",), "S": ("Q", "R"), "T": ("P",)}
    import functools

    @functools.lru_cache(None)
    def fin(x):
        return dur[x] + max([fin(p) for p in pre.get(x, ())], default=0)
    return max(fin(x) for x in dur)
q("C07-D-025", T, "Project with precedence and unlimited crews; longest chain", "Medium",
  "Conceptual/application",
  r"A renovation has five tasks P, Q, R, S and T, taking $4$, $3$, $5$, $2$ and $6$ days respectively. Q and T can start only after P is finished; S can start only after both Q and R are finished; R has no prerequisite. Enough crews are available for any number of tasks to run at the same time, and each task takes its stated time. What is the least number of days needed to finish all five tasks?",
  "MCQ",
  r"The project time is the longest chain of dependent tasks. The chains are P, Q, S: $4 + 3 + 2 = 9$; R, S: $5 + 2 = 7$; P, T: $4 + 6 = 10$. Hence $10$ days.",
  "Adding all durations, or following only the chain that ends at S.",
  "C07D-precedence-scheduling", "Requires finding the critical chain among several.",
  correct=r"$10$", distractors=[
      (r"$20$", "Adds all five durations."),
      (r"$9$", "Follows only the chain P, Q, S and overlooks T."),
      (r"$13$", "Groups tasks in rounds and waits for each round to end: $\\max(4, 5) + \\max(3, 6) + 2$.")],
  check=_c25, values=[10, 20, 9, 13], cognitive="Analysis")


def _c26():
    x = symbols('x', positive=True)
    return solve(Eq(x + (30 - x) / Rational(3, 4), 34), x)[0]
q("C07-D-026", T, "Efficiency drop midway; find when it happened from the delay", "Medium",
  "Inverse/parameter",
  r"A contractor planned to finish a job in $30$ days. After some days of work at the planned rate, a machine broke down and the daily output fell by $25\%$ for the rest of the job. The job was finished $4$ days late. After how many days did the breakdown occur?",
  "MCQ",
  r"If the breakdown came after $x$ days, the remaining work equals $30 - x$ planned days and took $\frac{30 - x}{3/4} = \frac{4(30 - x)}{3}$ days. The delay is $\frac{30 - x}{3} = 4$, so $30 - x = 12$ and $x = 18$.",
  "Treating a $25\\%$ fall in output as a $25\\%$ rise in time.",
  "C07D-efficiency-change-midway", "Inverse use of a rate change with a known delay.",
  correct=r"$18$", distractors=[
      (r"$14$", "Takes the delay as $25\\%$ of the remaining planned time: $\\frac{30 - x}{4} = 4$."),
      (r"$12$", "Solves for the remaining planned days, $30 - x = 12$, and reports that."),
      (r"$26$", "Assumes the slower phase lasted only the $4$ extra days: $30 - 4$.")],
  check=_c26, values=[18, 14, 12, 26], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT -----

def _c27():
    def workers(day):
        return max(21 - (day - 1), 11)      # one leaves after each day until 11 remain
    for d in range(6, 200):
        work = sum(workers(k) for k in range(1, d + 1))
        if work == 21 * (d - 5):
            return d
q("C07-D-027", T, "Workers leave daily until a floor is reached; actual time from the delay", "Difficult",
  "Inverse/parameter",
  r"A team of $21$ identical workers starts a job. At the end of each day one worker leaves, so $20$ work on day $2$, $19$ on day $3$, and so on, until the team is down to $11$ workers; these $11$ then stay until the job is done. Because of the departures the job is finished exactly at the end of a day and $5$ days later than if all $21$ had worked throughout. How many days did the job actually take? Type the number of days.",
  "TITA",
  r"The team first has $11$ workers on day $11$. If the job ended by day $11$, the lost work $0 + 1 + \dots + (d - 1) = \frac{d(d-1)}{2}$ would equal the $5 \times 21 = 105$ worker-days of delay, giving $d = 15$, which is not $\le 11$; so the job runs past day $11$. Days $1$ to $11$ give $21 + 20 + \dots + 11 = 176$ worker-days, and each later day gives $11$. So $176 + 11(d - 11) = 21(d - 5)$, which gives $10d = 160$ and $d = 16$.",
  "Ignoring the floor on the team size and using the unlimited-departure formula.",
  "C07D-leaving-pattern", "Two regimes: the unlimited-departure model must be tested and rejected before a second equation gives the answer.",
  tita_answer=16, check=_c27, tita_traps=[
      (15, "Ignores that departures stop at $11$ workers: $\\frac{d(d-1)}{2} = 105$ gives $d = 15$."),
      (11, "Reports the time the full team would have taken, $16 - 5$.")],
  cognitive="Analysis", exams=HARD)


def _c28():
    best = None
    N = 60
    for i in range(N + 1):
        for j in range(N + 1):
            for k in range(N + 1):
                srt = 30 * i + 20 * j + 30 * k
                lod = 20 * (N - i) + 40 * (N - j) + 30 * (N - k)
                if srt == 0 or lod == 0:
                    continue
                t = max(Fraction(240 * N, srt), Fraction(240 * N, lod))
                if best is None or t < best:
                    best = t
    return best * 60
q("C07-D-028", T, "Three workers, two divisible tasks; minimise completion time", "Difficult",
  "Casework/optimisation",
  r"At a courier hub, $240$ parcels must be sorted and a separate, already sorted batch of $240$ parcels must be loaded; the two tasks are independent and can go on together. Per hour, Meena can sort $30$ or load $20$ parcels, Tarun can sort $20$ or load $40$, and Kavya can sort $30$ or load $30$. All three start together, and each may switch between the tasks at any moment. What is the least time, in minutes, in which both tasks can be finished? Type the number of minutes.",
  "TITA",
  r"Each person handles at most their better rate in parcels per hour: $30 + 40 + 30 = 100$ parcels per hour in all, and $480$ parcels must be handled, so at least $4.8$ hours are needed. This is achievable: Meena only sorts, Tarun only loads, and Kavya sorts for $3.2$ hours and loads for $1.6$ hours. Sorting: $30 \times 4.8 + 30 \times 3.2 = 240$; loading: $40 \times 4.8 + 30 \times 1.6 = 240$. The answer is $4.8 \times 60 = 288$ minutes.",
  "Making everyone sort first and then load, or fixing each person to a single task.",
  "C07D-split-divisible-tasks", "Needs comparative advantage plus an exact split for the flexible worker.",
  tita_answer=288, check=_c28, tita_traps=[
      (340, "All three sort together ($80$ per hour, $3$ hours), then all load together ($90$ per hour, $\\frac{8}{3}$ hours)."),
      (360, "Puts Kavya only on sorting: sorting ends at $4$ hours but loading by Tarun alone takes $6$ hours.")],
  cognitive="Analysis", exams=HARD)


def _c29():
    import math
    best = None
    for m in range(0, 11):
        for h in range(0, 11 - m):
            r = 7 * m + 4 * h
            if r == 0:
                continue
            d = math.ceil(Fraction(300, r))
            if d > 6:
                continue
            c = d * (1400 * m + 900 * h)
            best = c if best is None else min(best, c)
    return best
q("C07-D-029", T, "Fixed team of two worker types, whole days, deadline and head-count cap; least cost", "Difficult",
  "Casework/optimisation",
  r"A project needs $300$ units of work and must be finished within $6$ days. A mason does $7$ units a day and is paid Rs. $1{,}400$ a day; a helper does $4$ units a day and is paid Rs. $900$ a day. At most $10$ people can work on the site. The same team works every day until the project is done, and every member is paid for each day on which any work is done. What is the least possible total wage bill?",
  "MCQ",
  r"A mason costs Rs. $200$ per unit and a helper Rs. $225$, so the bill is at least $300 \times 200 =$ Rs. $60{,}000$, but whole people and whole paid days matter. A $6$-day team needs at least $50$ units a day; the cheapest team giving at least $50$ units a day is $6$ masons and $2$ helpers ($50$ units), costing $6 \times 10{,}200 =$ Rs. $61{,}200$. A $5$-day team needs $60$ units a day: the cheapest team giving at least $60$ units a day is $8$ masons and $1$ helper, at Rs. $12{,}100$ a day, so $5 \times 12{,}100 =$ Rs. $60{,}500$. A $4$-day team needs $75$ units a day, which $10$ people cannot reach. The least bill is Rs. $60{,}500$.",
  "Using the per-unit cost without whole people and whole days, or insisting on using all $6$ days.",
  "C07D-integer-mix-min-cost", "Casework over the number of days, each with a whole-number team and the head-count cap.",
  correct=r"Rs. $60{,}500$", distractors=[
      (r"Rs. $60{,}000$", "Uses the per-unit cost of a mason for all $300$ units, ignoring whole people and paid days."),
      (r"Rs. $61{,}200$", "Assumes the cheapest plan uses all $6$ days: $6$ masons and $2$ helpers."),
      (r"Rs. $67{,}200$", "Uses only masons (cheaper per unit), the fewest that meet the deadline: $8$ masons for $6$ days.")],
  check=_c29, values=[60500, 60000, 61200, 67200], cognitive="Analysis", exams=HARD)


def _c30():
    pts = [(0, 0), (6, 300), (11, 1000)]
    best = None
    for i in range(0, 23):
        f = _pipe_finish(pts, 100, Fraction(i, 2), 1000)
        best = f if best is None else min(best, f)
    return best
q("C07-D-030", T, "Follower stage capped by a leader whose speed changes; earliest finish", "Difficult",
  "Conceptual/application",
  r"A crew digs a $1000$ m trench: the first $300$ m, through rock, at $50$ m per day, and the remaining $700$ m at $140$ m per day. A pipe crew lays pipe at $100$ m per day, but only in trench already dug; whenever it catches up with the diggers it continues at their pace. The pipe crew may start whenever it likes. What is the earliest day, counted from the start of digging, by which all the pipe can be laid?",
  "MCQ",
  r"The trench reaches $300$ m only at day $6$, so however early the pipe crew starts, it has laid at most $300$ m by day $6$. After that the diggers move at $140$ m per day, faster than the pipe crew, so the pipe crew is never held up again and needs $\frac{700}{100} = 7$ more days. The earliest finish is $6 + 7 = 13$ days, achieved by any start on or before day $3$.",
  "Assuming the pipe can finish with the diggers, or ignoring the slow rock section.",
  "C07D-dependent-stages", "Must see that the early slow section caps progress while the later fast section does not.",
  correct=r"$13$", distractors=[
      (r"$11$", "Assumes the pipe crew can finish together with the diggers."),
      (r"$10$", "Ignores the trench and uses $\\frac{1000}{100}$."),
      (r"$21$", "Waits for the whole trench ($11$ days) before laying all the pipe ($10$ days).")],
  check=_c30, values=[13, 11, 10, 21], cognitive="Analysis", exams=HARD)


def _c31():
    import math
    best = None
    for n in range(1, 121):
        d = math.ceil(Fraction(120, n))
        c = d * (500 * n + 3600) + 1500 * n
        best = c if best is None else min(best, c)
    return best
q("C07-D-031", T, "Choosing team size against hiring fee, daily wage and overhead with whole days", "Difficult",
  "Casework/optimisation",
  r"A job needs $120$ worker-days of work. A contractor hires some identical workers at the start and keeps all of them until the job is done. Each worker costs a one-time hiring fee of Rs. $1{,}500$ plus Rs. $500$ for every day worked, and the site costs Rs. $3{,}600$ in overheads for every day. Work is counted in whole days: wages and overheads are charged for every day on which any work is done. What is the least possible total cost of the job?",
  "MCQ",
  r"For $d$ whole days the smallest team is $n = \lceil 120/d \rceil$, and the cost is $d(500n + 3600) + 1500n$. Checking: $d = 5$, $n = 24$: Rs. $1{,}14{,}000$; $d = 6$, $n = 20$: Rs. $1{,}11{,}600$; $d = 7$, $n = 18$: Rs. $1{,}15{,}200$; $d = 8$, $n = 15$: $8 \times 11{,}100 + 22{,}500 =$ Rs. $1{,}11{,}300$; $d = 9$, $n = 14$: Rs. $1{,}16{,}400$; $d = 10$, $n = 12$: Rs. $1{,}14{,}000$. Other values of $d$ cost more (for example $d = 4$ gives Rs. $1{,}19{,}400$ and $d = 11$ gives Rs. $1{,}16{,}600$), so the least is Rs. $1{,}11{,}300$.",
  "Optimising as if days could be fractional and then paying for whole days.",
  "C07D-cost-time-tradeoff", "Trade-off between fee and overhead with a whole-day ceiling; needs case checking.",
  correct=r"Rs. $1{,}11{,}300$", distractors=[
      (r"Rs. $1{,}22{,}300$", "Minimises $60{,}000 + \\frac{432{,}000}{n} + 1{,}500n$ as if days were fractional, takes $n = 17$, then pays $8$ whole days."),
      (r"Rs. $1{,}16{,}800$", "Rounds the fractional optimum $n \\approx 16.97$ down to $16$ and pays $8$ whole days."),
      (r"Rs. $88{,}800$", "Finds the best plan ($15$ workers, $8$ days) but leaves out the hiring fees.")],
  check=_c31, values=[111300, 122300, 116800, 88800], cognitive="Analysis", exams=HARD)


def _c32():
    jobs = {"P": (3, 6), "Q": (5, 2), "R": (1, 2), "S": (6, 6)}
    best = None
    for order in itertools.permutations(jobs):
        c = p = 0
        for j in order:
            c += jobs[j][0]
            p = max(p, c) + jobs[j][1]
        best = p if best is None else min(best, p)
    return best
q("C07-D-032", T, "Two-stage workshop; order the jobs to finish earliest", "Difficult",
  "Casework/optimisation",
  r"A workshop has four orders P, Q, R and S. Each order is first cut by Harpreet and then polished by Fatima; each of them handles one order at a time, and an order can be polished only after its cutting is complete. Cutting times are P $3$, Q $5$, R $1$, S $6$ hours; polishing times are P $6$, Q $2$, R $2$, S $6$ hours. Both follow the same order sequence, which can be chosen freely. What is the least time in which all four orders can be finished?",
  "MCQ",
  r"Put short cutting jobs early (so Fatima starts soon) and short polishing jobs late (so the tail is short): R first, Q last, giving R, P, S, Q. Cutting ends at $1, 4, 10, 15$. Polishing: R $1$ to $3$, P $4$ to $10$, S $10$ to $16$, Q $16$ to $18$. So $18$ hours. No order gives $17$: polishing totals $16$ hours and cannot start before hour $1$, so $17$ would need Fatima busy without a break from hour $1$. That forces R (the only $1$-hour cut) first, polished from $1$ to $3$, but the next order's cutting cannot end before hour $1 + 3 = 4$, so Fatima must wait. Hence $18$ hours is the least.",
  "Processing in the given order, or taking a lower bound as attainable.",
  "C07D-pipeline-stages", "Choosing the job order (Johnson-type reasoning) and verifying no better order exists.",
  correct=r"$18$ hours", distractors=[
      (r"$17$ hours", "Takes the lower bound, total polishing $16$ plus the shortest cutting time $1$, as attainable."),
      (r"$21$ hours", "Processes the orders in the sequence P, Q, R, S."),
      (r"$31$ hours", "Lets each order be cut and polished before the next is started.")],
  check=_c32, values=[18, 17, 21, 31], cognitive="Analysis", exams=HARD)


def _c33():
    import functools
    dur = {"P": 4, "Q": 3, "R": 1, "S": 4, "T": 3, "U": 2}
    pre = {"Q": ("P",), "R": ("P",), "S": ("R",), "T": ("R",), "U": ("Q",)}
    names = list(dur)

    @functools.lru_cache(None)
    def f(done, running):
        if len(done) == len(names):
            return 0
        runset = {t for t, _ in running}
        avail = [t for t in names if t not in done and t not in runset and all(p in done for p in pre.get(t, ()))]
        free = 2 - len(running)
        best = 10 ** 9
        for k in range(0, min(free, len(avail)) + 1):
            for start in itertools.combinations(avail, k):
                run = list(running) + [(t, dur[t]) for t in start]
                if not run:
                    continue
                step = min(r for _, r in run)
                nd, nr = set(done), []
                for t, r in run:
                    if r == step:
                        nd.add(t)
                    else:
                        nr.append((t, r - step))
                best = min(best, step + f(frozenset(nd), tuple(sorted(nr))))
        return best
    return f(frozenset(), ())
q("C07-D-033", T, "Precedence-constrained tasks with only two crews", "Difficult",
  "Casework/optimisation",
  r"A shop fit-out has six tasks P, Q, R, S, T and U, taking $4$, $3$, $1$, $4$, $3$ and $2$ days respectively. Q and R need P to be finished; S and T need R to be finished; U needs Q to be finished. Only two crews are available. Each task is done entirely by one crew, a crew does one task at a time, and a task once started continues until it is finished. What is the least number of days in which all six tasks can be completed? Type the number of days.",
  "TITA",
  r"Nothing else can start until P is done, so for the first $4$ days one crew is idle. The remaining tasks total $3 + 1 + 4 + 3 + 2 = 13$ crew-days, and each task is done wholly by one crew, so the two crews' loads after day $4$ are whole numbers adding to $13$, and one crew has at least $7$ days of work after day $4$: at least $11$ days in all. A schedule achieving $11$: crew one does R (days $4$ to $5$), S ($5$ to $9$), U ($9$ to $11$); crew two does Q ($4$ to $7$), T ($7$ to $10$). U can start at $9$ since Q ended at $7$. The answer is $11$.",
  "Using the longest chain as if crews were unlimited.",
  "C07D-precedence-scheduling", "Combines a precedence bottleneck with a crew-capacity bound and needs an explicit schedule.",
  tita_answer=11, check=_c33, tita_traps=[
      (9, "Takes the longest chain, P, R, S or P, Q, U, as if crews were unlimited."),
      (17, "Adds all durations, as if only one crew worked.")],
  cognitive="Analysis", exams=HARD)


def _c34():
    x = symbols('x', positive=True)
    D = 16
    x0 = solve(Eq(D * x + D * (D - 1) / 2, Rational(5, 2) * D * x), x)[0]
    W = D * x0 + D * (D - 1) // 2
    done, day = 0, 0
    while done < W:
        done += x0 + 2 * day
        day += 1
    return D - day
q("C07-D-034", T, "Comparing two joining patterns after inferring the starting workforce", "Difficult",
  "Multi-step word problem",
  r"A contractor starts a job with a certain number of workers on day $1$ and adds one more worker of the same efficiency at the start of every later day; the job is completed exactly at the end of day $16$. With the day-$1$ workforce kept unchanged throughout, the job would have taken $2.5$ times as many days. Had he started with the same day-$1$ workforce but added $2$ workers at the start of every later day, the job would have been completed on day $n$. By how many days is $n$ earlier than $16$?",
  "MCQ",
  r"With $x$ workers on day $1$, the work is $16x + (0 + 1 + \dots + 15) = 16x + 120$, and also $40x$, so $x = 5$ and the job is $200$ worker-days. Adding $2$ a day, after $n$ days the work is $5n + n(n-1) = n^2 + 4n$. $12^2 + 48 = 192 < 200$ and $13^2 + 52 = 221 \ge 200$, so the job ends on day $13$, which is $3$ days earlier.",
  "Rounding the root of the quadratic down, or comparing with the wrong plan.",
  "C07D-joining-pattern", "Two stages: infer the workforce from a comparison, then solve a second pattern with a part-day.",
  correct=r"$3$", distractors=[
      (r"$4$", "Solves $n^2 + 4n = 200$, gets $n \\approx 12.3$ and rounds down to $12$."),
      (r"$8$", "Assumes doubling the daily addition halves the time: $16 - 8$."),
      (r"$27$", "Compares day $13$ with the constant-workforce plan of $40$ days.")],
  check=_c34, values=[3, 4, 8, 27], cognitive="Analysis", exams=HARD)


def _c35():
    import math
    best = None
    for n in range(1, 12):
        out = n * (12 - n)
        d = math.ceil(Fraction(180, out))
        if d > 6:
            continue
        c = n * d
        best = c if best is None else min(best, c)
    return best
q("C07-D-035", T, "Crowding lowers each worker's output; fewest paid worker-days under a deadline", "Difficult",
  "Casework/optimisation",
  r"In a narrow tunnel, crowding slows everyone: when $n$ workers work together, each of them does $12 - n$ units a day (for $1 \le n \le 11$). A job of $180$ units must be finished within $6$ days by a team whose size stays the same every day, and each worker is paid for every day on which any work is done. What is the least possible number of paid worker-days?",
  "MCQ",
  r"A team of $n$ does $n(12 - n)$ units a day: $27$ for $n = 3$, $32$ for $n = 4$, $35$ for $n = 5$, $36$ for $n = 6$, then falling. $n = 3$ needs $7$ days, too slow. $n = 4$ needs $\lceil 180/32 \rceil = 6$ days, $24$ worker-days. $n = 5$ needs $6$ days ($30$), $n = 6$ needs $5$ days ($30$), and larger teams are worse. The least is $24$ worker-days.",
  "Choosing the team with the highest daily output, or not paying for a part-day.",
  "C07D-crowding-output", "Non-monotonic team output combined with a deadline and whole paid days.",
  correct=r"$24$", distractors=[
      (r"$30$", "Picks the team with the highest daily output, $6$ workers for $5$ days."),
      (r"$21$", "Uses $3$ workers for $7$ days, overlooking the $6$-day limit."),
      (r"$20$", "Uses $4$ workers but pays only $5$ days, rounding $5.625$ down.")],
  check=_c35, values=[24, 30, 21, 20], cognitive="Analysis", exams=HARD)
