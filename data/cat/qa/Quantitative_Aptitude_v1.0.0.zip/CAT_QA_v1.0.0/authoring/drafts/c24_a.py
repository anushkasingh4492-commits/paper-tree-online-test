import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Digit problems"
HARD = ("CAT", "XAT")


def _ds(n):
    return sum(int(ch) for ch in str(n))


def _rev(n):
    # number formed by reversing the digits; trailing zeros become leading zeros (50 -> 5)
    return int(str(n)[::-1])


def _num(p):
    return int("".join(str(d) for d in p))


def _forms(digits, k=3):
    # k-digit numbers from the given digits, no repetition, no leading zero
    return [_num(p) for p in itertools.permutations(digits, k) if p[0] != 0]


# ---------------------------------------------------------------- EASY

def _c1():
    s = [n for n in range(10, 100) if n == 4 * _ds(n) and n + 27 == _rev(n)]
    assert len(s) == 1
    return s[0]
q("C24-A-001", T, "Two-digit number equal to a multiple of its digit sum, with a reversal condition", "Easy",
  "Multi-step word problem",
  r"A two-digit number is $4$ times the sum of its digits. When $27$ is added to the number, the result is the number formed by reversing its digits. What is the number?",
  "MCQ",
  r"Let the number be $10a + b$. From $10a + b = 4(a + b)$ we get $6a = 3b$, so $b = 2a$. Adding $27$ reverses the digits, so $(10b + a) - (10a + b) = 9(b - a) = 27$, giving $b - a = 3$. With $b = 2a$ this gives $a = 3$, $b = 6$, so the number is $36$. Check: $36 = 4 \times 9$ and $36 + 27 = 63$.",
  "Reporting the reversed number, or using only the first condition.",
  "C24A-two-digit-reversal-equations", "Two linear conditions on the digits; the trap is reporting the reversed number.",
  correct=r"$36$",
  distractors=[(r"$63$", "Solves correctly but reports the number formed after reversal, $63$."),
               (r"$12$", "Uses only $b = 2a$ from the first condition and takes the smallest such number, $12$, never checking the reversal."),
               (r"$48$", "Uses only $b = 2a$ and picks $48$ (also $4$ times its digit sum), ignoring the reversal condition; $48 + 27 = 75 \\ne 84$.")],
  check=_c1, values=[36, 63, 12, 48], cognitive="Application")


def _c2():
    s = [n for n in range(10, 100) if (n // 10) * (n % 10) == 24 and n - _rev(n) == 18]
    assert len(s) == 1
    return s[0]
q("C24-A-002", T, "Digit product and the decrease on reversing digits", "Easy",
  "Multi-step word problem",
  r"The product of the digits of a two-digit number is $24$. When its digits are reversed, the new number is $18$ less than the original number. What is the original number?",
  "MCQ",
  r"Write the number as $10a + b$. Reversing lowers it by $9(a - b) = 18$, so $a - b = 2$. With $ab = 24$, the digits are $6$ and $4$ (since $6 - 4 = 2$ and $6 \times 4 = 24$), with the larger digit in the tens place. The number is $64$, and indeed $64 - 46 = 18$.",
  "Placing the larger digit in the units place, or choosing a digit pair with product $24$ without testing the reversal.",
  "C24A-two-digit-reversal-equations", "One product condition and one reversal condition; the direction of change decides digit order.",
  correct=r"$64$",
  distractors=[(r"$46$", "Finds digits $6$ and $4$ but puts the smaller digit first; reversing $46$ increases it by $18$."),
               (r"$83$", "Takes the digit pair $8$ and $3$ (product $24$) without using the reversal; $83 - 38 = 45$, not $18$."),
               (r"$38$", "Takes the smallest two-digit number with digit product $24$ without using the reversal condition.")],
  check=_c2, values=[64, 46, 83, 38], cognitive="Application")


def _c3():
    return sum(1 for n in range(10, 100) if n + _rev(n) == 154)
q("C24-A-003", T, "Counting two-digit numbers whose sum with the reversal is fixed", "Easy",
  "Casework/optimisation",
  r"A two-digit number is added to the number formed by reversing its digits, and the sum is $154$. How many two-digit numbers have this property?",
  "TITA",
  r"If the number is $10a + b$, then $(10a + b) + (10b + a) = 11(a + b) = 154$, so $a + b = 14$. With digits at most $9$, the pairs $(a, b)$ are $(5, 9), (6, 8), (7, 7), (8, 6), (9, 5)$, giving $59, 68, 77, 86, 95$. That is $5$ numbers.",
  "Counting unordered digit pairs, or dropping the number with equal digits.",
  "C24A-number-plus-reverse", "One identity, $N + \\text{rev} = 11(a+b)$, then a short listing.",
  tita_answer=5, check=_c3,
  tita_traps=[(4, "Leaves out $77$, thinking the reversed number must be different."),
              (3, "Counts unordered digit pairs $\\{5,9\\}, \\{6,8\\}, \\{7,7\\}$ instead of numbers.")],
  cognitive="Application")


def _c4():
    return sum(1 for n in range(10, 100) if _rev(n) - n == 18)
q("C24-A-004", T, "Counting two-digit numbers that increase by a fixed amount on reversal", "Easy",
  "Casework/optimisation",
  r"How many two-digit numbers increase by exactly $18$ when their digits are reversed?",
  "TITA",
  r"For $10a + b$, reversing gives $10b + a$, an increase of $9(b - a)$. So $b - a = 2$, with $a \ge 1$ (tens digit of a two-digit number) and $b \le 9$. Hence $a = 1, 2, \dots, 7$, giving $13, 24, 35, 46, 57, 68, 79$: $7$ numbers.",
  "Allowing the tens digit to be $0$.",
  "C24A-number-minus-reverse", "Single identity $9(b - a)$ and a range check on the digits.",
  tita_answer=7, check=_c4,
  tita_traps=[(8, "Includes $a = 0$, treating $02$ as a two-digit number."),
              (2, "Reports the digit difference $b - a$ instead of the count.")],
  cognitive="Application")


def _c5():
    return sum(1 for n in range(10, 100) if n - _ds(n) == 63)
q("C24-A-005", T, "Number minus its digit sum depends only on the tens digit", "Easy",
  "Conceptual/application",
  r"Priya picks a two-digit number and subtracts the sum of its digits from it. The result is $63$. How many different two-digit numbers could Priya have picked?",
  "TITA",
  r"For $10a + b$, the number minus its digit sum is $10a + b - (a + b) = 9a$. So $9a = 63$ gives $a = 7$, and the units digit $b$ can be anything from $0$ to $9$. All of $70, 71, \dots, 79$ work: $10$ numbers.",
  "Assuming a unique answer, or forgetting the units digit $0$.",
  "C24A-number-minus-digit-sum", "One observation: the units digit cancels.",
  tita_answer=10, check=_c5,
  tita_traps=[(1, "Assumes the number is unique and stops after finding one value such as $70$."),
              (9, "Leaves out $70$ by allowing units digits only from $1$ to $9$.")],
  cognitive="Understanding")


def _c6():
    ratios = {Fraction(_rev(n), _ds(n)) for n in range(10, 100) if n == 7 * _ds(n)}
    assert len(ratios) == 1
    return ratios.pop()
q("C24-A-006", T, "Reversed number as a multiple of the digit sum", "Easy",
  "Conceptual/application",
  r"A two-digit number is $7$ times the sum of its digits. The number formed by reversing its digits is how many times the sum of its digits?",
  "MCQ",
  r"For any two-digit number, the number plus its reversal is $11(a + b)$, that is $11$ times the digit sum. If the number is $7$ times the digit sum, the reversal is $11 - 7 = 4$ times the digit sum. For instance $42 = 7 \times 6$ and $24 = 4 \times 6$.",
  "Assuming reversal keeps the same multiple, or taking the number plus its reversal as $10$ times the digit sum.",
  "C24A-multiple-of-digit-sum", "One identity applied in a single step; the trap is keeping the multiple $7$.",
  correct=r"$4$",
  distractors=[(r"$7$", "Assumes the reversed number keeps the same multiple of the digit sum."),
               (r"$11$", "Reports the multiple for the sum of the number and its reversal."),
               (r"$3$", "Writes the number plus its reversal as $10(a + b)$, that is $10$ times the digit sum, giving $10 - 7 = 3$.")],
  check=_c6, values=[4, 7, 11, 3], cognitive="Understanding")


def _c7():
    return sum(1 for n in range(100, 1000) if len(set(str(n))) == 3 and n % 2 == 1)
q("C24-A-007", T, "Odd three-digit numbers with all digits different", "Easy",
  "Single-step computation",
  r"The lockers in a gym are numbered from $100$ to $999$. A locker is called clean if the three digits of its number are all different and the number is odd. How many clean lockers are there?",
  "MCQ",
  r"Fill the restricted places first. The units digit must be odd: $5$ ways. The hundreds digit cannot be $0$ or the units digit: $8$ ways. The tens digit can be any of the $8$ digits not yet used (now including $0$): $8$ ways. Total $5 \times 8 \times 8 = 320$.",
  "Filling the hundreds place before the units place, or halving the count of numbers with distinct digits.",
  "C24A-repeated-and-distinct-digits", "Multiplication principle where the order of filling places matters.",
  correct=r"$320$",
  distractors=[(r"$324$", "Takes half of the $9 \\times 9 \\times 8 = 648$ numbers with distinct digits, assuming exactly half of them are odd."),
               (r"$360$", "Allows $0$ in the hundreds place: after the units digit, $9$ digits remain for the hundreds place and $8$ for the tens, $5 \\times 9 \\times 8$."),
               (r"$405$", "Fills the hundreds and tens places first ($9 \\times 9$) and then still gives the units digit all $5$ odd choices: $9 \\times 9 \\times 5$.")],
  check=_c7, values=[320, 324, 360, 405], cognitive="Application")


def _c8():
    return sum(1 for n in _forms([0, 1, 2, 5, 7, 9]) if n % 25 == 0)
q("C24-A-008", T, "Forming three-digit multiples of 25 from given digits", "Easy",
  "Casework/optimisation",
  r"Using the digits $0, 1, 2, 5, 7, 9$, with no digit used more than once in a number, how many three-digit numbers divisible by $25$ can be formed?",
  "MCQ",
  r"A number is divisible by $25$ when its last two digits are $00$, $25$, $50$ or $75$. Ending $00$ repeats a digit, so the endings are $25$, $50$ and $75$. Ending $50$: the hundreds digit is any of $1, 2, 7, 9$, giving $4$. Ending $25$: the hundreds digit is from $1, 7, 9$ (not $0$), giving $3$. Ending $75$: from $1, 2, 9$, giving $3$. Total $4 + 3 + 3 = 10$.",
  "Allowing $0$ in the hundreds place, or treating divisibility by $25$ like divisibility by $5$.",
  "C24A-form-numbers-last-digits", "List the possible two-digit endings, then one leading-zero check per ending.",
  correct=r"$10$",
  distractors=[(r"$12$", "Gives every ending $4$ choices for the hundreds digit, allowing $0$ in front of $25$ and $75$."),
               (r"$6$", "Uses only the endings $25$ and $75$, missing $50$."),
               (r"$36$", "Tests only for a units digit of $0$ or $5$, that is divisibility by $5$: $20 + 16$.")],
  check=_c8, values=[10, 12, 6, 36], cognitive="Application")


def _c9():
    return sum(_num(p) for p in itertools.permutations([2, 4, 7]))
q("C24-A-009", T, "Sum of all numbers formed by permuting three given digits", "Easy",
  "Conceptual/application",
  r"What is the sum of all the three-digit numbers that can be formed using the digits $2$, $4$ and $7$, each exactly once?",
  "MCQ",
  r"There are $3! = 6$ numbers, and each digit appears in each place exactly $2$ times. So each place contributes $2 \times (2 + 4 + 7) = 26$ units of that place value, and the sum is $26 \times 111 = 2886$.",
  "Using the wrong number of appearances of each digit in a place.",
  "C24A-sum-of-formed-numbers", "One symmetry idea: each digit appears equally often in each place.",
  correct=r"$2886$",
  distractors=[(r"$1443$", "Lets each digit appear only once in each place: $13 \\times 111$."),
               (r"$8658$", "Lets each digit appear $3! = 6$ times in each place: $6 \\times 13 \\times 111$."),
               (r"$4329$", "Lets each digit appear $3$ times in each place (the number of digits): $3 \\times 13 \\times 111$.")],
  check=_c9, values=[2886, 1443, 8658, 4329], cognitive="Application")


def _c10():
    return sum(len(str(n)) for n in range(1, 251))
q("C24-A-010", T, "Total digits used to number pages 1 to 250", "Easy",
  "Multi-step word problem",
  r"The pages of a booklet are numbered consecutively from $1$ to $250$. How many digits in total are printed to number all the pages?",
  "TITA",
  r"Pages $1$ to $9$ use $9$ digits; pages $10$ to $99$ are $90$ pages using $180$ digits; pages $100$ to $250$ are $151$ pages using $453$ digits. Total $9 + 180 + 453 = 642$.",
  "Off-by-one in counting pages $100$ to $250$, or treating every page as three digits.",
  "C24A-digits-used-in-numbering", "Three blocks by number of digits, with one inclusive count.",
  tita_answer=642, check=_c10,
  tita_traps=[(639, "Counts pages $100$ to $250$ as $150$ pages instead of $151$."),
              (750, "Treats every page number as having three digits: $250 \\times 3$.")],
  cognitive="Application")


def _c11():
    s = [n for n in range(10, 100) if (10 * n + 7) - (700 + n) == 81]
    assert len(s) == 1
    return s[0]
q("C24-A-011", T, "Writing a digit to the left and to the right of a two-digit number", "Easy",
  "Inverse/parameter",
  r"Meera has a two-digit number. Writing the digit $7$ to its right gives a three-digit number $X$; writing the digit $7$ to its left gives a three-digit number $Y$. If $X$ exceeds $Y$ by $81$, what is Meera's number?",
  "MCQ",
  r"Let the number be $n$. Then $X = 10n + 7$ and $Y = 700 + n$, so $X - Y = 9n - 693 = 81$, giving $9n = 774$ and $n = 86$. Check: $867 - 786 = 81$.",
  "Mis-valuing the appended digit or subtracting in the wrong order.",
  "C24A-placing-or-moving-a-digit", "One linear equation once the place values are written correctly.",
  correct=r"$86$",
  distractors=[(r"$68$", "Sets up $Y - X = 81$, giving $693 - 9n = 81$ and $n = 68$."),
               (r"$16$", "Values the $7$ written on the left as $70$: $(10n + 7) - (70 + n) = 81$ gives $n = 16$."),
               (r"$79$", "Values the $7$ written on the right as $70$: $(10n + 70) - (700 + n) = 81$ gives $n = 79$.")],
  check=_c11, values=[86, 68, 16, 79], cognitive="Application")


def _c12():
    return sum(1 for n in range(100, 1000) if str(n) == str(n)[::-1] and n % 5 == 0)
q("C24-A-012", T, "Three-digit palindromes divisible by 5", "Easy",
  "Conceptual/application",
  r"A three-digit palindrome is a three-digit number that reads the same from left to right and from right to left, such as $474$. How many three-digit palindromes are divisible by $5$?",
  "MCQ",
  r"A palindrome $aba$ has units digit equal to its hundreds digit $a$. Divisibility by $5$ needs the units digit to be $0$ or $5$, but $a \ne 0$, so $a = 5$. The middle digit $b$ is free ($10$ choices): $505, 515, \dots, 595$, which is $10$ numbers.",
  "Forgetting that the units digit is tied to the non-zero hundreds digit.",
  "C24A-palindromes-divisibility", "One structural observation about palindromes.",
  correct=r"$10$",
  distractors=[(r"$20$", "Allows the units digit $0$ as well, forgetting it forces the hundreds digit to be $0$."),
               (r"$9$", "Lets the middle digit run only from $1$ to $9$."),
               (r"$18$", "Assumes one-fifth of the $90$ three-digit palindromes are divisible by $5$.")],
  check=_c12, values=[10, 20, 9, 18], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM

def _c13():
    s = [(k, _rev(k)) for k in range(10, 100) if k % 10 != 0 and _rev(k) + 2 == 2 * (k + 2)]
    assert len(s) == 1
    return s[0][1]
q("C24-A-013", T, "Ages with reversed digits and a future ratio", "Medium",
  "Multi-step word problem",
  r"Kabir's present age and his father's present age, in whole years, are both two-digit numbers, and the father's age is obtained by reversing the digits of Kabir's age. In $2$ years, the father will be exactly twice as old as Kabir. What is the father's present age, in years?",
  "TITA",
  r"Let Kabir be $10x + y$ years old, so the father is $10y + x$. Then $10y + x + 2 = 2(10x + y + 2)$, which simplifies to $8y = 19x + 2$. Trying digits, $x = 2$ gives $8y = 40$, $y = 5$ (no other digit $x$ makes $19x + 2$ a multiple of $8$ with $y \le 9$). So Kabir is $25$ and the father is $52$; in $2$ years they are $27$ and $54$.",
  "Reporting Kabir's age or the father's future age.",
  "C24A-two-digit-reversal-equations", "Needs a Diophantine step in the digits after setting up the age equation.",
  tita_answer=52, check=_c13,
  tita_traps=[(25, "Reports Kabir's present age."),
              (54, "Reports the father's age after $2$ years.")],
  cognitive="Application")


def _c14():
    return sum(1 for n in range(10, 100)
               if n - _rev(n) > 0 and int(math.isqrt(n - _rev(n))) ** 2 == n - _rev(n))
q("C24-A-014", T, "Two-digit numbers whose excess over the reversal is a perfect square", "Medium",
  "Casework/optimisation",
  r"For a two-digit number, subtract from it the number formed by reversing its digits (for a number ending in $0$, such as $50$, the reversed number is $05 = 5$). For how many two-digit numbers is the result a positive perfect square?",
  "MCQ",
  r"For $10a + b$ the difference is $9(a - b)$, and since $9$ is a square, $9(a - b)$ is a positive perfect square exactly when $a - b$ is $1$, $4$ or $9$. $a - b = 1$: $10, 21, \dots, 98$ ($9$ numbers); $a - b = 4$: $40, 51, \dots, 95$ ($6$ numbers); $a - b = 9$: only $90$. Total $9 + 6 + 1 = 16$.",
  "Missing a case for $a - b$, or including a zero difference.",
  "C24A-number-minus-reverse", "Reduce to $a - b$ being a square, then three cases with range checks.",
  correct=r"$16$",
  distractors=[(r"$25$", "Also counts the $9$ numbers with equal digits, treating a difference of $0$ as a positive square."),
               (r"$7$", "Misses $a - b = 1$, overlooking that $1$ is a perfect square: $6 + 1$."),
               (r"$15$", "Misses $a - b = 9$, that is the number $90$: $9 + 6$.")],
  check=_c14, values=[16, 25, 7, 15], cognitive="Analysis")


def _c15():
    return sum(1 for n in range(100, 1000) if n % 10 != 0 and n - _rev(n) == 297)
q("C24-A-015", T, "Counting three-digit numbers exceeding their reversal by a fixed amount", "Medium",
  "Casework/optimisation",
  r"How many three-digit numbers with a non-zero units digit exceed the number formed by reversing their digits by exactly $297$?",
  "MCQ",
  r"For $100a + 10b + c$, the number minus its reversal is $99(a - c)$, so $a - c = 3$. With $c \ge 1$, $c$ runs from $1$ to $6$ and $a = c + 3$ from $4$ to $9$: $6$ choices. The middle digit does not affect the difference, so it has $10$ choices. Total $6 \times 10 = 60$.",
  "Ignoring the free middle digit, or the non-zero units condition.",
  "C24A-number-minus-reverse", "Identity $99(a-c)$ plus noticing the middle digit is free.",
  correct=r"$60$",
  distractors=[(r"$70$", "Allows units digit $0$, so $c$ runs from $0$ to $6$: $7 \\times 10$."),
               (r"$6$", "Counts only the pairs $(a, c)$, forgetting the middle digit is free."),
               (r"$48$", "Insists that all three digits be different, giving $6 \\times 8$.")],
  check=_c15, values=[60, 70, 6, 48], cognitive="Application")


def _c16():
    s = [n for n in range(100, 1000)
         if (n // 10) % 10 == n // 100 + n % 10 and _ds(n) == 16 and n - _rev(n) == 594]
    assert len(s) == 1
    return s[0]
q("C24-A-016", T, "Three-digit number from digit-sum, middle-digit and reversal conditions", "Medium",
  "Multi-step word problem",
  r"In a three-digit number, the tens digit equals the sum of the other two digits, and the sum of all three digits is $16$. When the digits are reversed, the number decreases by $594$. What is the number?",
  "MCQ",
  r"Let the digits be $a, b, c$. Since $b = a + c$ and $a + b + c = 16$, we get $2b = 16$, so $b = 8$ and $a + c = 8$. Reversing decreases the number by $99(a - c) = 594$, so $a - c = 6$. Hence $a = 7$, $c = 1$ and the number is $781$. Check: $781 - 187 = 594$.",
  "Placing the digits in the wrong order, or not using the reversal condition.",
  "C24A-three-digit-reversal", "Three conditions combined; needs the $99(a - c)$ identity.",
  correct=r"$781$",
  distractors=[(r"$187$", "Solves $|a - c| = 6$ but puts the smaller digit first; reversing $187$ increases it by $594$."),
               (r"$682$", "Satisfies the two digit-sum conditions with $a = 6$, $c = 2$ but skips the reversal condition; $682 - 286 = 396$."),
               (r"$862$", "Uses the digit-sum and reversal conditions but ignores the tens-digit condition; $862 - 268 = 594$ and the digits add to $16$, but the tens digit is not $8 + 2$.")],
  check=_c16, values=[781, 187, 682, 862], cognitive="Application")


def _c17():
    return sum(1 for n in range(100, 1000) if n % 10 != 0 and n + _rev(n) == 1131)
q("C24-A-017", T, "Three-digit numbers whose sum with the reversal is fixed", "Medium",
  "Casework/optimisation",
  r"A three-digit number whose units digit is not zero is added to the number formed by reversing its digits, and the sum is $1131$. How many such three-digit numbers are there?",
  "TITA",
  r"For digits $a, b, c$ the sum is $101(a + c) + 20b = 1131$. Since $0 \le 20b \le 180$, $101(a + c)$ lies between $951$ and $1131$, so $a + c$ is $10$ or $11$. If $a + c = 10$, $20b = 121$, impossible; if $a + c = 11$, $20b = 20$, so $b = 1$. The pairs $(a, c)$ with $a + c = 11$ are $(2,9), (3,8), \dots, (9,2)$, giving $219, 318, \dots, 912$: $8$ numbers.",
  "Counting digit pairs as unordered, or not using the tens-digit contribution $20b$.",
  "C24A-number-plus-reverse", "Needs the three-digit identity $101(a + c) + 20b$ and a bound argument.",
  tita_answer=8, check=_c17,
  tita_traps=[(4, "Counts unordered pairs $\\{a, c\\}$, treating a number and its reversal as one."),
              (1, "Finds one number such as $219$ and assumes it is unique.")],
  cognitive="Analysis", exams=HARD)


def _c18():
    s = [n for n in range(10, 100) if n // _ds(n) == 6 and n % _ds(n) == 5]
    assert len(s) == 1
    return s[0]
q("C24-A-018", T, "Division of a two-digit number by its digit sum with a remainder", "Medium",
  "Inverse/parameter",
  r"When a two-digit number is divided by the sum of its digits, the quotient is $6$ and the remainder is $5$. What is the number?",
  "MCQ",
  r"Write the number as $10a + b$. Then $10a + b = 6(a + b) + 5$, so $4a = 5b + 5 = 5(b + 1)$. Hence $b + 1$ is a multiple of $4$, so $b = 3$ or $7$; $b = 7$ gives $a = 10$, not a digit, so $b = 3$, $a = 5$. The number is $53$; check: $53 = 6 \times 8 + 5$.",
  "Ignoring the remainder or putting it on the wrong side of the equation.",
  "C24A-multiple-of-digit-sum", "Division identity with a remainder, then a divisibility argument on the digits.",
  correct=r"$53$",
  distractors=[(r"$54$", "Ignores the remainder: $10a + b = 6(a + b)$ gives $4a = 5b$, so $54$."),
               (r"$55$", "Adds the remainder to the number: $10a + b + 5 = 6(a + b)$ gives $4a = 5b - 5$, so $55$."),
               (r"$35$", "Finds the digits $5$ and $3$ but writes them in the wrong order.")],
  check=_c18, values=[53, 54, 55, 35], cognitive="Application")


def _c19():
    return sum(1 for n in range(100, 1000) if _ds(n) == 11)
q("C24-A-019", T, "Three-digit numbers with a given digit sum", "Medium",
  "Casework/optimisation",
  r"Raffle tickets are numbered from $100$ to $999$, one ticket for each number. A ticket wins a prize if the digits of its number add up to $11$. How many tickets win a prize?",
  "TITA",
  r"Let the digits be $a, b, c$ with $a \ge 1$. Put $a' = a - 1$, so $a' + b + c = 10$ with all three non-negative: $\binom{12}{2} = 66$ solutions. Now remove those breaking a digit limit. $a' \ge 9$ (so $a \ge 10$) leaves $b + c \le 1$: $3$ solutions. $b \ge 10$ forces $b = 10$, $a' = c = 0$: $1$ solution; likewise $c \ge 10$: $1$. These cases cannot overlap, so the answer is $66 - 3 - 1 - 1 = 61$.",
  "Forgetting that the tens and units digits can also exceed $9$ in the raw count, or capping only the hundreds digit.",
  "C24A-count-by-digit-sum", "Stars and bars with corrections on all three digit limits.",
  tita_answer=61, check=_c19,
  tita_traps=[(66, "Applies no digit limit at all after shifting the hundreds digit."),
              (63, "Removes only the cases with hundreds digit $10$ or more, forgetting that $b$ or $c$ could be $10$."),
              (64, "Removes only the cases with $b = 10$ or $c = 10$, forgetting the hundreds-digit limit.")],
  cognitive="Application")


def _c20():
    printed, n = 0, 0
    while True:
        n += 1
        if printed + len(str(n)) >= 1000:
            return n
        printed += len(str(n))
q("C24-A-020", T, "Page on which a given printed digit falls", "Medium",
  "Inverse/parameter",
  r"A machine prints the page numbers of a long book one digit at a time, starting with page $1$ and going through the pages in order. On which page is the $1000$th digit printed?",
  "MCQ",
  r"Pages $1$ to $9$ use $9$ digits and pages $10$ to $99$ use $180$, so $189$ digits are printed by the end of page $99$. That leaves $1000 - 189 = 811$ digits among three-digit pages. Since $811 = 3 \times 270 + 1$, the $270$ pages $100$ to $369$ use $810$ of them, and the $1000$th digit is the first digit of the next page, $370$.",
  "Stopping at the last complete page, or miscounting the pages from $100$ onwards.",
  "C24A-digits-used-in-numbering", "Reverse use of the digit blocks with a remainder that lands inside a page number.",
  correct=r"$370$",
  distractors=[(r"$369$", "Takes the last page completed within the first $1000$ digits, ignoring the leftover digit."),
               (r"$371$", "Rounds $811 \\div 3$ up to $271$ pages and adds this to $100$ instead of $99$."),
               (r"$334$", "Treats every page number as having three digits and rounds $1000 \\div 3$ up.")],
  check=_c20, values=[370, 369, 371, 334], cognitive="Application")


def _c21():
    return sum(str(n).count("7") for n in range(1, 801))
q("C24-A-021", T, "Number of times a digit is written from 1 to 800", "Medium",
  "Multi-step word problem",
  r"All the integers from $1$ to $800$ are written down once each. How many times is the digit $7$ written in all?",
  "MCQ",
  r"Count by place. Units place: $7$ appears once in every block of $10$, and $1$ to $800$ contains $80$ such blocks, so $80$ times. Tens place: $70$ to $79$ in every hundred gives $10$ per hundred, so $8 \times 10 = 80$ times. Hundreds place: every number from $700$ to $799$ has hundreds digit $7$, which is $100$ times (not $80$: the hundreds digit is not spread evenly, and $800$ adds none). Total $80 + 80 + 100 = 260$.",
  "Counting numbers that contain a $7$ instead of the number of times $7$ is written, or mishandling the hundreds place.",
  "C24A-digit-frequency", "Place-by-place counting with an uneven hundreds place.",
  correct=r"$260$",
  distractors=[(r"$233$", "Counts the numbers that contain at least one $7$, so a number like $777$ is counted once instead of three times."),
               (r"$160$", "Leaves out the hundreds place ($700$ to $799$)."),
               (r"$240$", "Assumes each of the three places contributes $80$.")],
  check=_c21, values=[260, 233, 160, 240], cognitive="Application")


def _c22():
    return sum(1 for n in range(100, 1000) if str(n)[0] < str(n)[1] < str(n)[2])
q("C24-A-022", T, "Three-digit numbers with strictly increasing digits", "Medium",
  "Conceptual/application",
  r"How many three-digit numbers have their digits strictly increasing from left to right, as in $258$?",
  "TITA",
  r"Any three different digits can be arranged in increasing order in exactly one way, so the count equals the number of ways to choose $3$ digits. The digit $0$ cannot be used: it would have to come first. So choose $3$ of the digits $1$ to $9$: $\binom{9}{3} = 84$.",
  "Including the digit $0$ in the choice.",
  "C24A-digit-order-patterns", "Insight that an increasing number is just a choice of a digit set.",
  tita_answer=84, check=_c22,
  tita_traps=[(120, "Chooses $3$ digits from $0$ to $9$, $\\binom{10}{3}$, not excluding $0$."),
              (204, "Adds the $\\binom{10}{3} = 120$ numbers with strictly decreasing digits, counting decreasing order as well.")],
  cognitive="Understanding")


def _c23():
    return sum(1 for n in range(100, 1000) if len(set(str(n))) == 2)
q("C24-A-023", T, "Three-digit numbers with exactly two equal digits", "Medium",
  "Casework/optimisation",
  r"How many three-digit numbers have exactly two of their three digits equal (for example, $121$ or $700$)?",
  "MCQ",
  r"Use the complement. Of the $900$ three-digit numbers, $9 \times 9 \times 8 = 648$ have all digits different and $9$ have all three equal ($111, \dots, 999$). The rest have exactly two equal: $900 - 648 - 9 = 243$.",
  "Not removing the numbers with all digits equal, or mishandling $0$.",
  "C24A-repeated-and-distinct-digits", "Complement counting with two excluded categories.",
  correct=r"$243$",
  distractors=[(r"$252$", "Computes $900 - 648$ and forgets to remove the $9$ numbers with all three digits equal."),
               (r"$270$", "Chooses the $3$ positions for the pair, $10$ digits for the pair and $9$ for the other, ignoring that the hundreds digit cannot be $0$."),
               (r"$216$", "Excludes $0$ altogether: $3 \\times 9 \\times 8$.")],
  check=_c23, values=[243, 252, 270, 216], cognitive="Application")


def _c24():
    return sum(1 for n in _forms(range(6)) if n % 3 == 0)
q("C24-A-024", T, "Forming three-digit multiples of 3 from 0 to 5 without repetition", "Medium",
  "Casework/optimisation",
  r"Using the digits $0, 1, 2, 3, 4, 5$, with no digit used more than once in a number, how many three-digit numbers divisible by $3$ can be formed?",
  "TITA",
  r"Group the digits by remainder on division by $3$: $\{0, 3\}$, $\{1, 4\}$, $\{2, 5\}$. A digit sum divisible by $3$ needs one digit from each group (no group has three digits), giving $2 \times 2 \times 2 = 8$ digit sets. The $4$ sets without $0$ give $3! = 6$ numbers each ($24$); the $4$ sets with $0$ give $6 - 2 = 4$ numbers each ($16$). Total $24 + 16 = 40$.",
  "Not removing arrangements with $0$ in the hundreds place.",
  "C24A-form-numbers-divisible-by-3", "Residue classes, then a leading-zero correction for half the sets.",
  tita_answer=40, check=_c24,
  tita_traps=[(48, "Counts $8 \\times 6$ arrangements, allowing $0$ in the hundreds place."),
              (8, "Counts the digit sets instead of the numbers.")],
  cognitive="Application")


def _c25():
    return sum(1 for n in range(100, 1000) if n % 9 == 0 and len(set(str(n))) == 3)
q("C24-A-025", T, "Three-digit multiples of 9 with all digits different", "Difficult",
  "Casework/optimisation",
  r"How many three-digit multiples of $9$ have all three digits different?",
  "MCQ",
  r"The digit sum must be a multiple of $9$; three different digits sum to at most $24$, so the sum is $9$ or $18$. Sum $9$: $\{0,1,8\}, \{0,2,7\}, \{0,3,6\}, \{0,4,5\}, \{1,2,6\}, \{1,3,5\}, \{2,3,4\}$. Sum $18$: no set with $0$ works (it would need $9 + 9$), so $\{1,8,9\}, \{2,7,9\}, \{3,6,9\}, \{4,5,9\}, \{3,7,8\}, \{4,6,8\}, \{5,6,7\}$. The $4$ sets containing $0$ give $3! - 2 = 4$ numbers each ($16$) and the other $10$ sets give $6$ each ($60$). Total $76$.",
  "Missing the digit sum $18$, or not removing arrangements that start with $0$.",
  "C24A-form-numbers-divisible-by-3", "Two target digit sums, fourteen digit sets to list, and a leading-zero correction for some of them.",
  correct=r"$76$",
  distractors=[(r"$84$", "Gives all $14$ digit sets $3! = 6$ arrangements, allowing $0$ in the hundreds place."),
               (r"$34$", "Uses only the digit sum $9$: $4 \\times 4 + 3 \\times 6$."),
               (r"$100$", "Counts all three-digit multiples of $9$, from $108$ to $999$, ignoring the different-digits condition.")],
  check=_c25, values=[76, 84, 34, 100], cognitive="Analysis", exams=HARD)


def _c26():
    return sum(1 for n in range(100, 1000) if n % 11 == 0 and _ds(n) == 13)
q("C24-A-026", T, "Three-digit multiples of 11 with a given digit sum", "Medium",
  "Casework/optimisation",
  r"How many three-digit multiples of $11$ have digit sum $13$?",
  "MCQ",
  r"For digits $a, b, c$, divisibility by $11$ means $a - b + c$ is $0$ or $11$. With $a + b + c = 13$: if $a + c = b$, then $2b = 13$, impossible. If $a + c = b + 11$, then $2b + 11 = 13$, so $b = 1$ and $a + c = 12$, giving $(a, c) = (3, 9), (4, 8), \dots, (9, 3)$: $7$ numbers ($319, 418, 517, 616, 715, 814, 913$).",
  "Considering only the case $a - b + c = 0$.",
  "C24A-multiples-of-11-digits", "The only case that works is the less obvious one, $a - b + c = 11$.",
  correct=r"$7$",
  distractors=[(r"$0$", "Considers only $a - b + c = 0$, finds $2b = 13$ impossible and concludes there are none."),
               (r"$6$", "Drops $616$, assuming the digits must be different."),
               (r"$4$", "Counts unordered pairs $\\{a, c\\}$ with sum $12$: $\\{3,9\\}, \\{4,8\\}, \\{5,7\\}, \\{6,6\\}$.")],
  check=_c26, values=[7, 0, 6, 4], cognitive="Analysis", exams=HARD)


def _c27():
    return sum(_forms([0, 3, 5, 8]))
q("C24-A-027", T, "Sum of three-digit numbers formed from digits including zero", "Medium",
  "Multi-step word problem",
  r"What is the sum of all the three-digit numbers that can be formed using three different digits from $0, 3, 5, 8$?",
  "MCQ",
  r"If $0$ were allowed in front, there would be $24$ arrangements with each digit $6$ times in each place, sum $6 \times 16 \times 111 = 10656$. The arrangements starting with $0$ are the two-digit numbers from $3, 5, 8$; in these each digit appears $2$ times in each of two places, sum $2 \times 16 \times 11 = 352$. So the required sum is $10656 - 352 = 10304$.",
  "Not removing the arrangements that begin with $0$, or removing them with the wrong place values.",
  "C24A-sum-of-formed-numbers", "Symmetry sum plus a correction for leading zeros.",
  correct=r"$10{,}304$",
  distractors=[(r"$10{,}656$", "Includes the arrangements that begin with $0$."),
               (r"$7{,}104$", "Subtracts $2 \\times 16 \\times 111 = 3552$, using three place values for the two-digit numbers."),
               (r"$7{,}992$", "Uses $18$ numbers times an average digit of $4$ in every place: $18 \\times 4 \\times 111$.")],
  check=_c27, values=[10304, 10656, 7104, 7992], cognitive="Application")


def _c28():
    return sum(1 for n in range(100, 1000) if str(n) == str(n)[::-1] and n % 6 == 0)
q("C24-A-028", T, "Three-digit palindromes divisible by 6", "Medium",
  "Casework/optimisation",
  r"A three-digit palindrome is a three-digit number that reads the same from left to right and from right to left, such as $474$. How many three-digit palindromes are divisible by $6$?",
  "MCQ",
  r"Write the palindrome as $aba$. Divisibility by $2$ needs $a \in \{2, 4, 6, 8\}$, and divisibility by $3$ needs $2a + b$ divisible by $3$. For $a = 2$, $b \in \{2, 5, 8\}$; $a = 4$, $b \in \{1, 4, 7\}$; $a = 6$, $b \in \{0, 3, 6, 9\}$; $a = 8$, $b \in \{2, 5, 8\}$. Total $3 + 3 + 4 + 3 = 13$.",
  "Assuming exactly a third of the even palindromes work, or ignoring the evenness condition.",
  "C24A-palindromes-divisibility", "Combines two tests, and the counts per case are uneven.",
  correct=r"$13$",
  distractors=[(r"$15$", "Assumes one-sixth of the $90$ three-digit palindromes are divisible by $6$."),
               (r"$12$", "Assumes $3$ choices of $b$ for each of the $4$ even values of $a$, missing that $a = 6$ allows $4$."),
               (r"$30$", "Checks only divisibility by $3$ and ignores evenness.")],
  check=_c28, values=[13, 15, 12, 30], cognitive="Application")


def _c29():
    return sum(1 for n in range(100, 1000) if math.prod(int(ch) for ch in str(n)) == 12)
q("C24-A-029", T, "Three-digit numbers with a given product of digits", "Medium",
  "Casework/optimisation",
  r"How many three-digit numbers have the product of their digits equal to $12$?",
  "TITA",
  r"No digit can be $0$. The digit multisets with product $12$ are $\{1, 2, 6\}$, $\{1, 3, 4\}$ and $\{2, 2, 3\}$ (a factor $12$ is not a digit). The first two give $3! = 6$ numbers each and $\{2, 2, 3\}$ gives $3$ numbers. Total $6 + 6 + 3 = 15$.",
  "Missing the multiset with a repeated digit, or overcounting its arrangements.",
  "C24A-digit-product-count", "Factor into digit multisets, then arrangements with a repeated digit.",
  tita_answer=15, check=_c29,
  tita_traps=[(18, "Counts $6$ arrangements of $\\{2, 2, 3\\}$ instead of $3$."),
              (12, "Misses the multiset $\\{2, 2, 3\\}$.")],
  cognitive="Application")


def _c30():
    s = [n for n in range(100, 1000) if n % 10 == 2 and n - (200 + n // 10) == 36]
    assert len(s) == 1
    return s[0]
q("C24-A-030", T, "Moving the units digit of a three-digit number to the front", "Medium",
  "Inverse/parameter",
  r"A three-digit number ends in the digit $2$. When this $2$ is moved from the units place to the hundreds place, with the other two digits shifting one place to the right in the same order, the new number is $36$ less than the original. What is the original number?",
  "MCQ",
  r"Let the original be $100t + 10u + 2$; the new number is $200 + 10t + u$. Their difference is $90t + 9u - 198 = 36$, so $10t + u = 26$, giving $t = 2$, $u = 6$. The number is $262$; check: $262 - 226 = 36$.",
  "Reporting the new number, reversing the subtraction, or slipping on place values.",
  "C24A-placing-or-moving-a-digit", "Place-value bookkeeping for a cyclic shift.",
  correct=r"$262$",
  distractors=[(r"$226$", "Solves correctly but reports the new number."),
               (r"$182$", "Subtracts the wrong way, $(200 + 10t + u) - (100t + 10u + 2) = 36$, giving $10t + u = 18$."),
               (r"$242$", "Writes the difference as $99t + 9u - 198$ (subtracting $t$ instead of $10t$), giving $11t + u = 26$, so $t = 2$, $u = 4$.")],
  check=_c30, values=[262, 226, 182, 242], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT

def _c31():
    return sum(1 for n in range(100, 1000) if n == 19 * _ds(n))
q("C24-A-031", T, "Three-digit numbers equal to 19 times their digit sum", "Difficult",
  "Casework/optimisation",
  r"How many three-digit numbers are equal to $19$ times the sum of their digits?",
  "TITA",
  r"With digits $a, b, c$: $100a + 10b + c = 19(a + b + c)$ gives $81a = 9b + 18c$, that is $9a = b + 2c$. Since $b + 2c \le 27$, $a \le 3$. For $a = 1$, $b + 2c = 9$ with $c = 0, \dots, 4$: $5$ numbers. For $a = 2$, $b + 2c = 18$ needs $c \ge 5$: $c = 5, \dots, 9$, $5$ numbers. For $a = 3$, $b = c = 9$: $399$. Total $5 + 5 + 1 = 11$.",
  r"Stopping before $a = 3$, or missing the bound $b \le 9$ in the case analysis.",
  "C24A-multiple-of-digit-sum", "Reduce to $9a = b + 2c$, then three cases with digit bounds.",
  tita_answer=11, check=_c31,
  tita_traps=[(10, "Misses $a = 3$ (the number $399$)."),
              (5, "Considers only $a = 1$.")],
  cognitive="Analysis", exams=HARD)


def _c32():
    vals = {n - _ds(n) for n in range(100, 1000)}
    opts = [486, 495, 477, 504]
    miss = [v for v in opts if v not in vals]
    assert len(miss) == 1
    return miss[0]
q("C24-A-032", T, "Values attainable by a three-digit number minus its digit sum", "Difficult",
  "Conceptual/application",
  r"For a three-digit number $N$, let $S$ be the sum of its digits. Which one of the following values can $N - S$ never take?",
  "MCQ",
  r"For digits $a, b, c$, $N - S = 99a + 9b = 9(11a + b)$ with $1 \le a \le 9$ and $0 \le b \le 9$. So $\frac{N - S}{9}$ must be $11a + b$ with $b \le 9$; a quotient leaving remainder $10$ on division by $11$ is impossible. Now $\frac{486}{9} = 54 = 11 \times 4 + 10$, which cannot occur, while $495 = 9 \times 55$ ($N = 500$), $477 = 9 \times 53$ ($N = 490$) and $504 = 9 \times 56$ ($N = 510$) all occur. The answer is $486$.",
  "Assuming every multiple of $9$ in range can occur, or wrongly restricting the tens digit.",
  "C24A-number-minus-digit-sum", "Needs the structure $9(11a + b)$ and the gap it creates at each change of the hundreds digit.",
  correct=r"$486$",
  distractors=[(r"$495$", "Notices that $495 = 99 \\times 5$ would need $N - S$ to come from $99a$ alone and believes the term $9b$ can never be zero; yet $500 - 5 = 495$."),
               (r"$477$", "Finds $477 \\div 9 = 53$, sees that $53$ lies between $44$ and $55$ and assumes it must be written as $11 \\times 5$ minus something, which is impossible; yet $53 = 11 \\times 4 + 9$ and $490 - 13 = 477$."),
               (r"$504$", "Knows a gap appears where the hundreds digit changes but places it just after $495 = 99 \\times 5$ instead of just before it; yet $510 - 6 = 504$.")],
  check=_c32, values=[486, 495, 477, 504], cognitive="Analysis", exams=HARD)


def _c33():
    return sum(1 for n in range(1, 501) if "3" in str(n) and "5" in str(n))
q("C24-A-033", T, "Integers from 1 to 500 containing two given digits", "Difficult",
  "Casework/optimisation",
  r"How many integers from $1$ to $500$, inclusive, contain both the digit $3$ and the digit $5$ (each at least once)?",
  "MCQ",
  r"Write $0$ to $499$ as three-digit strings $000$ to $499$; $500$ has no $3$ and is not counted. Of these $500$ strings, $4 \times 9 \times 9 = 324$ have no $3$ (hundreds digit from $0, 1, 2, 4$), $5 \times 9 \times 9 = 405$ have no $5$ (hundreds digit from $0$ to $4$), and $4 \times 8 \times 8 = 256$ have neither. By inclusion and exclusion, $500 - 324 - 405 + 256 = 27$ contain both. Check by blocks: each of the hundreds $0, 1, 2, 4$ gives $2$ ($\dots 35$, $\dots 53$) and the $300$s give $19$ (last two digits containing a $5$), so $8 + 19 = 27$.",
  "Double counting a number such as $355$, or overlooking the hundreds other than the $300$s.",
  "C24A-digit-frequency", "Inclusion and exclusion on two digits over an uneven range, with endpoint care.",
  correct=r"$27$",
  distractors=[(r"$28$", "In the $300$s counts $10$ numbers with units digit $5$ and $10$ with tens digit $5$, counting $355$ twice: $8 + 20$."),
               (r"$19$", "Counts only the $300$s, overlooking numbers such as $35$, $153$ and $453$."),
               (r"$26$", "Removes the string $000$ from the neither count only, using $255$ instead of $256$ while keeping $324$ and $405$.")],
  check=_c33, values=[27, 28, 19, 26], cognitive="Analysis", exams=HARD)


def _c34():
    return sum(1 for n in range(100, 1000) if str(n)[1] > str(n)[0] and str(n)[1] > str(n)[2])
q("C24-A-034", T, "Counting three-digit numbers whose middle digit exceeds both others", "Difficult",
  "Casework/optimisation",
  r"A three-digit number is called a peak number if its tens digit is strictly greater than both its hundreds digit and its units digit; for example, $273$ is a peak number. How many peak numbers are there?",
  "TITA",
  r"Fix the tens digit $b$. The hundreds digit can be $1, \dots, b - 1$ ($b - 1$ choices) and the units digit $0, \dots, b - 1$ ($b$ choices), so there are $b(b - 1)$ peak numbers with tens digit $b$. Summing for $b = 2$ to $9$: $2 + 6 + 12 + 20 + 30 + 42 + 56 + 72 = 240$.",
  "Forgetting that the units digit may be $0$, or insisting that all digits differ.",
  "C24A-digit-order-patterns", "Condition on the middle digit and sum an uneven series; two easy-to-miss allowances.",
  tita_answer=240, check=_c34,
  tita_traps=[(204, "Excludes units digit $0$, summing $(b - 1)^2$; requiring the outer digits to differ also gives $204$."),
              (120, "Chooses $3$ different digits and puts the largest in the middle in one way only: $\\binom{10}{3}$.")],
  cognitive="Analysis", exams=HARD)


def _c35():
    return sum(1 for n in range(1, 1000) if _ds(n) == 12)
q("C24-A-035", T, "Integers below 1000 with digit sum 12", "Difficult",
  "Casework/optimisation",
  r"How many integers from $1$ to $999$, inclusive, have digit sum $12$?",
  "MCQ",
  r"Write each integer as a three-digit string $abc$ with leading zeros; this does not change the digit sum. We need $a + b + c = 12$ with each digit from $0$ to $9$. Without the upper limit there are $\binom{14}{2} = 91$ solutions. A digit of $10$ or more leaves the other two summing to at most $2$: $\binom{4}{2} = 6$ solutions for each of the $3$ positions, and two such digits cannot occur together. So $91 - 18 = 73$.",
  "Forgetting the digit cap, applying it to one position only, or counting only three-digit numbers.",
  "C24A-count-by-digit-sum", "Stars and bars with inclusion-exclusion on three caps, plus handling numbers of fewer digits.",
  correct=r"$73$",
  distractors=[(r"$91$", "Ignores the restriction that each digit is at most $9$."),
               (r"$66$", "Counts only three-digit numbers, missing the $7$ two-digit numbers $39, 48, \\dots, 93$."),
               (r"$85$", "Removes the over-limit cases for only one digit position: $91 - 6$.")],
  check=_c35, values=[73, 91, 66, 85], cognitive="Analysis", exams=HARD)


def _c36():
    return sum(1 for n in _forms(range(8)) if n % 6 == 0)
q("C24-A-036", T, "Forming three-digit multiples of 6 from 0 to 7 without repetition", "Difficult",
  "Casework/optimisation",
  r"Using the digits $0, 1, 2, 3, 4, 5, 6, 7$, with no digit used more than once in a number, how many three-digit numbers divisible by $6$ can be formed?",
  "TITA",
  r"The units digit must be $0, 2, 4$ or $6$, and the hundreds and tens digits $h, t$ must make the digit sum divisible by $3$. Use classes mod $3$ among the unused digits and count ordered pairs, then remove $h = 0$. Units $0$: from $\{3,6\}, \{1,4,7\}, \{2,5\}$ we need two from the first class or one from each of the others: $2 + 12 = 14$. Units $2$: need $h + t \equiv 1$, one from $\{0,3,6\}$ and one from $\{1,4,7\}$: $18$, minus $3$ with $h = 0$, so $15$. Units $4$: need $h + t \equiv 2$, one from $\{0,3,6\}$ and one from $\{2,5\}$, or $\{1,7\}$ together: $12 + 2 = 14$, minus $2$, so $12$. Units $6$: need $h + t \equiv 0$, $\{0,3\}$ together or one from $\{1,4,7\}$ and one from $\{2,5\}$: $2 + 12 = 14$, minus $1$, so $13$. Total $14 + 15 + 12 + 13 = 54$.",
  "Not removing arrangements with $0$ in the hundreds place, or testing only divisibility by $3$.",
  "C24A-form-numbers-combined-tests", "Two divisibility tests plus a leading-zero restriction across many digit sets.",
  tita_answer=54, check=_c36,
  tita_traps=[(60, "Allows $0$ in the hundreds place."),
              (106, "Tests only divisibility by $3$, ignoring that the number must be even.")],
  cognitive="Analysis", exams=HARD)


def _c37():
    return sum(1 for n in range(100, 1000) if n % 11 == 0 and "0" not in str(n) and len(set(str(n))) == 3)
q("C24-A-037", T, "Three-digit multiples of 11 with distinct non-zero digits", "Difficult",
  "Casework/optimisation",
  r"How many three-digit multiples of $11$ have three different digits, none of which is $0$?",
  "TITA",
  r"For digits $a, b, c$, divisibility by $11$ means $a + c = b$ or $a + c = b + 11$. Case $a + c = b$ with $a, c \ge 1$, $a \ne c$, $a + c \le 9$: ordered pairs with sum $s$ number $s - 1$, so $\sum_{s=2}^{9}(s - 1) = 36$, minus the $4$ pairs with $a = c$, gives $32$; then $b$ automatically differs from $a$ and $c$. Case $a + c = b + 11$ with $b \ge 1$: $a + c$ from $12$ to $18$ gives $7 + 6 + 5 + 4 + 3 + 2 + 1 = 28$ ordered pairs, minus $4$ with $a = c$, so $24$. Total $32 + 24 = 56$.",
  "Missing the case $a + c = b + 11$, or not excluding $a = c$.",
  "C24A-multiples-of-11-digits", "Two cases from the 11-test, each with distinctness and non-zero corrections.",
  tita_answer=56, check=_c37,
  tita_traps=[(32, "Considers only $a + c = b$."),
              (64, "Does not exclude $a = c$ in either case: $36 + 28$.")],
  cognitive="Analysis", exams=HARD)


def _c38():
    return sum(1 for n in _forms(range(8)) if n % 15 == 0)
q("C24-A-038", T, "Forming three-digit multiples of 15 from 0 to 7 without repetition", "Difficult",
  "Casework/optimisation",
  r"Using the digits $0, 1, 2, 3, 4, 5, 6, 7$, with no digit used more than once in a number, how many three-digit numbers divisible by $15$ can be formed?",
  "MCQ",
  r"The units digit must be $0$ or $5$, and the digit sum must be a multiple of $3$. Units $0$: the hundreds and tens digits $h, t$ come from $1$ to $7$, with classes mod $3$: $\{3, 6\}$, $\{1, 4, 7\}$, $\{2, 5\}$. We need $h + t \equiv 0$: both from $\{3, 6\}$ ($2$ ordered pairs) or one from each of the other two classes ($2 \times 3 \times 2 = 12$), so $14$. Units $5$: $h, t$ come from $0, 1, 2, 3, 4, 6, 7$ and need $h + t \equiv 1$; the classes are $\{0, 3, 6\}$, $\{1, 4, 7\}$, $\{2\}$, so one digit from each of the first two: $2 \times 3 \times 3 = 18$ ordered pairs, minus the $3$ with $h = 0$, giving $15$. Total $14 + 15 = 29$.",
  "Allowing $0$ in the hundreds place, or testing only divisibility by $5$.",
  "C24A-form-numbers-combined-tests", "Two units-digit cases, each with a residue-class count and a leading-zero correction in one of them.",
  correct=r"$29$",
  distractors=[(r"$32$", "Allows $0$ in the hundreds place when the units digit is $5$: $14 + 18$."),
               (r"$14$", "Considers only numbers ending in $0$."),
               (r"$78$", "Tests only divisibility by $5$: $7 \\times 6 = 42$ ending in $0$ and $6 \\times 6 = 36$ ending in $5$.")],
  check=_c38, values=[29, 32, 14, 78], cognitive="Analysis", exams=HARD)


def _c39():
    return sum(_num(p) for p in itertools.permutations([1, 3, 5, 7, 9], 3) if _num(p) > 500)
q("C24-A-039", T, "Sum of three-digit numbers with distinct odd digits above 500", "Difficult",
  "Multi-step word problem",
  r"Consider all three-digit numbers greater than $500$ whose three digits are all odd and all different. What is the sum of all these numbers?",
  "MCQ",
  r"The hundreds digit is $5$, $7$ or $9$, and then the tens and units digits are an ordered pair of different digits from the other $4$ odd digits: $12$ numbers for each hundreds digit, $36$ in all. Hundreds place: $12 \times (5 + 7 + 9) \times 100 = 25200$. For hundreds digit $h$, each of the other $4$ digits appears $3$ times in the tens place, contributing $3(25 - h)$; summing over $h$ gives $3(75 - 21) = 162$, so the tens place gives $1620$ and the units place $162$. Total $25200 + 1620 + 162 = 26982$.",
  "Treating the lower places as if all five odd digits were equally likely there, or ignoring the condition above $500$.",
  "C24A-sum-of-formed-numbers", "Place sums are not symmetric because the hundreds digit restricts the others.",
  correct=r"$26{,}982$",
  distractors=[(r"$27{,}180$", "Uses an average digit of $5$ in the tens and units places: $25200 + 36 \\times 5 \\times 11$."),
               (r"$33{,}300$", "Sums all $60$ numbers with distinct odd digits, ignoring the condition greater than $500$."),
               (r"$28{,}500$", "Copies the count $12$ from the hundreds place to the other places: $25200 + 12 \\times 25 \\times 11$.")],
  check=_c39, values=[26982, 27180, 33300, 28500], cognitive="Analysis", exams=HARD)


def _c40():
    s = [n for n in range(100, 1000) if n % 10 != 0 and n + _rev(n) == 1252 and n // 100 - n % 10 == 4]
    assert len(s) == 1
    return s[0]
q("C24-A-040", T, "Three-digit number from its sum with the reversal and a digit gap", "Medium",
  "Inverse/parameter",
  r"A three-digit number is added to the number formed by reversing its digits, and the sum is $1252$. The hundreds digit of the number is $4$ more than its units digit. What is the number?",
  "MCQ",
  r"With digits $a, b, c$, the sum is $101(a + c) + 20b = 1252$. Since $0 \le 20b \le 180$, $a + c$ is $11$ or $12$; $a + c = 11$ gives $20b = 141$, impossible, so $a + c = 12$ and $20b = 40$, $b = 2$. With $a - c = 4$, $a = 8$ and $c = 4$, so the number is $824$. Check: $824 + 428 = 1252$.",
  "Writing the tens contribution of the sum as $10b$ instead of $20b$, or working column by column without checking the hundreds column.",
  "C24A-number-plus-reverse", "Needs the three-digit reversal-sum identity, a bound argument to fix $a + c$, and care with the $20b$ term.",
  correct=r"$824$",
  distractors=[(r"$844$", "Writes the sum as $101(a + c) + 10b$, counting the tens digit once, so $10b = 40$ gives $b = 4$, with $a = 8$, $c = 4$; but $844 + 448 = 1292$."),
               (r"$874$", "Works by columns: $a + c = 12$ from the units column, then takes $2b + 1 = 15$ (also ending in $5$) so $b = 7$, without checking the hundreds column; but $874 + 478 = 1352$."),
               (r"$428$", "Reads the digit condition the wrong way round, taking the units digit as $4$ more than the hundreds digit, so $a = 4$, $c = 8$; $428 + 824 = 1252$, but its hundreds digit is $4$ less than its units digit.")],
  check=_c40, values=[824, 844, 874, 428], cognitive="Application", exams=HARD)
