import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T_BASIC = "Speed, time and distance basics"
T_AVG = "Average speed"
T_LATE = "Late and early arrival"
CX = ("CAT", "XAT")


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ---------------------------------------------------------------- EASY (13)

def _c1():
    v_ms = F(54 * 1000, 3600)          # 54 km/h in m/s
    t = 1 * 60 + 20                     # seconds
    return v_ms * t
q("C08-A-001", T_BASIC, "Distance in metres from a speed in km/h and a time in minutes and seconds", "Easy",
  "Single-step computation",
  r"A scooter moves at a constant speed of $54$ km/h. How many metres does it cover in $1$ minute $20$ seconds?",
  "TITA",
  r"$54$ km/h $= 54 \times \frac{5}{18} = 15$ m/s, and $1$ minute $20$ seconds $= 80$ s. Distance $= 15 \times 80 = 1200$ m.",
  "Multiplying a km/h speed by a time in seconds without converting units.",
  "C08A-unit-conversion", "One unit conversion and one multiplication; the trap is the mixed units.",
  tita_answer=1200, check=_c1,
  tita_traps=[(4320, r"Multiplies $54$ by $80$ without converting km/h to m/s."),
              (1080, r"Reads $1$ minute $20$ seconds as $1.2$ minutes $= 72$ s, giving $15 \times 72 = 1080$.")],
  cognitive="Application")


def _c2():
    v = symbols('v', positive=True)
    usual = F(20, 40)                       # hours
    return solve(Eq(20 / v, usual - Rational(6, 60)), v)[0]
q("C08-A-002", T_LATE, "Speed needed on a fixed route to arrive a given time earlier", "Easy",
  "Inverse/parameter",
  r"Kabir's office is $20$ km from his home, and he usually drives there at a constant $40$ km/h. One day he leaves home at his usual time and wants to reach his office $6$ minutes earlier than usual. At what constant speed must he drive?",
  "MCQ",
  r"His usual drive takes $\frac{20}{40} = \frac{1}{2}$ hour $= 30$ minutes, so he must cover $20$ km in $24$ minutes $= \frac{2}{5}$ hour. Speed $= 20 \div \frac{2}{5} = 50$ km/h. (Equivalently, the time falls to $\frac{4}{5}$ of usual, so the speed rises to $\frac{5}{4} \times 40$.)",
  r"Assuming a $20\%$ cut in time needs only a $20\%$ rise in speed, or treating speed as directly proportional to time.",
  "C08A-fixed-distance-speed-change", "One usual time, one target time and one division; the trap is the inverse proportion.",
  correct=r"$50$ km/h",
  distractors=[(r"$48$ km/h", r"Sees that $6$ minutes is $20\%$ of the usual $30$ minutes and raises the speed by $20\%$: $40 \times 1.2 = 48$."),
               (r"$32$ km/h", r"Scales the speed in the same ratio as the time: $40 \times \frac{24}{30} = 32$."),
               (r"$44$ km/h", r"Finds that at $40$ km/h he covers only $40 \times \frac{24}{60} = 16$ km in the $24$ minutes, and adds the $4$ km shortfall to the speed: $40 + 4 = 44$.")],
  check=_c2, values=[50, 48, 32, 44], cognitive="Application")


def _c3():
    d = Symbol('d', positive=True)
    return simplify(2 * d / (d / 60 + d / 40))
q("C08-A-003", T_AVG, "Round trip at two speeds over equal distances", "Easy",
  "Conceptual/application",
  r"Priya drives from Nashik to Pune at a constant $60$ km/h and returns along the same road at a constant $40$ km/h. What is her average speed, in km/h, for the whole round trip?",
  "TITA",
  r"For equal distances the average speed is the harmonic mean: $\frac{2 \times 60 \times 40}{60 + 40} = \frac{4800}{100} = 48$ km/h. (For example, $120$ km each way takes $2 + 3 = 5$ hours for $240$ km.)",
  "Taking the arithmetic mean of the two speeds when the distances, not the times, are equal.",
  "C08A-avg-speed-equal-distance", "Direct use of the equal-distance average; the trap is the arithmetic mean.",
  tita_answer=48, check=_c3,
  tita_traps=[(50, r"Takes the arithmetic mean $\frac{60 + 40}{2}$."),
              (24, r"Uses $\frac{60 \times 40}{60 + 40}$ and drops the factor $2$.")],
  cognitive="Understanding")


def _c4():
    t = F(40, 60)
    dist = 12 * t + 18 * t + 24 * t
    return dist / (3 * t)
q("C08-A-004", T_AVG, "Average speed over three legs of equal time", "Easy",
  "Conceptual/application",
  r"On a training ride, Meera cycles for $40$ minutes at $12$ km/h, then for $40$ minutes at $18$ km/h, and then for $40$ minutes at $24$ km/h. What is her average speed for the entire ride?",
  "MCQ",
  r"The three legs take equal times, so the average speed is the arithmetic mean $\frac{12 + 18 + 24}{3} = 18$ km/h. Directly: distances $8 + 12 + 16 = 36$ km in $2$ hours gives $18$ km/h.",
  "Using the harmonic mean, which applies to equal distances, or slipping on minutes to hours.",
  "C08A-avg-speed-equal-time", "Recognising equal times; one line of arithmetic.",
  correct=r"$18$ km/h",
  distractors=[(r"$16\frac{8}{13}$ km/h", r"Applies the equal-distance rule: $\frac{3}{\frac{1}{12} + \frac{1}{18} + \frac{1}{24}} = \frac{216}{13}$."),
               (r"$30$ km/h", r"Writes $120$ minutes as $1.2$ hours: $\frac{36}{1.2} = 30$."),
               (r"$12$ km/h", r"Divides the total distance $36$ km by the number of legs, $3$.")],
  check=_c4, values=[18, F(216, 13), 30, 12], cognitive="Understanding")


def _c5():
    t = F(3) / F(9, 2)         # Arjun's time for 3 km
    return F(8) / t
q("C08-A-005", T_BASIC, "Same time, distances proportional to speeds", "Easy",
  "Conceptual/application",
  r"Arjun walks at a constant $4.5$ km/h. In the time Arjun walks $3$ km, Sneha cycles $8$ km at a constant speed. What is Sneha's speed?",
  "MCQ",
  r"In equal times distances are proportional to speeds, so Sneha's speed $= 4.5 \times \frac{8}{3} = 12$ km/h. (Arjun takes $\frac{3}{4.5} = \frac{2}{3}$ hour, and $8 \div \frac{2}{3} = 12$.)",
  r"Mishandling Arjun's time of $\frac{2}{3}$ hour, or computing the speed of the extra distance only.",
  "C08A-fixed-time-proportion", "Single proportion with one conversion trap.",
  correct=r"$12$ km/h",
  distractors=[(r"$20$ km/h", r"Converts Arjun's $\frac{2}{3}$ hour to $40$ minutes and then writes it as $0.4$ hour: $\frac{8}{0.4} = 20$."),
               (r"$7.5$ km/h", r"Divides the extra $5$ km by the $\frac{2}{3}$ hour, finding how much faster she covers ground rather than her speed."),
               (r"$5\frac{1}{3}$ km/h", r"Inverts Arjun's time: $\frac{4.5}{3} = 1.5$ hours, so $8 \div 1.5 = \frac{16}{3}$.")],
  check=_c5, values=[12, 20, F(15, 2), F(16, 3)], cognitive="Application")


def _c6():
    T = symbols('T', positive=True)
    # time at 4/5 speed is 5/4 of usual
    return solve(Eq(T * Rational(5, 4) - T, 9), T)[0]
q("C08-A-006", T_LATE, "Late by a fixed time at a fraction of usual speed; find usual time", "Easy",
  "Conceptual/application",
  r"When Joseph walks at $\frac{4}{5}$ of his usual speed, he reaches his office $9$ minutes later than usual. How many minutes does he usually take to walk to his office?",
  "TITA",
  r"At $\frac{4}{5}$ of the speed the time becomes $\frac{5}{4}$ of the usual time $T$. The extra $\frac{T}{4} = 9$, so $T = 36$ minutes.",
  r"Assuming the time rises by $\frac{1}{5}$ because the speed falls by $\frac{1}{5}$.",
  "C08A-fraction-of-usual-speed", "One inverse-proportion step; classic trap of a symmetric percentage.",
  tita_answer=36, check=_c6,
  tita_traps=[(45, r"Writes the extra time as $\frac{T}{5} = 9$ (or reports the new time $36 + 9$); both give $45$.")],
  cognitive="Understanding")


def _c7():
    secs = F(27000, 5)
    return secs / 60          # minutes
q("C08-A-007", T_BASIC, "Time for a distance in km at a speed in m/s", "Easy",
  "Single-step computation",
  r"In a time trial, a cyclist rides at a constant $5$ m/s. How long does the cyclist take to cover $27$ km?",
  "MCQ",
  r"$5$ m/s $= 5 \times \frac{18}{5} = 18$ km/h. Time $= \frac{27}{18} = 1.5$ hours, which is $1$ hour $30$ minutes.",
  "Treating m/s as km/h, or reading a decimal hour as hours and minutes.",
  "C08A-unit-conversion", "One conversion and one division, with a decimal-hour trap.",
  correct=r"$1$ hour $30$ minutes",
  distractors=[(r"$1$ hour $50$ minutes", r"Gets $1.5$ hours and reads it as $1$ hour $50$ minutes."),
               (r"$5$ hours $24$ minutes", r"Uses $5$ m/s as $5$ km/h: $\frac{27}{5} = 5.4$ hours $= 5$ hours $24$ minutes."),
               (r"$5$ hours $40$ minutes", r"Uses $5$ m/s as $5$ km/h and then reads $5.4$ hours as $5$ hours $40$ minutes.")],
  check=_c7, values=[90, 110, 324, 340], cognitive="Application")


def _c8():
    d1, s1, d2, s2 = 180, 90, 90, 30
    return F(d1 + d2) / (F(d1, s1) + F(d2, s2))
q("C08-A-008", T_AVG, "Average speed over two legs of unequal length", "Easy",
  "Multi-step word problem",
  r"A bus travels $180$ km at a constant $90$ km/h and then a further $90$ km at a constant $30$ km/h. What is its average speed for the whole journey?",
  "MCQ",
  r"Times are $\frac{180}{90} = 2$ hours and $\frac{90}{30} = 3$ hours. Average speed $= \frac{270}{5} = 54$ km/h.",
  "Averaging the speeds instead of dividing total distance by total time.",
  "C08A-avg-speed-unequal-legs", "Two leg times and one division; three tempting shortcuts.",
  correct=r"$54$ km/h",
  distractors=[(r"$60$ km/h", r"Takes the arithmetic mean $\frac{90 + 30}{2}$."),
               (r"$45$ km/h", r"Uses the equal-distance formula $\frac{2 \times 90 \times 30}{120}$ although the legs differ in length."),
               (r"$70$ km/h", r"Weights the speeds by distance: $\frac{180 \times 90 + 90 \times 30}{270} = \frac{18900}{270}$.")],
  check=_c8, values=[54, 60, 45, 70], cognitive="Application")


def _c9():
    circ_cm = F(22, 7) * 70
    m_per_min = circ_cm / 100 * 250
    return m_per_min * 60 / 1000
q("C08-A-009", T_BASIC, "Speed from wheel diameter and revolutions per minute", "Easy",
  "Multi-step word problem",
  r"The front wheel of a bicycle has a diameter of $70$ cm and turns at a steady $250$ revolutions per minute without slipping. Taking $\pi = \frac{22}{7}$, what is the speed of the bicycle in km/h?",
  "TITA",
  r"Circumference $= \frac{22}{7} \times 70 = 220$ cm $= 2.2$ m. Distance per minute $= 2.2 \times 250 = 550$ m, so per hour $550 \times 60 = 33000$ m $= 33$ km. Speed $= 33$ km/h.",
  "Using the diameter as the radius, or stopping at metres per minute.",
  "C08A-wheel-revolutions", "Two short conversions; the radius and unit traps.",
  tita_answer=33, check=_c9,
  tita_traps=[(66, r"Takes $70$ cm as the radius, doubling the circumference."),
              (550, r"Stops at $550$ m per minute and types that.")],
  cognitive="Application")


def _c10():
    new_time = 1 / F(5, 4)
    return (1 - new_time) * 100
q("C08-A-010", T_BASIC, "Percentage fall in time for a percentage rise in speed", "Easy",
  "Conceptual/application",
  r"On a fixed route, a delivery van's average speed rises by $25\%$ after a new flyover opens. By what percentage does its travel time on the route decrease? Type the number of percent only (for example, type $15$ for $15\%$).",
  "TITA",
  r"At fixed distance, time is inversely proportional to speed. New time $= \frac{1}{1.25} = \frac{4}{5}$ of the old time, a fall of $\frac{1}{5} = 20\%$.",
  "Assuming the time falls by the same percentage as the speed rises.",
  "C08A-percent-speed-change", "One inverse-proportion step; the trap is symmetry.",
  tita_answer=20, check=_c10,
  tita_traps=[(25, r"Assumes time falls by the same $25\%$."),
              (80, r"Reports the new time as a percentage of the old one.")],
  cognitive="Understanding")


def _c11():
    d = symbols('d', positive=True)
    return solve(Eq(d / 30 - d / 40, Rational(10 + 5, 60)), d)[0]
q("C08-A-011", T_LATE, "Late at one speed, early at another; find the distance", "Easy",
  "Multi-step word problem",
  r"Harpreet leaves home at the same time every day to drive to her factory. If she drives at a constant $30$ km/h, she reaches $10$ minutes late; if she drives at a constant $40$ km/h, she reaches $5$ minutes early. What is the distance from her home to the factory?",
  "MCQ",
  r"The two travel times differ by $10 + 5 = 15$ minutes. So $\frac{d}{30} - \frac{d}{40} = \frac{1}{4}$, that is $\frac{d}{120} = \frac{1}{4}$, giving $d = 30$ km. (She takes $60$ and $45$ minutes; on time is $50$ minutes.)",
  "Subtracting the late and early margins instead of adding them.",
  "C08A-late-early-two-speeds", "One equation; the trap is how the two margins combine.",
  correct=r"$30$ km",
  distractors=[(r"$10$ km", r"Takes the time difference as $10 - 5 = 5$ minutes: $\frac{d}{120} = \frac{1}{12}$."),
               (r"$18$ km", r"Writes $15$ minutes as $0.15$ hour: $d = 120 \times 0.15$."),
               (r"$50$ km", r"Finds the on-time travel time, $50$ minutes, and reports that number as the distance.")],
  check=_c11, values=[30, 10, 18, 50], cognitive="Application")


def _c12():
    x = symbols('x', positive=True)
    return simplify(3 * x / (x / 20 + x / 30 + x / 60))
q("C08-A-012", T_AVG, "Average speed over three stretches of equal length", "Easy",
  "Conceptual/application",
  r"A tourist bus covers three stretches of equal length at constant speeds of $20$ km/h, $30$ km/h and $60$ km/h respectively. What is its average speed for the whole journey?",
  "MCQ",
  r"Let each stretch be $60$ km. The times are $3$, $2$ and $1$ hours, so $180$ km take $6$ hours and the average is $30$ km/h. In general it is $\frac{3}{\frac{1}{20} + \frac{1}{30} + \frac{1}{60}} = \frac{3}{\frac{1}{10}} = 30$.",
  "Using the arithmetic mean, or applying the two-speed formula in stages.",
  "C08A-avg-speed-equal-distance", "Harmonic mean of three speeds with convenient reciprocals.",
  correct=r"$30$ km/h",
  distractors=[(r"$36\frac{2}{3}$ km/h", r"Takes the arithmetic mean $\frac{20 + 30 + 60}{3}$."),
               (r"$34\frac{2}{7}$ km/h", r"Combines $20$ and $30$ into $24$, then applies $\frac{2ab}{a+b}$ to $24$ and $60$ as if the two parts were equal in length: $\frac{2 \times 24 \times 60}{84} = \frac{240}{7}$."),
               (r"$10$ km/h", r"Computes $\frac{1}{\frac{1}{20} + \frac{1}{30} + \frac{1}{60}}$ and omits the factor $3$.")],
  check=_c12, values=[30, F(110, 3), F(240, 7), 10], cognitive="Application")


def _c13():
    t = symbols('t', positive=True)   # bus time in hours
    return solve(Eq(t - t * Rational(3, 5), Rational(72, 60)), t)[0] * 60
q("C08-A-013", T_BASIC, "Speed ratio to time ratio on the same route", "Easy",
  "Conceptual/application",
  r"The speeds of a car and a bus are in the ratio $5 : 3$. On the same route the car takes $1$ hour $12$ minutes less than the bus. How long does the bus take for the route?",
  "MCQ",
  r"Times are inversely proportional to speeds, so car time $:$ bus time $= 3 : 5$. The difference of $2$ parts is $72$ minutes, so $1$ part is $36$ minutes and the bus takes $5 \times 36 = 180$ minutes $= 3$ hours.",
  "Using the speed ratio directly as the time ratio.",
  "C08A-speed-ratio-time-ratio", "One inversion of a ratio and a parts calculation.",
  correct=r"$3$ hours",
  distractors=[(r"$1$ hour $48$ minutes", r"Gives the bus $3$ parts (speed ratio used as time ratio): $3 \times 36 = 108$ minutes."),
               (r"$2$ hours $48$ minutes", r"Writes $1$ hour $12$ minutes as $1.12$ hours: $1$ part $= 0.56$ hour, bus $= 2.8$ hours."),
               (r"$6$ hours", r"Treats the whole $72$ minutes as one part: $5 \times 72 = 360$ minutes.")],
  check=_c13, values=[180, 108, 168, 360], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM (18)

def _c14():
    v = symbols('v', positive=True)
    return solve(Eq(240 / (F(120, 40) + 120 / v), 48), v)[0]
q("C08-A-014", T_AVG, "Speed needed on the second half of the distance for a target average", "Medium",
  "Inverse/parameter",
  r"Ravi has to drive $240$ km. He covers the first $120$ km at a constant $40$ km/h. At what constant speed, in km/h, must he cover the remaining $120$ km so that his average speed for the whole $240$ km is exactly $48$ km/h?",
  "TITA",
  r"At $48$ km/h the $240$ km must take $5$ hours. The first $120$ km took $3$ hours, so the last $120$ km must take $2$ hours: speed $= 60$ km/h.",
  "Treating the target average as the arithmetic mean of the two speeds.",
  "C08A-missing-leg-target-average", "Work back from total time; the arithmetic-mean trap is strong.",
  tita_answer=60, check=_c14,
  tita_traps=[(56, r"Solves $\frac{40 + v}{2} = 48$."),
              (48, r"Assumes driving the rest at the target speed is enough.")],
  cognitive="Application")


def _c15():
    v = symbols('v', positive=True)
    return solve(Eq(36 / (F(12, 16) + F(12, 24) + 12 / v), 24), v)[0]
q("C08-A-015", T_AVG, "Speed on the third of three equal stretches for a target average", "Medium",
  "Inverse/parameter",
  r"Fatima cycles a $36$ km route made of three stretches of $12$ km each. She rides the first stretch at a constant $16$ km/h and the second at a constant $24$ km/h. At what constant speed must she ride the third stretch so that her average speed over the whole route is $24$ km/h?",
  "MCQ",
  r"At $24$ km/h the route must take $\frac{36}{24} = 1.5$ hours. The first two stretches take $\frac{12}{16} + \frac{12}{24} = 0.75 + 0.5 = 1.25$ hours, leaving $0.25$ hour for $12$ km, so the speed is $48$ km/h.",
  "Averaging speeds arithmetically or slipping on a quarter hour.",
  "C08A-missing-leg-target-average", "Three legs and a back calculation from total time.",
  correct=r"$48$ km/h",
  distractors=[(r"$32$ km/h", r"Sets $\frac{16 + 24 + v}{3} = 24$."),
               (r"$80$ km/h", r"Writes the remaining $15$ minutes as $0.15$ hour: $\frac{12}{0.15} = 80$."),
               (r"$24$ km/h", r"Assumes riding the last stretch at the target speed gives the target average.")],
  check=_c15, values=[48, 32, 80, 24], cognitive="Application")


def _c16():
    d = symbols('d', positive=True)
    dist = solve(Eq(d / 12 - d / 15, Rational(10 + 8, 60)), d)[0]
    return dist / 12 * 60 - 10
q("C08-A-016", T_LATE, "On-time travel time from a late and an early trial", "Medium",
  "Multi-step word problem",
  r"Sneha leaves home at the same time every day to cycle to college. At a constant $12$ km/h she arrives $10$ minutes late; at a constant $15$ km/h she arrives $8$ minutes early. How many minutes should the ride take for her to arrive exactly on time?",
  "TITA",
  r"The two ride times differ by $18$ minutes: $\frac{d}{12} - \frac{d}{15} = \frac{d}{60} = \frac{18}{60}$, so $d = 18$ km. At $12$ km/h she takes $90$ minutes and is $10$ minutes late, so the on-time ride is $80$ minutes. (Check: at $15$ km/h, $72 + 8 = 80$.)",
  "Averaging the two ride times, which works only when the late and early margins are equal.",
  "C08A-late-early-two-speeds", "Needs the distance first, then the on-time duration; unequal margins defeat the averaging shortcut.",
  tita_answer=80, check=_c16,
  tita_traps=[(81, r"Averages the two ride times $90$ and $72$ minutes."),
              (90, r"Reports the ride time at $12$ km/h.")],
  cognitive="Application")


def _c17():
    d, T = symbols('d T', positive=True)
    sol = solve([Eq(d / 30, T + Rational(20, 60)), Eq(d / 50, T - Rational(28, 60))], [d, T], dict=True)[0]
    return sol[d] / sol[T]
q("C08-A-017", T_LATE, "Speed for exact arrival when late and early margins are unequal", "Medium",
  "Inverse/parameter",
  r"Fatima leaves home at the same time every day to drive to work. At a constant $30$ km/h she reaches $20$ minutes late, and at a constant $50$ km/h she reaches $28$ minutes early. At what constant speed should she drive to reach exactly on time?",
  "MCQ",
  r"The travel times differ by $48$ minutes: $\frac{d}{30} - \frac{d}{50} = \frac{d}{75} = \frac{4}{5}$, so $d = 60$ km. At $30$ km/h she takes $120$ minutes, so the on-time duration is $100$ minutes. Speed $= 60 \div \frac{5}{3} = 36$ km/h.",
  "Using the harmonic or arithmetic mean, or interpolating linearly in speed.",
  "C08A-late-early-two-speeds","Unequal margins break both mean shortcuts; must find distance and on-time duration.",
  correct=r"$36$ km/h",
  distractors=[(r"$37.5$ km/h", r"Uses $\frac{2 \times 30 \times 50}{80}$, the shortcut valid only when the late and early margins are equal."),
               (r"$40$ km/h", r"Takes the arithmetic mean of $30$ and $50$."),
               (r"$38\frac{1}{3}$ km/h", r"Interpolates linearly in speed: $30 + 20 \times \frac{20}{48} = \frac{115}{3}$.")],
  check=_c17, values=[36, F(75, 2), 40, F(115, 3)], cognitive="Analysis", exams=CX)


def _c18():
    v = symbols('v')
    return _pos(solve(Eq(360 / v - 360 / (v + 8), Rational(3, 2)), v))[0]
q("C08-A-018", T_BASIC, "Original speed from time saved by a speed increase (quadratic)", "Medium",
  "Multi-step word problem",
  r"A bus covers $360$ km at a constant speed. If its speed had been $8$ km/h more, the journey would have taken $1$ hour $30$ minutes less. What was its actual speed, in km/h?",
  "TITA",
  r"$\frac{360}{v} - \frac{360}{v + 8} = \frac{3}{2}$ gives $v(v + 8) = \frac{360 \times 8 \times 2}{3} = 1920$. Since $40 \times 48 = 1920$, $v = 40$ km/h. (Times: $9$ hours against $7.5$ hours.)",
  "Reporting the increased speed, or dropping the linear term.",
  "C08A-speed-increase-quadratic", r"Sets up and factors a quadratic; spotting $40 \times 48$ is the fast route.",
  tita_answer=40, check=_c18,
  tita_traps=[(48, r"Reports the increased speed $v + 8$."),
              (44, r"Drops the $8v$ term: $v^2 = 1920$, $v \approx 43.8$, typed as $44$.")],
  cognitive="Application")


def _c19():
    T = symbols('T', positive=True)
    rem = T * Rational(2, 3)
    return solve(Eq(rem * Rational(5, 4) - rem, 24), T)[0]
q("C08-A-019", T_LATE, "Speed drops after a fraction of the journey; find the usual time", "Medium",
  "Multi-step word problem",
  r"Arjun sets out on a journey at his usual constant speed. After covering $\frac{1}{3}$ of the distance, a fault in his scooter forces him to ride the rest of the way at $\frac{4}{5}$ of that speed, and he arrives $24$ minutes later than he would have at his usual speed throughout. How long does the whole journey normally take him?",
  "MCQ",
  r"Let the usual time be $T$. The last $\frac{2}{3}$ of the distance normally takes $\frac{2T}{3}$; at $\frac{4}{5}$ speed it takes $\frac{5}{4}$ of that, an extra $\frac{1}{4} \times \frac{2T}{3} = \frac{T}{6}$. So $\frac{T}{6} = 24$ and $T = 144$ minutes $= 2$ hours $24$ minutes.",
  r"Applying the slowdown to the whole journey, or treating a $20\%$ speed cut as a $20\%$ time rise.",
  "C08A-breakdown-midway", "Two ideas: only part of the journey is affected, and the inverse change in time.",
  correct=r"$2$ hours $24$ minutes",
  distractors=[(r"$3$ hours", r"Takes the $20\%$ speed cut as a $20\%$ time rise on the last part: $\frac{1}{5} \times \frac{2T}{3} = 24$ gives $T = 180$ minutes."),
               (r"$1$ hour $36$ minutes", r"Applies the extra $\frac{1}{4}$ to the whole journey: $\frac{T}{4} = 24$ gives $T = 96$ minutes."),
               (r"$2$ hours $48$ minutes", r"Reports the delayed journey time $144 + 24 = 168$ minutes.")],
  check=_c19, values=[144, 180, 96, 168], cognitive="Application")


def _c20():
    R = symbols('R', positive=True)   # usual time for second half, minutes
    r = solve(Eq(R * Rational(4, 3) - R, 10), R)[0]
    return r - r * Rational(4, 5)
q("C08-A-020", T_LATE, "Late with a slower second half, then early with a faster second half", "Medium",
  "Conceptual/application",
  r"Meera drives to work and, at her usual constant speed, arrives exactly at $9{:}00$ am. On Monday she left at the usual time, drove the first half of the distance at her usual speed and the second half at $\frac{3}{4}$ of her usual speed, and arrived $10$ minutes late. On Tuesday she left at the usual time, drove the first half at her usual speed and the second half at $\frac{5}{4}$ of her usual speed. How many minutes before $9{:}00$ am did she arrive on Tuesday?",
  "TITA",
  r"Let the second half usually take $R$ minutes. On Monday it took $\frac{4}{3}R$, so $\frac{R}{3} = 10$ and $R = 30$. On Tuesday it took $\frac{4}{5}R = 24$ minutes, saving $6$ minutes.",
  "Assuming equal and opposite speed changes give equal and opposite time changes.",
  "C08A-breakdown-midway", "Inverse proportion applied twice with asymmetric results; the symmetry trap is strong.",
  tita_answer=6, check=_c20,
  tita_traps=[(10, r"Assumes the $25\%$ speed rise saves exactly what the $25\%$ speed fall lost."),
              (8, r"Takes the Monday delay as $\frac{R}{4} = 10$, so $R = 40$, and then $\frac{R}{5} = 8$.")],
  cognitive="Analysis")


def _c21():
    w, r = symbols('w r', positive=True)
    s = solve([Eq(w + r, 105), Eq(2 * r, 50)], [w, r], dict=True)[0]
    return 2 * s[w]
q("C08-A-021", T_BASIC, "Walk one way and ride back; find the walk-both-ways time", "Medium",
  "Conceptual/application",
  r"Ananya walks to the library and returns by autorickshaw along the same road; the round trip takes $1$ hour $45$ minutes of travel. When she goes both ways by autorickshaw, the round trip takes $50$ minutes. Her walking speed and the autorickshaw's speed are the same on every trip. How many minutes would the round trip take if she walked both ways?",
  "TITA",
  r"One autorickshaw leg takes $\frac{50}{2} = 25$ minutes, so one walking leg takes $105 - 25 = 80$ minutes. Walking both ways takes $2 \times 80 = 160$ minutes.",
  "Combining the two given totals directly instead of isolating one leg.",
  "C08A-walk-ride-combination", "Isolating single-leg times from two combined totals.",
  tita_answer=160, check=_c21,
  tita_traps=[(210, r"Doubles the walk-and-ride total $105$ minutes."),
              (155, r"Adds the two given totals $105 + 50$.")],
  cognitive="Understanding")


def _c22():
    x = symbols('x', positive=True)
    return solve(Eq(F(10, 5) + x / 3 + x / 6, 5), x)[0]
q("C08-A-022", T_AVG, "Round trip over flat ground and a hill; find the hill length", "Medium",
  "Multi-step word problem",
  r"From a village, a footpath runs $5$ km across flat ground to the foot of a hill and then climbs steadily up the hill to a temple. Kabir walks at $5$ km/h on flat ground, $3$ km/h uphill and $6$ km/h downhill. His walking time for the round trip from the village to the temple and back along the same path is $5$ hours. How long is the uphill stretch?",
  "MCQ",
  r"The flat part is walked twice: $\frac{10}{5} = 2$ hours. That leaves $3$ hours for the hill: $\frac{x}{3} + \frac{x}{6} = \frac{x}{2} = 3$, so $x = 6$ km.",
  "Averaging uphill and downhill speeds arithmetically, or counting the flat stretch once.",
  "C08A-uphill-downhill", "Separate the flat legs, then a two-speed round trip on the hill.",
  correct=r"$6$ km",
  distractors=[(r"$6.75$ km", r"Uses the mean $4.5$ km/h for the hill: $\frac{2x}{4.5} = 3$."),
               (r"$8$ km", r"Counts the flat $5$ km only once, leaving $4$ hours: $\frac{x}{2} = 4$."),
               (r"$12$ km", r"Reports the total hill walking, up and down, $2x$.")],
  check=_c22, values=[6, F(27, 4), 8, 12], cognitive="Application")


def _c23():
    r = symbols('r', positive=True)
    rem = solve(Eq(r / 45 - r / 60, Rational(20, 60)), r)[0]
    return 90 - rem
q("C08-A-023", T_BASIC, "Part of a route at a higher speed; find the split from the time saved", "Medium",
  "Inverse/parameter",
  r"Priya normally drives the $90$ km from her town to the city at a constant $45$ km/h. One day she drove the first part of the route at $45$ km/h and the rest at a constant $60$ km/h, and saved $20$ minutes. How many kilometres did she drive at $45$ km/h?",
  "MCQ",
  r"Only the faster part saves time. If it is $r$ km, then $\frac{r}{45} - \frac{r}{60} = \frac{r}{180} = \frac{1}{3}$, so $r = 60$ km at $60$ km/h and $90 - 60 = 30$ km at $45$ km/h.",
  "Finding the faster stretch and reporting it, or mishandling the difference of reciprocals.",
  "C08A-partial-speed-change", "Time saved arises only on the changed stretch; then subtract from the total.",
  correct=r"$30$ km",
  distractors=[(r"$60$ km", r"Reports the stretch driven at $60$ km/h."),
               (r"$54$ km", r"Writes $20$ minutes as $0.2$ hour: $r = 36$, so $90 - 36 = 54$."),
               (r"$85$ km", r"Writes $\frac{r}{60 - 45} = \frac{1}{3}$, giving $r = 5$ and $90 - 5 = 85$.")],
  check=_c23, values=[30, 60, 54, 85], cognitive="Application")


def _c24():
    run_km = F(5 * 3600, 1000) * F(20, 60)
    walk_km = 6 * F(40, 60)
    return (run_km + walk_km) / 1
q("C08-A-024", T_AVG, "Average speed with legs in m/s and km/h over unequal times", "Medium",
  "Multi-step word problem",
  r"During a $1$ hour workout, Kabir runs for the first $20$ minutes at a constant $5$ m/s and then walks for $40$ minutes at a constant $6$ km/h. What is his average speed for the workout?",
  "MCQ",
  r"$5$ m/s $= 18$ km/h, so the run covers $18 \times \frac{1}{3} = 6$ km and the walk $6 \times \frac{2}{3} = 4$ km. Total $10$ km in $1$ hour: $10$ km/h.",
  "Averaging the two speeds, or not converting m/s to km/h.",
  "C08A-unit-conversion", "Conversion plus a time-weighted average with unequal times.",
  correct=r"$10$ km/h",
  distractors=[(r"$12$ km/h", r"Takes the arithmetic mean of $18$ and $6$, as if the times were equal."),
               (r"$9$ km/h", r"Uses $\frac{2 \times 18 \times 6}{24}$, the equal-distance formula."),
               (r"$5.5$ km/h", r"Averages $5$ and $6$ without converting m/s to km/h.")],
  check=_c24, values=[10, 12, 9, F(11, 2)], cognitive="Application")


def _c25():
    dists = [10, 20, 30]
    best = max(F(60) / sum(F(d, s) for d, s in zip(dists, p)) for p in itertools.permutations([10, 15, 30]))
    return best
q("C08-A-025", T_AVG, "Maximum average speed by assigning speeds to stretches", "Medium",
  "Casework/optimisation",
  r"A cyclist has to ride three stretches of $10$ km, $20$ km and $30$ km. She will ride each stretch at one of the constant speeds $10$ km/h, $15$ km/h and $30$ km/h, using each speed on exactly one stretch, in whatever order she chooses. What is the highest average speed she can achieve over the $60$ km?",
  "MCQ",
  r"Total time is least when the longest stretch gets the fastest speed: $\frac{30}{30} + \frac{20}{15} + \frac{10}{10} = 1 + \frac{4}{3} + 1 = \frac{10}{3}$ hours. Average $= 60 \div \frac{10}{3} = 18$ km/h. Any other pairing takes longer (the worst is $\frac{14}{3}$ hours).",
  "Averaging the three speeds, or pairing the fastest speed with the shortest stretch.",
  "C08A-optimise-leg-speed-assignment", "Needs the pairing principle and a comparison of cases.",
  correct=r"$18$ km/h",
  distractors=[(r"$18\frac{1}{3}$ km/h", r"Takes the arithmetic mean $\frac{10 + 15 + 30}{3}$."),
               (r"$15$ km/h", r"Uses the equal-distance formula $\frac{3}{\frac{1}{10} + \frac{1}{15} + \frac{1}{30}}$."),
               (r"$12\frac{6}{7}$ km/h", r"Rides the shortest stretch fastest and the longest slowest: $60 \div \frac{14}{3} = \frac{90}{7}$.")],
  check=_c25, values=[18, F(55, 3), 15, F(90, 7)], cognitive="Analysis")


def _c26():
    used = F(30, 45)
    v = 1
    while used + F(70, v) > 2:
        v += 1
    return v
q("C08-A-026", T_BASIC, "Least whole-number speed to meet a deadline after a slow start", "Medium",
  "Casework/optimisation",
  r"Rohan has to cover $100$ km in at most $2$ hours. He drives the first $30$ km at a constant $45$ km/h. He will drive the remaining distance at a constant speed that is a whole number of km/h. What is the least such speed, in km/h, that gets him to his destination within the $2$ hours?",
  "TITA",
  r"The first $30$ km take $\frac{2}{3}$ hour, leaving $\frac{4}{3}$ hours for $70$ km. He needs $v \ge 70 \div \frac{4}{3} = 52.5$ km/h, so the least whole-number speed is $53$ km/h.",
  "Rounding $52.5$ down, or averaging speeds instead of working with time.",
  "C08A-minimum-speed-deadline", "Inequality from remaining time plus an integer rounding decision.",
  tita_answer=53, check=_c26,
  tita_traps=[(52, r"Rounds $52.5$ down, which would arrive late."),
              (55, r"Needs an average of $50$ and solves $\frac{45 + v}{2} = 50$.")],
  cognitive="Application")


def _c27():
    a, b, t1, t2 = symbols('a b t1 t2', positive=True)
    # PQ = 40 t1, QR = 60 t2, average 45
    r = solve(Eq((40 * t1 + 60 * t2) / (t1 + t2), 45), t1)[0]
    return simplify(40 * r / (60 * t2))
q("C08-A-027", T_AVG, "Ratio of two leg lengths from an overall average speed", "Medium",
  "Conceptual/application",
  r"Arjun drove from P to Q at a constant $40$ km/h and then from Q to R at a constant $60$ km/h. His average speed for the whole journey from P to R was $45$ km/h. What is the ratio of the distance PQ to the distance QR?",
  "MCQ",
  r"An overall average speed is a time-weighted mean, so times are in the ratio $(60 - 45) : (45 - 40) = 3 : 1$. Distances are $40 \times 3 : 60 \times 1 = 120 : 60 = 2 : 1$.",
  "Stopping at the time ratio, or applying alligation the wrong way round.",
  "C08A-alligation-average-speed", "Recognising that alligation on speeds gives a time ratio, then converting to distances.",
  correct=r"$2 : 1$",
  distractors=[(r"$3 : 1$", r"Stops at the time ratio $3 : 1$ from alligation."),
               (r"$1 : 2$", r"Inverts the correct distance ratio."),
               (r"$2 : 9$", r"Takes the times as $1 : 3$ and then distances $40 : 180$.")],
  check=_c27, values=[2, 3, F(1, 2), F(2, 9)], cognitive="Analysis")


def _c28():
    r = symbols('r', positive=True)
    rem = solve(Eq((40 + r) / (1 + r / 60), 55), r)[0]
    return 40 + rem
q("C08-A-028", T_AVG, "Total distance from the first hour's speed, later speed and overall average", "Medium",
  "Inverse/parameter",
  r"Joseph drove from Rampur to Sitapur. For the first hour he drove at a constant $40$ km/h, and for the rest of the way at a constant $60$ km/h. His average speed for the whole trip was $55$ km/h. What is the distance from Rampur to Sitapur?",
  "MCQ",
  r"By alligation on time, $t_1 : t_2 = (60 - 55) : (55 - 40) = 1 : 3$. With $t_1 = 1$ hour, $t_2 = 3$ hours, so the distance is $40 + 3 \times 60 = 220$ km. (Check: $220 \div 4 = 55$.)",
  "Applying the alligation ratio to distances, or reversing it.",
  "C08A-alligation-average-speed", "Alligation on time with one leg fixed by time, not distance.",
  correct=r"$220$ km",
  distractors=[(r"$180$ km", r"Reports only the stretch driven at $60$ km/h."),
               (r"$160$ km", r"Applies the ratio $1 : 3$ to distances: $40 + 3 \times 40 = 160$."),
               (r"$60$ km", r"Reverses the ratio to $3 : 1$: $t_2 = \frac{1}{3}$ hour, so $40 + 20 = 60$.")],
  check=_c28, values=[220, 180, 160, 60], cognitive="Application", exams=CX)


def _c29():
    T = symbols('T', positive=True)
    t = solve(Eq(T - T / Rational(6, 5), 15), T)[0]
    return t / Rational(4, 5) - t
q("C08-A-029", T_LATE, "Early by a fixed time at a higher speed; lateness at a lower speed", "Medium",
  "Conceptual/application",
  r"If Harpreet drives $20\%$ faster than her usual speed, she reaches her destination $15$ minutes earlier than usual. If she instead drives $20\%$ slower than her usual speed, how many minutes later than usual will she reach?",
  "MCQ",
  r"At $\frac{6}{5}$ speed the time is $\frac{5}{6}T$, so $\frac{T}{6} = 15$ and $T = 90$ minutes. At $\frac{4}{5}$ speed the time is $\frac{5}{4}T$, an extra $\frac{T}{4} = 22.5$ minutes.",
  "Assuming equal and opposite percentage changes in speed give equal and opposite changes in time.",
  "C08A-percent-speed-change", "Inverse proportion in both directions; symmetry trap.",
  correct=r"$22.5$ minutes",
  distractors=[(r"$15$ minutes", r"Assumes a $20\%$ fall in speed costs exactly what a $20\%$ rise saved."),
               (r"$18$ minutes", r"Finds $T = 90$ correctly but then takes $20\%$ of it as the delay."),
               (r"$18.75$ minutes", r"Takes the saving as $20\%$ of $T$, so $T = 75$, then the delay as $25\%$ of $75$.")],
  check=_c29, values=[F(45, 2), 15, 18, F(75, 4)], cognitive="Application")


def _c30():
    T = symbols('T', positive=True)
    # leaves 10 late, arrives 2 early: walking time T*4/5 = T - 12
    return solve(Eq(T * Rational(4, 5), T - 12), T)[0]
q("C08-A-030", T_LATE, "Late start made up by walking faster; find the usual time", "Medium",
  "Multi-step word problem",
  r"One morning Ananya leaves home $10$ minutes later than usual and walks to school $25\%$ faster than her usual speed. She reaches school $2$ minutes earlier than usual. How many minutes does her usual walk take?",
  "MCQ",
  r"Her walk that day was $10 + 2 = 12$ minutes shorter than usual. At $\frac{5}{4}$ speed it takes $\frac{4}{5}T$, so $\frac{T}{5} = 12$ and $T = 60$ minutes.",
  r"Ignoring one of the two margins, or treating a $25\%$ speed rise as a $25\%$ time cut.",
  "C08A-late-start-make-up", "Combine the late start and early arrival, then inverse proportion.",
  correct=r"$60$ minutes",
  distractors=[(r"$48$ minutes", r"Writes the saving as $\frac{T}{4} = 12$ (a $25\%$ time cut), or reports that day's walk."),
               (r"$50$ minutes", r"Ignores the $2$ minutes early: $\frac{T}{5} = 10$."),
               (r"$40$ minutes", r"Subtracts the margins: $\frac{T}{5} = 10 - 2$.")],
  check=_c30, values=[60, 48, 50, 40], cognitive="Application")


def _c31():
    T = symbols('T', positive=True)
    trip = (T / 2) / Rational(6, 5) + (T / 2) / Rational(3, 2)
    return solve(Eq(T - trip, 12), T)[0]
q("C08-A-031", T_LATE, "Late start made up at two different higher speeds on the two halves", "Medium",
  "Multi-step word problem",
  r"One day Kabir leaves home $12$ minutes later than usual. He drives the first half of the distance at $\frac{6}{5}$ of his usual speed and the second half at $\frac{3}{2}$ of his usual speed, and reaches exactly at his usual time. How many minutes does his journey usually take?",
  "MCQ",
  r"Let the usual time be $T$. The halves now take $\frac{T}{2} \times \frac{5}{6} = \frac{5T}{12}$ and $\frac{T}{2} \times \frac{2}{3} = \frac{T}{3}$, total $\frac{3T}{4}$. The saving $\frac{T}{4} = 12$ gives $T = 48$ minutes.",
  "Applying each saving to the whole journey, or reporting the shortened trip time.",
  "C08A-late-start-make-up", "Two separate inverse-proportion savings on half journeys.",
  correct=r"$48$ minutes",
  distractors=[(r"$36$ minutes", r"Reports the time taken that day, $\frac{3T}{4}$."),
               (r"$24$ minutes", r"Applies each saving to the whole journey: $\frac{T}{6} + \frac{T}{3} = 12$."),
               (r"$72$ minutes", r"Counts only the second half's saving: $\frac{T}{2} \times \frac{1}{3} = 12$.")],
  check=_c31, values=[48, 36, 24, 72], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (9)

def _c32():
    v, D = symbols('v D', positive=True)
    extra = lambda R: R / (v * Rational(3, 5)) - R / v
    sol = solve([Eq(extra(D - v), 2), Eq(extra(D - v - 50), Rational(4, 3))], [v, D], dict=True)
    return sol[0][D]
q("C08-A-032", T_LATE, "Speed drop after a fault; two scenarios give speed and distance", "Difficult",
  "Multi-step word problem",
  r"A car leaves town P for town Q at a constant speed. One hour after starting, an engine fault forces it to continue at $\frac{3}{5}$ of its original speed, and it reaches Q $2$ hours later than it would have at its original speed throughout. Had the fault occurred $50$ km farther along the road, the car would have reached Q only $1$ hour $20$ minutes later than it would have at its original speed throughout. What is the distance from P to Q?",
  "MCQ",
  r"At $\frac{3}{5}$ speed every km takes $\frac{5}{3}$ of the normal time, so the delay is $\frac{2}{3}$ of the normal time for the stretch after the fault. Moving the fault $50$ km on cuts the delay by $40$ minutes, so $\frac{2}{3} \times \frac{50}{v} = \frac{2}{3}$ and $v = 50$ km/h. In the first case $\frac{2}{3} \times \frac{D - 50}{50} = 2$, so $D - 50 = 150$ and $D = 200$ km.",
  "Using the speed fraction for the delay, or comparing full times instead of delays.",
  "C08A-breakdown-two-scenarios", "Two scenarios, delay proportional to affected distance, then back to total distance.",
  correct=r"$200$ km",
  distractors=[(r"$150$ km", r"Finds the distance after the fault, $150$ km, and omits the first hour's $50$ km."),
               (r"$180$ km", r"Takes the delay as $\frac{2}{5}$ of the normal time: $\frac{2}{5} \times \frac{50}{v} = \frac{2}{3}$ gives $v = 30$, then $D = 30 + 150 = 180$."),
               (r"$300$ km", r"Equates the $40$ minute difference to the normal time for $50$ km: $v = 75$, then $D = 4v = 300$.")],
  check=_c32, values=[200, 150, 180, 300], cognitive="Analysis", exams=CX)


def _c33():
    d, v = symbols('d v', positive=True)
    sol = solve([Eq(d / v - d / (v + 10), Rational(1, 2)), Eq(d / (v - 10) - d / v, Rational(3, 4))], [d, v], dict=True)
    return [s[d] for s in sol if s[v] > 10][0]
q("C08-A-033", T_BASIC, "Distance from two hypothetical speed changes of the same size", "Difficult",
  "Multi-step word problem",
  r"Fatima drove from her home to a hill station at a constant speed. Had her speed been $10$ km/h more, she would have taken $30$ minutes less; had it been $10$ km/h less, she would have taken $45$ minutes more. How many kilometres did she drive?",
  "TITA",
  r"With distance $d$ and speed $v$: $\frac{10d}{v(v + 10)} = \frac{1}{2}$ and $\frac{10d}{v(v - 10)} = \frac{3}{4}$. Dividing, $\frac{v + 10}{v - 10} = \frac{3}{2}$, so $v = 50$. Then $\frac{10d}{50 \times 60} = \frac{1}{2}$ gives $d = 150$ km. (Check: $3$ hours, $2.5$ hours, $3.75$ hours.)",
  "Reporting the speed, or writing minutes as decimal hours.",
  "C08A-two-speed-changes", "Two nonlinear equations; dividing them to eliminate $d$ is the key step.",
  tita_answer=150, check=_c33,
  tita_traps=[(50, r"Stops at the speed $50$ km/h."),
              (90, r"Writes $30$ minutes as $0.3$ hour and $45$ minutes as $0.45$ hour: the ratio is still $\frac{3}{2}$, so $v = 50$, but $\frac{10d}{3000} = 0.3$ gives $d = 90$.")],
  cognitive="Analysis", exams=CX)


def _c34():
    d = symbols('d', positive=True)
    dist = solve(Eq(d / 5 - d / 6, Rational(7 + 5, 60)), d)[0]
    on_time = dist / 5 - Rational(7, 60)
    x = symbols('x', positive=True)
    return solve(Eq(x / 6 + (dist - x) / 5, on_time), x)[0] * 1000
q("C08-A-034", T_LATE, "Split a walk between two speeds to arrive exactly on time", "Difficult",
  "Inverse/parameter",
  r"Every day Kabir leaves home at the same time and walks to a bus stop to catch a bus that leaves at a fixed time. Walking at a constant $5$ km/h he arrives $7$ minutes after the bus has left; walking at a constant $6$ km/h he arrives $5$ minutes before it leaves. One day he walks part of the way at $6$ km/h and the rest at $5$ km/h, and arrives exactly when the bus leaves. How many metres did he walk at $6$ km/h?",
  "TITA",
  r"The two walk times differ by $12$ minutes: $\frac{d}{5} - \frac{d}{6} = \frac{d}{30} = \frac{1}{5}$, so $d = 6$ km. At $5$ km/h he takes $72$ minutes, so the on-time walk is $65$ minutes. With $x$ km at $6$ km/h: $\frac{x}{6} + \frac{6 - x}{5} = \frac{65}{60}$, so $\frac{36 - x}{30} = \frac{13}{12}$ and $x = 3.5$ km $= 3500$ m.",
  "Assigning the larger share to the slower speed, or splitting the distance equally.",
  "C08A-split-journey-on-time", "Three stages: distance, on-time duration, then the split; units change to metres.",
  tita_answer=3500, check=_c34,
  tita_traps=[(2500, r"Reports the stretch walked at $5$ km/h."),
              (3000, r"Splits the distance equally, as if the late and early margins were equal.")],
  cognitive="Analysis", exams=CX)


def _c35():
    # simulate interval by interval in exact arithmetic: speed changes every 30 minutes
    target, covered, t, speed = F(338), F(0), F(0), F(30)
    step = F(1, 2)                                   # hours per interval
    while covered + speed * step <= target:
        covered += speed * step
        t += step
        speed += 4
    t += (target - covered) / speed
    return t * 60
q("C08-A-035", T_BASIC, "Speed rising by a fixed amount every half hour; time for a given distance", "Difficult",
  "Multi-step word problem",
  r"During a rally, a car travels at a constant $30$ km/h for the first half hour. In each later half hour it travels at a constant speed that is $4$ km/h more than its speed in the previous half hour. How many minutes does it take to cover the first $338$ km?",
  "TITA",
  r"In the $k$th half hour the speed is $30 + 4(k - 1)$ km/h, so the distance is $15 + 2(k - 1)$ km: $15, 17, 19, \dots$. After $n$ half hours the distance is $15n + n(n - 1)$; after $12$ half hours it is $180 + 132 = 312$ km, and a full $13$th half hour would add $39$ km, which overshoots. In the $13$th half hour the speed is $78$ km/h, so the last $26$ km take $\frac{26}{78} = \frac{1}{3}$ hour $= 20$ minutes. Total $6$ hours $20$ minutes $= 380$ minutes.",
  "Adding the speeds as if each were covered for a full hour, or rounding up to a whole number of half hours.",
  "C08A-speed-changing-each-hour", "Speeds must be halved into half-hour distances, the progression summed, the partial interval located and its fraction converted to minutes.",
  tita_answer=380, check=_c35,
  tita_traps=[(390, r"Rounds up to $13$ full half hours."),
              (360, r"Stops after $12$ full half hours and ignores the last $26$ km.")],
  cognitive="Analysis", exams=CX)


def _c36():
    d, u, v = symbols('d u v', positive=True)
    sol = solve([Eq(v, u + 8), Eq(2 * u * v / (u + v), 15), Eq(d / u - d / v, Rational(20, 60))], [d, u, v], dict=True)
    assert len(sol) == 1
    return sol[0][d]
q("C08-A-036", T_AVG, "Round trip: both speeds from their difference and the average, then the distance", "Difficult",
  "Inverse/parameter",
  r"Sneha cycled from her village to a market at a constant speed and returned along the same road at a constant speed that was $8$ km/h higher. Her average speed for the round trip was $15$ km/h, and the return trip took $20$ minutes less than the outward trip. How far is the market from her village?",
  "MCQ",
  r"With outward speed $u$, the equal-distance average gives $\frac{2u(u + 8)}{2u + 8} = 15$, so $u(u + 8) = 15(u + 4)$, that is $u^2 - 7u - 60 = 0 = (u - 12)(u + 5)$, and $u = 12$ km/h, return $20$ km/h. Then $\frac{d}{12} - \frac{d}{20} = \frac{d}{30} = \frac{1}{3}$, so $d = 10$ km. (Check: $50$ minutes out, $30$ minutes back, $20$ km in $\frac{4}{3}$ hours is $15$ km/h.)",
  "Confusing the one-way and round-trip distance, or slipping on minutes.",
  "C08A-round-trip-unknown-return", "Three conditions: a quadratic from the reversed harmonic mean, then a time-difference equation; one-way versus round-trip distance is an easy slip.",
  correct=r"$10$ km",
  distractors=[(r"$5$ km", r"Solves $\frac{d}{12} - \frac{d}{20} = \frac{1}{3}$ correctly for $10$, then takes $10$ km as the round-trip distance and halves it."),
               (r"$6$ km", r"Finds $12$ and $20$ km/h correctly but writes $20$ minutes as $0.2$ hour: $\frac{d}{30} = 0.2$."),
               (r"$20$ km", r"Reports the round-trip distance.")],
  check=_c36, values=[10, 5, 6, 20], cognitive="Analysis", exams=CX)


def _c37():
    d, v = symbols('d v', positive=True)
    sol = solve([Eq(d / v - d / (v + 10), Rational(24, 60)), Eq(d / v - d / (v + 20), Rational(40, 60))], [d, v], dict=True)[0]
    return 10 * 60 - sol[d] / sol[v] * 60     # minutes after midnight
q("C08-A-037", T_LATE, "Departure time from arrival times at three speeds", "Difficult",
  "Multi-step word problem",
  r"Harpreet leaves home at the same time every day and drives to her office at a constant speed, arriving at $10{:}00$ am. Had her speed been $10$ km/h more she would have arrived at $9{:}36$ am, and had it been $20$ km/h more she would have arrived at $9{:}20$ am. At what time does she leave home?",
  "MCQ",
  r"Time saved: $\frac{10d}{v(v + 10)} = \frac{2}{5}$ and $\frac{20d}{v(v + 20)} = \frac{2}{3}$. Dividing, $\frac{v + 20}{2(v + 10)} = \frac{3}{5}$, so $v = 40$ km/h, and then $\frac{10d}{40 \times 50} = \frac{2}{5}$ gives $d = 80$ km. The trip takes $2$ hours, so she leaves at $8{:}00$ am.",
  "Writing minutes as decimal hours, or subtracting the wrong trip duration from $10{:}00$ am.",
  "C08A-two-speed-changes", "Two equations from three scenarios, ratio to find speed, then distance and duration.",
  correct=r"$8{:}00$ am",
  distractors=[(r"$8{:}48$ am", r"Writes $24$ minutes as $0.24$ hour: $v = 40$ still, but $d = 48$ km and the trip takes $1.2$ hours."),
               (r"$8{:}24$ am", r"Subtracts the trip time at $50$ km/h, $1$ hour $36$ minutes, from $10{:}00$ am."),
               (r"$8{:}40$ am", r"Subtracts the trip time at $60$ km/h, $1$ hour $20$ minutes, from $10{:}00$ am.")],
  check=_c37, values=[480, 528, 504, 520], cognitive="Analysis", exams=CX)


def _c38():
    L, D = symbols('L D', positive=True)
    sol = solve(Eq(2 * L / 15 + (D - L) / 10 + (D - L) / 30, 3), D)[0]
    sol = simplify(sol)
    assert sol.free_symbols == set()
    return sol
q("C08-A-038", T_AVG, "Level and hilly road where the hill round trip averages the level speed", "Difficult",
  "Conceptual/application",
  r"Fatima cycles from her house to a lake and back along the same road. The first part of the road is level and the rest climbs steadily uphill all the way to the lake. She rides at a constant $15$ km/h on level ground, $10$ km/h uphill and $30$ km/h downhill. The round trip takes her $3$ hours of riding. How far is the lake from her house?",
  "MCQ",
  r"A hill stretch of $h$ km ridden up and down takes $\frac{h}{10} + \frac{h}{30} = \frac{2h}{15}$ hours, exactly as if ridden both ways at $15$ km/h. So the whole round trip behaves like $2D$ km at $15$ km/h: $\frac{2D}{15} = 3$ and $D = 22.5$ km, whatever the split between level and hill.",
  "Believing the split between level and hill is needed, or averaging uphill and downhill speeds arithmetically.",
  "C08A-uphill-downhill", "Insight that the harmonic mean of $10$ and $30$ equals the level speed; looks under-determined.",
  correct=r"$22.5$ km",
  distractors=[(r"$45$ km", r"Reports the round-trip distance $2D$."),
               (r"$30$ km", r"Uses the mean $20$ km/h of uphill and downhill speeds for the whole trip: $\frac{2D}{20} = 3$."),
               (r"$27.5$ km", r"Uses the mean of all three speeds, $\frac{55}{3}$ km/h: $2D = 55$.")],
  check=_c38, values=[F(45, 2), 45, 30, F(55, 2)], cognitive="Analysis", exams=CX)


def _c39():
    d = symbols('d', positive=True)
    # Mon: leave 7:20, speed 4, arrive S+5. Tue: leave 7:28, speed 6, arrive S-2 (minutes)
    dist = solve(Eq((440 + d / 4 * 60) - (448 + d / 6 * 60), 5 + 2), d)[0]
    return 440 + dist / 4 * 60 - 5
q("C08-A-039", T_LATE, "Late and early arrival with different departure times; find the start time", "Difficult",
  "Multi-step word problem",
  r"Ravi walks to school. On Monday he leaves home at $7{:}20$ am, walks at a constant $4$ km/h and reaches school $5$ minutes after it starts. On Tuesday he leaves home $8$ minutes later than on Monday, walks at a constant $6$ km/h and reaches $2$ minutes before school starts. At what time does school start?",
  "MCQ",
  r"Tuesday's arrival is $7$ minutes earlier than Monday's although he left $8$ minutes later, so Tuesday's walk is $15$ minutes shorter: $\frac{d}{4} - \frac{d}{6} = \frac{d}{12} = \frac{1}{4}$, giving $d = 3$ km. Monday's walk takes $45$ minutes, so he arrives at $8{:}05$ am and school starts at $8{:}00$ am. (Tuesday: $7{:}28$ am plus $30$ minutes is $7{:}58$ am.)",
  "Ignoring the later departure when comparing the two walking times.",
  "C08A-late-early-different-departures", "Must combine the departure shift with both margins before finding distance, then convert back to clock time.",
  correct=r"$8{:}00$ am",
  distractors=[(r"$7{:}36$ am", r"Ignores the later start: $\frac{d}{12} = \frac{7}{60}$, $d = 1.4$ km, a $21$ minute walk, arrival $7{:}41$ am."),
               (r"$7{:}48$ am", r"Uses $5 - 2 + 8 = 11$ minutes: $d = 2.2$ km, a $33$ minute walk, arrival $7{:}53$ am."),
               (r"$7{:}30$ am", r"Uses $8 - 5 + 2 = 5$ minutes: $d = 1$ km, a $15$ minute walk, arrival $7{:}35$ am.")],
  check=_c39, values=[480, 456, 468, 450], cognitive="Analysis", exams=CX)


def _c40():
    start = 8 * 60
    plans = []
    plans.append(start + F(60, 15) * 60)                          # cycle all the way
    plans.append(9 * 60 + F(60, 40) * 60)                         # bus from P at 9:00
    reach_R = start + F(20, 15) * 60                               # cycle to R
    for dep in (9 * 60 + 25, 10 * 60 + 25):
        if dep >= reach_R:
            plans.append(dep + F(40, 60) * 60)
            break
    bus_at_R = 9 * 60 + F(20, 40) * 60                             # bus to R, then shuttle
    for dep in (9 * 60 + 25, 10 * 60 + 25):
        if dep >= bus_at_R:
            plans.append(dep + F(40, 60) * 60)
            break
    return min(plans)
q("C08-A-040", T_BASIC, "Earliest arrival by comparing cycle, bus and shuttle plans", "Difficult",
  "Casework/optimisation",
  r"Kabir is at town P at $8{:}00$ am and wants to reach town Q, $60$ km away along a straight road, as early as possible. He can cycle at a constant $15$ km/h. A bus leaves P at $9{:}00$ am and runs to Q at a constant $40$ km/h, picking up passengers only at P; passengers may get off at junction R on the same road, $20$ km from P. From R, a shuttle leaves for Q at $9{:}25$ am and at $10{:}25$ am, running at a constant $60$ km/h. Ignore time spent boarding or changing. What is the earliest time at which Kabir can reach Q?",
  "MCQ",
  r"Cycling all the way takes $4$ hours: $12{:}00$ noon. The bus leaves at $9{:}00$ am and takes $1.5$ hours, reaching Q at $10{:}30$ am. Cycling to R takes $\frac{20}{15}$ hours $= 80$ minutes, reaching R at $9{:}20$ am, in time for the $9{:}25$ am shuttle, which covers $40$ km in $40$ minutes: $10{:}05$ am. Taking the bus to R reaches R at $9{:}30$ am, too late for that shuttle, so the next one would arrive at $11{:}05$ am. The earliest is $10{:}05$ am.",
  r"Forgetting the wait for the shuttle, or slipping on $\frac{4}{3}$ hours.",
  "C08A-route-choice-timetable", "Four plans to compare against a timetable; the best plan needs a wait and a precise time conversion.",
  correct=r"$10{:}05$ am",
  distractors=[(r"$10{:}00$ am", r"Assumes the shuttle leaves R the moment he arrives at $9{:}20$ am."),
               (r"$10{:}30$ am", r"Compares only cycling all the way and the bus."),
               (r"$11{:}05$ am", r"Writes $\frac{4}{3}$ hours as $1.33$ hours $= 1$ hour $33$ minutes, reaches R at $9{:}33$ am and takes the $10{:}25$ am shuttle.")],
  check=_c40, values=[605, 600, 630, 665], cognitive="Analysis", exams=CX)
