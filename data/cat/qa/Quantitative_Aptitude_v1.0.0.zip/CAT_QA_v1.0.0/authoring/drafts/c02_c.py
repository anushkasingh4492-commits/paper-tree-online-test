import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

DW = "Dishonest dealers and false weights"
CH = "Chains of sellers"
CX = ("CAT", "XAT")
F = Fraction


# ---------------------------------------------------------------- C02-C-001
def _c1():
    cost_per_kg = F(1)
    billed_kg = F(2)                  # one use of the false "2 kg" weight
    actual_kg = F(16, 10)
    revenue = billed_kg * cost_per_kg
    cost = actual_kg * cost_per_kg
    return (revenue - cost) / cost * 100
q("C02-C-001", DW, "Selling at cost price with a light weight; profit percentage", "Easy",
  "Single-step computation",
  r"Kabir, a grocer, charges each customer exactly his own cost price per kilogram of lentils. However, the weight he uses as a $2$ kg weight actually weighs only $1.6$ kg, and every sale is weighed in multiples of this weight. What is his profit as a percentage of his cost price (in $\%$)?",
  "TITA",
  r"For every $2$ kg he charges for, he hands over only $1.6$ kg. He is paid the cost of $2$ kg but spends the cost of $1.6$ kg, so profit $= \frac{2 - 1.6}{1.6} = \frac{0.4}{1.6} = \frac{1}{4} = 25\%$.",
  "Dividing the shortfall by the claimed weight instead of the weight actually given.",
  "C02C-short-weight-at-cp", "One idea (profit is the shortfall over the true weight) with one base trap.",
  tita_answer=25, check=_c1,
  tita_traps=[(20, "Divides the $0.4$ kg shortfall by the claimed $2$ kg instead of the $1.6$ kg actually given.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-002
def _c2():
    true_kg_cost = F(9000)            # cost of goods actually handed over (any price per kg works)
    p = F(30)                         # assumed cost per true kg
    true_kg = true_kg_cost / p
    billed_kg = true_kg * F(1000, 750)
    revenue = billed_kg * p
    return revenue - true_kg_cost
q("C02-C-002", DW, "Rupee profit for a day when selling at cost price with a light weight", "Easy",
  "Multi-step word problem",
  r"Sneha charges every customer her own cost price per kilogram of dry fruits, but the weight she uses as $1$ kg actually weighs $750$ g, and all sales are weighed with it. On one day the dry fruits she actually hands over cost her Rs. $9{,}000$. What is her profit for that day, in rupees?",
  "TITA",
  r"Each true $750$ g is billed as $1000$ g, so customers pay $\frac{1000}{750} = \frac{4}{3}$ times the cost of what they receive. Her collection is $\frac{4}{3} \times 9000 = 12000$ rupees, and her profit is $12000 - 9000 = 3000$ rupees.",
  r"Taking the shortfall $\frac{250}{1000} = 25\%$ of the cost as the profit.",
  "C02C-short-weight-at-cp", "Converts the false weight to a revenue factor and applies it to a rupee cost; one base trap.",
  tita_answer=3000, check=_c2,
  tita_traps=[(2250, r"Takes the $250$ g shortfall as $25\%$ of the true cost: $0.25 \times 9000$."),
              (12000, "Reports the day's collection instead of the profit.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-003
def _c3():
    c = F(1)
    revenue_per_billed_kg = c * F(110, 100)
    cost_per_billed_kg = c * F(900, 1000)
    return (revenue_per_billed_kg / cost_per_billed_kg - 1) * 100
q("C02-C-003", DW, "Markup on price combined with a short weight", "Easy",
  "Multi-step word problem",
  r"Harpreet sells rice at a price $10\%$ above his cost price per kilogram, but for every sale he uses a weight of $900$ g in place of $1$ kg. His actual profit percentage is",
  "MCQ",
  r"For each kilogram billed he receives $1.1$ times the cost of $1$ kg but gives goods costing $0.9$ times the cost of $1$ kg. So $\frac{\text{SP}}{\text{CP}} = \frac{1.1}{0.9} = \frac{11}{9}$, a profit of $\frac{2}{9} = 22\frac{2}{9}\%$.",
  "Adding the markup and the weight shortfall as if both were simple percentages.",
  "C02C-short-weight-with-markup", "Two factors combined multiplicatively; the trap is adding them.",
  correct=r"$22\frac{2}{9}\%$",
  distractors=[(r"$20\%$", r"Adds $10\%$ markup and the $10\%$ weight shortfall."),
               (r"$21\%$", r"Treats the $100$ g shortfall as a second $10\%$ markup: $1.1 \times 1.1 = 1.21$."),
               (r"$21\frac{1}{9}\%$", r"Finds the weight gain $\frac{100}{900} = 11\frac{1}{9}\%$ correctly but then adds the $10\%$ markup to it.")],
  check=_c3, values=[F(200, 9), 20, 21, F(190, 9)], cognitive="Application")


# ---------------------------------------------------------------- C02-C-004
def _c4():
    c = F(1)
    revenue = F(96, 100) * c           # per billed kg
    cost = F(800, 1000) * c            # goods handed over per billed kg
    return (revenue - cost) / cost * 100
q("C02-C-004", DW, "Advertised loss turned into profit by a light weight", "Medium",
  "Multi-step word problem",
  r"Joseph advertises that he sells sugar at $4\%$ below his cost price, and he does charge that price per kilogram. However, he weighs every sale with a weight that is marked $1$ kg but actually weighs $800$ g. What is his actual profit as a percentage of his cost price (in $\%$)?",
  "TITA",
  r"Per kilogram billed he receives $0.96$ times the cost of $1$ kg and hands over goods costing $0.8$ times the cost of $1$ kg. So $\frac{\text{SP}}{\text{CP}} = \frac{0.96}{0.8} = 1.2$, a profit of $20\%$.",
  "Combining the advertised loss and the weight effect by addition.",
  "C02C-short-weight-with-markup", "A loss factor and a weight factor combined; two additive traps.",
  tita_answer=20, check=_c4,
  tita_traps=[(21, r"Takes the weight gain as $\frac{1000}{800} = 25\%$ and subtracts the $4\%$ price cut."),
              (16, r"Takes the $200$ g shortfall as a $20\%$ gain and subtracts the $4\%$ price cut.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-005
def _c5():
    price = F(1)
    paid_for = F(100)                  # kg paid for
    received = paid_for * F(1200, 1000)
    billed = received / F(800, 1000)   # every 800 g handed over is billed as 1 kg
    return (billed * price - paid_for * price) / (paid_for * price) * 100
q("C02-C-005", DW, "Heavy weight when buying, light weight when selling, same rate", "Medium",
  "Multi-step word problem",
  r"A grain trader uses two dishonest weights. When buying wheat from farmers, he receives $1{,}200$ g for every kilogram he pays for. When selling, he hands over only $800$ g for every kilogram he charges for. He buys and sells at the same price per kilogram. What is his profit percentage?",
  "MCQ",
  r"Paying for $1$ kg gets him $1.2$ kg. Selling $1.2$ kg in lots of $0.8$ kg lets him bill $\frac{1.2}{0.8} = 1.5$ kg. So he receives the price of $1.5$ kg for the price of $1$ kg: a profit of $50\%$.",
  "Adding or compounding the two percentages without converting the selling shortfall into a gain on the true quantity.",
  "C02C-cheat-buy-and-sell", "Two cheats on different sides combined; three tempting shortcuts.",
  correct=r"$50\%$",
  distractors=[(r"$40\%$", r"Adds the two $20\%$ figures."),
               (r"$44\%$", r"Treats the selling shortfall as another $20\%$ gain and compounds: $1.2 \times 1.2 = 1.44$."),
               (r"$25\%$", r"Accounts only for the selling weight, $\frac{1}{0.8} = 1.25$, ignoring the gain while buying.")],
  check=_c5, values=[50, 40, 44, 25], cognitive="Application")


# ---------------------------------------------------------------- C02-C-006
def _c6():
    buy_price = F(100)                 # per kg paid for
    paid_kg = F(10)
    true_kg = paid_kg * F(110, 100)
    declared_kg = true_kg * F(125, 100)
    sell_price = buy_price * F(96, 100)
    revenue = declared_kg * sell_price
    outlay = paid_kg * buy_price
    return (revenue - outlay) / outlay * 100
q("C02-C-006", DW, "Extra quantity when buying, overstated weight when selling, lower selling rate", "Medium",
  "Multi-step word problem",
  r"Fatima, a trader, cheats in two ways. While buying, she receives $10\%$ more goods than she pays for. While selling, she declares the weight of the goods to be $25\%$ more than their true weight and charges for the declared weight. Her selling price per declared kilogram is $4\%$ below her buying price per kilogram. What is her overall profit percentage?",
  "MCQ",
  r"Paying for $1$ kg gets $1.1$ kg, which she declares as $1.1 \times 1.25 = 1.375$ kg and sells at $0.96$ times her buying rate. Revenue $\div$ outlay $= 1.375 \times 0.96 = 1.32$, a profit of $32\%$.",
  "Adding and subtracting the three percentages instead of multiplying the factors.",
  "C02C-cheat-buy-and-sell", "Three factors (two cheats and a price cut) to combine multiplicatively.",
  correct=r"$32\%$",
  distractors=[(r"$31\%$", r"Adds and subtracts: $10 + 25 - 4$."),
               (r"$35\%$", r"Adds the two cheats, $10 + 25$, and ignores the $4\%$ lower selling rate."),
               (r"$20\%$", r"Ignores the buying cheat: $1.25 \times 0.96 = 1.2$.")],
  check=_c6, values=[32, 31, 35, 20], cognitive="Application")


# ---------------------------------------------------------------- C02-C-007
def _c7():
    p, w = symbols('p w', positive=True)
    # p = price per billed kg as a multiple of cost per kg; w = true kg in the present '1 kg'
    sol = solve([Eq(p / w, F(120, 100)), Eq(p / (w - F(100, 1000)), F(135, 100))], [p, w], dict=True)
    sol = [s for s in sol if 0 < s[w] <= 1]
    assert len(sol) == 1
    return (sol[0][p] - 1) * 100
q("C02-C-007", DW, "Price markup from the profits under two different false weights", "Difficult",
  "Inverse/parameter",
  r"Arjun sells rice at a fixed price per kilogram billed and weighs every sale with a false weight that he passes off as $1$ kg. His profit is $20\%$. If he kept the same price but used a false weight $100$ g lighter than his present one, his profit would be $35\%$. By what percentage is his price per kilogram above his cost price per kilogram (in $\%$)?",
  "TITA",
  r"Let his price be $p$ times his cost per kilogram and let his present weight be $w$ kg. The profit factor is $\frac{p}{w}$, so $p = 1.2w$ and $p = 1.35(w - 0.1)$. Then $1.2w = 1.35w - 0.135$, so $0.15w = 0.135$ and $w = 0.9$ kg. Hence $p = 1.2 \times 0.9 = 1.08$: his price is $8\%$ above cost.",
  "Taking the present weight as honest, or combining the price and weight effects by subtraction.",
  "C02C-weight-switch-two-scenarios", "Two scenarios give two equations in two unknowns (price factor and true weight) linked through a reciprocal; neither unknown is given directly.",
  tita_answer=8, check=_c7,
  tita_traps=[(20, r"Assumes his present weight is honest, so the whole $20\%$ profit comes from the price."),
              (10, r"Finds the $900$ g weight, then subtracts its $10\%$ shortfall from the $20\%$ profit instead of computing $1.2 \times 0.9$.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-008
def _c8():
    w = symbols('w', positive=True)
    # sells at 1.2 c per billed kg, gives w grams; profit 60%
    sol = solve(Eq(F(12, 10) * 1000 / w, F(16, 10)), w)
    return sol[0]
q("C02-C-008", DW, "Find the false weight from markup and overall profit", "Medium",
  "Inverse/parameter",
  r"Priya sells spices at a price $20\%$ above her cost price per kilogram. Because she uses a false weight for every sale, her overall profit is $60\%$. How many grams does her '$1$ kg' weight actually weigh?",
  "MCQ",
  r"Per kilogram billed she receives $1.2$ times the cost of $1$ kg. If the weight is $w$ g, she gives goods costing $\frac{w}{1000}$ of that. So $\frac{1.2 \times 1000}{w} = 1.6$, giving $w = \frac{1200}{1.6} = 750$ g.",
  "Subtracting percentages to get a weight shortfall, or reading the profit on the wrong base.",
  "C02C-find-false-weight", "Inverse use of the price-times-weight factor with a markup present.",
  correct=r"$750$ g",
  distractors=[(r"$600$ g", r"Takes the shortfall as $60 - 20 = 40\%$ of $1000$ g."),
               (r"$625$ g", r"Ignores the $20\%$ markup: $\frac{1000}{1.6}$."),
               (r"$480$ g", r"Reads the $60\%$ profit as a percentage of selling price, so revenue is $2.5$ times cost: $\frac{1200}{2.5}$.")],
  check=_c8, values=[750, 600, 625, 480], cognitive="Application")


# ---------------------------------------------------------------- C02-C-009
def _c9():
    w = symbols('w', positive=True)
    sol = solve(Eq(F(1000) / w, F(125, 100)), w)
    return sol[0]
q("C02-C-009", DW, "Weight of the false kilogram from the profit when selling at cost price", "Easy",
  "Inverse/parameter",
  r"Ananya charges her cost price per kilogram for sugar, yet she makes a profit of $25\%$ because the weight she uses as $1$ kg is light. How many grams does that weight actually weigh?",
  "TITA",
  r"She is paid for $1000$ g but gives $w$ g, so $\frac{1000}{w} = 1.25$ and $w = 800$ g.",
  r"Reducing $1000$ g by the profit percentage instead of dividing by the profit factor.",
  "C02C-find-false-weight", "One inverse step; the trap is the percentage base.",
  tita_answer=800, check=_c9,
  tita_traps=[(750, r"Reduces $1000$ g by $25\%$."),
              (975, "Subtracts $25$ grams.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-010
def _c10():
    w = symbols('w', positive=True)
    sol = solve(Eq(F(84, 100) * 1000 / w, F(120, 100)), w)
    return sol[0]
q("C02-C-010", DW, "Find the false weight when an advertised loss becomes a profit", "Medium",
  "Inverse/parameter",
  r"A cloth-dye dealer advertises that he sells at $16\%$ below his cost price per kilogram, and he does charge that price. However, he uses a false weight for every sale and actually makes a profit of $20\%$. How many grams does his '$1$ kg' weight actually weigh?",
  "MCQ",
  r"Per kilogram billed he receives $0.84$ times the cost of $1$ kg. With a $w$ g weight, $\frac{0.84 \times 1000}{w} = 1.2$, so $w = \frac{840}{1.2} = 700$ g.",
  "Adding the advertised loss and the profit to get a single shortfall percentage.",
  "C02C-find-false-weight", "Inverse problem where the price factor is below $1$; two plausible shortcuts.",
  correct=r"$700$ g",
  distractors=[(r"$640$ g", r"Adds $16\%$ and $20\%$ and takes $36\%$ off $1000$ g."),
               (r"$672$ g", r"Multiplies $0.84 \times 0.8$, treating the $20\%$ profit as a $20\%$ cut in weight."),
               (r"$800$ g", r"Ignores the advertised loss and takes $20\%$ off $1000$ g.")],
  check=_c10, values=[700, 640, 672, 800], cognitive="Application")


# ---------------------------------------------------------------- C02-C-011
def _c11():
    milk = F(100)                       # litres bought
    cost = milk * 1                     # Re 1 per litre
    mixture = milk + milk * F(20, 100)
    revenue = mixture * 1
    return (revenue - cost) / cost * 100
q("C02-C-011", DW, "Adding water and selling at the cost price of pure milk", "Easy",
  "Single-step computation",
  r"A milkman buys pure milk and adds water equal to $20\%$ of the volume of the milk. Water costs him nothing. He sells the mixture at the cost price of pure milk per litre, using an honest measure. What is his profit as a percentage of his cost price (in $\%$)?",
  "TITA",
  r"Every $1$ litre of milk becomes $1.2$ litres of mixture, all sold at the cost of $1$ litre of milk. Revenue $\div$ cost $= 1.2$, a profit of $20\%$.",
  "Treating the water as a percentage of the mixture instead of the milk.",
  "C02C-adulteration-cheat", "One step once the base of the water percentage is read correctly.",
  tita_answer=20, check=_c11,
  tita_traps=[(25, r"Treats water as $20\%$ of the mixture, so milk is $80\%$ and profit is $\frac{1}{0.8} - 1$.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-012
def _c12():
    bag = F(100)                        # kg sold
    rice = bag * F(75, 100)
    c = F(40)                           # cost per kg of pure rice
    revenue = bag * c * F(90, 100)
    cost = rice * c
    return (revenue - cost) / cost * 100
q("C02-C-012", DW, "Worthless husk mixed in and sold below cost price per kilogram", "Medium",
  "Multi-step word problem",
  r"A rice trader mixes worthless husk into rice so that husk makes up $25\%$ of the weight of every bag he sells. The husk costs him nothing. He sells the bags at a price per kilogram $10\%$ below his cost price of pure rice per kilogram, using honest weights. What is his profit or loss percentage?",
  "MCQ",
  r"In every $1$ kg sold only $0.75$ kg is rice. He receives $0.9$ times the cost of $1$ kg of rice for goods that cost him $0.75$ of it. So $\frac{0.9}{0.75} = 1.2$, a profit of $20\%$.",
  "Mixing up the base of the husk percentage, or adding and subtracting percentages.",
  "C02C-adulteration-cheat", "The husk share is of the selling weight, not of the rice; a price factor below $1$ is combined with a quantity factor, and the base of the husk percentage is the trap.",
  correct=r"$20\%$ profit",
  distractors=[(r"$15\%$ profit", r"Adds and subtracts: $25 - 10$."),
               (r"$12\frac{1}{2}\%$ profit", r"Treats husk as $25\%$ of the rice, so $0.9 \times 1.25 = 1.125$."),
               (r"$33\frac{1}{3}\%$ profit", r"Ignores the $10\%$ lower price: $\frac{1}{0.75}$.")],
  check=_c12, values=[20, 15, F(25, 2), F(100, 3)], cognitive="Application")


# ---------------------------------------------------------------- C02-C-013
def _c13():
    c = F(1)                            # cost per litre of pure milk
    measured_litres = F(1000)
    mixture = measured_litres * F(960, 1000)
    milk = mixture / F(120, 100)
    revenue = measured_litres * c
    cost = milk * c
    return (revenue - cost) / cost * 100
q("C02-C-013", DW, "Water added and a short litre measure together", "Medium",
  "Multi-step word problem",
  r"A milk vendor adds water equal to $20\%$ of the volume of pure milk; water costs nothing. He sells the mixture at the cost price of pure milk per litre, but his '$1$ litre' measure actually holds only $960$ ml. What is his profit as a percentage of his cost price (in $\%$)?",
  "TITA",
  r"For each litre charged he hands over $0.96$ litre of mixture, of which milk is $\frac{0.96}{1.2} = 0.8$ litre. He is paid for $1$ litre of milk while giving $0.8$ litre, so profit $= \frac{1}{0.8} - 1 = 25\%$.",
  "Adding the water percentage and the measure shortfall.",
  "C02C-adulteration-cheat", "Two cheats on quantity combined; needs the milk content per measured litre.",
  tita_answer=25, check=_c13,
  tita_traps=[(24, r"Adds $20\%$ water and the $4\%$ short measure."),
              (20, "Ignores the short measure.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-014
def _c14():
    c = F(100)
    sp_per_billed_kg = c * F(150, 100) * F(90, 100)
    cost_per_billed_kg = c * F(750, 1000)
    return (sp_per_billed_kg / cost_per_billed_kg - 1) * 100
q("C02-C-014", DW, "Markup, discount and a short weight combined", "Medium",
  "Multi-step word problem",
  r"Kabir marks his tea $50\%$ above his cost price per kilogram and gives a $10\%$ discount on the marked price. He also uses a $750$ g weight in place of $1$ kg for every sale. What is his profit percentage?",
  "MCQ",
  r"Selling price per billed kilogram $= 1.5 \times 0.9 = 1.35$ times the cost of $1$ kg, while the goods handed over cost $0.75$ of it. So $\frac{1.35}{0.75} = 1.8$, a profit of $80\%$.",
  "Ignoring the weight, or adding and subtracting the percentages.",
  "C02C-markup-discount-false-weight", "Three factors, one of them below $1$, combined multiplicatively; ignoring the weight and adding percentages are the traps.",
  correct=r"$80\%$",
  distractors=[(r"$35\%$", r"Ignores the false weight: $1.5 \times 0.9 = 1.35$."),
               (r"$50\%$", "Ignores both the discount and the false weight."),
               (r"$65\%$", r"Adds and subtracts: $50 - 10 + 25$, taking the $250$ g shortfall as $25\%$.")],
  check=_c14, values=[80, 35, 50, 65], cognitive="Application")


# ---------------------------------------------------------------- C02-C-015
def _c15():
    m = symbols('m', positive=True)     # marked price factor
    # pays for 1 kg, gets 1.125 kg; sells 900 g per billed kg at m*0.75
    billed = F(1125, 1000) / F(900, 1000)
    sol = solve(Eq(billed * m * F(75, 100), F(150, 100)), m)
    return (sol[0] - 1) * 100
q("C02-C-015", DW, "Find the markup given discount, two dishonest weights and overall profit", "Difficult",
  "Inverse/parameter",
  r"Meera buys saffron using a dishonest weight that gives her $1{,}125$ g for every kilogram she pays for. She sells it with another dishonest weight, handing over $900$ g for every kilogram she charges for, and she gives a $25\%$ discount on her marked price per kilogram. Her overall profit is $50\%$. By what percentage above her buying price per kilogram is the saffron marked (in $\%$)?",
  "TITA",
  r"Paying for $1$ kg gives $1.125$ kg, which she bills as $\frac{1.125}{0.9} = 1.25$ kg. With marked price $m$ times her buying rate, she receives $1.25 \times 0.75m = 0.9375m$ for an outlay of $1$. So $0.9375m = 1.5$, $m = 1.6$: the saffron is marked $60\%$ above her buying price.",
  "Leaving out one of the two weights when building the equation.",
  "C02C-markup-discount-false-weight", "Four factors (two weights, discount, markup) with the markup unknown.",
  tita_answer=60, check=_c15,
  tita_traps=[(100, r"Ignores both weights: $\frac{1.5}{0.75} = 2$."),
              (80, r"Ignores the buying weight: $\frac{1.5}{0.75 \times \frac{10}{9}} = 1.8$.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-016
def _c16():
    rate = F(100)                       # buying price per kg
    paid = F(50)
    true_kg = paid * F(110, 100)
    billed = true_kg / F(800, 1000)
    sp = rate * F(140, 100) * F(80, 100)
    return (billed * sp - paid * rate) / (paid * rate) * 100
q("C02-C-016", DW, "Markup and discount with dishonest weights on both buying and selling", "Difficult",
  "Multi-step word problem",
  r"Joseph marks his goods $40\%$ above his buying price per kilogram and then gives a $20\%$ discount on the marked price. While buying, he receives $10\%$ more than the quantity he pays for. While selling, he hands over only $800$ g for every kilogram he charges for. What is his overall profit percentage?",
  "MCQ",
  r"Selling rate $= 1.4 \times 0.8 = 1.12$ times his buying rate. Paying for $1$ kg gives $1.1$ kg, billed as $\frac{1.1}{0.8} = 1.375$ kg. Revenue $\div$ outlay $= 1.375 \times 1.12 = 1.54$, a profit of $54\%$.",
  "Missing one factor, or adding percentages across stages.",
  "C02C-markup-discount-false-weight", "Four separate factors must all be identified and multiplied.",
  correct=r"$54\%$",
  distractors=[(r"$40\%$", r"Ignores the buying cheat: $1.12 \times 1.25 = 1.4$."),
               (r"$50\%$", r"Adds and subtracts every figure: $40 - 20 + 10 + 20$."),
               (r"$42\%$", r"Gets $12\%$ from markup and discount, then simply adds $10\%$ and $20\%$ for the two weights.")],
  check=_c16, values=[54, 40, 50, 42], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-017
def _c17():
    billed_false, billed_honest = F(1), F(1)
    given = billed_false * F(800, 1000) + billed_honest * 1
    revenue = billed_false + billed_honest
    return (revenue - given) / given * 100
q("C02-C-017", DW, "Overall profit when only half the billed quantity uses the false weight", "Medium",
  "Conceptual/application",
  r"Ravi charges his cost price per kilogram for cashews. For exactly half of all the kilograms he bills in a month, he weighs with a false weight that is marked $1$ kg but actually weighs $800$ g; the other half he weighs honestly. What is his overall profit percentage for the month?",
  "MCQ",
  r"Take $2$ billed kilograms: one is weighed falsely ($0.8$ kg given) and one honestly ($1$ kg given). He is paid for $2$ kg and hands over $1.8$ kg, so profit $= \frac{0.2}{1.8} = \frac{1}{9} = 11\frac{1}{9}\%$.",
  "Averaging the two profit percentages, which ignores that the bases differ.",
  "C02C-part-honest-part-false", "Weighted combination; the simple average is the trap.",
  correct=r"$11\frac{1}{9}\%$",
  distractors=[(r"$12\frac{1}{2}\%$", r"Averages $25\%$ and $0\%$."),
               (r"$10\%$", r"Averages the $20\%$ weight shortfall and $0\%$."),
               (r"$25\%$", "Uses the false-weight profit for the whole month.")],
  check=_c17, values=[F(100, 9), F(25, 2), 10, 25], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-018
def _c18():
    cost = 100 * 40
    billed_false = F(60) / F(800, 1000)
    revenue = billed_false * 45 + 40 * 42
    return revenue - cost
q("C02-C-018", DW, "Rupee profit when part of the stock is sold with a false weight", "Medium",
  "Multi-step word problem",
  r"Harpreet buys $100$ kg of onions at Rs. $40$ per kg. He sells $60$ kg of them (true weight) using a weight that is marked $1$ kg but actually weighs $800$ g, charging Rs. $45$ per kilogram billed. He sells the remaining $40$ kg with an honest weight at Rs. $42$ per kg. What is his total profit, in rupees?",
  "TITA",
  r"The $60$ true kilograms are billed as $\frac{60}{0.8} = 75$ kg, fetching $75 \times 45 = 3375$ rupees. The honest part fetches $40 \times 42 = 1680$ rupees. Total revenue $= 5055$ rupees against a cost of $4000$ rupees, so the profit is $1055$ rupees.",
  r"Billing the false-weight portion at its true weight, or scaling it by $1.2$ instead of dividing by $0.8$.",
  "C02C-part-honest-part-false", "Two sales channels, one needing conversion from true to billed weight.",
  tita_answer=1055, check=_c18,
  tita_traps=[(380, "Ignores the false weight and bills $60$ kg."),
              (920, r"Bills $60 \times 1.2 = 72$ kg instead of $\frac{60}{0.8} = 75$ kg.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-019
def _c19():
    # brute force over the fraction (in 1/100 steps) of true weight sold with the false weight
    for k in range(1, 100):
        a = F(k, 100)
        b = 1 - a
        revenue = a * F(1000, 750) + b
        if revenue == F(12, 10):
            return a
q("C02-C-019", DW, "Share of stock sold with a false weight from the overall profit", "Difficult",
  "Inverse/parameter",
  r"Imran always charges his cost price per kilogram. To some customers he sells using a weight that is marked $1$ kg but actually weighs $750$ g; to all other customers he sells using an honest weight. Over the season his overall profit is $20\%$. What fraction of the total true weight of goods he sold went out through the false weight?",
  "MCQ",
  r"Let a fraction $a$ of the true weight go through the false weight. That part is billed at $\frac{4}{3}$ times its true weight; the rest at its true weight. So $\frac{4}{3}a + (1 - a) = 1.2$, giving $\frac{a}{3} = 0.2$ and $a = \frac{3}{5}$. (By alligation of $33\frac{1}{3}\%$ and $0\%$ around $20\%$, the ratio is $20 : 13\frac{1}{3} = 3 : 2$.)",
  "Measuring the share on billed weight instead of true weight, or using the wrong profit figure for the false weight.",
  "C02C-part-honest-part-false", "Inverse weighted average with a choice of base (true or billed weight).",
  correct=r"$\frac{3}{5}$",
  distractors=[(r"$\frac{2}{3}$", r"Gives the false weight's share of the billed weight: $\frac{4}{3} \times \frac{3}{5} = \frac{4}{5}$ billed falsely against $\frac{2}{5}$ billed honestly, that is $\frac{2}{3}$."),
               (r"$\frac{4}{5}$", r"Takes the false-weight profit as $25\%$ and alligates $25\%$ and $0\%$ around $20\%$: $20 : 5$."),
               (r"$\frac{2}{5}$", "Reports the share sold with the honest weight.")],
  check=_c19, values=[F(3, 5), F(2, 3), F(4, 5), F(2, 5)], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-020
def _c20():
    schemes = [(F(112, 100), 920), (F(120, 100), 1000), (F(1), 825), (F(115, 100), 950)]
    profits = [(p * 1000 / w - 1) * 100 for p, w in schemes]
    best = max(profits)
    assert profits.index(best) == 0
    return best
q("C02-C-020", DW, "Ranking four pricing and weighing schemes by profit percentage", "Medium",
  "Casework/optimisation",
  r"Four grocers sell the same rice, each buying at the same cost price per kilogram. Each one prices per kilogram billed and weighs every sale as described below. Which grocer makes the highest percentage profit?",
  "MCQ",
  r"Profit factor $= \frac{\text{price factor} \times 1000}{\text{grams given}}$. The four schemes give $\frac{1.12}{0.92} \approx 1.2174$, $\frac{1.2}{1} = 1.2$, $\frac{1}{0.825} \approx 1.2121$ and $\frac{1.15}{0.95} \approx 1.2105$. The highest is $12\%$ above cost with a $920$ g weight, a profit of $\frac{20}{92} = 21\frac{17}{23}\%$.",
  "Ranking the schemes by the size of the markup or of the weight shortfall alone instead of by the combined factor.",
  "C02C-compare-schemes", "Four close cases; the near-equal profits can be ranked only by exact division, not by estimation.",
  correct=r"Prices at $12\%$ above cost and uses a $920$ g weight for $1$ kg",
  distractors=[(r"Prices at $20\%$ above cost and uses an honest $1$ kg weight", r"Distrusts the cheating schemes and assumes an honest $20\%$ markup is at least as good; true profit $20\%$."),
               (r"Prices at cost and uses an $825$ g weight for $1$ kg", r"Judges by the largest weight shortfall, $175$ g; true profit $21\frac{7}{33}\%$."),
               (r"Prices at $15\%$ above cost and uses a $950$ g weight for $1$ kg", r"Judges by the largest markup among the cheating grocers; true profit $21\frac{1}{19}\%$.")],
  check=_c20, values=[F(500, 23), 20, F(1000, 825) * 100 - 100, F(115, 95) * 100 - 100], cognitive="Analysis")


# ---------------------------------------------------------------- C02-C-021
def _c21():
    per_pencil = F(1)
    boxes = 100
    revenue = boxes * 25 * per_pencil
    cost = boxes * 20 * per_pencil
    return (revenue - cost) / cost * 100
q("C02-C-021", DW, "Short-counted boxes sold at the cost of the full count", "Easy",
  "Single-step computation",
  r"A stationer packs pencils in boxes labelled '$25$ pencils' but puts only $20$ pencils in each box. He prices each box at exactly his cost of $25$ pencils. What is his profit as a percentage of his cost price (in $\%$)?",
  "TITA",
  r"He is paid for $25$ pencils and gives $20$, so profit $= \frac{25 - 20}{20} = 25\%$.",
  "Dividing the $5$ missing pencils by $25$ instead of $20$.",
  "C02C-count-short-packs", "One step; base of the percentage is the trap.",
  tita_answer=25, check=_c21,
  tita_traps=[(20, r"Divides $5$ by the labelled $25$ instead of the $20$ actually given.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-022
def _c22():
    p = F(120)                           # price paid per dozen
    dozens_paid = 4
    oranges = dozens_paid * 15
    cost = dozens_paid * p
    sale_dozens = F(oranges, 10)
    revenue = sale_dozens * p * F(96, 100)
    return (revenue - cost) / cost * 100
q("C02-C-022", DW, "Extra count when buying, short count when selling, lower selling rate", "Medium",
  "Multi-step word problem",
  r"A fruit seller pays a fixed price per dozen oranges, but each supplier gives him $15$ oranges for the price of a dozen. He sells oranges by the 'dozen', but each of his 'dozens' contains only $10$ oranges, and his price per 'dozen' is $4\%$ below the price per dozen he pays. What is his profit percentage?",
  "MCQ",
  r"Paying for one dozen gets $15$ oranges, which he sells as $\frac{15}{10} = 1.5$ 'dozens' at $0.96$ of his buying price per dozen. Revenue $\div$ outlay $= 1.5 \times 0.96 = 1.44$, a profit of $44\%$.",
  "Adding the percentages from the two counts and the price cut.",
  "C02C-count-short-packs", "Two count cheats and a price cut combined multiplicatively.",
  correct=r"$44\%$",
  distractors=[(r"$41\%$", r"Adds $25\%$ (buying) and $20\%$ (selling), then subtracts $4\%$."),
               (r"$50\%$", r"Ignores the $4\%$ lower price: $1.25 \times 1.2$."),
               (r"$45\%$", r"Adds $25\%$ and $20\%$ and ignores the price cut.")],
  check=_c22, values=[44, 41, 50, 45], cognitive="Application")


# ---------------------------------------------------------------- C02-C-023
def _c23():
    near, far = F(20), F(22)
    W = F(1)                              # standard weight used, kg
    bought = W * far / near               # goods on near pan balance W on far pan
    paid = W
    # sell 'bought' kg: each billed W uses goods W*near/far
    billed = bought / (W * near / far)
    return (billed * W - paid) / paid * 100
q("C02-C-023", DW, "Unequal-arm balance used one way when buying and the other way when selling", "Difficult",
  "Conceptual/application",
  r"A dealer's beam balance has its two pans hung at $20$ cm and $22$ cm from the pivot; the beam balances exactly when both pans are empty. When buying, he puts the goods in the pan nearer the pivot and the standard weights in the other pan. When selling, he puts the goods in the pan farther from the pivot and the standard weights in the other. He pays and charges the same price per kilogram shown by the standard weights. What is his profit as a percentage of his cost (in $\%$)?",
  "TITA",
  r"At balance, weight $\times$ arm length is equal on both sides. Buying: goods $\times 20 =$ weights $\times 22$, so he gets $1.1$ kg for each kilogram paid. Selling: goods $\times 22 =$ weights $\times 20$, so he gives $\frac{1}{1.1}$ kg for each kilogram charged, that is, he bills $1.1$ kg for every true kilogram. Overall factor $= 1.1 \times 1.1 = 1.21$, a profit of $21\%$.",
  "Adding the gains from the two sides of the trade, or counting the cheat on only one side.",
  "C02C-unequal-arm-balance", "Needs the lever principle to turn arm lengths into quantity factors, then compounding.",
  tita_answer=21, check=_c23,
  tita_traps=[(20, r"Adds the two $10\%$ gains."),
              (10, "Counts the gain on only one side of the trade.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-024
def _c24():
    charged = F(120)
    actual_kg = F(800, 1000)
    eff = charged / actual_kg
    return eff - 125
q("C02-C-024", DW, "Effective price per true kilogram compared with an honest shop", "Easy",
  "Conceptual/application",
  r"Honest shops sell groundnuts at Rs. $125$ per kg. Neha buys instead from a shop that charges Rs. $120$ per kilogram billed, but whose '$1$ kg' weight actually weighs $800$ g. Per kilogram of groundnuts she actually receives, how does her price compare with the honest shops' price?",
  "MCQ",
  r"She pays Rs. $120$ for $0.8$ kg, that is, $\frac{120}{0.8} = 150$ rupees per true kilogram. Compared with Rs. $125$, she pays Rs. $25$ more per kilogram.",
  "Comparing the billed prices directly, ignoring the short weight.",
  "C02C-effective-price-customer", "One conversion to price per true kilogram; the apparent saving is the trap.",
  correct=r"Rs. $25$ more",
  distractors=[(r"Rs. $5$ less", r"Compares Rs. $120$ with Rs. $125$ and ignores the short weight."),
               (r"Rs. $19$ more", r"Raises Rs. $120$ by $20\%$ to Rs. $144$ instead of dividing by $0.8$."),
               (r"Rs. $29$ less", r"Multiplies by $0.8$, getting Rs. $96$ per kilogram.")],
  check=_c24, values=[25, -5, 19, -29], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-025
def _c25():
    paid_kg = F(100)
    outlay = paid_kg * 36
    true_kg = paid_kg * F(1200, 1000)
    revenue = true_kg * 33
    return (revenue - outlay) / outlay * 100
q("C02-C-025", DW, "Heavy weight when buying, honest sale below the buying rate", "Easy",
  "Multi-step word problem",
  r"A trader pays farmers Rs. $36$ per kg for potatoes, but his buying scale is dishonest: for every kilogram he pays for, he actually receives $1{,}200$ g. He then sells the potatoes with an honest weight at Rs. $33$ per kg. What is his profit or loss percentage?",
  "MCQ",
  r"His true cost per kilogram is $\frac{36}{1.2} = 30$ rupees. Selling at Rs. $33$ per kg gives a profit of $\frac{3}{30} = 10\%$.",
  "Comparing the selling price with the nominal buying rate of Rs. $36$.",
  "C02C-heavy-weight-buying", "One conversion to true cost per kilogram; the nominal loss is the trap.",
  correct=r"A profit of $10\%$",
  distractors=[(r"A loss of $8\frac{1}{3}\%$", r"Ignores the buying weight: $\frac{33 - 36}{36}$."),
               (r"A profit of $11\frac{2}{3}\%$", r"Adds the $20\%$ extra quantity to the $8\frac{1}{3}\%$ apparent loss."),
               (r"A profit of $32\%$", r"Applies the $1.2$ factor twice: $\frac{33 \times 1.2}{30}$.")],
  check=_c25, values=[10, F(-25, 3), F(35, 3), 32], cognitive="Application")


# ---------------------------------------------------------------- C02-C-026
def _c26():
    x = symbols('x', positive=True)
    sol = solve(Eq(F(84, 100) * (1 + x) / (1 - x), F(140, 100)), x)
    return [s * 100 for s in sol if 0 < s < 1][0]
q("C02-C-026", DW, "Same cheating percentage on both sides; find it from the profit", "Difficult",
  "Inverse/parameter",
  r"A wholesaler cheats by the same percentage $x$ on both sides of his trade: when buying he receives $x\%$ more than the quantity he pays for, and when selling he hands over $x\%$ less than the quantity he charges for. His selling price per kilogram is $16\%$ below his buying price per kilogram, and his overall profit is $40\%$. What is the value of $x$?",
  "MCQ",
  r"Write $t = \frac{x}{100}$. Paying for $1$ kg gets $(1 + t)$ kg, which he bills as $\frac{1 + t}{1 - t}$ kg at $0.84$ of his buying rate. So $\frac{0.84(1 + t)}{1 - t} = 1.4$, that is, $\frac{1 + t}{1 - t} = \frac{5}{3}$. Then $3 + 3t = 5 - 5t$, so $t = \frac{1}{4}$ and $x = 25$.",
  "Splitting the profit equally between the two cheats by addition.",
  "C02C-cheat-buy-and-sell", "Unknown appears in numerator and denominator alongside a price cut; additive splitting gives tempting wrong values.",
  correct=r"$25$",
  distractors=[(r"$20$", r"Halves the $40\%$ profit, ignoring the price cut."),
               (r"$28$", r"Adds back the $16\%$ and halves: $\frac{40 + 16}{2}$."),
               (r"$12$", r"Subtracts the $16\%$ price cut from the $40\%$ profit and halves: $\frac{40 - 16}{2}$.")],
  check=_c26, values=[25, 20, 28, 12], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-027
def _c27():
    price = F(480)
    for pct in (20, 25, 20):
        price = price * (100 + pct) / 100
    return price
q("C02-C-027", CH, "Customer price after three successive profit margins", "Easy",
  "Multi-step word problem",
  r"A manufacturer makes a lamp at a cost of Rs. $480$ and sells it to a wholesaler at a profit of $20\%$. The wholesaler sells it to a retailer at a profit of $25\%$, and the retailer sells it to a customer at a profit of $20\%$. Each profit is on that seller's own cost. How much does the customer pay?",
  "MCQ",
  r"The price is multiplied at each stage: $480 \times 1.2 = 576$, then $576 \times 1.25 = 720$, then $720 \times 1.2 = 864$. The customer pays Rs. $864$.",
  "Adding the three percentages and applying the total to the manufacturing cost.",
  "C02C-chain-forward", "Three successive factors; additive trap.",
  correct=r"Rs. $864$",
  distractors=[(r"Rs. $792$", r"Adds $20 + 25 + 20 = 65\%$ to Rs. $480$."),
               (r"Rs. $1{,}000$", r"Treats each profit as a percentage of selling price: $\frac{480}{0.8 \times 0.75 \times 0.8}$."),
               (r"Rs. $720$", "Stops at the retailer's purchase price.")],
  check=_c27, values=[864, 792, 1000, 720], cognitive="Application")


# ---------------------------------------------------------------- C02-C-028
def _c28():
    m_sp = F(320) * F(125, 100)
    w_sp = m_sp * F(120, 100)
    r_sp = w_sp * F(125, 100)
    return r_sp - w_sp
q("C02-C-028", CH, "Retailer's rupee profit at the end of a chain", "Easy",
  "Multi-step word problem",
  r"A pressure cooker costs its manufacturer Rs. $320$ to make. The manufacturer sells it to a wholesaler at $25\%$ profit, the wholesaler sells it to a retailer at $20\%$ profit, and the retailer sells it to a customer at $25\%$ profit, each profit on that seller's own cost. How many rupees of profit does the retailer make on one cooker?",
  "MCQ",
  r"Manufacturer's price $= 320 \times 1.25 = 400$; wholesaler's price $= 400 \times 1.2 = 480$, which is the retailer's cost. Retailer's profit $= 25\%$ of $480 = 120$ rupees.",
  "Applying the retailer's percentage to the wrong base.",
  "C02C-chain-forward", "Two forward steps to find the retailer's cost, then one percentage.",
  correct=r"Rs. $120$",
  distractors=[(r"Rs. $80$", r"Takes $25\%$ of the manufacturing cost Rs. $320$."),
               (r"Rs. $150$", r"Takes $25\%$ of the customer's price Rs. $600$."),
               (r"Rs. $280$", r"Gives the total profit of the whole chain, $600 - 320$.")],
  check=_c28, values=[120, 80, 150, 280], cognitive="Application")


# ---------------------------------------------------------------- C02-C-029
def _c29():
    c = F(100)
    final = c * F(120, 100) * F(125, 100) * F(140, 100)
    return (final - c) / c * 100
q("C02-C-029", CH, "Overall percentage rise from production cost to customer price", "Easy",
  "Conceptual/application",
  r"A manufacturer, a wholesaler and a retailer make profits of $20\%$, $25\%$ and $40\%$ respectively, each on his own cost. By what percentage does the price paid by the final customer exceed the manufacturer's cost of production?",
  "MCQ",
  r"The successive factors multiply: $1.2 \times 1.25 \times 1.4 = 1.5 \times 1.4 = 2.1$. The customer pays $2.1$ times the production cost, which is $110\%$ more.",
  "Adding the percentages, or reporting the multiplier itself as the percentage.",
  "C02C-chain-forward", "One idea: margins compound; two common slips.",
  correct=r"$110\%$",
  distractors=[(r"$85\%$", r"Adds $20 + 25 + 40$."),
               (r"$210\%$", r"Reports the factor $2.1$ as $210\%$ instead of the increase."),
               (r"$90\%$", r"Compounds the first two to $50\%$ and then adds $40\%$.")],
  check=_c29, values=[110, 85, 210, 90], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-030
def _c30():
    c = symbols('c', positive=True)
    sol = solve(Eq(c * F(150, 100) * F(120, 100) * F(110, 100), 1980), c)
    return sol[0]
q("C02-C-030", CH, "Manufacturer's cost from the customer's price", "Easy",
  "Multi-step word problem",
  r"A customer pays Rs. $1{,}980$ for a mixer. The retailer made a profit of $10\%$, the wholesaler who supplied the retailer made $20\%$, and the manufacturer who supplied the wholesaler made $50\%$, each profit on that seller's own cost. What did the mixer cost the manufacturer to make?",
  "MCQ",
  r"Work backwards dividing by each factor: $\frac{1980}{1.1} = 1800$, $\frac{1800}{1.2} = 1500$, $\frac{1500}{1.5} = 1000$. The cost of production is Rs. $1{,}000$.",
  "Dividing by the sum of the percentages, or stopping early in the chain.",
  "C02C-chain-backward", "Three successive divisions; additive and stopping traps.",
  correct=r"Rs. $1{,}000$",
  distractors=[(r"Rs. $1{,}100$", r"Divides by $1 + 0.1 + 0.2 + 0.5 = 1.8$."),
               (r"Rs. $1{,}500$", "Stops at the manufacturer's selling price."),
               (r"Rs. $1{,}800$", "Stops at the retailer's cost.")],
  check=_c30, values=[1000, 1100, 1500, 1800], cognitive="Application")


# ---------------------------------------------------------------- C02-C-031
def _c31():
    r_cost = F(90) / F(15, 100)
    w_cost = r_cost / F(120, 100)
    m_cost = w_cost / F(125, 100)
    return m_cost
q("C02-C-031", CH, "Production cost from the retailer's rupee profit and the margins", "Medium",
  "Inverse/parameter",
  r"A retailer makes a profit of Rs. $90$ on each unit of a product, which is $15\%$ of his cost. He buys from a wholesaler who makes $20\%$ profit on his cost, and the wholesaler buys from the manufacturer, who makes $25\%$ profit on his cost of production. What is the manufacturer's cost of production per unit, in rupees?",
  "TITA",
  r"Retailer's cost $= \frac{90}{0.15} = 600$ rupees. This is the wholesaler's selling price, so his cost is $\frac{600}{1.2} = 500$ rupees, which is the manufacturer's selling price. Manufacturer's cost $= \frac{500}{1.25} = 400$ rupees.",
  "Subtracting percentages going backwards instead of dividing by the factors.",
  "C02C-chain-backward", "Back out a base from a rupee profit, then two backward divisions.",
  tita_answer=400, check=_c31,
  tita_traps=[(360, r"Subtracts $20\%$ and then $25\%$: $600 \times 0.8 \times 0.75$."),
              (500, "Stops at the wholesaler's cost.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-032
def _c32():
    sp = F(800) * F(125, 100)
    return sp + sp * F(12, 100)
q("C02-C-032", CH, "Customer's price with profit and sales tax on the selling price", "Easy",
  "Single-step computation",
  r"A retailer buys a ceiling fan for Rs. $800$ and sells it at a profit of $25\%$ on his cost. The customer also pays a sales tax of $12\%$ on the retailer's selling price. How much does the customer pay in all?",
  "MCQ",
  r"Retailer's selling price $= 800 \times 1.25 = 1000$ rupees. Tax $= 12\%$ of $1000 = 120$ rupees. The customer pays Rs. $1{,}120$.",
  "Adding the tax rate to the profit rate on cost.",
  "C02C-chain-sales-tax", "Two successive factors; tax base is the trap.",
  correct=r"Rs. $1{,}120$",
  distractors=[(r"Rs. $1{,}096$", r"Adds $25\% + 12\% = 37\%$ to the cost of Rs. $800$."),
               (r"Rs. $1{,}000$", "Leaves out the sales tax."),
               (r"Rs. $896$", r"Applies the tax to the cost and leaves out the profit.")],
  check=_c32, values=[1120, 1096, 1000, 896], cognitive="Application")


# ---------------------------------------------------------------- C02-C-033
def _c33():
    c = symbols('c', positive=True)
    sol = solve(Eq(c * F(12, 10) * F(125, 100) * F(12, 10) * F(11, 10), 1188), c)
    return sol[0]
q("C02-C-033", CH, "Production cost from a tax-inclusive customer price", "Medium",
  "Inverse/parameter",
  r"A customer pays Rs. $1{,}188$ for an electric kettle; this includes a sales tax of $10\%$ on the retailer's selling price. The retailer made $20\%$ profit, the wholesaler who supplied him made $25\%$, and the manufacturer made $20\%$, each on his own cost. What was the manufacturer's cost of production?",
  "MCQ",
  r"Remove the tax first: $\frac{1188}{1.1} = 1080$ rupees. Then $\frac{1080}{1.2} = 900$ (retailer's cost), $\frac{900}{1.25} = 720$ (wholesaler's cost) and $\frac{720}{1.2} = 600$. The cost of production is Rs. $600$.",
  "Ignoring the tax, or subtracting percentages instead of dividing.",
  "C02C-chain-sales-tax", "Four backward divisions including stripping the tax.",
  correct=r"Rs. $600$",
  distractors=[(r"Rs. $660$", r"Ignores the tax and divides Rs. $1{,}188$ by $1.2$, $1.25$ and $1.2$."),
               (r"Rs. $720$", "Stops at the manufacturer's selling price."),
               (r"Rs. $576$", r"Reaches Rs. $720$ correctly and then subtracts $20\%$ instead of dividing by $1.2$.")],
  check=_c33, values=[600, 660, 720, 576], cognitive="Application")


# ---------------------------------------------------------------- C02-C-034
def _c34():
    w_sp = F(1000) * F(120, 100)
    tax1 = w_sp * F(10, 100)
    def customer(r_cost):
        r_sp = r_cost * F(125, 100)
        return r_sp + r_sp * F(10, 100)
    return customer(w_sp + tax1) - customer(w_sp)
q("C02-C-034", CH, "Cascading sales tax against a refund of input tax; fall in the customer's price", "Difficult",
  "Conceptual/application",
  r"A wholesaler buys a television set from the manufacturer for Rs. $1{,}000$, sells it to a retailer at a profit of $20\%$ on his cost, and collects a sales tax of $10\%$ on his selling price. The retailer sells the set to a customer at a profit of $25\%$ on his own cost and collects a sales tax of $10\%$ on his selling price. At present the retailer cannot recover the tax he paid, so his cost is the full amount he paid the wholesaler. Under a new rule that tax is refunded to him, so his cost becomes only the wholesaler's pre-tax price; all profit and tax rates stay the same. By how much does the amount the customer pays fall under the new rule?",
  "MCQ",
  r"At present the retailer's cost is $1200 \times 1.1 = 1320$, so the customer pays $1320 \times 1.25 \times 1.1 = 1815$ rupees. Under the new rule his cost is $1200$, so the customer pays $1200 \times 1.25 \times 1.1 = 1650$ rupees. The fall is Rs. $165$: the first-stage tax of Rs. $120$ was being marked up by $25\%$ and then taxed again, $120 \times 1.25 \times 1.1 = 165$.",
  "Taking the saving as the refunded tax alone, missing that it was marked up and taxed again.",
  "C02C-chain-sales-tax", "Two tax regimes must be modelled and compared; the insight is that a tax inside the retailer's cost is marked up and taxed again, so the saving exceeds the tax refunded.",
  correct=r"Rs. $165$",
  distractors=[(r"Rs. $120$", "Takes the saving as the refunded first-stage tax alone."),
               (r"Rs. $150$", r"Marks the Rs. $120$ tax up by the retailer's $25\%$ but forgets that it is taxed again: $120 \times 1.25$."),
               (r"Rs. $132$", r"Adds the second-stage tax on the Rs. $120$ but forgets the retailer's markup: $120 \times 1.1$.")],
  check=_c34, values=[165, 120, 150, 132], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-035
def _c35():
    x = symbols('x', positive=True)
    sol = solve(Eq(F(600) * F(125, 100) * (1 + x / 100) * F(120, 100), 1080), x)
    return sol[0]
q("C02-C-035", CH, "Wholesaler's missing profit percentage in a chain", "Medium",
  "Inverse/parameter",
  r"A pair of shoes costs its manufacturer Rs. $600$ to make. The manufacturer sells it to a wholesaler at $25\%$ profit, the wholesaler sells to a retailer at some profit, and the retailer sells to a customer at $20\%$ profit, each profit on that seller's own cost. The customer pays Rs. $1{,}080$. What is the wholesaler's profit percentage (in $\%$)?",
  "TITA",
  r"Retailer's cost $= \frac{1080}{1.2} = 900$ rupees. The wholesaler bought at $600 \times 1.25 = 750$ rupees and sold at $900$ rupees, a profit of $\frac{150}{750} = 20\%$.",
  "Subtracting the known margins from the overall rise instead of dividing by their factors.",
  "C02C-chain-missing-margin", "Work in from both ends of the chain to isolate the middle margin.",
  tita_answer=20, check=_c35,
  tita_traps=[(35, r"Overall rise $80\%$ minus $25\%$ minus $20\%$."),
              (44, r"Ignores the retailer: $\frac{1080}{750} = 1.44$.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-036
def _c36():
    C, p = symbols('C p', positive=True)
    sol = solve([Eq(C * (1 + p) ** 2 * F(150, 100), 1080), Eq(C * (1 + p) * p, 120)], [C, p], dict=True)
    sol = [s for s in sol if s[C] > 0 and s[p] > 0]
    assert len(sol) == 1
    return sol[0][C]
q("C02-C-036", CH, "Production cost from the customer's price and one seller's rupee profit, with two equal unknown margins", "Difficult",
  "Inverse/parameter",
  r"A jacket passes from a manufacturer to a wholesaler to a retailer to a customer. The manufacturer and the wholesaler each make the same percentage profit on their own cost, and the retailer makes a profit of $50\%$ on his cost. The customer pays Rs. $1{,}080$, and the wholesaler's profit on the jacket is Rs. $120$. What is the manufacturer's cost of production?",
  "MCQ",
  r"The retailer's cost is $\frac{1080}{1.5} = 720$ rupees, which is the wholesaler's selling price. With common rate $p$ and production cost $C$, the wholesaler's selling price is $C(1 + p)^2 = 720$ and his profit is $C(1 + p)p = 120$. Dividing, $\frac{1 + p}{p} = 6$, so $p = \frac{1}{5} = 20\%$. The wholesaler's cost is $720 - 120 = 600$, so $C = \frac{600}{1.2} = 500$ rupees.",
  "Treating equal percentage profits as equal rupee profits, or stopping partway back along the chain.",
  "C02C-chain-missing-margin", "The common rate is unknown and must be found from the ratio of a selling price to a rupee profit before the chain can be unwound.",
  correct=r"Rs. $500$",
  distractors=[(r"Rs. $600$", r"Stops at the wholesaler's cost, $720 - 120$."),
               (r"Rs. $720$", "Removes only the retailer's margin."),
               (r"Rs. $480$", r"Assumes equal percentage profits mean equal rupee profits and subtracts Rs. $120$ twice from Rs. $720$.")],
  check=_c36, values=[500, 600, 720, 480], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-037
def _c37():
    w_cost = F(1200)
    w_sp = w_cost + 300
    r_sp = F(2000)
    return (r_sp - w_sp) / w_sp * 100
q("C02-C-037", CH, "Retailer's profit percentage from rupee prices along a chain", "Medium",
  "Multi-step word problem",
  r"A manufacturer sells a cycle to a wholesaler for Rs. $1{,}200$, making a profit of $20\%$ on his cost. The wholesaler makes a profit of Rs. $300$ when he sells it to a retailer, and the retailer sells it to a customer for Rs. $2{,}000$. What is the retailer's profit as a percentage of his cost?",
  "MCQ",
  r"The retailer's cost is the wholesaler's selling price, $1200 + 300 = 1500$ rupees. His profit is $2000 - 1500 = 500$ rupees, which is $\frac{500}{1500} = 33\frac{1}{3}\%$ of his cost. The manufacturer's cost is not needed.",
  "Using the wrong stage of the chain as the retailer's cost, or the selling price as the base.",
  "C02C-chain-missing-margin", "Identify the right cost base among several given prices; an irrelevant figure is present.",
  correct=r"$33\frac{1}{3}\%$",
  distractors=[(r"$25\%$", r"Divides the Rs. $500$ profit by the selling price Rs. $2{,}000$."),
               (r"$66\frac{2}{3}\%$", r"Compares Rs. $2{,}000$ with the wholesaler's cost Rs. $1{,}200$."),
               (r"$100\%$", r"Compares Rs. $2{,}000$ with the manufacturer's cost Rs. $1{,}000$.")],
  check=_c37, values=[F(100, 3), 25, F(200, 3), 100], cognitive="Application")


# ---------------------------------------------------------------- C02-C-038
def _c38():
    c = F(400)
    m_sp = c * F(115, 100)
    old = m_sp * F(120, 100) * F(125, 100)
    new = m_sp * F(125, 100)
    return old - new
q("C02-C-038", CH, "Customer's saving when the wholesaler is removed from the chain", "Medium",
  "Conceptual/application",
  r"A toaster costs Rs. $400$ to make. The manufacturer sells it to a wholesaler at $15\%$ profit, the wholesaler sells to a retailer at $20\%$ profit, and the retailer sells to a customer at $25\%$ profit, each on his own cost. If the retailer instead buys directly from the manufacturer at the price the manufacturer charged the wholesaler, and still makes $25\%$ profit on his cost, how much less does the customer pay?",
  "MCQ",
  r"Present customer price $= 400 \times 1.15 \times 1.2 \times 1.25 = 690$ rupees. Without the wholesaler: $460 \times 1.25 = 575$ rupees. The customer pays Rs. $115$ less. (The wholesaler's Rs. $92$ profit was itself marked up by the retailer's $25\%$: $92 \times 1.25 = 115$.)",
  "Taking the saving as just the wholesaler's rupee profit, which ignores the retailer's markup on it.",
  "C02C-chain-cut-middleman", "Insight that a removed margin is also removed from later markups.",
  correct=r"Rs. $115$",
  distractors=[(r"Rs. $92$", r"Takes the saving as the wholesaler's profit, $20\%$ of Rs. $460$."),
               (r"Rs. $138$", r"Takes $20\%$ of the customer's present price Rs. $690$."),
               (r"Rs. $230$", r"Assumes the customer would pay the manufacturer's price Rs. $460$.")],
  check=_c38, values=[115, 92, 138, 230], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-039
def _c39():
    retail = F(825)
    c = retail / (F(110, 100) * F(120, 100) * F(125, 100))
    old_pct = (c * F(110, 100) - c) / c * 100
    online = retail - 25
    received = online * F(90, 100)
    new_pct = (received - c) / c * 100
    return new_pct - old_pct
q("C02-C-039", CH, "Manufacturer's gain from selling online through a commission platform", "Difficult",
  "Multi-step word problem",
  r"A blender reaches customers through a manufacturer (profit $10\%$), a wholesaler (profit $20\%$) and a retailer (profit $25\%$), each profit on that seller's own cost, and customers pay Rs. $825$ for it. The manufacturer starts selling directly to customers on an online platform at Rs. $25$ less than the retail price. The platform keeps a commission of $10\%$ of the online price. By how many percentage points does the manufacturer's profit percentage increase on each blender sold online?",
  "MCQ",
  r"Cost of production $= \frac{825}{1.1 \times 1.2 \times 1.25} = \frac{825}{1.65} = 500$ rupees, and the old profit was $10\%$. Online price $= 800$, of which the manufacturer keeps $90\%$, that is $720$ rupees, a profit of $\frac{220}{500} = 44\%$. The increase is $44 - 10 = 34$ percentage points.",
  "Leaving out or misplacing the commission, or reporting the new profit instead of the increase.",
  "C02C-chain-cut-middleman", "Back out the cost through the chain, then a commission on a different base; answer is a difference of percentages.",
  correct=r"$34$ percentage points",
  distractors=[(r"$50$ percentage points", r"Leaves out the commission: $\frac{800 - 500}{500} = 60\%$, minus $10\%$."),
               (r"$40$ percentage points", r"Leaves out the commission to get $60\%$, treats the commission as $10$ percentage points off that, getting $50\%$, and then subtracts the old $10\%$: $50 - 10 = 40$."),
               (r"$44$ percentage points", r"Reports the new profit percentage of $44\%$ instead of the increase.")],
  check=_c39, values=[34, 50, 40, 44], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-040
def _c40():
    c = F(400)
    m = c * F(120, 100)
    w = m * F(125, 100)
    r = w * F(150, 100)
    return (r - w) / r
q("C02-C-040", CH, "Retailer's profit as a fraction of the customer's price", "Medium",
  "Conceptual/application",
  r"A rice cooker costs Rs. $400$ to make. The manufacturer sells it at $20\%$ profit, the wholesaler at $25\%$ profit and the retailer at $50\%$ profit, each profit on that seller's own cost. What fraction of the price paid by the customer is the retailer's profit?",
  "MCQ",
  r"Prices: $400 \to 480 \to 600 \to 900$. The retailer's profit is $900 - 600 = 300$ rupees, which is $\frac{300}{900} = \frac{1}{3}$ of the customer's price. (A $50\%$ profit on cost is always $\frac{1}{3}$ of the selling price.)",
  "Equating the profit percentage on cost with the share of the selling price.",
  "C02C-chain-profit-share", "Converting a margin on cost into a share of selling price; several plausible bases.",
  correct=r"$\frac{1}{3}$",
  distractors=[(r"$\frac{1}{2}$", r"Uses the $50\%$ profit on cost directly as the share of the selling price."),
               (r"$\frac{3}{5}$", r"Gives the retailer's share of the total chain profit, $\frac{300}{500}$."),
               (r"$\frac{3}{4}$", r"Divides the Rs. $300$ profit by the production cost Rs. $400$.")],
  check=_c40, values=[F(1, 3), F(1, 2), F(3, 5), F(3, 4)], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-041
def _c41():
    c = F(100)
    profit = c * F(50, 100)
    w_cost = c + profit
    r_cost = w_cost + profit
    return profit / r_cost * 100
q("C02-C-041", CH, "Equal rupee profits along a chain; retailer's percentage", "Medium",
  "Inverse/parameter",
  r"A manufacturer, a wholesaler and a retailer each make exactly the same rupee profit on a unit of a product. The manufacturer's profit is $50\%$ of his cost of production. What is the retailer's profit as a percentage of his cost (in $\%$)?",
  "TITA",
  r"Let the cost of production be $100$. Each seller earns $50$. The wholesaler pays $150$ and sells at $200$, so the retailer's cost is $200$. The retailer's $50$ is $\frac{50}{200} = 25\%$ of his cost.",
  "Assuming equal rupee profits mean equal percentage profits.",
  "C02C-chain-equal-rupee-profit", "Bases grow along the chain, so equal rupee profits give falling percentages.",
  tita_answer=25, check=_c41,
  tita_traps=[(50, r"Assumes equal rupee profits mean equal percentage profits, so the retailer also makes $50\%$."),
              (20, r"Divides the profit by the customer's price $250$.")],
  cognitive="Application")


# ---------------------------------------------------------------- C02-C-042
def _c42():
    w_cost = F(640) * F(125, 100)
    # brute force over wholesaler's rate in steps of 1/1000
    for k in range(1, 1000):
        p = F(k, 1000)
        profit = w_cost * p
        r_cost = w_cost + profit
        r_rate = profit / r_cost
        if r_rate == p - F(5, 100):
            return r_cost + profit
q("C02-C-042", CH, "Equal rupee profits with a 5-point gap in percentages; customer's price", "Difficult",
  "Inverse/parameter",
  r"A manufacturer's cost of production for a chair is Rs. $640$, and he sells it to a wholesaler at a profit of $25\%$. The wholesaler sells it to a retailer, who sells it to a customer. The wholesaler and the retailer make exactly the same rupee profit per chair, and the retailer's profit percentage on his cost is $5$ percentage points lower than the wholesaler's profit percentage on his cost. How much does the customer pay, in rupees?",
  "TITA",
  r"The wholesaler pays $800$. Let his rate be $p$, so each of the two earns $800p$ and the retailer's cost is $800(1 + p)$, giving the retailer a rate of $\frac{p}{1 + p}$. Then $\frac{p}{1 + p} = p - 0.05$, so $p^2 - 0.05p - 0.05 = 0$, $(p - 0.25)(p + 0.2) = 0$ and $p = 0.25$. Each earns $200$, and the customer pays $800 + 200 + 200 = 1200$ rupees.",
  "Assuming both earn the same percentage, or stopping at the retailer's cost.",
  "C02C-chain-equal-rupee-profit", "Sets up and solves a quadratic linking equal rupee profits to a gap in percentages.",
  tita_answer=1200, check=_c42,
  tita_traps=[(1000, "Stops at the retailer's cost."),
              (1250, r"Takes $p = 25\%$ but lets the retailer also make $25\%$: $800 \times 1.25 \times 1.25$.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-043
def _c43():
    true_kg_to_customers = F(300)                 # any quantity works
    m_rate = F(40)
    w_rate = m_rate * F(125, 100)                 # per kg billed to the retailer
    r_rate = w_rate * F(120, 100)                 # per kg billed to customers
    billed_to_customers = true_kg_to_customers / F(750, 1000)
    paid = billed_to_customers * r_rate * F(1125, 1000)
    return paid / true_kg_to_customers
q("C02-C-043", CH, "Customer's tax-inclusive price per true kilogram when the wholesaler and the retailer both use short weights", "Difficult",
  "Conceptual/application",
  r"A manufacturer sells sugar to a wholesaler at Rs. $40$ per kg, weighing honestly. The wholesaler bills a retailer at $25\%$ above that rate per kilogram billed, but hands over only $900$ g for every kilogram he bills. The retailer, unaware of this, prices the sugar at $20\%$ above the rate he was billed, per kilogram billed, but his own '$1$ kg' weight actually weighs $750$ g. Customers also pay a sales tax of $12.5\%$ on the retailer's selling price. How much does a customer pay, tax included, for each kilogram of sugar he actually receives?",
  "MCQ",
  r"The wholesaler bills $40 \times 1.25 = 50$ rupees per kg; his short weight cheats only the retailer and does not change what customers are charged. The retailer charges $50 \times 1.2 = 60$ rupees per billed kilogram, or $60 \times 1.125 = 67.5$ rupees with tax. Each billed kilogram is only $0.75$ kg, so the customer pays $\frac{67.5}{0.75} = 90$ rupees per kilogram received.",
  "Letting the wholesaler's short weight raise the customer's price, although it affects only the retailer.",
  "C02C-chain-cheating-wholesaler", "Three price stages plus tax and two false weights; the insight is that only the retailer's weight affects what the customer receives.",
  correct=r"Rs. $90$",
  distractors=[(r"Rs. $100$", r"Also divides by the wholesaler's $0.9$, although that cheat affects only the retailer: $\frac{90}{0.9}$."),
               (r"Rs. $80$", r"Leaves out the sales tax: $\frac{60}{0.75}$."),
               (r"Rs. $72$", r"Applies the retailer's $20\%$ to the manufacturer's Rs. $40$, skipping the wholesaler's markup: $\frac{40 \times 1.2 \times 1.125}{0.75}$.")],
  check=_c43, values=[90, 100, 80, 72], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C02-C-044
def _c44():
    def customer(c):
        return c * F(125, 100) * F(120, 100) * F(110, 100)
    return customer(F(540)) - customer(F(500))
q("C02-C-044", CH, "Effect of a rise in production cost on the customer's price", "Easy",
  "Conceptual/application",
  r"The manufacturer, wholesaler and retailer of a kettle make profits of $25\%$, $20\%$ and $10\%$ respectively, each on his own cost. The manufacturer's cost of production rises by Rs. $40$, and every seller keeps the same percentage profit. By how much does the price paid by the customer rise?",
  "MCQ",
  r"Every price in the chain is the production cost times $1.25 \times 1.2 \times 1.1 = 1.65$. So a Rs. $40$ rise in cost raises the customer's price by $40 \times 1.65 = 66$ rupees.",
  "Assuming the rise passes through unchanged or is marked up only once.",
  "C02C-chain-cost-propagation", "One idea: the customer's price is proportional to the production cost.",
  correct=r"Rs. $66$",
  distractors=[(r"Rs. $40$", "Assumes the rise passes to the customer unchanged."),
               (r"Rs. $50$", r"Marks the rise up only by the manufacturer's $25\%$."),
               (r"Rs. $62$", r"Adds the percentages: $40 \times 1.55$.")],
  check=_c44, values=[66, 40, 50, 62], cognitive="Understanding")


# ---------------------------------------------------------------- C02-C-045
def _c45():
    c = F(400)
    m_sp = c * F(125, 100)
    customer = m_sp * F(120, 100) * F(140, 100)
    new_r_cost = m_sp * F(150, 100)
    return (customer - new_r_cost) / new_r_cost * 100
q("C02-C-045", CH, "Retailer absorbs the wholesaler's higher margin to hold the customer price", "Medium",
  "Inverse/parameter",
  r"A manufacturer makes a heater for Rs. $400$ and sells it to a wholesaler at $25\%$ profit. The wholesaler sells to a retailer at $20\%$ profit, and the retailer sells to customers at $40\%$ profit, each profit on that seller's own cost. The wholesaler then raises his profit to $50\%$ on his cost, while the manufacturer's price is unchanged. If the retailer keeps the customer's price unchanged, what is the retailer's new profit as a percentage of his new cost (in $\%$)?",
  "TITA",
  r"Customer's price $= 400 \times 1.25 \times 1.2 \times 1.4 = 840$ rupees. The retailer's new cost is $500 \times 1.5 = 750$ rupees, so his profit is $\frac{840 - 750}{750} = \frac{90}{750} = 12\%$.",
  "Shifting percentage points from the retailer to the wholesaler as if percentages simply add.",
  "C02C-chain-cost-propagation", "Hold the final price fixed and recompute a margin on a new base.",
  tita_answer=12, check=_c45,
  tita_traps=[(10, r"Shifts $30$ percentage points: $40 - 30$."),
              (15, r"Divides the new profit of Rs. $90$ by the retailer's old cost of Rs. $600$.")],
  cognitive="Application")
