import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Weighted averages and groups"
X2 = ("CAT", "XAT")


def _sol1(eq, var):
    s = solve(eq, var)
    assert len(s) == 1, s
    return s[0]


# ---------------------------------------------------------------- EASY (11)

def _c001():
    return Fraction(32 * 64 + 48 * 74, 32 + 48)
q("C05-B-001", TOPIC, "Combined average of two batches of unequal size", "Easy",
  "Single-step computation",
  r"Two batches at a coaching institute took the same mock test. Batch P has $32$ students with an average score of $64$, and batch Q has $48$ students with an average score of $74$. What is the average score of all $80$ students taken together?",
  "TITA",
  r"Total of P is $32 \times 64 = 2048$ and total of Q is $48 \times 74 = 3552$. Combined average $= \frac{2048 + 3552}{80} = \frac{5600}{80} = 70$. Faster: the batch sizes are in ratio $2 : 3$, so the combined average lies $\frac{3}{5}$ of the way from $64$ to $74$, that is $64 + 6 = 70$.",
  "Taking the simple mean of the two batch averages, ignoring batch sizes.",
  "C05B-combined-two-groups", "One weighted average of two groups; the only trap is ignoring the unequal sizes.",
  tita_answer=70, check=_c001,
  tita_traps=[(69, r"Takes the simple mean of $64$ and $74$, ignoring the batch sizes."),
              (68, r"Attaches the larger batch to the lower average: $\frac{48 \times 64 + 32 \times 74}{80} = 68$.")],
  cognitive="Application")


def _c002():
    x = symbols('x')
    return _sol1(Eq(15 * 86000 + 45 * x, 60 * 50000), x)
q("C05-B-002", TOPIC, "Average salary of the non-managers from the overall and managers' averages", "Easy",
  "Inverse/parameter",
  r"A company has $60$ employees whose average monthly salary is Rs. $50{,}000$. The $15$ managers among them have an average monthly salary of Rs. $86{,}000$. What is the average monthly salary of the remaining employees?",
  "MCQ",
  r"Total salary $= 60 \times 50{,}000 = 30{,}00{,}000$; the managers draw $15 \times 86{,}000 = 12{,}90{,}000$. The other $45$ employees draw $17{,}10{,}000$, an average of $\frac{17{,}10{,}000}{45} = 38{,}000$. Check by balance: managers to others is $15 : 45 = 1 : 3$, so the others sit $\frac{36{,}000}{3} = 12{,}000$ below the overall average of $50{,}000$.",
  "Dividing the remaining salary by the whole headcount, or balancing the gap against the wrong group size.",
  "C05B-missing-group-average", "Single subtraction of totals; traps are in which headcount to divide by.",
  correct=r"Rs. $38{,}000$",
  distractors=[(r"Rs. $41{,}000$", r"Balances the gap using $15 : 60$ instead of $15 : 45$: the others sit $\frac{36{,}000}{4} = 9{,}000$ below $50{,}000$."),
               (r"Rs. $28{,}500$", r"Divides the remaining total $17{,}10{,}000$ by all $60$ employees instead of the $45$ non-managers."),
               (r"Rs. $14{,}000$", r"Treats the two groups as equal in size: $2 \times 50{,}000 - 86{,}000$.")],
  check=_c002, values=[38000, 41000, 28500, 14000], cognitive="Application")


def _c003():
    x = symbols('x')
    return _sol1(Eq((20 * 42 + x) / 21, 44), x)
q("C05-B-003", TOPIC, "Runs needed in the next innings to lift a batting average", "Easy",
  "Inverse/parameter",
  r"A batsman has a batting average of $42$ after $20$ innings, having been dismissed in every innings. How many runs must he score in his $21$st innings, in which he is also dismissed, to raise his batting average to $44$?",
  "MCQ",
  r"He needs $21 \times 44 = 924$ runs in all and already has $20 \times 42 = 840$, so he must score $924 - 840 = 84$. Shortcut: the new innings must cover the new average $44$ plus $2$ extra runs for each of the $20$ earlier innings: $44 + 40 = 84$.",
  "Forgetting that every earlier innings must also be lifted by the increase in average.",
  "C05B-batting-next-innings", "Direct use of totals; one natural trap in the shortcut.",
  correct=r"$84$",
  distractors=[(r"$46$", r"Adds only the $2$-run increase to $44$, ignoring the $20$ earlier innings."),
               (r"$82$", r"Starts the shortcut from the old average: $42 + 2 \times 20 = 82$."),
               (r"$86$", r"Lifts $21$ innings instead of $20$: $44 + 2 \times 21 = 86$.")],
  check=_c003, values=[84, 46, 82, 86], cognitive="Application")


def _c004():
    b = symbols('b', positive=True)
    return _sol1(Eq((60 * b + 75 * 24) / (b + 24), 66), b)
q("C05-B-004", TOPIC, "Number of boys from the boys', girls' and class averages", "Easy",
  "Inverse/parameter",
  r"In a class, the average mark of the boys is $60$, the average mark of the girls is $75$, and the average mark of the whole class is $66$. If there are $24$ girls, how many boys are in the class?",
  "TITA",
  r"The boys are $6$ below the class average and the girls are $9$ above, so boys : girls $= 9 : 6 = 3 : 2$. With $24$ girls, the number of boys is $24 \times \frac{3}{2} = 36$. Check: $\frac{36 \times 60 + 24 \times 75}{60} = \frac{2160 + 1800}{60} = 66$.",
  "Inverting the ratio: the group farther from the mean is the smaller group.",
  "C05B-group-size-from-averages", "One balance step; the inverted ratio is the standard trap.",
  tita_answer=36, check=_c004,
  tita_traps=[(16, r"Inverts the ratio and takes boys : girls $= 6 : 9$, giving $24 \times \frac{2}{3} = 16$."),
              (60, "Reports the size of the whole class.")],
  cognitive="Application")


def _c005():
    # per 100 employees
    return Fraction(40 * 45000 + 60 * 30000, 100)
q("C05-B-005", TOPIC, "Overall average salary from department shares given in percent", "Easy",
  "Single-step computation",
  r"In a firm, $40\%$ of the employees work in Sales and have an average monthly salary of Rs. $45{,}000$. The remaining employees work in Operations and have an average monthly salary of Rs. $30{,}000$. What is the average monthly salary of all the employees, in rupees?",
  "TITA",
  r"Weight each average by its share of the headcount: $0.4 \times 45{,}000 + 0.6 \times 30{,}000 = 18{,}000 + 18{,}000 = 36{,}000$. The overall figure lies closer to the Operations average because Operations is the larger group.",
  "Using the simple mean of the two department averages, or swapping the weights.",
  "C05B-percentage-share-weights", "Percent shares used directly as weights in one step.",
  tita_answer=36000, check=_c005,
  tita_traps=[(37500, "Takes the simple mean of the two department averages."),
              (39000, r"Swaps the weights: $0.6 \times 45{,}000 + 0.4 \times 30{,}000$.")],
  cognitive="Application")


def _c006():
    r = symbols('r')
    return _sol1(Eq((40 * 24 + r) / 45, 23), r)
q("C05-B-006", TOPIC, "Runs conceded in a match from the change in bowling average", "Easy",
  "Inverse/parameter",
  r"A bowler had taken $40$ wickets at a bowling average of $24$ runs per wicket. In his next match he took $5$ wickets, and his bowling average fell to $23$ runs per wicket. How many runs did he concede in that match?",
  "MCQ",
  r"Runs before the match $= 40 \times 24 = 960$. Afterwards he has $45$ wickets at $23$ runs each, that is $45 \times 23 = 1035$ runs. So he conceded $1035 - 960 = 75$ runs in the match. Shortcut: the $5$ new wickets cost $23$ each, less the $1$-run drop on each of the $40$ earlier wickets: $5 \times 23 - 40 = 75$.",
  "Assuming the match was bowled at the new average, or misapplying the shortcut (wrong base average or wrong wicket count for the drop).",
  "C05B-bowling-average-change", "Difference of two totals; traps lie in the shortcut.",
  correct=r"$75$",
  distractors=[(r"$80$", r"Uses the old average $24$ instead of the new average $23$ as the base in the shortcut: $5 \times 24 - 40 = 80$."),
               (r"$115$", r"Assumes the match itself was bowled at the new average: $5 \times 23 = 115$."),
               (r"$70$", r"Subtracts the $1$-run drop for all $45$ wickets instead of the $40$ earlier ones: $5 \times 23 - 45 = 70$.")],
  check=_c006, values=[75, 80, 115, 70], cognitive="Application")


def _c007():
    x = symbols('x')
    return _sol1(Eq((24 * Rational(85, 10) + 16 * x) / 40, Rational(82, 10)), x)
q("C05-B-007", TOPIC, "SGPA needed in a semester for a target credit-weighted CGPA", "Easy",
  "Inverse/parameter",
  r"Meera earned an SGPA of $8.5$ in a semester worth $24$ credits. Her next semester is worth $16$ credits. Her CGPA is the credit-weighted average of her semester SGPAs. What SGPA must she earn in the second semester for her CGPA over the two semesters to be exactly $8.2$?",
  "MCQ",
  r"Total grade points needed $= 40 \times 8.2 = 328$. The first semester gives $24 \times 8.5 = 204$. The second semester must give $328 - 204 = 124$ points over $16$ credits, an SGPA of $\frac{124}{16} = 7.75$.",
  "Treating the two semesters as equally weighted, or scaling the gap by the wrong credit ratio.",
  "C05B-credit-weighted-gpa", "One weighted-average equation in one unknown.",
  correct=r"$7.75$",
  distractors=[(r"$7.90$", r"Weights the semesters equally: $2 \times 8.2 - 8.5 = 7.9$."),
               (r"$8.00$", r"Scales the $0.3$ surplus of the first semester by $\frac{16}{24}$ instead of $\frac{24}{16}$: $8.2 - 0.2$."),
               (r"$7.45$", r"Scales the $0.3$ surplus by $\frac{40}{16}$, using total credits: $8.2 - 0.75$.")],
  check=_c007, values=[Rational(31, 4), Rational(79, 10), 8, Rational(149, 20)], cognitive="Application")


def _c008():
    x = symbols('x')
    return _sol1(Eq(Rational(40, 100) * 65 + Rational(60, 100) * x, 77), x)
q("C05-B-008", TOPIC, "Final examination mark needed for a target weighted course grade", "Easy",
  "Inverse/parameter",
  r"A course grade is computed as $40\%$ of the internal assessment mark plus $60\%$ of the final examination mark, both marked out of $100$. Kabir scored $65$ in the internal assessment. What mark, out of $100$, must he score in the final examination to get a course grade of exactly $77$?",
  "TITA",
  r"$0.4 \times 65 + 0.6x = 77$ gives $26 + 0.6x = 77$, so $0.6x = 51$ and $x = 85$.",
  "Treating the two components as equally weighted or attaching the weights to the wrong components.",
  "C05B-weighted-assessment-components", "One linear equation with given weights.",
  tita_answer=85, check=_c008,
  tita_traps=[(89, r"Weights the components equally: $2 \times 77 - 65 = 89$."),
              (95, r"Swaps the weights: $0.6 \times 65 + 0.4x = 77$ gives $x = 95$.")],
  cognitive="Application")


def _c009():
    true_avg = Fraction(30 * 72 + 10 * 60, 40)
    principal = Fraction(72 + 60, 2)
    return true_avg - principal
q("C05-B-009", TOPIC, "Gap between the true combined average and the mean of two section averages", "Easy",
  "Conceptual/application",
  r"Section P of a class has $30$ students with an average score of $72$, and Section Q has $10$ students with an average score of $60$. The principal reported the average of all $40$ students as the simple mean of the two section averages. The true average of all $40$ students minus the principal's figure equals",
  "MCQ",
  r"The principal's figure is $\frac{72 + 60}{2} = 66$. The true average is $\frac{30 \times 72 + 10 \times 60}{40} = \frac{2160 + 600}{40} = 69$. The difference is $69 - 66 = 3$; the simple mean understates the true figure because the larger section has the higher average.",
  "Believing the mean of group averages equals the combined average when the groups differ in size.",
  "C05B-average-of-averages", "Two quick averages; the conceptual trap is assuming they agree.",
  correct=r"$3$",
  distractors=[(r"$0$", "Assumes the mean of the two section averages always equals the true combined average."),
               (r"$-3$", r"Swaps the section sizes, getting a true average of $\frac{10 \times 72 + 30 \times 60}{40} = 63$."),
               (r"$2$", r"Places the true average $\frac{10}{30} = \frac{1}{3}$ of the way from $72$ to $60$, getting $68$, instead of $\frac{1}{4}$ of the way.")],
  check=_c009, values=[3, 0, -3, 2], cognitive="Understanding")


def _c010():
    # simulate per 100 students with arbitrary base averages; the change must not depend on them
    out = set()
    for jb, sb in [(50, 70), (61, 44), (30, 90)]:
        before = Fraction(60 * jb + 40 * sb, 100)
        after = Fraction(60 * (jb + 5) + 40 * (sb - 2), 100)
        out.add(after - before)
    assert len(out) == 1
    return out.pop()
q("C05-B-010", TOPIC, "Change in the combined average when the two group averages move in opposite directions", "Easy",
  "Conceptual/application",
  r"In a school, $60\%$ of the students are in the junior wing and the rest are in the senior wing. In this year's annual test, the average score of the junior wing rose by $5$ marks over last year, while the average score of the senior wing fell by $2$ marks. The number of students in each wing did not change. By how many marks did the average score of all the students rise?",
  "MCQ",
  r"Per $100$ students, the junior wing's total rises by $60 \times 5 = 300$ marks and the senior wing's total falls by $40 \times 2 = 80$ marks. The net rise is $220$ marks over $100$ students, so the overall average rises by $2.2$ marks, whatever the two wings' actual averages were.",
  "Combining the two changes without weighting them by the sizes of the wings.",
  "C05B-group-average-shifts", "One weighted combination of two signed changes; the trap is the unweighted mean.",
  correct=r"$2.2$",
  distractors=[(r"$1.5$", r"Takes the simple mean of the two changes: $\frac{5 - 2}{2} = 1.5$."),
               (r"$0.8$", r"Swaps the weights: $0.4 \times 5 - 0.6 \times 2 = 0.8$."),
               (r"$3.8$", r"Adds the senior wing's change instead of subtracting it: $0.6 \times 5 + 0.4 \times 2 = 3.8$.")],
  check=_c010, values=[Rational(11, 5), Rational(3, 2), Rational(4, 5), Rational(19, 5)], cognitive="Understanding")


def _c011():
    innings, not_out, runs = 16, 4, 720
    return Fraction(runs, innings - not_out)
q("C05-B-011", TOPIC, "Batting average with not-out innings", "Easy",
  "Single-step computation",
  r"In a season, a batsman played $16$ innings and remained not out in $4$ of them. He scored $720$ runs in all, of which $120$ came in the innings in which he remained not out. His batting average is his total runs divided by the number of times he was dismissed. What is his batting average for the season?",
  "MCQ",
  r"He was dismissed $16 - 4 = 12$ times. All $720$ runs count, including the $120$ scored when not out, so his batting average is $\frac{720}{12} = 60$.",
  "Dividing by innings rather than dismissals, or discarding runs scored in not-out innings.",
  "C05B-batting-not-outs", "One division once the right denominator is identified.",
  correct=r"$60$",
  distractors=[(r"$45$", r"Divides by all $16$ innings: $\frac{720}{16}$."),
               (r"$36$", r"Adds the not-out innings to the innings count: $\frac{720}{20}$."),
               (r"$50$", r"Discards the $120$ runs scored in not-out innings: $\frac{600}{12}$.")],
  check=_c011, values=[60, 45, 36, 50], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM (15)

def _c012():
    # simulate year by year: raise everyone on the rolls, then add the joiners
    salaries = [Fraction(45000)] * 40
    for _ in range(2):
        salaries = [x * Fraction(110, 100) for x in salaries]
        salaries += [Fraction(30000)] * 10
    assert len(salaries) == 60
    return sum(salaries) / len(salaries)
q("C05-B-012", TOPIC, "Average salary after two rounds of raises followed by fresh hiring", "Medium",
  "Multi-step word problem",
  r"A firm has $40$ employees with an average monthly salary of Rs. $45{,}000$. At the start of each of the next two years, every employee then on the rolls gets a $10\%$ raise, and after the raises $10$ new employees join at a monthly salary of Rs. $30{,}000$ each. What is the average monthly salary, in rupees, of all $60$ employees just after the second group of new employees joins?",
  "TITA",
  r"The salary bill starts at $40 \times 45{,}000 = 18{,}00{,}000$. Year $1$: the raise makes it $19{,}80{,}000$, and the $10$ joiners add $3{,}00{,}000$, giving $22{,}80{,}000$. Year $2$: the raise applies to all $50$ employees then on the rolls, making it $25{,}08{,}000$, and the next $10$ joiners add $3{,}00{,}000$, giving $28{,}08{,}000$. The average is $\frac{28{,}08{,}000}{60} = 46{,}800$.",
  "Forgetting that the first year's joiners also receive the second year's raise, or raising joiners on the day they join.",
  "C05B-staged-hiring-raises", "Two stages in which the group receiving the raise changes; the bill must be tracked stage by stage.",
  tita_answer=46800, check=_c012,
  tita_traps=[(46300, r"Gives the second raise only to the original $40$: $\frac{40 \times 45{,}000 \times 1.21 + 6{,}00{,}000}{60} = 46{,}300$."),
              (47850, r"Also raises each group of joiners in the year it joins: $\frac{1.1 \times (1.1 \times 21{,}00{,}000 + 3{,}00{,}000)}{60} = 47{,}850$."),
              (45600, r"Stops after the first year: $\frac{22{,}80{,}000}{50} = 45{,}600$.")],
  cognitive="Application")


def _c013():
    hits = []
    for w in range(1, 11):          # at most 10 wickets in a match
        total_runs, total_wkts = 50 * 26 + 100, 50 + w
        avg = Fraction(total_runs, total_wkts)
        if avg.denominator == 1 and avg < 26:
            hits.append(w)
    assert len(hits) == 1
    return hits[0]
q("C05-B-013", TOPIC, "Wickets taken in a match when the new bowling average must be a whole number", "Medium",
  "Casework/optimisation",
  r"A bowler has taken $50$ wickets at a bowling average of $26$ runs per wicket. In his next match he conceded $100$ runs and took at least one wicket; a bowler can take at most $10$ wickets in a match. After the match, his bowling average was a whole number of runs per wicket. How many wickets did he take in that match?",
  "TITA",
  r"His runs become $50 \times 26 + 100 = 1400$ over $50 + w$ wickets, with $1 \le w \le 10$. So $50 + w$ must be a divisor of $1400 = 2^3 \times 5^2 \times 7$ between $51$ and $60$. The only such divisor is $56$, giving $w = 6$ and a new average of $\frac{1400}{56} = 25$.",
  "Ignoring the limit of $10$ wickets in a match, or reporting the total number of wickets.",
  "C05B-bowling-average-change", "Requires turning the condition into a divisor search within a bounded range; the bound is easy to miss.",
  tita_answer=6, check=_c013,
  tita_traps=[(20, r"Ignores the $10$-wicket limit and takes the divisor $70$, giving an average of $20$."),
              (56, "Reports his total wickets after the match.")],
  cognitive="Analysis")


def _c014():
    managers, others = 20, 80      # per 100 employees
    m_avg, o_avg = 4, 1            # in units of the others' average
    return Fraction(managers * m_avg, managers * m_avg + others * o_avg)
q("C05-B-014", TOPIC, "Share of the salary bill paid to a group from headcount share and salary multiple", "Medium",
  "Conceptual/application",
  r"In a company, $20\%$ of the employees are managers. The average salary of the managers is four times the average salary of the other employees. What fraction of the company's total salary bill is paid to the managers?",
  "MCQ",
  r"Take the other employees' average salary as $1$ unit. Per $100$ employees, the managers draw $20 \times 4 = 80$ units and the other $80$ employees draw $80 \times 1 = 80$ units. The managers' share is $\frac{80}{80 + 80} = \frac{1}{2}$.",
  "Confusing a group's share of headcount with its share of the total, or forgetting to divide by the full bill.",
  "C05B-group-share-of-total", "Two-step: build totals from shares and an average multiple, then take a ratio.",
  correct=r"$\frac{1}{2}$",
  distractors=[(r"$\frac{1}{5}$", "Reports the managers' share of the headcount."),
               (r"$\frac{4}{5}$", r"Takes $0.2 \times 4 = 0.8$ as the share without dividing by the whole bill."),
               (r"$\frac{1}{17}$", r"Attaches the factor $4$ to the other employees: $\frac{20}{20 + 80 \times 4}$.")],
  check=_c014, values=[Fraction(1, 2), Fraction(1, 5), Fraction(4, 5), Fraction(1, 17)], cognitive="Understanding")


def _c015():
    n, s = symbols('n s', positive=True)
    sol = solve([Eq((24 * 40 + s) / 25, 41), Eq((75 * n - s) / (n - 1), Rational(151, 2))], [n, s], dict=True)
    assert len(sol) == 1
    return sol[0][n]
q("C05-B-015", TOPIC, "Size of a group from the averages after one member moves between groups", "Medium",
  "Multi-step word problem",
  r"Two groups of trainees took an aptitude test. Group P had an average score of $75$, and Group Q had $24$ trainees with an average score of $40$. One trainee was then moved from P to Q, and her score stayed with her. As a result, the average of P rose by $0.5$ and the average of Q rose by $1$. How many trainees were in Group P before the move?",
  "TITA",
  r"Q now has $25$ trainees averaging $41$, a total of $1025$, against $24 \times 40 = 960$ before, so the trainee scored $65$. If P had $n$ trainees, $75n - 65 = 75.5(n - 1)$, so $0.5n = 10.5$ and $n = 21$. Check: $\frac{21 \times 75 - 65}{20} = \frac{1510}{20} = 75.5$.",
  "Using the old size of the receiving group when finding the moved score, or reporting the size after the move.",
  "C05B-transfer-between-groups", "Two linked stages: recover the moved score from Q, then solve for P's size.",
  tita_answer=21, check=_c015,
  tita_traps=[(20, "Reports the size of Group P after the move."),
              (69, r"Takes the moved trainee's score as Q's new average $41$: $75n - 41 = 75.5(n - 1)$ gives $n = 69$.")],
  cognitive="Analysis", exams=X2)


def _c016():
    bx, by = symbols('bx by', positive=True)
    bX = _sol1(Eq(56 * bx + 66 * (40 - bx), 60 * 40), bx)
    bY = _sol1(Eq(68 * by + 78 * (60 - by), 70 * 60), by)
    return Fraction(int(bX * 56 + bY * 68), int(bX + bY))
q("C05-B-016", TOPIC, "Combined average of the boys of two classes from class-level averages", "Medium",
  "Multi-step word problem",
  r"Class X has $40$ students: the boys average $56$, the girls average $66$, and the class average is $60$. Class Y has $60$ students: the boys average $68$, the girls average $78$, and the class average is $70$. What is the average score of all the boys of the two classes taken together?",
  "MCQ",
  r"In X, boys : girls $= (66 - 60) : (60 - 56) = 3 : 2$, so X has $24$ boys. In Y, boys : girls $= (78 - 70) : (70 - 68) = 4 : 1$, so Y has $48$ boys. All boys: $\frac{24 \times 56 + 48 \times 68}{72} = \frac{1344 + 3264}{72} = \frac{4608}{72} = 64$.",
  "Averaging the two boys' averages directly, or inverting a balance ratio inside one class.",
  "C05B-cross-classified-groups", "Needs two group-size deductions before a final weighted average.",
  correct=r"$64$",
  distractors=[(r"$62$", r"Takes the simple mean of the boys' averages $56$ and $68$."),
               (r"$65$", r"Inverts the ratio in X, taking $16$ boys there: $\frac{16 \times 56 + 48 \times 68}{64} = 65$."),
               (r"$60$", r"Inverts the ratio in Y, taking $12$ boys there: $\frac{24 \times 56 + 12 \times 68}{36} = 60$.")],
  check=_c016, values=[64, 62, 65, 60], cognitive="Analysis", exams=X2)


def _c017():
    heads = {"junior": 30, "senior": 70}
    sal = {"junior": 35000, "senior": 60000}
    rise = {"junior": Fraction(15, 100), "senior": Fraction(5, 100)}
    before = sum(heads[k] * sal[k] for k in heads)
    after = sum(heads[k] * sal[k] * (1 + rise[k]) for k in heads)
    return (after - before) / before * 100
q("C05-B-017", TOPIC, "Overall percentage rise in average salary when groups get different raises", "Medium",
  "Multi-step word problem",
  r"In a firm, $30\%$ of the employees are juniors with an average monthly salary of Rs. $35{,}000$, and the rest are seniors with an average monthly salary of Rs. $60{,}000$. Every junior gets a $15\%$ raise and every senior a $5\%$ raise, and the headcount does not change. By what percentage does the average monthly salary of all the employees rise?",
  "MCQ",
  r"Per $100$ employees, the salary bill is $30 \times 35{,}000 + 70 \times 60{,}000 = 10{,}50{,}000 + 42{,}00{,}000 = 52{,}50{,}000$. The increase is $15\%$ of $10{,}50{,}000$ plus $5\%$ of $42{,}00{,}000$, that is $1{,}57{,}500 + 2{,}10{,}000 = 3{,}67{,}500$. With the headcount fixed, the average rises by $\frac{3{,}67{,}500}{52{,}50{,}000} = 7\%$. The raises must be weighted by salary bill, not by headcount.",
  "Weighting the percentage raises by headcount instead of by each group's share of the salary bill.",
  "C05B-group-raises", "Percentage changes must be weighted by bill shares, which are not given directly.",
  correct=r"$7\%$",
  distractors=[(r"$8\%$", r"Weights the raises by headcount: $0.3 \times 15 + 0.7 \times 5 = 8$."),
               (r"$10\%$", r"Takes the simple mean of $15\%$ and $5\%$."),
               (r"$13\%$", r"Gives the $15\%$ raise to the seniors' bill and $5\%$ to the juniors': $\frac{52{,}500 + 6{,}30{,}000}{52{,}50{,}000} = 13\%$.")],
  check=_c017, values=[7, 8, 10, 13], cognitive="Analysis")


def _c018():
    p = symbols('p', positive=True)
    pv = _sol1(Eq((52 * p + 72 * (p + 18)) / (2 * p + 18), 67), p)
    return 2 * pv + 18
q("C05-B-018", TOPIC, "Total participants from the combined average and the difference in group sizes", "Medium",
  "Conceptual/application",
  r"In a quiz, the participants from Pune had an average score of $52$ and those from Nagpur had an average score of $72$. The average score of all the participants together was $67$. If there were $18$ more participants from Nagpur than from Pune, how many participants were there in all?",
  "MCQ",
  r"Pune is $15$ below the overall average and Nagpur is $5$ above, so Pune : Nagpur $= 5 : 15 = 1 : 3$. The difference of $2$ parts is $18$, so one part is $9$: Pune $9$, Nagpur $27$, total $36$. Check: $\frac{9 \times 52 + 27 \times 72}{36} = \frac{468 + 1944}{36} = 67$.",
  "Mapping the given difference to the wrong number of ratio parts.",
  "C05B-group-size-from-averages", "Balance ratio plus a parts argument on a difference.",
  correct=r"$36$",
  distractors=[(r"$72$", r"Treats the difference of $18$ as one part of the $1 : 3$ ratio, so the total is $4 \times 18$."),
               (r"$27$", "Reports the number of participants from Nagpur only."),
               (r"$24$", r"Treats the difference of $18$ as $3$ parts, so one part is $6$ and the total is $4 \times 6$.")],
  check=_c018, values=[36, 72, 27, 24], cognitive="Analysis")


def _c019():
    best = None
    for g in range(15, 36):
        b = 50 - g
        if b < 15:
            continue
        avg = Fraction(62 * b + 72 * g, 50)
        best = avg if best is None or avg > best else best
    return best
q("C05-B-019", TOPIC, "Highest possible combined average under minimum group sizes", "Medium",
  "Casework/optimisation",
  r"A class of $50$ students has boys averaging $62$ marks and girls averaging $72$ marks in a test. The class has at least $15$ boys and at least $15$ girls. What is the highest possible average mark for the whole class?",
  "MCQ",
  r"With $g$ girls, the class average is $62 + 10 \times \frac{g}{50}$, which increases with $g$. The largest allowed $g$ is $50 - 15 = 35$, giving $62 + 10 \times \frac{35}{50} = 62 + 7 = 69$.",
  "Ignoring the minimum-size condition or optimising in the wrong direction.",
  "C05B-combined-average-range", "Needs to see the average is monotonic in group size and apply the bound.",
  correct=r"$69$",
  distractors=[(r"$72$", r"Ignores the condition of at least $15$ boys and takes an all-girl class."),
               (r"$67$", "Takes the simple mean of the two averages, as if the class were half boys and half girls."),
               (r"$65$", r"Finds the lowest possible average, with $35$ boys and $15$ girls.")],
  check=_c019, values=[69, 72, 67, 65], cognitive="Analysis")


def _c020():
    hits = []
    for n in range(21, 30):
        for f in range(1, n):
            if 70 * f + 57 * (n - f) == 62 * n:
                hits.append(f)
    assert len(hits) == 1
    return hits[0]
q("C05-B-020", TOPIC, "Group size from averages with a range on the total", "Medium",
  "Casework/optimisation",
  r"The average weight of the players in a rugby squad is $62$ kg. The forwards average $70$ kg and the remaining players average $57$ kg. If the squad has more than $20$ but fewer than $30$ players, how many forwards are there?",
  "TITA",
  r"The forwards are $8$ kg above the squad average and the others $5$ kg below, so forwards : others $= 5 : 8$. The squad size is a multiple of $13$; the only one between $20$ and $30$ is $26$, giving $10$ forwards and $16$ others. Check: $\frac{10 \times 70 + 16 \times 57}{26} = \frac{700 + 912}{26} = 62$.",
  "Inverting the balance ratio, or answering with the squad size.",
  "C05B-group-size-from-averages", "Balance ratio combined with an integer constraint on the total.",
  tita_answer=10, check=_c020,
  tita_traps=[(16, r"Inverts the ratio to $8 : 5$ and reports $16$ forwards."),
              (26, "Reports the size of the squad.")],
  cognitive="Analysis")


def _c021():
    t1 = 30 * 50
    t12 = 50 * 54
    t123 = 100 * 60
    b2 = Fraction(t12 - t1, 20)
    b3 = Fraction(t123 - t12, 50)
    return b3 - b2
q("C05-B-021", TOPIC, "Averages of batches recovered from successive combined averages", "Medium",
  "Multi-step word problem",
  r"A coaching centre admitted three batches. Batch $1$ had $30$ students with an average score of $50$ in an entrance test. When Batch $2$, with $20$ students, was included, the average of all the students became $54$. When Batch $3$, with $50$ students, was also included, the average of all the students became $60$. By how many marks does the average of Batch $3$ exceed the average of Batch $2$?",
  "TITA",
  r"After Batch $2$ is included, the total is $50 \times 54 = 2700$, so Batch $2$ totals $2700 - 1500 = 1200$, an average of $60$. After Batch $3$, the total is $100 \times 60 = 6000$, so Batch $3$ totals $3300$, an average of $66$. The difference is $66 - 60 = 6$.",
  "Comparing a batch average with a running combined average instead of with the other batch.",
  "C05B-missing-group-average", "Two successive recoveries of a group total before a comparison.",
  tita_answer=6, check=_c021,
  tita_traps=[(12, r"Compares Batch $3$'s average $66$ with the running average $54$."),
              (16, r"Compares Batch $3$'s average $66$ with Batch $1$'s average $50$.")],
  cognitive="Application")


def _c022():
    P = Fraction(10 * 70000 + 30 * 28000, 40)
    Qb = Fraction(30 * 60000 + 10 * 26000, 40)
    return Qb - P   # positive means Q higher
q("C05-B-022", TOPIC, "Overall averages reversing the team-by-team comparison of two branches", "Medium",
  "Conceptual/application",
  r"A bank has two branches, P and Q, each with a Technology team and an Admin team. Branch P has $10$ people in Technology averaging Rs. $70{,}000$ a month and $30$ in Admin averaging Rs. $28{,}000$. Branch Q has $30$ people in Technology averaging Rs. $60{,}000$ and $10$ in Admin averaging Rs. $26{,}000$. Considering all the employees of each branch, which branch has the higher average monthly salary, and by how much?",
  "MCQ",
  r"Branch P: $\frac{10 \times 70{,}000 + 30 \times 28{,}000}{40} = \frac{15{,}40{,}000}{40} = 38{,}500$. Branch Q: $\frac{30 \times 60{,}000 + 10 \times 26{,}000}{40} = \frac{20{,}60{,}000}{40} = 51{,}500$. Q is higher by Rs. $13{,}000$, even though each team in P earns more than the same team in Q, because Q has most of its staff in the better-paid team.",
  "Concluding that a branch that pays more in every team must pay more overall.",
  "C05B-simpson-reversal", "The team-wise comparison points the wrong way; only weighting reveals the answer.",
  correct=r"Branch Q, by Rs. $13{,}000$",
  distractors=[(r"Branch P, by Rs. $6{,}000$", r"Compares unweighted means of the team averages: $49{,}000$ for P against $43{,}000$ for Q."),
               (r"Branch Q, by Rs. $4{,}500$", r"Weights P correctly ($38{,}500$) but takes Q's figure as the unweighted mean $43{,}000$."),
               (r"Branch P, by Rs. $8{,}000$", r"Applies Q's $3 : 1$ staff mix to P as well, giving $59{,}500$ for P against $51{,}500$ for Q.")],
  check=_c022, values=[13000, -6000, 4500, -8000], cognitive="Analysis")


def _c023():
    d, m, o = symbols('d m o')   # department totals in thousands
    sol = solve([Eq(d + m, 55 * 46), Eq(m + o, 75 * 62), Eq(d + m + o, 100 * 55)], [d, m, o], dict=True)[0]
    return sol[m] / 30 * 1000
q("C05-B-023", TOPIC, "Average of one department from pairwise and overall averages", "Medium",
  "Multi-step word problem",
  r"A company has three departments: Design with $25$ employees, Marketing with $30$ and Operations with $45$. The average monthly salary of the Design and Marketing employees taken together is Rs. $46{,}000$, that of the Marketing and Operations employees together is Rs. $62{,}000$, and that of all $100$ employees is Rs. $55{,}000$. What is the average monthly salary in Marketing?",
  "MCQ",
  r"Work with totals in thousands. Design and Marketing: $55 \times 46 = 2530$; Marketing and Operations: $75 \times 62 = 4650$; all three: $100 \times 55 = 5500$. Adding the first two counts Marketing twice, so Marketing's total is $2530 + 4650 - 5500 = 1680$, and its average is $\frac{1680}{30} = 56$, that is Rs. $56{,}000$.",
  "Combining averages as if they were totals.",
  "C05B-pairwise-union-averages", "Inclusion-exclusion on totals across three groups.",
  correct=r"Rs. $56{,}000$",
  distractors=[(r"Rs. $53{,}000$", r"Adds and subtracts the averages as if they were totals: $46 + 62 - 55 = 53$ thousand."),
               (r"Rs. $54{,}000$", r"Takes Marketing's average as the mean of the two pair averages $46$ and $62$ thousand."),
               (r"Rs. $66{,}000$", r"Finds Operations' total $5500 - 2530 = 2970$ and reports its average $\frac{2970}{45} = 66$ thousand.")],
  check=_c023, values=[56000, 53000, 54000, 66000], cognitive="Analysis", exams=X2)


def _c024():
    m, s, e = symbols('m s e')
    sol = solve([Eq(3 * m + 2 * s + e, 6 * 70), Eq(m + s + e, 3 * 66)], [s, e], dict=True)[0]
    val = simplify((m + 2 * sol[s] + 3 * sol[e]) / 6)
    assert val.free_symbols == set()
    return val
q("C05-B-024", TOPIC, "Weighted average when the weights are reversed, from the simple average", "Medium",
  "Conceptual/application",
  r"Ravi's marks in Mathematics, Science and English are combined in two ways. With weights $3$, $2$ and $1$ respectively, his weighted average is $70$. His simple (unweighted) average of the three marks is $66$. What is his weighted average if the weights are $1$, $2$ and $3$ respectively?",
  "MCQ",
  r"Let the marks be $m, s, e$. Then $3m + 2s + e = 6 \times 70 = 420$ and $m + s + e = 3 \times 66 = 198$. Adding the two weighted sums gives $(3m + 2s + e) + (m + 2s + 3e) = 4(m + s + e) = 792$, so $m + 2s + 3e = 792 - 420 = 372$ and the new weighted average is $\frac{372}{6} = 62$. The two weighted averages are symmetric about the simple average $66$.",
  "Assuming reversing the weights leaves the average unchanged, or reflecting it the wrong way.",
  "C05B-reversed-weight-schemes", "Requires spotting that the two weight schemes sum to a multiple of equal weights.",
  correct=r"$62$",
  distractors=[(r"$70$", "Assumes that reversing the weights does not change the weighted average."),
               (r"$66$", "Assumes the reversed weighting gives the simple average."),
               (r"$74$", r"Reflects the wrong way: $70 + (70 - 66) = 74$.")],
  check=_c024, values=[62, 70, 66, 74], cognitive="Analysis")


def _c025():
    p, qq = symbols('p qq')
    sol = solve([Eq((p + qq) / 2, 70), Eq((40 * p + 60 * qq) / 100, 68)], [p, qq], dict=True)[0]
    return sol[p]
q("C05-B-025", TOPIC, "Section average from the true combined average and the mean of section averages", "Medium",
  "Inverse/parameter",
  r"Section P has $40$ students and Section Q has $60$ students. The mean of the two section averages is $70$, while the true average of all $100$ students is $68$. What is the average score of Section P?",
  "MCQ",
  r"Let the section averages be $p$ and $q$. Then $p + q = 140$ and $40p + 60q = 6800$, that is $2p + 3q = 340$. Subtracting $2(p + q) = 280$ gives $q = 60$, so $p = 80$. The true average is below the simple mean because the larger section has the lower average.",
  "Mixing up which section carries which weight, or mishandling the gap between the two kinds of average.",
  "C05B-average-of-averages", "Two simultaneous equations from two different kinds of average.",
  correct=r"$80$",
  distractors=[(r"$60$", r"Swaps the section sizes, writing $60p + 40q = 6800$, which gives $p = 60$."),
               (r"$75$", r"Writes the gap between the two averages as $(0.6 - 0.4)(p - q) = 2$, giving $p - q = 10$; the gap is actually $0.1(p - q)$."),
               (r"$90$", r"Finds $p - q = 20$ correctly but adds all of it to $70$ instead of half of it.")],
  check=_c025, values=[80, 60, 75, 90], cognitive="Analysis", exams=X2)


def _c026():
    x = symbols('x')
    return _sol1(Eq(8 * 84 + 10 * 36 + 22 * x, 40 * 61), x)
q("C05-B-026", TOPIC, "Average of the middle group from the class, top and bottom averages", "Medium",
  "Multi-step word problem",
  r"In a class of $40$ students, the top $8$ scorers in a test average $84$ and the bottom $10$ scorers average $36$. The class average is $61$. What is the average score of the remaining $22$ students?",
  "MCQ",
  r"The class total is $40 \times 61 = 2440$. The top $8$ contribute $8 \times 84 = 672$ and the bottom $10$ contribute $10 \times 36 = 360$, leaving $2440 - 1032 = 1408$ for the middle $22$ students, an average of $\frac{1408}{22} = 64$.",
  "Treating three groups of different sizes as if they were equal, or assuming the middle group sits at the class average.",
  "C05B-three-part-split", "Three unequal groups; totals must be used throughout.",
  correct=r"$64$",
  distractors=[(r"$63$", r"Treats the three groups as equal in size: $3 \times 61 - 84 - 36 = 63$."),
               (r"$60$", r"Takes the midpoint of the top and bottom averages, $\frac{84 + 36}{2}$."),
               (r"$61$", "Assumes the middle group averages exactly the class average.")],
  check=_c026, values=[64, 63, 60, 61], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (9)

def _c027():
    k, x = symbols('k x', positive=True)
    sol = solve([Eq(40 * 52 + k * x, 53 * (40 + k)), Eq(30 * 76 - k * x, 78 * (30 - k))], [k, x], dict=True)
    assert len(sol) == 1
    return sol[0][x]
q("C05-B-027", TOPIC, "Average of students moved between sections when both averages rise", "Difficult",
  "Multi-step word problem",
  r"Section P has $40$ students with an average score of $52$, and Section Q has $30$ students with an average score of $76$. Some students are moved from Q to P, keeping their scores. Afterwards, the average of P is $53$ and the average of Q is $78$. What is the average score of the students who were moved?",
  "TITA",
  r"The overall total $40 \times 52 + 30 \times 76 = 2080 + 2280 = 4360$ does not change. If $k$ students move, $53(40 + k) + 78(30 - k) = 4360$, so $4460 - 25k = 4360$ and $k = 4$. P's total rises from $2080$ to $53 \times 44 = 2332$, so the movers total $252$ and average $\frac{252}{4} = 63$. Students scoring between the two old averages raise both averages when they move.",
  "Trying to find the movers' average without first fixing how many moved, using the conserved total.",
  "C05B-transfer-between-groups", "Two unknowns (count and average) linked through a conserved total; non-obvious first step.",
  tita_answer=63, check=_c027,
  tita_traps=[(4, "Reports the number of students moved instead of their average."),
              (62, r"Uses P's old average $52$ as the base in the shortcut: $52 + \frac{40 \times 1}{4} = 62$."),
              (65, r"Uses Q's new average $78$ as the base in the shortcut: $78 - \frac{26 \times 2}{4} = 65$.")],
  cognitive="Analysis", exams=X2)


def _c028():
    m1, w1, m2, w2 = symbols('m1 w1 m2 w2')
    sol = solve([Eq(m1 + w1 + m2 + w2, 100),
                 Eq(50 * m1 + 40 * m2, 46 * (m1 + m2)),
                 Eq(60 * w1 + 45 * w2, 54 * (w1 + w2)),
                 Eq(50 * m1 + 60 * w1, 56 * (m1 + w1))], [m1, w1, m2, w2], dict=True)
    assert len(sol) == 1
    return sol[0][w2]
q("C05-B-028", TOPIC, "Headcount in one office-gender cell from office-wise and gender-wise averages", "Difficult",
  "Multi-step word problem",
  r"A firm has offices in Mumbai and Pune, with $100$ employees in all. In Mumbai, the men average Rs. $50{,}000$ a month and the women Rs. $60{,}000$; in Pune, the men average Rs. $40{,}000$ and the women Rs. $45{,}000$. Across both offices, the men average Rs. $46{,}000$ and the women Rs. $54{,}000$. The Mumbai office as a whole averages Rs. $56{,}000$. How many women work in the Pune office?",
  "MCQ",
  r"Men, Mumbai : Pune $= (46 - 40) : (50 - 46) = 3 : 2$. Women, Mumbai : Pune $= (54 - 45) : (60 - 54) = 3 : 2$. Since both splits are $3 : 2$, Mumbai has $\frac{3}{5}$ of all $100$ employees, that is $60$, and Pune has $40$. In Mumbai, men : women $= (60 - 56) : (56 - 50) = 2 : 3$, so $24$ men and $36$ women. The men's split then gives $16$ men in Pune, so Pune has $40 - 16 = 24$ women.",
  "Losing track of which cell (office and gender) the balance ratios refer to.",
  "C05B-cross-classified-groups", "Three balance ratios across a two-way classification must be chained to reach one cell.",
  correct=r"$24$",
  distractors=[(r"$36$", "Reports the number of women in the Mumbai office."),
               (r"$16$", "Reports the number of men in the Pune office."),
               (r"$20$", r"Finds Pune's $40$ employees and assumes they are split equally between men and women.")],
  check=_c028, values=[24, 36, 16, 20], cognitive="Analysis", exams=X2)


def _c029():
    vals = set()
    for qn in range(3, 22):
        avg = Fraction(45 * (24 - qn) + 75 * qn, 24)
        if avg.denominator == 1 and avg > 55:
            vals.add(qn)
    return len(vals)
q("C05-B-029", TOPIC, "Counting group sizes that make the combined average an integer above a bound", "Difficult",
  "Casework/optimisation",
  r"Two sections, P and Q, have $24$ students in all, and each section has at least $3$ students. In a test, the students of P average $45$ and the students of Q average $75$. The average of all $24$ students is a whole number greater than $55$. How many different values can the number of students in Q take?",
  "TITA",
  r"With $q$ students in Q, the overall average is $\frac{45(24 - q) + 75q}{24} = 45 + \frac{5q}{4}$. This is a whole number only when $q$ is a multiple of $4$, and it exceeds $55$ only when $q > 8$. With $3 \le q \le 21$, the possibilities are $q = 12, 16, 20$, giving averages $60, 65, 70$. So there are $3$ values.",
  "Including the boundary case where the average equals the bound, or forgetting one of the conditions.",
  "C05B-integer-combined-average", "Combines an integrality condition, a strict bound and size limits.",
  tita_answer=3, check=_c029,
  tita_traps=[(4, r"Includes $q = 8$, where the average is exactly $55$, not greater than $55$."),
              (5, r"Ignores the condition that the average exceeds $55$ and counts $q = 4, 8, 12, 16, 20$.")],
  cognitive="Analysis", exams=X2)


def _c030():
    best = None
    for m in range(1, 30):
        for e in range(1, 30 - m):
            t = 30 - m - e
            if t >= 1 and 80 * m + 60 * e + 30 * t == 55 * 30 and e > m:
                best = t if best is None or t > best else best
    return best
q("C05-B-030", TOPIC, "Largest possible size of a salary grade from the overall average with integer headcounts", "Difficult",
  "Casework/optimisation",
  r"A firm has $30$ employees in three grades, with at least one employee in each grade. Managers average Rs. $80{,}000$ a month, executives Rs. $60{,}000$ and assistants Rs. $30{,}000$, and the average for all $30$ employees is Rs. $55{,}000$. There are more executives than managers. What is the largest possible number of assistants?",
  "MCQ",
  r"Let there be $m$ managers, $e$ executives and $t$ assistants. In thousands, $m + e + t = 30$ and $80m + 60e + 30t = 1650$. Subtracting $30$ times the first equation gives $50m + 30e = 750$, that is $5m + 3e = 75$, so $m$ is a multiple of $3$, $e = 25 - \frac{5m}{3}$ and $t = 5 + \frac{2m}{3}$. The cases are $(m, e, t) = (3, 20, 7), (6, 15, 9), (9, 10, 11), (12, 5, 13)$. The last has fewer executives than managers, so the largest possible number of assistants is $11$.",
  "Missing the extra condition after listing the integer solutions, or stopping at the first solution found.",
  "C05B-integer-grade-headcounts", "Diophantine reduction with three groups, then a side condition that removes the extreme case.",
  correct=r"$11$",
  distractors=[(r"$13$", r"Takes the case $(12, 5, 13)$, which has fewer executives than managers."),
               (r"$9$", r"Stops at the case $(6, 15, 9)$ without checking larger values of $m$."),
               (r"$7$", r"Stops at the first case found, $(3, 20, 7)$.")],
  check=_c030, values=[11, 13, 9, 7], cognitive="Analysis", exams=X2)


def _c031():
    ne, nt, s = symbols('ne nt s', positive=True)
    # engineers earn 2s, technicians s
    before = ne * 2 * s + nt * s
    after = ne * 2 * s * Rational(110, 100) + nt * s * Rational(125, 100)
    r = _sol1(Eq(after.subs(ne, symbols('rr') * nt), Rational(116, 100) * before.subs(ne, symbols('rr') * nt)), symbols('rr'))
    return r
q("C05-B-031", TOPIC, "Headcount ratio from group raises, overall raise and salary multiple", "Difficult",
  "Inverse/parameter",
  r"In a factory, the average salary of the engineers is twice the average salary of the technicians. The engineers receive a $10\%$ raise and the technicians a $25\%$ raise, the headcount does not change, and the average salary of all the staff rises by $16\%$. What is the ratio of the number of engineers to the number of technicians?",
  "MCQ",
  r"The overall rise is the salary-bill weighted average of $10\%$ and $25\%$, so engineers' bill : technicians' bill $= (25 - 16) : (16 - 10) = 3 : 2$. Each engineer earns twice as much as a technician, so the headcounts are in ratio $\frac{3}{2} : \frac{2}{1} = 3 : 4$. Check: $3$ engineers at $2$ units and $4$ technicians at $1$ unit give a bill of $10$ units and a raise of $0.6 + 1 = 1.6$ units, which is $16\%$.",
  "Treating the bill ratio as the headcount ratio, or adjusting for the salary multiple in the wrong direction.",
  "C05B-group-raises", "Two layers: balance on bills, then convert bills to headcounts via the salary multiple.",
  correct=r"$3 : 4$",
  distractors=[(r"$3 : 2$", "Reports the ratio of the salary bills as the ratio of headcounts."),
               (r"$2 : 3$", r"Inverts the balance ratio on bills and does not adjust for the salary multiple."),
               (r"$3 : 1$", r"Multiplies the bill ratio by the salary multiple instead of dividing: $3 \times 2 : 2$.")],
  check=_c031, values=[Fraction(3, 4), Fraction(3, 2), Fraction(2, 3), 3], cognitive="Analysis", exams=X2)


def _c032():
    a, W = symbols('a W')
    sol = solve([Eq(a * W + 40, (a - 1) * (W + 5)),
                 Eq((a - 1) * (W + 5) + 87, (a - Rational(1, 2)) * (W + 7))], [a, W], dict=True)
    assert len(sol) == 1
    return sol[0][W]
q("C05-B-032", TOPIC, "Earlier wicket count from bowling-average changes over two matches", "Difficult",
  "Multi-step word problem",
  r"A bowler's bowling average is the number of runs he has conceded per wicket taken. In one match he took $5$ wickets for $40$ runs, and his bowling average fell by exactly $1$. In his next match he took $2$ wickets for $87$ runs, and his bowling average rose by exactly $0.5$. How many wickets had he taken before the first of these two matches?",
  "TITA",
  r"Let his average be $a$ over $W$ wickets before the first match. First match: $aW + 40 = (a - 1)(W + 5)$, which simplifies to $W = 5a - 45$. Second match: $(a - 1)(W + 5) + 87 = (a - 0.5)(W + 7)$, which simplifies to $W = 171 - 4a$. Equating, $9a = 216$, so $a = 24$ and $W = 75$. Check: $\frac{1800 + 40}{80} = 23$ and $\frac{1840 + 87}{82} = 23.5$.",
  "Measuring the second change from the original average instead of from the average after the first match.",
  "C05B-bowling-average-change", "Two unknowns from two sequential changes; each equation must use the right running total.",
  tita_answer=75, check=_c032,
  tita_traps=[(80, "Reports the wickets after the first match."),
              (82, "Reports the wickets after both matches.")],
  cognitive="Analysis", exams=X2)


def _c033():
    p, qq, r = symbols('p qq r', positive=True)
    ratio_pq = _sol1(Eq((640 * p + 560) / (p + 1), 620), p)          # with qq = 1
    ratio_rq = _sol1(Eq((560 + 360 * r) / (1 + r), 400), r)          # with qq = 1
    return (640 * ratio_pq + 560 + 360 * ratio_rq) / (ratio_pq + 1 + ratio_rq)
q("C05-B-033", TOPIC, "Overall average of three plants from individual and pairwise averages", "Difficult",
  "Multi-step word problem",
  r"A company runs three plants, P, Q and R, whose workers earn average daily wages of Rs. $640$, Rs. $560$ and Rs. $360$ respectively. The workers of P and Q together average Rs. $620$ a day, and the workers of Q and R together average Rs. $400$ a day. What is the average daily wage of all the workers of the three plants together?",
  "MCQ",
  r"From P and Q: P : Q $= (620 - 560) : (640 - 620) = 60 : 20 = 3 : 1$. From Q and R: Q : R $= (400 - 360) : (560 - 400) = 40 : 160 = 1 : 4$. So P : Q : R $= 3 : 1 : 4$, and the overall average is $\frac{3 \times 640 + 560 + 4 \times 360}{8} = \frac{1920 + 560 + 1440}{8} = \frac{3920}{8} = 490$.",
  "Averaging averages or treating averages as additive instead of chaining the two size ratios.",
  "C05B-chained-group-ratios", "Two balance ratios must be chained through the common group before weighting.",
  correct=r"Rs. $490$",
  distractors=[(r"Rs. $520$", r"Takes the simple mean of the three plant averages."),
               (r"Rs. $510$", r"Takes the simple mean of the two pair averages $620$ and $400$."),
               (r"Rs. $460$", r"Adds the pair averages and subtracts Q's average: $620 + 400 - 560$.")],
  check=_c033, values=[490, 520, 510, 460], cognitive="Analysis", exams=X2)


def _c034():
    s0, t0 = 25, 75
    s1, t1 = Fraction(s0) * Fraction(120, 100), Fraction(t0) * Fraction(60, 100)
    a0 = Fraction(s0 * 20000 + t0 * 60000, s0 + t0)
    a1 = (s1 * 20000 + t1 * 60000) / (s1 + t1)
    return (a0 - a1) / a0 * 100
q("C05-B-034", TOPIC, "Fall in overall average salary caused only by a change in headcount mix", "Difficult",
  "Conceptual/application",
  r"In 2024, $25\%$ of a firm's employees worked in Sales at an average monthly salary of Rs. $20{,}000$, and the rest worked in Technology at an average monthly salary of Rs. $60{,}000$. In 2025, the Sales headcount rose by $20\%$ and the Technology headcount fell by $40\%$, while the average salary within each department stayed the same. By what percentage did the average monthly salary of the firm's employees fall from 2024 to 2025?",
  "MCQ",
  r"Per $100$ employees in 2024: $25$ in Sales and $75$ in Technology, an average of $\frac{25 \times 20{,}000 + 75 \times 60{,}000}{100} = 50{,}000$. In 2025: $30$ in Sales and $45$ in Technology, an average of $\frac{30 \times 20{,}000 + 45 \times 60{,}000}{75} = \frac{33{,}00{,}000}{75} = 44{,}000$. The fall is $\frac{6{,}000}{50{,}000} = 12\%$; the mix has shifted towards the lower-paid department.",
  "Confusing the change in the total bill with the change in the average, or averaging the headcount changes.",
  "C05B-headcount-mix-shift", "Average falls with no salary change; needs both bill and headcount to move correctly.",
  correct=r"$12\%$",
  distractors=[(r"$34\%$", r"Reports the fall in the total salary bill, from $50{,}00{,}000$ to $33{,}00{,}000$ per $100$ original employees."),
               (r"$9\%$", r"Subtracts the $25\%$ fall in headcount from the $34\%$ fall in the bill instead of comparing the ratio of averages."),
               (r"$10\%$", r"Takes the simple mean of the headcount changes $+20\%$ and $-40\%$.")],
  check=_c034, values=[12, 34, 9, 10], cognitive="Analysis", exams=X2)


def _c035():
    d = symbols('d', positive=True)
    dis = _sol1(Eq(40 * d + 90, Rational(85, 2) * d), d)   # not out: dismissals unchanged
    runs = 40 * dis + 90
    x = symbols('x')
    return _sol1(Eq((runs + x) / (dis + 1), 42), x)
q("C05-B-035", TOPIC, "Score in an innings after a not-out innings changes the batting average", "Difficult",
  "Inverse/parameter",
  r"A batsman's batting average is his total runs divided by the number of times he has been dismissed. At one stage of his career his batting average was $40$. In his next innings he scored $90$ and remained not out, and his batting average rose to $42.5$. In the innings after that he was dismissed, and his batting average became $42$. How many runs did he score in that last innings?",
  "MCQ",
  r"A not-out innings adds runs but no dismissal. With $d$ dismissals, $40d + 90 = 42.5d$, so $d = 36$ and his runs become $1440 + 90 = 1530$. After the last innings he has $37$ dismissals at an average of $42$, that is $1554$ runs, so he scored $1554 - 1530 = 24$.",
  "Counting the not-out innings as a dismissal.",
  "C05B-batting-not-outs", "The key step is seeing that the not-out innings leaves the dismissal count unchanged; two linked stages, each with a natural trap.",
  correct=r"$24$",
  distractors=[(r"$32$", r"Counts the not-out innings as a dismissal: $40d + 90 = 42.5(d + 1)$ gives $d = 19$ and $850$ runs, then $21 \times 42 - 850 = 32$."),
               (r"$114$", r"Leaves the $90$ not-out runs out of the running total: $37 \times 42 - 36 \times 40 = 1554 - 1440 = 114$."),
               (r"$66$", r"Finds $d = 36$ correctly but counts the not-out innings as a dismissal in the last step: $38 \times 42 - 1530 = 66$.")],
  check=_c035, values=[24, 32, 114, 66], cognitive="Analysis", exams=X2)
