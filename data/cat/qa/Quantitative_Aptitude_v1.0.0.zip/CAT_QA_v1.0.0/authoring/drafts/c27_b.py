import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds

T = "Maximum and minimum overlaps"
SPEED = ("CAT", "XAT")


def _regs(k):
    return list(itertools.product((0, 1), repeat=k))


def _opt(k, cons, obj, sense, total=None):
    """Integer programme over the 2^k Venn regions (counts >= 0).
    cons: list of (coef(region), lo, hi). obj: coef(region). Returns the optimum value."""
    regs = _regs(k)
    A, lo, hi = [], [], []
    if total is not None:
        A.append([1] * len(regs)); lo.append(total); hi.append(total)
    for f, a, b in cons:
        A.append([f(r) for r in regs]); lo.append(a); hi.append(b)
    c = np.array([obj(r) for r in regs], dtype=float)
    if sense == "max":
        c = -c
    res = milp(c, constraints=LinearConstraint(np.array(A, dtype=float), lo, hi),
               integrality=np.ones(len(regs)), bounds=Bounds(0, np.inf))
    assert res.status == 0, res.message
    v = -res.fun if sense == "max" else res.fun
    return int(round(v))


def _feasible(k, cons, total=None):
    regs = _regs(k)
    A, lo, hi = [], [], []
    if total is not None:
        A.append([1] * len(regs)); lo.append(total); hi.append(total)
    for f, a, b in cons:
        A.append([f(r) for r in regs]); lo.append(a); hi.append(b)
    res = milp(np.zeros(len(regs)), constraints=LinearConstraint(np.array(A, dtype=float), lo, hi),
               integrality=np.ones(len(regs)), bounds=Bounds(0, np.inf))
    return res.status == 0


def _size(i, v):
    return (lambda r, i=i: r[i], v, v)


def _sizes(vals):
    return [_size(i, v) for i, v in enumerate(vals)]


def _two_set_range(N, a, b, cond=lambda both, none: True):
    """Brute force over the overlap x of two sets of sizes a, b in a group of N."""
    ok = []
    for x in range(0, min(a, b) + 1):
        none = N - (a + b - x)
        if none < 0:
            continue
        if cond(x, none):
            ok.append((x, none))
    return ok


# ---------------------------------------------------------------- EASY

def _c1():
    return min(x for x, _ in _two_set_range(60, 42, 35))
q("C27-B-001", T, "Least possible overlap of two sets in a class when some may belong to neither", "Easy",
  "Single-step computation",
  r"In a class of $60$ students, $42$ play cricket and $35$ play football. Some students may play neither game. What is the least possible number of students who play both games?",
  "MCQ",
  r"The number playing at least one game cannot exceed $60$. So both $= 42 + 35 - (\text{at least one}) \ge 77 - 60 = 17$. This is attained when every student plays at least one game, so the least value is $17$.",
  "Confusing the least overlap with the greatest overlap, or subtracting one set size from the other.",
  "C27B-two-set-least-overlap", "One idea: the union is capped by the class size.",
  correct=r"$17$",
  distractors=[(r"$35$", r"Gives the greatest possible overlap, when all football players also play cricket."),
               (r"$7$", r"Subtracts the set sizes: $42 - 35 = 7$."),
               (r"$18$", r"Reports the number who do not play cricket: $60 - 42 = 18$.")],
  check=_c1, values=[17, 35, 7, 18], cognitive="Application")


def _c2():
    return max(none for _, none in _two_set_range(200, 130, 90))
q("C27-B-002", T, "Greatest possible number in neither of two sets", "Easy",
  "Conceptual/application",
  r"In a survey of $200$ households, $130$ own a car and $90$ own a two-wheeler. What is the greatest possible number of households that own neither a car nor a two-wheeler?",
  "TITA",
  r"Households owning neither are as many as possible when the union is as small as possible. The union is at least $130$, and equals $130$ when every two-wheeler owner also owns a car. Then neither $= 200 - 130 = 70$.",
  "Making the overlap as small as possible, which minimises rather than maximises the number owning neither.",
  "C27B-two-set-neither-bounds", "One idea: nest the smaller set inside the larger to shrink the union.",
  tita_answer=70, check=_c2,
  tita_traps=[(0, r"Makes the overlap as small as possible; since $130 + 90 > 200$ this gives the least number owning neither, $0$."),
              (110, r"Takes the smaller set ($90$) as the least possible union, giving $200 - 90 = 110$.")],
  cognitive="Understanding")


def _c3():
    return _opt(2, [(lambda r: r[0], 72, 72), (lambda r: r[1], 58, 58)],
                lambda r: 1 if sum(r) == 1 else 0, "max", total=100)
q("C27-B-003", T, "Greatest percentage in exactly one of two sets", "Easy",
  "Casework/optimisation",
  r"In a company, $72\%$ of the employees speak Hindi and $58\%$ speak Marathi. Some employees may speak neither language. What is the greatest possible percentage of employees who speak exactly one of these two languages?",
  "MCQ",
  r"If $x\%$ speak both, exactly one $= (72 - x) + (58 - x) = 130 - 2x$. This is largest when $x$ is smallest. Since at most $100\%$ speak at least one, $x \ge 130 - 100 = 30$. So the greatest value is $130 - 60 = 70\%$.",
  "Treating 'exactly one' as 'at least one', or minimising the wrong quantity.",
  "C27B-exactly-one-bounds", "Two short steps: express exactly one in terms of the overlap, then use the least overlap.",
  correct=r"$70\%$",
  distractors=[(r"$100\%$", r"Computes the number speaking at least one, $130 - x$ with $x = 30$, which counts the overlap once."),
               (r"$30\%$", r"Reports the least possible overlap itself."),
               (r"$14\%$", r"Uses the greatest overlap $x = 58$, which gives the least value $130 - 116 = 14\%$.")],
  check=_c3, values=[70, 100, 30, 14], cognitive="Application")


def _c4():
    # pass both = 100 - (fail at least one); fail sets 20 and 25
    return 100 - _opt(2, [(lambda r: r[0], 20, 20), (lambda r: r[1], 25, 25)],
                      lambda r: 1 if sum(r) >= 1 else 0, "max", total=100)
q("C27-B-004", T, "Least percentage passing both papers from failure percentages", "Easy",
  "Multi-step word problem",
  r"Every student in an examination wrote both a Mathematics paper and an English paper. $20\%$ of the students failed in Mathematics and $25\%$ failed in English. What is the least possible percentage of students who passed in both papers?",
  "MCQ",
  r"Passing both is the complement of failing at least one. Failing at least one is largest when no student failed both, giving $20 + 25 = 45\%$. Hence the least percentage passing both is $100 - 45 = 55\%$.",
  "Assuming the failures are nested, or multiplying pass rates as if the papers were independent.",
  "C27B-failure-complement", "One complement step with a single trap about which overlap to choose.",
  correct=r"$55\%$",
  distractors=[(r"$75\%$", r"Gives the greatest possible value, when every Mathematics failure also failed English."),
               (r"$60\%$", r"Treats the papers as independent: $0.8 \times 0.75 = 0.6$."),
               (r"$45\%$", r"Reports the percentage who failed at least one paper.")],
  check=_c4, values=[55, 75, 60, 45], cognitive="Application")


def _c5():
    vals = [none for _, none in _two_set_range(120, 70, 85)]
    return (min(vals), max(vals))
q("C27-B-005", T, "Least and greatest number in neither of two sets", "Easy",
  "Conceptual/application",
  r"A library has $120$ members. Of these, $70$ read fiction and $85$ read non-fiction; some members may read neither. If $n$ members read neither fiction nor non-fiction, the least and greatest possible values of $n$ are",
  "MCQ",
  r"$n = 120 - (\text{union})$. The union is at most $120$ (possible because $70 + 85 = 155 \ge 120$), so the least $n$ is $0$. The union is at least $85$, attained when every fiction reader also reads non-fiction, so the greatest $n$ is $120 - 85 = 35$.",
  "Pairing the wrong set with each bound, or using the difference of set sizes.",
  "C27B-two-set-neither-bounds", "Two bounds from one idea: union between the larger set and the group size.",
  correct=r"$0$ and $35$",
  distractors=[(r"$35$ and $50$", r"Takes $120 - 85$ and $120 - 70$ as the two bounds."),
               (r"$0$ and $50$", r"Uses the smaller set for the greatest value: $120 - 70 = 50$."),
               (r"$15$ and $35$", r"Uses $85 - 70 = 15$ as the least value.")],
  check=_c5, values=[(0, 35), (35, 50), (0, 50), (15, 35)], cognitive="Understanding")


def _c6():
    return len(_two_set_range(50, 32, 27))
q("C27-B-006", T, "Number of possible values of a two-set overlap", "Easy",
  "Casework/optimisation",
  r"In a group of $50$ people, $32$ like tea and $27$ like coffee. Some people may like neither. How many different values are possible for the number of people who like both tea and coffee?",
  "TITA",
  r"Least overlap: $32 + 27 - 50 = 9$. Greatest overlap: $27$, when every coffee lover also likes tea. Every integer from $9$ to $27$ is possible, so there are $27 - 9 + 1 = 19$ values.",
  "Off by one when counting the integers in a closed range.",
  "C27B-overlap-range-count", "Two bounds and an inclusive count; the off-by-one is the trap.",
  tita_answer=19, check=_c6,
  tita_traps=[(18, r"Counts $27 - 9 = 18$, dropping one endpoint."),
              (28, r"Takes the least overlap as $0$ and counts $0$ to $27$.")],
  cognitive="Application")


def _c7():
    return _opt(3, _sizes([90, 80, 75]), lambda r: 1 if sum(r) == 3 else 0, "min", total=100)
q("C27-B-007", T, "Least percentage in all three of three sets", "Easy",
  "Single-step computation",
  r"In a large office, $90\%$ of the staff have a smartphone, $80\%$ have a laptop and $75\%$ have a smartwatch. What is the least possible percentage of staff who have all three?",
  "MCQ",
  r"Work with the complements: $10\%$ lack a smartphone, $20\%$ lack a laptop, $25\%$ lack a smartwatch. At most $10 + 20 + 25 = 55\%$ lack at least one item, so at least $100 - 55 = 45\%$ have all three, attained when the three 'lacking' groups do not overlap.",
  "Applying the two-set formula to only two of the sets, or assuming independence.",
  "C27B-all-k-least-percent", "One complement idea across three sets.",
  correct=r"$45\%$",
  distractors=[(r"$54\%$", r"Assumes independence: $0.9 \times 0.8 \times 0.75 = 0.54$."),
               (r"$75\%$", r"Gives the greatest possible value, the size of the smallest set."),
               (r"$70\%$", r"Uses only the two largest sets: $90 + 80 - 100 = 70$.")],
  check=_c7, values=[45, 54, 75, 70], cognitive="Application")


def _c8():
    # every student plays at least one; >= 5 play only kabaddi; minimise class size
    return _opt(2, [(lambda r: r[0], 26, 26), (lambda r: r[1], 19, 19),
                    (lambda r: 1 if r == (0, 1) else 0, 5, 1000),
                    (lambda r: 1 if r == (0, 0) else 0, 0, 0)],
                lambda r: 1, "min")
q("C27-B-008", T, "Least group size with a lower bound on one exclusive region", "Easy",
  "Inverse/parameter",
  r"Every student in a class plays at least one of hockey and kabaddi. $26$ students play hockey and $19$ play kabaddi. At least $5$ students play kabaddi but not hockey. What is the least possible number of students in the class?",
  "TITA",
  r"Class size $= (\text{hockey players}) + (\text{kabaddi only}) = 26 + (\text{kabaddi only})$. Since kabaddi only is at least $5$, the class has at least $31$ students. This is attained with $14$ students playing both, so the answer is $31$.",
  "Nesting the kabaddi players fully inside the hockey players and ignoring the extra condition.",
  "C27B-least-group-size", "One idea with one condition that blocks the naive nested answer.",
  tita_answer=31, check=_c8,
  tita_traps=[(26, r"Ignores the 'at least $5$ kabaddi only' condition and nests the sets."),
              (45, r"Adds the two set sizes, as if no one played both.")],
  cognitive="Application")


def _c9():
    return min(x for x, _ in _two_set_range(90, 54, 47, cond=lambda x, none: none >= 10))
q("C27-B-009", T, "Least two-set overlap when a minimum number lie outside both sets", "Easy",
  "Multi-step word problem",
  r"A firm has $90$ employees. $54$ of them opted for a health plan and $47$ opted for a pension plan. At least $10$ employees opted for neither plan. What is the least possible number of employees who opted for both plans?",
  "MCQ",
  r"At least $10$ opted for neither, so at most $80$ opted for at least one plan. Then both $\ge 54 + 47 - 80 = 21$. With $21$ in both, exactly $10$ opt for neither, so $21$ is attained.",
  "Using the whole firm of $90$ as the cap on the union and ignoring the employees who opted for neither.",
  "C27B-two-set-least-overlap", "One overlap formula with a reduced cap on the union.",
  correct=r"$21$",
  distractors=[(r"$11$", r"Ignores the 'neither' condition: $54 + 47 - 90 = 11$."),
               (r"$47$", r"Gives the greatest possible overlap."),
               (r"$7$", r"Subtracts the plan sizes: $54 - 47 = 7$.")],
  check=_c9, values=[21, 11, 47, 7], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM

def _c10():
    return _opt(3, _sizes([340, 300, 280]) + [(lambda r: 1 if sum(r) == 0 else 0, 20, 1000)],
                lambda r: 1 if sum(r) == 3 else 0, "min", total=400)
q("C27-B-010", T, "Least count in all three sets via complements when some have none", "Medium",
  "Multi-step word problem",
  r"A company has $400$ employees. $340$ of them have a smartphone, $300$ have a laptop and $280$ have a tablet. At least $20$ employees have none of the three devices. What is the least possible number of employees who have all three devices?",
  "TITA",
  r"Count the missing devices: $60 + 100 + 120 = 280$. Each of the $n \ge 20$ employees with no device accounts for $3$ of these, and every other employee lacking something accounts for at least $1$. So at most $n + (280 - 3n) = 280 - 2n \le 240$ employees lack at least one device, and at least $400 - 240 = 160$ have all three. This is attained with $20$ having none and $40$, $80$, $100$ employees lacking only a smartphone, only a laptop, only a tablet.",
  "Treating the employees with no device as if each lacked only one device.",
  "C27B-all-k-least-percent", "Complement argument across three sets plus a second idea: each 'none' person uses up three missing devices.",
  tita_answer=160, check=_c10,
  tita_traps=[(120, r"Ignores the 'none' condition and uses $400 - 280 = 120$."),
              (100, r"Subtracts the $20$ with no device from the unconstrained bound: $120 - 20 = 100$.")],
  cognitive="Application")


def _c11():
    return _opt(4, _sizes([460, 440, 425, 400]), lambda r: 1 if sum(r) == 4 else 0, "min", total=500)
q("C27-B-011", T, "Least count in all four of four sets", "Medium",
  "Multi-step word problem",
  r"In a survey of $500$ home buyers, $460$ wanted covered parking, $440$ wanted power backup, $425$ wanted a gym and $400$ wanted a swimming pool. What is the least possible number of buyers who wanted all four amenities?",
  "MCQ",
  r"The numbers not wanting each amenity are $40$, $60$, $75$ and $100$, a total of $275$. So at most $275$ buyers miss at least one amenity, and at least $500 - 275 = 225$ wanted all four. Equality holds when the four 'not wanting' groups are disjoint.",
  "Using a three-set version of the formula, or reporting the complement total.",
  "C27B-all-k-least-percent", "Extends the complement argument to four sets; the three-set shortcut fails.",
  correct=r"$225$",
  distractors=[(r"$400$", r"Gives the greatest possible value, the size of the smallest set."),
               (r"$325$", r"Uses only the first three amenities: $460 + 440 + 425 - 2 \times 500 = 325$."),
               (r"$275$", r"Reports the total of the 'not wanting' counts, $40 + 60 + 75 + 100$.")],
  check=_c11, values=[225, 400, 325, 275], cognitive="Application", exams=SPEED)


def _c12():
    return _opt(3, _sizes([70, 65, 55]) + [(lambda r: 1 if sum(r) == 0 else 0, 0, 0)],
                lambda r: 1 if sum(r) == 3 else 0, "max", total=120)
q("C27-B-012", T, "Greatest number in all three sets when everyone is in at least one", "Medium",
  "Casework/optimisation",
  r"Each of the $120$ students in a language school studies at least one of French, German and Spanish. $70$ study French, $65$ study German and $55$ study Spanish. What is the greatest possible number of students who study all three languages?",
  "MCQ",
  r"Let $e_1, e_2, e_3$ be the numbers studying exactly one, two and three languages. Then $e_1 + e_2 + e_3 = 120$ and $e_1 + 2e_2 + 3e_3 = 70 + 65 + 55 = 190$, so $e_2 + 2e_3 = 70$. Hence $e_3 \le 35$, with $e_2 = 0$. This is attained: $35$ study all three and $35$, $30$, $20$ study only French, only German, only Spanish.",
  "Taking the smallest set as the greatest triple overlap without using the fact that every student is counted.",
  "C27B-at-least-two-bounds", "Requires the exactly-k equations and seeing that the excess caps the triple overlap.",
  correct=r"$35$",
  distractors=[(r"$55$", r"Takes the size of the smallest set, ignoring that all $120$ students must be covered."),
               (r"$70$", r"Reports the total excess $190 - 120 = 70$ as the triple overlap."),
               (r"$0$", r"Gives the least possible value.")],
  check=_c12, values=[35, 55, 70, 0], cognitive="Analysis")


def _c13():
    return _opt(3, _sizes([160, 140, 120]) + [(lambda r: 1 if sum(r) == 0 else 0, 40, 40)],
                lambda r: 1 if sum(r) == 1 else 0, "min", total=300)
q("C27-B-013", T, "Least number in exactly one of three sets with a fixed 'none' count", "Medium",
  "Casework/optimisation",
  r"In a housing colony of $300$ families, $160$ subscribe to a newspaper, $140$ to a magazine and $120$ to an OTT service. Exactly $40$ families subscribe to none of the three. What is the least possible number of families that subscribe to exactly one of the three?",
  "TITA",
  r"$260$ families subscribe to at least one. With $e_1, e_2, e_3$ for exactly one, two, three: $e_1 + e_2 + e_3 = 260$ and $e_1 + 2e_2 + 3e_3 = 420$, so $e_2 + 2e_3 = 160$ and $e_1 = 260 - e_2 - e_3 = 100 + e_3$. The least value is $100$, with $e_3 = 0$ and $e_2 = 160$ (for example $40$ newspaper and magazine, $20$ newspaper and OTT, $100$ magazine and OTT, and $100$ newspaper only).",
  "Assuming exactly one can be pushed to $0$ by making overlaps large, without using the equations.",
  "C27B-exactly-one-bounds", "Needs two counting equations and the sign of the dependence on the triple overlap.",
  tita_answer=100, check=_c13,
  tita_traps=[(0, r"Assumes every subscriber can be placed in two or more sets."),
              (180, r"Gives the greatest possible value, reached when $e_3 = 80$.")],
  cognitive="Analysis")


def _c14():
    return _opt(3, _sizes([70, 60, 50]) + [(lambda r: 1 if sum(r) == 0 else 0, 0, 0)],
                lambda r: 1 if sum(r) >= 2 else 0, "min", total=100)
q("C27-B-014", T, "Least number in at least two of three sets", "Medium",
  "Casework/optimisation",
  r"Each of $100$ people in a group likes at least one of three snacks: samosa, dhokla and vada pav. $70$ like samosa, $60$ like dhokla and $50$ like vada pav. What is the least possible number of people who like at least two of the three snacks?",
  "MCQ",
  r"Let $e_1, e_2, e_3$ be the numbers liking exactly one, two and three snacks. Then $e_1 + e_2 + e_3 = 100$ and $e_1 + 2e_2 + 3e_3 = 180$, so $e_2 + 2e_3 = 80$. The number liking at least two is $e_2 + e_3 = 80 - e_3$, smallest when $e_3$ is largest. With $e_2 = 0$, $e_3 = 40$, giving $40$; this works with $40$ liking all three and $30$, $20$, $10$ liking only one snack each.",
  "Minimising the triple overlap instead of maximising it.",
  "C27B-at-least-two-bounds", "Non-obvious direction: the at-least-two count falls as the triple overlap rises.",
  correct=r"$40$",
  distractors=[(r"$80$", r"Sets $e_3 = 0$, which gives the greatest possible value $e_2 = 80$."),
               (r"$20$", r"Reports the least possible number liking exactly one snack."),
               (r"$50$", r"Takes the size of the smallest set.")],
  check=_c14, values=[40, 80, 20, 50], cognitive="Analysis")


def _c15():
    return _opt(3, _sizes([90, 80, 70]) + [(lambda r: 1 if sum(r) == 0 else 0, 0, 0)],
                lambda r: 1 if sum(r) == 2 else 0, "max", total=150)
q("C27-B-015", T, "Greatest number in exactly two of three sets", "Medium",
  "Casework/optimisation",
  r"A residents' association has $150$ members, each of whom belongs to at least one of three committees. The committees have $90$, $80$ and $70$ members. What is the greatest possible number of members who belong to exactly two committees?",
  "TITA",
  r"With $e_1 + e_2 + e_3 = 150$ and $e_1 + 2e_2 + 3e_3 = 240$, we get $e_2 + 2e_3 = 90$, so $e_2 \le 90$ with $e_3 = 0$, $e_1 = 60$. This is attained, for example with $40$, $30$, $20$ members in the three pairs and $20$ members only in each committee.",
  "Confusing the greatest exactly-two count with the greatest triple count.",
  "C27B-at-least-two-bounds", "Needs the exactly-k equations and a feasibility check.",
  tita_answer=90, check=_c15,
  tita_traps=[(45, r"Computes the greatest possible number in all three committees, $90 / 2$."),
              (60, r"Reports the number in exactly one committee at the optimum.")],
  cognitive="Analysis")


def _c16():
    cons = _sizes([12, 18, 15])  # failure sets in percent
    mx = _opt(3, cons, lambda r: 1 if sum(r) >= 1 else 0, "max", total=100)
    mn = _opt(3, cons, lambda r: 1 if sum(r) >= 1 else 0, "min", total=100)
    return (100 - mx, 100 - mn)
q("C27-B-016", T, "Range of percentage passing all three subjects", "Medium",
  "Multi-step word problem",
  r"Every student of a batch wrote Physics, Chemistry and Mathematics papers. $12\%$ failed in Physics, $18\%$ in Chemistry and $15\%$ in Mathematics. If $p\%$ of the students passed in all three papers, the least and greatest possible values of $p$ are",
  "MCQ",
  r"Passing all three is the complement of failing at least one. Failing at least one is at most $12 + 18 + 15 = 45\%$ (no one fails two papers), so $p \ge 55$. It is at least $18\%$, when the other two failure groups lie inside the Chemistry failures, so $p \le 82$.",
  "Using the smaller failure set for the upper bound, or ignoring one subject.",
  "C27B-failure-complement", "Two bounds over three sets via complements.",
  correct=r"$55$ and $82$",
  distractors=[(r"$55$ and $88$", r"Uses the smallest failure group for the greatest value: $100 - 12 = 88$."),
               (r"$45$ and $82$", r"Reports the greatest failure percentage $45$ as the least pass percentage."),
               (r"$67$ and $82$", r"Drops Physics when computing the least value: $100 - 18 - 15 = 67$.")],
  check=_c16, values=[(55, 82), (55, 88), (45, 82), (67, 82)], cognitive="Application")


def _c17():
    cons = _sizes([150, 140, 130])
    f = lambda r: 1 if sum(r) == 3 else 0
    return _opt(3, cons, f, "max", total=200) - _opt(3, cons, f, "min", total=200)
q("C27-B-017", T, "Difference between greatest and least triple overlap", "Medium",
  "Multi-step word problem",
  r"In a group of $200$ students, $150$ like cricket, $140$ like football and $130$ like hockey. What is the difference between the greatest and the least possible number of students who like all three sports?",
  "MCQ",
  r"Greatest: $130$, when the hockey fans like the other two as well and the football fans like cricket. Least: the numbers not liking each sport are $50$, $60$, $70$, totalling $180$, so at least $200 - 180 = 20$ like all three. The difference is $130 - 20 = 110$.",
  "Using a two-set formula for the least value, or counting values instead of taking the difference.",
  "C27B-overlap-range-count", "Two separate bounds over three sets, then a difference.",
  correct=r"$110$",
  distractors=[(r"$40$", r"Uses the two-set least overlap $150 + 140 - 200 = 90$ as the least value: $130 - 90 = 40$."),
               (r"$130$", r"Reports only the greatest value."),
               (r"$111$", r"Counts the possible values $20, 21, \ldots, 130$ instead of taking the difference.")],
  check=_c17, values=[110, 40, 130, 111], cognitive="Application")


def _c18():
    return _opt(3, _sizes([130, 110, 90]) + [(lambda r: 1 if sum(r) == 3 else 0, 0, 0)],
                lambda r: 1 if sum(r) == 0 else 0, "max", total=200)
q("C27-B-018", T, "Greatest 'none' count when nobody is in all three sets", "Medium",
  "Conceptual/application",
  r"In a survey of $200$ people, $130$ watch news channels, $110$ watch sports channels and $90$ watch movie channels. Nobody watches all three types. What is the greatest possible number of people who watch none of the three types?",
  "MCQ",
  r"Since no one is in all three, each viewer is counted at most twice, so the number watching at least one is at least $\frac{130 + 110 + 90}{2} = 165$. This is attained with $75$ watching news and sports, $55$ news and movies, $35$ sports and movies, and nobody watching only one type. So the greatest number watching none is $200 - 165 = 35$.",
  "Nesting the sets, which is impossible when nobody may be in all three.",
  "C27B-at-most-two-least-union", "Needs the double-counting bound created by the 'nobody in all three' condition.",
  correct=r"$35$",
  distractors=[(r"$70$", r"Ignores the condition and nests the sets: $200 - 130 = 70$."),
               (r"$90$", r"Divides the total by $3$, as if a person could be counted three times: $200 - 110 = 90$."),
               (r"$0$", r"Gives the least possible value.")],
  check=_c18, values=[35, 70, 90, 0], cognitive="Analysis")


def _c19():
    return _opt(3, _sizes([24, 30, 36]) + [(lambda r: 1 if sum(r) == 3 else 0, 0, 0),
                                           (lambda r: 1 if sum(r) == 0 else 0, 0, 0)],
                lambda r: 1, "min")
q("C27-B-019", T, "Least group size when no one is in all three sets", "Medium",
  "Inverse/parameter",
  r"A firm runs three projects with $24$, $30$ and $36$ employees assigned. Every employee of the firm works on at least one project and no employee works on all three. What is the least possible number of employees in the firm?",
  "TITA",
  r"Each employee is counted at most twice in $24 + 30 + 36 = 90$, so there are at least $45$ employees. With $9$ on the first two projects, $15$ on the first and third, and $21$ on the second and third, every count matches and there are exactly $45$ employees.",
  "Nesting the projects, which needs someone on all three.",
  "C27B-at-most-two-least-union", "Inverse use of the double-counting bound with a feasibility check.",
  tita_answer=45, check=_c19,
  tita_traps=[(36, r"Nests the smaller projects inside the largest one, which puts people on all three."),
              (30, r"Divides $90$ by $3$, allowing triple counting.")],
  cognitive="Analysis")


def _c20():
    # attributes: woman, bus; per 100 employees
    w = _opt(2, [(lambda r: r[0], 40, 40), (lambda r: r[1], 70, 70)],
             lambda r: 1 if r == (1, 1) else 0, "min", total=100)
    return Fraction(w * 100, 40)
q("C27-B-020", T, "Least percentage of a subgroup inside a set from overall percentages", "Medium",
  "Conceptual/application",
  r"In a firm, $40\%$ of the employees are women and $70\%$ of all employees use the company bus. What is the least possible percentage of the women employees who use the company bus?",
  "MCQ",
  r"Out of every $100$ employees, $60$ are men, so at most $60$ of the $70$ bus users are men. At least $10$ bus users are women, which is $\frac{10}{40} = 25\%$ of the women.",
  "Reporting the overlap as a percentage of all employees instead of as a percentage of the women.",
  "C27B-conditional-percent-overlap", "Overlap bound followed by a change of base for the percentage.",
  correct=r"$25\%$",
  distractors=[(r"$10\%$", r"Reports the least overlap as a percentage of all employees."),
               (r"$30\%$", r"Subtracts the percentages: $70 - 40 = 30$."),
               (r"$28\%$", r"Assumes independence: $0.4 \times 0.7 = 0.28$.")],
  check=_c20, values=[25, 10, 30, 28], cognitive="Application")


def _c21():
    cons = _sizes([70, 60, 50]) + [
        (lambda r: r[0] * r[1], 25, 25), (lambda r: r[1] * r[2], 20, 20), (lambda r: r[0] * r[2], 15, 15),
        (lambda r: 1 if sum(r) == 0 else 0, 20, 1000)]
    return _opt(3, cons, lambda r: 1 if sum(r) == 1 else 0, "max", total=150)
q("C27-B-021", T, "Greatest exactly-one count with pairwise data and a 'none' constraint", "Medium",
  "Casework/optimisation",
  r"In a group of $150$ people, $70$ like Pune, $60$ like Goa and $50$ like Shimla as holiday spots. $25$ like both Pune and Goa, $20$ like both Goa and Shimla, and $15$ like both Pune and Shimla; each of these pair counts includes the people who like all three. At least $20$ people like none of the three. What is the greatest possible number of people who like exactly one of the three?",
  "MCQ",
  r"Let $t$ like all three. Then only Pune $= 70 - 25 - 15 + t = 30 + t$, only Goa $= 15 + t$, only Shimla $= 15 + t$, so exactly one $= 60 + 3t$. The union is $180 - 60 + t = 120 + t$, so none $= 30 - t \ge 20$ gives $t \le 10$. The greatest value is $60 + 30 = 90$.",
  "Subtracting the triple overlap the wrong number of times when converting pair counts to 'exactly two'.",
  "C27B-pairwise-data-parameter", "Parametrise all regions by the triple overlap, then apply a constraint on 'none'.",
  correct=r"$90$",
  distractors=[(r"$105$", r"Ignores the 'at least $20$ like none' condition and uses $t = 15$."),
               (r"$60$", r"Takes $t = 0$, which gives the least value."),
               (r"$70$", r"Writes exactly two as $60 - t$ instead of $60 - 3t$, giving exactly one $= 60 + t = 70$.")],
  check=_c21, values=[90, 105, 60, 70], cognitive="Analysis", exams=SPEED)


def _c22():
    return _opt(3, _sizes([80, 55, 45]) + [(lambda r: 1 if sum(r) == 0 else 0, 0, 0)],
                lambda r: 1 if r == (1, 0, 0) else 0, "max", total=130)
q("C27-B-022", T, "Greatest count in only one named set when everyone is covered", "Medium",
  "Conceptual/application",
  r"Each of the $130$ members of a gym uses at least one of three facilities: weights, treadmill and yoga room. $80$ use weights, $55$ use the treadmill and $45$ use the yoga room. What is the greatest possible number of members who use weights only?",
  "MCQ",
  r"Every member outside 'weights only' uses the treadmill or the yoga room, so weights only $= 130 - |\text{treadmill} \cup \text{yoga}|$. That union is at least $55$, so weights only is at most $75$. It is attained when all yoga users use the treadmill and $5$ weights users also use the treadmill.",
  "Maximising 'weights only' as the full weights count without using the fact that everyone is covered.",
  "C27B-only-one-set-greatest", "Insight: the region is the complement of the union of the other two sets.",
  correct=r"$75$",
  distractors=[(r"$80$", r"Takes all weights users as 'weights only'."),
               (r"$30$", r"Gives the least possible value, $130 - (55 + 45)$."),
               (r"$25$", r"Subtracts the treadmill count from the weights count: $80 - 55$.")],
  check=_c22, values=[75, 80, 30, 25], cognitive="Analysis")


def _c23():
    for N in range(1, 2001):
        if (52 * N) % 100 or (65 * N) % 100:
            continue
        E, M = 52 * N // 100, 65 * N // 100
        x = E + M + 36 - N  # both
        if 0 <= x <= min(E, M):
            return N
q("C27-B-023", T, "Least group size from exact percentages and a fixed 'neither' count", "Medium",
  "Inverse/parameter",
  r"At a seminar, exactly $52\%$ of the participants are engineers and exactly $65\%$ are from Maharashtra. Exactly $36$ participants are neither engineers nor from Maharashtra. What is the least possible number of participants?",
  "TITA",
  r"$52\%$ and $65\%$ of $N$ are whole numbers, so $N$ is a multiple of $100$. The 'neither' group is at most $100 - 65 = 35\%$ of $N$, so $36 \le 0.35N$, giving $N \ge 103$. The least multiple of $100$ is $200$: then $104$ engineers and $130$ from Maharashtra, with $104 + 130 + 36 - 200 = 70$ in both, which is valid.",
  "Using only the divisibility condition and missing that 'neither' cannot exceed the complement of the larger set.",
  "C27B-percent-integrality-group-size", "Combines a divisibility condition with an overlap bound on 'neither'.",
  tita_answer=200, check=_c23,
  tita_traps=[(100, r"Uses only divisibility; with $100$ participants, both would be $53$, more than the $52$ engineers."),
              (103, r"Uses only the bound $0.35N \ge 36$ and ignores that the percentages must give whole numbers.")],
  cognitive="Analysis", exams=SPEED)


# ---------------------------------------------------------------- DIFFICULT

def _c24():
    cons = _sizes([48, 40, 36]) + [(lambda r: 1 if sum(r) == 3 else 0, 12, 12),
                                   (lambda r: 1 if r == (0, 0, 1) else 0, 20, 1000),
                                   (lambda r: 1 if sum(r) == 0 else 0, 0, 0)]
    return _opt(3, cons, lambda r: 1, "min")
q("C27-B-024", T, "Least group size with a fixed triple overlap and a floor on one exclusive region", "Difficult",
  "Inverse/parameter",
  r"Every person in a group likes at least one of tea, coffee and juice. $48$ like tea, $40$ like coffee and $36$ like juice. Exactly $12$ like all three, and at least $20$ like juice but neither tea nor coffee. What is the least possible number of people in the group?",
  "MCQ",
  r"Remove the $12$ who like all three: tea, coffee and juice keep $36$, $28$ and $24$ other fans, and at least $20$ of the juice fans like juice only, so at most $4$ juice fans can be paired. The group is $12 + 20 + (\text{rest})$ and the rest is smallest when as many as possible like exactly two drinks. Every pair uses a coffee place or one of those $4$ juice places, so there are at most $28 + 4 = 32$ pairs; this needs the $4$ juice fans paired with tea and $28$ tea and coffee pairs, leaving $36 - 4 - 28 = 4$ tea only. So the group is $12 + 20 + 4 + 28 + 4 = 68$. Pairing the $4$ juice fans with coffee instead allows only $24$ tea and coffee pairs and gives $72$.",
  "Halving the remaining memberships without checking that the tea fans can actually be paired off.",
  "C27B-fixed-triple-least-union", "Three stages: strip out the fixed triple, use the floor on juice only, then see that pairing is limited by coffee and that the juice fans must go to tea.",
  correct=r"$68$",
  distractors=[(r"$66$", r"Halves the pairable memberships, $\frac{36 + 28 + 4}{2} = 34$, and adds $12 + 20$, without noticing that tea has more fans than coffee and juice can pair with."),
               (r"$56$", r"Ignores the juice-only condition: $12 + \frac{36 + 28 + 24}{2} = 56$."),
               (r"$72$", r"Pairs the $4$ spare juice fans with coffee, which leaves only $24$ tea and coffee pairs and $12$ tea only: $12 + 20 + 4 + 24 + 12 = 72$.")],
  check=_c24, values=[68, 66, 56, 72], cognitive="Analysis", exams=SPEED)


def _c25():
    # clubs: drama, music, chess, quiz; drama and music share no member
    cons = _sizes([30, 28, 26, 24]) + [(lambda r: 1 if sum(r) > 2 else 0, 0, 0),
                                       (lambda r: r[0] * r[1], 0, 0),
                                       (lambda r: 1 if sum(r) == 0 else 0, 0, 0)]
    return _opt(4, cons, lambda r: 1, "min")
q("C27-B-025", T, "Least population when each person is in at most two of four sets and two sets are disjoint", "Difficult",
  "Casework/optimisation",
  r"A hostel has four clubs: drama with $30$ members, music with $28$, chess with $26$ and quiz with $24$. Every student of the hostel is in at least one club and no student is in more than two clubs. Drama and music meet at the same time, so no student is in both of them. What is the least possible number of students in the hostel?",
  "TITA",
  r"The memberships total $108$. If $e_2$ students are in two clubs, the number of students is $108 - e_2$, so $e_2$ must be as large as possible. Since no one is in both drama and music, every student in two clubs is in chess or quiz, so $e_2 \le 26 + 24 = 50$ and there are at least $58$ students. This is attained: $14$ in drama and chess, $12$ in drama and quiz, $12$ in music and chess, $12$ in music and quiz, and $4$ each in drama only and music only.",
  "Halving the total memberships without using the clash between drama and music.",
  "C27B-at-most-two-least-union", "The halving bound is not attained; the solver must see that every double member uses a chess or quiz place, then construct.",
  tita_answer=58, check=_c25,
  tita_traps=[(54, r"Ignores the clash and halves the memberships: $\frac{108}{2} = 54$."),
              (50, r"Reports the greatest number of students in two clubs instead of the number of students.")],
  cognitive="Analysis", exams=SPEED)


def _c26():
    v = _opt(5, _sizes([80, 75, 70, 65, 60]), lambda r: 1 if sum(r) >= 3 else 0, "min", total=100)
    return v
q("C27-B-026", T, "Least percentage solving at least three of five questions", "Difficult",
  "Conceptual/application",
  r"In a quiz with five questions, the first question was solved by $80\%$ of the participants, the second by $75\%$, the third by $70\%$, the fourth by $65\%$ and the fifth by $60\%$. What is the least possible percentage of participants who solved at least three questions?",
  "MCQ",
  r"Per $100$ participants there are $80 + 75 + 70 + 65 + 60 = 350$ correct solutions. If $f$ participants solved at least three, they account for at most $5f$ solutions and the rest for at most $2(100 - f)$. So $350 \le 200 + 3f$, giving $f \ge 50$. This is attained: $50$ solve all five, and the other $50$ solve exactly two each, for example $15$ solve the first and second, $15$ the first and third, $10$ the second and fourth, $5$ the third and fifth, $5$ the fourth and fifth. The answer is $50\%$.",
  "Mixing up the per-person caps on either side of the threshold.",
  "C27B-average-membership-bound", "Needs a counting-by-memberships bound with different caps above and below the threshold, plus a construction.",
  correct=r"$50\%$",
  distractors=[(r"$30\%$", r"Divides the excess $350 - 200$ by $5$ instead of by $5 - 2 = 3$."),
               (r"$60\%$", r"Takes the percentage who solved the hardest question."),
               (r"$25\%$", r"Uses a cap of $3$ for the others, which is the bound for 'at least four': $350 \le 300 + 2f$.")],
  check=_c26, values=[50, 30, 60, 25], cognitive="Analysis", exams=SPEED)


def _c27():
    cons = _sizes([280, 250, 220]) + [(lambda r: 1 if sum(r) == 2 else 0, 150, 150)]
    return _opt(3, cons, lambda r: 1 if sum(r) == 0 else 0, "max", total=500)
q("C27-B-027", T, "Greatest 'none' count when the exactly-two count is fixed", "Difficult",
  "Casework/optimisation",
  r"In a survey of $500$ people about three apps, $280$ use the first app, $250$ use the second and $220$ use the third. Exactly $150$ people use exactly two of the three apps. What is the greatest possible number of people who use none of the three apps?",
  "TITA",
  r"Let $e_1$ and $e_3$ use exactly one and all three. Then $e_1 + 2(150) + 3e_3 = 750$, so $e_1 = 450 - 3e_3$, and the number using at least one is $e_1 + 150 + e_3 = 600 - 2e_3$. So none $= 2e_3 - 100$, largest when $e_3$ is largest. Since $e_1 \ge 0$, $e_3 \le 150$, giving none $= 200$. This works with $150$ using all three, $80$ using only the first two, $50$ only the first and third, $20$ only the second and third, and nobody using exactly one.",
  "Bounding 'none' only by the largest set and not using the fixed exactly-two count.",
  "C27B-exactly-two-given-none-bounds", "Express 'none' through the triple overlap, see the direction, find the binding constraint, and construct.",
  tita_answer=200, check=_c27,
  tita_traps=[(220, r"Uses $500 - 280$, the bound from the largest set alone, which is not reachable with exactly $150$ in two apps."),
              (0, r"Gives the least possible value, at $e_3 = 50$.")],
  cognitive="Analysis", exams=SPEED)


def _c28():
    # regions (man, smartphone, upi) per 100 adults
    cons = [(lambda r: r[0], 50, 50), (lambda r: r[1], 80, 80),
            (lambda r: 1 if (r[2] == 1 and r[1] == 0) else 0, 0, 0),
            (lambda r: 1 if (r[2] == 1 and r[1] == 1) else 0, 60, 60),
            (lambda r: 1 if (r[0] == 1 and r[2] == 0) else 0, 15, 100)]
    w = _opt(3, cons, lambda r: 1 if (r[0] == 0 and r[2] == 1) else 0, "min", total=100)
    return Fraction(w * 100, 50)
q("C27-B-028", T, "Least percentage of a subgroup in a set defined by a chain of conditions", "Difficult",
  "Multi-step word problem",
  r"In a town, $80\%$ of the adults own a smartphone, and $75\%$ of the smartphone owners use UPI; nobody without a smartphone uses UPI. Half the adults are men, and at least $30\%$ of the men do not use UPI. What is the least possible percentage of the women who use UPI?",
  "MCQ",
  r"Per $100$ adults, UPI users number $0.75 \times 80 = 60$. There are $50$ men, and at least $15$ of them do not use UPI, so at most $35$ men use UPI. Hence at least $60 - 35 = 25$ women use UPI, which is $\frac{25}{50} = 50\%$ of the women.",
  "Taking the percentage of men on the wrong base, or reporting the answer as a share of all adults.",
  "C27B-conditional-percent-overlap", "A chain of three conditions, two different bases for percentages, and an overlap bound.",
  correct=r"$50\%$",
  distractors=[(r"$20\%$", r"Ignores the condition on men: $60 - 50 = 10$ women, which is $20\%$ of the women."),
               (r"$25\%$", r"Reports the $25$ women UPI users as a percentage of all adults."),
               (r"$80\%$", r"Takes $30\%$ of all adults as the men not using UPI: $60 - 20 = 40$ women, which is $80\%$ of the women.")],
  check=_c28, values=[50, 20, 25, 80], cognitive="Analysis", exams=SPEED)


def _c29():
    return _opt(4, _sizes([60, 60, 60, 60]), lambda r: 1 if sum(r) >= 2 else 0, "min", total=100)
q("C27-B-029", T, "Least number in at least two of four sets with a ceiling", "Difficult",
  "Casework/optimisation",
  r"A training programme has four modules and $100$ trainees. Each module was completed by exactly $60$ trainees. What is the least possible number of trainees who completed at least two modules?",
  "MCQ",
  r"There are $240$ completions. If $s$ trainees completed at least two modules, they account for at most $4s$ completions and the others for at most $100 - s$. So $240 \le 100 + 3s$, giving $s \ge 46\frac{2}{3}$, so $s \ge 47$. This is attained: $46$ complete all four, $1$ completes the first three, $13$ complete only the first, $13$ only the second, $13$ only the third and $14$ only the fourth.",
  "Rounding the bound down, or carrying over a formula meant for three sets.",
  "C27B-average-membership-bound", "Membership-count bound with a non-integer value that must be rounded up, then a construction.",
  correct=r"$47$",
  distractors=[(r"$46$", r"Rounds the bound $46\frac{2}{3}$ down instead of up."),
               (r"$40$", r"Uses the three-set least-overlap pattern $240 - 2 \times 100 = 40$."),
               (r"$20$", r"Gives the bound for at least three modules, $240 \le 200 + 2s$.")],
  check=_c29, values=[47, 46, 40, 20], cognitive="Analysis", exams=SPEED)


def _c30():
    cons = _sizes([120, 100, 80]) + [(lambda r: 1 if sum(r) == 0 else 0, 30, 1000)]
    return _opt(3, cons, lambda r: 1 if sum(r) == 1 else 0, "max", total=200)
q("C27-B-030", T, "Greatest exactly-one count with a lower bound on 'none'", "Difficult",
  "Casework/optimisation",
  r"In a group of $200$ people, $120$ like Hindi films, $100$ like English films and $80$ like Tamil films. At least $30$ people like none of the three. What is the greatest possible number of people who like exactly one of the three?",
  "MCQ",
  r"Let $U$ people like at least one, so $U \le 170$. From $e_1 + e_2 + e_3 = U$ and $e_1 + 2e_2 + 3e_3 = 300$ we get $e_2 + 2e_3 = 300 - U$ and $e_1 = 2U - 300 + e_3$. The triple count is at most $\frac{300 - U}{2}$, so $e_1 \le \frac{3U}{2} - 150 \le 105$. This is attained at $U = 170$ with $65$ liking all three, nobody liking exactly two, and $55$, $35$, $15$ liking only Hindi, only English, only Tamil films.",
  "Thinking that exactly one is largest when overlaps are smallest, or ignoring the 'none' condition.",
  "C27B-exactly-one-bounds", "Two interacting parameters: the union size and the triple overlap, with a counter-intuitive direction.",
  correct=r"$105$",
  distractors=[(r"$150$", r"Ignores the 'at least $30$ like none' condition and uses $U = 200$."),
               (r"$170$", r"Assumes all $170$ people in the union can like exactly one film type."),
               (r"$0$", r"Gives the least possible value, reached with nobody liking all three and $50$ liking none: $e_1 = 2(150) - 300 = 0$.")],
  check=_c30, values=[105, 150, 170, 0], cognitive="Analysis", exams=SPEED)
