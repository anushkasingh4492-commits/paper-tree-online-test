import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TOP = "Linear and quadratic inequalities"
CX = ("CAT", "XAT")
X = Symbol('x', real=True)
oo_ = oo


def _count(pred, lo=-300, hi=300):
    """Count integers n in [lo, hi] with pred(n) True (pred uses exact arithmetic)."""
    return sum(1 for n in range(lo, hi + 1) if pred(n))


def _ints(pred, lo=-300, hi=300):
    return [n for n in range(lo, hi + 1) if pred(n)]


def _set(rel):
    return solve_univariate_inequality(rel, X, relational=False)


def _all(rels, v):
    """Solution set (in v) of several inequalities taken together."""
    out = S.Reals
    for r in rels:
        out = Intersection(out, solve_univariate_inequality(r, v, relational=False))
    return out


# ---------------------------------------------------------------- EASY (12)

def _c1():
    best = None
    for g in range(0, 2000):
        if 120 + 4 * g < 300 + F(3, 2) * g:
            best = g
    return best
q("C11-A-001", TOP, "Comparing two linear tariff plans: largest usage for which one plan is strictly cheaper", "Easy",
  "Multi-step word problem",
  r"A mobile operator offers two monthly data plans. Plan P charges a fixed Rs. $300$ plus Rs. $1.50$ per GB used, and plan Q charges a fixed Rs. $120$ plus Rs. $4$ per GB used. Usage is billed in whole GB. What is the largest monthly usage for which plan Q is strictly cheaper than plan P?",
  "MCQ",
  r"Plan Q is cheaper when $120 + 4g < 300 + 1.5g$, that is $2.5g < 180$, so $g < 72$. At exactly $72$ GB both plans cost Rs. $408$, so the largest whole number of GB with Q strictly cheaper is $71$ GB.",
  "Treating the break-even usage as one where the plan is already cheaper, or ignoring one plan's per-GB charge.",
  "C11A-linear-word", "One linear inequality from a cost comparison; the trap is the strict inequality at the break-even point.",
  correct=r"$71$ GB",
  distractors=[(r"$72$ GB", r"Solves $2.5g \le 180$; at $72$ GB the two plans cost the same, so Q is not strictly cheaper."),
               (r"$45$ GB", r"Ignores plan P's per-GB charge and divides the Rs. $180$ fixed-charge gap by Q's rate alone: $\frac{180}{4} = 45$."),
               (r"$32$ GB", r"Adds the per-GB rates instead of subtracting them: $\frac{180}{4 + 1.5} \approx 32.7$, rounded down to $32$.")],
  check=_c1, values=[71, 72, 45, 32], cognitive="Application")


def _c2():
    for e in range(0, 101):
        if F(4, 10) * 62 + F(6, 10) * e >= 75:
            return e
q("C11-A-002", TOP, "Weighted score: least whole-number mark meeting a target", "Easy",
  "Multi-step word problem",
  r"In a course, the final score is $40\%$ of the mid-term mark plus $60\%$ of the end-term mark, each mark being a whole number out of $100$. Ravi scored $62$ in the mid-term. What is the least end-term mark (in marks out of $100$) that gives him a final score of at least $75$?",
  "TITA",
  r"We need $0.4 \times 62 + 0.6E \ge 75$, that is $24.8 + 0.6E \ge 75$, so $0.6E \ge 50.2$ and $E \ge 83.67$. The least whole-number mark is $84$ (check: $24.8 + 50.4 = 75.2$, while $E = 83$ gives $74.6$).",
  "Rounding the bound down, or using a simple average of the two marks.",
  "C11A-linear-word", "A single linear inequality with a decimal bound; the trap is rounding in the wrong direction.",
  tita_answer=84, check=_c2,
  tita_traps=[(83, r"Rounds $83.67$ down; $E = 83$ gives only $74.6$."),
              (88, r"Uses the simple average $\frac{62 + E}{2} \ge 75$ instead of the $40 : 60$ weights.")],
  cognitive="Application")


def _c3():
    return _count(lambda n: n >= 1 and n + 2 <= 52 and 650 * n > 9000 + 350 * (n + 2), 0, 100)
q("C11-A-003", TOP, "System of linear conditions in a word problem: profitable trip sizes within bus capacity", "Medium",
  "Multi-step word problem",
  r"A school plans a day trip. The bus costs Rs. $9{,}000$ for the day whatever the number of travellers, and food costs Rs. $350$ for every person on the trip. Besides the students, $2$ teachers go on the trip; each student pays Rs. $650$ and the teachers pay nothing. The bus has $52$ seats and every traveller needs a seat. For how many different numbers of students will the total amount collected be strictly greater than the total cost?",
  "TITA",
  r"With $s$ students the cost is $9000 + 350(s + 2) = 9700 + 350s$ and the collection is $650s$. So $650s > 9700 + 350s$ gives $300s > 9700$, $s > 32.33$, so $s \ge 33$. Seats give $s + 2 \le 52$, so $s \le 50$. The possible values are $33, 34, \ldots, 50$: that is $18$ values.",
  "Forgetting that the teachers also eat and occupy seats.",
  "C11A-linear-word", "Two linear constraints from a word problem plus integer rounding at both ends.",
  tita_answer=18, check=_c3,
  tita_traps=[(20, r"Ignores the teachers' food ($300s > 9000$ gives $s \ge 31$) but still keeps $s \le 50$: $31$ to $50$."),
              (22, r"Ignores the teachers completely: $s \ge 31$ and $s \le 52$."),
              (19, r"Counts $32$ to $50$ after rounding $32.33$ down.")],
  cognitive="Application")


def _c4():
    return _count(lambda n: 3 * n - 7 < 2 * n + 5 and 5 * n + 4 >= 2 * n - 11)
q("C11-A-004", TOP, "Counting integers satisfying two linear inequalities simultaneously", "Easy",
  "Single-step computation",
  r"How many integers $x$ satisfy both $3x - 7 < 2x + 5$ and $5x + 4 \ge 2x - 11$?",
  "MCQ",
  r"The first gives $x < 12$. The second gives $3x \ge -15$, so $x \ge -5$. The integers are $-5, -4, \ldots, 11$, which is $11 - (-5) + 1 = 17$ integers.",
  "Mishandling the endpoints or the sign of a negative bound.",
  "C11A-linear-system-count", "Two one-step linear inequalities and an endpoint count.",
  correct=r"$17$",
  distractors=[(r"$16$", r"Treats $x \ge -5$ as $x > -5$ and leaves out $-5$."),
               (r"$18$", r"Treats $x < 12$ as $x \le 12$ and includes $12$."),
               (r"$7$", r"Loses the sign in $3x \ge -15$ and writes $x \ge 5$, counting $5$ to $11$.")],
  check=_c4, values=[17, 16, 18, 7], cognitive="Application")


def _c5():
    return _count(lambda n: n > 0 and 3 * n - 7 > 20 and F(n + 15, 2) <= 17, 0, 200)
q("C11-A-005", TOP, "Number puzzle leading to two linear inequalities; count of integer solutions", "Easy",
  "Single-step computation",
  r"Meera thinks of a positive integer. When she triples it and subtracts $7$, the result is greater than $20$. When she adds $15$ to it and halves the sum, the result is at most $17$. How many different integers could Meera be thinking of?",
  "TITA",
  r"$3n - 7 > 20$ gives $n > 9$. $\frac{n + 15}{2} \le 17$ gives $n + 15 \le 34$, so $n \le 19$. The integers are $10, 11, \ldots, 19$: that is $10$ integers.",
  "Including the excluded endpoint $9$ or dropping the included endpoint $19$.",
  "C11A-linear-system-count", "Two linear conditions read from words; the only trap is strict versus non-strict endpoints.",
  tita_answer=10, check=_c5,
  tita_traps=[(11, r"Treats $n > 9$ as $n \ge 9$ and includes $9$."),
              (9, r"Treats $n \le 19$ as $n < 19$ and leaves out $19$.")],
  cognitive="Application")


def _c6():
    return _count(lambda n: n * n - 7 * n - 30 < 0)
q("C11-A-006", TOP, "Integer solutions of a factorable quadratic inequality", "Easy",
  "Single-step computation",
  r"How many integers $x$ satisfy $x^2 - 7x - 30 < 0$?",
  "TITA",
  r"$x^2 - 7x - 30 = (x - 10)(x + 3)$, which is negative strictly between the roots: $-3 < x < 10$. The integers are $-2, -1, \ldots, 9$, which is $12$ integers.",
  "Including the roots, where the expression equals zero.",
  "C11A-quadratic-count", "One factorisation and one count between the roots.",
  tita_answer=12, check=_c6,
  tita_traps=[(14, r"Counts $-3$ to $10$, including both roots where the expression is $0$."),
              (13, r"Includes exactly one of the two roots.")],
  cognitive="Application")


def _c7():
    t = Symbol('t', real=True)
    s = solve_univariate_inequality(40 * t - 5 * t ** 2 >= 60, t, relational=False)
    return s.measure
q("C11-A-007", TOP, "Duration for which a quadratic height function stays above a level", "Easy",
  "Multi-step word problem",
  r"A ball is thrown straight up. Its height above the ground $t$ seconds after the throw is $h = 40t - 5t^2$ metres. For how many seconds in all is the ball at a height of at least $60$ metres?",
  "TITA",
  r"$40t - 5t^2 \ge 60$ gives $t^2 - 8t + 12 \le 0$, that is $(t - 2)(t - 6) \le 0$, so $2 \le t \le 6$. The ball is at or above $60$ m for $6 - 2 = 4$ seconds.",
  "Reporting a root instead of the length of the interval between the roots.",
  "C11A-quadratic-word", "One quadratic inequality whose answer is the length of the solution interval.",
  tita_answer=4, check=_c7,
  tita_traps=[(6, r"Reports the time $t = 6$ s when the ball comes back down to $60$ m."),
              (8, r"Reports the total flight time, from $40t - 5t^2 = 0$.")],
  cognitive="Application")


def _c8():
    return _set((X - 4) / (X + 2) <= 0)
q("C11-A-008", TOP, "Solution set of a simple rational inequality with a pole", "Easy",
  "Single-step computation",
  r"The set of all real $x$ satisfying $\frac{x - 4}{x + 2} \le 0$ is",
  "MCQ",
  r"The critical points are $x = -2$ (denominator zero, never included) and $x = 4$ (numerator zero, included because of $\le$). The fraction is negative when numerator and denominator have opposite signs, which happens between them. So $-2 < x \le 4$.",
  "Including the value that makes the denominator zero.",
  "C11A-rational-basic", "A single sign chart with two critical points; the trap is the excluded pole.",
  correct=r"$-2 < x \le 4$",
  distractors=[(r"$-2 \le x \le 4$", r"Includes $x = -2$, where the fraction is undefined."),
               (r"$x < -2$ or $x \ge 4$", r"Takes the regions where the fraction is non-negative, the reverse of what is asked."),
               (r"$-4 \le x < 2$", r"Reads the critical points with the signs flipped, as $x = -4$ and $x = 2$.")],
  check=_c8,
  values=[Interval.Lopen(-2, 4), Interval(-2, 4), Union(Interval.open(-oo, -2), Interval(4, oo)), Interval.Ropen(-4, 2)],
  cognitive="Application")


def _c9():
    k = Symbol('k', real=True)
    return solve_univariate_inequality(k ** 2 - 4 * 9 < 0, k, relational=False)
q("C11-A-009", TOP, "Quadratic positive for every real x: range of the linear coefficient", "Easy",
  "Inverse/parameter",
  r"For which values of $k$ is $x^2 - kx + 9 > 0$ for every real number $x$?",
  "MCQ",
  r"The leading coefficient is positive, so the expression is positive for all $x$ exactly when it has no real root: $k^2 - 4 \times 9 < 0$, that is $k^2 < 36$, so $-6 < k < 6$. At $k = \pm 6$ the expression is a perfect square and equals $0$ at one point.",
  "Allowing a zero discriminant, or dropping the factor $4$ in the discriminant.",
  "C11A-always-positive", "Direct use of the discriminant condition; the trap is the boundary case.",
  correct=r"$-6 < k < 6$",
  distractors=[(r"$-6 \le k \le 6$", r"Allows a zero discriminant; at $k = 6$ the expression $(x - 3)^2$ is $0$ at $x = 3$."),
               (r"$k < -6$ or $k > 6$", r"Requires the discriminant to be positive, which gives two real roots."),
               (r"$-3 < k < 3$", r"Uses $k^2 - 9 < 0$, dropping the $4$ in $b^2 - 4ac$.")],
  check=_c9,
  values=[Interval.open(-6, 6), Interval(-6, 6), Union(Interval.open(-oo, -6), Interval.open(6, oo)), Interval.open(-3, 3)],
  cognitive="Understanding")


def _c10():
    return Intersection(_set(X ** 2 <= 16), _set(2 * X - 1 > 3))
q("C11-A-010", TOP, "Common solution of a quadratic and a linear inequality", "Easy",
  "Single-step computation",
  r"The set of all real $x$ satisfying both $x^2 \le 16$ and $2x - 1 > 3$ is",
  "MCQ",
  r"$x^2 \le 16$ gives $-4 \le x \le 4$. $2x - 1 > 3$ gives $x > 2$. The overlap is $2 < x \le 4$.",
  r"Mishandling the strictness of an endpoint or solving $x^2 \le 16$ as $x \le 16$.",
  "C11A-two-quadratics", "Two short inequalities and their intersection.",
  correct=r"$2 < x \le 4$",
  distractors=[(r"$2 \le x \le 4$", r"Treats $x > 2$ as $x \ge 2$; at $x = 2$, $2x - 1 = 3$, which is not greater than $3$."),
               (r"$2 < x \le 16$", r"Reads $x^2 \le 16$ as $x \le 16$, forgetting to take the square root."),
               (r"$-4 \le x \le 4$", r"Solves only the quadratic condition and ignores the linear one.")],
  check=_c10,
  values=[Interval.Lopen(2, 4), Interval(2, 4), Interval.Lopen(2, 16), Interval(-4, 4)],
  cognitive="Application")


def _c11():
    s = 0
    for n in range(1, 1000):
        s += n
        if s > 500:
            return n
q("C11-A-011", TOP, "Least n for which a triangular-number sum exceeds a bound", "Easy",
  "Inverse/parameter",
  r"What is the least positive integer $n$ for which $1 + 2 + 3 + \cdots + n$ exceeds $500$?",
  "TITA",
  r"We need $\frac{n(n + 1)}{2} > 500$, that is $n(n + 1) > 1000$. Since $\sqrt{1000} \approx 31.6$, test nearby values: $31 \times 32 = 992$ fails and $32 \times 33 = 1056$ works. So $n = 32$ (the sums are $496$ and $528$).",
  "Stopping at the integer part of the square root without checking it.",
  "C11A-least-integer-quadratic", "One quadratic inequality solved by estimation and a check of neighbouring integers.",
  tita_answer=32, check=_c11,
  tita_traps=[(31, r"Takes the integer part of $\sqrt{1000} \approx 31.6$; the sum to $31$ is only $496$."),
              (22, r"Forgets the factor $\frac{1}{2}$ and solves $n(n + 1) > 500$.")],
  cognitive="Application")


def _c12():
    return _set(1 / X < Rational(1, 3))
q("C11-A-012", TOP, "Reciprocal inequality where x may be negative", "Easy",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $\frac{1}{x} < \frac{1}{3}$ is",
  "MCQ",
  r"Write it as $\frac{1}{x} - \frac{1}{3} < 0$, that is $\frac{3 - x}{3x} < 0$, or $\frac{x - 3}{x} > 0$. This holds when $x$ and $x - 3$ have the same sign: $x < 0$ or $x > 3$. Every negative $x$ works because $\frac{1}{x}$ is then negative.",
  "Cross-multiplying by $x$ as though $x$ were positive.",
  "C11A-reciprocal", "One rational rearrangement; the trap is multiplying by a variable of unknown sign.",
  correct=r"$x < 0$ or $x > 3$",
  distractors=[(r"$x > 3$", r"Multiplies both sides by $3x$ assuming $x > 0$, and so loses all negative $x$."),
               (r"$0 < x < 3$", r"Flips the inequality on taking reciprocals and keeps only positive $x$."),
               (r"$x < 0$", r"Notices that negative $x$ works but assumes no positive $x$ can.")],
  check=_c12,
  values=[Union(Interval.open(-oo, 0), Interval.open(3, oo)), Interval.open(3, oo), Interval.open(0, 3), Interval.open(-oo, 0)],
  cognitive="Understanding")


def _c13():
    xs = [F(k, 97) for k in range(1, 97)]
    assert all(x * x < x for x in xs)
    stmts = {1: lambda x: x ** 3 < x ** 2,
             2: lambda x: x > 1,
             3: lambda x: 1 / x < 1,
             4: lambda x: sqrt(Rational(x.numerator, x.denominator)) < x}
    always = [i for i, f in stmts.items() if all(bool(f(x)) for x in xs)]
    assert len(always) == 1
    return always[0]
q("C11-A-013", TOP, "Deducing the interval from x squared less than x and testing statements", "Easy",
  "Conceptual/application",
  r"A real number $x$ satisfies $x^2 < x$. Which of the following must be true?",
  "MCQ",
  r"$x^2 < x$ means $x(x - 1) < 0$, so $0 < x < 1$. Multiplying $x < 1$ by $x^2 > 0$ gives $x^3 < x^2$. So $x^3 < x^2$ always holds. For $0 < x < 1$ we have $\frac{1}{x} > 1$ and $\sqrt{x} > x$, so the other statements fail.",
  "Dividing by $x$ without fixing its sign, or believing reciprocals and square roots shrink every number.",
  "C11A-must-be-true", "Requires turning the condition into an interval and testing each statement against it.",
  correct=r"$x^3 < x^2$",
  distractors=[(r"$x > 1$", r"Divides $x^2 < x$ by $x$ and reverses the sign as though $x$ were negative."),
               (r"$\frac{1}{x} < 1$", r"Believes that the reciprocal of a number less than $1$ is also less than $1$."),
               (r"$\sqrt{x} < x$", r"Assumes a square root is always smaller than the number, which is false for $0 < x < 1$.")],
  check=_c13, values=[1, 2, 3, 4], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM (18)

def _c14():
    a = Symbol('a', real=True)
    # integer solutions are the integers n with 2a - 3 < n < 6, i.e. {.., 4, 5};
    # exactly four of them: 2 must be a solution and 1 must not.
    cand = _all([2 * a - 3 < 2, 2 * a - 3 >= 1], a)

    def cnt(av):
        return _count(lambda n: n + 3 > 2 * av and 2 * n - 5 < 7, -100, 100)
    for k in range(-200, 400):
        av = F(k, 40)
        assert (cnt(av) == 4) == bool(cand.contains(Rational(av.numerator, av.denominator)))
    return cand
q("C11-A-014", TOP, "Parameter range for which a linear system has exactly four integer solutions", "Medium",
  "Inverse/parameter",
  r"The inequalities $x + 3 > 2a$ and $2x - 5 < 7$, taken together, have exactly $4$ integer solutions $x$. The set of all possible values of $a$ is",
  "MCQ",
  r"The system is $2a - 3 < x < 6$. Its integer solutions run downward from $5$, so exactly four of them means the solutions are $2, 3, 4, 5$: $2$ must satisfy $2 > 2a - 3$ while $1$ must fail, $1 \le 2a - 3$. So $1 \le 2a - 3 < 2$, giving $2 \le a < \frac{5}{2}$.",
  "Getting the inclusion of the endpoints the wrong way round, or mis-solving one of the linear inequalities.",
  "C11A-param-integer-count", "Requires translating a count of integer solutions into strict and non-strict conditions on a moving endpoint.",
  correct=r"$2 \le a < \frac{5}{2}$",
  distractors=[(r"$2 < a \le \frac{5}{2}$", r"Swaps the endpoint inclusions; at $a = \frac{5}{2}$ the system is $2 < x < 6$, with only $3$ integer solutions."),
               (r"$\frac{5}{2} \le a < 3$", r"Reads $2x - 5 < 7$ as $x \le 6$, so takes the solutions as $3, 4, 5, 6$."),
               (r"$-1 \le a < -\frac{1}{2}$", r"Solves $x + 3 > 2a$ as $x > 2a + 3$ and then requires $1 \le 2a + 3 < 2$.")],
  check=_c14,
  values=[Interval.Ropen(2, Rational(5, 2)), Interval.Lopen(2, Rational(5, 2)), Interval.Ropen(Rational(5, 2), 3), Interval.Ropen(-1, Rational(-1, 2))],
  cognitive="Analysis")


def _c15():
    return _count(lambda n: n * n + 200 > 30 * n, 1, 50)
q("C11-A-015", TOP, "Counting integers in a bounded range outside the roots of a quadratic", "Medium",
  "Casework/optimisation",
  r"How many positive integers $n$ not exceeding $50$ satisfy $n^2 + 200 > 30n$?",
  "MCQ",
  r"$n^2 - 30n + 200 > 0$ means $(n - 10)(n - 20) > 0$, so $n < 10$ or $n > 20$. In $1$ to $50$ this gives $1$ to $9$ ($9$ values) and $21$ to $50$ ($30$ values), a total of $39$.",
  "Counting the region between the roots, or miscounting the block $21$ to $50$.",
  "C11A-quadratic-count", "Two outer regions inside a bounded range, each counted separately.",
  correct=r"$39$",
  distractors=[(r"$11$", r"Counts $10$ to $20$, the region where $n^2 - 30n + 200 \le 0$, which is the opposite of what is asked."),
               (r"$41$", r"Includes the roots $10$ and $20$, where both sides are equal."),
               (r"$38$", r"Counts the block $21$ to $50$ as $50 - 21 = 29$ values instead of $30$.")],
  check=_c15, values=[39, 11, 41, 38], cognitive="Application")


def _c16():
    return _count(lambda p: 200 - 4 * p >= 0 and (p - 10) * (200 - 4 * p) >= 1200, 0, 50)
q("C11-A-016", TOP, "Price range giving a minimum profit when demand falls linearly with price", "Medium",
  "Multi-step word problem",
  r"A shop sells a gadget at Rs. $p$ per unit, where $p$ is a whole number. At this price it sells $200 - 4p$ units a day, and each unit costs the shop Rs. $10$. For how many different prices $p$ is the daily profit at least Rs. $1{,}200$?",
  "TITA",
  r"Profit $= (p - 10)(200 - 4p) = 4(p - 10)(50 - p) \ge 1200$, so $(p - 10)(50 - p) \ge 300$. Expanding, $-p^2 + 60p - 500 \ge 300$, that is $p^2 - 60p + 800 \le 0$, or $(p - 20)(p - 40) \le 0$. So $20 \le p \le 40$, which is $21$ whole-number prices.",
  "Using strict inequality at the ends, or counting all prices with a positive profit.",
  "C11A-quadratic-word", "Modelling profit as a product, reducing to a quadratic inequality, then counting with inclusive ends.",
  tita_answer=21, check=_c16,
  tita_traps=[(19, r"Treats the bounds as strict and counts $21$ to $39$."),
              (39, r"Counts every price with positive profit, $10 < p < 50$."),
              (20, r"Computes $40 - 20 = 20$ without adding $1$ for the inclusive count.")],
  cognitive="Application")


def _c17():
    return _count(lambda n: (n + 4) * (n - 1) * (n - 6) * (n - 9) < 0)
q("C11-A-017", TOP, "Wavy-curve sign analysis of a product of four linear factors; integer count", "Medium",
  "Conceptual/application",
  r"How many integers $x$ satisfy $(x + 4)(x - 1)(x - 6)(x - 9) < 0$?",
  "MCQ",
  r"The critical points are $-4, 1, 6, 9$. For $x > 9$ all four factors are positive, and the sign alternates across each simple root: negative on $(6, 9)$, positive on $(1, 6)$, negative on $(-4, 1)$, positive for $x < -4$. So $x \in (-4, 1) \cup (6, 9)$: the integers $-3, -2, -1, 0$ and $7, 8$, which is $6$ integers.",
  "Taking the wrong alternate intervals, or including the roots.",
  "C11A-wavy-count", "Sign chart with four critical points and two separate negative intervals.",
  correct=r"$6$",
  distractors=[(r"$10$", r"Includes the four roots, counting $-4$ to $1$ and $6$ to $9$."),
               (r"$4$", r"Starts the alternation with the wrong sign and counts the integers $2, 3, 4, 5$ of $(1, 6)$."),
               (r"$12$", r"Counts all integers strictly between the smallest and largest roots, $-3$ to $8$.")],
  check=_c17, values=[6, 10, 4, 12], cognitive="Application")


def _c18():
    return _set(X ** 3 - 4 * X ** 2 - 11 * X + 30 > 0)
q("C11-A-018", TOP, "Cubic inequality by factorising and the wavy-curve method", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $x^3 - 4x^2 - 11x + 30 > 0$ is",
  "MCQ",
  r"$x = 2$ is a root ($8 - 16 - 22 + 30 = 0$), so the cubic is $(x - 2)(x^2 - 2x - 15) = (x - 2)(x - 5)(x + 3)$. It is positive for $x > 5$ and alternates sign across $5$, $2$ and $-3$: negative on $(2, 5)$, positive on $(-3, 2)$, negative for $x < -3$. So $-3 < x < 2$ or $x > 5$.",
  "Starting the sign pattern from the wrong end or factorising the quadratic with the wrong signs.",
  "C11A-wavy-count", "Needs a root by inspection, a factorisation and a three-point sign chart.",
  correct=r"$-3 < x < 2$ or $x > 5$",
  distractors=[(r"$x < -3$ or $2 < x < 5$", r"Assigns a positive sign to the leftmost region and alternates from there, which gives the regions where the cubic is negative."),
               (r"$x > 5$", r"Keeps only the region to the right of the largest root."),
               (r"$-5 < x < 2$ or $x > 3$", r"Factorises $x^2 - 2x - 15$ as $(x + 5)(x - 3)$, so uses the roots $-5, 2, 3$.")],
  check=_c18,
  values=[Union(Interval.open(-3, 2), Interval.open(5, oo)), Union(Interval.open(-oo, -3), Interval.open(2, 5)),
          Interval.open(5, oo), Union(Interval.open(-5, 2), Interval.open(3, oo))],
  cognitive="Application")


def _c19():
    return _count(lambda n: (n - 3) ** 2 * (n + 2) * (n - 6) < 0, -10, 10)
q("C11-A-019", TOP, "Squared factor in a sign analysis: excluding the double root from a strict inequality", "Medium",
  "Conceptual/application",
  r"How many integers $x$ with $-10 \le x \le 10$ satisfy $(x - 3)^2 (x + 2)(x - 6) < 0$?",
  "MCQ",
  r"$(x - 3)^2 \ge 0$, and it is $0$ at $x = 3$, so the product is negative exactly when $(x + 2)(x - 6) < 0$ and $x \ne 3$. That gives $-2 < x < 6$ with $x \ne 3$: the integers $-1, 0, 1, 2, 4, 5$, which is $6$ integers.",
  "Forgetting that the squared factor makes the product zero at its root, or letting the sign change there.",
  "C11A-wavy-repeated", "Requires handling an even-power factor, which does not change sign but does create a zero.",
  correct=r"$6$",
  distractors=[(r"$7$", r"Cancels $(x - 3)^2$ as a positive factor and keeps $x = 3$, where the product is $0$."),
               (r"$10$", r"Lets the sign alternate at $x = 3$ as at a simple root, giving $(3, 6)$ and $x < -2$: $4, 5$ and $-10$ to $-3$."),
               (r"$9$", r"Solves $(x + 2)(x - 6) \le 0$ and counts $-2$ to $6$.")],
  check=_c19, values=[6, 7, 10, 9], cognitive="Analysis")


def _c20():
    return _set((X ** 2 - 5 * X + 6) / (X ** 2 - 9 * X + 20) <= 0)
q("C11-A-020", TOP, "Rational inequality with quadratic numerator and denominator", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $\frac{x^2 - 5x + 6}{x^2 - 9x + 20} \le 0$ is",
  "MCQ",
  r"The fraction is $\frac{(x - 2)(x - 3)}{(x - 4)(x - 5)}$. With critical points $2, 3, 4, 5$, its sign is positive for $x > 5$ and alternates: negative on $(4, 5)$, positive on $(3, 4)$, negative on $(2, 3)$, positive for $x < 2$. Zeros of the numerator ($2$ and $3$) are included; zeros of the denominator ($4$ and $5$) are not. So $2 \le x \le 3$ or $4 < x < 5$.",
  "Including the zeros of the denominator, or ignoring the denominator's sign.",
  "C11A-rational-basic", "Four critical points with two different endpoint rules.",
  correct=r"$2 \le x \le 3$ or $4 < x < 5$",
  distractors=[(r"$2 \le x \le 3$ or $4 \le x \le 5$", r"Includes $x = 4$ and $x = 5$, where the denominator is zero."),
               (r"$2 \le x \le 3$", r"Solves only the numerator $\le 0$, ignoring that the denominator can be negative."),
               (r"$x \le 2$ or $3 \le x < 4$ or $x > 5$", r"Takes the regions where the fraction is $\ge 0$.")],
  check=_c20,
  values=[Union(Interval(2, 3), Interval.open(4, 5)), Union(Interval(2, 3), Interval(4, 5)), Interval(2, 3),
          Union(Interval(-oo, 2), Interval.Ropen(3, 4), Interval.open(5, oo))],
  cognitive="Application")


def _c21():
    a = Symbol('a', real=True)
    return _all([a >= 0, Rational(2, 5) <= (10 + a) / (40 + a), (10 + a) / (40 + a) <= Rational(1, 2)], a)
q("C11-A-021", TOP, "Concentration bounds after adding a pure component: rational inequality in a mixture", "Medium",
  "Multi-step word problem",
  r"A vessel holds $40$ litres of a solution that is $25\%$ acid by volume. Some pure acid is added so that the resulting solution is at least $40\%$ and at most $50\%$ acid. If $a$ litres of pure acid are added, then",
  "MCQ",
  r"The vessel has $10$ litres of acid, so after adding $a$ litres the concentration is $\frac{10 + a}{40 + a}$. From $\frac{10 + a}{40 + a} \ge 0.4$: $10 + a \ge 16 + 0.4a$, so $a \ge 10$. From $\frac{10 + a}{40 + a} \le 0.5$: $10 + a \le 20 + 0.5a$, so $a \le 20$. Hence $10 \le a \le 20$.",
  "Forgetting that the added acid also increases the total volume.",
  "C11A-rational-word", "Two rational inequalities in a mixture setting; the volume grows with the added acid.",
  correct=r"$10 \le a \le 20$",
  distractors=[(r"$6 \le a \le 10$", r"Keeps the total at $40$ litres: $16 \le 10 + a \le 20$."),
               (r"$2 \le a \le 5$", r"Uses the acid to water ratio $\frac{10 + a}{30}$ in place of the concentration."),
               (r"$16 \le a \le 20$", r"Takes $40\%$ and $50\%$ of the original $40$ litres as the amount of acid to add.")],
  check=_c21, values=[Interval(10, 20), Interval(6, 10), Interval(2, 5), Interval(16, 20)], cognitive="Application")


def _c22():
    v = Symbol('v', real=True)
    s = _all([v > 8, 24 / (v - 8) + 24 / (v + 8) <= 4], v)
    return s.inf
q("C11-A-022", TOP, "Least still-water speed for a round trip within a time limit: rational inequality", "Medium",
  "Multi-step word problem",
  r"A motorboat goes $24$ km upstream and then returns $24$ km downstream on a river flowing at a constant $8$ km/h. The boat's speed in still water is constant. If the whole round trip must take at most $4$ hours, what is the least possible speed of the boat in still water?",
  "MCQ",
  r"With still-water speed $v > 8$: $\frac{24}{v - 8} + \frac{24}{v + 8} \le 4$. Combining, $\frac{48v}{v^2 - 64} \le 4$, so $48v \le 4v^2 - 256$, that is $v^2 - 12v - 64 \ge 0$, or $(v - 16)(v + 4) \ge 0$. With $v > 8$ this gives $v \ge 16$, so the least speed is $16$ km/h (upstream $3$ h, downstream $1$ h).",
  "Ignoring the current or giving the whole time limit to one leg.",
  "C11A-rational-word", "A rational inequality from a stream problem, reduced to a factorable quadratic with a domain restriction.",
  correct=r"$16$ km/h",
  distractors=[(r"$12$ km/h", r"Ignores the current: $\frac{48}{v} \le 4$ gives $v \ge 12$."),
               (r"$20$ km/h", r"Ignores the current to get $12$, then adds the current speed $8$."),
               (r"$14$ km/h", r"Uses the whole $4$ hours for the upstream leg alone: $\frac{24}{v - 8} \le 4$ gives $v \ge 14$.")],
  check=_c22, values=[16, 12, 20, 14], cognitive="Application")


def _c23():
    def good(m):
        # x^2 + 2(m-1)x + 2m + 6 > 0 for all real x  <=>  no real root (leading coefficient 1)
        return Poly(X ** 2 + 2 * (m - 1) * X + 2 * m + 6, X).count_roots() == 0
    return _count(good, -40, 40)
q("C11-A-023", TOP, "Counting integer parameters for which a quadratic is positive for all real x", "Medium",
  "Inverse/parameter",
  r"For how many integers $m$ is $x^2 + 2(m - 1)x + 2m + 6 > 0$ for every real number $x$?",
  "MCQ",
  r"The expression is positive for all $x$ exactly when it has no real root: $\frac{D}{4} = (m - 1)^2 - (2m + 6) < 0$, that is $m^2 - 4m - 5 < 0$, or $(m + 1)(m - 5) < 0$. So $-1 < m < 5$, giving $m = 0, 1, 2, 3, 4$: $5$ integers.",
  "Allowing a zero discriminant, or dropping the factor $2$ in the middle coefficient.",
  "C11A-always-positive", "Discriminant condition becomes a quadratic inequality in the parameter, then an integer count.",
  correct=r"$5$",
  distractors=[(r"$7$", r"Allows $D = 0$ and counts $-1$ to $5$; at $m = 5$ the expression is $(x + 4)^2$, which is $0$ at $x = -4$."),
               (r"$6$", r"Includes one boundary value, counting $-1$ to $4$."),
               (r"$13$", r"Takes $b = m - 1$: $(m - 1)^2 - 4(2m + 6) < 0$ gives $m^2 - 10m - 23 < 0$, roughly $-1.9 < m < 11.9$, so $m = -1$ to $11$.")],
  check=_c23, values=[5, 7, 6, 13], cognitive="Application")


def _c24():
    for a in range(5, 100):
        if _count(lambda n: n * n - (a + 4) * n + 4 * a < 0, -50, 200) == 7:
            return a
q("C11-A-024", TOP, "Integer parameter from the number of integer solutions of a quadratic inequality", "Medium",
  "Inverse/parameter",
  r"For an integer $a > 4$, the inequality $x^2 - (a + 4)x + 4a < 0$ has exactly $7$ integer solutions. What is the value of $a$?",
  "TITA",
  r"$x^2 - (a + 4)x + 4a = (x - 4)(x - a)$, which is negative for $4 < x < a$. The integers in this open interval are $5, 6, \ldots, a - 1$, which number $a - 5$. So $a - 5 = 7$ and $a = 12$.",
  "Counting the integers in an open interval as the difference of its endpoints.",
  "C11A-param-integer-count", "Factorisation with a parameter and a careful count of integers in an open interval.",
  tita_answer=12, check=_c24,
  tita_traps=[(11, r"Counts the integers strictly between $4$ and $a$ as $a - 4$."),
              (10, r"Solves $\le 0$ instead of $< 0$, so counts $4$ to $a$ inclusive as $a - 3$.")],
  cognitive="Application")


def _c25():
    xs = Symbol('xs', real=True)
    lo = solve_univariate_inequality((2 * xs + 3) / (xs - 4) >= -1, xs, relational=False)
    hi = solve_univariate_inequality((2 * xs + 3) / (xs - 4) <= 1, xs, relational=False)
    sym = Intersection(lo, hi)
    brute = [n for n in range(-300, 301) if n != 4 and -1 <= F(2 * n + 3, n - 4) <= 1]
    assert all(sym.contains(n) for n in brute) and len(brute) == len([n for n in range(-300, 301) if sym.contains(n)])
    return len(brute)
q("C11-A-025", TOP, "Double rational inequality whose denominator can be negative; integer count", "Medium",
  "Conceptual/application",
  r"For how many integers $x$ does the value of $\frac{2x + 3}{x - 4}$ lie between $-1$ and $1$, both inclusive?",
  "TITA",
  r"Split into two conditions and never cross-multiply. Upper: $\frac{2x + 3}{x - 4} - 1 = \frac{x + 7}{x - 4} \le 0$, so $-7 \le x < 4$. Lower: $\frac{2x + 3}{x - 4} + 1 = \frac{3x - 1}{x - 4} \ge 0$, so $x \le \frac{1}{3}$ or $x > 4$. Together, $-7 \le x \le \frac{1}{3}$, whose integers are $-7, -6, \ldots, 0$: $8$ integers.",
  "Multiplying through by $x - 4$ as if it were positive, or solving only one side of the double inequality.",
  "C11A-rational-double", "Two rational inequalities taken together; the sign of the denominator decides the region.",
  tita_answer=8, check=_c25,
  tita_traps=[(11, r"Solves only the upper condition $\frac{2x + 3}{x - 4} \le 1$ and counts $-7$ to $3$."),
              (0, r"Multiplies by $x - 4$ as if it were positive: $2x + 3 \le x - 4$ gives $x \le -7$ and $2x + 3 \ge 4 - x$ gives $x \ge \frac{1}{3}$, which cannot both hold.")],
  cognitive="Application")


def _c26():
    return _count(lambda n: n ** 4 - 26 * n ** 2 + 25 < 0)
q("C11-A-026", TOP, "Biquadratic inequality by substituting t = x squared; integer count", "Medium",
  "Conceptual/application",
  r"How many integers $x$ satisfy $x^4 - 26x^2 + 25 < 0$?",
  "MCQ",
  r"Put $t = x^2$: $t^2 - 26t + 25 = (t - 1)(t - 25) < 0$, so $1 < x^2 < 25$. The integers with $x^2$ strictly between $1$ and $25$ are $\pm 2, \pm 3, \pm 4$: $6$ integers.",
  "Forgetting negative values of $x$, or treating the interval for $x^2$ as an interval for $x$.",
  "C11A-substitution", "One substitution and a back-translation that must include negative values.",
  correct=r"$6$",
  distractors=[(r"$3$", r"Counts only the positive values $2, 3, 4$."),
               (r"$10$", r"Solves $\le 0$ and includes $\pm 1$ and $\pm 5$."),
               (r"$23$", r"Treats $1 < t < 25$ as an interval for $x$ and counts $2$ to $24$.")],
  check=_c26, values=[6, 3, 10, 23], cognitive="Application")


def _c27():
    return _count(lambda n: n * n - 3 * n - 28 < 0 and n * n - 2 * n - 8 > 0)
q("C11-A-027", TOP, "Integer solutions common to two quadratic inequalities", "Medium",
  "Conceptual/application",
  r"How many integers $x$ satisfy both $x^2 - 3x - 28 < 0$ and $x^2 - 2x - 8 > 0$?",
  "MCQ",
  r"$(x - 7)(x + 4) < 0$ gives $-4 < x < 7$. $(x - 4)(x + 2) > 0$ gives $x < -2$ or $x > 4$. The overlap is $-4 < x < -2$ or $4 < x < 7$, whose integers are $-3, 5, 6$: that is $3$ integers.",
  "Losing one branch of the second inequality or including its roots.",
  "C11A-two-quadratics", "Intersection of an inner interval with a two-piece outer region.",
  correct=r"$3$",
  distractors=[(r"$10$", r"Counts the integers of the first inequality alone, $-3$ to $6$."),
               (r"$5$", r"Solves the second as $\ge 0$ and includes $-2$ and $4$."),
               (r"$2$", r"Keeps only the branch $x > 4$ of the second inequality.")],
  check=_c27, values=[3, 10, 5, 2], cognitive="Application")


def _c28():
    # denominator has negative discriminant, so it never vanishes
    assert discriminant(X ** 2 + 2 * X + 5, X) < 0
    return _set((X ** 2 - X - 12) / (X ** 2 + 2 * X + 5) < 0)
q("C11-A-028", TOP, "Rational inequality whose quadratic denominator is always positive", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $\frac{x^2 - x - 12}{x^2 + 2x + 5} < 0$ is",
  "MCQ",
  r"The denominator is $x^2 + 2x + 5 = (x + 1)^2 + 4 \ge 4$, so it is always positive and never zero; the fraction has the sign of its numerator. So we need $x^2 - x - 12 = (x - 4)(x + 3) < 0$, that is $-3 < x < 4$.",
  "Treating the denominator as if it could change sign, or reversing the sign condition.",
  "C11A-positive-denominator", "The insight is that the denominator has no real root, which reduces the problem to one quadratic inequality.",
  correct=r"$-3 < x < 4$",
  distractors=[(r"$x < -3$ or $x > 4$", r"Solves $(x - 4)(x + 3) > 0$, taking the regions where the fraction is positive."),
               (r"$-4 < x < 3$", r"Factorises $x^2 - x - 12$ as $(x + 4)(x - 3)$."),
               (r"$-3 \le x \le 4$", r"Includes the endpoints, where the fraction equals $0$ and the strict inequality fails.")],
  check=_c28,
  values=[Interval.open(-3, 4), Union(Interval.open(-oo, -3), Interval.open(4, oo)), Interval.open(-4, 3), Interval(-3, 4)],
  cognitive="Application")


def _c29():
    return _count(lambda n: 150 <= n * (n - 1) // 2 <= 300, 2, 200)
q("C11-A-029", TOP, "Range of group sizes from bounds on the number of handshakes", "Medium",
  "Inverse/parameter",
  r"At a meeting, every pair of people shook hands exactly once. The total number of handshakes was at least $150$ and at most $300$. How many different values are possible for the number of people at the meeting?",
  "TITA",
  r"With $n$ people there are $\frac{n(n - 1)}{2}$ handshakes, so $300 \le n(n - 1) \le 600$. Now $17 \times 16 = 272 < 300$ and $18 \times 17 = 306 \ge 300$, so $n \ge 18$. Also $25 \times 24 = 600$ and $26 \times 25 = 650$, so $n \le 25$. Thus $n = 18, \ldots, 25$: $8$ values.",
  "Excluding a boundary value where the bound is met exactly, or using $n^2$ for the number of handshakes.",
  "C11A-least-integer-quadratic", "A double quadratic inequality in an integer, with one bound attained exactly.",
  tita_answer=8, check=_c29,
  tita_traps=[(7, r"Treats the upper bound as strict and drops $n = 25$, which gives exactly $300$ handshakes."),
              (9, r"Rounds $\sqrt{300} \approx 17.3$ down and starts the count at $17$, which gives only $136$ handshakes.")],
  cognitive="Application")


def _c30():
    return _set(1 / (X - 2) > 1 / (X + 1))
q("C11-A-030", TOP, "Comparing two reciprocals: sign of a combined fraction", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $\frac{1}{x - 2} > \frac{1}{x + 1}$ is",
  "MCQ",
  r"Subtract: $\frac{1}{x - 2} - \frac{1}{x + 1} = \frac{(x + 1) - (x - 2)}{(x - 2)(x + 1)} = \frac{3}{(x - 2)(x + 1)} > 0$. The numerator is positive, so we need $(x - 2)(x + 1) > 0$: $x < -1$ or $x > 2$.",
  "Cross-multiplying by denominators whose signs are unknown.",
  "C11A-reciprocal", "Bringing both sides to one fraction reveals a constant numerator; the trap is cross-multiplication.",
  correct=r"$x < -1$ or $x > 2$",
  distractors=[(r"$x > 2$", r"Assumes both denominators are positive."),
               (r"$x \ne -1$ and $x \ne 2$", r"Cross-multiplies to get $x + 1 > x - 2$, which is always true, and only removes the excluded values."),
               (r"$-1 < x < 2$", r"Requires $(x - 2)(x + 1) < 0$, reversing the sign condition.")],
  check=_c30,
  values=[Union(Interval.open(-oo, -1), Interval.open(2, oo)), Interval.open(2, oo),
          Complement(S.Reals, FiniteSet(-1, 2)), Interval.open(-1, 2)],
  cognitive="Analysis")


# ---------------------------------------------------------------- DIFFICULT (10)

def _c31():
    def ok(n):
        if n == 7:
            return False
        return F((n * n + 2 * n - 3) * (n - 4) ** 2, n - 7) >= 0
    return _count(ok, -20, 20)
q("C11-A-031", TOP, "Rational inequality with a quadratic factor and a squared factor, counted over a bounded integer range", "Difficult",
  "Casework/optimisation",
  r"How many integers $x$ with $-20 \le x \le 20$ satisfy $\frac{(x^2 + 2x - 3)(x - 4)^2}{x - 7} \ge 0$?",
  "TITA",
  r"Factorise: $x^2 + 2x - 3 = (x + 3)(x - 1)$. The factor $(x - 4)^2$ is never negative, so it does not change the sign; it only makes the expression $0$ at $x = 4$, which is allowed by $\ge$. For $x \ne 4$ the sign is that of $\frac{(x + 3)(x - 1)}{x - 7}$: positive for $x > 7$, negative on $(1, 7)$, positive on $(-3, 1)$, negative for $x < -3$. So the solution is $-3 \le x \le 1$, the single point $x = 4$, or $x > 7$. In the range: $-3$ to $1$ ($5$), $4$ ($1$), $8$ to $20$ ($13$), total $19$.",
  "Changing the sign at the double root, or losing the isolated zero at the double root.",
  "C11A-wavy-repeated", "Two stages: factorise the quadratic, then handle a squared factor that adds an isolated solution, with an excluded pole and a window count.",
  tita_answer=19, check=_c31,
  tita_traps=[(18, r"Drops the isolated solution $x = 4$, where the expression equals $0$."),
              (35, r"Treats $(x - 4)^2$ like a simple factor and alternates the sign at $4$, getting $x \le -3$, $1 \le x \le 4$ or $x > 7$."),
              (20, r"Includes $x = 7$, where the expression is undefined.")],
  exams=CX, cognitive="Analysis")


def _c32():
    def ok(n):
        if n in (8, 12):
            return False
        return F((n + 5) ** 3 * (n - 1) ** 4, (n - 8) ** 5 * (n - 12) ** 2) <= 0
    return _count(ok)
q("C11-A-032", TOP, "Rational inequality with odd and even powers in numerator and denominator", "Difficult",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $\frac{(x + 5)^3 (x - 1)^4}{(x - 8)^5 (x - 12)^2} \le 0$?",
  "TITA",
  r"Even powers never change sign: $(x - 1)^4$ only makes the expression $0$ at $x = 1$, and $(x - 12)^2$ only excludes $x = 12$. Odd powers behave like the simple factors, so for $x \ne 1, 12$ the sign is that of $\frac{x + 5}{x - 8}$, which is negative on $(-5, 8)$. Adding the zeros $x = -5$ and $x = 1$ and excluding $8$, the solution is $-5 \le x < 8$, $x \ne 12$, which has $13$ integers, $-5$ to $7$.",
  "Changing the sign at every critical point regardless of the power, or including a zero of the denominator.",
  "C11A-wavy-repeated", "Mixed odd and even powers in numerator and denominator, with different inclusion rules.",
  tita_answer=13, check=_c32,
  tita_traps=[(14, r"Includes $x = 8$, where the denominator is zero."),
              (10, r"Alternates the sign at every critical point, giving $-5 \le x \le 1$ and $8 < x < 12$.")],
  exams=CX, cognitive="Analysis")


def _c33():
    k = Symbol('k', real=True)
    # case k = 2: expression is the constant 4 > 0
    s = FiniteSet(2) if (4 > 0) else S.EmptySet
    # case k != 2: need k - 2 > 0 and discriminant < 0
    disc = (2 * (k - 2)) ** 2 - 4 * (k - 2) * 4
    s = Union(s, _all([k - 2 > 0, disc < 0], k))
    # independent numeric confirmation on a grid of k
    for j in range(-40, 120):
        kv = Rational(j, 8)
        e = (kv - 2) * X ** 2 + 2 * (kv - 2) * X + 4
        if kv == 2:
            pos = True
        else:
            pos = kv > 2 and Poly(e, X).count_roots() == 0
        assert pos == bool(s.contains(kv)), kv
    return s
q("C11-A-033", TOP, "Quadratic in x with a parameter leading coefficient positive for all x, including the degenerate case", "Difficult",
  "Inverse/parameter",
  r"The set of all real $k$ for which $(k - 2)x^2 + 2(k - 2)x + 4 > 0$ for every real number $x$ is",
  "MCQ",
  r"If $k = 2$ the expression is the constant $4 > 0$, so $k = 2$ works. If $k \ne 2$ we need $k - 2 > 0$ and a negative discriminant: $4(k - 2)^2 - 16(k - 2) < 0$, that is $(k - 2)(k - 6) < 0$, so $2 < k < 6$. At $k = 6$ the expression is $4(x + 1)^2$, which is $0$ at $x = -1$. Combining, $2 \le k < 6$.",
  "Missing the case where the expression stops being quadratic, or allowing a zero discriminant.",
  "C11A-always-positive", "Needs a separate degenerate case plus the leading-coefficient and discriminant conditions.",
  correct=r"$2 \le k < 6$",
  distractors=[(r"$2 < k < 6$", r"Uses only the quadratic conditions and misses $k = 2$, where the expression is the constant $4$."),
               (r"$2 \le k \le 6$", r"Allows a zero discriminant; at $k = 6$ the expression is $0$ at $x = -1$."),
               (r"$k \ge 2$", r"Checks only that the leading coefficient is not negative and ignores the discriminant.")],
  check=_c33,
  values=[Interval.Ropen(2, 6), Interval.open(2, 6), Interval(2, 6), Interval(2, oo)],
  exams=CX, cognitive="Analysis")


def _c34():
    a = Symbol('a', real=True)
    xx = Symbol('xx', real=True)
    f = xx ** 2 - a * xx + 12
    # minimum of f on [2, 4], by vertex casework: vertex at a/2
    s = S.EmptySet
    s = Union(s, _all([a / 2 <= 2, f.subs(xx, 2) > 0], a))
    s = Union(s, _all([a / 2 >= 4, f.subs(xx, 4) > 0], a))
    s = Union(s, _all([a / 2 > 2, a / 2 < 4, f.subs(xx, a / 2) > 0], a))
    # independent numeric confirmation: exact minimum over [2, 4] on a grid of a
    for j in range(-80, 161):
        av = Rational(j, 10)
        cand = [Rational(2), Rational(4)] + ([av / 2] if 2 < av / 2 < 4 else [])
        holds = min(c ** 2 - av * c + 12 for c in cand) > 0
        assert holds == bool(s.contains(av)), av
    return s
q("C11-A-034", TOP, "Parameter range for which a quadratic stays positive on a closed interval, by vertex casework", "Difficult",
  "Inverse/parameter",
  r"For which values of $a$ is $x^2 - ax + 12 > 0$ for every $x$ with $2 \le x \le 4$?",
  "MCQ",
  r"Let $f(x) = x^2 - ax + 12$, an upward parabola with vertex at $x = \frac{a}{2}$; we need the least value of $f$ on $[2, 4]$ to be positive. If $\frac{a}{2} \le 2$, the least value is $f(2) = 16 - 2a > 0$, true for all $a \le 4$. If $\frac{a}{2} \ge 4$, it is $f(4) = 28 - 4a > 0$, impossible for $a \ge 8$. If $4 < a < 8$, it is $f\left(\frac{a}{2}\right) = 12 - \frac{a^2}{4} > 0$, so $a < 4\sqrt{3} \approx 6.93$. Combining, $a < 4\sqrt{3}$.",
  "Testing only the endpoints of the interval, or demanding positivity for every real $x$.",
  "C11A-param-holds-on-interval", "Needs vertex casework (vertex left of, inside or right of the interval) rather than an endpoint or discriminant test.",
  correct=r"$a < 4\sqrt{3}$",
  distractors=[(r"$a < 7$", r"Tests only the endpoints: $f(2) > 0$ gives $a < 8$ and $f(4) > 0$ gives $a < 7$, missing that the vertex dips below $0$ for $4\sqrt{3} \le a < 7$."),
               (r"$a < 8$", r"Tests only the endpoint $x = 2$."),
               (r"$-4\sqrt{3} < a < 4\sqrt{3}$", r"Demands $f(x) > 0$ for every real $x$, using $a^2 - 48 < 0$; but for $a \le -4\sqrt{3}$ the vertex lies left of the interval and $f$ is positive on $[2, 4]$.")],
  check=_c34,
  values=[Interval.open(-oo, 4 * sqrt(3)), Interval.open(-oo, 7), Interval.open(-oo, 8), Interval.open(-4 * sqrt(3), 4 * sqrt(3))],
  exams=CX, cognitive="Analysis")


def _c35():
    total = 0
    for k in range(-100, 100):
        if _count(lambda n: n * n - 7 * n + k < 0, -100, 100) == 4:
            total += k
    return total
q("C11-A-035", TOP, "Integer parameters for which a quadratic inequality has exactly four integer solutions", "Difficult",
  "Inverse/parameter",
  r"Consider all integers $k$ for which the inequality $x^2 - 7x + k < 0$ has exactly $4$ integer solutions $x$. What is the sum of all such values of $k$?",
  "TITA",
  r"The roots are symmetric about $3.5$, so the solution set is $3.5 - d < x < 3.5 + d$ with $d = \sqrt{12.25 - k}$. Exactly $4$ integers means the solutions are $2, 3, 4, 5$: we need $1.5 < d \le 2.5$, that is $2.25 < 12.25 - k \le 6.25$, so $6 \le k < 10$. (At $k = 6$ the roots are $1$ and $6$, excluded, leaving $2$ to $5$; at $k = 10$ the roots are $2$ and $5$, leaving only $3, 4$.) So $k = 6, 7, 8, 9$, with sum $30$.",
  "Mishandling the boundary cases where the roots are integers.",
  "C11A-param-integer-count", "Requires the symmetry of the roots and careful treatment of integer roots at both boundaries.",
  tita_answer=30, check=_c35,
  tita_traps=[(40, r"Includes $k = 10$; then the roots $2$ and $5$ are excluded and only $3, 4$ remain."),
              (24, r"Excludes $k = 6$, thinking that integer roots $1$ and $6$ reduce the count.")],
  exams=CX, cognitive="Analysis")


def _c36():
    return len([(x, y) for x in range(-30, 31) for y in range(-60, 61) if y > x * x - 4 * x and y < x])
q("C11-A-036", TOP, "Lattice points strictly between a parabola and a line", "Difficult",
  "Casework/optimisation",
  r"How many pairs of integers $(x, y)$ satisfy both $y > x^2 - 4x$ and $y < x$?",
  "MCQ",
  r"We need $x^2 - 4x < y < x$, which requires $x^2 - 4x < x - 1$ for an integer $y$ to fit, so $x^2 - 5x + 1 < 0$ and $x \in \{1, 2, 3, 4\}$. For each $x$ the number of integers strictly between $x^2 - 4x$ and $x$ is $x - (x^2 - 4x) - 1$: for $x = 1, 2, 3, 4$ this is $3, 5, 5, 3$. Total $16$.",
  "Including boundary points or dropping an allowed column.",
  "C11A-lattice-count", "Combines a quadratic inequality for the column range with a strict count in each column.",
  correct=r"$16$",
  distractors=[(r"$26$", r"Uses $\ge$ and $\le$, counting boundary points and the extra columns $x = 0$ and $x = 5$."),
               (r"$20$", r"Counts $x - (x^2 - 4x)$ integers in each column, including one boundary."),
               (r"$6$", r"Counts only pairs of positive integers, dropping every point with $y \le 0$: $0 + 1 + 2 + 3$.")],
  check=_c36, values=[16, 26, 20, 6], exams=CX, cognitive="Analysis")


def _c37():
    return len([(x, y) for x in range(0, 60) for y in range(0, 60)
                if 20 <= x + y <= 30 and x >= 2 * y and y >= 5])
q("C11-A-037", TOP, "Counting integer pairs in a region defined by three linear constraints", "Difficult",
  "Casework/optimisation",
  r"A caterer is preparing $x$ vegetarian and $y$ non-vegetarian meal boxes for an event. The total number of boxes must be at least $20$ and at most $30$, the number of vegetarian boxes must be at least twice the number of non-vegetarian boxes, and at least $5$ non-vegetarian boxes are needed. How many different ordered pairs $(x, y)$ are possible?",
  "MCQ",
  r"Constraints: $20 \le x + y \le 30$, $x \ge 2y$, $y \ge 5$. For each $y$, $x$ runs from $\max(2y, 20 - y)$ to $30 - y$. $y = 5$: $15$ to $25$ ($11$); $y = 6$: $14$ to $24$ ($11$); $y = 7$: $14$ to $23$ ($10$); $y = 8$: $16$ to $22$ ($7$); $y = 9$: $18$ to $21$ ($4$); $y = 10$: $20$ to $20$ ($1$); $y = 11$ needs $x \ge 22$ and $x \le 19$, impossible. Total $44$.",
  "Dropping a constraint or switching which lower bound is active.",
  "C11A-lattice-count", "Column-by-column count where the active lower bound switches from one constraint to another.",
  correct=r"$44$",
  distractors=[(r"$40$", r"Reads at least twice as strictly more than twice, $x > 2y$."),
               (r"$51$", r"Ignores the lower limit of $20$ boxes, so $x$ starts at $2y$ in every column."),
               (r"$99$", r"Ignores the condition $y \ge 5$ and also counts $y = 0$ to $4$.")],
  check=_c37, values=[44, 40, 51, 99], exams=CX, cognitive="Analysis")


def _c38():
    return _count(lambda n: (n * n - 3 * n) ** 2 - 14 * (n * n - 3 * n) + 40 <= 0)
q("C11-A-038", TOP, "Quadratic in a quadratic expression: sandwich condition and integer count", "Difficult",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $(x^2 - 3x)^2 - 14(x^2 - 3x) + 40 \le 0$?",
  "TITA",
  r"Let $t = x^2 - 3x$. Then $t^2 - 14t + 40 = (t - 4)(t - 10) \le 0$, so $4 \le x^2 - 3x \le 10$. The left part, $x^2 - 3x - 4 = (x - 4)(x + 1) \ge 0$, gives $x \le -1$ or $x \ge 4$. The right part, $(x - 5)(x + 2) \le 0$, gives $-2 \le x \le 5$. Together: $-2 \le x \le -1$ or $4 \le x \le 5$, so the integers are $-2, -1, 4, 5$: $4$ integers.",
  "Using only one side of the double inequality in $t$.",
  "C11A-substitution", "A substitution yields a double inequality, each side a quadratic inequality, which must be intersected.",
  tita_answer=4, check=_c38,
  tita_traps=[(8, r"Uses only $x^2 - 3x \le 10$ and counts $-2$ to $5$."),
              (2, r"Keeps only the branch $x \ge 4$ of $x^2 - 3x \ge 4$.")],
  exams=CX, cognitive="Analysis")


def _c39():
    return _count(lambda n: (n * n + n) ** 2 - 8 * (n * n + n) + 12 > 0, -10, 10)
q("C11-A-039", TOP, "Quadratic in a quadratic expression: union of two cases counted in a window", "Difficult",
  "Casework/optimisation",
  r"How many integers $x$ with $-10 \le x \le 10$ satisfy $(x^2 + x)^2 - 8(x^2 + x) + 12 > 0$?",
  "MCQ",
  r"Let $t = x^2 + x$: $(t - 2)(t - 6) > 0$, so $t < 2$ or $t > 6$. Case $t < 2$: $(x + 2)(x - 1) < 0$, so $-2 < x < 1$, giving $-1, 0$. Case $t > 6$: $(x + 3)(x - 2) > 0$, so $x < -3$ or $x > 2$, giving $-10$ to $-4$ ($7$) and $3$ to $10$ ($8$). Total $2 + 7 + 8 = 17$.",
  "Solving only one of the two cases, or making the conditions non-strict.",
  "C11A-substitution", "A substitution yields two separate cases, each a quadratic inequality, counted inside a window.",
  correct=r"$17$",
  distractors=[(r"$15$", r"Solves only the case $t > 6$."),
               (r"$2$", r"Solves only the case $t < 2$."),
               (r"$21$", r"Uses $t \le 2$ or $t \ge 6$, adding $-2, 1, -3, 2$.")],
  check=_c39, values=[17, 15, 2, 21], exams=CX, cognitive="Analysis")


def _c40():
    p, qq = symbols('p q', real=True)
    sol = solve([(-3) ** 2 + p * (-3) + qq, 5 ** 2 + p * 5 + qq], [p, qq], dict=True)[0]
    # x^2 + px + q < 0 must have solution set (-3, 5)
    assert _set(X ** 2 + sol[p] * X + sol[qq] < 0) == Interval.open(-3, 5)
    return _set(sol[qq] * X ** 2 + sol[p] * X + 1 > 0)
q("C11-A-040", TOP, "Recovering coefficients from a solution set and solving the reversed-coefficient inequality", "Difficult",
  "Conceptual/application",
  r"The solution set of $x^2 + px + q < 0$ is $-3 < x < 5$. The set of all real $x$ satisfying $qx^2 + px + 1 > 0$ is",
  "MCQ",
  r"$-3$ and $5$ are the roots of $x^2 + px + q$, so $p = -(-3 + 5) = -2$ and $q = (-3)(5) = -15$. Then $-15x^2 - 2x + 1 > 0$; multiplying by $-1$ reverses it: $15x^2 + 2x - 1 < 0$, that is $(5x - 1)(3x + 1) < 0$. So $-\frac{1}{3} < x < \frac{1}{5}$. (The roots are the reciprocals $-\frac{1}{3}$ and $\frac{1}{5}$ of $-3$ and $5$.)",
  "Not reversing the inequality when the leading coefficient is negative, or taking the wrong sign for $p$.",
  "C11A-reverse-coefficients", "Two stages: reconstruct the coefficients from a solution set, then solve a quadratic with a negative leading coefficient.",
  correct=r"$-\frac{1}{3} < x < \frac{1}{5}$",
  distractors=[(r"$x < -\frac{1}{3}$ or $x > \frac{1}{5}$", r"Does not reverse the inequality after multiplying by $-1$."),
               (r"$-\frac{1}{5} < x < \frac{1}{3}$", r"Takes $p = 2$ (sum of roots without the minus sign), so solves $15x^2 - 2x - 1 < 0$."),
               (r"$x < -\frac{1}{5}$ or $x > \frac{1}{3}$", r"Takes $p = 2$ and also forgets to reverse the inequality.")],
  check=_c40,
  values=[Interval.open(Rational(-1, 3), Rational(1, 5)), Union(Interval.open(-oo, Rational(-1, 3)), Interval.open(Rational(1, 5), oo)),
          Interval.open(Rational(-1, 5), Rational(1, 3)), Union(Interval.open(-oo, Rational(-1, 5)), Interval.open(Rational(1, 3), oo))],
  exams=CX, cognitive="Analysis")
