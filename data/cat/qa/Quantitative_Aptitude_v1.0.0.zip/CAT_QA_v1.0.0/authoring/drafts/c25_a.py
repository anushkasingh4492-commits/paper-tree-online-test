import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from sympy.utilities.iterables import multiset_permutations as _mp
from itertools import permutations as _perms

T = "Arrangements"
CX = ("CAT", "XAT")
VOW = set("AEIOU")


def _arr(word):
    return ["".join(p) for p in _mp(list(word))]


def _adj(p, x, y):
    i, j = p.index(x), p.index(y)
    return abs(i - j) == 1


# 1
def _c1():
    return len(_arr("GOREGAON"))
q("C25-A-001", T, "All distinct arrangements of a word with two pairs of repeated letters", "Easy",
  "Single-step computation",
  r"A signboard painter has wooden letter tiles spelling GOREGAON and wants to try out every distinct arrangement of all eight tiles in a row (tiles showing the same letter are identical). How many distinct arrangements are possible?",
  "TITA",
  r"GOREGAON has $8$ letters in which G appears twice, O appears twice and R, E, A, N once each. The number of distinct arrangements is $\frac{8!}{2!\,2!} = \frac{40320}{4} = 10080$.",
  "Ignoring repeated letters, or correcting for only one of the two repeated letters.",
  "C25A-word-all-arrangements-repeated", "Direct use of the multiset formula with two repeated letters.",
  tita_answer=10080, check=_c1, values=[10080],
  tita_traps=[(40320, "Uses $8!$, treating the two G's and the two O's as different."),
              (20160, "Divides by only one $2!$, correcting for one repeated letter but not the other.")],
  cognitive="Application")

# 2
def _c2():
    return len(_arr("VADODARA"))
q("C25-A-002", T, "All distinct arrangements of a word with a letter repeated thrice and another twice", "Easy",
  "Single-step computation",
  r"How many distinct arrangements of all the letters of the word VADODARA are possible?",
  "MCQ",
  r"VADODARA has $8$ letters: A three times, D twice, and V, O, R once each. The count is $\frac{8!}{3!\,2!} = \frac{40320}{12} = 3360$.",
  "Correcting for only one repeated letter, or adding the factorials of the repeat counts instead of multiplying them.",
  "C25A-word-all-arrangements-repeated", "One formula, but two different repetition counts must both be divided out.",
  correct=r"$3360$",
  distractors=[(r"$6720$", r"Divides only by $3!$ for the A's and treats the two D's as different: $\frac{8!}{3!} = 6720$."),
               (r"$20160$", r"Divides only by $2!$ for the D's and treats the three A's as different: $\frac{8!}{2!} = 20160$."),
               (r"$5040$", r"Divides by $3! + 2! = 8$ instead of $3! \times 2! = 12$: $\frac{40320}{8} = 5040$.")],
  check=_c2, values=[3360, 6720, 20160, 5040], cognitive="Application")

# 3
def _c3():
    c = 0
    for w in _arr("DEHRADUN"):
        pos = [i for i, ch in enumerate(w) if ch in VOW]
        if max(pos) - min(pos) == 2:
            c += 1
    return c
q("C25-A-003", T, "Vowels together in a word that also has a repeated consonant", "Medium",
  "Multi-step word problem",
  r"In how many distinct arrangements of all the letters of the word DEHRADUN do the three vowels appear together (in consecutive positions, in any order among themselves)?",
  "TITA",
  r"Glue E, A, U into one block. The units are the block and D, H, R, D, N: $6$ units with D repeated, giving $\frac{6!}{2!} = 360$ arrangements. The block can be arranged internally in $3! = 6$ ways, so the answer is $360 \times 6 = 2160$.",
  "Forgetting the repeated D among the units, or forgetting to arrange the vowels inside the block.",
  "C25A-word-vowels-together-block", "Block method combined with a repeated letter outside the block.",
  tita_answer=2160, check=_c3, values=[2160],
  tita_traps=[(4320, r"Treats the two D's as different: $6! \times 3! = 4320$."),
              (360, r"Forgets the $3!$ internal arrangements of the vowel block.")],
  cognitive="Application")

# 4
def _c4():
    tog = notg = 0
    for w in _arr("SANSKRIT"):
        if abs(w.index("A") - w.index("I")) == 1:
            tog += 1
        else:
            notg += 1
    return Fraction(tog, notg)
q("C25-A-004", T, "Ratio of arrangements with the two vowels together to those with them apart", "Medium",
  "Conceptual/application",
  r"Consider all distinct arrangements of the letters of the word SANSKRIT. The ratio of the number of arrangements in which the two vowels are next to each other to the number in which they are not next to each other is",
  "MCQ",
  r"The total is $\frac{8!}{2!} = 20160$ (S is repeated). With A and I glued, there are $7$ units with S repeated: $\frac{7!}{2!} \times 2 = 5040$. So $20160 - 5040 = 15120$ have the vowels apart, and the ratio is $5040 : 15120 = 1 : 3$. (Quick check: A and I occupy a random pair of the $\binom{8}{2} = 28$ position pairs, of which $7$ are adjacent, so the split is $7 : 21$.)",
  "Comparing the favourable count with the total instead of with the complement, or dropping the internal swap of the vowel pair.",
  "C25A-word-vowels-together-block", "Needs both the block count and the complement, then a ratio.",
  correct=r"$1 : 3$",
  distractors=[(r"$1 : 4$", r"Compares the together count with the total: $5040 : 20160$."),
               (r"$1 : 7$", r"Forgets the swap of A and I in the block, getting $2520$ together and $17640$ apart."),
               (r"$1 : 2$", r"Subtracts the together count twice from the total, getting $10080$ apart.")],
  check=_c4, values=[Fraction(1, 3), Fraction(1, 4), Fraction(1, 7), Fraction(1, 2)], cognitive="Analysis")

# 5
def _c5():
    c = 0
    for w in _arr("SATELLITE"):
        if all(not (w[i] in VOW and w[i + 1] in VOW) for i in range(len(w) - 1)):
            c += 1
    return c
q("C25-A-005", T, "No two vowels adjacent, with repeated letters among both vowels and consonants", "Difficult",
  "Multi-step word problem",
  r"In how many distinct arrangements of all the letters of the word SATELLITE are no two vowels next to each other?",
  "MCQ",
  r"The consonants are S, T, T, L, L, arranged in $\frac{5!}{2!\,2!} = 30$ ways. They create $6$ gaps (including both ends), and the vowels A, E, I, E go into $4$ different gaps: $\binom{6}{4} = 15$ choices of gaps and $\frac{4!}{2!} = 12$ orders of the vowels. Total $30 \times 15 \times 12 = 5400$.",
  "Ignoring repetition on one side, or using only the gaps between consonants and not the two ends.",
  "C25A-word-no-two-vowels-gap", "Gap method with repeated letters among both vowels and consonants; three separate factors.",
  correct=r"$5400$",
  distractors=[(r"$10800$", r"Treats the two E's as different: $30 \times 15 \times 24$."),
               (r"$21600$", r"Treats the repeated T's and L's as different: $120 \times 15 \times 12$."),
               (r"$360$", r"Uses only the $4$ gaps between consonants, leaving out the two ends: $30 \times \binom{4}{4} \times 12$.")],
  check=_c5, values=[5400, 10800, 21600, 360], cognitive="Analysis", exams=CX)

# 6
def _c6():
    return sum(1 for w in _arr("PALLAVI") if "AA" not in w)
q("C25-A-006", T, "Two identical letters never adjacent, by the gap method", "Medium",
  "Multi-step word problem",
  r"In how many distinct arrangements of all the letters of the word PALLAVI are the two A's not next to each other?",
  "TITA",
  r"Arrange the other letters P, L, L, V, I in $\frac{5!}{2!} = 60$ ways. They leave $6$ gaps, and the two identical A's go into $2$ different gaps in $\binom{6}{2} = 15$ ways. Answer $60 \times 15 = 900$. (Check: total $\frac{7!}{2!\,2!} = 1260$, A's together $\frac{6!}{2!} = 360$, and $1260 - 360 = 900$.)",
  "Treating the two identical A's as distinct when placing them in gaps.",
  "C25A-word-no-two-vowels-gap", "Gap method where the separated letters are identical and the rest contain a repeat.",
  tita_answer=900, check=_c6, values=[900],
  tita_traps=[(1800, r"Places the A's as if distinct: $60 \times 6 \times 5$."),
              (540, r"Doubles the together count for a swap of identical A's: $1260 - 2 \times 360$.")],
  cognitive="Application")

# 7
def _c7():
    c = 0
    for w in _arr("MAHARANI"):
        if [ch for ch in w if ch not in VOW] == list("MHRN"):
            c += 1
    return c
q("C25-A-007", T, "Consonants kept in their original relative order", "Medium",
  "Conceptual/application",
  r"In how many distinct arrangements of all the letters of the word MAHARANI do the consonants M, H, R, N appear in the same relative order as in the word itself, that is M before H before R before N reading from left to right (not necessarily next to each other)?",
  "MCQ",
  r"Choose the $4$ positions for the consonants in $\binom{8}{4} = 70$ ways; the order M, H, R, N fills them in one way. The remaining $4$ positions take A, A, A, I in $\frac{4!}{3!} = 4$ ways. Total $70 \times 4 = 280$. Equivalently, $\frac{8!}{3!} = 6720$ arrangements divided by the $4! = 24$ orders of the consonants.",
  "Forgetting to arrange the vowels in the remaining positions, or treating the three A's as different.",
  "C25A-word-fixed-relative-order", "Fixed relative order needs the choose-positions insight plus a multiset count.",
  correct=r"$280$",
  distractors=[(r"$6720$", r"Ignores the order condition and counts all arrangements $\frac{8!}{3!}$."),
               (r"$70$", r"Chooses the consonant positions but leaves out the $4$ ways to place A, A, A, I."),
               (r"$1680$", r"Treats the three A's as different: $70 \times 4! = 1680$.")],
  check=_c7, values=[280, 6720, 70, 1680], cognitive="Analysis")

# 8
def _c8():
    names = ["Ravi", "Meera", "x1", "x2", "x3", "x4", "x5"]
    return sum(1 for p in _perms(names) if p.index("Ravi") < p.index("Meera"))
q("C25-A-008", T, "One person to the left of another, by symmetry", "Easy",
  "Conceptual/application",
  r"Seven runners, including Ravi and Meera, line up side by side in a single row at the start of a race. In how many ways can the line be formed if Ravi must be somewhere to the left of Meera (not necessarily next to her)?",
  "TITA",
  r"In every line-up either Ravi is left of Meera or Meera is left of Ravi, and swapping the two gives a one-to-one correspondence. So exactly half of the $7! = 5040$ line-ups work: $2520$.",
  "Reading 'to the left of' as 'immediately to the left of'.",
  "C25A-row-relative-order-symmetry", "One symmetry idea, one step.",
  tita_answer=2520, check=_c8, values=[2520],
  tita_traps=[(5040, "Ignores the condition and counts all line-ups."),
              (720, r"Treats it as Ravi immediately left of Meera: a fixed block with $6!$ arrangements.")],
  cognitive="Understanding")

# 9
def _c9():
    names = ["Ravi", "Meera", "Kabir", "x1", "x2", "x3", "x4", "x5"]
    c = 0
    for p in _perms(names):
        r = p.index("Ravi")
        if r < p.index("Meera") and r < p.index("Kabir"):
            c += 1
    return c
q("C25-A-009", T, "One person to the left of two others, by symmetry among three", "Medium",
  "Conceptual/application",
  r"Eight friends, including Ravi, Meera and Kabir, stand in a single row for a photograph. In how many arrangements is Ravi to the left of both Meera and Kabir (not necessarily next to either)?",
  "MCQ",
  r"Look only at the relative order of Ravi, Meera and Kabir. All $3! = 6$ orders are equally frequent, and Ravi comes first in $2$ of them. So the count is $\frac{1}{3} \times 8! = \frac{40320}{3} = 13440$.",
  "Imposing a full order on all three people, or treating the two conditions as independent halves.",
  "C25A-row-relative-order-symmetry", "Symmetry over three people, where the two conditions are not independent.",
  correct=r"$13440$",
  distractors=[(r"$6720$", r"Fixes the full order Ravi, Meera, Kabir: $\frac{8!}{3!}$."),
               (r"$20160$", r"Applies only one condition (Ravi left of Meera): $\frac{8!}{2}$."),
               (r"$10080$", r"Halves twice as if the two conditions were independent: $\frac{8!}{4}$.")],
  check=_c9, values=[13440, 6720, 20160, 10080], cognitive="Analysis")

# 10
def _c10():
    cons = set("THN")
    return sum(1 for w in _arr("THANE") if w[0] in cons and w[-1] in cons)
q("C25-A-010", T, "Words that begin and end with a consonant", "Easy",
  "Single-step computation",
  r"How many arrangements of all the letters of the word THANE begin with a consonant and also end with a consonant?",
  "MCQ",
  r"The consonants are T, H, N. Fill the first and last places with two different consonants in $3 \times 2 = 6$ ways, then arrange the remaining $3$ letters in the middle in $3! = 6$ ways. Total $6 \times 6 = 36$.",
  "Allowing the same consonant at both ends, or imposing the condition at only one end.",
  "C25A-word-letters-in-specified-places", "Fill restricted places first, then the rest.",
  correct=r"$36$",
  distractors=[(r"$54$", r"Chooses each end from the $3$ consonants independently, $3 \times 3$, then multiplies by $3!$."),
               (r"$72$", r"Imposes only the first letter: $3 \times 4! = 72$."),
               (r"$120$", r"Ignores both conditions: $5! = 120$.")],
  check=_c10, values=[36, 54, 72, 120], cognitive="Application")

# 11
def _c11():
    c = 0
    for w in _arr("PARAMETER"):
        if all((ch in VOW) == (i % 2 == 1) for i, ch in enumerate(w)):
            c += 1
    return c
q("C25-A-011", T, "Vowels filling exactly the even positions, with repeats on both sides", "Medium",
  "Multi-step word problem",
  r"The letters of the word PARAMETER are arranged in a row of nine positions numbered $1$ to $9$ from the left. In how many distinct arrangements do the vowels occupy the even-numbered positions?",
  "TITA",
  r"There are $4$ vowels (A, A, E, E) and exactly $4$ even positions, so the vowels fill them in $\frac{4!}{2!\,2!} = 6$ ways. The $5$ consonants P, R, R, M, T fill the $5$ odd positions in $\frac{5!}{2!} = 60$ ways. Total $6 \times 60 = 360$.",
  "Overlooking the repeated letters among the vowels or among the consonants.",
  "C25A-word-letters-in-specified-places", "Two separate multiset counts; the repeated R is easy to miss.",
  tita_answer=360, check=_c11, values=[360],
  tita_traps=[(2880, r"Ignores all repeats: $4! \times 5!$."),
              (720, r"Corrects the vowels but not the repeated R: $6 \times 5!$.")],
  cognitive="Application")

# 12
def _c12():
    c = 0
    for w in _arr("BENGALURU"):
        if all(i % 2 == 0 for i, ch in enumerate(w) if ch in VOW):
            c += 1
    return c
q("C25-A-012", T, "Vowels restricted to odd positions with one spare odd position", "Medium",
  "Multi-step word problem",
  r"The letters of the word BENGALURU are arranged in a row of nine positions numbered $1$ to $9$ from the left. In how many distinct arrangements does every vowel stand in an odd-numbered position?",
  "MCQ",
  r"The vowels are E, A, U, U and there are $5$ odd positions. Choose $4$ of them in $\binom{5}{4} = 5$ ways and arrange E, A, U, U there in $\frac{4!}{2!} = 12$ ways. The $5$ distinct consonants B, N, G, L, R fill the remaining $5$ positions in $5! = 120$ ways. Total $5 \times 12 \times 120 = 7200$.",
  "Missing the choice of which odd positions the vowels take, or treating the two U's as different.",
  "C25A-word-letters-in-specified-places", "Positions for the vowels must be chosen first, and one letter repeats.",
  correct=r"$7200$",
  distractors=[(r"$14400$", r"Treats the two U's as different: $5 \times 24 \times 120$."),
               (r"$1440$", r"Leaves out the $\binom{5}{4} = 5$ ways to choose the odd positions: $12 \times 120$."),
               (r"$600$", r"Chooses the positions but forgets to arrange the vowels in them: $5 \times 120$.")],
  check=_c12, values=[7200, 14400, 1440, 600], cognitive="Application")

# 13
def _c13():
    names = ["Arjun", "Fatima", "x1", "x2", "x3", "x4"]
    return sum(1 for p in _perms(names) if _adj(p, "Arjun", "Fatima"))
q("C25-A-013", T, "Two particular people together in a row", "Easy",
  "Single-step computation",
  r"Six friends, including Arjun and Fatima, stand in a row for a photograph. In how many ways can they stand if Arjun and Fatima must be next to each other?",
  "MCQ",
  r"Treat Arjun and Fatima as one unit. Then $5$ units can be arranged in $5! = 120$ ways, and the pair can stand in $2$ orders. Total $120 \times 2 = 240$.",
  "Forgetting that the pair can stand in two orders.",
  "C25A-row-people-together-block", "Single block idea.",
  correct=r"$240$",
  distractors=[(r"$120$", r"Forgets the $2$ orders of Arjun and Fatima inside the unit."),
               (r"$720$", r"Ignores the condition and counts all $6!$ line-ups."),
               (r"$480$", r"Counts the line-ups in which the two are apart: $720 - 240$.")],
  check=_c13, values=[240, 120, 720, 480], cognitive="Application")

# 14
def _c14():
    names = ["Ravi", "Meera", "Kabir", "Priya", "Joseph", "x1", "x2", "x3"]
    c = 0
    for p in _perms(names):
        pos = sorted(p.index(n) for n in ("Ravi", "Meera", "Kabir"))
        if pos[2] - pos[0] == 2 and not _adj(p, "Priya", "Joseph"):
            c += 1
    return c
q("C25-A-014", T, "A block of three together while another pair is kept apart", "Medium",
  "Multi-step word problem",
  r"Eight people, including Ravi, Meera, Kabir, Priya and Joseph, stand in a single row. Ravi, Meera and Kabir must stand together (in consecutive places, in any order among themselves), and Priya and Joseph must not stand next to each other. In how many ways can the row be formed?",
  "TITA",
  r"With the trio as one block there are $6$ units: $6! \times 3! = 4320$ rows. Among these, Priya and Joseph are adjacent when they too form a block: $5$ units, so $5! \times 3! \times 2 = 1440$. Answer $4320 - 1440 = 2880$.",
  "Ignoring the separation condition, or forgetting the internal order of the trio.",
  "C25A-row-people-together-block", "Combines a block with a complement count on top of it.",
  tita_answer=2880, check=_c14, values=[2880],
  tita_traps=[(4320, "Ignores the condition that Priya and Joseph must be apart."),
              (480, r"Forgets the $3!$ orders inside the trio: $720 - 240$.")],
  cognitive="Application")

# 15
def _c15():
    S = ["S1", "S2", "S3"]; G = ["G1", "G2"]
    names = S + G + ["x1", "x2", "x3", "x4"]
    c = 0
    for p in _perms(names):
        sp = sorted(p.index(n) for n in S); gp = sorted(p.index(n) for n in G)
        if sp[2] - sp[0] != 2 or gp[1] - gp[0] != 1:
            continue
        if sp[2] + 1 == gp[0] or gp[1] + 1 == sp[0]:
            continue
        c += 1
    return c
q("C25-A-015", T, "Two family blocks, each kept together, with the blocks not adjacent", "Difficult",
  "Casework/optimisation",
  r"Nine people stand in a row for a photograph: the three members of the Sharma family, the two members of the Gupta family and four friends. The Sharmas must stand together (in consecutive places), the Guptas must stand together, and no Sharma may stand next to a Gupta. In how many ways can the row be formed?",
  "MCQ",
  r"Treat each family as a block. With $2$ blocks and $4$ friends there are $6$ units, arranged in $6! = 720$ ways, of which $2 \times 5! = 240$ have the two blocks adjacent (in either order). So $720 - 240 = 480$ unit orders keep the blocks apart. Inside the blocks there are $3! \times 2! = 12$ orders. Total $480 \times 12 = 5760$.",
  "Ignoring the non-adjacency of the blocks, missing one internal order, or counting only one order of the two adjacent blocks.",
  "C25A-row-people-together-block", "Two blocks, a complement for block adjacency and two internal orders; several factors to track.",
  correct=r"$5760$",
  distractors=[(r"$8640$", r"Ignores the condition that the families are not adjacent: $6! \times 12$."),
               (r"$2880$", r"Forgets the $2!$ internal order of the Guptas: $480 \times 3!$."),
               (r"$7200$", r"Subtracts only $5!$ for adjacent blocks, missing that either family can come first: $(720 - 120) \times 12$.")],
  check=_c15, values=[5760, 8640, 2880, 7200], cognitive="Analysis", exams=CX)

# 16
def _c16():
    names = ["b1", "b2", "b3", "b4", "g1", "g2", "g3"]
    c = 0
    for p in _perms(names):
        if all(not (p[i][0] == "g" and p[i + 1][0] == "g") for i in range(6)):
            c += 1
    return c
q("C25-A-016", T, "No two girls adjacent, gap method", "Easy",
  "Single-step computation",
  r"Four boys and three girls, all of different heights, stand in a single row. In how many ways can they stand if no two girls are next to each other?",
  "TITA",
  r"Arrange the boys first in $4! = 24$ ways. This leaves $5$ gaps (including both ends). Place the three girls in $3$ different gaps, in order: $5 \times 4 \times 3 = 60$ ways. Total $24 \times 60 = 1440$.",
  "Forgetting to arrange the girls in the chosen gaps, or using only the gaps between boys.",
  "C25A-row-gap-method-separation", "Standard gap method.",
  tita_answer=1440, check=_c16, values=[1440],
  tita_traps=[(240, r"Chooses the gaps but does not arrange the girls: $24 \times \binom{5}{3}$."),
              (144, r"Uses only the $3$ gaps between boys, leaving out the ends: $24 \times 3!$.")],
  cognitive="Application")

# 17
def _c17():
    names = ["m1", "m2", "m3", "m4", "m5", "w1", "w2", "w3"]
    c = 0
    for p in _perms(names):
        if p[0][0] == "w" and p[-1][0] == "w" and all(not (p[i][0] == "w" and p[i + 1][0] == "w") for i in range(7)):
            c += 1
    return c
q("C25-A-017", T, "Women at both ends and no two women adjacent", "Medium",
  "Multi-step word problem",
  r"Five men and three women stand in a single row. Both ends of the row must be occupied by women, and no two women may stand next to each other. In how many ways can the row be formed?",
  "MCQ",
  r"Arrange the men in $5! = 120$ ways. The two end gaps must hold women, and the third woman must go into one of the $4$ gaps between men. The three women can be arranged in the three chosen gaps in $3! = 6$ ways. Total $120 \times 4 \times 6 = 2880$.",
  "Dropping the end condition, or re-counting the end gaps when placing the third woman.",
  "C25A-row-gap-method-separation", "Gap method with forced gaps; an extra condition to apply correctly.",
  correct=r"$2880$",
  distractors=[(r"$14400$", r"Ignores the ends condition: $120 \times \binom{6}{3} \times 3!$."),
               (r"$480$", r"Forgets to arrange the three women: $120 \times 4$."),
               (r"$4320$", r"Lets the third woman choose from all $6$ gaps, including the end gaps already used: $120 \times 6 \times 6$.")],
  check=_c17, values=[2880, 14400, 480, 4320], cognitive="Application")

# 18
def _c18():
    names = ["Priya", "Ravi", "Meera", "Kabir", "x1", "x2", "x3", "x4"]
    trio = {"Ravi", "Meera", "Kabir"}
    c = 0
    for p in _perms(names):
        i = p.index("Priya")
        if not any(0 <= j < 8 and p[j] in trio for j in (i - 1, i + 1)):
            c += 1
    return c
q("C25-A-018", T, "One person kept away from each of three named people, with end and interior cases", "Difficult",
  "Casework/optimisation",
  r"Eight people, including Priya, Ravi, Meera and Kabir, stand in a single row. Priya does not want to stand next to Ravi, next to Meera or next to Kabir. In how many ways can the row be formed?",
  "TITA",
  r"Place Priya first and fill her neighbouring places from the $4$ people other than Ravi, Meera and Kabir. If Priya is at either end ($2$ places), her one neighbour can be chosen in $4$ ways and the other $6$ people fill the rest in $6! = 720$ ways: $2 \times 4 \times 720 = 5760$. If Priya is in one of the $6$ inner places, her two neighbours are chosen and ordered in $4 \times 3 = 12$ ways and the other $5$ people fill the rest in $5! = 120$ ways: $6 \times 12 \times 120 = 8640$. Total $5760 + 8640 = 14400$.",
  "Giving Priya two neighbours in every place, or subtracting the three adjacency counts without adding back the overlaps.",
  "C25A-row-person-apart-from-group", "Neighbour counts differ for end and inner places, so two cases are needed; a naive complement double-subtracts overlaps.",
  tita_answer=14400, check=_c18, values=[14400],
  tita_traps=[(11520, r"Treats every place as having two neighbours: $8 \times 4 \times 3 \times 5!$."),
              (10080, r"Subtracts $3 \times 2 \times 7!$ from $8!$ without adding back rows where Priya stands between two of the three."),
              (8640, "Counts only the rows with Priya in an inner place.")],
  cognitive="Analysis", exams=CX)

# 19
def _c19():
    names = ["b1", "b2", "b3", "b4", "b5", "g1", "g2", "g3", "g4"]
    c = 0
    for p in _perms(names):
        if all(p[i][0] != p[i + 1][0] for i in range(8)):
            c += 1
    return c
q("C25-A-019", T, "Boys and girls alternating with unequal numbers", "Easy",
  "Single-step computation",
  r"Five boys and four girls stand in a single row so that boys and girls alternate (no two boys are next to each other and no two girls are next to each other). In how many ways can this be done?",
  "MCQ",
  r"With $5$ boys and $4$ girls, the only alternating pattern is boy, girl, boy, girl, and so on, ending with a boy, so the row must start and end with a boy. The boys fill their places in $5! = 120$ ways and the girls in $4! = 24$ ways. Total $120 \times 24 = 2880$.",
  "Multiplying by $2$ for starting with either gender, which is possible only when the numbers are equal.",
  "C25A-row-alternating-pattern", "Single pattern; the trap is the factor of $2$.",
  correct=r"$2880$",
  distractors=[(r"$5760$", r"Multiplies by $2$ for starting with a girl, but that pattern needs $5$ girls."),
               (r"$144$", r"Adds instead of multiplying: $5! + 4!$."),
               (r"$43200$", r"Counts only no two girls together: $5! \times 6 \times 5 \times 4 \times 3$.")],
  check=_c19, values=[2880, 5760, 144, 43200], cognitive="Understanding")

# 20
def _c20():
    names = ["Ravi", "m2", "m3", "m4", "Meera", "w2", "w3", "w4"]
    c = 0
    for p in _perms(names):
        if all(p[i][0] in "Rm" and p[i + 1][0] in "Mw" or p[i][0] in "Mw" and p[i + 1][0] in "Rm" for i in range(7)):
            if _adj(p, "Ravi", "Meera"):
                c += 1
    return c
q("C25-A-020", T, "Alternating men and women with a particular couple adjacent", "Difficult",
  "Conceptual/application",
  r"Four men (including Ravi) and four women (including his wife Meera) stand in a single row so that men and women alternate. In how many such arrangements are Ravi and Meera next to each other?",
  "TITA",
  r"There are $2$ alternating patterns (starting with a man or with a woman). In either pattern, each of the $7$ pairs of neighbouring places consists of one man's place and one woman's place, so Ravi and Meera can occupy a neighbouring pair in exactly $7$ ways. The other $3$ men and $3$ women fill their places in $3! \times 3! = 36$ ways. Total $2 \times 7 \times 36 = 504$.",
  "Forgetting the second pattern, or treating the couple as a free block without respecting the pattern.",
  "C25A-row-alternating-pattern", "Needs the observation that every adjacent pair of places is one man and one woman in an alternating row.",
  tita_answer=504, check=_c20, values=[504],
  tita_traps=[(252, "Counts only the pattern that starts with a man."),
              (1152, r"Counts all alternating rows, $2 \times 4! \times 4!$, without the adjacency condition.")],
  cognitive="Analysis", exams=CX)

# 21
def _c21():
    c = 0
    for w in _arr("NAINITAL"):
        if all((w[i] in VOW) != (w[i + 1] in VOW) for i in range(7)):
            c += 1
    return c
q("C25-A-021", T, "Vowels and consonants alternating in a word with repeated letters", "Medium",
  "Multi-step word problem",
  r"In how many distinct arrangements of all the letters of the word NAINITAL do vowels and consonants alternate?",
  "MCQ",
  r"NAINITAL has $4$ vowels (A, A, I, I) and $4$ consonants (N, N, T, L). With equal numbers there are $2$ patterns (starting with a vowel or with a consonant). In each, the vowels can be placed in $\frac{4!}{2!\,2!} = 6$ ways and the consonants in $\frac{4!}{2!} = 12$ ways. Total $2 \times 6 \times 12 = 144$.",
  "Using a single pattern, or overlooking repeated letters.",
  "C25A-row-alternating-pattern", "Alternation with two patterns and repeated letters in both groups.",
  correct=r"$144$",
  distractors=[(r"$72$", r"Uses only one pattern, $6 \times 12$."),
               (r"$1152$", r"Ignores all repeats: $2 \times 4! \times 4!$."),
               (r"$288$", r"Corrects the vowels but treats the two N's as different: $2 \times 6 \times 24$.")],
  check=_c21, values=[144, 72, 1152, 288], cognitive="Application")

# 22
def _c22():
    names = ["Sneha", "x1", "x2", "x3", "x4", "x5", "x6"]
    return sum(1 for p in _perms(names) if p.index("Sneha") not in (0, 6))
q("C25-A-022", T, "A person kept away from both ends", "Easy",
  "Single-step computation",
  r"Seven students, including Sneha, stand in a single row for an assembly. In how many ways can they stand if Sneha must not be at either end of the row?",
  "TITA",
  r"Sneha can take any of the $5$ middle places, and the other $6$ students fill the remaining places in $6! = 720$ ways. Total $5 \times 720 = 3600$.",
  "Excluding only one end, or counting the arrangements with Sneha at an end.",
  "C25A-row-restricted-places", "One restricted person; one step.",
  tita_answer=3600, check=_c22, values=[3600],
  tita_traps=[(4320, r"Excludes only one end: $6 \times 6!$."),
              (1440, r"Counts Sneha at an end: $2 \times 6!$.")],
  cognitive="Application")

# 23
def _c23():
    names = ["Harpreet", "Ananya", "x1", "x2", "x3", "x4", "x5", "x6"]
    return sum(1 for p in _perms(names) if p[0] != "Harpreet" and p[-1] != "Ananya")
q("C25-A-023", T, "Two people each barred from one end, inclusion and exclusion", "Medium",
  "Multi-step word problem",
  r"Eight people, including Harpreet and Ananya, stand in a single row. Harpreet refuses to stand at the left end, and Ananya refuses to stand at the right end. In how many ways can the row be formed?",
  "MCQ",
  r"Total $8! = 40320$. Harpreet at the left end: $7! = 5040$; Ananya at the right end: $5040$; both: $6! = 720$. Good rows $= 40320 - 5040 - 5040 + 720 = 30960$.",
  "Not adding back the rows where both restrictions are broken, or treating the two placements as independent.",
  "C25A-row-restricted-places", "Two overlapping restrictions need inclusion and exclusion.",
  correct=r"$30960$",
  distractors=[(r"$30240$", r"Subtracts both bad cases but does not add back the $6!$ rows counted twice."),
               (r"$29520$", r"Subtracts the overlap $6!$ a third time instead of adding it back."),
               (r"$35280$", r"Gives each of Harpreet and Ananya $7$ places independently: $7 \times 7 \times 6!$.")],
  check=_c23, values=[30960, 30240, 29520, 35280], cognitive="Application")

# 24
def _c24():
    names = ["T", "s1", "s2", "t2", "t3", "x1", "x2"]
    return sum(1 for p in _perms(names) if p[3] == "T" and not _adj(p, "s1", "s2") and not _adj(p, "t2", "t3"))
q("C25-A-024", T, "Fixed middle person splitting the row, then two non-adjacency conditions", "Difficult",
  "Casework/optimisation",
  r"Seven players of different heights stand in a single row for a team photograph. The tallest player must stand in the middle (fourth) place, the two shortest players must not stand next to each other, and the second tallest and third tallest players must not stand next to each other. In how many ways can the row be formed?",
  "MCQ",
  r"With the tallest fixed in place $4$, the other $6$ fill places $1, 2, 3, 5, 6, 7$ in $6! = 720$ ways. The neighbouring pairs among these places are $(1,2), (2,3), (5,6), (6,7)$; places $3$ and $5$ are separated by the tallest player. The two shortest are adjacent in $4 \times 2 \times 4! = 192$ rows, and likewise the second and third tallest in $192$ rows. Both pairs are adjacent when they take two disjoint neighbouring pairs: $4$ choices for the shortest pair, then $2$ disjoint pairs for the other, with $2 \times 2$ internal orders and $2! = 2$ for the remaining two players, giving $4 \times 2 \times 4 \times 2 = 64$. Answer $720 - 192 - 192 + 64 = 400$.",
  "Not adding back the rows where both pairs are adjacent, or treating places $3$ and $5$ as neighbours.",
  "C25A-row-restricted-places", "The fixed middle player breaks the row, and two adjacency conditions need inclusion and exclusion with a careful overlap count.",
  correct=r"$400$",
  distractors=[(r"$336$", r"Subtracts both adjacency counts but does not add back the $64$ rows where both pairs are adjacent: $720 - 384$."),
               (r"$528$", r"Applies only the condition on the two shortest players: $720 - 192$."),
               (r"$352$", r"Counts the overlap without the internal orders of the two pairs: $720 - 384 + 4 \times 2 \times 2$.")],
  check=_c24, values=[400, 336, 528, 352], cognitive="Analysis", exams=CX)

# 25
def _c25():
    return sum(1 for p in _perms(range(1, 8), 4) if p[3] % 2 == 0)
q("C25-A-025", T, "Even four-digit numbers from given non-zero digits without repetition", "Easy",
  "Single-step computation",
  r"How many four-digit even numbers can be formed using the digits $1, 2, 3, 4, 5, 6, 7$, if no digit is repeated within a number?",
  "MCQ",
  r"The units digit must be $2$, $4$ or $6$: $3$ choices. The other three places are filled from the remaining $6$ digits in $6 \times 5 \times 4 = 120$ ways. Total $3 \times 120 = 360$.",
  "Assuming half of all such numbers are even, or forgetting the choice of the units digit.",
  "C25A-digits-no-repeat-divisibility", "Fill the restricted units place first.",
  correct=r"$360$",
  distractors=[(r"$840$", r"Counts all four-digit numbers $7 \times 6 \times 5 \times 4$, ignoring evenness."),
               (r"$420$", r"Takes half of $840$, but only $3$ of the $7$ digits are even."),
               (r"$120$", r"Fixes an even units digit but does not multiply by its $3$ choices.")],
  check=_c25, values=[360, 840, 420, 120], cognitive="Application")

# 26
def _c26():
    return sum(1 for p in _perms(range(7), 4) if p[0] != 0 and p[3] in (0, 5))
q("C25-A-026", T, "Four-digit multiples of 5 with zero among the digits", "Medium",
  "Multi-step word problem",
  r"Four-digit numbers are formed using the digits $0, 1, 2, 3, 4, 5, 6$, with no digit repeated within a number. How many of them are divisible by $5$?",
  "TITA",
  r"Units digit $0$: the other three places take any of the remaining $6$ digits, $6 \times 5 \times 4 = 120$. Units digit $5$: the first digit cannot be $0$ or $5$, so $5$ choices, then $5 \times 4 = 20$ for the middle places, giving $100$. Total $120 + 100 = 220$.",
  "Not splitting into the units digit $0$ and $5$ cases, so the leading-zero restriction is mishandled.",
  "C25A-digits-no-repeat-divisibility", "Two cases because zero interacts with the leading place.",
  tita_answer=220, check=_c26, values=[220],
  tita_traps=[(240, r"Treats both cases like the units digit $0$ case: $2 \times 120$."),
              (200, r"Treats both cases like the units digit $5$ case: $2 \times 100$.")],
  cognitive="Application")

# 27
def _c27():
    c = 0
    for n in range(50000, 100000):
        s = str(n)
        if n % 2 == 0 and len(set(s)) == 5:
            c += 1
    return c
q("C25-A-027", T, "Even five-digit numbers above a bound with distinct digits", "Difficult",
  "Casework/optimisation",
  r"How many five-digit numbers greater than $50000$ have all five digits different and are even?",
  "MCQ",
  r"The first digit is $5, 6, 7, 8$ or $9$. If it is $6$ or $8$ (even), the units digit is one of the other $4$ even digits; if it is $5, 7$ or $9$, the units digit has all $5$ even choices. The middle three places take $8 \times 7 \times 6 = 336$ ways in each case. Total $(2 \times 4 + 3 \times 5) \times 336 = 23 \times 336 = 7728$.",
  "Not splitting by the parity of the first digit, or assuming exactly half of the numbers are even.",
  "C25A-digits-no-repeat-divisibility", "The leading and units digits compete for even digits; casework on the first digit is needed.",
  correct=r"$7728$",
  distractors=[(r"$8400$", r"Always gives the units digit $5$ even choices: $5 \times 5 \times 336$."),
               (r"$6720$", r"Always gives the units digit $4$ even choices: $5 \times 4 \times 336$."),
               (r"$7560$", r"Takes half of all $5 \times 9 \times 8 \times 7 \times 6 = 15120$ such numbers.")],
  check=_c27, values=[7728, 8400, 6720, 7560], cognitive="Analysis", exams=CX)

# 28
def _c28():
    return sum(1 for p in _perms([2, 3, 5, 7, 8], 3) if 100 * p[0] + 10 * p[1] + p[2] > 500)
q("C25-A-028", T, "Three-digit numbers above a bound from given digits", "Easy",
  "Single-step computation",
  r"How many three-digit numbers greater than $500$ can be formed using the digits $2, 3, 5, 7, 8$, if no digit is repeated within a number?",
  "MCQ",
  r"The hundreds digit must be $5$, $7$ or $8$ (any number starting with $5$ and having distinct digits exceeds $500$). The tens and units places then take $4 \times 3 = 12$ ways. Total $3 \times 12 = 36$.",
  "Excluding the hundreds digit $5$, or allowing repetition.",
  "C25A-digits-range-bounds", "One restricted place, with a small trap at the boundary digit.",
  correct=r"$36$",
  distractors=[(r"$60$", r"Counts all three-digit numbers $5 \times 4 \times 3$, ignoring the bound."),
               (r"$75$", r"Allows repeated digits: $3 \times 5 \times 5$."),
               (r"$24$", r"Excludes the hundreds digit $5$ as if no such number could exceed $500$: $2 \times 12$.")],
  check=_c28, values=[36, 60, 75, 24], cognitive="Application")

# 29
def _c29():
    D = [0, 2, 3, 4, 6, 9]; c = 0
    for k in range(1, 7):
        for p in _perms(D, k):
            if p[0] == 0:
                continue
            if int("".join(map(str, p))) > 4000:
                c += 1
    return c
q("C25-A-029", T, "Numbers of any length above a bound, digits used at most once", "Medium",
  "Multi-step word problem",
  r"Numbers are formed using the digits $0, 2, 3, 4, 6, 9$, each digit used at most once in a number (and no number begins with $0$). How many such numbers are greater than $4000$?",
  "MCQ",
  r"Four-digit numbers above $4000$ start with $4$, $6$ or $9$ (and $4000$ itself repeats a digit), giving $3 \times 5 \times 4 \times 3 = 180$. Five-digit numbers: $5 \times 5 \times 4 \times 3 \times 2 = 600$. Six-digit numbers: $5 \times 5! = 600$. Total $180 + 600 + 600 = 1380$.",
  "Counting only four-digit numbers, or forgetting the lead digit restriction for them.",
  "C25A-digits-range-bounds", "Three length cases with the leading-zero rule.",
  correct=r"$1380$",
  distractors=[(r"$180$", "Counts only the four-digit numbers."),
               (r"$1200$", "Counts only the five-digit and six-digit numbers."),
               (r"$1500$", r"Lets any non-zero digit lead a four-digit number: $5 \times 60 + 600 + 600$.")],
  check=_c29, values=[1380, 180, 1200, 1500], cognitive="Application")

# 30
def _c30():
    return sum(1 for p in _perms([1, 3, 5, 7, 8, 9], 4) if int("".join(map(str, p))) > 5300 and p[3] % 2 == 1)
q("C25-A-030", T, "Odd four-digit numbers above a bound with casework on the first two digits", "Difficult",
  "Casework/optimisation",
  r"Four-digit numbers are formed using the digits $1, 3, 5, 7, 8, 9$, with no digit repeated within a number. How many of them are odd and greater than $5300$?",
  "MCQ",
  r"First digit $7$ or $9$: the units digit is one of the other $4$ odd digits and the middle places take $4 \times 3$, giving $2 \times 4 \times 12 = 96$. First digit $8$: $5$ odd units digits, $5 \times 12 = 60$. First digit $5$: second digit $7$ or $9$ gives $2 \times 3 \times 3 = 18$; second digit $8$ gives $4 \times 3 = 12$; second digit $3$ gives $3 \times 3 = 9$ (all such numbers exceed $5300$). Total $96 + 60 + 18 + 12 + 9 = 195$.",
  "Missing the numbers starting $53$, or not restricting the second digit when the first is $5$.",
  "C25A-digits-range-bounds", "Two-level casework combining a bound with a parity condition.",
  correct=r"$195$",
  distractors=[(r"$186$", r"Leaves out the $9$ numbers beginning with $53$."),
               (r"$204$", r"Counts every odd number beginning with $5$ as above $5300$, including those beginning $51$: $96 + 60 + 4 \times 12$."),
               (r"$156$", "Ignores the numbers beginning with $5$ altogether.")],
  check=_c30, values=[195, 186, 204, 156], cognitive="Analysis", exams=CX)

# 31
def _c31():
    return sum(1 for n in range(10000) if len(set(str(n).zfill(4))) < 4)
q("C25-A-031", T, "Codes with at least one repeated digit, by complement", "Easy",
  "Single-step computation",
  r"A bank issues four-digit PINs; every string from $0000$ to $9999$ is allowed. How many PINs have at least one digit appearing more than once?",
  "MCQ",
  r"There are $10^4 = 10000$ PINs in all, and $10 \times 9 \times 8 \times 7 = 5040$ have all digits different. So $10000 - 5040 = 4960$ have a repeated digit.",
  "Reporting the all-different count, treating PINs as numbers that cannot start with $0$, or counting only one repeated pair.",
  "C25A-digits-repetition-complement", "Complement of the all-distinct count.",
  correct=r"$4960$",
  distractors=[(r"$5040$", "Reports the number of PINs with all digits different."),
               (r"$4464$", r"Treats PINs as numbers from $1000$ to $9999$: $9000 - 4536$."),
               (r"$4320$", r"Counts only PINs with exactly one pair and two other different digits: $\binom{4}{2} \times 10 \times 9 \times 8$.")],
  check=_c31, values=[4960, 5040, 4464, 4320], cognitive="Application")

# 32
def _c32():
    return sum(1 for n in range(10000, 100000) if str(n).count("9") == 2)
q("C25-A-032", T, "Five-digit numbers with a digit appearing exactly twice", "Difficult",
  "Casework/optimisation",
  r"How many five-digit numbers contain the digit $9$ exactly twice?",
  "TITA",
  r"Case 1, first digit $9$: the second $9$ takes one of $4$ places and the other $3$ places take any of the $9$ non-nine digits: $4 \times 9^3 = 2916$. Case 2, first digit not $9$ (and not $0$): $8$ choices, the two $9$s take $2$ of the other $4$ places in $\binom{4}{2} = 6$ ways, and the remaining $2$ places take $9^2 = 81$: $8 \times 6 \times 81 = 3888$. Total $2916 + 3888 = 6804$.",
  "Placing the two $9$s anywhere and ignoring that the first digit cannot be $0$.",
  "C25A-digits-repetition-complement", "Leading-digit restriction forces a split into two cases.",
  tita_answer=6804, check=_c32, values=[6804],
  tita_traps=[(7290, r"Ignores the leading-zero issue: $\binom{5}{2} \times 9^3$."),
              (3888, "Counts only numbers whose first digit is not $9$.")],
  cognitive="Analysis", exams=CX)

# 33
def _c33():
    return sum(1 for p in _perms(range(1, 7), 4) if (10 * p[2] + p[3]) % 4 == 0)
q("C25-A-033", T, "Four-digit multiples of 4 from given digits without repetition", "Medium",
  "Multi-step word problem",
  r"Four-digit numbers are formed using the digits $1, 2, 3, 4, 5, 6$, with no digit repeated within a number. How many of them are divisible by $4$?",
  "MCQ",
  r"A number is divisible by $4$ when its last two digits are. With distinct digits from the set, the possible endings are $12, 16, 24, 32, 36, 52, 56, 64$: $8$ endings. The first two places are filled from the remaining $4$ digits in $4 \times 3 = 12$ ways. Total $8 \times 12 = 96$.",
  "Using only evenness of the last digit, dividing the total by $4$, or including the ending $44$.",
  "C25A-digits-divisibility-rules", "Divisibility test applied to the last two digits, listing endings.",
  correct=r"$96$",
  distractors=[(r"$90$", r"Takes a quarter of all $360$ such numbers."),
               (r"$180$", r"Checks only that the last digit is even: $3 \times 5 \times 4 \times 3$."),
               (r"$108$", r"Includes $44$ as a ninth ending although it repeats a digit: $9 \times 12$.")],
  check=_c33, values=[96, 90, 180, 108], cognitive="Application")

# 34
def _c34():
    D = [0, 1, 3, 4, 6, 8]
    return sum(1 for p in _perms(D, 5) if p[0] != 0 and int("".join(map(str, p))) % 6 == 0)
q("C25-A-034", T, "Five-digit multiples of 6 by choosing the omitted digit", "Difficult",
  "Casework/optimisation",
  r"Five-digit numbers are formed using five of the six digits $0, 1, 3, 4, 6, 8$, with no digit repeated. How many of these numbers are divisible by $6$?",
  "TITA",
  r"The six digits sum to $22$, so the omitted digit $d$ must satisfy $22 - d \equiv 0 \pmod 3$, giving $d = 1$ or $d = 4$. Omit $1$ (use $0, 3, 4, 6, 8$): the units digit is even; units $0$ gives $4! = 24$, units $4, 6$ or $8$ gives $3 \times 3 \times 3! = 54$, total $78$. Omit $4$ (use $0, 1, 3, 6, 8$): units $0$ gives $24$, units $6$ or $8$ gives $2 \times 3 \times 6 = 36$, total $60$. Answer $78 + 60 = 138$.",
  "Forgetting the leading-zero restriction, or checking divisibility by $3$ only.",
  "C25A-digits-divisibility-rules", "Combines the digit-sum test with evenness and zero handling in two cases.",
  tita_answer=138, check=_c34, values=[138],
  tita_traps=[(168, r"Allows $0$ as the leading digit."),
              (192, r"Checks divisibility by $3$ only, not evenness.")],
  cognitive="Analysis", exams=CX)

# 35
def _c35():
    names = ["Kabir", "Priya"] + ["x%d" % i for i in range(7)]
    return sum(1 for p in _perms(names) if abs(p.index("Kabir") - p.index("Priya")) == 4)
q("C25-A-035", T, "Exactly three people between two particular people", "Medium",
  "Multi-step word problem",
  r"Nine people, including Kabir and Priya, stand in a single row. In how many arrangements are there exactly three people standing between Kabir and Priya?",
  "MCQ",
  r"Places $i$ and $i + 4$ with $i = 1, \ldots, 5$ give $5$ pairs of places for the two, and they can take them in $2$ orders. The other $7$ people fill the rest in $7! = 5040$ ways. Total $5 \times 2 \times 5040 = 50400$.",
  "Forgetting the two orders of Kabir and Priya, or not arranging the people between them.",
  "C25A-row-exact-separation", "Count place pairs at a fixed distance, then arrange the rest.",
  correct=r"$50400$",
  distractors=[(r"$25200$", r"Forgets that Kabir and Priya can swap: $5 \times 7!$."),
               (r"$8400$", r"Chooses the three in between without ordering them: $\binom{7}{3} \times 2 \times 5!$."),
               (r"$151200$", r"Counts at least three people between them: $15$ place pairs $\times 2 \times 7!$.")],
  check=_c35, values=[50400, 25200, 8400, 151200], cognitive="Application")

# 36
def _c36():
    names = ["Ravi", "Sneha", "x1", "x2", "x3", "x4"]
    return sum(1 for p in _perms(names) if abs(p.index("Ravi") - p.index("Sneha")) == 2)
q("C25-A-036", T, "Exactly one person between two particular people", "Easy",
  "Single-step computation",
  r"Six people, including Ravi and Sneha, stand in a single row. In how many arrangements is there exactly one person standing between Ravi and Sneha?",
  "MCQ",
  r"Pick the person in the middle in $4$ ways and the order of Ravi and Sneha in $2$ ways. This trio is one block, so with the other $3$ people there are $4$ units, arranged in $4! = 24$ ways. Total $4 \times 2 \times 24 = 192$.",
  "Forgetting the choice of the person in between, or the order of Ravi and Sneha.",
  "C25A-row-exact-separation", "Block containing a chosen middle person.",
  correct=r"$192$",
  distractors=[(r"$96$", "Forgets that Ravi and Sneha can swap ends of the block."),
               (r"$240$", r"Counts Ravi and Sneha next to each other: $2 \times 5!$."),
               (r"$48$", r"Forgets to choose who stands between them: $2 \times 4!$.")],
  check=_c36, values=[192, 96, 240, 48], cognitive="Application")

# 37
def _c37():
    drivers = {"Ravi", "Kabir", "Joseph"}
    names = ["Ravi", "Kabir", "Joseph", "Meera", "Ananya", "Fatima"]
    # seat 0 driver, seat 1 front passenger, seats 2 to 5 back row
    return sum(1 for p in _perms(names) if p[0] in drivers and "Meera" not in (p[0], p[1]))
q("C25-A-037", T, "Seating in a vehicle with driver and front-seat restrictions", "Medium",
  "Multi-step word problem",
  r"A van has two front seats (the driver's seat and one passenger seat) and four seats in the back row; all six seats are different. Six friends, Ravi, Kabir, Joseph, Meera, Ananya and Fatima, travel in it. Only Ravi, Kabir and Joseph can drive, and Meera refuses to sit in either front seat. In how many ways can the six friends be seated?",
  "MCQ",
  r"Choose the driver in $3$ ways. The front passenger seat can go to anyone except the driver and Meera: $4$ ways. The remaining $4$ friends fill the $4$ back seats in $4! = 24$ ways. Total $3 \times 4 \times 24 = 288$.",
  "Ignoring Meera's restriction, assuming the front passenger must be a non-driver, or dropping the driver choice.",
  "C25A-seats-with-roles", "Two restricted seats filled in the right order, then the rest.",
  correct=r"$288$",
  distractors=[(r"$360$", r"Ignores Meera's restriction: $3 \times 5!$."),
               (r"$144$", r"Lets only Ananya or Fatima take the front passenger seat: $3 \times 2 \times 24$."),
               (r"$96$", r"Leaves out the $3$ choices of driver: $4 \times 24$.")],
  check=_c37, values=[288, 360, 144, 96], cognitive="Application")

# 38
def _c38():
    names = ["Ravi", "Kabir", "Fatima"] + ["x%d" % i for i in range(5)]
    c = 0
    for p in _perms(names):
        row = lambda n: p.index(n) // 4
        if row("Ravi") == row("Kabir") and row("Fatima") != row("Ravi"):
            c += 1
    return c
q("C25-A-038", T, "Two rows of seats with same-row and different-row conditions", "Medium",
  "Multi-step word problem",
  r"A small studio has two rows of $4$ chairs each, and every chair is distinct. Eight participants, including Ravi, Kabir and Fatima, are to be seated, one per chair. Ravi and Kabir must sit in the same row, and Fatima must sit in the other row. In how many ways can the participants be seated?",
  "MCQ",
  r"Ravi can take any of the $8$ chairs. Kabir then takes one of the other $3$ chairs in Ravi's row, and Fatima one of the $4$ chairs in the other row. The remaining $5$ people fill the $5$ chairs in $5! = 120$ ways. Total $8 \times 3 \times 4 \times 120 = 11520$.",
  "Fixing which row Ravi sits in, ignoring Fatima's condition, or not ordering Ravi and Kabir.",
  "C25A-seats-with-roles", "Sequential placement under linked row conditions.",
  correct=r"$11520$",
  distractors=[(r"$5760$", r"Assumes Ravi's row is fixed: $4 \times 3 \times 4 \times 120$."),
               (r"$17280$", r"Ignores Fatima's condition: $8 \times 3 \times 6!$."),
               (r"$2880$", r"Fixes the row and picks an unordered pair of chairs for Ravi and Kabir: $\binom{4}{2} \times 4 \times 120$.")],
  check=_c38, values=[11520, 5760, 17280, 2880], cognitive="Application")

# 39
def _c39():
    for n in range(3, 9):
        cnt = sum(1 for p in _perms(range(n)) if abs(p.index(0) - p.index(1)) != 1)
        if cnt == 3600:
            return n
    return None
q("C25-A-039", T, "Find the group size from the count of arrangements with a pair apart", "Medium",
  "Inverse/parameter",
  r"A group of friends stands in a single row. The number of arrangements in which two particular friends, Joseph and Ananya, are not next to each other is $3600$. How many friends are in the group?",
  "TITA",
  r"For $n$ friends, the count is $n! - 2(n-1)! = (n-1)!\,(n - 2)$. Trying values, $n = 7$ gives $720 \times 5 = 3600$. So there are $7$ friends.",
  "Reporting $n - 1$ after spotting $(n-1)! = 720$.",
  "C25A-row-inverse-group-size", "Set up the count as a function of $n$ and invert it.",
  tita_answer=7, check=_c39, values=[7],
  tita_traps=[(6, r"Spots $720 = 6!$ inside $3600 = 720 \times 5$ and reports $6$, which is $n - 1$."),
              (5, r"Reports the factor $5$, which is $n - 2$.")],
  cognitive="Analysis")

# 40
def _c40():
    return sum(1 for w in _arr("COMMITTEE") if "MM" not in w and "TT" not in w and "EE" not in w)
q("C25-A-040", T, "Three pairs of identical letters, no pair adjacent, three-set inclusion and exclusion", "Difficult",
  "Casework/optimisation",
  r"In how many distinct arrangements of all the letters of the word COMMITTEE are the two M's not next to each other, the two T's not next to each other and the two E's not next to each other?",
  "MCQ",
  r"COMMITTEE has $9$ letters with M, T and E each appearing twice. Total $\frac{9!}{2!\,2!\,2!} = 45360$. One given pair glued: $\frac{8!}{2!\,2!} = 10080$, for each of $3$ pairs, $30240$. Two given pairs glued: $\frac{7!}{2!} = 2520$, for each of $3$ choices, $7560$. All three glued: $6! = 720$. By inclusion and exclusion the answer is $45360 - 30240 + 7560 - 720 = 21960$.",
  "Stopping inclusion and exclusion early, or getting the sign of the triple term wrong.",
  "C25A-word-identical-letters-apart", "Three overlapping conditions with repeated letters need all four terms of inclusion and exclusion.",
  correct=r"$21960$",
  distractors=[(r"$15120$", r"Subtracts the three single-pair counts but adds nothing back: $45360 - 30240$."),
               (r"$22680$", r"Adds back the two-pair overlaps but omits the triple term: $45360 - 30240 + 7560$."),
               (r"$23400$", r"Adds the triple term instead of subtracting it: $45360 - 30240 + 7560 + 720$.")],
  check=_c40, values=[21960, 15120, 22680, 23400], cognitive="Analysis", exams=CX)
