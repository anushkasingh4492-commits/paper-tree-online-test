import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

CE = ("CAT", "XAT")


def rt(*xs):
    """Ratio as a normalised tuple of Fractions (first term scaled to 1)."""
    xs = [Fraction(x) for x in xs]
    return tuple(x / xs[0] for x in xs)


def vessel(**kw):
    return {k: Fraction(v) for k, v in kw.items()}


def vol(v):
    return sum(v.values())


def take(v, amount):
    """Remove `amount` litres of well-mixed liquid from vessel v; return the portion."""
    amount = Fraction(amount)
    tot = vol(v)
    part = {k: x * amount / tot for k, x in v.items()}
    for k in v:
        v[k] -= part[k]
    return part


def pour(src, dst, amount):
    part = take(src, amount)
    for k, x in part.items():
        dst[k] = dst.get(k, Fraction(0)) + x


def ratio_parts(total, *parts):
    s = sum(parts)
    return [Fraction(total) * p / s for p in parts]


# ---------------------------------------------------------------- EASY

def _c1():
    m = w = Fraction(0)
    for v, a, b in [(12, 3, 1), (16, 5, 3), (24, 7, 5)]:
        x, y = ratio_parts(v, a, b)
        m += x; w += y
    return rt(m, w)
q("C06-C-001", "Multi-vessel mixtures", "Entire contents of three milk-water vessels of different sizes combined; final ratio", "Easy",
  "Multi-step word problem",
  r"Three cans hold milk and water. Can P has $12$ litres in the ratio $3 : 1$, can Q has $16$ litres in the ratio $5 : 3$ and can R has $24$ litres in the ratio $7 : 5$ (milk : water in each case). The entire contents of all three cans are emptied into a large drum. The ratio of milk to water in the drum is",
  "MCQ",
  r"Find the actual litres in each can. P: $9$ milk, $3$ water. Q: $10$ milk, $6$ water. R: $14$ milk, $10$ water. Total milk $= 33$ and total water $= 19$, so the ratio is $33 : 19$.",
  "Combining ratios directly (adding the terms or averaging the fractions) without converting each can to litres.",
  "C06C-combine-whole-vessels", "One idea: convert each ratio to litres and add; the trap is to add the ratio terms.",
  correct=r"$33 : 19$",
  distractors=[(r"$47 : 25$", "Averages the milk fractions $\\frac{3}{4}, \\frac{5}{8}, \\frac{7}{12}$ without weighting by volume: mean $= \\frac{47}{72}$, giving $47 : 25$."),
               (r"$5 : 3$", "Adds the ratio terms: $(3+5+7) : (1+3+5) = 15 : 9 = 5 : 3$."),
               (r"$19 : 33$", "Computes the litres correctly but writes water : milk.")],
  check=_c1, values=[rt(33, 19), rt(47, 25), rt(5, 3), rt(19, 33)], cognitive="Application")


def _c2():
    juice = Fraction(20) * Fraction(25, 100) + 30 * Fraction(40, 100) + 50 * Fraction(22, 100)
    return juice / 100 * 100
q("C06-C-002", "Multi-vessel mixtures", "Weighted concentration when three cans of juice drink are combined", "Easy",
  "Single-step computation",
  r"A canteen has three cans of a fruit drink: $20$ litres containing $25\%$ juice, $30$ litres containing $40\%$ juice and $50$ litres containing $22\%$ juice (by volume). All three cans are poured into one tank and stirred. What percentage of the liquid in the tank is juice? Type the number of percent.",
  "TITA",
  r"Juice $= 0.25 \times 20 + 0.40 \times 30 + 0.22 \times 50 = 5 + 12 + 11 = 28$ litres in $100$ litres, so the tank is $28\%$ juice.",
  "Taking the simple average of the three percentages, ignoring the different volumes.",
  "C06C-combine-whole-vessels", "Single weighted average; the trap is the unweighted mean.",
  tita_answer=28, check=_c2, cognitive="Application",
  tita_traps=[(29, "Simple average $\\frac{25+40+22}{3} = 29$, ignoring volumes.")])


def _c3():
    P = dict(zip("mws", ratio_parts(20, 5, 3, 2)))
    Q = dict(zip("mws", ratio_parts(30, 2, 5, 3)))
    return (P["s"] + Q["s"]) / 50 * 100
q("C06-C-003", "Multi-vessel mixtures", "Two three-component vessels combined; percentage of one component", "Easy",
  "Multi-step word problem",
  r"Jug P holds $20$ litres of a drink made of milk, water and rose syrup in the ratio $5 : 3 : 2$. Jug Q holds $30$ litres of milk, water and rose syrup in the ratio $2 : 5 : 3$. Both jugs are emptied into a bowl. What percentage of the liquid in the bowl is rose syrup?",
  "MCQ",
  r"Syrup in P $= \frac{2}{10} \times 20 = 4$ litres; syrup in Q $= \frac{3}{10} \times 30 = 9$ litres. Total syrup $= 13$ litres in $50$ litres, which is $26\%$.",
  "Averaging the two syrup shares as if the jugs held equal volumes.",
  "C06C-three-component-blend", "Direct component tracking across two jugs; the trap is equal weighting.",
  correct=r"$26\%$",
  distractors=[(r"$25\%$", "Averages the syrup shares $20\\%$ and $30\\%$ as though the jugs were of equal size."),
               (r"$24\%$", "Attaches the volumes to the wrong jugs: $\\frac{2}{10} \\times 30 + \\frac{3}{10} \\times 20 = 12$ litres out of $50$."),
               (r"$30\%$", "Takes the syrup share of the larger jug Q as the share of the whole bowl.")],
  check=_c3, values=[26, 25, 24, 30], cognitive="Application")


def _c4():
    P = vessel(m=20); Q = vessel(w=20); R = vessel(w=20)
    pour(P, Q, 5); pour(Q, R, 5)
    return R["m"] / vol(R) * 100
q("C06-C-004", "Multi-vessel mixtures", "Chain transfer P to Q to R; concentration in the last vessel", "Easy",
  "Multi-step word problem",
  r"Vessel P contains $20$ litres of pure milk, and vessels Q and R contain $20$ litres of water each. Sneha pours $5$ litres from P into Q and stirs well. She then pours $5$ litres from Q into R and stirs well. What percentage of the liquid in R is now milk?",
  "MCQ",
  r"After the first pour Q has $5$ litres of milk in $25$ litres, a milk share of $\frac{1}{5}$. The $5$ litres poured into R therefore carry $1$ litre of milk. R now holds $25$ litres with $1$ litre of milk, which is $4\%$.",
  "Dividing by the original $20$ litres of R instead of its new volume of $25$ litres.",
  "C06C-chain-transfer", "Two transfers with a single dilution step each; the trap is the stale volume.",
  correct=r"$4\%$",
  distractors=[(r"$5\%$", "Divides the $1$ litre of milk by $20$ litres, ignoring that R now holds $25$ litres."),
               (r"$20\%$", "Reports the milk share of Q after the first pour."),
               (r"$25\%$", "Treats the $5$ litres reaching R as pure milk and divides by $20$ litres.")],
  check=_c4, values=[4, 5, 20, 25], cognitive="Application")


def _c5():
    x = symbols('x')
    return solve(Eq(10 * Rational(30, 100) + 20 * Rational(45, 100) + 30 * x / 100, Rational(42, 100) * 60), x)[0]
q("C06-C-005", "Multi-vessel mixtures", "Unknown concentration of the third vessel from the concentration of the combined mixture", "Easy",
  "Inverse/parameter",
  r"Three containers hold sugar solution: $10$ litres at $30\%$ sugar, $20$ litres at $45\%$ sugar and $30$ litres of unknown strength. When all three are mixed, the solution is $42\%$ sugar. What is the sugar percentage of the third container?",
  "MCQ",
  r"The mixture of $60$ litres holds $0.42 \times 60 = 25.2$ litres of sugar. The first two containers supply $3 + 9 = 12$ litres, so the third supplies $13.2$ litres out of $30$, which is $44\%$.",
  "Treating the overall percentage as the simple average of the three percentages.",
  "C06C-unknown-vessel-from-result", "One balance equation in one unknown; the trap is the unweighted average.",
  correct=r"$44\%$",
  distractors=[(r"$51\%$", "Sets $\\frac{30 + 45 + x}{3} = 42$, an unweighted average, giving $x = 51$."),
               (r"$54\%$", "Leaves out the $3$ litres of sugar from the first container: $9 + 0.3x = 25.2$ gives $x = 54$."),
               (r"$74\%$", "Leaves out the $9$ litres of sugar from the second container: $3 + 0.3x = 25.2$ gives $x = 74$.")],
  check=_c5, values=[44, 51, 54, 74], cognitive="Application")


def _c6():
    r = symbols('r', nonnegative=True)
    return solve(Eq(10 * Rational(20, 100) + 20 * Rational(35, 100) + r * Rational(70, 100), Rational(40, 100) * (30 + r)), r)[0]
q("C06-C-006", "Multi-vessel mixtures", "Volume needed from a third vessel to reach a target strength", "Easy",
  "Inverse/parameter",
  r"Ravi mixes $10$ litres of a $20\%$ acid solution with $20$ litres of a $35\%$ acid solution. How many litres of a $70\%$ acid solution must he add to this so that the final mixture is $40\%$ acid?",
  "MCQ",
  r"The first two solutions give $30$ litres with $2 + 7 = 9$ litres of acid, that is $30\%$. Alligating $30\%$ and $70\%$ about $40\%$: (volume at $30\%$) : (volume at $70\%$) $= (70 - 40) : (40 - 30) = 3 : 1$. So the $70\%$ solution needed is $\frac{30}{3} = 10$ litres.",
  "Reversing the alligation ratio, or reporting the final volume.",
  "C06C-three-source-target-inverse", "Combine two vessels, then one alligation step.",
  correct=r"$10$ litres",
  distractors=[(r"$90$ litres", "Reverses the alligation ratio, taking strong : weak $= 3 : 1$, so $3 \\times 30 = 90$."),
               (r"$40$ litres", "Reports the volume of the final mixture, $30 + 10$."),
               (r"$20$ litres", "Uses $20\\%$ as the strength of the whole $30$ litres: $(40-20) : (70-40) = 2 : 3$ gives $20$ litres.")],
  check=_c6, values=[10, 90, 40, 20], cognitive="Application")


def _c7():
    m = symbols('m', nonnegative=True)
    milk, water, syrup = ratio_parts(60, 5, 4, 3)
    return solve(Eq(milk + m, 2 * water), m)[0]
q("C06-C-007", "Multi-vessel mixtures", "Three-component mixture; milk to add to reach a target ratio of two components", "Easy",
  "Inverse/parameter",
  r"A drum holds $60$ litres of a beverage containing milk, water and syrup in the ratio $5 : 4 : 3$. How many litres of pure milk must be added so that the ratio of milk to water becomes $2 : 1$?",
  "MCQ",
  r"The drum has $25$ litres of milk, $20$ litres of water and $15$ litres of syrup. Water is unchanged, so milk must become $2 \times 20 = 40$ litres. Milk to add $= 40 - 25 = 15$ litres.",
  "Comparing milk with the wrong component or with everything else.",
  "C06C-three-component-blend", "One component fixed, one equation; the trap is the third component.",
  correct=r"$15$ litres",
  distractors=[(r"$45$ litres", "Makes milk twice water and syrup together: $25 + m = 2 \\times 35$."),
               (r"$25$ litres", "Reads $2 : 1$ as doubling the milk already present."),
               (r"$5$ litres", "Uses the syrup ($15$ litres) in place of the water: $25 + m = 30$.")],
  check=_c7, values=[15, 45, 25, 5], cognitive="Application")


def _c8():
    out = set()
    for qv in [Fraction(1), Fraction(5), Fraction(17, 3), Fraction(40)]:
        acid = 12 * Fraction(10, 100) + qv * Fraction(30, 100) + 12 * Fraction(50, 100)
        out.add(acid / (24 + qv) * 100)
    assert len(out) == 1
    return out.pop()
q("C06-C-008", "Multi-vessel mixtures", "Equal volumes from vessels symmetric about the middle strength; amount of the middle vessel irrelevant", "Easy",
  "Conceptual/application",
  r"Bottles P, Q and R contain alcohol solutions of strength $10\%$, $30\%$ and $50\%$ respectively. Meera pours $12$ litres from P, $12$ litres from R, and some quantity (she does not measure it) from Q into an empty can and stirs. What is the alcohol percentage in the can? Type the number of percent.",
  "TITA",
  r"$12$ litres at $10\%$ and $12$ litres at $50\%$ together form $24$ litres at $\frac{10 + 50}{2} = 30\%$. Adding any amount of the $30\%$ solution from Q leaves the strength at $30\%$. So the can is $30\%$ alcohol whatever the amount from Q.",
  "Believing the answer needs the unknown amount from Q.",
  "C06C-symmetric-mix-insight", "One insight: the P and R portions already average to Q's strength.",
  tita_answer=30, check=_c8, cognitive="Understanding",
  tita_traps=[(20, "Averages only P and Q, $\\frac{10 + 30}{2}$.")])


def _c9():
    P = vessel(m=20); Q = vessel(w=20)
    pour(P, Q, 5); pour(Q, P, 5)
    return P["w"]
q("C06-C-009", "Multi-vessel mixtures", "Two-way transfer of equal volumes; water ending up in the milk vessel", "Easy",
  "Conceptual/application",
  r"Jar P contains $20$ litres of pure milk and jar Q contains $20$ litres of pure water. Arjun pours $5$ litres from P into Q and stirs well, and then pours $5$ litres from Q back into P. How many litres of water are now in jar P?",
  "TITA",
  r"After the first pour Q has $5$ litres of milk and $20$ litres of water, so water is $\frac{4}{5}$ of Q. The $5$ litres returned to P carry $4$ litres of water and $1$ litre of milk. So P contains $4$ litres of water. (Both jars end at $20$ litres, so this also equals the milk now in Q.)",
  "Assuming the returned liquid is pure water.",
  "C06C-two-way-transfer", "One dilution step; the trap is to treat the returned liquid as pure water.",
  tita_answer=4, check=_c9, cognitive="Understanding",
  tita_traps=[(5, "Treats all $5$ litres poured back as water."), (1, "Reports the milk in the returned $5$ litres.")])


# ---------------------------------------------------------------- MEDIUM

def _c10():
    P = vessel(m=36); Q = vessel(w=24)
    pour(P, Q, 12); pour(Q, P, 18)
    return rt(P["m"], P["w"])
q("C06-C-010", "Multi-vessel mixtures", "Unequal two-way transfer between a milk vessel and a water vessel; final ratio in the first", "Medium",
  "Multi-step word problem",
  r"Vessel P holds $36$ litres of pure milk and vessel Q holds $24$ litres of pure water. Kabir pours $12$ litres from P into Q and stirs well. He then pours $18$ litres from Q into P. What is the ratio of milk to water in P now?",
  "MCQ",
  r"After the first pour Q has $12$ litres of milk and $24$ litres of water, $36$ litres in the ratio $1 : 2$. The $18$ litres poured back carry $6$ litres of milk and $12$ litres of water. P now has $24 + 6 = 30$ litres of milk and $12$ litres of water, a ratio of $30 : 12 = 5 : 2$.",
  "Treating the liquid returned to P as pure water, or forgetting the milk it carries.",
  "C06C-two-way-transfer", "Two transfers of different sizes; the composition of the return must be tracked.",
  correct=r"$5 : 2$",
  distractors=[(r"$4 : 3$", "Treats all $18$ litres poured back as water: $24 : 18$."),
               (r"$2 : 1$", "Counts the $12$ litres of water returned but not the $6$ litres of milk: $24 : 12$."),
               (r"$1 : 2$", "Reports the ratio in Q, $6 : 12$.")],
  check=_c10, values=[rt(5, 2), rt(4, 3), rt(2, 1), rt(1, 2)], cognitive="Application")


def _c11():
    x = symbols('x', positive=True)
    sol = solve(Eq(30 * x / (30 + x), 10), x)
    v = sol[0]
    P = vessel(wine=50); Q = vessel(w=30)
    pour(P, Q, v); pour(Q, P, v)
    assert P["w"] == 10
    return v
q("C06-C-011", "Multi-vessel mixtures", "Volume transferred each way, found from the water that ends up in the wine vessel", "Medium",
  "Inverse/parameter",
  r"Cask P contains $50$ litres of wine and cask Q contains $30$ litres of water. A certain volume is poured from P into Q and stirred well, and then the same volume is poured from Q back into P. Cask P now contains $10$ litres of water. How many litres were poured each time?",
  "TITA",
  r"Let $x$ litres be poured each way. Q then has $x$ litres of wine and $30$ litres of water, so the $x$ litres returned contain $\frac{30x}{30 + x}$ litres of water. Setting $\frac{30x}{30+x} = 10$ gives $30x = 300 + 10x$, so $x = 15$. Check: Q has $15$ wine and $30$ water; one third of it, $5$ wine and $10$ water, goes back.",
  "Assuming the returned liquid is pure water, so that the water in P equals the volume poured.",
  "C06C-two-way-transfer", "Requires modelling the composition of the returned portion and solving for the transfer size.",
  tita_answer=15, check=_c11, cognitive="Analysis",
  tita_traps=[(10, "Assumes the liquid poured back is all water.")])


def _c12():
    P = vessel(a=30); Q = vessel(w=10); R = vessel(w=10)
    pour(P, Q, 10); pour(Q, R, 10); pour(R, P, 10)
    return P["a"] / vol(P)
q("C06-C-012", "Multi-vessel mixtures", "Cyclic transfer P to Q to R to P with a single solute; final strength of P", "Medium",
  "Multi-step word problem",
  r"Flask P holds $30$ litres of pure acid, and flasks Q and R hold $10$ litres of water each. Ananya pours $10$ litres from P into Q, then $10$ litres from Q into R, then $10$ litres from R into P, stirring well after every pour. What fraction of the liquid in P is now acid?",
  "MCQ",
  r"Q gets $10$ litres of acid, becoming $20$ litres that are half acid; its $10$ litres to R carry $5$ litres of acid. R becomes $20$ litres with $5$ litres of acid, a quarter; its $10$ litres to P carry $2.5$ litres of acid. P has $20 + 2.5 = 22.5$ litres of acid in $30$ litres, which is $\frac{3}{4}$.",
  "Taking the liquid returned to P at Q's strength or as pure water, skipping the dilution in R.",
  "C06C-cyclic-transfer", "Three successive transfers, each with its own dilution, around a cycle.",
  correct=r"$\frac{3}{4}$",
  distractors=[(r"$\frac{5}{6}$", "Takes the liquid returned to P at Q's strength $\\frac{1}{2}$: $\\frac{20 + 5}{30}$."),
               (r"$\frac{2}{3}$", "Treats the liquid returned to P as pure water: $\\frac{20}{30}$."),
               (r"$\frac{1}{4}$", "Reports the acid fraction left in R.")],
  check=_c12, values=[Fraction(3, 4), Fraction(5, 6), Fraction(2, 3), Fraction(1, 4)], cognitive="Application")


def _c13():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(2 * x + y, 90), Eq(x * Rational(10, 100) + x * Rational(40, 100) + y * Rational(70, 100), 45)], [x, y], dict=True)[0]
    return s[y]
q("C06-C-013", "Multi-vessel mixtures", "Equal amounts from two vessels plus a third to make a fixed volume at a target strength", "Medium",
  "Inverse/parameter",
  r"Tanks P, Q and R contain alcohol solutions of strength $10\%$, $40\%$ and $70\%$ respectively. Joseph wants $90$ litres of a $50\%$ solution, and he must draw equal volumes from P and Q, with the rest from R. How many litres must he draw from R?",
  "MCQ",
  r"Equal volumes $x$ from P and Q act like $2x$ litres at $\frac{10 + 40}{2} = 25\%$. Alligating $25\%$ and $70\%$ about $50\%$: $2x : y = 20 : 25 = 4 : 5$. With $2x + y = 90$, $y = 50$ litres (and $x = 20$).",
  "Reporting the draw from P or Q, or splitting the volume equally.",
  "C06C-three-source-target-inverse", "Reduce the equal-volume pair to one solution, then alligate; two equations.",
  correct=r"$50$ litres",
  distractors=[(r"$20$ litres", "Solves correctly but reports the draw from P (or from Q)."),
               (r"$40$ litres", "Reports the combined draw from P and Q."),
               (r"$30$ litres", "Splits $90$ litres equally among the three tanks.")],
  check=_c13, values=[50, 20, 40, 30], cognitive="Application")


def _c14():
    lo = hi = None
    # enumerate litres in steps of 1 (linear objective, extremes at integer vertices)
    for a in range(10, 41):
        for b in range(10, 41):
            c = 60 - a - b
            if c < 10:
                continue
            conc = Fraction(20 * a + 50 * b + 80 * c, 60)
            lo = conc if lo is None else min(lo, conc)
            hi = conc if hi is None else max(hi, conc)
    return hi - lo
q("C06-C-014", "Multi-vessel mixtures", "Range of possible strengths when each of three vessels must contribute a minimum volume", "Medium",
  "Casework/optimisation",
  r"Three drums contain milk solutions with $20\%$, $50\%$ and $80\%$ milk. A $60$-litre batch is to be made from them, using at least $10$ litres from each drum (any amounts otherwise). By how many percentage points does the highest possible milk percentage of the batch exceed the lowest possible? Type the number of percentage points.",
  "TITA",
  r"Lowest: use the minimum $10$ litres of the $50\%$ and $80\%$ solutions and $40$ litres of the $20\%$ one: milk $= 8 + 5 + 8 = 21$ litres, which is $35\%$. Highest: $10$ litres each of the $20\%$ and $50\%$ solutions and $40$ litres of the $80\%$: milk $= 2 + 5 + 32 = 39$ litres, which is $65\%$. Difference $= 65 - 35 = 30$ percentage points.",
  "Ignoring the minimum draw from one or more drums.",
  "C06C-concentration-range", "Two extreme cases under constraints; the middle drum's minimum is easily forgotten.",
  tita_answer=30, check=_c14, cognitive="Analysis",
  tita_traps=[(60, "Ignores the minimum draws: $80 - 20$."), (40, "Applies the minimum to the extreme drums but forgets the $10$ litres from the $50\\%$ drum: $70 - 30$.")])


def _c15():
    p, qq, r = symbols('p q r')
    s = solve([Eq((p + qq) / 2, 30), Eq((qq + r) / 2, 44), Eq((p + r) / 2, 40)], [p, qq, r])
    return (s[p] + s[qq] + s[r]) / 3
q("C06-C-015", "Multi-vessel mixtures", "Three equal-volume vessels; pairwise mixture strengths given, strength of all three combined", "Medium",
  "Conceptual/application",
  r"Three jars P, Q and R contain equal volumes of salt solution, each of a different strength. If the whole of P were mixed with the whole of Q, the result would be $30\%$ salt; Q with R would give $44\%$; P with R would give $40\%$. What is the salt percentage if the whole of all three jars is mixed together? Type the number of percent.",
  "TITA",
  r"Let the strengths be $p, q, r$. Equal volumes give $p + q = 60$, $q + r = 88$, $p + r = 80$. Adding, $2(p + q + r) = 228$, so $p + q + r = 114$, and the three-jar mixture is $\frac{114}{3} = 38\%$. In short, it is the mean of the three pairwise strengths.",
  "Halving the sum of the pairwise strengths, which gives $p + q + r$ rather than its average.",
  "C06C-pairwise-mix-strengths", "Recognise that adding the pair equations gives the total directly.",
  tita_answer=38, check=_c15, cognitive="Analysis",
  tita_traps=[(57, "Computes $\\frac{30 + 44 + 40}{2}$, which is $p + q + r$, not the average."), (54, "Solves the system and reports $r$, the strongest jar.")])


def _c16():
    P = {"Cu": Fraction(10) * Fraction(3, 5), "Zn": Fraction(10) * Fraction(2, 5)}
    Q = {"Zn": Fraction(8) * Fraction(1, 4), "Sn": Fraction(8) * Fraction(3, 4)}
    R = {"Cu": Fraction(6) * Fraction(1, 2), "Sn": Fraction(6) * Fraction(1, 2)}
    tot = {k: P.get(k, 0) + Q.get(k, 0) + R.get(k, 0) for k in ("Cu", "Zn", "Sn")}
    return rt(tot["Cu"], tot["Zn"], tot["Sn"])
q("C06-C-016", "Multi-vessel mixtures", "Three alloys, each with two of three metals, melted together; final three-metal ratio", "Medium",
  "Multi-step word problem",
  r"Alloy P contains copper and zinc in the ratio $3 : 2$; alloy Q contains zinc and tin in the ratio $1 : 3$; alloy R contains copper and tin in the ratio $1 : 1$. A craftsman melts together $10$ kg of P, $8$ kg of Q and $6$ kg of R. What is the ratio of copper : zinc : tin in the new alloy?",
  "MCQ",
  r"P gives $6$ kg copper and $4$ kg zinc. Q gives $2$ kg zinc and $6$ kg tin. R gives $3$ kg copper and $3$ kg tin. Totals: copper $9$, zinc $6$, tin $9$, so the ratio is $9 : 6 : 9 = 3 : 2 : 3$.",
  "Adding ratio terms of different alloys directly, or reading a two-metal ratio the wrong way round.",
  "C06C-three-component-blend", "Three sources each missing one metal; each must be split before adding.",
  correct=r"$3 : 2 : 3$",
  distractors=[(r"$4 : 3 : 4$", "Adds the ratio terms without using the weights: copper $3 + 1$, zinc $2 + 1$, tin $3 + 1$."),
               (r"$22 : 13 : 25$", "Uses $1$ kg of each alloy: copper $0.6 + 0.5$, zinc $0.4 + 0.25$, tin $0.75 + 0.5$."),
               (r"$9 : 10 : 5$", "Reads Q's ratio as zinc : tin $= 3 : 1$, giving $6$ kg zinc and $2$ kg tin from Q.")],
  check=_c16, values=[rt(3, 2, 3), rt(4, 3, 4), rt(22, 13, 25), rt(9, 10, 5)], cognitive="Application")


def _c17():
    x = symbols('x', positive=True)
    s = solve(Eq((6 - x * Rational(20, 100) + x * Rational(50, 100)) / 30, (30 - x * Rational(50, 100) + x * Rational(20, 100)) / 60), x)
    v = s[0]
    P = vessel(a=6, w=24); Q = vessel(a=30, w=30)
    pp = take(P, v); qp = take(Q, v)
    for k in qp: P[k] += qp[k]
    for k in pp: Q[k] += pp[k]
    assert P["a"] / vol(P) == Q["a"] / vol(Q)
    return v
q("C06-C-017", "Multi-vessel mixtures", "Equal volumes swapped between two vessels so that both end at the same strength", "Medium",
  "Inverse/parameter",
  r"Vessel P contains $30$ litres of a $20\%$ acid solution and vessel Q contains $60$ litres of a $50\%$ acid solution. The same volume is drawn from each vessel at the same time, and the portion drawn from P is poured into Q while the portion drawn from Q is poured into P. After stirring, both vessels have the same acid concentration. How many litres were drawn from each vessel?",
  "MCQ",
  r"Total acid $= 6 + 30 = 36$ litres in $90$ litres, so the common final strength must be $40\%$. Track P (volume stays $30$ litres): $6 - 0.2x + 0.5x = 0.4 \times 30 = 12$, so $0.3x = 6$ and $x = 20$ litres. (In general the swap volume is $\frac{30 \times 60}{30 + 60} = 20$.)",
  "Aiming for the simple average of the two strengths rather than the volume-weighted one.",
  "C06C-swap-to-equal-strength", "Needs the overall strength first, then one balance equation.",
  correct=r"$20$ litres",
  distractors=[(r"$15$ litres", "Aims for the simple average $35\\%$: $6 + 0.3x = 10.5$ gives $x = 15$."),
               (r"$12$ litres", "Aims at the correct $40\\%$ but forgets the acid removed from P: $6 + 0.5x = 12$ gives $x = 12$."),
               (r"$30$ litres", "Swaps the whole of P with $30$ litres of Q.")],
  check=_c17, values=[20, 15, 12, 30], cognitive="Analysis", exams=CE)


def _c18():
    found = []
    for x2 in range(1, 201):          # candidate pours in half litres, up to all of P
        x = Fraction(x2, 2)
        P = vessel(s=100); Q = vessel(w=60); R = vessel(w=20)
        pour(P, Q, x); pour(Q, R, 10)
        if R.get("s", 0) / vol(R) == Fraction(20, 100):
            found.append(x)
    assert len(found) == 1
    return found[0]
q("C06-C-018", "Multi-vessel mixtures", "Chain transfer P to Q to R worked backwards; volume of the first pour from the strength in the last vessel", "Medium",
  "Inverse/parameter",
  r"Tank P holds $100$ litres of pure syrup, tank Q holds $60$ litres of water and tank R holds $20$ litres of water. Some syrup is poured from P into Q and stirred well. Then $10$ litres are poured from Q into R and stirred well. The liquid in R is now $20\%$ syrup. How many litres of syrup were poured from P into Q?",
  "MCQ",
  r"Work backwards. R now holds $30$ litres at $20\%$, so it has $6$ litres of syrup, all carried by the $10$ litres from Q. Hence Q was $60\%$ syrup. If $x$ litres were poured into Q, then $\frac{x}{60 + x} = \frac{3}{5}$, so $5x = 180 + 3x$ and $x = 90$ litres.",
  "Using a vessel's volume before the pour into it (stale volume) when finding its strength.",
  "C06C-chain-transfer", "Two-stage chain worked backwards, with both vessels' volumes changing along the way.",
  correct=r"$90$ litres",
  distractors=[(r"$36$ litres", "Takes Q's strength as $\\frac{x}{60}$, forgetting Q grew to $60 + x$ litres: $10 \\times \\frac{x}{60} = 0.2 \\times 30$ gives $x = 36$."),
               (r"$15$ litres", "Skips the dilution in R and sets Q's strength to $20\\%$: $\\frac{x}{60 + x} = \\frac{1}{5}$ gives $x = 15$."),
               (r"$40$ litres", "Divides the syrup reaching R by R's original $20$ litres: $\\frac{10x}{60 + x} = 0.2 \\times 20$ gives $x = 40$.")],
  check=_c18, values=[90, 36, 15, 40], cognitive="Analysis")


def _c19():
    P = vessel(j=400); Q = vessel(w=100); R = vessel(w=100); S = vessel(w=100)
    pour(P, Q, 100); pour(Q, R, 100); pour(R, S, 100)
    return S["j"]
q("C06-C-019", "Multi-vessel mixtures", "Chain transfer through four vessels; quantity of solute reaching the last", "Medium",
  "Multi-step word problem",
  r"Glass P holds $400$ mL of pure orange juice, and glasses Q, R and S hold $100$ mL of water each. Fatima pours $100$ mL from P into Q, then $100$ mL from Q into R, then $100$ mL from R into S, stirring well after each pour. How many mL of orange juice are in glass S at the end?",
  "TITA",
  r"Q gets $100$ mL of juice and becomes half juice, so the $100$ mL sent to R carries $50$ mL of juice. R then holds $200$ mL with $50$ mL of juice, a quarter, so the $100$ mL sent to S carries $25$ mL of juice. Glass S has $25$ mL of juice.",
  "Stopping one dilution early, or treating the transferred liquid as pure juice.",
  "C06C-chain-transfer", "Three successive dilutions; the strength halves at each glass.",
  tita_answer=25, check=_c19, cognitive="Application",
  tita_traps=[(50, "Uses the juice carried into R as the juice reaching S, missing the dilution in R."), (100, "Treats every transfer as pure juice.")])


def _c20():
    P = dict(zip("mw", ratio_parts(20, 3, 2)))
    Q = dict(zip("mw", ratio_parts(16, 5, 3)))
    final = dict(zip("mw", ratio_parts(48, 5, 3)))
    return rt(final["m"] - P["m"] - Q["m"], final["w"] - P["w"] - Q["w"])
q("C06-C-020", "Multi-vessel mixtures", "Ratio inside the third vessel deduced from the ratio of the combined mixture", "Medium",
  "Inverse/parameter",
  r"Three containers hold milk and water: P has $20$ litres in the ratio $3 : 2$, Q has $16$ litres in the ratio $5 : 3$, and R has $12$ litres in an unknown ratio (milk : water throughout). When all three are poured together, the ratio of milk to water is $5 : 3$. What is the ratio of milk to water in R?",
  "MCQ",
  r"P has $12$ milk and $8$ water; Q has $10$ milk and $6$ water. The $48$-litre mixture has $30$ litres of milk and $18$ of water. So R has $30 - 22 = 8$ litres of milk and $18 - 14 = 4$ litres of water, a ratio of $2 : 1$.",
  "Assuming R must have the same ratio as the final mixture, or reporting milk against the whole of R.",
  "C06C-unknown-vessel-from-result", "Component balance over three containers with one unknown container.",
  correct=r"$2 : 1$",
  distractors=[(r"$1 : 2$", "Finds $8$ litres of milk and $4$ of water but writes water : milk."),
               (r"$5 : 3$", "Assumes R must have the same ratio as the final mixture."),
               (r"$2 : 3$", "Reports milk : total volume of R, $8 : 12$.")],
  check=_c20, values=[rt(2, 1), rt(1, 2), rt(5, 3), rt(2, 3)], cognitive="Application")


def _c21():
    P = vessel(m=12, w=8, s=0); Q = vessel(m=0, w=5, s=15)
    pour(P, Q, 10); pour(Q, P, 10)
    return rt(P["m"], P["w"], P["s"])
q("C06-C-021", "Multi-vessel mixtures", "Two-way transfer between a milk-water vessel and a water-syrup vessel; three-component result", "Medium",
  "Multi-step word problem",
  r"Bowl P has $12$ litres of milk and $8$ litres of water. Bowl Q has $5$ litres of water and $15$ litres of syrup. Harpreet pours $10$ litres from P into Q and stirs well, and then pours $10$ litres from Q back into P and stirs. What is the ratio of milk : water : syrup in P now?",
  "MCQ",
  r"The $10$ litres from P carry $6$ milk and $4$ water, leaving P with $6$ milk and $4$ water. Q becomes $6$ milk, $9$ water, $15$ syrup ($30$ litres). The $10$ litres returned are one third of Q: $2$ milk, $3$ water, $5$ syrup. P ends with $8$ milk, $7$ water, $5$ syrup, that is $8 : 7 : 5$.",
  "Tracking only the syrup in the returned liquid, or not removing what left P.",
  "C06C-three-component-transfer", "Two transfers with three components tracked through both vessels.",
  correct=r"$8 : 7 : 5$",
  distractors=[(r"$6 : 4 : 5$", "Counts only the syrup in the $10$ litres returned to P, ignoring its milk and water."),
               (r"$2 : 3 : 5$", "Reports the composition of the returned $10$ litres (also the final ratio in Q)."),
               (r"$12 : 8 : 5$", "Adds the returned syrup to P's original contents without removing the $10$ litres poured out.")],
  check=_c21, values=[rt(8, 7, 5), rt(6, 4, 5), rt(2, 3, 5), rt(12, 8, 5)], cognitive="Application")


def _c22():
    best = Fraction(0)
    # grid search over q and w; p fixed by the strength condition
    for qn in range(0, 41):
        for wn in range(0, 7):
            for qd in (Fraction(0), Fraction(1, 2)):
                qv = qn + qd
                if qv > 40:
                    continue
                pv = (3 * qv + 8 * wn) / Fraction(12)
                if pv <= 20 and pv + qv + wn > 0:
                    tot = pv + qv + wn
                    assert (pv + qv / 4) / tot == Fraction(2, 5)
                    best = max(best, tot)
    return best
q("C06-C-022", "Multi-vessel mixtures", "Largest batch at a target strength from two acid stocks and a limited water supply", "Medium",
  "Casework/optimisation",
  r"A lab has $20$ litres of pure acid, $40$ litres of a $25\%$ acid solution and only $6$ litres of distilled water. Using any amounts from these three (not necessarily all), what is the largest volume, in litres, of $40\%$ acid solution that can be made?",
  "TITA",
  r"Using $p$ litres of pure acid, $q$ of the $25\%$ solution and $w$ of water, the strength condition $p + 0.25q = 0.4(p + q + w)$ gives $12p = 3q + 8w$. The total $p + q + w = \frac{5q}{4} + \frac{5w}{3}$ grows with both $q$ and $w$, so take $q = 40$ and $w = 6$: then $p = \frac{120 + 48}{12} = 14 \le 20$. The largest batch is $14 + 40 + 6 = 60$ litres.",
  "Assuming all the acid can be used, which needs more water than is available.",
  "C06C-max-volume-at-target", "Must notice the binding constraint is the water and the weak solution, not the acid.",
  tita_answer=60, check=_c22, cognitive="Analysis", exams=CE,
  tita_traps=[(75, "Divides all the acid, $20 + 10 = 30$ litres, by $0.4$, ignoring the water limit."), (66, "Uses everything, $20 + 40 + 6$, without checking the strength.")])


# ---------------------------------------------------------------- DIFFICULT

def _c23():
    n = 0
    for a in range(1, 51):
        for b in range(1, 51):
            c = 50 - a - b
            if c >= 1 and 20 * a + 30 * b + 60 * c == 40 * 50:
                n += 1
    return n
q("C06-C-023", "Multi-vessel mixtures", "Number of whole-litre draws from three vessels that give a fixed volume at a target strength", "Difficult",
  "Casework/optimisation",
  r"Three vessels contain acid solutions of strength $20\%$, $30\%$ and $60\%$. Priya needs exactly $50$ litres of a $40\%$ solution, drawing a whole number of litres from each vessel and at least $1$ litre from each. In how many different ways (different triples of volumes) can she do this?",
  "TITA",
  r"With $a, b, c$ litres from the three vessels: $a + b + c = 50$ and $20a + 30b + 60c = 2000$. Subtracting $20$ times the first, $10b + 40c = 1000$, so $b = 100 - 4c$ and $a = 50 - b - c = 3c - 50$. Need $a \ge 1$, so $c \ge 17$; need $b \ge 1$, so $c \le 24$. Hence $c = 17, 18, \ldots, 24$: $8$ ways.",
  "Allowing a vessel to contribute zero, or miscounting the end points.",
  "C06C-integer-draw-count", "Two linear equations in three integer unknowns, then bounding a parameter from both sides.",
  tita_answer=8, check=_c23, cognitive="Analysis", exams=CE,
  tita_traps=[(9, "Allows $b = 0$ (the case $c = 25$), ignoring the at-least-$1$-litre condition."), (7, "Counts $24 - 17$ instead of $24 - 17 + 1$.")])


def _c24():
    best = Fraction(0)
    for p2 in range(0, 61):           # p in half litres
        pv = Fraction(p2, 2)
        for r4 in range(0, 201):      # r in quarter litres
            rv = Fraction(r4, 4)
            qv = 2 * pv - 4 * rv
            if 0 <= qv <= 40 and rv <= 50:
                tot = pv + qv + rv
                if tot and (Fraction(80) * pv + 50 * qv + 20 * rv) / tot == 60:
                    best = max(best, tot)
    return best
q("C06-C-024", "Multi-vessel mixtures", "Largest volume at a target strength from three limited stocks on both sides of the target", "Difficult",
  "Casework/optimisation",
  r"A distillery has $30$ litres of $80\%$ spirit, $40$ litres of $50\%$ spirit and $50$ litres of $20\%$ spirit. Drawing any amounts from these stocks, what is the largest volume of exactly $60\%$ spirit that can be made?",
  "MCQ",
  r"With $p, q, r$ litres of the $80\%$, $50\%$ and $20\%$ stocks, $80p + 50q + 20r = 60(p + q + r)$ gives $2p = q + 4r$. Only the $80\%$ stock is above $60\%$, so use all of it: $q + 4r = 60$. The total $30 + q + r$ is largest when the weak part comes mostly from the $50\%$ stock (it dilutes least per litre), so $q = 40$ and $r = 5$. The largest volume is $30 + 40 + 5 = 75$ litres.",
  "Pairing the strong stock with only one of the weaker stocks, or counting the strong stock twice.",
  "C06C-max-volume-at-target", "Optimisation with two weaker stocks of different efficiency and a capacity limit.",
  correct=r"$75$ litres",
  distractors=[(r"$60$ litres", "Uses only the $80\\%$ and $50\\%$ stocks: $2p = q$ with $q = 40$ gives $p = 20$, total $60$."),
               (r"$45$ litres", "Uses only the $80\\%$ and $20\\%$ stocks: $2p = 4r$ with $p = 30$ gives $r = 15$, total $45$."),
               (r"$105$ litres", "Adds the two single-pair maxima $60 + 45$, using the $80\\%$ stock twice.")],
  check=_c24, values=[75, 60, 45, 105], cognitive="Analysis", exams=CE)


def _c25():
    p, qq, r = symbols('p q r')
    s = solve([Eq(20 * p + 30 * qq, 50 * 22), Eq(30 * qq + 50 * r, 80 * 45), Eq(20 * p + 50 * r, 70 * 50)], [p, qq, r])
    return (20 * s[p] + 30 * s[qq] + 50 * s[r]) / 100
q("C06-C-025", "Multi-vessel mixtures", "Three unequal vessels; pairwise mixture strengths given, strength of all three combined", "Difficult",
  "Conceptual/application",
  r"Vessels P, Q and R contain $20$ litres, $30$ litres and $50$ litres of acid solution of different strengths. Mixing the whole of P with the whole of Q would give a $22\%$ solution; the whole of Q with the whole of R would give $45\%$; the whole of P with the whole of R would give $50\%$. What is the acid percentage if the whole contents of all three vessels are mixed together?",
  "MCQ",
  r"Acid in P and Q together $= 0.22 \times 50 = 11$ litres; in Q and R $= 0.45 \times 80 = 36$ litres; in P and R $= 0.50 \times 70 = 35$ litres. Adding counts each vessel's acid twice: $2 \times \text{total acid} = 82$, so total acid $= 41$ litres in $100$ litres, which is $41\%$.",
  "Averaging the pairwise strengths, or averaging the individual strengths, without volume weights.",
  "C06C-pairwise-mix-strengths", "Needs the acid-litre view of each pair and the double-counting insight; unequal volumes block the simple average.",
  correct=r"$41\%$",
  distractors=[(r"$39\%$", "Takes the simple average of the pairwise strengths, $\\frac{22 + 45 + 50}{3}$."),
               (r"$35\%$", "Solves for the strengths $25\\%$, $20\\%$, $60\\%$ and averages them without volume weights."),
               (r"$60\%$", "Solves for the individual strengths and reports R's, the largest vessel.")],
  check=_c25, values=[41, 39, 35, 60], cognitive="Analysis", exams=CE)


def _c26():
    best = None
    for a in range(6, 41):
        for b in range(6, 41):
            c = 40 - a - b
            if c >= 6 and 10 * a + 25 * b + 50 * c == 30 * 40:
                best = c if best is None else min(best, c)
    return best
q("C06-C-026", "Multi-vessel mixtures", "Minimum draw from the only vessel above the target strength, with a minimum draw from the weakest", "Difficult",
  "Casework/optimisation",
  r"Three tanks hold acid solutions of strength $10\%$, $25\%$ and $50\%$. Kabir must make $40$ litres of a $30\%$ solution using at least $6$ litres from each tank, in whole litres. What is the least number of litres he can draw from the $50\%$ tank?",
  "TITA",
  r"With $a, b, c$ litres: $a + b + c = 40$ and $10a + 25b + 50c = 1200$. Subtracting $10$ times the first gives $15b + 40c = 800$, so $b = \frac{160 - 8c}{3}$ and $a = 40 - b - c = \frac{5c - 40}{3}$. Whole litres need $5c - 40$ divisible by $3$, that is $c \equiv 2 \pmod 3$: $c = 11, 14, 17, \ldots$. The bound $a \ge 6$ forces $5c \ge 58$, so $c \ge 12$, and the first allowed value is $c = 14$. At $c = 14$: $a = 10$, $b = 16$, all at least $6$. Least draw is $14$ litres.",
  "Stopping at the bound $c \\ge 12$ without checking that the draws come out in whole litres.",
  "C06C-concentration-range", "Diophantine reduction where the lower bound and the divisibility condition both bind, so the first candidate fails.",
  tita_answer=14, check=_c26, cognitive="Analysis", exams=CE,
  tita_traps=[(12, "Uses only the bound $a \\ge 6$, giving $c \\ge 11.6$, and ignores that $c = 12$ makes $a = \\frac{20}{3}$, not a whole number."), (11, "Takes $c = 11$, the first value that makes every draw a whole number, without checking that it gives $a = 5$, below the $6$-litre minimum."), (20, "Alligates only the $10\\%$ and $50\\%$ tanks, $1 : 1$, giving $20$ litres.")])


def _c27():
    P = vessel(m=40, w=0, s=0); Q = vessel(m=0, w=20, s=0); R = vessel(m=0, w=0, s=30)
    pour(P, Q, 20); pour(Q, R, 10); pour(R, P, 20)
    return rt(P["m"], P["w"], P["s"])
q("C06-C-027", "Multi-vessel mixtures", "Cyclic transfers among three vessels each starting with a different pure liquid", "Difficult",
  "Multi-step word problem",
  r"Vessel P contains $40$ litres of milk, vessel Q contains $20$ litres of water and vessel R contains $30$ litres of syrup. Rahul pours $20$ litres from P into Q, then $10$ litres from Q into R, then $20$ litres from R into P, stirring well after every pour. What is the ratio of milk : water : syrup in P at the end?",
  "MCQ",
  r"Q becomes $20$ milk and $20$ water; its $10$ litres to R carry $5$ milk and $5$ water. R becomes $5$ milk, $5$ water, $30$ syrup ($40$ litres), so the $20$ litres sent to P (half of R) carry $2.5$ milk, $2.5$ water, $15$ syrup. P had $20$ litres of milk left, so it ends with $22.5 : 2.5 : 15 = 9 : 1 : 6$.",
  "Not removing the $20$ litres that left P, or dropping the milk carried back from R.",
  "C06C-cyclic-transfer", "Three components tracked through three unequal transfers around a cycle.",
  correct=r"$9 : 1 : 6$",
  distractors=[(r"$17 : 1 : 6$", "Keeps P's original $40$ litres of milk: $42.5 : 2.5 : 15$."),
               (r"$1 : 1 : 6$", "Reports the composition of the $20$ litres sent from R (also R's final ratio)."),
               (r"$8 : 1 : 6$", "Counts the water and syrup returned from R but not its $2.5$ litres of milk: $20 : 2.5 : 15$.")],
  check=_c27, values=[rt(9, 1, 6), rt(17, 1, 6), rt(1, 1, 6), rt(8, 1, 6)], cognitive="Analysis", exams=CE)


def _c28():
    p, qq, r = symbols('p q r', positive=True)
    milk = Rational(3, 4) * p + Rational(1, 4) * r
    water = Rational(1, 4) * p + Rational(1, 2) * qq
    syrup = Rational(1, 2) * qq + Rational(3, 4) * r
    s = solve([Eq(milk, water), Eq(water, syrup), Eq(r, 2)], [p, qq, r], dict=True)[0]
    return rt(s[p], s[qq], s[r])
q("C06-C-028", "Multi-vessel mixtures", "Ratio of draws from three two-component vessels to get equal amounts of three components", "Difficult",
  "Inverse/parameter",
  r"Jar P contains milk and water in the ratio $3 : 1$, jar Q contains water and syrup in the ratio $1 : 1$, and jar R contains milk and syrup in the ratio $1 : 3$. In what ratio of volumes P : Q : R should liquid be drawn from the jars so that the mixture contains equal volumes of milk, water and syrup?",
  "MCQ",
  r"Per litre, P gives $\frac{3}{4}$ milk and $\frac{1}{4}$ water; Q gives $\frac{1}{2}$ water and $\frac{1}{2}$ syrup; R gives $\frac{1}{4}$ milk and $\frac{3}{4}$ syrup. Water $=$ syrup: $\frac{p}{4} + \frac{q}{2} = \frac{q}{2} + \frac{3r}{4}$, so $p = 3r$. Milk $=$ water: $\frac{9r}{4} + \frac{r}{4} = \frac{3r}{4} + \frac{q}{2}$, so $q = \frac{7r}{2}$. Thus $p : q : r = 3 : \frac{7}{2} : 1 = 6 : 7 : 2$.",
  "Using ratio terms as litres without dividing by the sum of the terms, or reading a ratio backwards.",
  "C06C-three-component-target-ratio", "Two balance equations in three unknowns across three different two-component jars.",
  correct=r"$6 : 7 : 2$",
  distractors=[(r"$3 : 7 : 1$", "Uses ratio terms as amounts per litre (milk $3p + r$, water $p + q$, syrup $q + 3r$) without dividing by the term sums."),
               (r"$2 : 7 : 6$", "Finds the correct volumes but lists them in the order R : Q : P."),
               (r"$2 : 5 : 2$", "Reads R's ratio as milk : syrup $= 3 : 1$, which gives $p = r$ and $q = \\frac{5r}{2}$.")],
  check=_c28, values=[rt(6, 7, 2), rt(3, 7, 1), rt(2, 7, 6), rt(2, 5, 2)], cognitive="Analysis", exams=CE)


def _c29():
    P = vessel(m=48, w=0); Q = vessel(m=0, w=48)
    for _ in range(3):
        pour(P, Q, 16); pour(Q, P, 16)
    return P["m"]
q("C06-C-029", "Multi-vessel mixtures", "Repeated rounds of equal two-way transfers; milk left after three rounds", "Difficult",
  "Conceptual/application",
  r"Vessel P holds $48$ litres of pure milk and vessel Q holds $48$ litres of pure water. One round consists of pouring $16$ litres from P into Q, stirring, and then pouring $16$ litres from Q back into P and stirring. After three such rounds, how many litres of milk are in P?",
  "TITA",
  r"Both vessels stay at $48$ litres and the total milk stays $48$. Let $d$ be (milk in P) minus (milk in Q). In a round, P sends $\frac{1}{3}$ of its contents to Q, and Q (now $64$ litres) returns $\frac{1}{4}$ of its contents, which works out to $d \to d \times \frac{48 - 16}{48 + 16} = \frac{d}{2}$. So $d$ goes $48 \to 24 \to 12 \to 6$. Then milk in P $= \frac{48 + 6}{2} = 27$ litres. (Round by round, P holds $36$, $30$, then $27$ litres of milk.)",
  "Stopping after one round, or assuming the vessels become fully mixed quickly.",
  "C06C-repeated-two-way-rounds", "Three rounds by direct tracking, or the insight that the milk difference halves each round.",
  tita_answer=27, check=_c29, cognitive="Analysis", exams=CE,
  tita_traps=[(36, "Stops after the first round."), (30, "Stops after the second round."), (24, "Assumes the two vessels are fully mixed, $48 / 2$.")])


def _c30():
    best = None
    for a in range(1, 25):
        for b in range(1, 25):
            c = 24 - a - b
            if c >= 1 and Fraction(a, 2) + Fraction(2 * b, 3) + Fraction(3 * c, 4) == 16:
                best = b if best is None else max(best, b)
    return best
q("C06-C-030", "Multi-vessel mixtures", "Largest whole-litre draw from the middle vessel when all three must be used", "Difficult",
  "Casework/optimisation",
  r"Jugs P, Q and R contain milk and water in the ratios $1 : 1$, $2 : 1$ and $3 : 1$ respectively. Sneha wants $24$ litres of a mixture with milk and water in the ratio $2 : 1$, drawing a whole number of litres from each jug and at least $1$ litre from every jug. What is the largest number of litres she can draw from Q?",
  "MCQ",
  r"With $p, q, r$ litres, milk $= \frac{p}{2} + \frac{2q}{3} + \frac{3r}{4} = 16$ and $p + q + r = 24$. Multiplying the first by $12$ and subtracting $6$ times the second gives $2q + 3r = 48$, so $q = 24 - \frac{3r}{2}$ and $p = \frac{r}{2}$. Thus $r$ must be even, and $p \ge 1$ forces $r \ge 2$. The largest $q$ is at $r = 2$: $q = 21$, $p = 1$.",
  "Ignoring the at-least-one-litre condition or the whole-litre condition.",
  "C06C-integer-draw-count", "Diophantine reduction with a parity condition and a lower bound.",
  correct=r"$21$ litres",
  distractors=[(r"$3$ litres", "Sets up $q = 24 - \\frac{3r}{2}$ correctly but takes the largest allowed even $r = 14$, which gives the smallest possible draw from Q instead of the largest."),
               (r"$9$ litres", r"Substitutes $p = 24 - q - r$ to get $\frac{q}{6} + \frac{r}{4} = 4$, then multiplies the left side by $24$ but the right side by $12$: $4q + 6r = 48$, so $q = 12 - \frac{3r}{2}$, largest at $r = 2$."),
               (r"$18$ litres", "Assumes the draw from R must be a multiple of $4$, so takes $r = 4$, $p = 2$.")],
  check=_c30, values=[21, 3, 9, 18], cognitive="Analysis", exams=CE)
