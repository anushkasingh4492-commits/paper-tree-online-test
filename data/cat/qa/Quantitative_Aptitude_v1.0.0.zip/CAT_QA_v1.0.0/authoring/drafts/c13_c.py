import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Special series"
HARD = ("CAT", "XAT")
F = Fraction


# ---------------------------------------------------------------- 001
def _c001():
    total, side = 0, 12
    while side >= 1:
        total += side * side
        side -= 1
    return total
q("C13-C-001", TOPIC, "Count of objects in a square-based pyramid stack (sum of squares)", "Easy",
  "Multi-step word problem",
  r"A fruit seller stacks oranges in a solid pyramid. The bottom layer is a square of $12$ by $12$ oranges, each layer above it is a square with one orange fewer along each side than the layer below, and the top layer is a single orange. How many oranges are there in the stack?",
  "TITA",
  r"The layers contain $12^2, 11^2, \dots, 1^2$ oranges. Using $1^2 + 2^2 + \dots + n^2 = \frac{n(n+1)(2n+1)}{6}$ with $n = 12$ gives $\frac{12 \times 13 \times 25}{6} = 650$ oranges.",
  "Adding the side lengths $1 + 2 + \\dots + 12$ instead of the layer sizes, or counting only the bottom layer.",
  "C13C-sum-squares-stack", "One standard formula applied to a stack that must first be recognised as a sum of squares.",
  tita_answer=650, check=_c001, values=[650],
  tita_traps=[(78, "Adds the side lengths $1 + 2 + \\dots + 12$ instead of their squares."),
              (144, "Counts only the bottom layer, $12^2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    big = sum(s * s for s in range(11, 21))
    small = sum(s * s for s in range(1, 11))
    return big - small
q("C13-C-002", TOPIC, "Difference of two blocks of consecutive squares by pairing terms", "Medium",
  "Multi-step word problem",
  r"Meera has ten square tiles with sides $11$ cm, $12$ cm, $13$ cm, $\dots$, $20$ cm, one of each size. Ravi has ten square tiles with sides $1$ cm, $2$ cm, $3$ cm, $\dots$, $10$ cm, one of each size. By how much does the total area of Meera's tiles exceed the total area of Ravi's tiles?",
  "MCQ",
  r"Pair Meera's tile of side $k + 10$ with Ravi's tile of side $k$, for $k = 1, 2, \dots, 10$. Each pair differs by $(k+10)^2 - k^2 = 20k + 100$. Summing, the excess is $20(1 + 2 + \dots + 10) + 10 \times 100 = 20 \times 55 + 1000 = 2100$ cm$^2$. (Check: $2870 - 2 \times 385 = 2100$.)",
  "Dropping the cross term $20k$, halving it, or not subtracting Ravi's total at all.",
  "C13C-sum-squares-shifted-blocks", "Needs either two partial sums of squares or the pairing $(k+10)^2 - k^2$; two steps with an easy omission.",
  correct=r"$2100$ cm$^2$",
  distractors=[(r"$2485$ cm$^2$", "Finds Meera's total $11^2 + \\dots + 20^2 = 2870 - 385 = 2485$ and forgets to subtract Ravi's total $385$."),
               (r"$1550$ cm$^2$", "Expands $(k+10)^2 - k^2$ as $10k + 100$, dropping the factor $2$ in the cross term: $550 + 1000 = 1550$."),
               (r"$1000$ cm$^2$", "Keeps only the constant $100$ in each pair difference and drops the $20k$ term: $10 \\times 100$.")],
  check=_c002, values=[2100, 2485, 1550, 1000], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    return sum(e ** 3 for e in range(1, 16))
q("C13-C-003", TOPIC, "Total unit cubes in solid cubes of edges 1 to 15 (sum of cubes)", "Easy",
  "Single-step computation",
  r"A child builds $15$ solid cubes out of identical unit cubes. The first solid cube has edge $1$ unit, the second has edge $2$ units, and so on, the fifteenth having edge $15$ units. How many unit cubes are used in all?",
  "MCQ",
  r"The total is $1^3 + 2^3 + \dots + 15^3 = \left(\frac{15 \times 16}{2}\right)^2 = 120^2 = 14400$.",
  "Using the sum of squares formula, stopping one term early, or counting only the largest cube.",
  "C13C-sum-cubes", "Direct use of the identity for the sum of the first $n$ cubes.",
  correct=r"$14400$",
  distractors=[(r"$11025$", "Stops at $14^3$: $\\left(\\frac{14 \\times 15}{2}\\right)^2 = 105^2 = 11025$."),
               (r"$1240$", "Uses the sum of squares formula: $\\frac{15 \\times 16 \\times 31}{6} = 1240$."),
               (r"$3375$", "Counts only the largest cube, $15^3$.")],
  check=_c003, values=[14400, 11025, 1240, 3375], cognitive="Recall")

# ---------------------------------------------------------------- 004
def _c004():
    s, n = 0, 0
    while s <= 100000:
        n += 1
        s += n ** 3
    return n
q("C13-C-004", TOPIC, "Smallest n for which the sum of the first n cubes exceeds a bound", "Medium",
  "Inverse/parameter",
  r"What is the smallest positive integer $n$ for which $1^3 + 2^3 + 3^3 + \dots + n^3$ exceeds $1{,}00{,}000$?",
  "TITA",
  r"The sum equals $\left(\frac{n(n+1)}{2}\right)^2$, which exceeds $100000$ exactly when $\frac{n(n+1)}{2} > \sqrt{100000} \approx 316.2$, that is $n(n+1) > 632.4$. Since $24 \times 25 = 600$ and $25 \times 26 = 650$, the smallest such $n$ is $25$. Check: $n = 24$ gives $300^2 = 90000$ and $n = 25$ gives $325^2 = 105625$.",
  "Forgetting that the identity squares $\\frac{n(n+1)}{2}$, or reporting the largest $n$ that does not exceed the bound.",
  "C13C-sum-cubes", "Inverting the sum of cubes identity and bracketing a square root between consecutive products.",
  tita_answer=25, check=_c004, values=[25],
  tita_traps=[(24, "Reports the largest $n$ whose sum stays below the bound ($90000$)."),
              (18, "Drops the division by $2$ and solves $n(n+1) > 316.2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    return sum(k ** 3 for k in range(1, 20, 2))
q("C13-C-005", TOPIC, "Sum of cubes of the first ten odd numbers via all cubes minus even cubes", "Medium",
  "Conceptual/application",
  r"The value of $1^3 + 3^3 + 5^3 + \dots + 19^3$ is",
  "MCQ",
  r"Take all cubes up to $20^3$ and remove the even ones. $1^3 + \dots + 20^3 = 210^2 = 44100$, and $2^3 + 4^3 + \dots + 20^3 = 8(1^3 + \dots + 10^3) = 8 \times 55^2 = 24200$. The odd cubes sum to $44100 - 24200 = 19900$.",
  "Forgetting the factor $8 = 2^3$ when the even cubes are rewritten, or assuming the odd and even parts are equal.",
  "C13C-odd-power-sums", "Splitting into all terms minus even terms and handling the scale factor $2^3$.",
  correct=r"$19900$",
  distractors=[(r"$24200$", "Reports the sum of the even cubes $2^3 + \\dots + 20^3$ that was meant to be subtracted."),
               (r"$41075$", "Writes the even cubes as $1^3 + \\dots + 10^3 = 3025$ without the factor $8$: $44100 - 3025$."),
               (r"$22050$", "Assumes the odd and even cubes contribute equally and halves $44100$.")],
  check=_c005, values=[19900, 24200, 41075, 22050], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    cnt = 0
    for n in range(1, 101):
        if sum(k * k for k in range(1, n + 1)) % 5 == 0:
            cnt += 1
    return cnt
q("C13-C-006", TOPIC, "Counting n up to 100 for which the sum of the first n squares is a multiple of 5", "Difficult",
  "Casework/optimisation",
  r"For how many integers $n$ with $1 \le n \le 100$ is $1^2 + 2^2 + 3^2 + \dots + n^2$ divisible by $5$?",
  "TITA",
  r"The sum is $\frac{n(n+1)(2n+1)}{6}$. Since $5$ and $6$ are coprime, it is divisible by $5$ exactly when $5$ divides $n(n+1)(2n+1)$. Modulo $5$: $n \equiv 0$ makes $n$ a multiple, $n \equiv 4$ makes $n + 1$ a multiple, and $n \equiv 2$ makes $2n + 1 = 5$ a multiple; $n \equiv 1, 3$ give none. So $3$ residues out of every $5$, and among $1$ to $100$ there are $3 \times 20 = 60$ such $n$.",
  "Checking only the factors $n$ and $n+1$ and missing the factor $2n+1$.",
  "C13C-sum-squares-divisibility", "Needs the closed form, the coprimality argument and a residue casework that hides the $2n+1$ case.",
  tita_answer=60, check=_c006, values=[60],
  tita_traps=[(40, "Considers only $n$ or $n + 1$ being a multiple of $5$ and misses $2n + 1$."),
              (20, "Counts only the multiples of $5$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 007
def _c007():
    s = 0
    for k in range(20, 0, -1):
        s += k * k if k % 2 == 0 else -k * k
    return s
q("C13-C-007", TOPIC, "Alternating sum of squares from 20 down to 1 by difference of squares", "Easy",
  "Conceptual/application",
  r"The value of $20^2 - 19^2 + 18^2 - 17^2 + \dots + 2^2 - 1^2$ is",
  "MCQ",
  r"Each pair is a difference of squares of consecutive integers: $(m+1)^2 - m^2 = (m+1) + m$. So the expression equals $(20 + 19) + (18 + 17) + \dots + (2 + 1) = 1 + 2 + \dots + 20 = 210$.",
  "Treating each consecutive difference of squares as $1$, or using $2m - 1$ in place of $2m + 1$.",
  "C13C-alternating-squares", "One insight (difference of squares turns the series into $1 + 2 + \\dots + 20$).",
  correct=r"$210$",
  distractors=[(r"$10$", "Takes each $(m+1)^2 - m^2$ as $(m+1) - m = 1$, dropping the factor $(m+1) + m$; ten pairs give $10$."),
               (r"$230$", "Writes $(2k)^2 - (2k-1)^2$ as $4k + 1$ instead of $4k - 1$: $4 \\times 55 + 10 = 230$."),
               (r"$420$", "Writes each pair as $2(m + 1) + 2m$, doubling every pair: $2 \\times 210$.")],
  check=_c007, values=[210, 10, 230, 420], cognitive="Understanding")

# ---------------------------------------------------------------- 008
def _c008():
    return sum(k * k if k % 2 == 1 else -k * k for k in range(1, 50))
q("C13-C-008", TOPIC, "Alternating sum of squares 1 to 49 with an unpaired last term", "Medium",
  "Conceptual/application",
  r"The value of $1^2 - 2^2 + 3^2 - 4^2 + \dots - 48^2 + 49^2$ is",
  "MCQ",
  r"Pair from the top: $49^2 - 48^2 = 97$, $47^2 - 46^2 = 93$, and so on down to $3^2 - 2^2 = 5$, leaving $1^2 = 1$ alone. Each pair $(m+1)^2 - m^2 = (m + 1) + m$, so the total is $49 + 48 + 47 + \dots + 2 + 1 = \frac{49 \times 50}{2} = 1225$. The sign is positive because the odd squares are the larger terms in each pair.",
  "Pairing from the start and losing the unpaired $49^2$, or treating the series as running up to $50$.",
  "C13C-alternating-squares", "Pairing needs care because the number of terms is odd and the sign of the result must be tracked.",
  correct=r"$1225$",
  distractors=[(r"$-1176$", "Pairs from the start as $(1^2 - 2^2) + \\dots + (47^2 - 48^2) = -(1 + 2 + \\dots + 48)$ and forgets the unpaired $49^2$."),
               (r"$1275$", "Uses $1 + 2 + \\dots + 50$, treating the series as running up to $50$."),
               (r"$-1275$", "Treats the series as $1^2 - 2^2 + \\dots - 50^2$, which equals $-(1 + 2 + \\dots + 50)$.")],
  check=_c008, values=[1225, -1176, 1275, -1275], cognitive="Analysis")

# ---------------------------------------------------------------- 009
def _c009():
    return sum(F(1, k * (k + 1)) for k in range(2, 30))
q("C13-C-009", TOPIC, "Telescoping sum of 1/(k(k+1)) from k = 2 to 29", "Easy",
  "Single-step computation",
  r"The value of $\frac{1}{2 \cdot 3} + \frac{1}{3 \cdot 4} + \frac{1}{4 \cdot 5} + \dots + \frac{1}{29 \cdot 30}$ is",
  "MCQ",
  r"Since $\frac{1}{k(k+1)} = \frac{1}{k} - \frac{1}{k+1}$, the sum telescopes to $\frac{1}{2} - \frac{1}{30} = \frac{15 - 1}{30} = \frac{7}{15}$.",
  "Starting the telescoping from $1$ instead of $\\frac{1}{2}$, or using the wrong last term.",
  "C13C-telescoping-two-factor", "One partial fraction split followed by cancellation.",
  correct=r"$\frac{7}{15}$",
  distractors=[(r"$\frac{29}{30}$", "Telescopes as if the first term were $\\frac{1}{1 \\cdot 2}$: $1 - \\frac{1}{30}$."),
               (r"$\frac{8}{15}$", "Gets the sign of the surviving last term wrong: $\\frac{1}{2} + \\frac{1}{30}$."),
               (r"$\frac{27}{58}$", "Keeps $\\frac{1}{29}$ as the surviving last term: $\\frac{1}{2} - \\frac{1}{29}$.")],
  check=_c009, values=[F(7, 15), F(29, 30), F(8, 15), F(27, 58)], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    return sum(F(1, sum(range(1, k + 1))) for k in range(1, 100))
q("C13-C-010", TOPIC, "Sum of reciprocals of the first 99 triangular numbers", "Medium",
  "Single-step computation",
  r"The value of $1 + \frac{1}{1 + 2} + \frac{1}{1 + 2 + 3} + \dots + \frac{1}{1 + 2 + 3 + \dots + 99}$ is",
  "MCQ",
  r"The $k$th term is $\frac{1}{k(k+1)/2} = \frac{2}{k(k+1)} = 2\left(\frac{1}{k} - \frac{1}{k+1}\right)$, for $k = 1$ to $99$. The sum telescopes to $2\left(1 - \frac{1}{100}\right) = \frac{99}{50}$.",
  "Dropping the factor $2$ from the triangular number, or ending the telescoping at the wrong index.",
  "C13C-telescoping-two-factor", "Rewriting each denominator as a triangular number before telescoping.",
  correct=r"$\frac{99}{50}$",
  distractors=[(r"$\frac{99}{100}$", "Takes $1 + 2 + \\dots + k$ as $k(k+1)$, losing the factor $2$: $1 - \\frac{1}{100}$."),
               (r"$\frac{200}{101}$", "Runs the telescoping one term too far, to $k = 100$: $2\\left(1 - \\frac{1}{101}\\right)$."),
               (r"$\frac{196}{99}$", "Ends the telescoping with $\\frac{1}{99}$ instead of $\\frac{1}{100}$: $2\\left(1 - \\frac{1}{99}\\right)$.")],
  check=_c010, values=[F(99, 50), F(99, 100), F(200, 101), F(196, 99)], cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    S = lambda n: n * (n + 1) * (n + 2)
    terms = [S(k) - S(k - 1) for k in range(1, 21)]
    return sum(F(1, t) for t in terms)
q("C13-C-011", TOPIC, "Terms recovered from the partial-sum formula, then reciprocals telescoped", "Difficult",
  "Multi-step word problem",
  r"For a sequence $t_1, t_2, t_3, \dots$, the sum of the first $n$ terms is $n(n+1)(n+2)$ for every positive integer $n$. What is the value of $\frac{1}{t_1} + \frac{1}{t_2} + \dots + \frac{1}{t_{20}}$?",
  "MCQ",
  r"$t_n = n(n+1)(n+2) - (n-1)n(n+1) = 3n(n+1)$, which also gives $t_1 = 6$ correctly. Then $\frac{1}{t_n} = \frac{1}{3}\left(\frac{1}{n} - \frac{1}{n+1}\right)$, and the sum telescopes to $\frac{1}{3}\left(1 - \frac{1}{21}\right) = \frac{1}{3} \times \frac{20}{21} = \frac{20}{63}$.",
  "Treating $n(n+1)(n+2)$ as the $n$th term instead of the $n$th partial sum, or losing the factor $3$.",
  "C13C-telescoping-two-factor", "Two linked ideas: extract $t_n$ from the partial sums, then telescope; a strong trap in reading the formula as $t_n$.",
  correct=r"$\frac{20}{63}$",
  distractors=[(r"$\frac{20}{21}$", "Finds $t_n = 3n(n+1)$ but drops the factor $\\frac{1}{3}$ while telescoping."),
               (r"$\frac{115}{462}$", "Reads $n(n+1)(n+2)$ as the $n$th term and sums $\\frac{1}{k(k+1)(k+2)}$: $\\frac{1}{4} - \\frac{1}{2 \\cdot 21 \\cdot 22}$."),
               (r"$\frac{7}{22}$", "Telescopes one term too far, to $n = 21$: $\\frac{1}{3}\\left(1 - \\frac{1}{22}\\right)$.")],
  check=_c011, values=[F(20, 63), F(20, 21), F(115, 462), F(7, 22)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 012
def _c012():
    return sum(F(1, k * (k + 1) * (k + 2)) for k in range(1, 19))
q("C13-C-012", TOPIC, "Telescoping sum of 1/(k(k+1)(k+2)) up to k = 18", "Medium",
  "Single-step computation",
  r"The value of $\frac{1}{1 \cdot 2 \cdot 3} + \frac{1}{2 \cdot 3 \cdot 4} + \frac{1}{3 \cdot 4 \cdot 5} + \dots + \frac{1}{18 \cdot 19 \cdot 20}$ is",
  "MCQ",
  r"Use $\frac{1}{k(k+1)(k+2)} = \frac{1}{2}\left(\frac{1}{k(k+1)} - \frac{1}{(k+1)(k+2)}\right)$. The sum telescopes to $\frac{1}{2}\left(\frac{1}{1 \cdot 2} - \frac{1}{19 \cdot 20}\right) = \frac{1}{4} - \frac{1}{760} = \frac{190 - 1}{760} = \frac{189}{760}$.",
  "Forgetting the factor $\\frac{1}{2}$ in the three-factor split, or ending at the wrong pair.",
  "C13C-telescoping-three-factor", "Needs the less familiar three-factor split with its factor $\\frac{1}{2}$.",
  correct=r"$\frac{189}{760}$",
  distractors=[(r"$\frac{189}{380}$", "Omits the factor $\\frac{1}{2}$: $\\frac{1}{2} - \\frac{1}{380}$."),
               (r"$\frac{85}{342}$", "Ends the telescoping at $\\frac{1}{18 \\cdot 19}$: $\\frac{1}{4} - \\frac{1}{684}$."),
               (r"$\frac{1}{4}$", "Keeps only the first surviving piece, as if summing to infinity.")],
  check=_c012, values=[F(189, 760), F(189, 380), F(85, 342), F(1, 4)], cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    return sum(F(k, k ** 4 + k ** 2 + 1) for k in range(1, 21))
q("C13-C-013", TOPIC, "Telescoping k/(k^4 + k^2 + 1) via factorisation into two quadratics", "Difficult",
  "Conceptual/application",
  r"The value of $\sum_{k=1}^{20} \frac{k}{k^4 + k^2 + 1}$ is",
  "MCQ",
  r"Factor $k^4 + k^2 + 1 = (k^2 + 1)^2 - k^2 = (k^2 - k + 1)(k^2 + k + 1)$. The two factors differ by $2k$, so $\frac{k}{k^4 + k^2 + 1} = \frac{1}{2}\left(\frac{1}{k^2 - k + 1} - \frac{1}{k^2 + k + 1}\right)$. Since $k^2 + k + 1 = (k+1)^2 - (k+1) + 1$, the sum telescopes to $\frac{1}{2}\left(1 - \frac{1}{20^2 + 20 + 1}\right) = \frac{1}{2} \times \frac{420}{421} = \frac{210}{421}$.",
  "Missing the factor $\\frac{1}{2}$ or taking the wrong surviving last term.",
  "C13C-telescoping-quartic", "Non-obvious factorisation of a quartic before any telescoping is visible.",
  correct=r"$\frac{210}{421}$",
  distractors=[(r"$\frac{420}{421}$", "Telescopes correctly but omits the factor $\\frac{1}{2}$."),
               (r"$\frac{190}{381}$", "Takes the surviving last term as $\\frac{1}{20^2 - 20 + 1} = \\frac{1}{381}$."),
               (r"$\frac{1}{2}$", "Keeps only the first surviving term, as for the infinite sum.")],
  check=_c013, values=[F(210, 421), F(420, 421), F(190, 381), F(1, 2)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 014
def _c014():
    s = N(sum(1 / (sqrt(k) + sqrt(k + 1)) for k in range(1, 121)), 50)
    r = int(round(s))
    assert abs(s - r) < 1e-30
    return r
q("C13-C-014", TOPIC, "Telescoping sum after rationalising 1/(sqrt k + sqrt(k+1))", "Easy",
  "Single-step computation",
  r"What is the value of $\frac{1}{\sqrt{1} + \sqrt{2}} + \frac{1}{\sqrt{2} + \sqrt{3}} + \frac{1}{\sqrt{3} + \sqrt{4}} + \dots + \frac{1}{\sqrt{120} + \sqrt{121}}$?",
  "TITA",
  r"Rationalising, $\frac{1}{\sqrt{k} + \sqrt{k+1}} = \sqrt{k+1} - \sqrt{k}$. The sum telescopes to $\sqrt{121} - \sqrt{1} = 11 - 1 = 10$.",
  "Forgetting to subtract the surviving first term $\\sqrt{1}$.",
  "C13C-radical-telescoping", "One rationalisation and direct cancellation.",
  tita_answer=10, check=_c014, values=[10],
  tita_traps=[(11, "Keeps only $\\sqrt{121}$ and forgets to subtract $\\sqrt{1}$."),
              (12, "Gets the sign of the first term wrong: $\\sqrt{121} + 1$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 015
def _c015():
    n = symbols('n', positive=True)
    sol = solve(Eq(sqrt(n + 1) - 1, 14), n)
    n0 = int(sol[0])
    s = sum(1 / (sqrt(k) + sqrt(k + 1)) for k in range(1, n0 + 1))
    assert abs(N(s, 40) - 14) < 1e-30
    return n0
q("C13-C-015", TOPIC, "Number of terms of the sum of 1/(sqrt k + sqrt(k+1)) that gives a target value", "Medium",
  "Inverse/parameter",
  r"For a positive integer $n$, let $S_n = \frac{1}{\sqrt{1} + \sqrt{2}} + \frac{1}{\sqrt{2} + \sqrt{3}} + \dots + \frac{1}{\sqrt{n} + \sqrt{n+1}}$. For what value of $n$ is $S_n = 14$?",
  "TITA",
  r"Each term rationalises to $\sqrt{k+1} - \sqrt{k}$, so $S_n = \sqrt{n+1} - 1$. Setting $\sqrt{n+1} - 1 = 14$ gives $\sqrt{n+1} = 15$, so $n + 1 = 225$ and $n = 224$.",
  "Dropping the $-1$ from the telescoped sum, or setting $\\sqrt{n} = 15$ instead of $\\sqrt{n+1} = 15$.",
  "C13C-radical-telescoping", "Telescoping must be done in general before the condition can be inverted; two index traps.",
  tita_answer=224, check=_c015, values=[224],
  tita_traps=[(195, "Takes $S_n = \\sqrt{n+1}$, forgetting the $-1$, so $n + 1 = 196$."),
              (225, "Solves $\\sqrt{n} = 15$ instead of $\\sqrt{n+1} = 15$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    # verify the telescoped form on small n, then count n for which it is rational
    for n in range(1, 8):
        s = sum(1 / ((k + 1) * sqrt(k) + k * sqrt(k + 1)) for k in range(1, n + 1))
        assert abs(N(s - (1 - 1 / sqrt(n + 1)), 40)) < 1e-30
    return sum(1 for n in range(1, 2026) if math.isqrt(n + 1) ** 2 == n + 1)
q("C13-C-016", TOPIC, "Counting n for which a telescoping surd sum is rational", "Difficult",
  "Casework/optimisation",
  r"For a positive integer $n$, let $T_n = \frac{1}{2\sqrt{1} + 1\sqrt{2}} + \frac{1}{3\sqrt{2} + 2\sqrt{3}} + \frac{1}{4\sqrt{3} + 3\sqrt{4}} + \dots + \frac{1}{(n+1)\sqrt{n} + n\sqrt{n+1}}$. For how many integers $n$ with $1 \le n \le 2025$ is $T_n$ a rational number?",
  "TITA",
  r"Factor the $k$th denominator as $\sqrt{k}\sqrt{k+1}(\sqrt{k+1} + \sqrt{k})$. Rationalising, the term equals $\frac{\sqrt{k+1} - \sqrt{k}}{\sqrt{k}\sqrt{k+1}} = \frac{1}{\sqrt{k}} - \frac{1}{\sqrt{k+1}}$. So $T_n = 1 - \frac{1}{\sqrt{n+1}}$, which is rational exactly when $n + 1$ is a perfect square. With $2 \le n + 1 \le 2026$, $n + 1$ can be $2^2, 3^2, \dots, 45^2$ (as $45^2 = 2025$ and $46^2 = 2116$), giving $44$ values.",
  "Including $n + 1 = 1$, which would need $n = 0$, or miscounting the squares up to $2026$.",
  "C13C-radical-telescoping", "Non-obvious factorisation of the denominator, then a counting condition with endpoint care.",
  tita_answer=44, check=_c016, values=[44],
  tita_traps=[(45, "Counts $1^2$ as well, which corresponds to $n = 0$."),
              (43, "Reads the bound as $n + 1 < 2025$ and loses $45^2$, counting only $2^2, \\dots, 44^2$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 017
def _c017():
    price = F(40)
    for k in range(1, 25):
        price = price * (1 + F(100, k) / 100)
    return price
q("C13-C-017", TOPIC, "Successive percentage increases of 100/k percent form a telescoping product", "Easy",
  "Multi-step word problem",
  r"An item costs Rs. $40$. Its price is then raised $24$ times in succession: the first raise is $100\%$, the second is $50\%$, the third is $33\frac{1}{3}\%$, and in general the $k$th raise is $\frac{100}{k}\%$ of the price just before that raise. What is the final price of the item, in rupees?",
  "TITA",
  r"The $k$th raise multiplies the price by $1 + \frac{1}{k} = \frac{k+1}{k}$. The overall multiplier is $\frac{2}{1} \times \frac{3}{2} \times \frac{4}{3} \times \dots \times \frac{25}{24} = 25$. The final price is $40 \times 25 = 1000$ rupees.",
  "Adding the percentage raises on the original price, or stopping the product one factor early.",
  "C13C-product-telescoping", "One telescoping product disguised as successive percentage changes.",
  tita_answer=1000, check=_c017, values=[1000],
  tita_traps=[(960, "Stops the product at $\\frac{24}{23}$, a multiplier of $24$."),
              (1040, "Runs the product one factor too far, to $\\frac{26}{25}$, a multiplier of $26$.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 018
def _c018():
    p = F(1)
    for k in range(2, 51):
        p *= 1 - F(1, k * k)
    return p
q("C13-C-018", TOPIC, "Telescoping product of (1 - 1/k^2) for k = 2 to 50", "Medium",
  "Conceptual/application",
  r"The value of $\left(1 - \frac{1}{2^2}\right)\left(1 - \frac{1}{3^2}\right)\left(1 - \frac{1}{4^2}\right) \cdots \left(1 - \frac{1}{50^2}\right)$ is",
  "MCQ",
  r"Write $1 - \frac{1}{k^2} = \frac{k-1}{k} \cdot \frac{k+1}{k}$. The first factors give $\frac{1}{2} \cdot \frac{2}{3} \cdots \frac{49}{50} = \frac{1}{50}$ and the second give $\frac{3}{2} \cdot \frac{4}{3} \cdots \frac{51}{50} = \frac{51}{2}$. The product is $\frac{1}{50} \times \frac{51}{2} = \frac{51}{100}$.",
  "Telescoping only one of the two factor families, or stopping one factor early.",
  "C13C-product-telescoping", "Two interleaved telescoping products must both be tracked.",
  correct=r"$\frac{51}{100}$",
  distractors=[(r"$\frac{1}{50}$", "Telescopes only the $\\frac{k-1}{k}$ factors and ignores the $\\frac{k+1}{k}$ factors."),
               (r"$\frac{51}{50}$", "Multiplies $\\frac{1}{50}$ by $51$, dropping the denominator $2$ of the second product."),
               (r"$\frac{25}{49}$", "Stops at $k = 49$: $\\frac{1}{49} \\times \\frac{50}{2}$.")],
  check=_c018, values=[F(51, 100), F(1, 50), F(51, 50), F(25, 49)], cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    return sum(k * math.factorial(k) for k in range(1, 10))
q("C13-C-019", TOPIC, "Sum of k times k factorial telescopes to (n+1)! - 1", "Medium",
  "Conceptual/application",
  r"The value of $1 \cdot 1! + 2 \cdot 2! + 3 \cdot 3! + \dots + 9 \cdot 9!$ is",
  "MCQ",
  r"Since $k \cdot k! = (k + 1 - 1) \cdot k! = (k+1)! - k!$, the sum telescopes to $10! - 1! = 10! - 1$.",
  "Not subtracting the surviving first term $1!$, or ending at $9!$.",
  "C13C-factorial-telescoping", "The rewrite $k = (k+1) - 1$ is the whole insight; then cancellation.",
  correct=r"$10! - 1$",
  distractors=[(r"$10!$", "Telescopes to $10!$ and forgets the surviving $-1!$."),
               (r"$9! - 1$", "Ends the telescoping at $9!$ instead of $(9+1)!$."),
               (r"$10! + 1$", "Gets the sign of the surviving first term wrong.")],
  check=_c019, values=[math.factorial(10) - 1, math.factorial(10), math.factorial(9) - 1, math.factorial(10) + 1],
  cognitive="Understanding")

# ---------------------------------------------------------------- 020
def _c020():
    r = symbols('r')
    k = symbols('k', integer=True, positive=True)
    return summation((k + 1) * Rational(1, 3) ** k, (k, 0, oo))
q("C13-C-020", TOPIC, "Infinite arithmetico-geometric series 1 + 2/3 + 3/9 + ...", "Easy",
  "Single-step computation",
  r"The sum of the infinite series $1 + \frac{2}{3} + \frac{3}{9} + \frac{4}{27} + \frac{5}{81} + \dots$ is",
  "MCQ",
  r"Let $S$ be the sum. Then $\frac{S}{3} = \frac{1}{3} + \frac{2}{9} + \frac{3}{27} + \dots$, and subtracting, $S - \frac{S}{3} = 1 + \frac{1}{3} + \frac{1}{9} + \dots = \frac{3}{2}$. So $\frac{2S}{3} = \frac{3}{2}$ and $S = \frac{9}{4}$.",
  "Stopping at the geometric series $\\frac{3}{2}$ without dividing by $1 - r$.",
  "C13C-agp-infinite", "The standard multiply by $r$ and subtract step, done once.",
  correct=r"$\frac{9}{4}$",
  distractors=[(r"$\frac{3}{2}$", "Finds $S - rS = \\frac{3}{2}$ and reports it as $S$, not dividing by $1 - r = \\frac{2}{3}$."),
               (r"$\frac{3}{4}$", "Uses $\\frac{r}{(1-r)^2} = \\frac{1/3}{4/9}$, the formula for $\\sum k r^k$ starting at $r$, not at $1$."),
               (r"$\frac{9}{2}$", "Divides $\\frac{3}{2}$ by $r = \\frac{1}{3}$ instead of by $1 - r$.")],
  check=_c020, values=[F(9, 4), F(3, 2), F(3, 4), F(9, 2)], cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    k = symbols('k', integer=True, nonnegative=True)
    return summation((1 + 3 * k) * Rational(1, 5) ** k, (k, 0, oo))
q("C13-C-021", TOPIC, "Infinite AGP with first term 1, common difference 3 and ratio 1/5", "Medium",
  "Single-step computation",
  r"The sum of the infinite series $1 + \frac{4}{5} + \frac{7}{25} + \frac{10}{125} + \frac{13}{625} + \dots$ is",
  "MCQ",
  r"The numerators $1, 4, 7, 10, \dots$ rise by $3$ and the denominators are powers of $5$. With $S$ the sum, $S - \frac{S}{5} = 1 + 3\left(\frac{1}{5} + \frac{1}{25} + \dots\right) = 1 + 3 \times \frac{1}{4} = \frac{7}{4}$. So $\frac{4S}{5} = \frac{7}{4}$ and $S = \frac{35}{16}$.",
  "Treating the series as purely geometric, or mishandling the $\\frac{dr}{(1-r)^2}$ part.",
  "C13C-agp-infinite", "An AGP whose arithmetic part does not start at $1$ with difference $1$; the subtraction step must be done carefully.",
  correct=r"$\frac{35}{16}$",
  distractors=[(r"$\frac{5}{4}$", "Sums only the geometric part $1 + \\frac{1}{5} + \\frac{1}{25} + \\dots$, ignoring the growing numerators."),
               (r"$\frac{95}{16}$", "Uses $\\frac{a}{1-r} + \\frac{d}{(1-r)^2} = \\frac{5}{4} + \\frac{75}{16}$, omitting the factor $r$ in the second part."),
               (r"$\frac{31}{16}$", "Uses $a + \\frac{dr}{(1-r)^2} = 1 + \\frac{15}{16}$, taking the first part as the first term alone instead of $\\frac{a}{1-r}$.")],
  check=_c021, values=[F(35, 16), F(5, 4), F(95, 16), F(31, 16)], cognitive="Application")

# ---------------------------------------------------------------- 022
def _c022():
    return sum(k * 2 ** k for k in range(1, 11))
q("C13-C-022", TOPIC, "Finite arithmetico-geometric sum of k times 2^k for k = 1 to 10", "Medium",
  "Single-step computation",
  r"What is the value of $1 \cdot 2 + 2 \cdot 2^2 + 3 \cdot 2^3 + \dots + 10 \cdot 2^{10}$?",
  "TITA",
  r"Let $S$ be the sum. Then $2S = 1 \cdot 2^2 + 2 \cdot 2^3 + \dots + 9 \cdot 2^{10} + 10 \cdot 2^{11}$. Subtracting, $S - 2S = 2 + 2^2 + \dots + 2^{10} - 10 \cdot 2^{11} = (2^{11} - 2) - 20480 = -18434$. Hence $S = 18434$. (In general $S = (n-1)2^{n+1} + 2$; here $9 \times 2048 + 2$.)",
  "Dropping the constant $2$ from the geometric sum, or using $2^n$ where $2^{n+1}$ belongs.",
  "C13C-agp-finite", "A finite AGP with ratio greater than $1$, so signs in the subtraction step need care.",
  tita_answer=18434, check=_c022, values=[18434],
  tita_traps=[(18432, "Writes the geometric part as $2^{11}$ instead of $2^{11} - 2$, giving $(n-1)2^{n+1}$."),
              (9218, "Uses $2^n$ in place of $2^{n+1}$ in the result: $9 \\times 1024 + 2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 023
def _c023():
    s, n = F(0), 0
    while s <= F(199, 100):
        n += 1
        s += F(n, 2 ** n)
    return n
q("C13-C-023", TOPIC, "Smallest n for which a partial sum of k/2^k exceeds 1.99", "Difficult",
  "Inverse/parameter",
  r"Let $S_n = \frac{1}{2} + \frac{2}{2^2} + \frac{3}{2^3} + \dots + \frac{n}{2^n}$. What is the smallest positive integer $n$ for which $S_n > 1.99$?",
  "MCQ",
  r"Using $S_n - \frac{S_n}{2} = \frac{1}{2} + \frac{1}{2^2} + \dots + \frac{1}{2^n} - \frac{n}{2^{n+1}}$, one gets $S_n = 2 - \frac{n+2}{2^n}$. We need $\frac{n+2}{2^n} < \frac{1}{100}$. For $n = 10$: $\frac{12}{1024} \approx 0.0117$, too big. For $n = 11$: $\frac{13}{2048} \approx 0.0063$, which works. So $n = 11$.",
  "Using a wrong tail such as $\\frac{n}{2^n}$ or $\\frac{1}{2^n}$ for $2 - S_n$.",
  "C13C-agp-finite", "Needs the closed form of a finite AGP and then an inequality checked at the boundary; several plausible wrong tails.",
  correct=r"$11$",
  distractors=[(r"$10$", "Takes the shortfall $2 - S_n$ as $\\frac{n}{2^n}$; $\\frac{10}{1024} < 0.01$ gives $10$."),
               (r"$7$", "Treats the series as if it were geometric and takes the shortfall as $\\frac{1}{2^n}$; $2^n > 100$ gives $7$."),
               (r"$12$", "Writes the shortfall as $\\frac{n+2}{2^{n-1}}$; this first drops below $0.01$ at $n = 12$.")],
  check=_c023, values=[11, 10, 7, 12], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 024
def _c024():
    cells = 3
    for _ in range(10):
        cells = 2 * cells - 1
    return cells
q("C13-C-024", TOPIC, "Recurrence a(n+1) = 2a(n) - 1 from a doubling culture with one cell removed each hour", "Medium",
  "Multi-step word problem",
  r"A laboratory culture starts with $3$ cells. At the end of every hour the number of cells doubles, and immediately afterwards exactly one cell is removed for testing. How many cells are there just after the removal at the end of the $10$th hour?",
  "MCQ",
  r"If $a_n$ is the count after $n$ hours, $a_n = 2a_{n-1} - 1$ with $a_0 = 3$. Then $a_n - 1 = 2(a_{n-1} - 1)$, so $a_n - 1 = 2^n(a_0 - 1) = 2^{n+1}$ and $a_n = 2^{n+1} + 1$. Hence $a_{10} = 2^{11} + 1 = 2049$.",
  "Ignoring the removals, subtracting them only at the end, or counting one hour too few.",
  "C13C-linear-recurrence", "Requires the shift $a_n - 1$ to turn the recurrence into a geometric progression.",
  correct=r"$2049$",
  distractors=[(r"$1025$", "Counts one hour too few, giving $a_9 = 2^{10} + 1$."),
               (r"$3072$", "Ignores the removals: $3 \\times 2^{10}$."),
               (r"$3062$", "Doubles ten times and subtracts the ten removed cells only at the end: $3072 - 10$.")],
  check=_c024, values=[2049, 1025, 3072, 3062], cognitive="Application")

# ---------------------------------------------------------------- 025
def _c025():
    a = F(1, 2)
    for _ in range(24):
        a = a / (1 + 2 * a)
    return a
q("C13-C-025", TOPIC, "Recurrence a(n+1) = a(n)/(1 + 2a(n)) linearised by reciprocals", "Medium",
  "Conceptual/application",
  r"A sequence is defined by $a_1 = \frac{1}{2}$ and $a_{n+1} = \frac{a_n}{1 + 2a_n}$ for $n \ge 1$. What is $a_{25}$?",
  "MCQ",
  r"Taking reciprocals, $\frac{1}{a_{n+1}} = \frac{1 + 2a_n}{a_n} = \frac{1}{a_n} + 2$. So $\frac{1}{a_n}$ is an arithmetic progression with first term $2$ and common difference $2$: $\frac{1}{a_n} = 2n$. Hence $a_{25} = \frac{1}{50}$.",
  "Taking the reciprocals to increase by $1$, or miscounting the number of steps from $a_1$.",
  "C13C-reciprocal-recurrence", "The reciprocal substitution is the key insight; then an index count.",
  correct=r"$\frac{1}{50}$",
  distractors=[(r"$\frac{1}{26}$", "Takes the reciprocals to increase by $1$ each step: $\\frac{1}{a_n} = n + 1$."),
               (r"$\frac{1}{48}$", "Uses $\\frac{1}{a_n} = 2(n-1)$, dropping the starting value $2$."),
               (r"$\frac{1}{52}$", "Counts $25$ steps after $a_1$ instead of $24$: $2 + 2 \\times 25$.")],
  check=_c025, values=[F(1, 50), F(1, 26), F(1, 48), F(1, 52)], cognitive="Application")

# ---------------------------------------------------------------- 026
def _c026():
    x, y = symbols('x y')
    seq = [x, y]
    while len(seq) < 10:
        seq.append(seq[-1] + seq[-2])
    sol = solve([Eq(seq[4], 26), Eq(seq[7], 110)], [x, y], dict=True)[0]
    return seq[9].subs(sol)
q("C13-C-026", TOPIC, "Two-term additive recurrence: recover the start from two given terms", "Medium",
  "Inverse/parameter",
  r"In a sequence of positive integers, every term from the third onwards is the sum of the two terms just before it. The $5$th term is $26$ and the $8$th term is $110$. What is the $10$th term?",
  "TITA",
  r"Let the first two terms be $x$ and $y$. The terms run $x, y, x + y, x + 2y, 2x + 3y, 3x + 5y, 5x + 8y, 8x + 13y, \dots$ So $2x + 3y = 26$ and $8x + 13y = 110$. Four times the first equation gives $8x + 12y = 104$, so $y = 6$ and $x = 4$. The sequence is $4, 6, 10, 16, 26, 42, 68, 110, 178, 288$, so the $10$th term is $288$.",
  "Stopping at the $9$th term, or writing the general term with wrong coefficients.",
  "C13C-fibonacci-like", "Two unknowns tracked through the recurrence, then solved simultaneously.",
  tita_answer=288, check=_c026, values=[288],
  tita_traps=[(178, "Reports the $9$th term."),
              (466, "Reports the $11$th term, miscounting from the $8$th.")],
  cognitive="Application")

# ---------------------------------------------------------------- 027
def _c027():
    x = symbols('x')
    seq = [x, Integer(7)]
    while len(seq) < 12:
        seq.append(seq[-1] + seq[-2])
    xv = solve(Eq(seq[11], 788), x)[0]
    vals = [s.subs(x, xv) for s in seq]
    assert all(v > 0 and v == int(v) for v in vals)
    return sum(vals[:10])
q("C13-C-027", TOPIC, "Sum of the first ten terms of a Fibonacci-type sequence from two given terms", "Difficult",
  "Conceptual/application",
  r"In a sequence of positive integers, every term from the third onwards is the sum of the two terms just before it. The $2$nd term is $7$ and the $12$th term is $788$. What is the sum of the first $10$ terms?",
  "MCQ",
  r"Since $a_k = a_{k+2} - a_{k+1}$, the sum $a_1 + a_2 + \dots + a_{10}$ telescopes to $a_{12} - a_2 = 788 - 7 = 781$. (Directly: with $a_1 = x$, $a_{12} = 55x + 89 \times 7 = 55x + 623 = 788$, so $x = 3$, and the first ten terms $3, 7, 10, 17, 27, 44, 71, 115, 186, 301$ add to $781$.)",
  "Using the pure Fibonacci identity $a_{n+2} - 1$, or subtracting the wrong starting term.",
  "C13C-fibonacci-like", "Either a non-obvious telescoping identity or a long chain of coefficients; several near-miss identities.",
  correct=r"$781$",
  distractors=[(r"$787$", "Uses the identity for the standard Fibonacci numbers, sum $= a_{n+2} - 1$."),
               (r"$785$", "Subtracts the first term instead of the second: $a_{12} - a_1 = 788 - 3$."),
               (r"$480$", "Shifts the identity by one place: $a_{11} - a_2 = 487 - 7$.")],
  check=_c027, values=[781, 787, 785, 480], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 028
def _c028():
    a = [2, 5]
    while len(a) < 2026:
        a.append(a[-1] - a[-2])
    return a[2025]
q("C13-C-028", TOPIC, "Term of a period-6 recurrence a(n+2) = a(n+1) - a(n)", "Easy",
  "Conceptual/application",
  r"A sequence has $a_1 = 2$, $a_2 = 5$ and $a_{n+2} = a_{n+1} - a_n$ for all $n \ge 1$. The value of $a_{2026}$ is",
  "MCQ",
  r"The terms are $2, 5, 3, -2, -5, -3, 2, 5, \dots$, so the sequence repeats every $6$ terms. Since $2026 = 6 \times 337 + 4$, $a_{2026} = a_4 = -2$.",
  "Misreading the period or the remainder.",
  "C13C-period-6-recurrence", "Write a few terms, spot the period, take a remainder.",
  correct=r"$-2$",
  distractors=[(r"$3$", "Uses remainder $3$ (from $2025 \\div 6$) and reports $a_3$."),
               (r"$-5$", "Uses remainder $5$ and reports $a_5$, an off-by-one in the remainder."),
               (r"$2$", "Sees $a_4 = -a_1$ and assumes the sequence repeats every $3$ terms; $2026 \\div 3$ leaves $1$, giving $a_1$.")],
  check=_c028, values=[-2, 3, -5, 2], cognitive="Understanding")

# ---------------------------------------------------------------- 029
def _c029():
    a = [4, 9]
    while len(a) < 2026:
        a.append(a[-1] - a[-2])
    return sum(a)
q("C13-C-029", TOPIC, "Partial sum of a period-6 recurrence whose cycle sums to zero", "Medium",
  "Conceptual/application",
  r"A sequence has $a_1 = 4$, $a_2 = 9$ and $a_{n+2} = a_{n+1} - a_n$ for all $n \ge 1$. The sum of the first $2026$ terms of the sequence is",
  "MCQ",
  r"The terms are $4, 9, 5, -4, -9, -5$, then they repeat; each block of $6$ sums to $0$. Since $2026 = 6 \times 337 + 4$, the sum equals the sum of the first $4$ terms: $4 + 9 + 5 - 4 = 14$.",
  "Assuming the full sum is zero, or using the wrong number of leftover terms.",
  "C13C-period-6-recurrence", "Needs the period, the zero block sum and the correct leftover count.",
  correct=r"$14$",
  distractors=[(r"$0$", "Assumes $2026$ is a whole number of periods, so the sum vanishes."),
               (r"$18$", "Takes $3$ leftover terms instead of $4$: $4 + 9 + 5$."),
               (r"$5$", "Takes $5$ leftover terms: $4 + 9 + 5 - 4 - 9$.")],
  check=_c029, values=[14, 0, 18, 5], cognitive="Application")

# ---------------------------------------------------------------- 030
def _c030():
    a = [F(3)]
    while len(a) < 100:
        a.append(1 / (1 - a[-1]))
    p = F(1)
    for t in a:
        p *= t
    return p
q("C13-C-030", TOPIC, "Product of terms of the period-3 recurrence a(n+1) = 1/(1 - a(n))", "Medium",
  "Conceptual/application",
  r"A sequence has $a_1 = 3$ and $a_{n+1} = \frac{1}{1 - a_n}$ for all $n \ge 1$. The product $a_1 a_2 a_3 \cdots a_{100}$ equals",
  "MCQ",
  r"$a_2 = \frac{1}{1 - 3} = -\frac{1}{2}$, $a_3 = \frac{1}{1 + \frac{1}{2}} = \frac{2}{3}$, $a_4 = \frac{1}{1 - \frac{2}{3}} = 3$, so the period is $3$ and each block has product $3 \times \left(-\frac{1}{2}\right) \times \frac{2}{3} = -1$. The first $99$ terms form $33$ blocks with product $(-1)^{33} = -1$, and $a_{100} = a_1 = 3$. The product is $-3$.",
  "Mishandling the sign of $(-1)^{33}$ or forgetting the leftover term $a_{100}$.",
  "C13C-period-3-recurrence", "Spot the period, the block product, then a parity and leftover step.",
  correct=r"$-3$",
  distractors=[(r"$3$", "Takes $(-1)^{33}$ as $+1$."),
               (r"$-1$", "Uses the $33$ full blocks and forgets the leftover factor $a_{100} = 3$."),
               (r"$1$", "Forgets the leftover factor and also takes $(-1)^{33}$ as $+1$.")],
  check=_c030, values=[-3, 3, -1, 1], cognitive="Application")

# ---------------------------------------------------------------- 031
def _c031():
    cnt = 0
    for L in range(1, 13):
        for moves in itertools.product((1, 3), repeat=L):
            if sum(moves) == 12:
                cnt += 1
    return cnt
q("C13-C-031", TOPIC, "Ways to climb 12 steps in moves of 1 or 3 via a(n) = a(n-1) + a(n-3)", "Difficult",
  "Casework/optimisation",
  r"Kabir climbs a staircase of $12$ steps, starting at the bottom. Each move takes him up either exactly $1$ step or exactly $3$ steps, and he finishes exactly on the $12$th step. Two climbs are different if their sequences of moves are different. In how many different ways can he climb the staircase?",
  "TITA",
  r"Let $w_n$ be the number of ways to reach step $n$. The last move is $1$ or $3$, so $w_n = w_{n-1} + w_{n-3}$ with $w_0 = w_1 = w_2 = 1$. Then $w_3 = 2, w_4 = 3, w_5 = 4, w_6 = 6, w_7 = 9, w_8 = 13, w_9 = 19, w_{10} = 28, w_{11} = 41, w_{12} = 60$. (Check by cases on the number $j$ of $3$-step moves: $\binom{12}{0} + \binom{10}{1} + \binom{8}{2} + \binom{6}{3} + \binom{4}{4} = 1 + 10 + 28 + 20 + 1 = 60$.)",
  "Counting only how many $3$-step moves are used, ignoring order, or starting the recurrence with wrong initial values.",
  "C13C-step-recurrence", "Setting up a three-term recurrence (or the arrangement casework) and running it to $12$ without slips.",
  tita_answer=60, check=_c031, values=[60],
  tita_traps=[(5, "Counts only the possible numbers of $3$-step moves ($0$ to $4$), ignoring their order."),
              (41, "Stops the recurrence one step early, at $w_{11}$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 032
def _c032():
    groups, nxt = [], 1
    for g in range(1, 26):
        groups.append(list(range(nxt, nxt + g)))
        nxt += g
    return groups[24][0]
q("C13-C-032", TOPIC, "First number of the 25th group when natural numbers are grouped 1, 2, 3, ... at a time", "Easy",
  "Single-step computation",
  r"The natural numbers are written in groups: $(1), (2, 3), (4, 5, 6), (7, 8, 9, 10), \dots$, the $n$th group containing $n$ consecutive numbers. What is the first number in the $25$th group?",
  "MCQ",
  r"The first $24$ groups contain $1 + 2 + \dots + 24 = \frac{24 \times 25}{2} = 300$ numbers, ending with $300$. So the $25$th group starts at $301$.",
  "Reporting the last number of a group, or forgetting to add $1$.",
  "C13C-natural-number-groups", "One triangular-number count with an off-by-one trap.",
  correct=r"$301$",
  distractors=[(r"$325$", "Reports the last number of the $25$th group, $\\frac{25 \\times 26}{2}$."),
               (r"$300$", "Finds the last number of the $24$th group and forgets to add $1$."),
               (r"$277$", "Gives the first number of the $24$th group, $1 + \\frac{23 \\times 24}{2}$.")],
  check=_c032, values=[301, 325, 300, 277], cognitive="Application")

# ---------------------------------------------------------------- 033
def _c033():
    nxt, g = 1, 0
    while True:
        g += 1
        grp = [nxt + 2 * i for i in range(g)]
        nxt = grp[-1] + 2
        if 2025 in grp:
            return sum(grp)
q("C13-C-033", TOPIC, "Sum of the group of odd numbers containing 2025 (group sums are cubes)", "Difficult",
  "Conceptual/application",
  r"The odd natural numbers are written in groups: $(1), (3, 5), (7, 9, 11), (13, 15, 17, 19), \dots$, the $n$th group containing $n$ consecutive odd numbers. What is the sum of the numbers in the group that contains $2025$?",
  "MCQ",
  r"The $n$th group sums to $n^3$ (for example $3 + 5 = 8$, $7 + 9 + 11 = 27$), because its $n$ terms are centred on $n^2$. The number $2025$ is the $1013$th odd number. The first $44$ groups hold $\frac{44 \times 45}{2} = 990$ odd numbers and the first $45$ hold $1035$, so $2025$ lies in the $45$th group. Its sum is $45^3 = 91125$. (Indeed $2025 = 45^2$ is the middle term.)",
  "Placing $2025$ in the wrong group, or misplacing $2025$ within its group.",
  "C13C-odd-groups-cubes", "Two stages: locate the group via triangular numbers, then use the cube pattern of group sums.",
  correct=r"$91125$",
  distractors=[(r"$85184$", "Places $2025$ in the $44$th group, giving $44^3$."),
               (r"$97336$", "Places $2025$ in the $46$th group, giving $46^3$."),
               (r"$89145$", "Finds the $45$th group but assumes the $n$th group ends at $n^2$, so takes $2025$ as its last term: $45$ odd numbers from $1937$ to $2025$ sum to $45 \\times 1981$.")],
  check=_c033, values=[91125, 85184, 97336, 89145], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 034
def _c034():
    used, p = 0, 0
    while used < 1089:
        p += 1
        used += len(str(p))
    assert used == 1089
    return p
q("C13-C-034", TOPIC, "Number of pages from the total count of digits used in page numbering", "Easy",
  "Inverse/parameter",
  r"The pages of a book are numbered $1, 2, 3, \dots$ up to the last page, and exactly $1089$ digits are used in printing all the page numbers. How many pages does the book have?",
  "TITA",
  r"Pages $1$ to $9$ use $9$ digits and pages $10$ to $99$ use $90 \times 2 = 180$ digits, $189$ in all. The remaining $1089 - 189 = 900$ digits cover $300$ three-digit page numbers, $100$ to $399$. The book has $399$ pages.",
  "Adding the $300$ three-digit pages to $100$ instead of $99$, or dividing all digits by $3$.",
  "C13C-digit-counting", "One block-by-block count with a common off-by-one.",
  tita_answer=399, check=_c034, values=[399],
  tita_traps=[(400, "Starts the three-digit pages at $100$ and adds $300$ to get $400$."),
              (363, "Divides all $1089$ digits by $3$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 035
def _c035():
    s, k = "", 0
    while len(s) < 2026:
        k += 1
        s += str(k)
    return s[:2026].count("0")
q("C13-C-035", TOPIC, "Number of zeros among the first 2026 digits of the string 123456789101112...", "Difficult",
  "Multi-step word problem",
  r"Sneha writes the natural numbers in order, one after another without spaces: $123456789101112131415\dots$ She stops as soon as she has written $2026$ digits in all. How many times has she written the digit $0$?",
  "TITA",
  r"The numbers $1$ to $9$ use $9$ digits and $10$ to $99$ use $180$, so $189$ digits are used up to $99$. Then $2026 - 189 = 1837 = 3 \times 612 + 1$, so she writes $100$ to $711$ in full and only the digit $7$ of $712$. Zeros in $10$ to $99$: the units digits of $10, 20, \dots, 90$, which is $9$. In $100$ to $699$, each hundred has $10$ numbers with tens digit $0$ and $10$ with units digit $0$, so $20 \times 6 = 120$ zeros. In $700$ to $711$: tens digit $0$ in $700$ to $709$ gives $10$, units digit $0$ in $700$ and $710$ gives $2$. The total is $9 + 120 + 12 = 141$.",
  "Counting numbers that contain a zero instead of zero digits, or forgetting the zeros among the two-digit numbers.",
  "C13C-digit-counting", "Two stages: locate the stopping point through the digit blocks and a remainder, then count zero digits by place value across full and partial hundreds, where numbers like $100$ and $700$ carry two zeros.",
  tita_answer=141, check=_c035, values=[141],
  tita_traps=[(134, "Counts the numbers containing a zero ($9 + 6 \\times 19 + 11$) instead of the zero digits, so $100, 200, \\dots, 700$ are counted once each."),
              (132, "Counts only the three-digit numbers and forgets the zeros of $10, 20, \\dots, 90$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    seq = []
    k = 0
    while len(seq) < 100:
        k += 1
        seq.extend([k] * k)
    return seq[99]
q("C13-C-036", TOPIC, "100th term of 1, 2, 2, 3, 3, 3, ... where k appears k times", "Easy",
  "Single-step computation",
  r"In the sequence $1, 2, 2, 3, 3, 3, 4, 4, 4, 4, \dots$, each natural number $k$ appears exactly $k$ times in a row. The $100$th term of the sequence is",
  "MCQ",
  r"The last appearance of $k$ is at position $\frac{k(k+1)}{2}$. Since $\frac{13 \times 14}{2} = 91 < 100 \le 105 = \frac{14 \times 15}{2}$, positions $92$ to $105$ hold $14$. The $100$th term is $14$.",
  "Taking the largest $k$ with $\\frac{k(k+1)}{2} \\le 100$, or using $\\sqrt{100}$.",
  "C13C-block-sequence", "One triangular-number bracket.",
  correct=r"$14$",
  distractors=[(r"$13$", "Takes the largest $k$ with $\\frac{k(k+1)}{2} \\le 100$, which marks where $13$ ends, not the block containing position $100$."),
               (r"$15$", "Approximates $\\frac{k^2}{2} \\ge 100$, gets $k \\ge 14.1$ and rounds up to $15$."),
               (r"$10$", "Uses $\\sqrt{100}$, treating $k$ as appearing about $k^2$ positions in.")],
  check=_c036, values=[14, 13, 15, 10], cognitive="Application")

# ---------------------------------------------------------------- 037
def _c037():
    seq = []
    k = 0
    while len(seq) < 100:
        k += 1
        seq.extend([k] * k)
    return sum(seq[:100])
q("C13-C-037", TOPIC, "Sum of the first 100 terms of 1, 2, 2, 3, 3, 3, ... via sum of squares", "Medium",
  "Multi-step word problem",
  r"In the sequence $1, 2, 2, 3, 3, 3, 4, 4, 4, 4, \dots$, each natural number $k$ appears exactly $k$ times in a row. What is the sum of the first $100$ terms of the sequence?",
  "TITA",
  r"The complete blocks for $k = 1$ to $13$ fill $\frac{13 \times 14}{2} = 91$ positions and contribute $1^2 + 2^2 + \dots + 13^2 = \frac{13 \times 14 \times 27}{6} = 819$. The remaining $9$ positions all hold $14$, adding $126$. The sum is $819 + 126 = 945$.",
  "Including the whole block of $14$s, or forgetting the partial block.",
  "C13C-block-sequence", "Combines locating the partial block with recognising each full block as $k^2$.",
  tita_answer=945, check=_c037, values=[945],
  tita_traps=[(1015, "Includes the full block of fourteen $14$s: $1^2 + \\dots + 14^2$."),
              (819, "Stops at $91$ terms and omits the nine $14$s.")],
  cognitive="Application")

# ---------------------------------------------------------------- 038
def _c038():
    return sum(i * j for i in range(1, 13) for j in range(1, 13))
q("C13-C-038", TOPIC, "Sum of all entries of a 12 by 12 multiplication table as a square of a sum", "Easy",
  "Conceptual/application",
  r"A $12 \times 12$ table has the number $i \times j$ written in row $i$ and column $j$, for $1 \le i \le 12$ and $1 \le j \le 12$. What is the sum of all $144$ numbers in the table?",
  "MCQ",
  r"Row $i$ sums to $i(1 + 2 + \dots + 12) = 78i$. Adding over the rows gives $78(1 + 2 + \dots + 12) = 78 \times 78 = 6084$.",
  "Adding only one row or only the diagonal, or halving for a supposed double count.",
  "C13C-multiplication-table", "One factorisation of a double sum into a product of two sums.",
  correct=r"$6084$",
  distractors=[(r"$936$", "Multiplies the first row sum $78$ by $12$ rows, as if every row were the first row."),
               (r"$650$", "Adds only the diagonal entries $1^2 + 2^2 + \\dots + 12^2$."),
               (r"$3042$", "Halves $6084$, believing each product is counted twice.")],
  check=_c038, values=[6084, 936, 650, 3042], cognitive="Understanding")

# ---------------------------------------------------------------- 039
def _c039():
    return sum(i * j for i in range(1, 13) for j in range(1, 13) if i < j and (i + j) % 2 == 1)
q("C13-C-039", TOPIC, "Sum of multiplication-table entries above the diagonal with an odd index sum", "Difficult",
  "Casework/optimisation",
  r"A $12 \times 12$ table has the number $i \times j$ written in row $i$ and column $j$, for $1 \le i \le 12$ and $1 \le j \le 12$. What is the sum of the numbers in the cells where $i < j$ and $i + j$ is odd?",
  "MCQ",
  r"$i + j$ is odd exactly when one index is odd and the other even. Every pair made of an odd number $u$ and an even number $v$ from $1$ to $12$ gives exactly one cell with $i < j$ (row $\min(u, v)$, column $\max(u, v)$), holding $uv$, and every required cell arises this way. So the sum is $\sum uv = (1 + 3 + \dots + 11)(2 + 4 + \dots + 12) = 36 \times 42 = 1512$.",
  "Covering only the cells with an odd row and an even column, or mishandling the mirror symmetry.",
  "C13C-multiplication-table", "The direct route is row-by-row casework with two parity orientations; the fast route needs the non-obvious one-to-one match between required cells and odd-even pairs, which turns the double sum into a product of two sums.",
  correct=r"$1512$",
  distractors=[(r"$3024$", "Sums all cells with $i + j$ odd, $2 \\times 36 \\times 42$, without restricting to $i < j$."),
               (r"$882$", "Assumes the row must be odd and the column even, missing cells such as row $2$, column $3$."),
               (r"$756$", "Halves $36 \\times 42$ again, wrongly believing each odd-even pair has been counted twice.")],
  check=_c039, values=[1512, 3024, 882, 756], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 040
def _c040():
    seats, inc, total = 3, 4, 0
    for _ in range(20):
        total += seats
        seats += inc
        inc += 2
    return total
q("C13-C-040", TOPIC, "Total of a sequence with constant second differences (n^2 + n + 1)", "Medium",
  "Multi-step word problem",
  r"An auditorium has $20$ rows. The first four rows have $3$, $7$, $13$ and $21$ seats, and the number of extra seats each row has over the row in front of it goes up by $2$ from one row to the next, so the increases are $4, 6, 8, \dots$. How many seats are there in all $20$ rows?",
  "TITA",
  r"Row $n$ has $3 + (4 + 6 + \dots + 2n) = 3 + (n(n+1) - 2) = n^2 + n + 1$ seats (check: $3, 7, 13, 21$). The total is $\sum_{n=1}^{20}(n^2 + n + 1) = 2870 + 210 + 20 = 3100$.",
  "Dropping the constant term of the general row count, or reporting only the last row.",
  "C13C-second-differences", "First find the quadratic general term from the differences, then sum squares, integers and constants.",
  tita_answer=3100, check=_c040, values=[3100],
  tita_traps=[(3080, "Uses $n^2 + n$ for row $n$, dropping the $+1$."),
              (421, "Reports the number of seats in the $20$th row only.")],
  cognitive="Application")
