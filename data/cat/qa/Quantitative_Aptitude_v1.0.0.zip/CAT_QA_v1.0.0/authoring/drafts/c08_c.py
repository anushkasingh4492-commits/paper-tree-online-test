import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

BS = "Boats and streams"
EW = "Escalators and moving walkways"
CX = ("CAT", "XAT")
F = Fraction


# ---------------------------------------------------------------- C08-C-001
def _c1():
    b, s = symbols('b s')
    sol = solve([Eq(b + s, Rational(36, 3)), Eq(b - s, Rational(20) / Rational(5, 2))], [b, s])
    return sol[s]
q("C08-C-001", BS, "Stream speed from one downstream and one upstream journey", "Easy",
  "Single-step computation",
  r"A boat covers $36$ km downstream in $3$ hours and $20$ km upstream in $2$ hours $30$ minutes. The speed of the boat in still water and the speed of the stream are both constant. What is the speed of the stream?",
  "MCQ",
  r"Downstream speed $= \frac{36}{3} = 12$ km/h and upstream speed $= \frac{20}{2.5} = 8$ km/h. The stream speed is half their difference: $\frac{12 - 8}{2} = 2$ km/h. (The still-water speed is half their sum, $10$ km/h.)",
  "Taking the full difference of downstream and upstream speeds as the stream speed.",
  "C08C-up-down-speeds", "Two direct speed computations and the half-difference rule.",
  correct=r"$2$ km/h",
  distractors=[(r"$4$ km/h", "Takes the full difference $12 - 8 = 4$ without halving."),
               (r"$10$ km/h", "Reports the still-water speed $\\frac{12 + 8}{2} = 10$."),
               (r"$12$ km/h", "Reports the downstream speed $\\frac{36}{3} = 12$.")],
  check=_c1, values=[2, 4, 10, 12], cognitive="Application")


# ---------------------------------------------------------------- C08-C-002
def _c2():
    b, s, d = 15, 3, 36
    return F(d, b + s) + F(d, b - s)
q("C08-C-002", BS, "Round-trip time with known boat and stream speeds", "Easy",
  "Multi-step word problem",
  r"A motorboat whose speed in still water is $15$ km/h travels $36$ km downstream from a jetty and then returns to the jetty. The river flows at a constant $3$ km/h and the turnaround takes no time. How long does the whole round trip take?",
  "MCQ",
  r"Downstream speed $= 18$ km/h, so the outward leg takes $\frac{36}{18} = 2$ hours. Upstream speed $= 12$ km/h, so the return takes $\frac{36}{12} = 3$ hours. Total $= 5$ hours. The stream does not cancel out: the slow leg lasts longer, so it costs more than the fast leg saves.",
  "Assuming the stream's help downstream exactly cancels its hindrance upstream.",
  "C08C-round-trip-time", "Two leg times added; the trap is believing the stream cancels.",
  correct=r"$5$ hours",
  distractors=[(r"$4$ hours $48$ minutes", "Ignores the stream: $\\frac{72}{15} = 4.8$ hours."),
               (r"$4$ hours", "Uses the downstream speed for both legs: $\\frac{72}{18} = 4$ hours."),
               (r"$6$ hours", "Uses the upstream speed for both legs: $\\frac{72}{12} = 6$ hours.")],
  check=_c2, values=[5, F(24, 5), 4, 6], cognitive="Application")


# ---------------------------------------------------------------- C08-C-003
def _c3():
    v, w = symbols('v w')
    sol = solve([Eq(v + w, Rational(1800, 3)), Eq(v - w, Rational(1800, 4))], [v, w])
    return sol[v]
q("C08-C-003", BS, "Aeroplane airspeed from tail-wind and head-wind flight times", "Easy",
  "Single-step computation",
  r"An aeroplane flies $1{,}800$ km from city P to city Q in $3$ hours with a steady tail wind, and flies back along the same route from Q to P in $4$ hours against the same wind. The wind speed and the aeroplane's speed in still air are both constant. What is the speed of the aeroplane in still air?",
  "MCQ",
  r"Ground speed with the wind $= \frac{1800}{3} = 600$ km/h and against the wind $= \frac{1800}{4} = 450$ km/h. The still-air speed is the mean of these two: $\frac{600 + 450}{2} = 525$ km/h (and the wind speed is $75$ km/h).",
  "Dividing the total distance by the total time, which gives the average ground speed, not the still-air speed.",
  "C08C-wind-ground-speeds", "One idea: still-air speed is the mean of the two ground speeds; one trap.",
  correct=r"$525$ km/h",
  distractors=[(r"$514\frac{2}{7}$ km/h", "Total distance over total time: $\\frac{3600}{7}$, the average ground speed."),
               (r"$600$ km/h", "Reports the ground speed with the tail wind."),
               (r"$75$ km/h", "Reports the wind speed $\\frac{600 - 450}{2}$.")],
  check=_c3, values=[525, F(3600, 7), 600, 75], cognitive="Application")


# ---------------------------------------------------------------- C08-C-004
def _c4():
    b, s = symbols('b s', positive=True)
    d = 6
    sol = solve([Eq(d / (b - s), 3), Eq(d / (b + s), 2)], [b, s], dict=True)[0]
    return sol[b] / sol[s]
q("C08-C-004", BS, "Ratio of still-water speed to stream speed from a time ratio", "Easy",
  "Conceptual/application",
  r"Joseph rows a certain distance upstream in $3$ hours and rows the same distance back downstream in $2$ hours. His rowing speed in still water and the speed of the current are constant. The ratio of his speed in still water to the speed of the current is",
  "MCQ",
  r"For a fixed distance, speed is inversely proportional to time, so downstream speed : upstream speed $= 3 : 2$. Write them as $3k$ and $2k$. Then still-water speed $= \frac{3k + 2k}{2} = 2.5k$ and current $= \frac{3k - 2k}{2} = 0.5k$, giving $5 : 1$.",
  "Stopping at the ratio of downstream to upstream speeds instead of converting to still-water and current speeds.",
  "C08C-time-ratio-speed-ratio", "One proportionality idea followed by the half-sum and half-difference.",
  correct=r"$5 : 1$",
  distractors=[(r"$3 : 2$", "Stops at downstream speed : upstream speed."),
               (r"$2 : 3$", "Uses the ratio of the times, downstream to upstream, as the required ratio."),
               (r"$1 : 5$", "Correct working but writes the ratio the wrong way round, current to still water.")],
  check=_c4, values=[5, F(3, 2), F(2, 3), F(1, 5)], cognitive="Understanding")


# ---------------------------------------------------------------- C08-C-005
def _c5():
    L = 120                      # any common multiple of 60 and 40
    esc, walk = F(L, 60), F(L, 40)
    return L / (esc + walk)
q("C08-C-005", EW, "Walking up a moving escalator from the standing time and the walking time", "Easy",
  "Single-step computation",
  r"Standing still on a moving up-escalator, Riya reaches the top in $60$ seconds. When the escalator is switched off, she walks up it in $40$ seconds. If she walks up at the same pace while the escalator is moving, how many seconds will she take to reach the top?",
  "TITA",
  r"Per second the escalator covers $\frac{1}{60}$ of the length and Riya covers $\frac{1}{40}$. Together they cover $\frac{1}{60} + \frac{1}{40} = \frac{5}{120} = \frac{1}{24}$ per second, so she takes $24$ seconds.",
  "Combining the two times directly (average or sum) instead of adding the rates.",
  "C08C-escalator-combined-rates", "One idea: add rates, not times.",
  tita_answer=24, check=_c5,
  tita_traps=[(50, "Averages the two times."), (20, "Subtracts the two times."), (100, "Adds the two times.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-006
def _c6():
    L, belt, walk = F(90), F(12, 10), F(18, 10)
    return L / walk - L / (walk + belt)
q("C08-C-006", EW, "Time saved by walking on an airport moving walkway", "Easy",
  "Multi-step word problem",
  r"An airport moving walkway is $90$ m long and moves at $1.2$ m/s. Kabir walks along it in its direction of motion at $1.8$ m/s relative to the walkway, which is also his normal walking speed on the floor. How much time does he save by walking on the walkway instead of walking the same $90$ m on the floor beside it?",
  "MCQ",
  r"On the walkway his ground speed is $1.8 + 1.2 = 3$ m/s, so he takes $\frac{90}{3} = 30$ s. On the floor he takes $\frac{90}{1.8} = 50$ s. He saves $50 - 30 = 20$ seconds.",
  "Comparing the wrong pair of scenarios (standing on the walkway, or reporting the walkway time itself).",
  "C08C-walkway-time-saved", "Two direct times and a difference; the trap is picking the wrong comparison.",
  correct=r"$20$ seconds",
  distractors=[(r"$30$ seconds", "Reports the time on the walkway, not the saving."),
               (r"$45$ seconds", "Compares standing still on the walkway ($75$ s) with walking on it ($30$ s)."),
               (r"$25$ seconds", "Compares standing on the walkway ($75$ s) with walking on the floor ($50$ s).")],
  check=_c6, values=[20, 30, 45, 25], cognitive="Application")


# ---------------------------------------------------------------- C08-C-007
def _c7():
    b, s, t0 = 10, 2, F(1, 4)
    boat = -(b - s) * t0           # upstream is negative
    hat = s * t0
    t = symbols('t', positive=True)
    tau = solve(Eq(boat + (b + s) * t, hat + s * t), t)[0]
    return tau * 60
q("C08-C-007", BS, "Hat dropped from a boat going upstream, recovered after turning back", "Medium",
  "Conceptual/application",
  r"Sneha is going upstream in a motorboat whose speed in still water is $10$ km/h, on a river flowing at $2$ km/h. Her hat falls into the water and floats away with the current. She notices $15$ minutes later, turns around instantly and goes downstream at the same still-water speed. How many minutes after turning around does she reach her hat?",
  "TITA",
  r"Work in the frame of the water, in which the hat is at rest and the boat always moves at $10$ km/h. The boat moves away from the hat for $15$ minutes, so it needs exactly $15$ minutes to come back. Check on land: in $15$ minutes the boat goes $2$ km upstream and the hat $0.5$ km downstream, a gap of $2.5$ km closed at $12 - 2 = 10$ km/h, which is $15$ minutes.",
  "Treating the hat as fixed at the point where it fell, or using the boat's downstream ground speed as the closing speed.",
  "C08C-floating-object-frame", "Needs the water-frame insight; the land-frame route must track the hat's drift in both phases and use a closing speed, and the tempting shortcuts give $12$ or $10$.",
  tita_answer=15, check=_c7,
  tita_traps=[(12, "Ignores the hat's drift before she notices: gap $2$ km closed at $10$ km/h."),
              (10, "Ignores the hat's drift entirely and uses the downstream speed: $\\frac{2}{12}$ hour.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C08-C-008
def _c8():
    b, s = 4, 2
    dist = (b - s) * F(1, 2)
    return dist / (b + s) * 60
q("C08-C-008", BS, "Swimmer's return time after swimming upstream for a fixed time", "Easy",
  "Multi-step word problem",
  r"Fatima can swim at $4$ km/h in still water. In a river flowing at a constant $2$ km/h, she swims upstream from a jetty for $30$ minutes, then turns and swims back to the jetty at the same effort. How long does the return swim take?",
  "MCQ",
  r"Upstream speed $= 4 - 2 = 2$ km/h, so in $30$ minutes she covers $1$ km. Downstream speed $= 4 + 2 = 6$ km/h, so the return takes $\frac{1}{6}$ hour $= 10$ minutes.",
  "Assuming the return takes as long as the outward swim.",
  "C08C-swimmer-along-river", "Two short steps: distance from the upstream leg, time for the downstream leg.",
  correct=r"$10$ minutes",
  distractors=[(r"$30$ minutes", "Assumes the return swim takes as long as the outward swim."),
               (r"$15$ minutes", "Ignores the current on the return: $1$ km at $4$ km/h."),
               (r"$20$ minutes", "Uses the still-water speed for the outward leg: $2$ km at $6$ km/h.")],
  check=_c8, values=[10, 30, 15, 20], cognitive="Application")


# ---------------------------------------------------------------- C08-C-009
def _c9():
    air, wind, d = 450, 50, 2000
    return (F(d, air - wind) - F(d, air + wind)) * 60
q("C08-C-009", BS, "Difference between head-wind and tail-wind flight times", "Easy",
  "Multi-step word problem",
  r"An aeroplane with a speed of $450$ km/h in still air flies $2{,}000$ km from city P to city Q and then back along the same route. Throughout, a steady wind blows at $50$ km/h from Q towards P. How many minutes longer does the flight from P to Q take than the flight from Q to P?",
  "TITA",
  r"From P to Q the plane flies into the wind at $450 - 50 = 400$ km/h, taking $\frac{2000}{400} = 5$ hours. From Q to P it flies with the wind at $500$ km/h, taking $4$ hours. The difference is $1$ hour $= 60$ minutes.",
  "Believing the wind's help and hindrance cancel, so both legs take equal time.",
  "C08C-wind-leg-times", "Two direct times; the only trap is the direction of the wind.",
  tita_answer=60, check=_c9,
  tita_traps=[(0, "Assumes the wind effects cancel so the legs take equal time."),
              (540, "Reports the total flying time of $9$ hours in minutes.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-010
def _c10():
    N, esc, walk = 60, 1, 2
    t = F(N, esc + walk)
    return walk * t
q("C08-C-010", EW, "Steps actually taken while walking up a moving escalator", "Easy",
  "Single-step computation",
  r"An up-escalator has $60$ steps visible at any time and moves up at $1$ step per second. Ananya walks up it at a steady $2$ steps per second (steps she herself climbs). How many steps does she take before reaching the top?",
  "MCQ",
  r"Her rate relative to the ground is $2 + 1 = 3$ steps per second, so she needs $\frac{60}{3} = 20$ seconds. In $20$ seconds she takes $2 \times 20 = 40$ steps; the escalator supplies the other $20$.",
  "Assuming she must climb every visible step herself.",
  "C08C-escalator-steps-count", "One combined rate and one multiplication.",
  correct=r"$40$",
  distractors=[(r"$60$", "Assumes she climbs all $60$ visible steps herself."),
               (r"$20$", "Reports the escalator's share, or the time in seconds."),
               (r"$30$", "Splits the $60$ steps equally between her and the escalator.")],
  check=_c10, values=[40, 60, 20, 30], cognitive="Application")


# ---------------------------------------------------------------- C08-C-011
def _c11():
    s = 6
    t = symbols('t', positive=True)
    x1 = (12 + s) * t                # boat from P, downstream
    x2 = 60 - (18 - s) * t           # boat from Q, upstream
    return solve(Eq(x1, x2), t)[0] * 60
q("C08-C-011", BS, "Two boats approaching each other on a river", "Easy",
  "Conceptual/application",
  r"Towns P and Q lie on the same bank of a river, $60$ km apart, with Q downstream of P. The river flows at $6$ km/h. A boat with still-water speed $12$ km/h leaves P for Q and, at the same moment, a boat with still-water speed $18$ km/h leaves Q for P. After how many minutes do the boats meet?",
  "TITA",
  r"The boat from P moves at $12 + 6 = 18$ km/h and the boat from Q at $18 - 6 = 12$ km/h, so they close at $30$ km/h; the stream adds to one and subtracts from the other, so the closing speed is just $12 + 18$. Time $= \frac{60}{30} = 2$ hours $= 120$ minutes.",
  "Adding or subtracting the stream speed in the closing speed.",
  "C08C-two-boats-towards", "One insight: the stream cancels in the closing speed.",
  tita_answer=120, check=_c11,
  tita_traps=[(100, "Adds the stream once to the closing speed: $\\frac{60}{36}$ hour."),
              (150, "Subtracts the stream once from the closing speed: $\\frac{60}{24}$ hour.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- C08-C-012
def _c12():
    L = 90
    esc, walk = F(L, 45), F(L, 30)
    return L / (walk - esc)
q("C08-C-012", EW, "Walking down an up-moving escalator", "Easy",
  "Single-step computation",
  r"Standing still on a moving up-escalator, Ananya reaches the top in $45$ seconds. When the escalator is switched off, she can walk up or down it in $30$ seconds. One day, for fun, she walks down the moving up-escalator from top to bottom at that same pace. How long does she take?",
  "MCQ",
  r"Per second she covers $\frac{1}{30}$ of the length and the escalator carries her back $\frac{1}{45}$. Net progress is $\frac{1}{30} - \frac{1}{45} = \frac{1}{90}$ per second, so she takes $90$ seconds.",
  "Subtracting the times instead of subtracting the rates.",
  "C08C-escalator-combined-rates", "One subtraction of rates; one trap.",
  correct=r"$90$ seconds",
  distractors=[(r"$15$ seconds", "Subtracts the times: $45 - 30$."),
               (r"$75$ seconds", "Adds the times: $45 + 30$."),
               (r"$18$ seconds", "Adds the rates, which is her time walking up the moving escalator.")],
  check=_c12, values=[90, 15, 75, 18], cognitive="Application")


# ---------------------------------------------------------------- C08-C-013
def _c13():
    s = symbols('s', positive=True)
    sol = [r for r in solve(Eq(36 / (9 - s) - 36 / (9 + s), 3), s) if r < 9]
    return sol[0]
q("C08-C-013", BS, "Stream speed from the difference between upstream and downstream times", "Medium",
  "Inverse/parameter",
  r"A boat whose speed in still water is $9$ km/h takes $3$ hours longer to travel $36$ km upstream than to travel $36$ km downstream on the same river. Assuming the stream flows at a constant speed, what is the speed of the stream?",
  "MCQ",
  r"Let the stream speed be $s$. Then $\frac{36}{9 - s} - \frac{36}{9 + s} = 3$, so $\frac{72s}{81 - s^2} = 3$, giving $s^2 + 24s - 81 = 0 = (s - 3)(s + 27)$. Hence $s = 3$ km/h. Check: $\frac{36}{6} - \frac{36}{12} = 6 - 3 = 3$ hours.",
  "Comparing the upstream time with the still-water time instead of the downstream time.",
  "C08C-up-down-speeds", "Sets up a rational equation and solves a quadratic.",
  correct=r"$3$ km/h",
  distractors=[(r"$6$ km/h", "Reports the upstream speed $9 - 3$."),
               (r"$\frac{27}{7}$ km/h", "Compares upstream with still water: $\\frac{36}{9 - s} - \\frac{36}{9} = 3$ gives $s = \\frac{27}{7}$."),
               (r"$12$ km/h", "Reports the downstream speed $9 + 3$.")],
  check=_c13, values=[3, 6, F(27, 7), 12], cognitive="Application")


# ---------------------------------------------------------------- C08-C-014
def _c14():
    d = symbols('d', positive=True)
    return solve(Eq(d / 12 + d / 8, 5), d)[0]
q("C08-C-014", BS, "One-way distance from total round-trip time", "Easy",
  "Inverse/parameter",
  r"A motorboat whose speed in still water is $10$ km/h goes from a jetty upstream to a temple on the riverbank and comes straight back to the jetty. The river flows at a constant $2$ km/h, and the total travel time is $5$ hours. How far, in km, is the temple from the jetty?",
  "TITA",
  r"Upstream speed $8$ km/h and downstream speed $12$ km/h. With distance $d$: $\frac{d}{8} + \frac{d}{12} = 5$, so $\frac{5d}{24} = 5$ and $d = 24$ km.",
  "Using a single speed for both legs.",
  "C08C-round-trip-time", "Two direct speeds and one linear equation; the only trap is using a single speed for both legs.",
  tita_answer=24, check=_c14,
  tita_traps=[(25, "Ignores the stream: $\\frac{2d}{10} = 5$."),
              (30, "Uses the downstream speed for both legs."),
              (20, "Uses the upstream speed for both legs.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-015
def _c15():
    b, D = symbols('b D', positive=True)
    s = 5
    sol = solve([Eq(b + s, D), Eq(b - s, Rational(3, 5) * D)], [b, D], dict=True)[0]
    return Rational(48) / sol[b] * 60
q("C08-C-015", BS, "Still-water travel time when upstream speed is a percentage of downstream speed", "Medium",
  "Multi-step word problem",
  r"A motorboat's upstream speed on a river is $60\%$ of its downstream speed on the same river. The river flows at $5$ km/h, and the boat's speed in still water is constant. How long would the boat take to cover $48$ km on a lake with no current?",
  "MCQ",
  r"Let the downstream speed be $D$; the upstream speed is $0.6D$. Their difference is twice the stream speed: $0.4D = 10$, so $D = 25$ km/h and the still-water speed is $25 - 5 = 20$ km/h. Time $= \frac{48}{20}$ hours $= 2.4$ hours $= 144$ minutes.",
  "Taking the stream speed itself, rather than twice it, as the gap between downstream and upstream speeds.",
  "C08C-time-ratio-speed-ratio", "Percentage relation turned into speeds, then a time conversion.",
  correct=r"$144$ minutes",
  distractors=[(r"$115.2$ minutes", "Uses the downstream speed $25$ km/h for the lake: $\\frac{48}{25}$ hours."),
               (r"$192$ minutes", "Uses the upstream speed $15$ km/h for the lake: $\\frac{48}{15}$ hours."),
               (r"$384$ minutes", "Sets $0.4D = 5$, so $D = 12.5$ and still-water speed $7.5$ km/h: $\\frac{48}{7.5}$ hours.")],
  check=_c15, values=[144, F(576, 5), 192, 384], cognitive="Application")


# ---------------------------------------------------------------- C08-C-016
def _c16():
    T = lambda s: F(24, 7 - s) + F(24, 7 + s)
    return T(5) - T(1)
q("C08-C-016", BS, "Effect of a faster stream on round-trip time", "Medium",
  "Multi-step word problem",
  r"A ferry with a speed of $7$ km/h in still water runs from a ghat $24$ km upstream to a village and straight back. Usually the river flows at $1$ km/h; after heavy rain it flows at $5$ km/h, the ferry's still-water speed being unchanged. By how many hours does the round trip time increase after the rain?",
  "TITA",
  r"Usually: $\frac{24}{6} + \frac{24}{8} = 4 + 3 = 7$ hours. After the rain: $\frac{24}{2} + \frac{24}{12} = 12 + 2 = 14$ hours. The increase is $14 - 7 = 7$ hours. The faster stream saves only $1$ hour downstream but costs $8$ hours upstream.",
  "Assuming the gain downstream offsets the loss upstream.",
  "C08C-stream-speed-change", "Two round-trip computations; the trap is the cancellation intuition.",
  tita_answer=7, check=_c16,
  tita_traps=[(0, "Assumes the stream's help and hindrance cancel."),
              (14, "Reports the new round-trip time."),
              (8, "Accounts only for the slower upstream leg.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-017
def _c17():
    b, s, D = 12, 3, 60
    pos, t = F(0), F(0)
    pos += (b + s) * 2; t += 2          # 2 h under power
    pos += s * 1; t += 1                # 1 h drifting
    t += (D - pos) / (b + s)
    return t
q("C08-C-017", BS, "Engine failure on a downstream journey, boat drifts with the current", "Medium",
  "Multi-step word problem",
  r"Town Q is $60$ km downstream of town P. A launch with still-water speed $12$ km/h leaves P for Q on a river flowing at $3$ km/h. After $2$ hours its engine fails, and for the next $1$ hour, while it is repaired, the launch drifts with the current. It then continues to Q at its usual still-water speed. How long does the whole journey from P to Q take?",
  "MCQ",
  r"In the first $2$ hours the launch covers $2 \times 15 = 30$ km. Drifting for $1$ hour at the stream speed adds $3$ km, so it is $33$ km from P. The remaining $27$ km at $15$ km/h takes $1.8$ hours $= 1$ hour $48$ minutes. Total $= 2 + 1 + 1.8 = 4.8$ hours $= 4$ hours $48$ minutes.",
  "Treating the drifting launch as stationary.",
  "C08C-engine-failure-drift", "Three stages, with the drift stage needing care.",
  correct=r"$4$ hours $48$ minutes",
  distractors=[(r"$5$ hours", "Treats the launch as stationary while drifting: $2 + 1 + \\frac{30}{15}$."),
               (r"$3$ hours $48$ minutes", "Counts the $3$ km drifted but leaves out the $1$ hour of drifting."),
               (r"$5$ hours $15$ minutes", "Uses the still-water speed $12$ km/h for the last $27$ km.")],
  check=_c17, values=[F(24, 5), 5, F(19, 5), F(21, 4)], cognitive="Application")


# ---------------------------------------------------------------- C08-C-018
def _c18():
    b, s, D = 9, 3, 34
    pos, t = F(0), F(0)                 # distance covered from Q towards P
    pos += (b - s) * 2; t += 2
    pos -= s * F(2, 3); t += F(2, 3)    # drifts back downstream for 40 min
    t += (D - pos) / (b - s)
    return t * 60
q("C08-C-018", BS, "Engine failure on an upstream journey, boat drifts back", "Medium",
  "Multi-step word problem",
  r"Village P is $34$ km upstream of village Q. A boat with still-water speed $9$ km/h leaves Q for P on a river flowing at $3$ km/h. After $2$ hours its engine stops, and for the next $40$ minutes the boat drifts with the current. The engine then restarts and the boat continues to P at its usual still-water speed. How long does the whole journey from Q to P take?",
  "MCQ",
  r"Upstream speed $= 6$ km/h, so in $2$ hours the boat covers $12$ km. Drifting downstream for $\frac{2}{3}$ hour at $3$ km/h takes it back $2$ km, to $10$ km from Q. The remaining $24$ km at $6$ km/h takes $4$ hours. Total $= 2$ hours $+ 40$ minutes $+ 4$ hours, that is $6$ hours $40$ minutes.",
  "Treating the drifting boat as stationary, or drifting in the wrong direction.",
  "C08C-engine-failure-drift", "Three stages; the drift moves the boat backwards.",
  correct=r"$6$ hours $40$ minutes",
  distractors=[(r"$6$ hours $20$ minutes", "Treats the boat as stationary while drifting: $22$ km left, taking $3$ hours $40$ minutes."),
               (r"$6$ hours", "Moves the boat $2$ km forward while drifting: $20$ km left, taking $3$ hours $20$ minutes."),
               (r"$7$ hours $40$ minutes", "Drifts at the downstream speed $12$ km/h, losing $8$ km: $30$ km left, taking $5$ hours.")],
  check=_c18, values=[400, 380, 360, 460], cognitive="Application")


# ---------------------------------------------------------------- C08-C-019
def _c19():
    out = set()
    for b in (8, 10, 15):
        s, t = symbols('s t', positive=True)
        t1 = Rational(3, 4)
        boat = -(b - s) * t1 + (b + s) * (t - t1)
        sol = solve([Eq(boat, s * t), Eq(s * t, 3)], [s, t], dict=True)
        out.add(sol[0][s])
    assert len(out) == 1
    return out.pop()
q("C08-C-019", BS, "Stream speed from where a boat recovers a log it passed", "Medium",
  "Inverse/parameter",
  r"A motorboat going upstream passes a log floating with the current just as both are at a bridge. $45$ minutes later the boat turns around instantly and, going downstream at the same still-water speed, catches up with the log $3$ km downstream of the bridge. Assuming the current is constant, what is the speed of the current in km/h?",
  "TITA",
  r"In the frame of the water the log is at rest and the boat moves away for $45$ minutes, so it needs $45$ more minutes to return. The log has therefore drifted for $1.5$ hours and covered $3$ km, so the current is $\frac{3}{1.5} = 2$ km/h. The boat's speed is not needed.",
  "Dividing the log's drift by the outward time only.",
  "C08C-floating-object-frame", "Needs the water-frame insight; the boat speed is deliberately not given.",
  tita_answer=2, check=_c19,
  tita_traps=[(4, "Divides $3$ km by $45$ minutes only.")],
  cognitive="Analysis")


# ---------------------------------------------------------------- C08-C-020
def _c20():
    b1, b2, s, t1 = 9, 15, 2, 1
    t = symbols('t', positive=True)
    kabir = (b1 + s) * t
    sneha = -(b2 - s) * t1 + (b2 + s) * (t - t1)
    return solve(Eq(kabir, sneha), t)[0] - t1
q("C08-C-020", BS, "Chasing on a river after turning back, in the frame of the water", "Difficult",
  "Conceptual/application",
  r"Kabir and Sneha leave the same jetty at the same moment in two boats: Kabir goes downstream at a still-water speed of $9$ km/h and Sneha goes upstream at a still-water speed of $15$ km/h. The river flows at $2$ km/h. After $1$ hour Sneha turns around instantly and chases Kabir downstream at the same still-water speed. How long after turning around does she catch him?",
  "MCQ",
  r"In the frame of the water both boats move at their still-water speeds. After $1$ hour they are $9 + 15 = 24$ km apart, and Sneha closes the gap at $15 - 9 = 6$ km/h, taking $4$ hours. Check on land: Kabir at $11 \times 5 = 55$ km; Sneha at $-13 + 17 \times 4 = 55$ km.",
  "Giving only the chaser the stream's help when computing the closing speed.",
  "C08C-boats-chase-water-frame", "Two boats, a turn and a chase with four different ground speeds; the land-frame route needs a full timeline, and the clean route needs the non-obvious switch to the frame of the water.",
  correct=r"$4$ hours",
  distractors=[(r"$3$ hours", "Adds the stream only to Sneha: closing speed $(15 + 2) - 9 = 8$ km/h."),
               (r"$5$ hours", "Reports the time from the start rather than from the turn."),
               (r"$1$ hour", "Adds the still-water speeds, $24$ km/h, as the closing speed.")],
  check=_c20, values=[4, 3, 5, 1], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-021
def _c21():
    w = symbols('w', positive=True)
    return [r for r in solve(Eq(1200 / (500 + w) + 1200 / (500 - w), 5), w) if r < 500][0]
q("C08-C-021", BS, "Wind speed from the round-trip time of an aeroplane", "Medium",
  "Inverse/parameter",
  r"An aeroplane with a speed of $500$ km/h in still air flies $1{,}200$ km from P to Q and straight back along the same route. A steady wind blows along the route throughout, and the round trip takes $5$ hours of flying. What is the speed of the wind?",
  "MCQ",
  r"With wind speed $w$: $\frac{1200}{500 + w} + \frac{1200}{500 - w} = 5$, so $\frac{1200 \times 1000}{250000 - w^2} = 5$, giving $250000 - w^2 = 240000$ and $w = 100$ km/h. Check: $\frac{1200}{600} + \frac{1200}{400} = 2 + 3 = 5$ hours.",
  "Taking the average ground speed of the round trip as one of the one-way ground speeds.",
  "C08C-wind-round-trip", "Rational equation reducing to a difference of squares.",
  correct=r"$100$ km/h",
  distractors=[(r"$20$ km/h", "Average ground speed $\\frac{2400}{5} = 480$ km/h, then $500 - 480 = 20$."),
               (r"$400$ km/h", "Reports the ground speed against the wind."),
               (r"$600$ km/h", "Reports the ground speed with the wind.")],
  check=_c21, values=[100, 20, 400, 600], cognitive="Application")


# ---------------------------------------------------------------- C08-C-022
def _c22():
    N, e = symbols('N e', positive=True)
    v = 1                                   # Ravi's step rate
    sol = solve([Eq(N, 20 + e * F(20, v)), Eq(N, 30 + e * F(30, 2 * v))], [N, e], dict=True)[0]
    return sol[N]
q("C08-C-022", EW, "Visible steps on an up-escalator from two walkers' step counts", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera each walk up a moving up-escalator. Meera takes steps at twice Ravi's rate, and each keeps a constant rate. Ravi takes $20$ steps to reach the top and Meera takes $30$ steps. How many steps of the escalator are visible when it is switched off?",
  "TITA",
  r"Let Ravi take $1$ step per unit time and let the escalator move $e$ steps per unit time. Ravi needs $20$ units, so $N = 20 + 20e$. Meera needs $\frac{30}{2} = 15$ units, so $N = 30 + 15e$. Equating, $5e = 10$, $e = 2$, and $N = 20 + 40 = 60$.",
  "Combining the two step counts directly instead of accounting for the escalator's contribution in each person's time.",
  "C08C-escalator-two-people-steps", "Two equations in two unknowns from rates and step counts.",
  tita_answer=60, check=_c22,
  tita_traps=[(50, "Adds the two step counts."), (25, "Averages the two step counts.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-023
def _c23():
    N, e = symbols('N e', positive=True)
    sol = solve([Eq(N, 30 + 30 * e), Eq(N, 90 - 90 * e)], [N, e], dict=True)[0]
    return sol[N]
q("C08-C-023", EW, "Visible steps from walking down and then up the same down-escalator", "Difficult",
  "Multi-step word problem",
  r"Arjun walks down a moving down-escalator and takes $30$ steps to reach the bottom. He then walks up the same down-escalator, taking steps at the same rate as before, and takes $90$ steps to reach the top. How many steps are visible on the escalator when it is stopped?",
  "MCQ",
  r"Let Arjun take $1$ step per unit time and the escalator move $e$ steps per unit time. Going down: $N = 30 + 30e$. Going up: $N = 90 - 90e$. So $120e = 60$, $e = \frac{1}{2}$ and $N = 30 + 15 = 45$.",
  "Assuming the escalator contributes the same number of steps on both trips, although the trips take different times.",
  "C08C-escalator-up-down-same-person", "Two regimes with opposite signs and unequal durations must be modelled with an unknown escalator rate; the natural equal-contribution set-up gives a wrong answer that is among the options.",
  correct=r"$45$",
  distractors=[(r"$60$", "Assumes the escalator moves the same number of steps on both trips: $30 + x = 90 - x$."),
               (r"$75$", "Swaps the durations: $30 + 90e = 90 - 30e$ gives $e = \\frac{1}{2}$ and $N = 75$."),
               (r"$120$", "Adds the two step counts.")],
  check=_c23, values=[45, 60, 75, 120], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-024
def _c24():
    L = 120
    esc, walk = F(L, 40), F(L, 60)
    half = F(L, 2)
    return half / (esc + walk) + half / walk
q("C08-C-024", EW, "Escalator stops midway while a person walks up", "Medium",
  "Multi-step word problem",
  r"Standing still on a moving up-escalator, Joseph reaches the top in $40$ seconds; walking up it when it is switched off, he takes $60$ seconds. One day he walks up the moving escalator at his usual pace, and exactly when he is halfway up, the escalator stops. He continues walking at the same pace. How long does he take in all to reach the top?",
  "MCQ",
  r"While moving together, he covers $\frac{1}{40} + \frac{1}{60} = \frac{1}{24}$ of the length per second, so the first half takes $12$ seconds. The second half at walking pace alone takes $\frac{60}{2} = 30$ seconds. Total $= 42$ seconds.",
  "Using a single rate for the whole climb.",
  "C08C-escalator-stops-midway", "Two stages with different combined rates.",
  correct=r"$42$ seconds",
  distractors=[(r"$24$ seconds", "Uses the combined rate for the whole climb, as if the escalator never stopped."),
               (r"$50$ seconds", "Takes the first half at the standing rate: $20 + 30$."),
               (r"$60$ seconds", "Uses the walking rate alone for the whole climb.")],
  check=_c24, values=[42, 24, 50, 60], cognitive="Application")


# ---------------------------------------------------------------- C08-C-025
def _c25():
    w, e = symbols('w e', positive=True)
    sol = solve([Eq(w + e, Rational(120, 30)), Eq(w - e, Rational(120, 120))], [w, e], dict=True)[0]
    return Rational(120) / sol[e]
q("C08-C-025", EW, "Standing time on a moving walkway from with and against walking times", "Medium",
  "Inverse/parameter",
  r"A moving walkway at an airport is $120$ m long. Priya walks along it in its direction of motion and reaches the end in $30$ seconds. She then walks back along the same walkway, against its motion, at the same pace relative to the walkway, and takes $120$ seconds. How many seconds would she take to travel its length standing still on the walkway?",
  "TITA",
  r"With the walkway her ground speed is $\frac{120}{30} = 4$ m/s; against it, $\frac{120}{120} = 1$ m/s. The walkway speed is half the difference: $1.5$ m/s. Standing still she takes $\frac{120}{1.5} = 80$ seconds.",
  "Averaging the two times, or computing her floor walking time instead.",
  "C08C-walkway-with-against", "Half-difference rule applied to a walkway, then a time.",
  tita_answer=80, check=_c25,
  tita_traps=[(75, "Averages $30$ and $120$ seconds."),
              (48, "Uses her own walking speed $2.5$ m/s: her time walking on the floor.")],
  cognitive="Application")


# ---------------------------------------------------------------- C08-C-026
def _c26():
    b, s = symbols('b s', positive=True)
    sol = solve([Eq((b + s) * Rational(1, 3), (b - s) * Rational(1, 2)), Eq(s, Rational(3, 2))], [b, s], dict=True)[0]
    return (sol[b] + sol[s]) * Rational(1, 3)
q("C08-C-026", BS, "Distance from times of a down-and-back kayak trip", "Medium",
  "Multi-step word problem",
  r"Harpreet paddles a kayak downstream from a jetty for $20$ minutes, then turns and paddles back upstream at the same effort, reaching the jetty $30$ minutes after turning. The river flows at a constant $1.5$ km/h. How far downstream of the jetty did she turn?",
  "MCQ",
  r"The same distance takes $20$ and $30$ minutes, so downstream : upstream speed $= 3 : 2$. Writing them as $3k$ and $2k$, the stream is $\frac{k}{2} = 1.5$, so $k = 3$: downstream $9$ km/h, upstream $6$ km/h. The turning point is $9 \times \frac{1}{3} = 3$ km downstream.",
  "Using the still-water speed, or the wrong time, for the outward leg.",
  "C08C-down-and-back-time-split", "Time ratio to speed ratio, then a distance.",
  correct=r"$3$ km",
  distractors=[(r"$2.5$ km", "Uses the still-water speed $7.5$ km/h for the $20$ minutes."),
               (r"$2$ km", "Uses the upstream speed $6$ km/h for the $20$ minutes."),
               (r"$4.5$ km", "Uses the downstream speed $9$ km/h for the $30$ minutes.")],
  check=_c26, values=[3, F(5, 2), 2, F(9, 2)], cognitive="Application")


# ---------------------------------------------------------------- C08-C-027
def _c27():
    b, s = symbols('b s', positive=True)
    sol = solve([Eq(24 / (b - s) + 40 / (b + s), 8), Eq(18 / (b - s) + 60 / (b + s), 9)], [b, s], dict=True)
    sol = [x for x in sol if x[b] > x[s]]
    return sol[0][s]
q("C08-C-027", BS, "Boat and stream speeds from two combined journeys", "Medium",
  "Multi-step word problem",
  r"A boat goes $24$ km upstream and $40$ km downstream in a total of $8$ hours. On the same river it goes $18$ km upstream and $60$ km downstream in a total of $9$ hours. The boat's speed in still water and the stream speed are the same on both occasions. What is the speed of the stream?",
  "MCQ",
  r"Let $u = \frac{1}{\text{upstream speed}}$ and $d = \frac{1}{\text{downstream speed}}$. Then $24u + 40d = 8$ and $18u + 60d = 9$. Multiply the first by $3$ and the second by $4$: $72u + 120d = 24$ and $72u + 240d = 36$, so $d = \frac{1}{10}$ and $u = \frac{1}{6}$. Speeds are $10$ and $6$ km/h, so the stream is $\frac{10 - 6}{2} = 2$ km/h.",
  "Stopping at the difference of the two speeds, or reporting the still-water speed.",
  "C08C-two-trips-linear", "Substitution to a linear system, then the half-difference.",
  correct=r"$2$ km/h",
  distractors=[(r"$4$ km/h", "Takes the full difference $10 - 6$."),
               (r"$8$ km/h", "Reports the still-water speed $\\frac{10 + 6}{2}$."),
               (r"$6$ km/h", "Reports the upstream speed.")],
  check=_c27, values=[2, 4, 8, 6], cognitive="Application")


# ---------------------------------------------------------------- C08-C-028
def _c28():
    N, e, r, m, d = 100, F(1), F(1), F(2), F(15)
    t = d                             # time since Ravi stepped on; step in 1/4 s, exact
    while True:
        ravi = (r + e) * t
        meera = (m + e) * (t - d)
        if meera >= ravi:
            assert meera == ravi and ravi < N      # level exactly, before the top
            assert N / (r + e) > t                 # Ravi has not yet left the escalator
            return t - d
        t += F(1, 4)
q("C08-C-028", EW, "One walker catching another who started earlier on the same escalator", "Medium",
  "Conceptual/application",
  r"An up-escalator has $100$ visible steps and moves at $1$ step per second. Ravi steps on at the bottom and walks up at $1$ step per second relative to the escalator. Exactly $15$ seconds later Meera steps on at the bottom and walks up at $2$ steps per second relative to the escalator. Each keeps a constant pace until reaching the top. How many seconds after stepping on does Meera draw level with Ravi?",
  "MCQ",
  r"Ravi rises at $1 + 1 = 2$ steps per second, so when Meera steps on he is $2 \times 15 = 30$ steps above the bottom. The escalator carries both equally, so the gap closes at $2 - 1 = 1$ step per second and Meera draws level after $30$ seconds. Check: she is then $3 \times 30 = 90$ steps up, below the top at $100$, and Ravi, who needs $50$ seconds in all, has been on for only $45$ seconds, so they do draw level on the escalator.",
  "Measuring Ravi's lead by the steps he climbed himself, forgetting what the escalator carried him, or closing the gap at Meera's ground rate.",
  "C08C-escalator-overtake", "Two walking rates, a head start that includes the escalator's carry, relative rates on a shared moving medium, and a check that the meeting happens before the top.",
  correct=r"$30$ seconds",
  distractors=[(r"$15$ seconds", "Takes Ravi's lead as only the $15$ steps he climbed himself and closes it at $1$ step per second."),
               (r"$45$ seconds", "Measures the time from when Ravi stepped on: $15 + 30$."),
               (r"$10$ seconds", "Closes the $30$-step gap at Meera's ground rate of $3$ steps per second.")],
  check=_c28, values=[30, 15, 45, 10], cognitive="Understanding")


# ---------------------------------------------------------------- C08-C-029
def _c29():
    s = 3
    t = symbols('t', positive=True)
    # X: still 15, downstream for 3/4 h then back upstream
    tx = solve(Eq((15 + s) * Rational(3, 4) - (15 - s) * (t - Rational(3, 4)), s * t), t)[0]
    # Y: still 10, upstream for 1 h then back downstream
    ty = solve(Eq(-(10 - s) * 1 + (10 + s) * (t - 1), s * t), t)[0]
    return (ty - tx) * 60
q("C08-C-029", BS, "Two boats leaving a drifting raft and returning to it", "Medium",
  "Conceptual/application",
  r"Two boats leave a raft drifting in the middle of a river at the same moment. One, with still-water speed $15$ km/h, heads downstream; the other, with still-water speed $10$ km/h, heads upstream. The river flows at $3$ km/h. The first boat turns around after $45$ minutes and the second after $60$ minutes, and each returns to the raft at its own still-water speed. How many minutes after the first boat reaches the raft does the second boat reach it?",
  "TITA",
  r"Relative to the water the raft is at rest, so each boat takes as long to come back as it spent going away. The first boat is back after $90$ minutes and the second after $120$ minutes, a gap of $30$ minutes. The speeds of the boats and of the river do not matter.",
  "Taking only the difference between the turning times.",
  "C08C-raft-two-boats", "Recognising that the frame of the water makes all the given speeds irrelevant.",
  tita_answer=30, check=_c29,
  tita_traps=[(15, "Takes only the difference of the turning times."),
              (0, "Assumes both boats must reach the raft together.")],
  cognitive="Analysis")


# ---------------------------------------------------------------- C08-C-030
def _c30():
    s = symbols('s', positive=True)
    sv = solve(Eq(2 * (10 + s), 4 * (10 - 2 * s)), s)[0]
    return 2 * (10 + sv)
q("C08-C-030", BS, "Stream speed doubles before the return journey", "Medium",
  "Inverse/parameter",
  r"A boat with still-water speed $10$ km/h goes downstream from P to Q in $2$ hours. Before it sets out on the return journey the stream speed doubles, and the return from Q to P takes $4$ hours. Stream speeds are constant during each journey. What is the distance from P to Q?",
  "MCQ",
  r"Let the original stream speed be $s$. Then $2(10 + s) = 4(10 - 2s)$, so $20 + 2s = 40 - 8s$, $s = 2$ km/h. Distance $= 2 \times 12 = 24$ km (check: upstream at $10 - 4 = 6$ km/h for $4$ hours is $24$ km).",
  "Ignoring the change in stream speed, or applying it to the wrong leg.",
  "C08C-stream-speed-change", "One linear equation, but the changed stream must go on the right leg.",
  correct=r"$24$ km",
  distractors=[(r"$26\frac{2}{3}$ km", "Ignores the doubling: $2(10 + s) = 4(10 - s)$ gives $s = \\frac{10}{3}$."),
               (r"$30$ km", "Doubles the stream on the downstream leg: $2(10 + 2s) = 4(10 - s)$ gives $s = 2.5$, distance $30$."),
               (r"$20$ km", "Ignores the stream: $2 \\times 10$.")],
  check=_c30, values=[24, F(80, 3), 30, 20], cognitive="Application", exams=EXAMS)


# ---------------------------------------------------------------- C08-C-031
def _c31():
    N, e = symbols('N e', positive=True)
    v = 1
    sol = solve([Eq(N, 30 + e * F(30, v)), Eq(N, 150 - e * F(150, 3 * v))], [N, e], dict=True)[0]
    assert 3 * v > sol[e]
    return sol[N]
q("C08-C-031", EW, "Visible steps when one person walks with and another against an up-escalator", "Difficult",
  "Multi-step word problem",
  r"Ravi walks up a moving up-escalator and takes $30$ steps to reach the top. Sneha, starting at the top, walks down the same up-escalator against its motion, taking steps at $3$ times Ravi's rate, and takes $150$ steps to reach the bottom. Each walks at a constant rate. How many steps are visible on the escalator when it is stopped?",
  "TITA",
  r"Let Ravi take $1$ step per unit time and the escalator move $e$ steps per unit time. Ravi needs $30$ units: $N = 30 + 30e$. Sneha needs $\frac{150}{3} = 50$ units and is pushed back $50e$ steps: $N = 150 - 50e$. So $80e = 120$, $e = 1.5$, and $N = 30 + 45 = 75$.",
  "Combining the step counts directly, or giving both walkers the same duration.",
  "C08C-escalator-opposite-walkers", "Opposite directions, different step rates, unequal durations: two equations with sign care.",
  tita_answer=75, check=_c31,
  tita_traps=[(90, "Averages $30$ and $150$."), (120, "Takes the difference $150 - 30$.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-032
def _c32():
    D, s, b = F(60), F(2), F(10)
    # boat 1 starts at P (0) going down; boat 2 starts at Q (60) going up
    def legs(start, direction):
        out, t, x, d = [], F(0), start, direction
        for _ in range(4):
            v = (b + s) if d > 0 else (b - s)
            target = D if d > 0 else F(0)
            dt = abs(target - x) / v
            out.append((t, t + dt, x, d * v))
            t, x, d = t + dt, target, -d
        return out
    L1, L2 = legs(F(0), 1), legs(D, -1)
    meets = []
    for (a0, a1, ax, av) in L1:
        for (c0, c1, cx, cv) in L2:
            lo, hi = max(a0, c0), min(a1, c1)
            if lo >= hi or av == cv:
                continue
            t = (cx - cv * c0 - ax + av * a0) / (av - cv)
            if lo <= t <= hi:
                meets.append((t, ax + av * (t - a0)))
    meets = sorted(set(meets))
    return meets[1][1]
q("C08-C-032", BS, "Second meeting point of two boats shuttling on a river", "Difficult",
  "Casework/optimisation",
  r"Town Q is $60$ km downstream of town P on a river flowing at $2$ km/h. Two boats, each with still-water speed $10$ km/h, leave P and Q at the same moment heading towards each other. Each boat turns around instantly on reaching the other town and heads back. How far from P do the boats meet for the second time?",
  "MCQ",
  r"The boat from P goes downstream at $12$ km/h and the boat from Q upstream at $8$ km/h; they first meet after $3$ hours, $36$ km from P. The first boat reaches Q at $5$ h and returns upstream at $8$ km/h; the second reaches P at $7.5$ h, when the first is at $60 - 8 \times 2.5 = 40$ km from P. Now the second goes downstream at $12$ km/h, closing $40$ km at $20$ km/h in $2$ hours. They meet $12 \times 2 = 24$ km from P.",
  "Applying the constant-speed rule (second meeting after three times the first combined distance) although each boat's speed changes when it turns.",
  "C08C-two-boats-meet-twice", "Speeds change at each turn, so the timeline must be built leg by leg; the standard land shortcut fails.",
  correct=r"$24$ km",
  distractors=[(r"$12$ km", "Uses the constant-speed rule: first boat covers $3 \\times 36 = 108$ km, ending $12$ km from P."),
               (r"$30$ km", "Ignores the stream, so both boats are symmetric and meet at the midpoint again."),
               (r"$36$ km", "Reports the first meeting point.")],
  check=_c32, values=[24, 12, 30, 36], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-033
def _c33():
    b, D = 8, 10
    s, t = symbols('s t', positive=True)
    boat = (b + s) * 1 - (b - s) * (t - 2)   # 1 h downstream, moored 1 h, then upstream
    sols = solve([Eq(boat, s * t), Eq(s * t, D)], [s, t], dict=True)
    ok = [x[s] for x in sols if x[s] < b and x[t] > 2]
    assert len(ok) == 1
    return ok[0]
q("C08-C-033", BS, "Moored motorboat returning to meet a raft, current from the meeting point", "Difficult",
  "Inverse/parameter",
  r"A motorboat with a speed of $8$ km/h in still water leaves jetty P heading downstream at the moment a raft drifting with the current passes P. After $1$ hour the boat's engine fails, and the boat is tied to a post on the bank, so that it stays in one place, for the next $1$ hour while the engine is repaired. It then immediately heads back upstream at its usual still-water speed and meets the raft $10$ km downstream of P. The current is constant. What is the speed of the current in km/h?",
  "TITA",
  r"Let the current be $s$ km/h. After $2$ hours the moored boat is $8 + s$ km from P and the raft is $2s$ km from P, a gap of $8 - s$ km, which closes at $(8 - s) + s = 8$ km/h. So they meet $2 + \frac{8 - s}{8}$ hours after the start, and the raft is then at $s \cdot \frac{24 - s}{8} = 10$ km. This gives $s^2 - 24s + 80 = 0$, so $s = 4$ or $s = 20$; a current of $20$ km/h would make it impossible for the boat to go upstream, so $s = 4$ km/h. Check: the boat is at $12$ km and covers $2$ km upstream at $4$ km/h in $30$ minutes, reaching $10$ km just as the raft does after $2.5$ hours.",
  "Treating the moored boat like a drifting one, so that the water-frame shortcut seems to make the boat's speed irrelevant.",
  "C08C-raft-engine-failure", "Mooring to the bank breaks the familiar water-frame shortcut, so the meeting must be modelled on land; it leads to a quadratic whose extra root must be rejected.",
  tita_answer=4, check=_c33,
  tita_traps=[(5, "Uses the water-frame shortcut and leaves out the moored hour: the raft drifts $2$ hours, $\\frac{10}{2}$."),
              (20, "Keeps the other root of the quadratic, which is more than the boat's still-water speed.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-034
def _c34():
    v, c1, c2, T = F(4), F(1), F(2), F(1, 2)
    def total(direction):                       # -1 upstream first, +1 downstream first
        out = (v + direction * c1) * T          # distance from the buoy at the turn
        back = v - direction * c2               # ground speed on the way back
        assert back > 0
        return T + out / back
    return (total(+1) - total(-1)) * 60
q("C08-C-034", BS, "Two swimmers leaving an anchored buoy in opposite directions when the current rises", "Difficult",
  "Multi-step word problem",
  r"Ananya and Kabir, who each swim at $4$ km/h in still water, start together from a buoy anchored in a river flowing at $1$ km/h. Ananya swims upstream and Kabir swims downstream. After $30$ minutes both turn at the same moment and swim back towards the buoy at the same effort. At the moment they turn, a sluice gate upstream is opened and the current immediately rises to $2$ km/h, staying at that speed. How many minutes after Ananya reaches the buoy does Kabir reach it?",
  "TITA",
  r"Outward, Ananya moves at $4 - 1 = 3$ km/h and is $1.5$ km upstream after $30$ minutes; Kabir moves at $4 + 1 = 5$ km/h and is $2.5$ km downstream. On the way back the current is $2$ km/h: Ananya comes downstream at $6$ km/h, taking $\frac{1.5}{6}$ hour $= 15$ minutes, and Kabir struggles upstream at $2$ km/h, taking $\frac{2.5}{2}$ hours $= 75$ minutes. Ananya is back after $45$ minutes and Kabir after $105$ minutes, so Kabir arrives $60$ minutes later.",
  "Assuming equal swimmers with equal outward times return together, or forgetting that the current changes before the return legs.",
  "C08C-swimmers-current-change", "Two swimmers, four legs and two current regimes; the buoy is anchored, so no frame shortcut applies, and the change of current hits the two return legs in opposite ways.",
  tita_answer=60, check=_c34,
  tita_traps=[(32, "Ignores the rise in the current: returns take $18$ and $50$ minutes, totals $48$ and $80$."),
              (0, "Assumes swimmers of equal speed who swim out for equal times get back together."),
              (105, "Reports Kabir's total time instead of the difference.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-035
def _c35():
    N, e, x = symbols('N e x', positive=True)
    sol = solve([Eq(N, 50), Eq(N, 30 + 30 * e), Eq(x - e * x, N)], [N, e, x], dict=True)[0]
    return sol[x]
q("C08-C-035", EW, "Steps needed to walk down an up-escalator from stopped and moving counts", "Medium",
  "Multi-step word problem",
  r"When an escalator is switched off, Kabir walks up it in $50$ steps, one step per stair. When it is moving up, he walks up it at the same step rate and takes only $30$ steps. If he walks down the moving up-escalator, against its motion, at the same step rate, how many steps will he take?",
  "MCQ",
  r"There are $50$ visible steps. Going up the moving escalator, Kabir takes $30$ steps and the escalator supplies $20$ in the same time, so the escalator moves $\frac{20}{30} = \frac{2}{3}$ of a step per step of his. Going down, each of his steps nets $1 - \frac{2}{3} = \frac{1}{3}$ step of progress, so he needs $50 \times 3 = 150$ steps.",
  "Assuming the escalator pushes him back by the same number of steps it carried him on the way up.",
  "C08C-escalator-stopped-steps", "Two short steps once the escalator's share per step is found; the trap is assuming its contribution is the same on both trips.",
  correct=r"$150$",
  distractors=[(r"$70$", "Adds the escalator's $20$ steps from the upward trip: $50 + 20$."),
               (r"$125$", "Takes the escalator-to-walker ratio as $\\frac{30}{50}$: $\\frac{50}{1 - 0.6}$."),
               (r"$100$", "Assumes walking against the escalator doubles the $50$ steps.")],
  check=_c35, values=[150, 70, 125, 100], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-036
def _c36():
    b, s = symbols('b s', positive=True)
    sol = solve([Eq(b + s, 2 * (b - s)), Eq(b + s + 2, 3 * (b - s - 2))], [b, s], dict=True)[0]
    return sol[b]
q("C08-C-036", BS, "Still-water speed from time ratios before and after the stream speeds up", "Medium",
  "Inverse/parameter",
  r"On a normal day a launch takes twice as long to cover a stretch of river upstream as downstream. After heavy rain the stream flows $2$ km/h faster, and the launch, at the same still-water speed, takes three times as long upstream as downstream over the same stretch. What is the launch's speed in still water, in km/h?",
  "TITA",
  r"Normally downstream speed is twice upstream: $b + s = 2(b - s)$, so $b = 3s$. After rain: $b + s + 2 = 3(b - s - 2)$, so $2b = 4s + 8$. Substituting $b = 3s$: $6s = 4s + 8$, $s = 4$ and $b = 12$ km/h. Check: normal speeds $16$ and $8$; after rain $18$ and $6$.",
  "Reporting the stream speed, or the new stream speed, instead of the boat's speed.",
  "C08C-time-ratio-speed-ratio", "Two time ratios become two linear equations solved by substitution; a typical two-step CAT item.",
  tita_answer=12, check=_c36,
  tita_traps=[(4, "Reports the normal stream speed."), (6, "Reports the stream speed after the rain.")],
  cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-037
def _c37():
    L, belt, walk, floor = F(240), F(1), F(3, 2), F(3, 2)
    t_turn = L / (walk + belt)
    t = symbols('t', positive=True)
    tm = solve(Eq(L - (walk + belt) * (t - t_turn), floor * t), t)[0]
    assert tm > t_turn
    return floor * tm
q("C08-C-037", EW, "Out on one walkway and back on the opposite walkway, meeting a floor walker", "Difficult",
  "Multi-step word problem",
  r"An airport corridor $240$ m long has two parallel moving walkways running its full length in opposite directions, each moving at $1$ m/s. Joseph steps onto the outbound walkway and walks along it at $1.5$ m/s relative to it; at the far end he immediately steps onto the return walkway and walks back at $1.5$ m/s relative to it. At the moment Joseph starts, Priya starts from the same end and walks along the floor in the outbound direction at $1.5$ m/s. How far from the starting end do Joseph and Priya meet?",
  "MCQ",
  r"Joseph's ground speed is $2.5$ m/s each way, so he reaches the far end after $\frac{240}{2.5} = 96$ s; Priya is then at $144$ m. The gap of $96$ m closes at $2.5 + 1.5 = 4$ m/s, in $24$ s. They meet at $t = 120$ s, when Priya is at $1.5 \times 120 = 180$ m from the start.",
  "Forgetting that the return walkway also carries Joseph, or measuring from the wrong end.",
  "C08C-walkway-multi-stage", "Three phases with direction changes and two walkways; the meeting needs a timeline.",
  correct=r"$180$ m",
  distractors=[(r"$192$ m", "Gives Joseph only $1.5$ m/s on the way back: gap $96$ m closed at $3$ m/s."),
               (r"$144$ m", "Reports Priya's position when Joseph turns around."),
               (r"$60$ m", "Measures the meeting point from the far end.")],
  check=_c37, values=[180, 192, 144, 60], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-038
def _c38():
    b = symbols('b', positive=True)
    bv = [r for r in solve(Eq(24 / (b + 2) + 24 / (b - 2), 5), b) if r > 2][0]
    s = symbols('s', positive=True)
    return [r for r in solve(Eq(24 / (bv + s) + 24 / (bv - s), Rational(15, 2)), s) if r < bv][0]
q("C08-C-038", BS, "New stream speed from a longer round-trip time", "Difficult",
  "Inverse/parameter",
  r"A motorboat goes $24$ km upstream from a jetty and returns. When the stream flows at $2$ km/h, the round trip takes $5$ hours. On another day, with the boat's still-water speed unchanged, the round trip takes $7$ hours $30$ minutes. What is the speed of the stream on that day?",
  "MCQ",
  r"First find the still-water speed $b$: $\frac{24}{b + 2} + \frac{24}{b - 2} = 5$ gives $48b = 5(b^2 - 4)$, so $5b^2 - 48b - 20 = 0 = (5b + 2)(b - 10)$ and $b = 10$. Then $\frac{24}{10 + s} + \frac{24}{10 - s} = 7.5$ gives $\frac{480}{100 - s^2} = 7.5$, so $100 - s^2 = 64$ and $s = 6$ km/h. Check: $\frac{24}{16} + \frac{24}{4} = 1.5 + 6 = 7.5$.",
  "Assuming round-trip time is proportional to stream speed.",
  "C08C-stream-speed-change", "Two stages, each a quadratic from a rational equation.",
  correct=r"$6$ km/h",
  distractors=[(r"$3$ km/h", "Scales the stream speed with the time: $2 \\times \\frac{7.5}{5}$."),
               (r"$4$ km/h", "Reports the new upstream speed $10 - 6$."),
               (r"$16$ km/h", "Reports the new downstream speed $10 + 6$.")],
  check=_c38, values=[6, 3, 4, 16], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-039
def _c39():
    s, t = symbols('s t', positive=True)
    b = 15
    sol = solve([Eq((b + s) * t, (b - s) * 4), Eq((b - s) * t, (b + s) * 1)], [s, t], dict=True)
    return [x for x in sol if x[s] < b][0][s]
q("C08-C-039", BS, "Stream speed from the times two boats take after meeting", "Difficult",
  "Conceptual/application",
  r"Town Q lies downstream of town P. Two boats, each with still-water speed $15$ km/h, leave P and Q at the same moment and travel towards each other at constant speeds. After they meet, the boat from P takes $1$ hour to reach Q and the boat from Q takes $4$ hours to reach P. What is the speed of the stream?",
  "MCQ",
  r"If two bodies start together towards each other and take $t_1$ and $t_2$ after meeting, their speeds are in the ratio $\sqrt{t_2} : \sqrt{t_1}$. So downstream : upstream speed $= \sqrt{4} : \sqrt{1} = 2 : 1$, that is $15 + s = 2(15 - s)$, giving $s = 5$ km/h. Check: speeds $20$ and $10$ meet after $2$ hours; then $\frac{20}{20} = 1$ h and $\frac{40}{10} = 4$ h.",
  "Using the ratio of the times after meeting directly, without the square root.",
  "C08C-river-meeting-after-times", "Needs the square-root meeting rule transferred to a river.",
  correct=r"$5$ km/h",
  distractors=[(r"$9$ km/h", "Uses the speed ratio $4 : 1$ without the square root: $15 + s = 4(15 - s)$."),
               (r"$7.5$ km/h", "Takes the speed ratio $2 : 1$ as still-water speed : stream speed."),
               (r"$10$ km/h", "Reports the upstream speed $15 - 5$.")],
  check=_c39, values=[5, 9, F(15, 2), 10], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- C08-C-040
def _c40():
    b, s, D, t0 = 12, 3, 15, F(1, 2)
    boat = (b - s) * t0                   # upstream positive
    hat = -s * t0
    tau = (boat - hat) / ((b + s) - s)    # closing speed on the way back
    t = t0 + tau
    pos = boat - (b + s) * tau
    assert pos == -s * t
    t += (D - pos) / (b - s)
    return t * 60
q("C08-C-040", BS, "Hat lost at the start of an upstream trip, recovered, then trip completed", "Difficult",
  "Multi-step word problem",
  r"Village Q is $15$ km upstream of jetty P. Just as Ananya's motorboat leaves P for Q, her hat falls into the water at P and floats downstream with the current. The boat's still-water speed is $12$ km/h and the river flows at $3$ km/h. After $30$ minutes she notices, turns around instantly, goes downstream to pick up the hat, then turns again and goes on to Q, all at the same still-water speed. Ignoring the time for turning and picking up the hat, how long does she take from P to Q?",
  "MCQ",
  r"Relative to the water the hat is at rest, so after $30$ minutes going away she needs $30$ minutes to return to it. The hat has then drifted for $1$ hour, so it is $3$ km downstream of P. From there to Q is $18$ km upstream at $9$ km/h, taking $2$ hours. Total $= 0.5 + 0.5 + 2 = 3$ hours $= 180$ minutes.",
  "Treating the hat as stationary at P, which puts the pickup point and the remaining distance in the wrong place.",
  "C08C-floating-object-frame", "Water-frame insight followed by a further leg whose length depends on the hat's drift.",
  correct=r"$180$ minutes",
  distractors=[(r"$160$ minutes", "Takes $30$ minutes to return but assumes the hat is picked up at P: $30 + 30 + 100$."),
               (r"$148$ minutes", "Treats the hat as fixed at P: back to P in $18$ minutes, then $100$ minutes to Q."),
               (r"$150$ minutes", "Finds the pickup point correctly but uses the still-water speed $12$ km/h for the final $18$ km.")],
  check=_c40, values=[180, 160, 148, 150], cognitive="Analysis", exams=CX)
