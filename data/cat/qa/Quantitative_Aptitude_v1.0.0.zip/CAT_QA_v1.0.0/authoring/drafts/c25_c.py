import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Advanced counting"
SPEED = ("CAT", "XAT")


def _adj(i, j, n):
    return (i - j) % n in (1, n - 1)


def _seat_count(n, cond):
    # people 0..n-1 round an unnumbered table; rotations identical, so fix person 0 at seat 0
    cnt = 0
    for rest in itertools.permutations(range(1, n)):
        seat = (0,) + rest  # seat[k] = person in seat k
        pos = {p: k for k, p in enumerate(seat)}
        if cond(seat, pos):
            cnt += 1
    return cnt


def _paths(E, N, avoid=(), through=()):
    cnt = 0
    for npos in itertools.combinations(range(E + N), N):
        x = y = 0
        pts = {(0, 0)}
        s = set(npos)
        for k in range(E + N):
            if k in s:
                y += 1
            else:
                x += 1
            pts.add((x, y))
        if any(p in pts for p in avoid):
            continue
        if not all(p in pts for p in through):
            continue
        cnt += 1
    return cnt


def _fixed(p):
    return sum(1 for i, v in enumerate(p) if i == v)


# ---------------------------------------------------------------- EASY

def _e1():
    for n in range(2, 60):
        if len(list(itertools.combinations(range(n), 2))) == 78:
            return n
q("C25-C-001", T, "Number of people from the total number of handshakes", "Easy",
  "Inverse/parameter",
  r"At a school reunion, every person present shook hands exactly once with every other person present, and no one shook hands with themselves. A total of $78$ handshakes took place. How many people were present at the reunion?",
  "TITA",
  r"Each handshake corresponds to a pair of people, so $\binom{n}{2} = \frac{n(n-1)}{2} = 78$, giving $n(n-1) = 156 = 13 \times 12$. Hence $n = 13$ people.",
  "Setting $n(n-1) = 78$ without halving, or treating each handshake as two ordered greetings.",
  "C25C-handshake-inverse", "One equation $\\binom{n}{2} = 78$ solved by spotting consecutive factors.",
  tita_answer=13, check=_e1,
  tita_traps=[(12, "Solves $n(n-1) = 156$ but reports the smaller factor $12$.")],
  cognitive="Application")


def _e2():
    return _seat_count(7, lambda s, pos: _adj(pos[1], pos[2], 7))
q("C25-C-002", T, "Circular seating with two particular people adjacent", "Easy",
  "Single-step computation",
  r"Seven friends, including Ravi and Meera, sit around a circular table with seven identical, unnumbered chairs. Two seatings are the same if one can be obtained from the other by rotation. In how many seatings do Ravi and Meera sit next to each other?",
  "MCQ",
  r"Tie Ravi and Meera into one block. The block and the other $5$ friends are $6$ units around a circle, which can be arranged in $(6-1)! = 120$ ways. Inside the block they can sit in $2$ orders, so the count is $2 \times 120 = 240$.",
  "Arranging the $6$ units as if in a row, or forgetting that Ravi and Meera can swap inside the block.",
  "C25C-circular-adjacency", "Single block idea plus the $(n-1)!$ rule for circles.",
  correct=r"$240$",
  distractors=[(r"$1440$", "Arranges the $6$ units in a row, $6! \\times 2 = 1440$, ignoring that rotations are identical."),
               (r"$120$", "Counts $(6-1)! = 120$ but forgets the $2$ internal orders of Ravi and Meera."),
               (r"$480$", "Computes the seatings where they are not adjacent, $720 - 240 = 480$.")],
  check=_e2, values=[240, 1440, 120, 480], cognitive="Application")


def _e3():
    return sum(1 for t in itertools.product(range(9), repeat=4) if sum(t) == 8)
q("C25-C-003", T, "Non-negative integer solutions of a four-variable linear equation", "Easy",
  "Single-step computation",
  r"How many ordered quadruples $(a, b, c, d)$ of non-negative integers satisfy $a + b + c + d = 8$?",
  "TITA",
  r"Write $8$ stars and $3$ bars in a row; each arrangement gives one solution, the bars cutting the stars into four groups. The number of arrangements is $\binom{8+3}{3} = \binom{11}{3} = 165$.",
  "Using the positive-integer formula $\\binom{n-1}{r-1}$, or miscounting the number of bars.",
  "C25C-nonneg-stars-bars", "Direct application of the stars and bars formula.",
  tita_answer=165, check=_e3,
  tita_traps=[(35, "Uses the positive-integer count $\\binom{7}{3} = 35$."),
              (220, "Uses $\\binom{8+4}{3} = \\binom{12}{3} = 220$, adding the number of variables in place of the number of bars to $8$.")],
  cognitive="Application")


def _e4():
    pts = [(Fraction(k, 1009), 0) for k in range(1, 5)] + [(x, x * x + 1) for x in range(1, 7)]
    c = 0
    for p, r, s in itertools.combinations(pts, 3):
        if (r[0] - p[0]) * (s[1] - p[1]) - (r[1] - p[1]) * (s[0] - p[0]) != 0:
            c += 1
    return c
q("C25-C-004", T, "Triangles from points with one collinear subset", "Easy",
  "Single-step computation",
  r"There are $10$ points in a plane. Exactly $4$ of them lie on one straight line, and no three of the points are collinear apart from triples taken from those $4$. How many triangles have all three vertices among these $10$ points?",
  "MCQ",
  r"Any $3$ of the $10$ points give $\binom{10}{3} = 120$ triples. A triple fails to form a triangle only when all three points come from the $4$ collinear ones, which happens in $\binom{4}{3} = 4$ ways. So there are $120 - 4 = 116$ triangles.",
  "Treating the line of $4$ points as just one failed triple, or subtracting pairs instead of triples.",
  "C25C-triangles-collinear", "One subtraction of degenerate triples from $\\binom{10}{3}$.",
  correct=r"$116$",
  distractors=[(r"$120$", "Takes $\\binom{10}{3}$ and ignores the collinear points."),
               (r"$119$", "Subtracts $1$, thinking the collinear set spoils only one triple."),
               (r"$114$", "Subtracts $\\binom{4}{2} = 6$, the pairs on the line, rather than the $4$ collinear triples.")],
  check=_e4, values=[116, 120, 119, 114], cognitive="Understanding")


def _e5():
    c = 0
    for c1 in range(5):
        for c2 in range(c1, 5):
            for r1 in range(4):
                for r2 in range(r1, 4):
                    c += 1
    return c
q("C25-C-005", T, "Rectangles of all sizes in a rectangular grid", "Easy",
  "Conceptual/application",
  r"A rectangular board is divided by straight lines into a grid of unit squares with $5$ columns and $4$ rows, so it has $20$ unit squares. Counting every rectangle of every size whose sides lie along the grid lines (squares included), how many rectangles are there on the board?",
  "TITA",
  r"A rectangle is fixed by choosing $2$ of the $6$ vertical grid lines and $2$ of the $5$ horizontal grid lines. That gives $\binom{6}{2} \times \binom{5}{2} = 15 \times 10 = 150$ rectangles.",
  "Choosing from the numbers of columns and rows rather than from the numbers of grid lines.",
  "C25C-rectangles-grid", "One insight: a rectangle is a choice of two vertical and two horizontal lines.",
  tita_answer=150, check=_e5,
  tita_traps=[(60, "Uses $\\binom{5}{2} \\times \\binom{4}{2}$, choosing from columns and rows instead of grid lines."),
              (20, "Counts only the unit squares.")],
  cognitive="Understanding")


def _e6():
    return sum(1 for p in itertools.permutations(range(5)) if _fixed(p) == 0)
q("C25-C-006", T, "Derangements of five objects", "Easy",
  "Conceptual/application",
  r"Five colleagues each write their own name on a slip of paper. The five slips are shuffled and each colleague draws one slip, every possible assignment of slips being allowed. In how many assignments does no colleague draw the slip with their own name?",
  "MCQ",
  r"This is the number of derangements of $5$ objects: $D_5 = 5!\left(1 - \frac{1}{1!} + \frac{1}{2!} - \frac{1}{3!} + \frac{1}{4!} - \frac{1}{5!}\right) = 120 - 120 + 60 - 20 + 5 - 1 = 44$. Equivalently, $D_n = (n-1)(D_{n-1} + D_{n-2})$ gives $D_5 = 4(9 + 2) = 44$.",
  "Counting all assignments except the one where everyone draws their own slip.",
  "C25C-derangement-full", "Recognising a derangement and evaluating $D_5$.",
  correct=r"$44$",
  distractors=[(r"$119$", "Subtracts only the single assignment where everyone gets their own slip, $5! - 1$."),
               (r"$1024$", "Gives each colleague $4$ wrong slips independently, $4^5$, ignoring that each slip goes to only one person."),
               (r"$24$", "Uses $4! = 24$, the number of ways to arrange the other four slips once one colleague's slip is fixed, as the answer.")],
  check=_e6, values=[44, 119, 1024, 24], cognitive="Understanding")


def _e7():
    for n in range(4, 40):
        diag = sum(1 for i, j in itertools.combinations(range(n), 2) if not _adj(i, j, n))
        if diag == 4 * n:
            return n
q("C25-C-007", T, "Number of sides of a polygon from a diagonal condition", "Easy",
  "Inverse/parameter",
  r"A convex polygon has exactly $4$ times as many diagonals as it has sides. How many sides does the polygon have?",
  "MCQ",
  r"An $n$-sided polygon has $\frac{n(n-3)}{2}$ diagonals, since each vertex joins $n - 3$ non-adjacent vertices and each diagonal is counted twice. Setting $\frac{n(n-3)}{2} = 4n$ gives $n - 3 = 8$, so $n = 11$.",
  "Forgetting that each diagonal is counted from both of its ends.",
  "C25C-polygon-diagonals", "One formula and a linear equation after cancelling $n$.",
  correct=r"$11$",
  distractors=[(r"$7$", "Uses $n(n-3) = 4n$ without halving, so $n - 3 = 4$."),
               (r"$9$", "Counts all segments joining vertices, $\\frac{n(n-1)}{2} = 4n$, which includes the sides."),
               (r"$10$", "Excludes only the two neighbours of a vertex but not the vertex itself, $\\frac{n(n-2)}{2} = 4n$.")],
  check=_e7, values=[11, 7, 9, 10], cognitive="Application")


def _e8():
    return _paths(5, 3, through=[(2, 1)])
q("C25-C-008", T, "Shortest grid routes through a given intersection", "Easy",
  "Multi-step word problem",
  r"In a town whose streets form a square grid, Priya walks from crossing P to crossing Q, which is $5$ blocks east and $3$ blocks north of P, always moving one block east or one block north. She must pass through crossing R, which is $2$ blocks east and $1$ block north of P. How many different routes can she take?",
  "TITA",
  r"From P to R she makes $2$ east and $1$ north moves in any order: $\binom{3}{1} = 3$ ways. From R to Q she makes $3$ east and $2$ north moves: $\binom{5}{2} = 10$ ways. By the multiplication principle there are $3 \times 10 = 30$ routes.",
  "Adding the two stage counts, or ignoring the compulsory crossing.",
  "C25C-grid-paths-via-avoid", "Two stages multiplied; one trap of adding instead.",
  tita_answer=30, check=_e8,
  tita_traps=[(56, "Counts all routes $\\binom{8}{3}$ and ignores the condition about R."),
              (13, "Adds the stage counts, $3 + 10$.")],
  cognitive="Application")


def _e9():
    teams = range(10)
    league = [(h, a) for h in teams for a in teams if h != a]
    knockout = 2 + 1 + 1  # two semi-finals, final, third-place match
    return len(league) + knockout
q("C25-C-009", T, "Matches in a double round robin followed by a knockout", "Easy",
  "Multi-step word problem",
  r"In a football league of $10$ teams, every team plays every other team twice, once at home and once away. The top $4$ teams then play two semi-finals, after which the two winners play the final and the two losers play a third-place match. How many matches are played in all?",
  "MCQ",
  r"Each ordered pair (home team, away team) is one league match: $10 \times 9 = 90$ matches. The play-offs add $2$ semi-finals, $1$ final and $1$ third-place match, that is $4$ more. Total $90 + 4 = 94$.",
  "Counting each pair of teams only once in the league stage.",
  "C25C-tournament-matches", "Two stages, one trap on home and away counting.",
  correct=r"$94$",
  distractors=[(r"$49$", "Counts each pair of teams once, $\\binom{10}{2} = 45$, then adds $4$."),
               (r"$93$", "Counts the league correctly but leaves out the third-place match."),
               (r"$104$", "Uses $10 \\times 10 = 100$ league matches, letting a team play itself, then adds $4$.")],
  check=_e9, values=[94, 49, 93, 104], cognitive="Application")


def _e10():
    men = {0, 2, 4, 6}
    return _seat_count(8, lambda s, pos: all((s[k] in men) != (s[(k + 1) % 8] in men) for k in range(8)))
q("C25-C-010", T, "Men and women alternating around a circular table", "Easy",
  "Conceptual/application",
  r"Four men and four women are to sit around a circular table with eight identical, unnumbered chairs, so that no two men sit next to each other and no two women sit next to each other. Seatings that differ only by a rotation are the same. How many seatings are possible?",
  "MCQ",
  r"First seat the men around the table: $(4-1)! = 6$ ways. This fixes $4$ gaps, one between each pair of neighbouring men, and the women fill these gaps in $4! = 24$ ways. Total $6 \times 24 = 144$.",
  "Applying the circular reduction twice, or not at all.",
  "C25C-circular-alternate", "Seat one group in a circle, then the other in the gaps.",
  correct=r"$144$",
  distractors=[(r"$576$", "Arranges both groups as $4! \\times 4!$, forgetting that the circle removes one factor."),
               (r"$36$", "Applies the circular rule to both groups, $3! \\times 3!$."),
               (r"$1152$", "Treats the seats as a row with two possible starting genders, $2 \\times 4! \\times 4!$.")],
  check=_e10, values=[144, 576, 36, 1152], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM

def _m1():
    seen = set()
    for p in itertools.permutations(range(8)):
        forms = []
        for r in range(8):
            rot = p[r:] + p[:r]
            forms.append(rot)
            forms.append(tuple(reversed(rot)))
        seen.add(min(forms))
    return sum(1 for f in seen if _adj(f.index(0), f.index(1), 8))
q("C25-C-011", T, "Necklace of distinct beads with two beads adjacent", "Medium",
  "Multi-step word problem",
  r"Eight beads of eight different colours, including one red and one blue bead, are strung on a closed loop to make a necklace. Two necklaces are the same if one can be obtained from the other by rotating it or by turning it over. In how many different necklaces are the red and blue beads next to each other?",
  "MCQ",
  r"Treat the red and blue beads as one block, which can be ordered in $2$ ways. The block and the other $6$ beads are $7$ units on a loop: $(7-1)! = 720$ circular orders. Turning the necklace over pairs each order with its mirror image, so divide by $2$: $\frac{720 \times 2}{2} = 720$.",
  "Forgetting that a necklace can be flipped, or forgetting the internal order of the block.",
  "C25C-necklace-flip", "Block method combined with the extra factor of $2$ for reflections.",
  correct=r"$720$",
  distractors=[(r"$1440$", "Does not divide by $2$ for turning the necklace over."),
               (r"$360$", "Divides by $2$ for the flip but forgets the $2$ orders of red and blue inside the block."),
               (r"$2520$", "Counts all necklaces, $\\frac{7!}{2}$, ignoring the adjacency condition.")],
  check=_m1, values=[720, 1440, 360, 2520], cognitive="Application")


def _m2():
    return sum(1 for p in itertools.permutations(range(6)) if _fixed(p) == 2)
q("C25-C-012", T, "Permutations with exactly two fixed points", "Medium",
  "Multi-step word problem",
  r"Six guests leave their coats with an attendant, who loses the tags and hands the coats back at random, one coat to each guest. In how many of the possible ways of returning the coats do exactly two guests receive their own coats?",
  "TITA",
  r"Choose the $2$ guests who get their own coats: $\binom{6}{2} = 15$ ways. The other $4$ guests must all get wrong coats, which is a derangement of $4$: $D_4 = 24 - 24 + 12 - 4 + 1 = 9$. Total $15 \times 9 = 135$.",
  "Letting the remaining four coats go anywhere, which counts 'at least two' instead of 'exactly two'.",
  "C25C-derangement-exactly-k", "Choose the fixed guests, then derange the rest.",
  tita_answer=135, check=_m2,
  tita_traps=[(360, "Arranges the other four coats freely, $15 \\times 4!$, so some of them may also be correct."),
              (9, "Gives only $D_4$ and forgets to choose which two guests are correct.")],
  cognitive="Application")


def _m3():
    return sum(1 for x in range(15) for y in range(15) for z in range(15) if 2 * x + y + z == 14)
q("C25-C-013", T, "Non-negative solutions of a linear equation with one doubled coefficient", "Medium",
  "Casework/optimisation",
  r"How many ordered triples $(x, y, z)$ of non-negative integers satisfy $2x + y + z = 14$?",
  "MCQ",
  r"Fix $x$. Then $x$ can be $0, 1, \ldots, 7$, and $y + z = 14 - 2x$ has $15 - 2x$ non-negative solutions. Summing, $15 + 13 + 11 + 9 + 7 + 5 + 3 + 1 = 64$, the sum of the first $8$ odd numbers, which is $8^2$.",
  "Treating the coefficient $2$ as $1$, or dropping an end case of the casework on $x$.",
  "C25C-solutions-weighted", "Casework on the variable with coefficient $2$, then summing an arithmetic series.",
  correct=r"$64$",
  distractors=[(r"$120$", "Ignores the coefficient $2$ and counts solutions of $x + y + z = 14$, $\\binom{16}{2}$."),
               (r"$36$", "Counts positive solutions only: $x = 1$ to $6$ with $13 - 2x$ choices each, $11 + 9 + 7 + 5 + 3 + 1$."),
               (r"$49$", "Starts the casework at $x = 1$, leaving out the $15$ solutions with $x = 0$.")],
  check=_m3, values=[64, 120, 36, 49], cognitive="Application")


def _m4():
    return sum(1 for t in itertools.product(range(11), repeat=3) if sum(t) == 20)
q("C25-C-014", T, "Solutions with a common upper bound via complements", "Medium",
  "Conceptual/application",
  r"Ananya takes three quizzes. Each quiz is marked out of $10$, and her score on each quiz is an integer from $0$ to $10$. Her total over the three quizzes is $20$. How many different ordered triples of quiz scores are possible?",
  "TITA",
  r"Let her marks lost be $x' = 10 - x$, $y' = 10 - y$, $z' = 10 - z$, each a non-negative integer. Then $x' + y' + z' = 30 - 20 = 10$, and each $x' \le 10$ holds automatically. So the count is $\binom{12}{2} = 66$. (By inclusion and exclusion: $\binom{22}{2} - 3\binom{11}{2} = 231 - 165 = 66$.)",
  "Ignoring the cap of $10$ marks per quiz, or subtracting the cases of exactly $10$ as if they were too large.",
  "C25C-solutions-upper-bound", "Requires handling an upper bound, best by the complement substitution.",
  tita_answer=66, check=_m4,
  tita_traps=[(231, "Ignores the cap and uses $\\binom{22}{2}$."),
              (33, "Removes cases with a score of $10$ or more, $231 - 3\\binom{12}{2} = 33$, which wrongly discards scores of exactly $10$.")],
  cognitive="Analysis")


def _m5():
    return _paths(6, 4, avoid=[(3, 2)])
q("C25-C-015", T, "Shortest grid routes avoiding one intersection", "Medium",
  "Multi-step word problem",
  r"A delivery rider travels on a square street grid from depot P to shop Q, which is $6$ blocks east and $4$ blocks north of P, moving only east or north one block at a time. The crossing that is $3$ blocks east and $2$ blocks north of P is flooded and cannot be entered. How many routes can the rider take?",
  "MCQ",
  r"Without the restriction there are $\binom{10}{4} = 210$ routes. Routes through the flooded crossing: $\binom{5}{2}$ ways to reach it times $\binom{5}{2}$ ways to go on to Q, which is $10 \times 10 = 100$. So $210 - 100 = 110$ routes avoid it.",
  "Subtracting the sum of the two stage counts rather than their product.",
  "C25C-grid-paths-via-avoid", "Complement count with a two-stage product.",
  correct=r"$110$",
  distractors=[(r"$210$", "Counts all routes and ignores the flooded crossing."),
               (r"$100$", "Reports the number of routes through the flooded crossing."),
               (r"$190$", "Subtracts $10 + 10$, adding the stage counts in place of multiplying them.")],
  check=_m5, values=[110, 210, 100, 190], cognitive="Application")


def _m6():
    for n in range(1, 40):
        people = range(2 * n)
        hs = sum(1 for i, j in itertools.combinations(people, 2) if i // 2 != j // 2)
        if hs == 60:
            return 2 * n
q("C25-C-016", T, "Handshakes among couples who skip their own spouse", "Medium",
  "Inverse/parameter",
  r"At a party attended only by married couples, every person shook hands exactly once with every other person except their own spouse. There were $60$ handshakes in all. How many people attended the party?",
  "TITA",
  r"Let there be $n$ couples, so $2n$ people. All pairs number $\binom{2n}{2} = n(2n - 1)$, and the $n$ spouse pairs do not shake hands, so $n(2n - 1) - n = 2n(n - 1) = 60$. Then $n(n - 1) = 30$, so $n = 6$ couples, that is $12$ people.",
  "Reporting the number of couples rather than the number of people.",
  "C25C-handshake-inverse", "Needs a modified handshake count and solving for a parameter.",
  tita_answer=12, check=_m6,
  tita_traps=[(6, "Finds $n = 6$ couples and reports it as the number of people.")],
  cognitive="Application")


def _m7():
    n = 12
    return sum(1 for t in itertools.combinations(range(n), 3)
               if not any(_adj(a, b, n) for a, b in itertools.combinations(t, 2)))
q("C25-C-017", T, "Triangles from polygon vertices sharing no side with the polygon", "Medium",
  "Casework/optimisation",
  r"Triangles are formed by choosing three of the twelve vertices of a convex $12$-sided polygon. How many of these triangles have no side in common with the polygon?",
  "MCQ",
  r"There are $\binom{12}{3} = 220$ triangles. Exactly two sides are shared when the vertices are three consecutive ones: $12$ triangles. Exactly one side is shared when two vertices are adjacent and the third is not next to either: $12 \times (12 - 4) = 96$. So $220 - 12 - 96 = 112$ share no side.",
  "Counting triangles that share a side as $12 \\times 10$, which counts the two-side triangles twice, or leaving them out.",
  "C25C-polygon-triangles-no-side", "Casework on how many sides are shared.",
  correct=r"$112$",
  distractors=[(r"$124$", "Subtracts only the $96$ triangles sharing exactly one side and forgets the $12$ sharing two."),
               (r"$100$", "Subtracts $12 \\times 10 = 120$, counting each two-side triangle twice and not adding them back."),
               (r"$220$", "Counts all triangles $\\binom{12}{3}$ without the condition.")],
  check=_m7, values=[112, 124, 100, 220], cognitive="Analysis", exams=SPEED)


def _m8():
    c = 0
    for k in range(1, 5):
        for x in range(0, 6 - k + 1):
            for y in range(0, 4 - k + 1):
                c += 1
    return c
q("C25-C-018", T, "Squares of all sizes in a rectangular grid", "Medium",
  "Casework/optimisation",
  r"A floor is tiled with $24$ unit square tiles laid in $4$ rows of $6$ tiles each. Counting every square of every size whose sides lie along the tile edges, how many squares are there?",
  "MCQ",
  r"A $k \times k$ square fits in $(7 - k)(5 - k)$ positions. For $k = 1, 2, 3, 4$ this gives $24 + 15 + 8 + 3 = 50$ squares.",
  "Stopping before the largest square size, or counting rectangles in place of squares.",
  "C25C-rectangles-grid", "Casework over square sizes with a position count for each.",
  correct=r"$50$",
  distractors=[(r"$47$", "Stops at $3 \\times 3$ squares, missing the three $4 \\times 4$ squares."),
               (r"$24$", "Counts only the unit tiles."),
               (r"$210$", "Counts all rectangles, $\\binom{7}{2}\\binom{5}{2}$.")],
  check=_m8, values=[50, 47, 24, 210], cognitive="Application")


def _m9():
    objs = ["L"] * 6 + ["C"] * 4
    w = {("L", "L"): 1, ("L", "C"): 2, ("C", "L"): 2, ("C", "C"): 2}
    return sum(w[(a, b)] for a, b in itertools.combinations(objs, 2))
q("C25-C-019", T, "Maximum intersection points of lines and circles", "Medium",
  "Casework/optimisation",
  r"Six distinct straight lines and four distinct circles are drawn in a plane. What is the greatest possible number of points at which at least two of these figures intersect?",
  "TITA",
  r"Count by type of pair, with all intersection points distinct. Two lines meet in at most $1$ point: $\binom{6}{2} = 15$. A line and a circle meet in at most $2$ points: $6 \times 4 \times 2 = 48$. Two circles meet in at most $2$ points: $\binom{4}{2} \times 2 = 12$. Maximum $15 + 48 + 12 = 75$.",
  "Allowing only one intersection point for a line and a circle, or for two circles.",
  "C25C-lines-circles-intersections", "Three pair types, each with its own maximum.",
  tita_answer=75, check=_m9,
  tita_traps=[(45, "Uses $1$ point for every pair, $\\binom{10}{2}$."),
              (69, "Uses $1$ point for each pair of circles, $15 + 48 + 6$.")],
  cognitive="Application")


def _m10():
    # Arjun = 0, Fatima = 1
    return _seat_count(8, lambda s, pos: (pos[1] - pos[0]) % 8 not in (1, 7, 4))
q("C25-C-020", T, "Circular seating with two people neither adjacent nor opposite", "Medium",
  "Casework/optimisation",
  r"Eight people, including Arjun and Fatima, sit around a circular table with eight equally spaced, identical chairs. Seatings that differ only by a rotation are the same. In how many seatings is Fatima neither next to Arjun nor directly opposite him?",
  "MCQ",
  r"Since rotations are identical, fix Arjun's chair. Of the remaining $7$ chairs, $2$ are next to him and $1$ is opposite, so Fatima has $4$ allowed chairs. The other $6$ people fill the rest in $6! = 720$ ways. Total $4 \times 720 = 2880$.",
  "Excluding only the adjacent chairs, or thinking there are two opposite chairs.",
  "C25C-circular-adjacency", "Fix one person, then casework on the other's allowed chairs.",
  correct=r"$2880$",
  distractors=[(r"$3600$", "Excludes only the $2$ adjacent chairs, so Fatima has $5$ choices."),
               (r"$2160$", "Excludes $2$ adjacent and $2$ supposedly opposite chairs, leaving $3$ choices."),
               (r"$5760$", "Multiplies by $2$ again for swapping Arjun and Fatima, though fixing Arjun already counts each seating once.")],
  check=_m10, values=[2880, 3600, 2160, 5760], cognitive="Application")


def _m11():
    return len(set(itertools.permutations("XXXYYZ")))
q("C25-C-021", T, "Shortest paths along edges of a three-dimensional lattice", "Medium",
  "Conceptual/application",
  r"A climbing frame is built from rods forming a lattice of unit cubes, $3$ units long, $2$ units wide and $1$ unit high. A spider starts at one corner of the frame and crawls along the rods to the diagonally opposite corner, each move taking it one unit farther along the length, the width or the height. How many different routes can it take?",
  "MCQ",
  r"Every route is a sequence of $6$ unit moves: $3$ along the length, $2$ along the width and $1$ along the height. The number of such sequences is $\frac{6!}{3!\,2!\,1!} = \frac{720}{12} = 60$.",
  "Treating the moves as all different, or placing only one type of move.",
  "C25C-grid-paths-3d", "Extends the grid path idea to three directions.",
  correct=r"$60$",
  distractors=[(r"$20$", "Chooses positions for the $3$ length moves, $\\binom{6}{3}$, and stops."),
               (r"$120$", "Divides $6!$ by $3!$ only, treating the width moves as different."),
               (r"$720$", "Counts $6!$ orders of the moves as if all were distinct.")],
  check=_m11, values=[60, 20, 120, 720], cognitive="Understanding")


def _m12():
    return sum(1 for x in range(11) for y in range(11) for z in range(11) if x + y + z <= 10)
q("C25-C-022", T, "Non-negative solutions of a linear inequality using a slack variable", "Medium",
  "Conceptual/application",
  r"How many ordered triples $(x, y, z)$ of non-negative integers satisfy $x + y + z \le 10$?",
  "MCQ",
  r"Introduce a slack variable $w = 10 - (x + y + z) \ge 0$. Then $x + y + z + w = 10$ in non-negative integers, which has $\binom{13}{3} = 286$ solutions.",
  "Counting only the equality case, or summing only up to a total of $9$.",
  "C25C-solutions-at-most", "Converting an inequality to an equation with a slack variable.",
  correct=r"$286$",
  distractors=[(r"$66$", "Counts only $x + y + z = 10$, $\\binom{12}{2}$."),
               (r"$220$", "Sums the equality counts for totals $0$ to $9$ only, $\\binom{12}{3}$."),
               (r"$364$", "Uses $\\binom{14}{3}$, one too many in the top of the binomial.")],
  check=_m12, values=[286, 66, 220, 364], cognitive="Understanding")


def _m13():
    for n in range(4, 60):
        H, J, Pr = 0, 1, 2  # Harpreet, Joseph, Priya; players 3.. stayed
        stay = range(3, n)
        games = set(itertools.combinations(stay, 2))
        games.add((H, J))
        games |= {(H, 3), (H, 4)}          # Harpreet: 3 games in all
        games |= {(J, 5)}                  # Joseph: 2 games in all
        games |= {(Pr, 6)}                 # Priya: 1 game
        if len(games) == 60:
            return n
q("C25-C-023", T, "Round robin with three players who withdrew partway", "Medium",
  "Inverse/parameter",
  r"In a chess tournament, every pair of players was scheduled to play exactly one game against each other. Three players withdrew early: Harpreet after playing $3$ games, Joseph after playing $2$ games and Priya after playing $1$ game. Among these three, the only game played was Harpreet against Joseph. All other scheduled games were completed, and $60$ games were played in all. How many players were there at the start?",
  "TITA",
  r"Let there be $n$ players. The $n - 3$ who stayed played all $\binom{n-3}{2}$ games among themselves. The withdrawn players took part in $3 + 2 + 1 = 6$ games, but the Harpreet against Joseph game is counted twice in that sum, so they account for $5$ games. Then $\binom{n-3}{2} + 5 = 60$, so $\binom{n-3}{2} = 55$, $n - 3 = 11$ and $n = 14$.",
  "Counting the game between two withdrawn players twice, or reporting the number of players who stayed.",
  "C25C-tournament-matches", "Modified round-robin count with a double-counted game, solved for $n$.",
  tita_answer=14, check=_m13,
  tita_traps=[(11, "Reports $n - 3 = 11$, the players who completed the tournament.")],
  cognitive="Analysis")


def _m14():
    pts = [(x, 0) for x in range(6)] + [(x, 1) for x in range(8)]
    c = 0
    for p, r, s in itertools.combinations(pts, 3):
        if (r[0] - p[0]) * (s[1] - p[1]) - (r[1] - p[1]) * (s[0] - p[0]) != 0:
            c += 1
    return c
q("C25-C-024", T, "Triangles from points on two parallel lines", "Medium",
  "Multi-step word problem",
  r"Six points are marked on a straight line $\ell$ and eight points on a different straight line $m$ parallel to $\ell$. How many triangles have all three vertices among these $14$ points?",
  "MCQ",
  r"A triangle needs two vertices on one line and one on the other. Two on $\ell$ and one on $m$: $\binom{6}{2} \times 8 = 120$. Two on $m$ and one on $\ell$: $\binom{8}{2} \times 6 = 168$. Total $288$. (Check: $\binom{14}{3} - \binom{6}{3} - \binom{8}{3} = 364 - 20 - 56 = 288$.)",
  "Removing collinear triples from only one of the lines, or counting only one case.",
  "C25C-triangles-collinear", "Two collinear sets; casework or complement.",
  correct=r"$288$",
  distractors=[(r"$364$", "Takes $\\binom{14}{3}$ and ignores collinearity."),
               (r"$344$", "Removes the collinear triples on $\\ell$ only, $364 - 20$."),
               (r"$168$", "Counts only triangles with two vertices on $m$.")],
  check=_m14, values=[288, 364, 344, 168], cognitive="Application")


def _m15():
    c = 0
    for p in itertools.permutations(range(8)):
        if _adj(p.index(0), p.index(1), 8):
            c += 1
    return c
q("C25-C-025", T, "Circular table with numbered seats and two people adjacent", "Medium",
  "Conceptual/application",
  r"A round table has eight chairs numbered $1$ to $8$ in order around it, so chair $8$ is next to chair $1$. Eight people, including Kabir and Sneha, are to be seated, one per chair. Seatings are different whenever some person sits in a different numbered chair. In how many seatings are Kabir and Sneha in neighbouring chairs?",
  "MCQ",
  r"Because the chairs are numbered, rotations give different seatings. There are $8$ pairs of neighbouring chairs around the table, Kabir and Sneha can occupy a pair in $2$ orders, and the other $6$ people fill the remaining chairs in $6! = 720$ ways. Total $8 \times 2 \times 720 = 11520$.",
  "Using the $(n-1)!$ rule although numbered chairs make rotations distinct, or using only $7$ neighbouring pairs as in a row.",
  "C25C-circular-adjacency", "Requires seeing that numbered chairs remove the rotational symmetry.",
  correct=r"$11520$",
  distractors=[(r"$1440$", "Uses the unnumbered-table count $2 \\times 6!$."),
               (r"$10080$", "Counts $7$ neighbouring pairs as in a row of $8$ chairs, $7 \\times 2 \\times 720$."),
               (r"$5760$", "Forgets that Kabir and Sneha can swap, $8 \\times 720$.")],
  check=_m15, values=[11520, 1440, 10080, 5760], cognitive="Understanding")


def _m16():
    c = 0
    for c1 in range(7):
        for c2 in range(c1, 7):
            for r1 in range(5):
                for r2 in range(r1, 5):
                    if c2 - c1 != r2 - r1:
                        c += 1
    return c
q("C25-C-026", T, "Rectangles that are not squares in a grid", "Medium",
  "Multi-step word problem",
  r"A wall is covered by a grid of unit squares with $7$ columns and $5$ rows. How many rectangles with sides along the grid lines are not squares?",
  "MCQ",
  r"All rectangles: $\binom{8}{2} \times \binom{6}{2} = 28 \times 15 = 420$. Squares: a $k \times k$ square fits in $(8 - k)(6 - k)$ places, giving $35 + 24 + 15 + 8 + 3 = 85$. Non-square rectangles: $420 - 85 = 335$.",
  "Subtracting only the unit squares, or reporting the total.",
  "C25C-rectangles-grid", "Two separate counts combined: all rectangles minus all squares.",
  correct=r"$335$",
  distractors=[(r"$385$", "Subtracts only the $35$ unit squares from $420$."),
               (r"$420$", "Reports all rectangles, squares included."),
               (r"$85$", "Reports the number of squares.")],
  check=_m16, values=[335, 385, 420, 85], cognitive="Application", exams=SPEED)


# ---------------------------------------------------------------- DIFFICULT

def _d1():
    return sum(1 for p in itertools.permutations(range(7)) if _fixed(p) <= 2)
q("C25-C-027", T, "Permutations with at most two fixed points", "Difficult",
  "Casework/optimisation",
  r"Seven students hand in their answer sheets, and the teacher returns the sheets at random for peer checking, one sheet to each student. In how many ways can the sheets be returned so that at most two students receive their own sheets?",
  "TITA",
  r"Add the cases. None correct: $D_7 = 1854$. Exactly one: $\binom{7}{1} D_6 = 7 \times 265 = 1855$. Exactly two: $\binom{7}{2} D_5 = 21 \times 44 = 924$. Total $1854 + 1855 + 924 = 4633$. (The derangement numbers follow $D_n = (n-1)(D_{n-1} + D_{n-2})$: $2, 9, 44, 265, 1854$.)",
  "Taking only the case where nobody is correct, or forgetting the case of exactly two.",
  "C25C-derangement-exactly-k", "Three cases, each needing a derangement number up to $D_7$.",
  tita_answer=4633, check=_d1,
  tita_traps=[(1854, "Counts only the case where no one gets their own sheet."),
              (3709, "Adds the cases of none and exactly one, missing exactly two.")],
  cognitive="Analysis", exams=SPEED)


def _d2():
    c = 0
    for pos in itertools.combinations(range(12), 6):
        s = set(pos)
        bal, ok = 0, True
        for k in range(12):
            bal += 1 if k in s else -1  # k in s: a Rs. 50 note
            if bal < 0:
                ok = False
                break
        if ok:
            c += 1
    return c
q("C25-C-028", T, "Paths that never cross the diagonal (ticket queue)", "Difficult",
  "Conceptual/application",
  r"Twelve people queue at a ticket counter. A ticket costs Rs. $50$. Six of them pay with a single Rs. $50$ note and six with a single Rs. $100$ note. The cashier starts with no money and can give change only from notes already received. Considering only the sequence of note types in the queue (not which person is where), in how many sequences can the cashier give change to everyone who needs it, at the moment they pay?",
  "MCQ",
  r"Write each Rs. $50$ payer as an up step and each Rs. $100$ payer as a down step. The cashier always has change exactly when the path never goes below the starting level. Of the $\binom{12}{6} = 924$ sequences, the bad ones are counted by reflecting the part of the path after the first time it reaches level $-1$ (swapping up and down steps from there on). The reflected path ends at level $-2$, so this matches the bad sequences one to one with sequences of $5$ up and $7$ down steps: $\binom{12}{5} = 792$. So $924 - 792 = 132$, which is $\frac{1}{7}\binom{12}{6}$.",
  "Dividing by $n$ in place of $n + 1$, or reporting the number of bad sequences.",
  "C25C-catalan-paths", "Needs the reflection principle or recognising the Catalan number.",
  correct=r"$132$",
  distractors=[(r"$154$", "Divides $\\binom{12}{6}$ by $6$ in place of $7$."),
               (r"$792$", "Reports the number of sequences in which the cashier runs out of change."),
               (r"$924$", "Counts all orders of six notes of each type without the change condition.")],
  check=_d2, values=[132, 154, 792, 924], cognitive="Analysis", exams=SPEED)


def _d3():
    return sum(1 for x in range(5) for y in range(6) for z in range(10) if x + y + z == 11)
q("C25-C-029", T, "Solutions with different upper bounds needing inclusion and exclusion with an overlap", "Difficult",
  "Casework/optimisation",
  r"An aptitude test has three sections carrying $4$, $5$ and $9$ marks respectively. A candidate's score in each section is an integer from $0$ up to that section's maximum. How many different ordered triples of section scores give a total of exactly $11$?",
  "TITA",
  r"Without caps, $x + y + z = 11$ has $\binom{13}{2} = 78$ solutions. Remove those with $x \ge 5$: $\binom{8}{2} = 28$; with $y \ge 6$: $\binom{7}{2} = 21$; with $z \ge 10$: $\binom{3}{2} = 3$. Add back $x \ge 5$ and $y \ge 6$ together, which forces $x = 5$, $y = 6$, $z = 0$: $1$ solution; no other pair of violations fits in a total of $11$. Answer $78 - 28 - 21 - 3 + 1 = 27$.",
  "Forgetting to add back the overlap, or assuming the caps cannot bind after a complement substitution.",
  "C25C-solutions-upper-bound", "Three unequal caps, two of which can be broken together, so full inclusion and exclusion with an overlap is needed.",
  tita_answer=27, check=_d3,
  tita_traps=[(26, "Subtracts the three violation counts but does not add back the $1$ solution breaking two caps."),
              (78, "Ignores the section caps and uses $\\binom{13}{2}$."),
              (36, "Counts marks lost, $a + b + c = 7$, as $\\binom{9}{2}$, assuming the caps hold automatically.")],
  cognitive="Analysis", exams=SPEED)


def _d4():
    # boys 0..4 (Rahul 0, Kabir 1), girls 5..9 (Meera 5)
    def ok(s, pos):
        if not all((s[k] < 5) != (s[(k + 1) % 10] < 5) for k in range(10)):
            return False
        return _adj(pos[5], pos[0], 10) and not _adj(pos[5], pos[1], 10)
    return _seat_count(10, ok)
q("C25-C-030", T, "Alternating circular seating with an adjacency and a non-adjacency condition", "Difficult",
  "Casework/optimisation",
  r"Five boys, including Rahul and Kabir, and five girls, including Meera, sit around a circular table with ten identical, unnumbered chairs so that boys and girls alternate. Seatings that differ only by a rotation are the same. In how many seatings does Meera sit next to Rahul but not next to Kabir?",
  "MCQ",
  r"Seat the boys first: $4! = 24$ circular orders, and in $2 \times 3! = 12$ of them Rahul and Kabir are neighbours. If they are neighbours, only $1$ of the $2$ gaps beside Rahul avoids Kabir; otherwise both gaps do. So Meera has $12 \times 1 + 12 \times 2 = 36$ choices in total over the boy orders, and the other $4$ girls fill the remaining gaps in $4! = 24$ ways. Total $36 \times 24 = 864$.",
  "Overlooking the boy orders in which Rahul and Kabir are neighbours.",
  "C25C-circular-alternate", "Casework on whether two boys are adjacent, inside an alternating circular count.",
  correct=r"$864$",
  distractors=[(r"$1152$", "Always gives Meera $2$ gaps beside Rahul, overlooking the orders where Kabir is beside Rahul."),
               (r"$576$", "Always gives Meera only $1$ gap, as if Kabir were always beside Rahul."),
               (r"$432$", "Divides by $2$ for turning the arrangement over, as for a necklace.")],
  check=_d4, values=[864, 1152, 576, 432], cognitive="Analysis", exams=SPEED)


def _d5():
    import random
    rnd = random.Random(7)
    n = 10
    ang = sorted(rnd.uniform(0, 2 * math.pi) for _ in range(n))
    P = [(math.cos(a), math.sin(a)) for a in ang]
    diags = [(i, j) for i, j in itertools.combinations(range(n), 2) if not _adj(i, j, n)]
    on = {d: 0 for d in diags}
    pts = set()
    for (a, b), (c, d) in itertools.combinations(diags, 2):
        if len({a, b, c, d}) < 4:
            continue
        x1, y1 = P[a]; x2, y2 = P[b]; x3, y3 = P[c]; x4, y4 = P[d]
        den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if abs(den) < 1e-12:
            continue
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den
        if 1e-9 < t < 1 - 1e-9 and 1e-9 < u < 1 - 1e-9:
            pts.add((round(x1 + t * (x2 - x1), 9), round(y1 + t * (y2 - y1), 9)))
            on[(a, b)] += 1
            on[(c, d)] += 1
    V = n + len(pts)
    E = n + sum(k + 1 for k in on.values())
    return E - V + 1  # Euler: V - E + F = 2, minus the outer face
q("C25-C-031", T, "Regions formed inside a convex polygon by all its diagonals", "Difficult",
  "Conceptual/application",
  r"All the diagonals of a convex decagon are drawn. No three diagonals pass through the same point inside the decagon. Into how many regions do the diagonals divide the interior of the decagon?",
  "TITA",
  r"Draw the diagonals one at a time. A new diagonal that crosses $k$ diagonals already drawn is cut into $k + 1$ pieces, and each piece splits one region into two, so it adds $k + 1$ regions. Starting from $1$ region, the total is $1 + (\text{number of diagonals}) + (\text{number of crossing points})$. A decagon has $\frac{10 \times 7}{2} = 35$ diagonals, and each set of $4$ vertices gives exactly one crossing, so there are $\binom{10}{4} = 210$ crossings. Regions $= 1 + 35 + 210 = 246$.",
  "Leaving out the starting region, counting only crossing points, or including the region outside the decagon.",
  "C25C-diagonal-regions", "Needs both the crossing count $\\binom{n}{4}$ and an incremental or Euler-formula argument for regions.",
  tita_answer=246, check=_d5,
  tita_traps=[(245, "Adds diagonals and crossings, $35 + 210$, but forgets the starting region."),
              (210, "Reports the number of crossing points, $\\binom{10}{4}$."),
              (247, "Uses Euler's formula $F = E - V + 2$ and keeps the region outside the decagon.")],
  cognitive="Analysis", exams=SPEED)


def _d6():
    return _paths(5, 5, avoid=[(2, 2), (3, 3)])
q("C25-C-032", T, "Shortest grid routes avoiding two intersections", "Difficult",
  "Casework/optimisation",
  r"On a square street grid, Joseph walks from crossing P to crossing Q, which is $5$ blocks east and $5$ blocks north of P, moving only one block east or one block north at a time. Roadworks close two crossings: the one $2$ blocks east and $2$ blocks north of P, and the one $3$ blocks east and $3$ blocks north of P. How many routes avoid both closed crossings?",
  "MCQ",
  r"All routes: $\binom{10}{5} = 252$. Through the first closed crossing: $\binom{4}{2}\binom{6}{3} = 6 \times 20 = 120$. Through the second: $\binom{6}{3}\binom{4}{2} = 120$. Through both: $\binom{4}{2} \times \binom{2}{1} \times \binom{4}{2} = 6 \times 2 \times 6 = 72$. By inclusion and exclusion, $252 - 120 - 120 + 72 = 84$.",
  "Not adding back the routes through both closed crossings.",
  "C25C-grid-paths-via-avoid", "Inclusion and exclusion over two forbidden points with three-stage products.",
  correct=r"$84$",
  distractors=[(r"$12$", "Subtracts $120 + 120$ but does not add back the $72$ routes through both."),
               (r"$132$", "Subtracts the routes through only one of the closed crossings, $252 - 120$."),
               (r"$180$", "Subtracts only the $72$ routes through both closed crossings.")],
  check=_d6, values=[84, 12, 132, 180], cognitive="Analysis", exams=SPEED)


def _d7():
    return sum(1 for x in range(22) for y in range(22) for z in range(22) if x + y + z == 21 and len({x, y, z}) == 3)
q("C25-C-033", T, "Ordered non-negative solutions with all three values different", "Difficult",
  "Casework/optimisation",
  r"How many ordered triples $(x, y, z)$ of non-negative integers satisfy $x + y + z = 21$ with $x$, $y$ and $z$ all different from one another?",
  "MCQ",
  r"All non-negative solutions: $\binom{23}{2} = 253$. Solutions with $x = y$: $2x + z = 21$ gives $x = 0, 1, \ldots, 10$, that is $11$; likewise $11$ with $y = z$ and $11$ with $x = z$. The triple $(7, 7, 7)$ lies in all three sets, so by inclusion and exclusion at least two values are equal in $3 \times 11 - 3 \times 1 + 1 = 31$ solutions. Hence $253 - 31 = 222$ have all values different.",
  "Subtracting $3 \\times 11$ without correcting for the triple with all three values equal.",
  "C25C-solutions-distinct", "Inclusion and exclusion over three equality conditions, with the all-equal triple as the overlap trap.",
  correct=r"$222$",
  distractors=[(r"$220$", "Subtracts $3 \\times 11 = 33$, removing $(7, 7, 7)$ three times."),
               (r"$242$", "Removes only the $11$ solutions with $x = y$, forgetting the other two equal pairs."),
               (r"$37$", "Divides $222$ by $3! = 6$, counting unordered sets of three different values.")],
  check=_d7, values=[222, 220, 242, 37], cognitive="Analysis", exams=SPEED)


def _d8():
    F = Fraction
    P, Q, R = (F(0), F(0)), (F(12), F(0)), (F(4), F(9))
    def lerp(u, v, t):
        return (u[0] + (v[0] - u[0]) * t, u[1] + (v[1] - u[1]) * t)
    segs = [(P, Q), (P, R), (Q, R)]
    segs += [(P, lerp(Q, R, F(k, 3))) for k in (1, 2)]
    segs += [(Q, lerp(P, R, F(k, 4))) for k in (1, 2, 3)]
    def inter(s1, s2):
        (x1, y1), (x2, y2) = s1; (x3, y3), (x4, y4) = s2
        den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if den == 0:
            return None
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den
        if 0 <= t <= 1 and 0 <= u <= 1:
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
        return None
    c = 0
    for a, b, d in itertools.combinations(segs, 3):
        p1, p2, p3 = inter(a, b), inter(b, d), inter(a, d)
        if None in (p1, p2, p3) or len({p1, p2, p3}) < 3:
            continue
        c += 1
    return c
q("C25-C-034", T, "Triangles in a triangle cut by lines from two vertices", "Difficult",
  "Conceptual/application",
  r"In triangle PQR, two line segments are drawn from P to two different interior points of side QR, and three line segments are drawn from Q to three different interior points of side PR. Counting every triangle in the resulting figure whose three sides lie along drawn segments (the sides of PQR included), how many triangles are there?",
  "MCQ",
  r"The figure uses $8$ lines: through P go PQ, PR and the $2$ segments from P; through Q go QP, QR and the $3$ segments from Q. Any $3$ of these lines that are not concurrent bound a triangle in the figure, because every line through P (other than PQ) meets every line through Q (other than PQ) inside or on the triangle. Of the $\binom{8}{3} = 56$ triples, $\binom{4}{3} = 4$ meet at P and $\binom{5}{3} = 10$ meet at Q, and no other point lies on three lines. So there are $56 - 4 - 10 = 42$ triangles.",
  "Removing only one family of concurrent triples, or ignoring concurrency altogether.",
  "C25C-cevian-triangles", "Counting via triples of lines minus concurrent triples needs a careful model.",
  correct=r"$42$",
  distractors=[(r"$56$", "Counts every triple of lines, ignoring that some meet at a single point."),
               (r"$46$", "Removes the $10$ triples through Q but not the $4$ through P."),
               (r"$30$", "Leaves out every triangle with PQ as a side, counting only those with two sides through P or two through Q: $\\binom{3}{2} \\times 4 + 3 \\times \\binom{4}{2} = 12 + 18$.")],
  check=_d8, values=[42, 56, 46, 30], cognitive="Analysis", exams=SPEED)


def _d9():
    return _seat_count(8, lambda s, pos: not any(_adj(pos[2 * k], pos[2 * k + 1], 8) for k in range(4)))
q("C25-C-035", T, "Circular seating of couples with no couple adjacent", "Difficult",
  "Casework/optimisation",
  r"Four married couples sit around a circular table with eight identical, unnumbered chairs. Seatings that differ only by a rotation are the same, and there is no rule about men and women alternating. In how many seatings does no husband sit next to his own wife?",
  "MCQ",
  r"Use inclusion and exclusion over the couples. If $k$ chosen couples are each tied into a block, there are $8 - k$ units in a circle, giving $(7 - k)! \times 2^k$ seatings. So the count is $7! - \binom{4}{1} 2 \cdot 6! + \binom{4}{2} 4 \cdot 5! - \binom{4}{3} 8 \cdot 4! + \binom{4}{4} 16 \cdot 3! = 5040 - 5760 + 2880 - 768 + 96 = 1488$.",
  "Forgetting the factor $2^k$ for the order within each tied couple, or stopping the inclusion and exclusion early.",
  "C25C-circular-incl-excl", "Full four-term inclusion and exclusion on a circle.",
  correct=r"$1488$",
  distractors=[(r"$2160$", "Stops after the terms for one and two couples, $5040 - 5760 + 2880$."),
               (r"$1392$", "Leaves out the final term, the one with all four couples tied."),
               (r"$2790$", "Omits the factor $2^k$ for the order inside each tied couple.")],
  check=_d9, values=[1488, 2160, 1392, 2790], cognitive="Analysis", exams=SPEED)
