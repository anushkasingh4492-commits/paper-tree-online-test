import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Averages basics"
CX = ("CAT", "XAT")


def _avg(xs):
    xs = list(xs)
    return F(sum(xs), len(xs))


# ================================================================ EASY (11)

def _c1():
    w = symbols('w')
    n, a, rise = 28, 39, F(3, 2)
    return solve(Eq((n * a + w) / (n + 1), a + rise), w)[0]
q("C05-A-001", T, "Value of a member who joins a group, from the rise in the average", "Easy",
  "Single-step computation",
  r"The average weight of the $28$ students in a class is $39$ kg. When the weight of the class teacher is also included, the average weight rises by $1.5$ kg. What is the weight of the class teacher?",
  "MCQ",
  r"The new average is $40.5$ kg for $29$ people. The teacher must bring his own share of $40.5$ kg and also lift each of the $28$ students' average by $1.5$ kg, so his weight is $40.5 + 28 \times 1.5 = 40.5 + 42 = 82.5$ kg. Check: $29 \times 40.5 - 28 \times 39 = 1174.5 - 1092 = 82.5$.",
  "Adding the rise for the wrong number of people, or starting from the old average instead of the new one.",
  "C05A-add-one-member", "One idea (new average plus the rise spread over the old members); the trap is the count used with the rise.",
  correct=r"$82.5$ kg",
  distractors=[(r"$81$ kg", r"Uses the old average with $28$ people: $39 + 28 \times 1.5 = 81$."),
               (r"$84$ kg", r"Uses the new average with $29$ people: $40.5 + 29 \times 1.5 = 84$."),
               (r"$79.5$ kg", r"Off by one in the count: $39 + 27 \times 1.5 = 79.5$.")],
  check=_c1, values=[F(165, 2), 81, 84, F(159, 2)], cognitive="Application")


def _c2():
    x = symbols('x')
    return solve(Eq((16 * 1250 - x) / 15, 1230), x)[0]
q("C05-A-002", T, "Value of a member who leaves, from the fall in the average", "Easy",
  "Single-step computation",
  r"The average monthly electricity bill of the $16$ households in a building is Rs. $1{,}250$. One household moves out, and the average monthly bill of the remaining $15$ households is Rs. $1{,}230$. What is the monthly bill, in rupees, of the household that moved out?",
  "TITA",
  r"Total before $= 16 \times 1250 = 20000$; total after $= 15 \times 1230 = 18450$. The household that left paid $20000 - 18450 = 1550$ rupees. (Fast route: it is $1250 + 15 \times 20 = 1550$, the old average plus the $20$ rupee drop for each of the $15$ who stay.)",
  "Multiplying the drop by the wrong count or starting from the wrong average.",
  "C05A-remove-members", "Two products and a subtraction; the trap is the count multiplying the drop.",
  tita_answer=1550, check=_c2,
  tita_traps=[(1530, r"Uses the new average: $1230 + 15 \times 20$."), (1570, r"Uses $16$ households with the old average: $1250 + 16 \times 20$.")],
  cognitive="Application")


def _c3():
    ws = [F(50 + i) for i in range(9)] + [F(58)]       # any 10 weights containing 58
    old = _avg(ws)
    x = symbols('x')
    newv = solve(Eq((sum(ws) - 58 + x) / 10, old + F(3, 2)), x)[0]
    return newv
q("C05-A-003", T, "Replacing one member raises the average; value of the newcomer", "Easy",
  "Conceptual/application",
  r"A rowing crew has $10$ members. When one member weighing $58$ kg is replaced by a new member, the average weight of the crew increases by $1.5$ kg. What is the weight of the new member?",
  "MCQ",
  r"The total weight of the crew rises by $10 \times 1.5 = 15$ kg, and the only change in the total is the swap. So the new member is $15$ kg heavier than the one replaced: $58 + 15 = 73$ kg.",
  "Adding only the change in average, or subtracting the change in total.",
  "C05A-replace-members", "One step once the change in total is seen; trap is adding $1.5$ instead of $15$.",
  correct=r"$73$ kg",
  distractors=[(r"$59.5$ kg", r"Adds only the rise in the average, $58 + 1.5$."),
               (r"$43$ kg", r"Subtracts the rise in the total, $58 - 15$, as if the average had fallen."),
               (r"$74.5$ kg", r"Multiplies the rise by $11$, counting the new member as an extra person: $58 + 11 \times 1.5$.")],
  check=_c3, values=[73, F(119, 2), 43, F(149, 2)], cognitive="Understanding")


def _c4():
    d = symbols('d')
    four_then = 4 * 24
    four_now = four_then + 4 * 6
    return solve(Eq((four_now + d) / 5, 25), d)[0]
q("C05-A-004", T, "Child born into a family: age from averages at two times", "Easy",
  "Multi-step word problem",
  r"Six years ago, the average age of the four members of the Menon family was $24$ years. Since then a daughter has been born and nobody has left the family. Today the average age of the five members is $25$ years. How old is the daughter today, in years?",
  "TITA",
  r"Six years ago the four members together were $4 \times 24 = 96$ years old, so today they total $96 + 4 \times 6 = 120$ years. The five members today total $5 \times 25 = 125$ years, so the daughter is $125 - 120 = 5$ years old.",
  "Forgetting that each of the four older members has aged six years.",
  "C05A-age-birth-death", "Two totals and the ageing of the old members; one trap.",
  tita_answer=5, check=_c4,
  tita_traps=[(29, r"Forgets the ageing: $125 - 96$."), (23, r"Adds the $6$ years only once instead of once per member: $125 - (96 + 6)$.")],
  cognitive="Application")


def _c5():
    for s in range(0, 200, 2):
        xs = [s + 2 * i for i in range(13)]
        if _avg(xs) == 58:
            return max(xs)
q("C05-A-005", T, "Largest of consecutive even numbers from their average", "Easy",
  "Conceptual/application",
  r"The average of $13$ consecutive even numbers is $58$. What is the largest of these numbers?",
  "MCQ",
  r"For an odd count of equally spaced numbers, the average is the middle (7th) number, $58$. The largest is $6$ steps of $2$ above it: $58 + 12 = 70$.",
  "Counting the wrong number of steps from the middle term to the end.",
  "C05A-consecutive-odd-even", "Average equals the middle term; one counting trap.",
  correct=r"$70$",
  distractors=[(r"$72$", r"Counts $7$ steps from the middle instead of $6$: $58 + 14$."),
               (r"$82$", r"Adds the whole span $2 \times 12 = 24$ to the average, as if the average were the smallest number."),
               (r"$46$", r"Reports the smallest number, $58 - 12$.")],
  check=_c5, values=[70, 72, 82, 46], cognitive="Understanding")


def _c6():
    return _avg([k for k in range(101, 400) if k % 9 == 0])
q("C05-A-006", T, "Average of all multiples of a number lying in a range", "Easy",
  "Multi-step word problem",
  r"What is the average of all the multiples of $9$ that lie between $100$ and $400$?",
  "MCQ",
  r"The multiples run from $9 \times 12 = 108$ to $9 \times 44 = 396$ in equal steps, so their average is the average of the first and last: $\frac{108 + 396}{2} = 252$.",
  "Using the ends of the range, or a multiple that lies outside the range, as the first or last term.",
  "C05A-multiples-in-range", "Average of an arithmetic sequence after locating its end terms; trap is the boundary.",
  correct=r"$252$",
  distractors=[(r"$250$", r"Averages the range ends, $\frac{100 + 400}{2}$."),
               (r"$247.5$", r"Starts at $99$, which is below $100$: $\frac{99 + 396}{2}$."),
               (r"$256.5$", r"Ends at $405$, which is above $400$: $\frac{108 + 405}{2}$.")],
  check=_c6, values=[252, 250, F(495, 2), F(513, 2)], cognitive="Application")


def _c7():
    total = 25 * 52
    total = total - 87 + 37
    return F(total, 25)
q("C05-A-007", T, "Correcting an average after one wrongly entered value", "Easy",
  "Single-step computation",
  r"The average marks of the $25$ students in a class were calculated as $52$. It was later found that one student's marks of $37$ had been entered as $87$. What is the correct average mark of the class, in marks?",
  "TITA",
  r"The total was overstated by $87 - 37 = 50$, so the average was overstated by $\frac{50}{25} = 2$. The correct average is $52 - 2 = 50$.",
  "Adjusting in the wrong direction, or reporting the size of the adjustment.",
  "C05A-misentered-values", "One correction to the total; trap is the direction.",
  tita_answer=50, check=_c7,
  tita_traps=[(54, r"Adds the correction instead of subtracting it."), (2, r"Reports the change in the average instead of the corrected average.")],
  cognitive="Application")


def _c8():
    wages = [400, 420, 440, 460, 470, 480, 480, 490, 500, 520, 540, 560]
    assert _avg(wages) == 480
    new = [F(w) * F(11, 10) + 20 for w in wages]
    return _avg(new)
q("C05-A-008", T, "Average after every member is scaled and then shifted", "Easy",
  "Conceptual/application",
  r"The average daily wage of the $12$ workers in a workshop is Rs. $480$. Every worker's daily wage is first increased by $10\%$, and then a further Rs. $20$ per day is added to each increased wage. What is the new average daily wage?",
  "MCQ",
  r"Scaling every value scales the average, and adding the same amount to every value adds it to the average. New average $= 480 \times 1.1 + 20 = 528 + 20 = 548$ rupees.",
  "Applying only one of the two changes, or applying them in the wrong order.",
  "C05A-transform-members", "Average follows a linear change applied to every member; trap is the order of operations.",
  correct=r"Rs. $548$",
  distractors=[(r"Rs. $528$", r"Applies the $10\%$ increase but forgets the Rs. $20$."),
               (r"Rs. $500$", r"Adds the Rs. $20$ but forgets the $10\%$ increase."),
               (r"Rs. $550$", r"Adds the Rs. $20$ first and then increases by $10\%$: $500 \times 1.1$.")],
  check=_c8, values=[548, 528, 500, 550], cognitive="Understanding")


def _c9():
    # brute: pick Thursday, then the remaining sums are forced; verify consistency
    for th in range(0, 60):
        a = 116 - th          # Mon+Tue+Wed
        b = 132 - th          # Fri+Sat+Sun
        if a + b + th == 210:
            return th
q("C05-A-009", T, "Overlapping averages of a week: the shared day", "Easy",
  "Multi-step word problem",
  r"In a certain week, the average maximum temperature from Monday to Thursday was $29$ degrees Celsius, the average from Thursday to Sunday was $33$ degrees Celsius, and the average for the whole week (Monday to Sunday) was $30$ degrees Celsius. What was the maximum temperature on Thursday, in degrees Celsius?",
  "TITA",
  r"Monday to Thursday total $4 \times 29 = 116$; Thursday to Sunday total $4 \times 33 = 132$. Together these count every day once and Thursday twice, so Thursday $= 116 + 132 - 7 \times 30 = 248 - 210 = 38$.",
  "Averaging the two partial averages, or forgetting that Thursday is counted in both groups.",
  "C05A-overlapping-groups", "Two totals and one subtraction; the trap is not spotting the double count.",
  tita_answer=38, check=_c9,
  tita_traps=[(31, r"Averages the two averages $29$ and $33$."), (30, r"Reports the weekly average.")],
  cognitive="Application")



def _c10():
    m = symbols('m')
    first = [m - 4 + 2 * i for i in range(5)]
    nxt = [first[-1] + 2 * i for i in range(1, 5)]
    assert simplify(sum(first) / 5 - m) == 0
    return simplify(sum(first + nxt) / 9)
_m = symbols('m')
q("C05-A-010", T, "Average after the next few consecutive odd numbers are included", "Easy",
  "Conceptual/application",
  r"The average of five consecutive odd numbers is $m$. If the next four consecutive odd numbers are also included, what is the average of all nine numbers?",
  "MCQ",
  r"The five numbers are $m - 4, m - 2, m, m + 2, m + 4$, and the next four are $m + 6, m + 8, m + 10, m + 12$. The nine numbers are consecutive odd numbers from $m - 4$ to $m + 12$, so their average is the middle (5th) one, $m + 4$.",
  "Averaging the two group averages although the groups have different sizes.",
  "C05A-consecutive-odd-even", "Seeing the nine numbers as one equally spaced run; trap is averaging averages.",
  correct=r"$m + 4$",
  distractors=[(r"$m + 4.5$", r"Averages the two group averages, $m$ and $m + 9$, with equal weight."),
               (r"$m + 9$", r"Reports the average of only the four new numbers."),
               (r"$m + 8$", r"Assumes each new number raises the average by $2$: $m + 4 \times 2$.")],
  check=_c10, values=[_m + 4, _m + F(9, 2), _m + 9, _m + 8], cognitive="Understanding")


def _c11():
    s = symbols('s')
    tot = solve(Eq((11 * 68 + s) / 13, 69), s)[0]
    return tot / 2
q("C05-A-011", T, "Average of two members who join a group, from the new average", "Easy",
  "Multi-step word problem",
  r"The average weight of the $11$ players in a football team is $68$ kg. Two new players join the squad, and the average weight of all $13$ players becomes $69$ kg. What is the average weight of the two new players?",
  "MCQ",
  r"The total rises from $11 \times 68 = 748$ kg to $13 \times 69 = 897$ kg, so the two newcomers weigh $149$ kg together, an average of $74.5$ kg. (Fast route: they share $69 \times 2$ plus the $11 \times 1 = 11$ kg needed to lift the old players, so each averages $69 + 5.5$.)",
  "Giving all of the extra weight needed to each newcomer, or using the wrong count.",
  "C05A-add-several-members", "Two totals and a division by two; trap is how the extra is shared.",
  correct=r"$74.5$ kg",
  distractors=[(r"$73.5$ kg", r"Shares the extra $11$ kg between the two newcomers but starts from the old average: $68 + \frac{11}{2}$."),
               (r"$80$ kg", r"Gives each newcomer the whole extra $11$ kg: $69 + 11$."),
               (r"$69$ kg", r"Assumes the two newcomers average the same as the new team average, ignoring the $11$ kg needed to lift the original players.")],
  check=_c11, values=[F(149, 2), F(147, 2), 80, 69], cognitive="Application")


# ================================================================ MEDIUM (15)

def _c12():
    # simulate: ages at formation with average 27, then 5 years, then swap
    ages = [22, 24, 26, 28, 30, 32]
    assert _avg(ages) == 27
    ages = [a + 5 for a in ages]
    leaver = ages[0]
    x = symbols('x')
    newcomer = solve(Eq((sum(ages) - leaver + x) / 6, 30), x)[0]
    return leaver - newcomer
q("C05-A-012", T, "Member replaced after some years: age gap between leaver and newcomer", "Medium",
  "Multi-step word problem",
  r"When a music band of $6$ members was formed, the average age of its members was $27$ years. Exactly $5$ years later, one member left and a new member joined at the same time, and the average age of the band became $30$ years. By how many years is the new member younger than the member who left, both ages taken on the day of the change?",
  "MCQ",
  r"After $5$ years, without any change, the average would be $27 + 5 = 32$ years. The swap brought it down to $30$, a fall of $2$ years over $6$ members, so the total fell by $12$ years. Hence the new member is $12$ years younger than the one who left.",
  "Ignoring the ageing of the band over the five years, or not multiplying the change in average by the number of members.",
  "C05A-age-replacement-over-time", "Two ideas: ageing of the whole group, then the replacement effect on the total.",
  correct=r"$12$ years",
  distractors=[(r"$18$ years", r"Ignores the $5$ years of ageing and treats the change from $27$ to $30$ as a change of $3$ in the average: $6 \times 3$."),
               (r"$2$ years", r"Takes the fall in the average, $32 - 30$, without multiplying by $6$."),
               (r"$3$ years", r"Takes the difference $30 - 27$ of the two stated averages as the age gap.")],
  check=_c12, values=[12, 18, 2, 3], cognitive="Application")


def _c13():
    for s in range(1, 200):
        xs = list(range(s, s + 25))
        if _avg(xs) == 63:
            ys = sorted(xs)[8:] + [max(xs) + 1, max(xs) + 2]
            return _avg(ys)
q("C05-A-013", T, "Consecutive integers: removing the smallest few and appending the next few", "Medium",
  "Conceptual/application",
  r"The average of $25$ consecutive natural numbers is $63$. The $8$ smallest of these numbers are removed, and the $2$ natural numbers that immediately follow the largest of the original $25$ numbers are added. What is the average of the resulting set?",
  "MCQ",
  r"The numbers are $51$ to $75$ (the middle one is $63$). Removing $51$ to $58$ and adding $76$ and $77$ leaves the consecutive run $59$ to $77$, whose average is $\frac{59 + 77}{2} = 68$.",
  "Shifting the average by the net change in count, or by the full number of changes, instead of locating the new run.",
  "C05A-consecutive-integers", "Needs the new run's end points; shortcut shifts tempt a wrong value.",
  correct=r"$68$",
  distractors=[(r"$66$", r"Shifts the average by half the net change in count: $63 + \frac{8 - 2}{2}$."),
               (r"$73$", r"Shifts the average by one for every number removed or added: $63 + 8 + 2$."),
               (r"$67$", r"Removes the $8$ smallest but forgets to add the two new numbers: average of $59$ to $75$.")],
  check=_c13, values=[68, 66, 73, 67], cognitive="Analysis")


def _c14():
    total = 30 * 2140
    total += (1580 - 1850) + (960 - 690)
    total += 3690
    return F(total, 31)
q("C05-A-014", T, "Correcting an average for two mis-keyed amounts and one omitted amount", "Medium",
  "Multi-step word problem",
  r"An accounts clerk calculated the average of $30$ invoice amounts as Rs. $2{,}140$. It was later found that an amount of Rs. $1{,}580$ had been keyed in as Rs. $1{,}850$, an amount of Rs. $960$ had been keyed in as Rs. $690$, and one more invoice of Rs. $3{,}690$ from the same set had been left out altogether. What is the correct average, in rupees, of all $31$ invoices?",
  "TITA",
  r"The first slip overstated the total by $270$ and the second understated it by $270$, so they cancel and the $30$ amounts correctly total $30 \times 2140 = 64200$. Adding the missed invoice gives $64200 + 3690 = 67890$, and $\frac{67890}{31} = 2190$. (Fast route: the new invoice is $3690 - 2140 = 1550$ above the old average, which lifts the average by $\frac{1550}{31} = 50$.)",
  "Dividing by the old count after adding a member, or ignoring the omitted invoice once the two slips cancel.",
  "C05A-misentered-values", "Three corrections, two of which cancel, followed by a change of count.",
  tita_answer=2190, check=_c14,
  tita_traps=[(2263, r"Divides the corrected total $67890$ by $30$ instead of $31$."), (2140, r"Notices the two slips cancel but forgets the omitted invoice.")],
  exams=CX, cognitive="Application")


def _c15():
    for n in range(1, 500):
        if F(38 * n + 98, n + 1) == 41:
            return n + 1
q("C05-A-015", T, "Number of innings from the rise in a batting average after one score", "Medium",
  "Inverse/parameter",
  r"Kabir's batting average (total runs divided by the number of innings) after a certain number of innings was $38$. In his next innings he scored $98$ runs, which raised his batting average to $41$. How many innings has he played in all, including the innings in which he scored $98$?",
  "TITA",
  r"Let $n$ be the number of innings before the $98$. Then $38n + 98 = 41(n + 1)$, so $3n = 57$ and $n = 19$. Including the latest innings he has played $20$ innings. (Insight: $98$ is $57$ above the new average $41$, and that excess lifts each of the $19$ earlier innings by $3$.)",
  "Reporting the number of innings before the last one.",
  "C05A-running-average", "Set up one linear equation in the count; trap is which count is asked.",
  tita_answer=20, check=_c15,
  tita_traps=[(19, r"Reports the number of innings before the $98$."), (57, r"Reports the excess $98 - 41$.")],
  cognitive="Application")


def _c16():
    a, d = symbols('a d')
    def avg_first(n):
        return sum(a + k * d for k in range(n)) / n
    sol = solve([Eq(avg_first(40), 83), Eq(avg_first(20), 43)], [a, d], dict=True)[0]
    return (a + 59 * d).subs(sol)
q("C05-A-016", T, "Term of an arithmetic progression from averages of its first terms", "Medium",
  "Multi-step word problem",
  r"The average of the first $40$ terms of an arithmetic progression is $83$, and the average of its first $20$ terms is $43$. What is the $60$th term of the progression?",
  "MCQ",
  r"The average of the first $n$ terms is $a + \frac{(n - 1)d}{2}$. So $a + 19.5d = 83$ and $a + 9.5d = 43$, giving $10d = 40$, $d = 4$, $a = 5$. The $60$th term is $5 + 59 \times 4 = 241$.",
  r"Using $a + \frac{nd}{2}$ for the average, or confusing the $60$th term with the average of the first $60$.",
  "C05A-ap-averages", "Average of an AP as the middle term, then two equations.",
  correct=r"$241$",
  distractors=[(r"$239$", r"Uses $a + \frac{nd}{2}$ as the average: $d = 4$, $a = 3$, then $3 + 59 \times 4$."),
               (r"$245$", r"Writes the $60$th term as $a + 60d = 5 + 240$."),
               (r"$123$", r"Finds the average of the first $60$ terms, $5 + 29.5 \times 4$, instead of the $60$th term.")],
  check=_c16, values=[241, 239, 245, 123], exams=CX, cognitive="Application")


def _c17():
    x, y = symbols('x y')
    sol = solve([Eq(12 * 50 - x - y, 10 * 48), Eq(x - y, 14)], [x, y], dict=True)[0]
    return sol[x]
q("C05-A-017", T, "Two members removed: recovering them from their sum and difference", "Medium",
  "Inverse/parameter",
  r"The average weight of $12$ parcels is $50$ kg. Two parcels are taken away, and the average weight of the remaining parcels becomes $48$ kg. If one of the two parcels taken away is $14$ kg heavier than the other, what is the weight of the heavier parcel?",
  "MCQ",
  r"The two parcels removed weigh $12 \times 50 - 10 \times 48 = 600 - 480 = 120$ kg together. With a difference of $14$ kg, the heavier one is $\frac{120 + 14}{2} = 67$ kg.",
  "Taking $11$ parcels as remaining, or adding the whole difference to the average of the pair.",
  "C05A-remove-members", "Sum of the removed pair from totals, then sum and difference.",
  correct=r"$67$ kg",
  distractors=[(r"$74$ kg", r"Adds the full difference to the pair's average: $60 + 14$."),
               (r"$43$ kg", r"Uses $11$ remaining parcels: removed sum $600 - 528 = 72$, then $\frac{72 + 14}{2}$."),
               (r"$53$ kg", r"Reports the lighter parcel.")],
  check=_c17, values=[67, 74, 43, 53], cognitive="Application")


def _c18():
    # simulate the family year by year (ages as of today = year 0; eight years ago = year -8)
    total_8_ago = 6 * 31
    grandma_at_death, years_since_death = 77, 2
    grandma_8_ago = grandma_at_death - (8 - years_since_death)
    others_now = total_8_ago - grandma_8_ago + 5 * 8
    baby_now = 1
    return F(others_now + baby_now, 6)
q("C05-A-018", T, "Family average age after a death and a birth over the years", "Medium",
  "Multi-step word problem",
  r"Eight years ago, the average age of the six members of the Iyer family was $31$ years. Exactly two years ago, the grandmother died at the age of $77$. Exactly one year ago, a baby was born into the family. There have been no other changes in the family. What is the average age, in years, of the six members of the family today?",
  "TITA",
  r"Eight years ago the grandmother was $77 - 6 = 71$, so the other five then totalled $6 \times 31 - 71 = 115$ years. Today those five total $115 + 5 \times 8 = 155$ years, and with the one year old baby the six total $156$ years. The average is $\frac{156}{6} = 26$ years.",
  "Removing the grandmother's age at death instead of her age at the earlier date.",
  "C05A-age-birth-death", "Three time-shifted adjustments to one total.",
  tita_answer=26, check=_c18,
  tita_traps=[(25, r"Subtracts her age at death, $77$, from the total of eight years ago: $\frac{186 - 77 + 40 + 1}{6}$."), (31, r"Forgets the baby and averages the five survivors: $\frac{155}{5}$.")],
  cognitive="Application")


def _c19():
    r = symbols('r1:11')
    sol = solve([Eq(sum(r), 400), Eq(sum(r[:4]), 144), Eq(sum(r[6:]), 180), Eq(r[4] - r[5], 6)],
                [r[4], r[5], r[0], r[6]], dict=True)[0]
    return sol[r[4]]
q("C05-A-019", T, "Averages of the first and last few days leave a gap: recovering the middle days", "Medium",
  "Multi-step word problem",
  r"Over $10$ consecutive days, the average daily rainfall at a station was $40$ mm. The average for the first $4$ days was $36$ mm and the average for the last $4$ days was $45$ mm. The rainfall on the $5$th day was $6$ mm more than on the $6$th day. What was the rainfall on the $5$th day?",
  "MCQ",
  r"The $5$th and $6$th days together had $10 \times 40 - 4 \times 36 - 4 \times 45 = 400 - 144 - 180 = 76$ mm. With a difference of $6$ mm, the $5$th day had $\frac{76 + 6}{2} = 41$ mm.",
  "Adding the whole difference to the average of the two days, or reporting the other day.",
  "C05A-overlapping-groups", "Subtracting partial totals to isolate two days, then sum and difference.",
  correct=r"$41$ mm",
  distractors=[(r"$44$ mm", r"Adds the full difference to the two days' average: $38 + 6$."),
               (r"$35$ mm", r"Reports the $6$th day's rainfall."),
               (r"$38$ mm", r"Reports the average of the $5$th and $6$th days.")],
  check=_c19, values=[41, 44, 35, 38], cognitive="Application")


def _c20():
    found = []
    for n in range(2, 3000):
        tot = n * (n + 1) // 2
        for x in range(1, n + 1):
            if F(tot - x, n - 1) == F(131, 5):
                found.append(x)
    assert len(found) == 1
    return found[0]
q("C05-A-020", T, "One card lost from cards numbered 1 to n: recovering n and the lost number from the new average", "Difficult",
  "Inverse/parameter",
  r"A pack contains cards numbered $1, 2, 3, \ldots, n$, one card for each number. One card is lost, and the average of the numbers on the remaining cards is $26.2$. What is the number on the lost card?",
  "TITA",
  r"Removing one card from $1$ to $n$ leaves an average between $\frac{n}{2}$ (largest card lost) and $\frac{n + 2}{2}$ (card $1$ lost), so $\frac{n}{2} \le 26.2 \le \frac{n + 2}{2}$, giving $n = 51$ or $52$. The $n - 1$ remaining cards total $26.2(n - 1) = \frac{131(n - 1)}{5}$, a whole number, so $n - 1$ is a multiple of $5$ and $n = 51$. The remaining $50$ cards total $50 \times 26.2 = 1310$, while all $51$ cards total $\frac{51 \times 52}{2} = 1326$, so the lost card is $1326 - 1310 = 16$.",
  "Fixing $n$ by doubling the average and rounding, without using the fact that the remaining total must be a whole number.",
  "C05A-erased-consecutive", "Two unknowns (the count and the lost number) pinned down by a bound on the average and a divisibility condition; casework on the possible counts.",
  tita_answer=16, check=_c20,
  tita_traps=[(51, r"Reports the number of cards in the full pack, $n$."),
              (36, r"Finds $n = 51$ and the full average $26$, sees that the $50$ remaining cards carry $50 \times 0.2 = 10$ more than that average, but gets the direction wrong and adds: $26 + 10 = 36$ instead of $26 - 10 = 16$.")],
  exams=CX, cognitive="Analysis")


def _c21():
    return _avg([k for k in range(100, 1000) if k % 8 == 3])
q("C05-A-021", T, "Average of all three-digit numbers leaving a given remainder", "Medium",
  "Multi-step word problem",
  r"What is the average of all three-digit natural numbers that leave a remainder of $3$ when divided by $8$?",
  "TITA",
  r"Such numbers form an arithmetic sequence with difference $8$. The first three-digit one is $107$ (since $100 = 8 \times 12 + 4$, the number $99$ is two-digit) and the last is $995$ (since $999 = 8 \times 124 + 7$). Their average is $\frac{107 + 995}{2} = 551$.",
  "Taking a first or last term outside the three-digit range.",
  "C05A-multiples-in-range", "Locating both end terms of the sequence with remainders, then the end-term average.",
  tita_answer=551, check=_c21,
  tita_traps=[(547, r"Starts at $99$, which is not a three-digit number: $\frac{99 + 995}{2}$."), (555, r"Ends at $1003$, which is a four-digit number: $\frac{107 + 1003}{2}$.")],
  cognitive="Application")


def _c22():
    xs = [F(20 + 2 * k) for k in range(1, 21)]       # any 20 numbers with average 35
    xs = [x - (_avg(xs) - 35) for x in xs]
    assert _avg(xs) == 35
    ys = [xs[k] + (k + 1) for k in range(20)]
    return _avg(ys)
q("C05-A-022", T, "Each member increased by its position: effect on the average", "Medium",
  "Conceptual/application",
  r"The average of $20$ numbers is $35$. The first number is increased by $1$, the second by $2$, the third by $3$, and so on, until the $20$th number is increased by $20$. What is the new average?",
  "MCQ",
  r"The total increases by $1 + 2 + \cdots + 20 = 210$, so the average increases by $\frac{210}{20} = 10.5$. The new average is $35 + 10.5 = 45.5$.",
  "Dividing the total increase by the wrong count, or adding a single increase to the average.",
  "C05A-transform-members", "Requires the sum of the increases and its spread over the count.",
  correct=r"$45.5$",
  distractors=[(r"$45$", r"Divides the total increase $210$ by $21$ instead of $20$."),
               (r"$55$", r"Adds the largest increase, $20$, to the average."),
               (r"$56$", r"Adds the first and last increases, $1 + 20$, to the average.")],
  check=_c22, values=[F(91, 2), 45, 55, 56], cognitive="Understanding")


def _c23():
    y = symbols('y')
    # 15 employees; 3 leave (average 40000) and 3 join (average y); group average falls by 1200
    S = symbols('S')
    return solve(Eq((S - 3 * 40000 + 3 * y) / 15, S / 15 - 1200), y)[0]
q("C05-A-023", T, "Three members replaced: average of the newcomers from the fall in the average", "Medium",
  "Inverse/parameter",
  r"A team has $15$ employees. Three of them, whose average monthly salary is Rs. $40{,}000$, leave, and three new employees join in their place. As a result, the average monthly salary of the team falls by Rs. $1{,}200$. What is the average monthly salary of the three new employees?",
  "MCQ",
  r"The team's total falls by $15 \times 1200 = 18000$ rupees, and this fall is shared by the three replacements. So each newcomer earns on average $\frac{18000}{3} = 6000$ less than the leavers: $40000 - 6000 = 34000$ rupees.",
  "Not scaling the fall in average to a fall in total, or not sharing it among the three newcomers.",
  "C05A-replace-members", "Converting the change in average into a change in total and sharing it among three.",
  correct=r"Rs. $34{,}000$",
  distractors=[(r"Rs. $38{,}800$", r"Subtracts only the fall in the team average: $40000 - 1200$."),
               (r"Rs. $36{,}400$", r"Multiplies the fall by $3$ instead of $15$: $40000 - 3600$."),
               (r"Rs. $22{,}000$", r"Subtracts the whole fall in total from one newcomer: $40000 - 18000$.")],
  check=_c23, values=[34000, 38800, 36400, 22000], cognitive="Application")


def _c24():
    for s in range(-100, 31):
        xs = list(range(s, 31))
        if _avg(xs) == F(37, 2):
            return len(xs)
q("C05-A-024", T, "Count of consecutive integers from their average and the largest", "Medium",
  "Inverse/parameter",
  r"The average of a set of consecutive integers is $18.5$, and the largest integer in the set is $30$. How many integers are there in the set?",
  "TITA",
  r"For consecutive integers the average is the average of the smallest and largest, so the smallest is $2 \times 18.5 - 30 = 7$. The integers $7, 8, \ldots, 30$ number $30 - 7 + 1 = 24$.",
  "Forgetting to add one when counting from the smallest to the largest.",
  "C05A-consecutive-integers", "Average as midpoint, then an inclusive count.",
  tita_answer=24, check=_c24,
  tita_traps=[(23, r"Counts $30 - 7$ without adding $1$.")],
  cognitive="Application")


def _c25():
    n, A = symbols('n A', positive=True)
    sol = solve([Eq((n * A + 64) / (n + 1), A + 2), Eq((n * A + 22) / (n + 1), A - 1)], [n, A], dict=True)
    return [s[n] for s in sol][0]
q("C05-A-025", T, "Size of a list from the effects of appending two different values", "Medium",
  "Inverse/parameter",
  r"Appending the number $64$ to a list of numbers increases the average of the list by $2$. If instead the number $22$ is appended to the original list, the average decreases by $1$. How many numbers are there in the original list?",
  "MCQ",
  r"Let the list have $n$ numbers with average $A$. Appending $x$ changes the average by $\frac{x - A}{n + 1}$. So $64 - A = 2(n + 1)$ and $22 - A = -(n + 1)$. Subtracting, $42 = 3(n + 1)$, so $n + 1 = 14$ and $n = 13$ (and $A = 36$).",
  "Reporting the size after appending, or mishandling the sign of the decrease.",
  "C05A-add-one-member", "Two equations from two hypothetical additions; the unknown is the count.",
  correct=r"$13$",
  distractors=[(r"$14$", r"Reports $n + 1$, the size of the list after appending."),
               (r"$20$", r"Uses only the rise of $2$: takes $n + 1 = \frac{42}{2} = 21$."),
               (r"$41$", r"Treats the decrease of $1$ as an increase, so $42 = (2 - 1)(n + 1)$.")],
  check=_c25, values=[13, 14, 20, 41], exams=CX, cognitive="Analysis")


def _c26():
    n = symbols('n', positive=True, integer=True)
    # average now (4 years later, after swap) = average 4 years earlier
    A = symbols('A')
    return solve(Eq((n * (A + 4) - 61 + 37) / n, A), n)[0]
q("C05-A-026", T, "Group size from a replacement that exactly cancels the ageing", "Medium",
  "Inverse/parameter",
  r"Exactly $4$ years after a certain date, one member of a committee, then aged $61$, retired, and a new member aged $37$ joined in his place on the same day. Immediately after this change, the average age of the committee was the same as its average age on that earlier date. There were no other changes in membership. How many members does the committee have?",
  "MCQ",
  r"In $4$ years each of the $n$ members ages $4$ years, adding $4n$ to the total. The swap removes $61 - 37 = 24$ years. For the average to return to its old value, $4n = 24$, so $n = 6$.",
  "Not linking the total ageing of the group to the number of members.",
  "C05A-age-replacement-over-time", "Insight that ageing adds $4n$ to the total, which the swap must cancel.",
  correct=r"$6$",
  distractors=[(r"$5$", r"Treats the newcomer as an extra member, $4(n + 1) = 24$."),
               (r"$24$", r"Equates the age gap $24$ directly to the number of members."),
               (r"$12$", r"Divides the age gap by the two people involved: $\frac{24}{2}$.")],
  check=_c26, values=[6, 5, 24, 12], cognitive="Analysis")


# ================================================================ DIFFICULT (9)

def _c27():
    a, d, k = symbols('a d k')
    term = lambda j: a + (j - 1) * d
    blk = lambda i, j: sum(term(m) for m in range(i, j + 1)) / (j - i + 1)
    sol = solve([Eq(blk(1, 10), 26), Eq(blk(11, 20), 66)], [a, d], dict=True)[0]
    for kk in range(1, 500):
        if blk(21, 20 + kk).subs(sol) == 150:
            return kk
q("C05-A-027", T, "Averages of successive blocks of an arithmetic progression: length of a later block", "Difficult",
  "Inverse/parameter",
  r"In an arithmetic progression, the average of the first $10$ terms is $26$ and the average of the next $10$ terms (the $11$th to the $20$th) is $66$. A block of consecutive terms of the progression begins with the $21$st term, and the average of the terms in this block is $150$. How many terms are there in this block?",
  "MCQ",
  r"The average of a block of consecutive terms is the term halfway along it. The two given blocks have middles at positions $5.5$ and $15.5$, so $10$ positions add $40$ and $d = 4$; then $a + 4.5 \times 4 = 26$ gives $a = 8$, and the $21$st term is $8 + 20 \times 4 = 88$. A block of $k$ terms starting there has average $88 + \frac{(k - 1) \times 4}{2} = 86 + 2k$. Setting $86 + 2k = 150$ gives $k = 32$.",
  r"Placing the middle of the block at position $21 + \frac{k}{2}$ instead of $21 + \frac{k - 1}{2}$, or measuring the block from the first term.",
  "C05A-ap-averages", "Recover the progression from two block averages, then solve for an unknown block length using the midpoint idea; several places to slip by one.",
  correct=r"$32$",
  distractors=[(r"$31$", r"Takes the block's average as the term at position $21 + \frac{k}{2}$: $88 + 2k = 150$."),
               (r"$52$", r"Reports the position of the last term of the block, $20 + 32$."),
               (r"$72$", r"Treats the block as the first $k$ terms of the progression: $8 + 2(k - 1) = 150$.")],
  check=_c27, values=[32, 31, 52, 72], exams=CX, cognitive="Analysis")


def _c28():
    # simulate the removals with exact fractions; no particular list is needed beyond the totals
    count, total = 40, F(40 * 50)
    removed = []
    for step in range(10):
        new_avg = total / count - 1
        x = total - new_avg * (count - 1)
        removed.append(x)
        total, count = total - x, count - 1
    return removed[-1]
q("C05-A-028", T, "Successive removals, each lowering the average by one: value of a later removal", "Difficult",
  "Multi-step word problem",
  r"A list contains $40$ numbers whose average is $50$. Numbers are removed from the list one at a time, and after each removal the average of the numbers still in the list is exactly $1$ less than it was just before that removal. What is the $10$th number removed?",
  "MCQ",
  r"Track totals, not individual numbers. After $k$ removals there are $40 - k$ numbers with average $50 - k$, so the total is $(40 - k)(50 - k)$. The $10$th number removed is the drop in total from $k = 9$ to $k = 10$: $31 \times 41 - 30 \times 40 = 1271 - 1200 = 71$. (In general the $k$th number removed is $91 - 2k$: $89, 87, 85, \ldots$)",
  "Assuming the removed numbers fall by $1$ each time, like the average, instead of by $2$.",
  "C05A-successive-removals", "Ten linked stages; the insight is to write the total after $k$ removals as $(40 - k)(50 - k)$ instead of simulating, with an off-by-one trap.",
  correct=r"$71$",
  distractors=[(r"$80$", r"Finds the first removal, $89$, then assumes each later removal is $1$ less: $89 - 9$."),
               (r"$69$", r"Off by one stage: computes the $11$th removal, $30 \times 40 - 29 \times 39 = 1200 - 1131$."),
               (r"$40$", r"Reports the average of the list after the $10$th removal, $50 - 10$.")],
  check=_c28, values=[71, 80, 69, 40], exams=CX, cognitive="Analysis")


def _c29():
    ages = [20, 22, 23, 24, 25, 26, 27, 28, 29, 31, 31]
    assert _avg(ages) == 26
    ages = [a + 2 for a in ages]
    ages = ages[:-2]
    total_left = sum([33, 37])
    s = symbols('s')
    # keep the squad total consistent: replace the two leavers (aged 33 and 37 then)
    rest = 11 * 28 - total_left
    pair = solve(Eq((rest + s) / 11, 25), s)[0]
    return pair / 2
q("C05-A-029", T, "Two members replaced after some years: average age of the newcomers", "Medium",
  "Multi-step word problem",
  r"At the start of a season, the average age of the $11$ players in a hockey squad was $26$ years. Exactly $2$ years later, two players, then aged $33$ and $37$, retired, and two new players joined on the same day. The average age of the $11$ players immediately after this change was $25$ years. What was the average age of the two new players on the day they joined?",
  "MCQ",
  r"After $2$ years the squad totals $11 \times 28 = 308$ years. Removing the retirees leaves $308 - 70 = 238$. The new total is $11 \times 25 = 275$, so the newcomers total $275 - 238 = 37$ years, an average of $18.5$ years.",
  "Forgetting that the squad aged two years before the change.",
  "C05A-age-replacement-over-time", "Three totals (the aged squad, minus the two retirees, against the new total) with an ageing trap; a typical two-idea CAT item.",
  correct=r"$18.5$ years",
  distractors=[(r"$29.5$ years", r"Ignores the $2$ years of ageing: $\frac{275 - (286 - 70)}{2}$."),
               (r"$37$ years", r"Reports the combined age of the two newcomers."),
               (r"$32$ years", r"Subtracts the fall in average, $28 - 25 = 3$, from the retirees' average age $35$.")],
  check=_c29, values=[F(37, 2), F(59, 2), 37, 32], exams=CX, cognitive="Analysis")


def _c30():
    n = symbols('n')
    n0 = solve(Eq((n * 33 + 25) / (n + 1), 32), n)[0]
    total = n0 * 33 + 25               # 3 years after formation, after the joining
    total += (n0 + 1) * 4              # 4 more years
    total -= 50
    return total / n0
q("C05-A-030", T, "Club ages through a joining, more years, and a leaving", "Difficult",
  "Multi-step word problem",
  r"When a club was formed, the average age of its members was $30$ years. Exactly $3$ years later, a new member aged $25$ joined, and the average age of the members became $32$ years. Exactly $4$ years after that, a member aged $50$ left the club. There were no other changes in membership. What was the average age of the members, in years, immediately after this member left?",
  "TITA",
  r"Let $n$ be the founding membership. After $3$ years the average is $33$, so $33n + 25 = 32(n + 1)$, giving $n = 7$ and a total of $256$ years for $8$ members. Four years later the total is $256 + 8 \times 4 = 288$. After the $50$ year old leaves, $7$ members total $238$ years, an average of $34$ years.",
  "Reporting the average just before the member left.",
  "C05A-age-birth-death", "Unknown group size found from a joining, then a further ageing and a leaving.",
  tita_answer=34, check=_c30,
  tita_traps=[(36, r"Reports the average of the $8$ members before the $50$ year old left, $\frac{288}{8}$.")],
  exams=CX, cognitive="Analysis")


def _c31():
    a, n = symbols('a n')
    d = 2
    first10 = a + F(9, 2) * d
    last = a + (n - 1) * d
    last10 = last - F(9, 2) * d
    sol = solve([Eq(first10, 25), Eq(last10, 79)], [a, n], dict=True)[0]
    return sol[n]
q("C05-A-031", T, "Number of terms of an arithmetic progression from averages of its first and last terms", "Difficult",
  "Inverse/parameter",
  r"An arithmetic progression has common difference $2$. The average of its first $10$ terms is $25$, and the average of its last $10$ terms is $79$. How many terms does the progression have?",
  "MCQ",
  r"The average of the first $10$ terms is the first term plus $4.5d$, so the first term is $25 - 9 = 16$. The average of the last $10$ terms is the last term minus $4.5d$, so the last term is $79 + 9 = 88$. Then $88 = 16 + (n - 1) \times 2$ gives $n = 37$.",
  "Treating the difference of the block averages as the difference of the end terms.",
  "C05A-ap-averages", "Converting block averages back to end terms in both directions before counting.",
  correct=r"$37$",
  distractors=[(r"$28$", r"Takes $79 - 25 = 54$ as the gap between first and last terms: $(n - 1) \times 2 = 54$."),
               (r"$36$", r"Gets the end terms right but writes the last term as $a + nd$: $16 + 2n = 88$."),
               (r"$46$", r"Shifts each end by $9d$ instead of $4.5d$: first term $7$, last term $97$, so $(n - 1) \times 2 = 90$.")],
  check=_c31, values=[37, 28, 36, 46], exams=CX, cognitive="Analysis")


def _c32():
    xs = symbols('x1:6')
    avgs = [31, 32, 33, 35, 39]
    eqs = [Eq((sum(xs) - xs[i]) / 4, avgs[i]) for i in range(5)]
    sol = solve(eqs, xs, dict=True)[0]
    vals = [sol[v] for v in xs]
    assert len(set(vals)) == 5
    return max(vals)
q("C05-A-032", T, "Five numbers from the averages obtained by leaving out each one in turn", "Difficult",
  "Conceptual/application",
  r"Five numbers are written on a board. Leaving out one number at a time and averaging the other four gives five averages, which are $31$, $32$, $33$, $35$ and $39$. What is the largest of the five numbers?",
  "MCQ",
  r"Each number is left out exactly once, so adding the five averages gives $\frac{4S}{4} = S$, where $S$ is the sum of all five numbers: $S = 31 + 32 + 33 + 35 + 39 = 170$. A number $x$ left out gives average $\frac{S - x}{4}$, so $x = S - 4 \times (\text{that average})$, and the largest number goes with the smallest average: $170 - 4 \times 31 = 46$. (The five numbers are $46, 42, 38, 30, 14$.)",
  "Pairing the largest number with the largest of the leave-one-out averages.",
  "C05A-leave-one-out-averages", "Needs the insight that the five leave-one-out averages add up to the total, then the reversed pairing of numbers and averages.",
  correct=r"$46$",
  distractors=[(r"$14$", r"Pairs the largest number with the largest average: $170 - 4 \times 39$."),
               (r"$37$", r"Takes the largest number to be as far above the overall average $34$ as the smallest average $31$ is below it: $34 + 3$, without scaling by $4$."),
               (r"$49$", r"Scales the gap by $5$ instead of $4$: $34 + 5 \times 3$.")],
  check=_c32, values=[46, 14, 37, 49], exams=CX, cognitive="Analysis")


def _c33():
    for s in range(1, 200, 2):
        for k in range(1, 200):
            xs = [s + 2 * i for i in range(k)]
            if sum(xs) == 315 and _avg(xs) == 3 * s:
                return max(xs)
q("C05-A-033", T, "Consecutive odd numbers whose average is a multiple of the smallest", "Difficult",
  "Inverse/parameter",
  r"The average of some consecutive odd numbers is three times the smallest of them, and the sum of these numbers is $315$. What is the largest of these numbers?",
  "TITA",
  r"Let the smallest be $s$ and the count be $k$. The average is the midpoint $s + (k - 1)$, so $s + k - 1 = 3s$, that is $k = 2s + 1$. The sum is $k \times 3s = 3s(2s + 1) = 315$, so $s(2s + 1) = 105 = 7 \times 15$, giving $s = 7$ and $k = 15$. The largest is $7 + 2 \times 14 = 35$.",
  "Reporting the average, or counting one step too many to the largest term.",
  "C05A-consecutive-odd-even", "Two conditions give a quadratic in the smallest term; needs the midpoint idea for odd numbers.",
  tita_answer=35, check=_c33,
  tita_traps=[(21, r"Reports the average, $3 \times 7$."), (37, r"Adds $2k = 30$ instead of $2(k - 1)$ to the smallest.")],
  exams=CX, cognitive="Analysis")


def _c34():
    r = symbols('r1:16')
    eqs = [Eq(sum(r), 15 * 40), Eq(sum(r[:8]), 8 * 38), Eq(sum(r[6:]), 9 * 43), Eq(r[6] - r[7], 7)]
    sol = solve(eqs, [r[6], r[7], r[0], r[14]], dict=True)[0]
    return sol[r[7]]
q("C05-A-034", T, "Overlap of two readings between a first block and a last block", "Difficult",
  "Multi-step word problem",
  r"A sensor records $15$ readings in order. The average of all $15$ readings is $40$, the average of the first $8$ readings is $38$, and the average of the last $9$ readings is $43$. The $7$th reading is $7$ more than the $8$th reading. What is the $8$th reading?",
  "MCQ",
  r"The first $8$ readings (positions $1$ to $8$) and the last $9$ (positions $7$ to $15$) overlap in two readings, the $7$th and $8$th. So their sum is $8 \times 38 + 9 \times 43 - 15 \times 40 = 304 + 387 - 600 = 91$. With the $7$th exceeding the $8$th by $7$, the $8$th is $\frac{91 - 7}{2} = 42$.",
  "Assuming the two blocks share only one reading.",
  "C05A-overlapping-groups", "Identifying a two-reading overlap, then sum and difference.",
  correct=r"$42$",
  distractors=[(r"$49$", r"Reports the $7$th reading."),
               (r"$45.5$", r"Reports the average of the two overlapping readings."),
               (r"$91$", r"Assumes the blocks overlap in the $8$th reading alone, so it equals $304 + 387 - 600$.")],
  check=_c34, values=[42, 49, F(91, 2), 91], exams=CX, cognitive="Analysis")


def _c35():
    S1, S2 = symbols('S1 S2')
    sol = solve([Eq(S1 + S2, 10 * 24), Eq(2 * S1 + (S2 - 6 * 3), 10 * 30)], [S1, S2], dict=True)[0]
    return sol[S1] / 4
q("C05-A-035", T, "Different changes to two parts of a set: recovering the part's average", "Difficult",
  "Inverse/parameter",
  r"The average of $10$ numbers is $24$. Each of the first $4$ numbers is doubled and each of the remaining $6$ numbers is decreased by $3$. The average of the $10$ new numbers is $30$. What was the average of the first $4$ numbers originally?",
  "MCQ",
  r"Let the first four total $S$. The original total is $240$. Doubling adds $S$ to the total and the decreases remove $6 \times 3 = 18$, so $240 + S - 18 = 300$ and $S = 78$. The average of the first four was $\frac{78}{4} = 19.5$.",
  "Mishandling the total effect of decreasing six numbers by $3$ each.",
  "C05A-transform-members", "Two different transformations on two parts; the unknown is one part's total.",
  correct=r"$19.5$",
  distractors=[(r"$15$", r"Forgets the decrease of the six numbers: $240 + S = 300$."),
               (r"$15.75$", r"Subtracts $3$ only once in total: $240 + S - 3 = 300$."),
               (r"$22.5$", r"Subtracts $3$ from all ten numbers: $240 + S - 30 = 300$.")],
  check=_c35, values=[F(39, 2), 15, F(63, 4), F(45, 2)], exams=CX, cognitive="Analysis")
