import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

# MCQ example: solve the equations the stem implies, from the givens.
def _c1():
    v = symbols('v', positive=True)
    # 240 km; if speed were 20 km/h more, the trip would take 1 hour less
    sol = solve(Eq(240/v - 240/(v + 20), 1), v)
    return [s for s in sol if s > 0][0]
q("C08-X-001", "Speed, time and distance basics", "Change in speed changes travel time", "Easy",
  "Multi-step word problem",
  r"A car covers a distance of $240$ km at a uniform speed. Had its speed been $20$ km/h more, the journey would have taken $1$ hour less. What was the original speed of the car?",
  "MCQ",
  r"Let the speed be $v$ km/h. Then $\frac{240}{v} - \frac{240}{v+20} = 1$, so $240 \times 20 = v(v+20)$, that is $v^2 + 20v - 4800 = 0 = (v-60)(v+80)$. Hence $v = 60$ km/h.",
  "Setting up the time difference the wrong way round or solving the quadratic carelessly.",
  "C08-speed-change-time-saved", "One equation in one unknown leading to a factorable quadratic.",
  correct=r"$60$ km/h",
  distractors=[(r"$80$ km/h", "Reports the increased speed $v + 20$ instead of the original speed."),
               (r"$40$ km/h", "Uses half the distance: $v(v+20) = 2400$ gives $v = 40$."),
               (r"$70$ km/h", "Drops the $20v$ term, writes $v^2 \\approx 4800$ and rounds $\\sqrt{4800} \\approx 69.3$ to $70$.")],
  check=_c1, values=[60, 80, 40, 70], cognitive="Application")

# TITA example: brute-force simulation where possible.
def _c2():
    # circular track 600 m, speeds 5 m/s and 3 m/s, same start, same direction.
    # Number of distinct points on the track where they meet.
    L, a, b = 600, 5, 3
    from math import gcd
    t_meet = Fraction(L, a - b)          # time between meetings
    pts = set()
    for k in range(1, 50):
        pts.add((a * t_meet * k) % L)
    return len(pts)
q("C08-X-002", "Circular tracks", "Distinct meeting points, same direction", "Medium",
  "Conceptual/application",
  r"Two runners start together from the same point on a circular track of length $600$ m and run in the same direction at constant speeds of $5$ m/s and $3$ m/s. If they keep running indefinitely, at how many distinct points on the track will they meet?",
  "TITA",
  r"They meet every time the faster runner gains one full lap, that is every $\frac{600}{5-3} = 300$ s. In $300$ s the faster runner covers $1500$ m, which is $2.5$ laps, so successive meetings are half a lap apart. The meeting points are the start and the diametrically opposite point: $2$ distinct points. (In general the count is $\frac{a-b}{\gcd(a,b)}$ for speeds in ratio $a:b$ in the same direction; here $\frac{5-3}{1} = 2$.)",
  "Using the sum of the ratio terms, which applies only to opposite directions.",
  "C08-circular-distinct-points-same-dir", "Needs the meeting interval and the idea that meeting points repeat.",
  tita_answer=2, check=_c2, tita_traps=[(8, "Uses $a + b$, the opposite-direction rule."), (1, "Assumes they only meet at the start.")],
  cognitive="Analysis")
