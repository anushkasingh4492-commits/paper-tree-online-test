import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Cost price, selling price and profit"
CX = ("CAT", "XAT")


def _pct(gain, base):
    return F(gain) * 100 / F(base)


# ================================================================ EASY (14)

def _c1():
    cp = 2500 + 500
    return _pct(3450 - cp, cp)
q("C02-A-001", T, "Profit percent when repair cost is part of the cost price", "Easy",
  "Single-step computation",
  r"Meera buys a second-hand bicycle for Rs. $2{,}500$ and spends Rs. $500$ on repairs before selling it for Rs. $3{,}450$. What is her profit percent, calculated on her total cost? Type the number only (for example, type $12$ for $12\%$).",
  "TITA",
  r"Her total cost is $2500 + 500 = 3000$ rupees, so the profit is $3450 - 3000 = 450$ rupees. Profit percent $= \frac{450}{3000} \times 100 = 15$.",
  "Leaving the repair cost out of the cost price.",
  "C02A-overheads-in-cost-price", "One addition and one percentage; the trap is ignoring the repair cost.",
  tita_answer=15, check=_c1,
  tita_traps=[(38, r"Ignores repairs: $\frac{3450 - 2500}{2500} \times 100 = 38$."),
              (18, r"Uses the correct profit $450$ but divides by the purchase price $2500$ only.")],
  cognitive="Application")


def _c2():
    cp_each = F(4000 + 800, 80)
    return _pct(75 - cp_each, cp_each)
q("C02-A-002", T, "Profit percent on a batch with a transport cost shared across items", "Easy",
  "Multi-step word problem",
  r"A potter spends Rs. $4{,}000$ on clay and firing to make $80$ pots and a further Rs. $800$ to transport them to the market. She sells all $80$ pots at Rs. $75$ each. What is her profit percent?",
  "MCQ",
  r"Total cost $= 4000 + 800 = 4800$ rupees, that is $60$ rupees per pot. Profit per pot $= 75 - 60 = 15$ rupees, so the profit percent is $\frac{15}{60} \times 100 = 25\%$.",
  "Leaving the transport cost out, or measuring profit against the selling price.",
  "C02A-overheads-in-cost-price", "Cost per item from a batch cost, then one percentage.",
  correct=r"$25\%$",
  distractors=[(r"$50\%$", r"Ignores the transport: revenue $6000$ against cost $4000$ gives $\frac{2000}{4000} = 50\%$."),
               (r"$20\%$", r"Divides the profit by the selling price: $\frac{15}{75} = 20\%$."),
               (r"$15\%$", r"Reports the profit of $15$ rupees per pot as a percentage.")],
  check=_c2, values=[25, 50, 20, 15], cognitive="Application")


def _c3():
    c = symbols('c', positive=True)
    return solve(Eq(c * Rational(120, 100), 30600), c)[0]
q("C02-A-003", T, "Cost price from the selling price and the profit percent", "Easy",
  "Inverse/parameter",
  r"Joseph sold his scooter for Rs. $30{,}600$ and made a profit of $20\%$. For how many rupees had he bought the scooter?",
  "TITA",
  r"Selling price $= 120\%$ of cost, so cost $= \frac{30600}{1.2} = 25500$ rupees.",
  r"Subtracting $20\%$ of the selling price instead of dividing by $1.2$.",
  "C02A-cost-from-selling-price", "One division; the trap is taking the percentage on the selling price.",
  tita_answer=25500, check=_c3,
  tita_traps=[(24480, r"Subtracts $20\%$ of the selling price: $30600 \times 0.8 = 24480$.")],
  cognitive="Application")


def _c4():
    cp = F(3400) / F(85, 100)
    return cp * F(110, 100)
q("C02-A-004", T, "Selling price for a target gain, given a sale at a loss", "Easy",
  "Multi-step word problem",
  r"Sneha sold a watch for Rs. $3{,}400$ and incurred a loss of $15\%$. At what price should she have sold it to gain $10\%$?",
  "MCQ",
  r"Cost $= \frac{3400}{0.85} = 4000$ rupees. For a $10\%$ gain she needs $4000 \times 1.1 = 4400$ rupees.",
  "Applying the percentages to the selling price instead of the cost price.",
  "C02A-selling-price-via-cost", "Recover the cost, then apply the new percentage.",
  correct=r"Rs. $4{,}400$",
  distractors=[(r"Rs. $4{,}250$", r"Adds $15 + 10 = 25\%$ to the old selling price: $3400 \times 1.25 = 4250$."),
               (r"Rs. $3{,}740$", r"Adds $10\%$ to the old selling price: $3400 \times 1.1 = 3740$."),
               (r"Rs. $4{,}301$", r"Takes the cost as $3400 \times 1.15 = 3910$ and then adds $10\%$: $4301$.")],
  check=_c4, values=[4400, 4250, 3740, 4301], cognitive="Application")


def _c5():
    s = symbols('s', positive=True)
    return solve(Eq(s - 1200, Rational(20, 100) * s), s)[0]
q("C02-A-005", T, "Selling price when the profit is a stated percentage of the selling price", "Easy",
  "Single-step computation",
  r"A shop fixes its prices so that its profit on every item is $20\%$ of the selling price. An item costs the shop Rs. $1{,}200$. At what price, in rupees, does the shop sell it?",
  "TITA",
  r"If profit is $20\%$ of the selling price, cost is $80\%$ of it. So the selling price is $\frac{1200}{0.8} = 1500$ rupees (profit $300$, which is $20\%$ of $1500$).",
  r"Adding $20\%$ to the cost when the percentage is on the selling price.",
  "C02A-profit-on-selling-price", r"One idea: cost is $80\%$ of the selling price.",
  tita_answer=1500, check=_c5,
  tita_traps=[(1440, r"Adds $20\%$ of the cost: $1200 \times 1.2 = 1440$.")],
  cognitive="Understanding")


def _c6():
    # cost of 24 = selling price of 30; take cost per article 30 units, price per article 24 units
    c, s = symbols('c s', positive=True)
    ratio = solve(Eq(24 * c, 30 * s), s)[0] / c
    return (ratio - 1) * 100
q("C02-A-006", T, "Cost of some articles equals the selling price of more articles", "Easy",
  "Conceptual/application",
  r"A trader finds that the cost price of $24$ identical lamps equals the selling price of $30$ such lamps. What is the result of his sale?",
  "MCQ",
  r"Let one lamp cost $c$ and sell for $s$. Then $24c = 30s$, so $s = 0.8c$: each lamp sells for $20\%$ below cost. The result is a loss of $20\%$.",
  "Dividing the difference of $6$ articles by the wrong count, or reading the direction of the relation backwards.",
  "C02A-cost-of-x-equals-price-of-y", "One ratio; the trap is the base and the direction.",
  correct=r"Loss of $20\%$",
  distractors=[(r"Loss of $25\%$", r"Divides the difference of $6$ lamps by $24$: $\frac{6}{24} = 25\%$."),
               (r"Gain of $25\%$", r"Reads the relation the other way round, as selling price of $24$ equal to cost of $30$."),
               (r"Gain of $20\%$", r"Reverses the direction and divides the difference of $6$ by $30$.")],
  check=_c6, values=[-20, -25, 25, 20], cognitive="Understanding")


def _c7():
    cp, sp = F(30, 6), F(25, 4)
    return _pct(sp - cp, cp)
q("C02-A-007", T, "Profit percent from buying and selling rates", "Easy",
  "Single-step computation",
  r"A flower seller buys marigold garlands at $6$ for Rs. $30$ and sells them at $4$ for Rs. $25$. What is his profit percent? Type the number only.",
  "TITA",
  r"Cost per garland $= \frac{30}{6} = 5$ rupees and selling price per garland $= \frac{25}{4} = 6.25$ rupees. Profit percent $= \frac{1.25}{5} \times 100 = 25$.",
  "Measuring the profit against the selling price.",
  "C02A-rate-buy-sell-profit", "Unit prices from two rates, then one percentage.",
  tita_answer=25, check=_c7,
  tita_traps=[(20, r"Divides by the selling price: $\frac{1.25}{6.25} = 20\%$.")],
  cognitive="Application")


def _c8():
    s = 9600
    cp_gain = F(s) / F(120, 100)
    cp_loss = F(s) / F(80, 100)
    return cp_gain + cp_loss - 2 * s
q("C02-A-008", T, "Two items at one selling price, equal percentage gain and loss", "Medium",
  "Conceptual/application",
  r"Arjun sold two phones for Rs. $9{,}600$ each. On one he gained $20\%$ and on the other he lost $20\%$, both percentages on the respective cost prices. What was his overall loss?",
  "MCQ",
  r"Costs are $\frac{9600}{1.2} = 8000$ and $\frac{9600}{0.8} = 12000$ rupees, total $20000$, against total sales of $19200$. The overall loss is $800$ rupees (a loss of $\frac{20^2}{100} = 4\%$ of the total cost).",
  r"Assuming the gain and the loss cancel, or applying $4\%$ to the selling price.",
  "C02A-same-price-equal-gain-loss", "Two separate cost recoveries from one selling price, a total, and a classic cancellation trap.",
  correct=r"Rs. $800$",
  distractors=[(r"Rs. $768$", r"Applies the $4\%$ loss to the total selling price $19200$."),
               (r"Rs. $384$", r"Applies the $4\%$ loss to one selling price $9600$."),
               (r"Rs. $320$", r"Finds the loss item's cost as $9600 \times 1.2 = 11520$, giving total cost $8000 + 11520 = 19520$.")],
  check=_c8, values=[800, 768, 384, 320], cognitive="Analysis")


def _c9():
    n = 0
    while n * (90 - 60) < 36000:
        n += 1
    return n
q("C02-A-009", T, "Break-even volume with fixed and per-unit costs", "Easy",
  "Single-step computation",
  r"A tiffin service has fixed costs of Rs. $36{,}000$ per month. Each meal costs Rs. $60$ to prepare and is sold for Rs. $90$. How many meals must it sell in a month to break even (no profit, no loss)?",
  "TITA",
  r"Each meal contributes $90 - 60 = 30$ rupees towards the fixed cost. Break-even needs $\frac{36000}{30} = 1200$ meals.",
  "Dividing the fixed cost by the price or by the cost per meal instead of by the margin.",
  "C02A-break-even-units", "One subtraction and one division.",
  tita_answer=1200, check=_c9,
  tita_traps=[(400, r"Divides by the selling price: $\frac{36000}{90}$."),
              (600, r"Divides by the cost per meal: $\frac{36000}{60}$.")],
  cognitive="Application")


def _c10():
    cp, sp = F(100), F(120)
    new_cp = cp * F(80, 100)
    return _pct(sp - new_cp, new_cp)
q("C02-A-010", T, "Effect of a fall in cost price on profit percent", "Easy",
  "Conceptual/application",
  r"A retailer sells a toaster at a profit of $20\%$. His supplier then cuts the cost price by $20\%$, and he keeps his selling price unchanged. What is his new profit percent?",
  "MCQ",
  r"Take the old cost as $100$, so the price is $120$. The new cost is $80$, and the profit is $40$ on $80$, that is $50\%$.",
  "Adding the two percentages, or forgetting that the base of the profit percent has changed.",
  "C02A-cost-and-price-change", "One substitution with a base-change trap.",
  correct=r"$50\%$",
  distractors=[(r"$40\%$", r"Adds the $20\%$ cost cut to the $20\%$ profit."),
               (r"$44\%$", r"Compounds $1.2 \times 1.2 = 1.44$ as if the cost cut raised the ratio by $20\%$."),
               (r"$25\%$", r"Divides the old profit $20$ by the new cost $80$.")],
  check=_c10, values=[50, 40, 44, 25], cognitive="Understanding")


def _c11():
    p = symbols('p', positive=True)  # actual price as a multiple of cost
    r = solve(Eq(Rational(4, 5) * p, Rational(96, 100)), p)[0]
    return (r - 1) * 100
q("C02-A-011", T, "Actual profit from a hypothetical sale at a fraction of the price", "Medium",
  "Multi-step word problem",
  r"Had a dealer sold a cycle for $\frac{4}{5}$ of the price he actually charged, he would have suffered a loss of $4\%$. What was his actual profit percent?",
  "MCQ",
  r"$\frac{4}{5}$ of the actual price equals $96\%$ of cost, so the actual price is $\frac{96}{0.8} = 120\%$ of cost. The profit was $20\%$.",
  "Adding or subtracting the percentages instead of scaling the price.",
  "C02A-price-scaling", "Links a hypothetical price to the actual one through the cost; two linear-thinking traps.",
  correct=r"$20\%$",
  distractors=[(r"$16\%$", r"Subtracts: a $20\%$ cut in price less the $4\%$ loss."),
               (r"$24\%$", r"Adds the $20\%$ price cut and the $4\%$ loss."),
               (r"$25\%$", r"Ignores the loss and takes the price ratio $\frac{5}{4}$ as the profit factor.")],
  check=_c11, values=[20, 16, 24, 25], cognitive="Application")


def _c12():
    n = 0
    profit = F(0)
    while profit < 120:
        n += 1
        profit = n * (F(12, 4) - F(12, 5))
    return n
q("C02-A-012", T, "Number of articles needed to earn a given profit from two rates", "Easy",
  "Multi-step word problem",
  r"A vendor buys lemons at $5$ for Rs. $12$ and sells them at $4$ for Rs. $12$. How many lemons must he sell to earn a profit of Rs. $120$?",
  "MCQ",
  r"Cost per lemon $= 2.40$ rupees and selling price per lemon $= 3$ rupees, so each lemon earns $0.60$ rupees. He needs $\frac{120}{0.6} = 200$ lemons.",
  "Dividing the target profit by a price instead of by the profit per lemon.",
  "C02A-rate-count-for-profit", "Unit profit from two rates, then one division.",
  correct=r"$200$",
  distractors=[(r"$50$", r"Divides $120$ by the cost per lemon $2.40$."),
               (r"$40$", r"Divides $120$ by the selling price per lemon $3$."),
               (r"$250$", r"Sees that $5$ lemons cost what $4$ sell for, so the profit on $5$ lemons is the price of one lemon, but takes that lemon at the buying rate Rs. $2.40$: $\frac{120}{2.40} = 50$ lots of $5$, that is $250$ lemons.")],
  check=_c12, values=[200, 50, 40, 250], cognitive="Application")


def _c13():
    return _pct(800 - 640, 800)
q("C02-A-013", T, "Profit as a percentage of selling price, stated explicitly", "Easy",
  "Single-step computation",
  r"Kabir buys calculators at Rs. $640$ each and sells them at Rs. $800$ each. What is his profit expressed as a percentage of the selling price?",
  "MCQ",
  r"Profit per calculator $= 800 - 640 = 160$ rupees. As a percentage of the selling price it is $\frac{160}{800} \times 100 = 20\%$.",
  "Using the cost price as the base when the question asks for the selling price.",
  "C02A-basis-conversion", "One percentage; the trap is the base.",
  correct=r"$20\%$",
  distractors=[(r"$25\%$", r"Divides the profit by the cost price."),
               (r"$80\%$", r"Reports the cost price as a percentage of the selling price."),
               (r"$125\%$", r"Reports the selling price as a percentage of the cost price.")],
  check=_c13, values=[20, 25, 80, 125], cognitive="Recall")


def _c14():
    total_cost = 24000 + 40 * 800
    p = 1
    while p * 800 < total_cost:
        p += 1
    return p
q("C02-A-014", T, "Break-even price per unit for a fixed print run", "Easy",
  "Inverse/parameter",
  r"A publisher prints $800$ copies of a guidebook. The set-up cost is Rs. $24{,}000$ and printing costs Rs. $40$ per copy. If all $800$ copies are sold at the same price, what is the lowest price per copy, in rupees, at which there is no loss?",
  "TITA",
  r"Total cost $= 24000 + 40 \times 800 = 56000$ rupees. Spread over $800$ copies this is $\frac{56000}{800} = 70$ rupees per copy.",
  "Recovering only the set-up cost and forgetting the printing cost per copy.",
  "C02A-break-even-price-and-target", "Total cost over volume; one trap.",
  tita_answer=70, check=_c14,
  tita_traps=[(30, r"Spreads only the set-up cost: $\frac{24000}{800} = 30$.")],
  cognitive="Application")


# ================================================================ MEDIUM (20)

def _c15():
    cp, sp = F(100), F(125)
    profit = sp - cp
    new_cp = cp * F(120, 100)
    new_sp = new_cp + profit
    return _pct(new_sp - sp, sp)
q("C02-A-015", T, "Price rise needed to keep the same rupee profit after a cost rise", "Medium",
  "Conceptual/application",
  r"A trader sells a mixer at a profit of $25\%$. The cost of the mixer rises by $20\%$. He wants to keep his profit in rupees exactly the same as before. By what percent must he raise his selling price? Type the number only.",
  "TITA",
  r"Take the old cost as $100$: price $125$, profit $25$. The new cost is $120$, so the new price must be $145$. The rise is $\frac{20}{125} \times 100 = 16\%$.",
  "Keeping the profit percent instead of the profit amount, or measuring the rise against the cost.",
  "C02A-cost-and-price-change", "Separating rupee profit from percentage profit, and the base of the rise.",
  tita_answer=16, check=_c15,
  tita_traps=[(20, r"Raises the price by the same $20\%$ as the cost, which keeps the profit percent, not the rupee profit.")],
  cognitive="Analysis")


def _c16():
    p = symbols('p', positive=True)  # profit as a fraction of SP
    sol = solve(Eq(p / (1 - p) - p, Rational(5, 100)), p)
    return [x for x in sol if 0 < x < 1][0] * 100
q("C02-A-016", T, "Profit percent on selling price from its gap with profit percent on cost", "Difficult",
  "Inverse/parameter",
  r"On a certain sale, Ananya's profit is $p\%$ of the selling price and $q\%$ of the cost price, where $q - p = 5$. What is the value of $p$?",
  "TITA",
  r"If profit is a fraction $x$ of the selling price, it is $\frac{x}{1-x}$ of the cost. So $\frac{x}{1-x} - x = \frac{5}{100}$, giving $\frac{x^2}{1-x} = 0.05$, or $x^2 + 0.05x - 0.05 = 0$, whose positive root is $x = 0.2$. Hence $p = 20$ (and $q = 25$).",
  "Reporting $q$ instead of $p$.",
  "C02A-basis-conversion", r"Needs the two-basis relation $\frac{x}{1-x}$ and then a quadratic in the unknown fraction; no direct formula gives $p$.",
  tita_answer=20, check=_c16,
  tita_traps=[(25, r"Reports $q$, the profit percent on cost.")],
  cognitive="Analysis", exams=CX)


def _c17():
    x = symbols('x', positive=True)
    return solve(Eq((x + x / 4) * Rational(110, 100), 165000), x)[0]
q("C02-A-017", T, "Purchase price when repairs are a fraction of it", "Medium",
  "Multi-step word problem",
  r"Harpreet bought a used car and spent one-fourth of its purchase price on repairs. She then sold the car for Rs. $1{,}65{,}000$, making a profit of $10\%$ on her total cost. What was the purchase price of the car?",
  "MCQ",
  r"Total cost $= \frac{165000}{1.1} = 150000$ rupees. This is $\frac{5}{4}$ of the purchase price, so the purchase price is $150000 \times \frac{4}{5} = 120000$ rupees.",
  "Stopping at the total cost, or subtracting percentages instead of dividing by the factors.",
  "C02A-overheads-in-cost-price", "Two successive inverse steps with fractions.",
  correct=r"Rs. $1{,}20{,}000$",
  distractors=[(r"Rs. $1{,}50{,}000$", r"Stops at the total cost including repairs."),
               (r"Rs. $1{,}23{,}750$", r"Subtracts a quarter of the selling price: $165000 \times 0.75$."),
               (r"Rs. $1{,}12{,}500$", r"Subtracts a quarter of the total cost: $150000 \times 0.75$.")],
  check=_c17, values=[120000, 150000, 123750, 112500], cognitive="Application")


def _c18():
    c = symbols('c', positive=True)
    return solve(Eq(10 * c * Rational(120, 100), 11 * c + 180), c)[0]
q("C02-A-018", T, "Cost per article from a relation between selling price and cost of different counts", "Medium",
  "Inverse/parameter",
  r"A shopkeeper sells school bags at a profit of $20\%$ on cost. The selling price of $10$ bags is Rs. $180$ more than the cost price of $11$ bags. What is the cost price of one bag, in rupees?",
  "TITA",
  r"Let one bag cost $c$. Then $10 \times 1.2c = 11c + 180$, so $12c - 11c = 180$ and $c = 180$.",
  r"Treating the $20\%$ as a percentage of the selling price.",
  "C02A-cost-of-x-equals-price-of-y", "Linear equation linking counts and the profit factor.",
  tita_answer=180, check=_c18,
  tita_traps=[(120, r"Takes the profit as $20\%$ of the selling price, so price $= 1.25c$: $12.5c = 11c + 180$ gives $120$.")],
  cognitive="Application")


def _c19():
    sp_total = 6000
    s = F(sp_total, 50)
    # 50s - 50c = 10s
    c = symbols('c', positive=True)
    return solve(Eq(50 * s - 50 * c, 10 * s), c)[0]
q("C02-A-019", T, "Gain equal to the selling price of some units, cost per unit", "Medium",
  "Multi-step word problem",
  r"A cloth merchant sells $50$ metres of fabric for Rs. $6{,}000$. His gain on this sale equals the selling price of $10$ metres. What is his cost price per metre, in rupees?",
  "TITA",
  r"Selling price per metre $= 120$ rupees, so the gain is $10 \times 120 = 1200$ rupees. The cost of $50$ metres is $6000 - 1200 = 4800$ rupees, that is $96$ rupees per metre.",
  r"Treating the gain as the cost price of $10$ metres, which gives a $20\%$ gain on cost.",
  "C02A-gain-equals-price-of-units", "Converts the gain statement into rupees before finding the cost.",
  tita_answer=96, check=_c19,
  tita_traps=[(100, r"Takes the gain as $\frac{10}{50} = 20\%$ of cost: $\frac{120}{1.2} = 100$.")],
  cognitive="Application")


def _c20():
    cp = F(45, 12)
    sp = symbols('s', positive=True)
    s = solve(Eq(sp - cp, Rational(25, 100) * sp), sp)[0]
    return 100 / s
q("C02-A-020", T, "Selling rate needed for a profit stated on the selling price", "Medium",
  "Inverse/parameter",
  r"A stationer buys pencils at $12$ for Rs. $45$. He wants his profit to be $25\%$ of his selling price. How many pencils should he sell for Rs. $100$?",
  "TITA",
  r"Cost per pencil $= \frac{45}{12} = 3.75$ rupees. If profit is $25\%$ of the selling price, cost is $75\%$ of it, so the price per pencil is $\frac{3.75}{0.75} = 5$ rupees. He should sell $\frac{100}{5} = 20$ pencils for Rs. $100$.",
  r"Taking the $25\%$ on cost, which gives a price of $4.6875$ rupees and a non-integer count.",
  "C02A-rate-count-for-price", "Rate inversion combined with the selling-price basis.",
  tita_answer=20, check=_c20,
  tita_traps=[(21, r"Takes $25\%$ on cost (price $4.6875$), gets $21.33$ and rounds to $21$.")],
  cognitive="Application")


def _c21():
    s = 24000
    cp1 = F(s) / F(120, 100)
    total_cp = 2 * s + 2000
    cp2 = total_cp - cp1
    return _pct(cp2 - s, cp2)
q("C02-A-021", T, "Loss percent on one item from the overall result of two sales at one price", "Medium",
  "Inverse/parameter",
  r"Fatima sold two sewing machines for Rs. $24{,}000$ each. On the first she gained $20\%$ on cost. Taking both sales together she lost Rs. $2{,}000$. What was her loss percent on the second machine?",
  "MCQ",
  r"The first machine cost $\frac{24000}{1.2} = 20000$, a gain of $4000$. For an overall loss of $2000$, the second sale lost $6000$, so it cost $30000$. Loss percent $= \frac{6000}{30000} = 20\%$.",
  "Dividing the second loss by the wrong base.",
  "C02A-same-price-unequal-results", "Back-calculates the second item's cost from the combined result.",
  correct=r"$20\%$",
  distractors=[(r"$25\%$", r"Divides the loss $6000$ by the selling price $24000$."),
               (r"$12\%$", r"Divides the loss $6000$ by the total cost $50000$."),
               (r"$30\%$", r"Divides the loss $6000$ by the first machine's cost $20000$.")],
  check=_c21, values=[20, 25, 12, 30], cognitive="Analysis")


def _c22():
    c = symbols('c', positive=True)
    return solve(Eq(c / Rational(80, 100) - c * Rational(120, 100), 90), c)[0]
q("C02-A-022", T, "Cost price from the gap between selling-price-basis and cost-basis pricing", "Medium",
  "Inverse/parameter",
  r"Kabir and Fatima sell the same kind of desk lamp, which costs each of them the same amount. Kabir prices it so that his profit is $20\%$ of his selling price; Fatima prices it so that her profit is $20\%$ of her cost. Kabir's price is Rs. $90$ more than Fatima's. What is the cost price of the lamp?",
  "MCQ",
  r"With cost $c$, Kabir's price is $\frac{c}{0.8} = 1.25c$ and Fatima's is $1.2c$. The difference $0.05c = 90$, so $c = 1800$ rupees.",
  r"Reporting one of the prices, or taking the $5\%$ gap on the wrong base.",
  "C02A-profit-on-selling-price", "Translates both bases into multiples of cost and solves.",
  correct=r"Rs. $1{,}800$",
  distractors=[(r"Rs. $1{,}440$", r"Treats the gap of $90$ as $5\%$ of Kabir's price, so Kabir's price is $1800$ and cost is $0.8 \times 1800$."),
               (r"Rs. $2{,}160$", r"Reports Fatima's selling price $1.2 \times 1800$."),
               (r"Rs. $2{,}250$", r"Reports Kabir's selling price $1.25 \times 1800$.")],
  check=_c22, values=[1800, 1440, 2160, 2250], cognitive="Application")


def _c23():
    units = 360000 / F(150 - 90)
    return units * 100 / 10000
q("C02-A-023", T, "Break-even as a percentage of capacity", "Medium",
  "Multi-step word problem",
  r"A factory can make at most $10{,}000$ water bottles a month. Its fixed costs are Rs. $3{,}60{,}000$ a month, each bottle costs Rs. $90$ in materials and labour, and each sells for Rs. $150$. At what percentage of its monthly capacity does the factory break even?",
  "MCQ",
  r"Each bottle contributes $150 - 90 = 60$ rupees, so break-even needs $\frac{360000}{60} = 6000$ bottles, which is $60\%$ of capacity.",
  "Dividing the fixed cost by the price or the unit cost instead of the margin.",
  "C02A-break-even-units", "Margin, break-even volume, then a percentage.",
  correct=r"$60\%$",
  distractors=[(r"$24\%$", r"Divides by the price: $\frac{360000}{150} = 2400$ bottles."),
               (r"$40\%$", r"Divides by the unit cost: $\frac{360000}{90} = 4000$ bottles."),
               (r"$15\%$", r"Divides by the sum $150 + 90 = 240$: $1500$ bottles.")],
  check=_c23, values=[60, 24, 40, 15], cognitive="Application")


def _c24():
    n = symbols('n', positive=True)
    return solve(Eq(270 * n - (90000 + 150 * n), Rational(20, 100) * (90000 + 150 * n)), n)[0]
q("C02-A-024", T, "Sales volume for a profit equal to a percentage of total cost", "Medium",
  "Inverse/parameter",
  r"A publisher's fixed cost for a new title is Rs. $90{,}000$, and each copy costs Rs. $150$ to produce and sells for Rs. $270$. Every copy produced is sold. How many copies must be sold so that the profit equals $20\%$ of the total cost?",
  "MCQ",
  r"For $n$ copies, total cost $= 90000 + 150n$ and revenue $= 270n$. Setting $270n = 1.2(90000 + 150n) = 108000 + 180n$ gives $90n = 108000$, so $n = 1200$.",
  r"Applying the $20\%$ to only part of the cost, or stopping at break-even.",
  "C02A-break-even-price-and-target", "Target profit defined on total cost, which itself depends on volume.",
  correct=r"$1{,}200$",
  distractors=[(r"$750$", r"Finds the break-even volume $\frac{90000}{120}$."),
               (r"$900$", r"Takes the target profit as $20\%$ of the fixed cost only: $120n = 108000$."),
               (r"$1{,}000$", r"Takes the target profit as $20\%$ of the production cost only: $120n = 90000 + 30n$.")],
  check=_c24, values=[1200, 750, 900, 1000], cognitive="Application")


def _c25():
    cp, sp = F(100), F(150)
    ncp, nsp = cp * F(125, 100), sp * F(110, 100)
    return _pct(nsp - ncp, ncp)
q("C02-A-025", T, "New profit percent after different percentage changes in cost and price", "Medium",
  "Multi-step word problem",
  r"A bakery sells a cake at a profit of $50\%$. Its cost then rises by $25\%$, and the bakery raises the price by only $10\%$. What is the new profit percent?",
  "MCQ",
  r"Take the old cost as $100$ and price $150$. The new cost is $125$ and the new price is $165$, so the profit is $40$ on $125$, that is $32\%$.",
  "Adding and subtracting the percentage changes as if they were points.",
  "C02A-cost-and-price-change", "Two changes on different bases; the trap is additive thinking.",
  correct=r"$32\%$",
  distractors=[(r"$35\%$", r"Adjusts the profit percent by points: $50 + 10 - 25$."),
               (r"$20\%$", r"Applies the cost rise but forgets the price rise: $\frac{150}{125}$."),
               (r"$65\%$", r"Applies the price rise but forgets the cost rise: $1.5 \times 1.1$.")],
  check=_c25, values=[32, 35, 20, 65], cognitive="Application")


def _c26():
    return sum(1 for s in range(241, 721)
               if (F(s - 240) * 100 / 240).denominator == 1 and (F(s - 240) * 100 / s).denominator == 1)
q("C02-A-026", T, "Counting selling prices that make profit percents on both cost and selling price whole numbers", "Difficult",
  "Casework/optimisation",
  r"An item costs Rs. $240$. A shopkeeper will sell it at a whole number of rupees, more than Rs. $240$ and at most Rs. $720$. For how many such selling prices are both the profit as a percentage of the cost price and the profit as a percentage of the selling price whole numbers?",
  "MCQ",
  r"For a price $s$, the profit percent on cost is $\frac{100(s - 240)}{240} = \frac{5(s - 240)}{12}$, a whole number exactly when $12$ divides $s$. The profit percent on the price is $\frac{100(s - 240)}{s} = 100 - \frac{24000}{s}$, a whole number exactly when $s$ divides $24000 = 2^6 \cdot 3 \cdot 5^3$. The divisors of $24000$ in $(240, 720]$ are $250, 300, 320, 375, 400, 480, 500, 600$, and of these only $300, 480, 600$ are multiples of $12$: $3$ prices.",
  r"Checking only one of the two bases, or reducing $\frac{100}{240}$ incompletely.",
  "C02A-integer-profit-percent", "Two divisibility conditions on different bases, one of them a divisor condition, then a careful intersection.",
  correct=r"$3$",
  distractors=[(r"$8$", r"Checks only the selling-price basis: all divisors of $24000$ in the range."),
               (r"$2$", r"Reduces $\frac{100}{240}$ only to $\frac{10}{24}$, so requires $24$ to divide $s$, which drops $300$."),
               (r"$4$", r"Reads more than Rs. $240$ as at least Rs. $240$ and counts $s = 240$, where both percentages are $0$, a whole number.")],
  check=_c26, values=[3, 8, 2, 4], cognitive="Analysis", exams=CX)


def _c27():
    cp = 437
    p = 10
    while F(p - cp, cp) < F(20, 100):
        p += 10
    return p
q("C02-A-027", T, "Lowest allowed price meeting a profit target when prices are rounded", "Easy",
  "Casework/optimisation",
  r"A store sets every price at a multiple of Rs. $10$. A blender costs the store Rs. $437$. What is the lowest price it can charge to make a profit of at least $20\%$ on cost?",
  "MCQ",
  r"A $20\%$ profit needs a price of at least $437 \times 1.2 = 524.40$ rupees. The smallest multiple of $10$ that is not below this is $530$ rupees.",
  "Rounding to the nearest multiple instead of up, or using the selling price as the base.",
  "C02A-price-window-casework", "One multiplication and a round-up; the trap is rounding to the nearest multiple.",
  correct=r"Rs. $530$",
  distractors=[(r"Rs. $520$", r"Rounds $524.40$ to the nearest multiple of $10$, which falls short of $20\%$."),
               (r"Rs. $550$", r"Takes the $20\%$ on the selling price: $\frac{437}{0.8} = 546.25$, rounded up."),
               (r"Rs. $540$", r"Takes the $20\%$ on the selling price ($546.25$) and rounds to the multiple of $10$ below it.")],
  check=_c27, values=[530, 520, 550, 540], cognitive="Application")


def _c28():
    # profit : cost = 2 : 5  -> profit : selling price
    c = 5
    p = 2
    return Rational(p, c + p)
q("C02-A-028", T, "Ratio of profit to selling price from ratio of profit to cost", "Easy",
  "Conceptual/application",
  r"On a sale, the ratio of the profit to the cost price is $2 : 5$. What is the ratio of the profit to the selling price?",
  "MCQ",
  r"Take cost $= 5$ and profit $= 2$. Then the selling price is $7$, and profit : selling price $= 2 : 7$.",
  "Keeping the cost as the base, or subtracting the profit instead of adding it.",
  "C02A-basis-conversion", "One-step basis change; the options test each base confusion.",
  correct=r"$2 : 7$",
  distractors=[(r"$2 : 5$", r"Keeps the cost as the base."),
               (r"$5 : 7$", r"Gives the ratio of cost to selling price."),
               (r"$2 : 3$", r"Takes the selling price as $5 - 2 = 3$.")],
  check=_c28, values=[Rational(2, 7), Rational(2, 5), Rational(5, 7), Rational(2, 3)], cognitive="Understanding")


def _c29():
    cp = F(36, 10)
    sp = cp * F(120, 100)
    return F(108) / sp
q("C02-A-029", T, "Selling rate (articles per amount) for a target gain", "Medium",
  "Inverse/parameter",
  r"A fruit seller buys oranges at $10$ for Rs. $36$. How many oranges should he sell for Rs. $108$ to gain $20\%$?",
  "MCQ",
  r"Cost per orange $= 3.60$ rupees, so for a $20\%$ gain he must charge $3.60 \times 1.2 = 4.32$ rupees each. For Rs. $108$ he should give $\frac{108}{4.32} = 25$ oranges.",
  r"Cutting the count by $20\%$ instead of dividing by $1.2$.",
  "C02A-rate-count-for-price", r"Rate inversion: a $20\%$ higher price means $\frac{1}{1.2}$ of the count.",
  correct=r"$25$",
  distractors=[(r"$24$", r"Finds $30$ oranges at cost and reduces the count by $20\%$."),
               (r"$30$", r"Gives the number of oranges that Rs. $108$ buys at cost, which yields no gain."),
               (r"$36$", r"Increases the count of $30$ by $20\%$ instead of decreasing it.")],
  check=_c29, values=[25, 24, 30, 36], cognitive="Application")


def _c30():
    cp = F(1350) / F(90, 100)
    s = symbols('s', positive=True)
    return solve(Eq(s - cp, Rational(20, 100) * s), s)[0]
q("C02-A-030", T, "Selling price for a profit on selling price, after a sale at a loss", "Medium",
  "Multi-step word problem",
  r"Priya sold a table lamp for Rs. $1{,}350$ at a loss of $10\%$ on cost. At what price should she have sold it for her profit to be $20\%$ of the selling price?",
  "MCQ",
  r"Cost $= \frac{1350}{0.9} = 1500$ rupees. If profit is $20\%$ of the selling price, cost is $80\%$ of it, so the price is $\frac{1500}{0.8} = 1875$ rupees.",
  r"Taking the $20\%$ on cost, or working from the old selling price.",
  "C02A-selling-price-via-cost", "Recover the cost, then apply a selling-price basis.",
  correct=r"Rs. $1{,}875$",
  distractors=[(r"Rs. $1{,}800$", r"Takes the $20\%$ profit on cost: $1500 \times 1.2$."),
               (r"Rs. $1{,}620$", r"Adds $20\%$ to the old selling price: $1350 \times 1.2$."),
               (r"Rs. $1{,}755$", r"Adds $10 + 20 = 30\%$ to the old selling price.")],
  check=_c30, values=[1875, 1800, 1620, 1755], cognitive="Application")


def _c31():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(a + b, 50000), Eq(a * Rational(120, 100), b * Rational(80, 100))], [a, b], dict=True)[0]
    return sol[b]
q("C02-A-031", T, "Cost of the loss item when two items with a known total cost sell at one price", "Medium",
  "Multi-step word problem",
  r"Joseph bought a sofa and a bed for a total of Rs. $50{,}000$. He sold both for the same price, gaining $20\%$ on one and losing $20\%$ on the other. What was the cost price of the item sold at a loss?",
  "MCQ",
  r"If the costs are $a$ and $b$ with $1.2a = 0.8b$, then $a : b = 2 : 3$. With $a + b = 50000$, the loss item cost $b = 30000$ rupees (each sold for $24000$).",
  "Splitting the cost equally, or picking the wrong item.",
  "C02A-same-price-equal-gain-loss", "Equal prices give a cost ratio, then a split of the total.",
  correct=r"Rs. $30{,}000$",
  distractors=[(r"Rs. $20{,}000$", r"Gives the cost of the item sold at a gain."),
               (r"Rs. $25{,}000$", r"Assumes the two items cost the same."),
               (r"Rs. $28{,}800$", r"Finds the common price $24000$ and adds $20\%$ to it.")],
  check=_c31, values=[30000, 20000, 25000, 28800], cognitive="Application")


def _c32():
    month, cum = 0, 0
    while cum < 420000:
        month += 1
        cum += 400 * (250 - 100) - 30000
    return month
q("C02-A-032", T, "Months needed to recover an initial investment from monthly profit", "Medium",
  "Multi-step word problem",
  r"Sneha invests Rs. $4{,}20{,}000$ in machinery for a juice kiosk. Every month she pays rent of Rs. $30{,}000$ and sells $400$ bottles at Rs. $250$ each; each bottle costs her Rs. $100$ to make. After how many complete months will her total profit (revenue minus making costs and rent) first equal the cost of the machinery?",
  "MCQ",
  r"Monthly margin $= 400 \times (250 - 100) = 60000$ rupees; after rent the profit is $30000$ rupees a month. She recovers $420000$ after $\frac{420000}{30000} = 14$ months.",
  "Leaving out the rent or the making cost, or adding one month too many.",
  "C02A-break-even-payback", "Monthly contribution net of a fixed cost, then a division.",
  correct=r"$14$",
  distractors=[(r"$15$", r"Adds one to the exact quotient, counting the month after recovery."),
               (r"$7$", r"Ignores the rent: $\frac{420000}{60000}$."),
               (r"$6$", r"Ignores the making cost: monthly profit $100000 - 30000 = 70000$, so $\frac{420000}{70000} = 6$.")],
  check=_c32, values=[14, 15, 7, 6], cognitive="Application")


def _c33():
    c = symbols('c', positive=True)
    cost = solve(Eq(2000 - c, 2 * (c - 1400)), c)[0]
    return cost * Rational(115, 100)
q("C02-A-033", T, "Cost price from two selling prices with the profit a multiple of the loss, then a target price", "Medium",
  "Multi-step word problem",
  r"Ravi finds that selling a study table for Rs. $2{,}000$ would give him a profit equal to twice the loss he would make by selling it for Rs. $1{,}400$. At what price should he sell the table to make a profit of $15\%$?",
  "MCQ",
  r"Let the cost be $c$. Then $2000 - c = 2(c - 1400)$, so $3c = 4800$ and $c = 1600$ rupees (profit $400$ at Rs. $2{,}000$, loss $200$ at Rs. $1{,}400$). A $15\%$ profit needs $1600 \times 1.15 = 1840$ rupees.",
  r"Taking the cost midway between the two prices, or reading the $2 : 1$ relation the wrong way round.",
  "C02A-cost-from-two-prices", r"Turns a profit-to-loss relation into an equation for the cost, then applies a percentage.",
  correct=r"Rs. $1{,}840$",
  distractors=[(r"Rs. $1{,}955$", r"Takes the cost as the midpoint $1700$ of the two prices, ignoring the $2 : 1$ relation: $1700 \times 1.15$."),
               (r"Rs. $2{,}070$", r"Reads the relation backwards, loss twice the profit: $c - 1400 = 2(2000 - c)$ gives $c = 1800$, and $1800 \times 1.15$."),
               (r"Rs. $2{,}300$", r"Applies the $15\%$ to the selling price of Rs. $2{,}000$ instead of to the cost.")],
  check=_c33, values=[1840, 1955, 2070, 2300], cognitive="Application")


def _c34():
    s = symbols('s', positive=True)
    return solve(Eq(40 * s - 40 * 360, 8 * s + 8 * 360), s)[0]
q("C02-A-034", T, "Selling price when profit equals the price of some units plus the cost of others", "Medium",
  "Multi-step word problem",
  r"A trader sells $40$ identical kurtas. His total profit equals the selling price of $8$ kurtas plus the cost price of $8$ kurtas. If each kurta costs him Rs. $360$, what is his selling price per kurta?",
  "MCQ",
  r"With price $s$ and cost $c = 360$: $40s - 40c = 8s + 8c$, so $32s = 48c$ and $s = 1.5c = 540$ rupees.",
  "Dropping one of the two parts of the profit statement, or treating both parts as costs.",
  "C02A-gain-equals-price-of-units", "Two-part profit statement turned into one linear equation.",
  correct=r"Rs. $540$",
  distractors=[(r"Rs. $450$", r"Ignores the cost of $8$ kurtas: $32s = 40c$."),
               (r"Rs. $432$", r"Ignores the selling price of $8$ kurtas: $40s = 48c$."),
               (r"Rs. $504$", r"Treats both parts as costs: $40(s - c) = 16c$.")],
  check=_c34, values=[540, 450, 432, 504], cognitive="Application")


# ================================================================ DIFFICULT (11)

def _c35():
    s = 480000
    cp1 = s - F(20, 100) * s          # profit 20% of SP
    cp2 = F(s) / F(80, 100)           # loss 20% of CP
    return cp1 + cp2 - 2 * s
q("C02-A-035", T, "Two items at one price with profit on selling price and loss on cost", "Medium",
  "Conceptual/application",
  r"A dealer sold two used tractors for Rs. $4{,}80{,}000$ each. On the first, his profit was $20\%$ of the selling price. On the second, his loss was $20\%$ of the cost price. What was his overall result?",
  "MCQ",
  r"First tractor: cost $= 0.8 \times 480000 = 384000$. Second: cost $= \frac{480000}{0.8} = 600000$. Total cost $984000$ against sales of $960000$, so the overall loss is $24000$ rupees.",
  "Applying the equal-percentage shortcut without noticing that the two percentages have different bases.",
  "C02A-same-price-unequal-results", "Two cost recoveries on different bases, a sum and a subtraction; the trap is the equal-percentage shortcut.",
  correct=r"Loss of Rs. $24{,}000$",
  distractors=[(r"Loss of Rs. $40{,}000$", r"Treats both percentages as on cost: costs $400000$ and $600000$."),
               (r"Loss of Rs. $16{,}000$", r"Swaps the bases: first cost $\frac{480000}{1.2} = 400000$, second cost $480000 + 0.2 \times 480000 = 576000$ (loss as $20\%$ of the price)."),
               (r"Loss of Rs. $38{,}400$", r"Uses the shortcut loss of $\frac{20^2}{100} = 4\%$ and applies it to the total selling price $960000$.")],
  check=_c35, values=[24000, 40000, 16000, 38400], cognitive="Analysis")


def _c36():
    return sum(1 for c in range(600, 1200) if (F(1200 - c) * 100 / c).denominator == 1)
q("C02-A-036", T, "Counting whole-rupee cost prices that give a whole-number profit percent", "Difficult",
  "Casework/optimisation",
  r"A gadget is sold for Rs. $1{,}200$ at a profit. Its cost price is a whole number of rupees, the profit percent on cost is a whole number, and the profit is at most $100\%$ of the cost. How many cost prices are possible?",
  "TITA",
  r"With cost $c$, the profit percent is $\frac{100(1200 - c)}{c} = \frac{120000}{c} - 100$, a whole number exactly when $c$ divides $120000 = 2^6 \cdot 3 \cdot 5^4$. The profit is at most $100\%$ when $c \ge 600$, and there is a profit when $c < 1200$. The divisors of $120000$ in $[600, 1199]$ are $600, 625, 750, 800, 960, 1000$: $6$ cost prices.",
  r"Reading 'at most $100\%$' as strictly less, or including a cost of $1200$, which gives no profit.",
  "C02A-integer-profit-percent", "Converts a percentage condition into a divisibility condition and lists divisors in a window.",
  tita_answer=6, check=_c36,
  tita_traps=[(5, r"Excludes $c = 600$, reading 'at most $100\%$' as strictly less than $100\%$."),
              (7, r"Includes $c = 1200$, where there is no profit.")],
  cognitive="Analysis", exams=CX)


def _c37():
    k = 0
    while k * (1 * (500 - 300) + 8 * (60 - 35)) < 120000:
        k += 1
    return k
q("C02-A-037", T, "Break-even with two products sold in a fixed ratio", "Difficult",
  "Multi-step word problem",
  r"A bakery sells only cakes and pastries, always in the ratio $1$ cake to $8$ pastries. A cake sells for Rs. $500$ and costs Rs. $300$ to make; a pastry sells for Rs. $60$ and costs Rs. $35$. Monthly fixed costs are Rs. $1{,}20{,}000$. How many cakes must it sell in a month to break even?",
  "MCQ",
  r"Treat $1$ cake and $8$ pastries as a bundle. Its margin is $(500 - 300) + 8(60 - 35) = 200 + 200 = 400$ rupees. Break-even needs $\frac{120000}{400} = 300$ bundles, that is $300$ cakes.",
  "Ignoring the pastries, using prices instead of margins, or reporting the total number of items.",
  "C02A-break-even-units", "Needs the bundle idea to combine two margins in a fixed mix.",
  correct=r"$300$",
  distractors=[(r"$600$", r"Ignores the pastries: $\frac{120000}{200}$."),
               (r"$240$", r"Divides by the cake's price $500$ instead of the bundle margin."),
               (r"$2{,}700$", r"Reports the total number of items, $300 \times 9$.")],
  check=_c37, values=[300, 600, 240, 2700], cognitive="Analysis", exams=CX)


def _c38():
    fixed, price, base_cost, cap = 180000, 100, 40, 5000
    extra_fixed, extra_cost, target = 15000, 55, 132000
    def profit(n):
        if n <= cap:
            return n * (price - base_cost) - fixed
        return (cap * (price - base_cost) + (n - cap) * (price - extra_cost)
                - fixed - extra_fixed)
    n = 1
    while profit(n) < target:
        n += 1
    return n
q("C02-A-038", T, "Sales volume for a profit target when costs step up beyond a capacity", "Difficult",
  "Casework/optimisation",
  r"A cafe has fixed costs of Rs. $1{,}80{,}000$ a month and sells coffee at Rs. $100$ a cup. Its machine can make up to $5{,}000$ cups a month at Rs. $40$ a cup. If it makes more than $5{,}000$ cups in a month, it must also rent a second machine for Rs. $15{,}000$ that month, and every cup beyond the $5{,}000$th costs Rs. $55$ to make. Every cup made is sold. What is the least number of cups it must sell in a month to make a profit of at least Rs. $1{,}32{,}000$?",
  "TITA",
  r"At $5{,}000$ cups the profit is $5000 \times 60 - 180000 = 120000$ rupees, short of the target, so the second machine is needed. Beyond $5{,}000$ cups each cup adds $100 - 55 = 45$ rupees, and the extra cups must cover the shortfall $12000$ plus the rent $15000$: $\frac{27000}{45} = 600$ cups. The least volume is $5600$ cups.",
  "Using the first margin throughout, or forgetting the second machine's rent or the higher cost per extra cup.",
  "C02A-break-even-price-and-target", "Piecewise costs: the candidate must test the capacity first, then combine a new margin with an extra fixed charge.",
  tita_answer=5600, check=_c38,
  tita_traps=[(5200, r"Uses the margin of $60$ for every cup and ignores the capacity: $\frac{180000 + 132000}{60}$."),
              (5450, r"Adds the rent but keeps the margin of $60$ on the extra cups: $\frac{27000}{60} = 450$ extra."),
              (5267, r"Ignores the rent: $\frac{12000}{45} = 266.7$ extra cups, rounded up.")],
  cognitive="Analysis", exams=CX)


def _c39():
    s, c = symbols('s c', positive=True)
    rel = solve(Eq(Rational(120, 100) * s - c, 2 * (s - c)), c)[0]   # c in terms of s
    # cost of 15 = selling price of n  ->  n = 15c/s
    return simplify(15 * rel / s)
q("C02-A-039", T, "Count in a cost-equals-price relation fixed by a profit-doubling condition", "Difficult",
  "Inverse/parameter",
  r"The cost price of $15$ identical mugs equals the selling price of $n$ such mugs. If the selling price of each mug were $20\%$ higher, the profit in rupees on each mug would be exactly double what it is now. Find $n$.",
  "TITA",
  r"With cost $c$ and price $s$: $1.2s - c = 2(s - c)$, so $c = 0.8s$, a profit of $25\%$ on cost. Then $15c = 12s$, so the cost of $15$ mugs equals the selling price of $12$ mugs: $n = 12$.",
  r"Taking the profit as $20\%$ (the price rise) instead of solving the doubling condition.",
  "C02A-cost-of-x-equals-price-of-y", "Two linked conditions; the doubling equation must be solved first.",
  tita_answer=12, check=_c39,
  cognitive="Analysis", exams=CX)


def _c40():
    for n in range(5, 200):
        cp, sp = F(20, n), F(20, n - 4)
        if sp - cp == F(20, 100) * sp:
            return n
q("C02-A-040", T, "Unknown buying rate from a profit stated on the selling price", "Difficult",
  "Inverse/parameter",
  r"A fruit seller buys bananas at the rate of $n$ for Rs. $20$ and sells them at the rate of $n - 4$ for Rs. $20$. His profit is $20\%$ of his selling price. What is $n$?",
  "MCQ",
  r"Cost per banana $= \frac{20}{n}$, price $= \frac{20}{n-4}$, so price : cost $= n : (n - 4)$. A profit of $20\%$ of the price means cost is $80\%$ of price, so $\frac{n}{n-4} = \frac{5}{4}$, giving $4n = 5n - 20$ and $n = 20$.",
  r"Taking the $20\%$ on cost, or converting between bases in the wrong direction.",
  "C02A-rate-buy-sell-profit", "Rate inversion with an unknown and a selling-price basis.",
  correct=r"$20$",
  distractors=[(r"$24$", r"Takes $20\%$ on cost: $\frac{n}{n-4} = \frac{6}{5}$."),
               (r"$28$", r"Converts $20\%$ of price to $\frac{20}{120} = 16\frac{2}{3}\%$ on cost (wrong direction): $\frac{n}{n-4} = \frac{7}{6}$."),
               (r"$16$", r"Converts correctly to $25\%$ on cost but then sets the $4$ extra bananas as $25\%$ of $n$.")],
  check=_c40, values=[20, 24, 28, 16], cognitive="Analysis", exams=CX)


def _c41():
    # buy in lots of 7 (Rs 30), sell only in packs of 6 (Rs 33); all pens sold
    for n in range(1, 2000):
        if n % 7 == 0 and n % 6 == 0:
            profit = F(33, 6) * n - F(30, 7) * n
            if profit >= 500:
                return n
q("C02-A-041", T, "Minimum stock to reach a profit target with lot-size constraints", "Difficult",
  "Casework/optimisation",
  r"A stationer can buy pens only in lots of $7$ for Rs. $30$ and can sell them only in packs of $6$ for Rs. $33$. He buys some lots and sells all the pens he buys, with none left over. What is the least number of pens he must buy to make a profit of at least Rs. $500$?",
  "TITA",
  r"The number of pens must be a multiple of both $7$ and $6$, that is of $42$. On $42$ pens he pays $6 \times 30 = 180$ and receives $7 \times 33 = 231$, a profit of $51$. He needs $51k \ge 500$, so $k = 10$ and he buys $420$ pens.",
  "Ignoring one or both lot sizes, or rounding the number of blocks down.",
  "C02A-rate-count-for-profit", "Unit profit plus an LCM constraint and a ceiling.",
  tita_answer=420, check=_c41,
  tita_traps=[(412, r"Ignores the lot sizes: profit per pen $\frac{17}{14}$, so $\frac{500 \times 14}{17} = 411.8$, rounded up."),
              (378, r"Uses blocks of $42$ but rounds $\frac{500}{51} = 9.8$ down to $9$.")],
  cognitive="Analysis", exams=CX)


def _c42():
    cum, m = 0, 0
    while cum < 840000:
        m += 1
        units = 300 if m <= 4 else 500
        cum += units * (500 - 200) - 50000
    return m
q("C02-A-042", T, "Payback month when monthly profit changes after a launch phase", "Difficult",
  "Multi-step word problem",
  r"A start-up spends Rs. $8{,}40{,}000$ on equipment. It sells its product at Rs. $500$ a unit; each unit costs Rs. $200$ to make, and other running costs are Rs. $50{,}000$ a month. In each of the first $4$ months it sells $300$ units, and from the $5$th month onwards it sells $500$ units a month. Profit each month is revenue minus unit costs and running costs. At the end of which month does its total profit first reach at least the cost of the equipment?",
  "MCQ",
  r"Months $1$ to $4$ each give $300 \times 300 - 50000 = 40000$, a total of $160000$. Later months each give $500 \times 300 - 50000 = 100000$. The remaining $680000$ needs $\lceil 6.8 \rceil = 7$ more months, so the cost is recovered at the end of month $4 + 7 = 11$.",
  "Ignoring one of the two phases, or rounding the months in the second phase down.",
  "C02A-break-even-payback", "Two phases with different monthly profits, a ceiling in the second phase, and careful month counting.",
  correct=r"Month $11$",
  distractors=[(r"Month $10$", r"Rounds the $6.8$ months of the second phase down to $6$."),
               (r"Month $9$", r"Ignores the launch phase and uses $100000$ a month throughout: $\lceil 8.4 \rceil$."),
               (r"Month $21$", r"Ignores the rise in sales and uses $40000$ a month throughout: $\frac{840000}{40000}$.")],
  check=_c42, values=[11, 10, 9, 21], cognitive="Analysis", exams=CX)


def _c43():
    cum, m = 0, 0
    while True:
        m += 1
        units = 100 + 50 * (m - 1)
        cum += 200 * units - 20000
        if cum >= 150000:
            return m
q("C02-A-043", T, "Break-even month with sales growing every month", "Difficult",
  "Casework/optimisation",
  r"Kabir spends Rs. $1{,}50{,}000$ to set up a shop. His rent is Rs. $20{,}000$ a month. He sells $100$ units in the first month and $50$ more units each month than in the month before, earning Rs. $200$ on each unit over its cost. Counting the set-up cost, rent and unit margins, at the end of which month does his total profit first reach zero or more?",
  "MCQ",
  r"In month $k$ he sells $100 + 50(k-1)$ units, so his monthly profit after rent is $200(100 + 50(k-1)) - 20000 = 10000(k-1)$. After $k$ months the total is $5000k(k-1)$, which reaches $150000$ when $k(k-1) = 30$, that is at the end of month $6$.",
  "Ignoring the rent, treating the growth as absent, or requiring the total to be strictly positive.",
  "C02A-break-even-payback", "Builds a growing monthly profit, sums it and solves a quadratic condition.",
  correct=r"Month $6$",
  distractors=[(r"Month $7$", r"Requires the total to be strictly positive; at the end of month $6$ it is exactly zero."),
               (r"Month $5$", r"Ignores the rent: the total $20000k + 5000k(k-1)$ first reaches $150000$ at $k = 5$."),
               (r"Month $16$", r"Treats every month as earning the month-$2$ profit of $10000$: $1 + 15$ months.")],
  check=_c43, values=[6, 7, 5, 16], cognitive="Analysis", exams=CX)


def _c44():
    return sum(1 for p in range(25, 3000, 25)
               if (p - 1180) >= F(12, 100) * p and (p - 1180) < F(20, 100) * 1180)
q("C02-A-044", T, "Counting allowed prices between a selling-price floor and a cost-price ceiling", "Difficult",
  "Casework/optimisation",
  r"A store sets every price at a multiple of Rs. $25$. For a printer that costs it Rs. $1{,}180$, it wants a profit of at least $12\%$ of the selling price, but less than $20\%$ of the cost price. How many prices satisfy both conditions?",
  "MCQ",
  r"A profit of at least $12\%$ of the price means cost $\le 88\%$ of price, so the price is at least $\frac{1180}{0.88} \approx 1340.9$. A profit below $20\%$ of cost means the price is below $1.2 \times 1180 = 1416$. The multiples of $25$ in this window are $1350, 1375, 1400$: $3$ prices.",
  "Applying a percentage to the wrong base on either bound.",
  "C02A-price-window-casework", "Two bounds on different bases, then a lattice count.",
  correct=r"$3$",
  distractors=[(r"$4$", r"Takes the lower bound as $12\%$ of cost: price $\ge 1321.6$, admitting $1325$."),
               (r"$5$", r"Takes the upper bound as $20\%$ of the price: price $< 1475$, admitting $1425$ and $1450$."),
               (r"$6$", r"Swaps both bases: $1321.6 \le$ price $< 1475$.")],
  check=_c44, values=[3, 4, 5, 6], cognitive="Analysis", exams=CX)


def _c45():
    s = symbols('s', positive=True)
    total_cp = s / Rational(115, 100) + s / Rational(85, 100)
    return solve(Eq(total_cp - 2 * s, 450), s)[0]
q("C02-A-045", T, "Common selling price from the overall loss with equal gain and loss percents", "Medium",
  "Inverse/parameter",
  r"Meera sold two paintings at the same price. On one she gained $15\%$ and on the other she lost $15\%$, both on cost. Her overall loss was Rs. $450$. At what price, in rupees, did she sell each painting?",
  "TITA",
  r"Equal gain and loss of $15\%$ at one price give an overall loss of $\frac{15^2}{100} = 2.25\%$ of the total cost. So the total cost is $\frac{450}{0.0225} = 20000$, the total selling price is $20000 - 450 = 19550$, and each painting sold for $9775$ rupees.",
  "Stopping at the total cost or the total selling price.",
  "C02A-same-price-equal-gain-loss", "Reverses the equal-percentage result, then two short steps to a single price.",
  tita_answer=9775, check=_c45,
  tita_traps=[(10000, r"Halves the total cost $20000$ instead of the total selling price."),
              (19550, r"Reports the total selling price of both paintings.")],
  cognitive="Analysis")
