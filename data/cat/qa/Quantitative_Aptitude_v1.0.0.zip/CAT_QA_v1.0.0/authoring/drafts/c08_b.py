import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

ALL6 = ("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET")
HARD = ("CAT", "XAT")


def ms(kmh):
    """km/h to m/s, exact."""
    return Fraction(kmh) * 5 / 18


def kmh(mps):
    """m/s to km/h, exact."""
    return Fraction(mps) * 18 / 5


# ---------------------------------------------------------------- EASY

def _c001():
    L, t_post, P = 180, 12, 270
    v = Fraction(L, t_post)
    return (L + P) / v
q("C08-B-001", "Trains", "Speed from a signal post, then time to cross a platform", "Easy",
  "Multi-step word problem",
  r"A train $180$ m long passes a signal post in $12$ seconds. Running at the same speed, how many seconds will it take to cross a platform $270$ m long completely?",
  "TITA",
  r"Passing the post, the train covers its own length, so its speed is $\frac{180}{12} = 15$ m/s. To cross the platform completely it must cover $180 + 270 = 450$ m, which takes $\frac{450}{15} = 30$ seconds.",
  "Using only the platform length as the distance, ignoring the length of the train.",
  "C08B-platform-bridge", "One speed from the post, then one division with the train-plus-platform distance.",
  tita_answer=30, check=_c001, values=[30],
  tita_traps=[(18, "Uses only the platform length: $\\frac{270}{15} = 18$."),
              (6, "Uses the difference of lengths: $\\frac{270 - 180}{15} = 6$.")],
  exams=ALL6)


def _c002():
    v = ms(90)
    L = v * 10
    return v * 22 - L
q("C08-B-002", "Trains", "Bridge length from pole time, bridge time and speed", "Easy",
  "Multi-step word problem",
  r"A train running at a uniform speed of $90$ km/h passes a signal pole in $10$ seconds and crosses a bridge completely in $22$ seconds. What is the length of the bridge?",
  "MCQ",
  r"$90$ km/h $= 25$ m/s. The extra $22 - 10 = 12$ seconds are spent covering exactly the bridge length, so the bridge is $25 \times 12 = 300$ m. (Equivalently, the train is $250$ m long and $25 \times 22 - 250 = 300$ m.)",
  "Taking the whole distance covered while crossing the bridge as the bridge length.",
  "C08B-platform-bridge", "Two short steps once the speed is converted to m/s.",
  correct=r"$300$ m",
  distractors=[(r"$550$ m", "Takes the full distance $25 \\times 22$ as the bridge length, forgetting to subtract the train's own $250$ m."),
               (r"$250$ m", "Reports the length of the train ($25 \\times 10$) instead of the bridge."),
               (r"$1{,}080$ m", "Skips the km/h to m/s conversion: $90 \\times (22 - 10) = 1080$.")],
  check=_c002, values=[300, 550, 250, 1080], exams=ALL6)


def _c003():
    v, L = symbols('v L', positive=True)
    s = solve([Eq(L, 9 * v), Eq(L + 300, 24 * v)], [v, L], dict=True)[0]
    return kmh(Rational(s[v]))
q("C08-B-003", "Trains", "Speed from times to pass a post and a platform", "Easy",
  "Inverse/parameter",
  r"A train passes a telegraph post in $9$ seconds and crosses a platform $300$ m long completely in $24$ seconds, running at the same uniform speed throughout. What is the speed of the train?",
  "MCQ",
  r"The extra $24 - 9 = 15$ seconds are spent covering the platform, so the speed is $\frac{300}{15} = 20$ m/s. In km/h this is $20 \times \frac{18}{5} = 72$ km/h.",
  "Dividing the platform length by the full crossing time, ignoring that the train also covers its own length.",
  "C08B-two-crossing-times", "Difference of the two times isolates the platform; one conversion.",
  correct=r"$72$ km/h",
  distractors=[(r"$45$ km/h", "Divides $300$ m by the full $24$ s: $12.5$ m/s $= 45$ km/h, ignoring the train's own length."),
               (r"$120$ km/h", "Divides the platform length by the post time: $\\frac{300}{9}$ m/s $= 120$ km/h."),
               (r"$20$ km/h", "Finds $20$ m/s correctly but does not convert it to km/h.")],
  check=_c003, values=[72, 45, 120, 20], exams=ALL6)


def _c004():
    rel = ms(50) + ms(58)
    return Fraction(120 + 180) / rel
q("C08-B-004", "Trains", "Two trains crossing each other in opposite directions", "Easy",
  "Single-step computation",
  r"Two trains, $120$ m and $180$ m long, run on parallel tracks in opposite directions at $50$ km/h and $58$ km/h respectively. From the moment their engines meet, how long do they take to pass each other completely?",
  "MCQ",
  r"In opposite directions the relative speed is $50 + 58 = 108$ km/h $= 30$ m/s. Together they must clear $120 + 180 = 300$ m, which takes $\frac{300}{30} = 10$ seconds.",
  "Subtracting the speeds for trains moving in opposite directions, or using only one train's length.",
  "C08B-opposite-crossing", "Single relative-speed computation with a units step.",
  correct=r"$10$ seconds",
  distractors=[(r"$135$ seconds", "Subtracts the speeds as if both moved the same way: $8$ km/h $= \\frac{20}{9}$ m/s and $\\frac{300}{20/9} = 135$."),
               (r"$6$ seconds", "Uses only the longer train's length: $\\frac{180}{30} = 6$."),
               (r"$4$ seconds", "Uses only the shorter train's length: $\\frac{120}{30} = 4$.")],
  check=_c004, values=[10, 135, 6, 4], exams=ALL6)


def _c005():
    rel = ms(72) - ms(54)
    return Fraction(175 + 105) / rel
q("C08-B-005", "Trains", "Faster train overtaking a slower train, same direction", "Easy",
  "Single-step computation",
  r"An express train $175$ m long running at $72$ km/h overtakes a goods train $105$ m long running at $54$ km/h on a parallel track in the same direction. From the moment the express's engine draws level with the rear of the goods train, how long does the express take to pass the goods train completely?",
  "MCQ",
  r"In the same direction the relative speed is $72 - 54 = 18$ km/h $= 5$ m/s. The express must gain $175 + 105 = 280$ m on the goods train, which takes $\frac{280}{5} = 56$ seconds.",
  "Adding the speeds for trains moving in the same direction, or counting only one train's length.",
  "C08B-same-direction-overtake", "One relative-speed step; the trap is the direction and the sum of lengths.",
  correct=r"$56$ seconds",
  distractors=[(r"$8$ seconds", "Adds the speeds: $126$ km/h $= 35$ m/s, and $\\frac{280}{35} = 8$."),
               (r"$35$ seconds", "Uses only the express's length: $\\frac{175}{5} = 35$."),
               (r"$21$ seconds", "Uses only the goods train's length: $\\frac{105}{5} = 21$.")],
  check=_c005, values=[56, 8, 35, 21], exams=ALL6)


def _c006():
    # simulate rear of train reaching the man: front starts level with man
    v, w = ms(57), ms(3)
    # gap between man and train rear initially 300 m, closes at v - w
    return Fraction(300) / (v - w)
q("C08-B-006", "Trains", "Train overtaking a man walking in the same direction", "Easy",
  "Single-step computation",
  r"A train $300$ m long running at $57$ km/h overtakes a man walking beside the track at $3$ km/h in the same direction as the train. In how many seconds does the train pass him completely?",
  "TITA",
  r"Relative to the man, the train moves at $57 - 3 = 54$ km/h $= 15$ m/s. It must cover its own length of $300$ m relative to him, so the time is $\frac{300}{15} = 20$ seconds.",
  "Adding the man's speed, as if he were walking towards the train.",
  "C08B-train-passes-walker", "One relative-speed subtraction and a unit conversion.",
  tita_answer=20, check=_c006, values=[20],
  tita_traps=[(18, "Adds the speeds: $60$ km/h $= \\frac{50}{3}$ m/s gives $18$ s.")],
  exams=ALL6)


def _c007():
    # metres and seconds; goods engine at 0 moving +, passenger engine at 1200 moving -
    vg, vp = ms(36), ms(54)
    Lg, Lp = 400, 200
    t = symbols('t', positive=True)
    goods_rear = vg * t - Lg
    pass_rear = 1200 - vp * t + Lp
    return solve(Eq(goods_rear, pass_rear), t)[0]
q("C08-B-007", "Trains", "Opposite-direction crossing that starts from a gap between the engines", "Easy",
  "Multi-step word problem",
  r"A goods train $400$ m long running at $36$ km/h and a passenger train $200$ m long running at $54$ km/h approach each other on parallel tracks, moving in opposite directions at constant speeds. At a certain instant the two engines are $1.2$ km apart. How long after that instant have the two trains completely passed each other?",
  "MCQ",
  r"The trains approach each other at $36 + 54 = 90$ km/h $= 25$ m/s. Before they have completely passed, they must close the $1200$ m gap between the engines and then clear both lengths, $400 + 200 = 600$ m: $1800$ m in all. This takes $\frac{1800}{25} = 72$ seconds.",
  "Stopping when the engines meet, or counting only the lengths and forgetting the initial gap.",
  "C08B-opposite-crossing", "One relative speed; the trap is adding the gap and both lengths.",
  correct=r"$72$ seconds",
  distractors=[(r"$48$ seconds", "Stops when the engines meet: $\\frac{1200}{25} = 48$."),
               (r"$24$ seconds", "Counts only the two lengths, as if timing started when the engines met: $\\frac{600}{25} = 24$."),
               (r"$360$ seconds", "Subtracts the speeds: $18$ km/h $= 5$ m/s, and $\\frac{1800}{5} = 360$.")],
  check=_c007, values=[72, 48, 24, 360], exams=ALL6)


def _c008():
    v1 = Fraction(200, 10)
    v2 = Fraction(300, 20)
    return v1 / v2
q("C08-B-008", "Trains", "Ratio of speeds from lengths and pole-crossing times", "Easy",
  "Conceptual/application",
  r"Two trains are $200$ m and $300$ m long. The first passes a pole in $10$ seconds and the second passes the same pole in $20$ seconds. The ratio of the speed of the first train to that of the second is",
  "MCQ",
  r"Passing a pole, each train covers its own length. The speeds are $\frac{200}{10} = 20$ m/s and $\frac{300}{20} = 15$ m/s, so the ratio is $20 : 15 = 4 : 3$.",
  "Treating speed as simply inversely proportional to the passing time, ignoring that the lengths differ.",
  "C08B-crossing-time-ratio", "Single idea: distance covered past a pole is the train's own length.",
  correct=r"$4 : 3$",
  distractors=[(r"$2 : 1$", "Inverts the time ratio $10 : 20$, ignoring the different lengths."),
               (r"$1 : 2$", "Reports the ratio of the times."),
               (r"$2 : 3$", "Reports the ratio of the lengths.")],
  check=_c008, values=[Fraction(4, 3), 2, Fraction(1, 2), Fraction(2, 3)], exams=ALL6)


def _c009():
    return (ms(45) + ms(63)) * 9
q("C08-B-009", "Trains", "Passenger in a train timing a train going the other way", "Easy",
  "Single-step computation",
  r"Sneha is sitting at a window of a train moving at $45$ km/h. A goods train moving at $63$ km/h in the opposite direction on a parallel track takes $9$ seconds to pass her window completely. What is the length of the goods train, in metres?",
  "TITA",
  r"Relative to Sneha, the goods train moves at $45 + 63 = 108$ km/h $= 30$ m/s. In $9$ seconds it moves its whole length past her, so its length is $30 \times 9 = 270$ m. Sneha's own train's length plays no part because she is a single point.",
  "Subtracting the speeds, or not converting km/h to m/s.",
  "C08B-man-in-train", "One relative speed (opposite directions) and a unit conversion.",
  tita_answer=270, check=_c009, values=[270],
  tita_traps=[(45, "Subtracts the speeds: $18$ km/h $= 5$ m/s, giving $45$ m."),
              (972, "Multiplies $108 \\times 9$ without converting to m/s.")],
  exams=ALL6)


def _c010():
    # step simulation in minutes after 7:00 am
    t = Fraction(90)
    while True:
        d1 = Fraction(60, 60) * t
        d2 = Fraction(90, 60) * (t - 90)
        if d2 >= d1:
            return d2
        t += 1
q("C08-B-010", "Relative speed", "Later train catching an earlier train from the same station", "Easy",
  "Multi-step word problem",
  r"A goods train leaves station P at $7{:}00$ am and runs at $60$ km/h. An express leaves P at $8{:}30$ am on a parallel track in the same direction and runs at $90$ km/h. Both speeds are constant. At what distance from P does the express draw level with the goods train?",
  "MCQ",
  r"By $8{:}30$ am the goods train is $60 \times 1.5 = 90$ km ahead. The express gains $90 - 60 = 30$ km every hour, so it draws level after $\frac{90}{30} = 3$ hours. In that time the express covers $90 \times 3 = 270$ km from P.",
  "Reporting the goods train's distance during the chase instead of its total distance from P.",
  "C08B-later-start-catchup", "Head start then relative speed; the trap is what distance is asked.",
  correct=r"$270$ km",
  distractors=[(r"$180$ km", "Reports only the goods train's run during the $3$-hour chase, $60 \\times 3$, forgetting its $90$ km head start."),
               (r"$90$ km", "Reports the head start itself."),
               (r"$54$ km", "Adds the speeds: $\\frac{90}{150} = 0.6$ h, then $90 \\times 0.6 = 54$ km.")],
  check=_c010, values=[270, 180, 90, 54], exams=ALL6)


def _c011():
    v = ms(72)
    L, T = 240, 600
    # rear enters at t = L/v, front exits at t = T/v (front entered at t = 0)
    return Fraction(T) / v - Fraction(L) / v
q("C08-B-011", "Trains", "Time for which a whole train is inside a tunnel", "Easy",
  "Conceptual/application",
  r"A train $240$ m long running at $72$ km/h enters a tunnel $600$ m long. For how many seconds is the entire train inside the tunnel?",
  "TITA",
  r"$72$ km/h $= 20$ m/s. The whole train is inside from the moment its rear enters (after the front has gone $240$ m into the tunnel) until its front reaches the exit (after the front has gone $600$ m). The front travels $600 - 240 = 360$ m in between, which takes $\frac{360}{20} = 18$ seconds.",
  "Computing the time for which any part of the train is in the tunnel, which uses the sum of the lengths.",
  "C08B-fully-inside-tunnel", "One idea, but the sum versus difference of lengths is a strong trap.",
  tita_answer=18, check=_c011, values=[18],
  tita_traps=[(42, "Uses $600 + 240 = 840$ m: the time for which any part of the train is inside."),
              (30, "Uses only the tunnel length: $\\frac{600}{20} = 30$.")],
  cognitive="Understanding", exams=ALL6)


def _c012():
    V = symbols('V', positive=True)  # train speed km/h
    s = solve(Eq(330, ms(1) * (V + 18) * 18), V)
    return s[0]
q("C08-B-012", "Trains", "Train speed from time to pass an oncoming cyclist", "Easy",
  "Inverse/parameter",
  r"A train $330$ m long passes a cyclist, who is riding at $18$ km/h in the opposite direction beside the track, completely in $18$ seconds. What is the speed of the train?",
  "MCQ",
  r"The relative speed is $\frac{330}{18} = \frac{55}{3}$ m/s $= \frac{55}{3} \times \frac{18}{5} = 66$ km/h. Since they move towards each other, this is the sum of the speeds, so the train runs at $66 - 18 = 48$ km/h.",
  "Treating the relative speed as the train's speed, or adding the cyclist's speed instead of subtracting it.",
  "C08B-train-passes-walker", "Relative speed then one subtraction; the direction decides the sign.",
  correct=r"$48$ km/h",
  distractors=[(r"$84$ km/h", "Adds the cyclist's speed to $66$ km/h, as if the cyclist were moving the same way as the train."),
               (r"$66$ km/h", "Reports the relative speed as the train's speed."),
               (r"$61$ km/h", "Subtracts the cyclist's speed in m/s ($5$) from the relative speed in km/h: $66 - 5$.")],
  check=_c012, values=[48, 84, 66, 61], exams=ALL6)


# ---------------------------------------------------------------- MEDIUM

def _c013():
    V = symbols('V', positive=True)
    return solve(Eq((V - 3) * 9, (V - 6) * 10), V)[0]
q("C08-B-013", "Trains", "Train speed from times to pass two people moving the same way", "Medium",
  "Inverse/parameter",
  r"A train overtakes a man walking at $3$ km/h and passes him completely in $9$ seconds. Later, running at the same speed, it overtakes a cyclist riding at $6$ km/h and passes her completely in $10$ seconds. Both are moving in the same direction as the train. What is the speed of the train, in km/h?",
  "TITA",
  r"In each case the train covers its own length relative to the person, so $(V - 3) \times 9 = (V - 6) \times 10$ (the km/h to m/s factor cancels). This gives $9V - 27 = 10V - 60$, so $V = 33$ km/h. As a check, the length is $30$ km/h $\times 9$ s $= \frac{25}{3} \times 9 = 75$ m, and $27$ km/h $\times 10$ s $= 7.5 \times 10 = 75$ m.",
  "Treating the train's speed as the relative speed, or reporting the length.",
  "C08B-two-moving-persons-speed", "Equating the same length through two relative speeds; two steps.",
  tita_answer=33, check=_c013, values=[33],
  tita_traps=[(75, "Reports the length of the train in metres instead of its speed."),
              (30, "Reports the speed relative to the walker, $V - 3$.")],
  exams=ALL6)


def _c014():
    # positions in km, time in hours after 10:00 am; train front at 0 at t=0 meets Ravi
    V, a, b = 48, 3, 6
    t_meera = Fraction(12, 60)
    meera_pos_at_tm = V * t_meera
    t = symbols('t', positive=True)
    ravi = a * t
    meera = meera_pos_at_tm - b * (t - t_meera)
    s = solve(Eq(ravi, meera), t)[0]
    return 10 * 60 + s * 60
q("C08-B-014", "Relative speed", "Train passes two people at different times; when do the people meet", "Medium",
  "Multi-step word problem",
  r"A train runs at a constant $48$ km/h along a straight track. Its engine draws level with Ravi at $10{:}00$ am; Ravi is walking beside the track at $3$ km/h in the same direction as the train. At $10{:}12$ am the engine draws level with Meera, who is jogging beside the track at $6$ km/h towards the train (and so towards Ravi). Treating Ravi and Meera as points and all speeds as constant, at what time do Ravi and Meera meet?",
  "MCQ",
  r"At $10{:}12$ am the engine, and so Meera, is $48 \times \frac{12}{60} = 9.6$ km beyond Ravi's $10{:}00$ am position, while Ravi has walked $3 \times \frac{12}{60} = 0.6$ km. The gap between them is $9$ km and they close it at $3 + 6 = 9$ km/h, which takes $1$ hour. They meet at $11{:}12$ am.",
  "Forgetting that Ravi keeps walking during the first $12$ minutes, or counting the hour from $10{:}00$ am.",
  "C08B-two-persons-passed-meet", "Positions at the second sighting, then closing speed; three short steps.",
  correct=r"$11{:}12$ am",
  distractors=[(r"$11{:}00$ am", "Finds the $1$ hour correctly but adds it to $10{:}00$ am instead of $10{:}12$ am."),
               (r"$11{:}16$ am", "Ignores Ravi's $0.6$ km during the first $12$ minutes: $\\frac{9.6}{9}$ h $= 64$ min after $10{:}12$ am."),
               (r"$1{:}12$ pm", "Uses the difference of their speeds, $6 - 3 = 3$ km/h: $\\frac{9}{3} = 3$ h after $10{:}12$ am.")],
  check=_c014, values=[672, 660, 676, 792], exams=HARD)


def _c015():
    L = (ms(72) - ms(36)) * 30
    return L / (ms(72) + ms(36))
q("C08-B-015", "Trains", "Overtaking time converted to oncoming crossing time for a car", "Medium",
  "Conceptual/application",
  r"A train running at $72$ km/h overtakes a car travelling at $36$ km/h in the same direction on a road parallel to the track, and passes it completely in $30$ seconds. Treating the car as a point, how long would the train take to pass the car completely if the car were travelling at $36$ km/h in the opposite direction?",
  "MCQ",
  r"The length is fixed, so the passing time is inversely proportional to the relative speed. Same direction: $72 - 36 = 36$ km/h; opposite: $72 + 36 = 108$ km/h. Hence the time is $30 \times \frac{36}{108} = 10$ seconds. (Directly, the train is $10 \times 30 = 300$ m long and $\frac{300}{30} = 10$ s.)",
  "Using the train's own speed in place of the relative speed, or scaling the time the wrong way.",
  "C08B-time-inverse-relative-speed", "Needs the insight that time scales inversely with relative speed.",
  correct=r"$10$ seconds",
  distractors=[(r"$15$ seconds", "Finds the length $300$ m but divides by the train's own speed $20$ m/s, ignoring the car."),
               (r"$20$ seconds", "Scales $30$ s by $\\frac{72}{108}$, using the train's speed in the numerator."),
               (r"$90$ seconds", "Scales the time up by $\\frac{108}{36}$, as if time grew with relative speed.")],
  check=_c015, values=[10, 15, 20, 90], cognitive="Understanding", exams=ALL6)


def _c016():
    x, y = symbols('x y', positive=True)  # m/s
    s = solve([Eq(400, (x + y) * 10), Eq(400, (x - y) * 40)], [x, y], dict=True)[0]
    return kmh(Rational(s[x]))
q("C08-B-016", "Trains", "Speeds from opposite and same-direction crossing times", "Medium",
  "Inverse/parameter",
  r"Two trains, $180$ m and $220$ m long, run at constant speeds on parallel tracks. When they move in opposite directions they pass each other completely in $10$ seconds; when they move in the same direction the faster one passes the slower one completely in $40$ seconds. What is the speed of the faster train?",
  "MCQ",
  r"The total length is $400$ m. Opposite: $x + y = \frac{400}{10} = 40$ m/s. Same direction: $x - y = \frac{400}{40} = 10$ m/s. So $x = 25$ m/s $= 90$ km/h.",
  "Reporting the sum or difference of speeds, or the slower train's speed.",
  "C08B-sum-difference-speeds", "Two equations (sum and difference of speeds), then a conversion.",
  correct=r"$90$ km/h",
  distractors=[(r"$54$ km/h", "Reports the slower train's speed, $15$ m/s."),
               (r"$144$ km/h", "Reports the sum of the speeds, $40$ m/s."),
               (r"$36$ km/h", "Reports the difference of the speeds, $10$ m/s.")],
  check=_c016, values=[90, 54, 144, 36], exams=ALL6)


def _c017():
    # simulate: express engine at x=0, goods rear at 400, goods engine at 760; express rear at -240
    t = Fraction(0)
    ve, vg = ms(72), ms(36)
    dt = Fraction(1, 2)
    while True:
        express_rear = -240 + ve * t
        goods_front = 760 + vg * t
        if express_rear >= goods_front:
            return t
        t += dt
q("C08-B-017", "Trains", "Overtaking with an initial gap between the trains", "Medium",
  "Multi-step word problem",
  r"An express train $240$ m long runs at $72$ km/h behind a goods train $360$ m long running at $36$ km/h on a parallel track in the same direction. At a certain instant the express's engine is $400$ m behind the rear of the goods train. How many seconds after that instant will the rear of the express draw level with the engine of the goods train?",
  "TITA",
  r"The relative speed is $72 - 36 = 36$ km/h $= 10$ m/s. The express must gain the $400$ m gap, then the goods train's $360$ m, then its own $240$ m: $1000$ m in all. This takes $\frac{1000}{10} = 100$ seconds.",
  "Leaving out one of the three distances: the gap, the goods train's length or the express's own length.",
  "C08B-same-direction-overtake", "Three distance components to add before using relative speed.",
  tita_answer=100, check=_c017, values=[100],
  tita_traps=[(60, "Ignores the initial $400$ m gap."),
              (76, "Leaves out the express's own $240$ m: $\\frac{760}{10}$."),
              (40, "Stops when the express's engine reaches the goods train's rear.")],
  exams=ALL6)


def _c018():
    L = symbols('L', positive=True)
    v = (L + Rational(3, 5) * L) / 24
    return simplify((L + Rational(2, 5) * L) / v)
q("C08-B-018", "Trains", "Fractional-length platform, then a standing train of fractional length", "Medium",
  "Multi-step word problem",
  r"A train crosses a platform whose length is $\frac{3}{5}$ of the train's own length in $24$ seconds. Running at the same speed, how long will it take to pass completely a train standing on a parallel track whose length is $\frac{2}{5}$ of its own length?",
  "MCQ",
  r"Let the train's length be $L$. Crossing the platform it covers $\frac{8}{5}L$ in $24$ s, so it covers $L$ in $15$ s. Passing the standing train it covers $\frac{7}{5}L$, which takes $\frac{7}{5} \times 15 = 21$ seconds.",
  "Forgetting the train's own length in one of the two crossings.",
  "C08B-fractional-length", "Must express both distances as multiples of the unknown length.",
  correct=r"$21$ seconds",
  distractors=[(r"$15$ seconds", "Reports the time to cover the train's own length only."),
               (r"$16$ seconds", "Scales $24$ s by $\\frac{2/5}{3/5}$, comparing only the obstacles and forgetting the train's own length."),
               (r"$56$ seconds", "Treats $24$ s as the time for the platform alone: $24 \\times \\frac{7/5}{3/5} = 56$.")],
  check=_c018, values=[21, 15, 16, 56], exams=ALL6)


def _c019():
    k = symbols('k', positive=True)
    L1, L2 = 4 * k, 5 * k
    v1, v2 = L1 / 12, L2 / 20
    return simplify((L1 + L2) / (v1 - v2))
q("C08-B-019", "Trains", "Overtaking time from pole times and a length ratio", "Medium",
  "Multi-step word problem",
  r"The length of one train is $\frac{4}{5}$ of the length of another. The shorter train passes a pole in $12$ seconds and the longer one passes the same pole in $20$ seconds. If they run in the same direction on parallel tracks at these speeds, how many seconds does the faster train take to pass the slower one completely?",
  "TITA",
  r"Take the lengths as $4k$ and $5k$. The speeds are $\frac{4k}{12} = \frac{k}{3}$ and $\frac{5k}{20} = \frac{k}{4}$, so the shorter train is faster, by $\frac{k}{3} - \frac{k}{4} = \frac{k}{12}$ per second. It must gain $4k + 5k = 9k$, which takes $\frac{9k}{k/12} = 108$ seconds.",
  "Assuming equal lengths, or combining the pole times directly.",
  "C08B-pole-times-to-crossing", "Needs a common length unit and the relative speed; easy to lose the length ratio.",
  tita_answer=108, check=_c019, values=[108],
  tita_traps=[(60, "Assumes equal lengths: $\\frac{2L}{L/12 - L/20} = 60$."),
              (32, "Adds the two pole times.")],
  cognitive="Analysis", exams=ALL6)


def _c020():
    L = symbols('L', positive=True)
    Ls = solve(Eq((L + 300) / (ms(54) + ms(90)), 15), L)[0]
    return (2 * Ls) / (ms(72) - ms(54))
q("C08-B-020", "Trains", "Third train fixes the common length of two trains", "Medium",
  "Multi-step word problem",
  r"Two trains of equal length run in the same direction on parallel tracks, one at $54$ km/h and the other at $72$ km/h. A third train, $300$ m long, runs at $90$ km/h on a third parallel track in the opposite direction and passes the slower train completely in $15$ seconds. How many seconds does the faster of the first two trains take to pass the slower one completely?",
  "TITA",
  r"The third train and the slower train approach at $54 + 90 = 144$ km/h $= 40$ m/s, so $L + 300 = 40 \times 15 = 600$ and $L = 300$ m. The faster train gains on the slower at $72 - 54 = 18$ km/h $= 5$ m/s and must gain $2L = 600$ m, which takes $\frac{600}{5} = 120$ seconds.",
  "Ignoring the slower train's own motion when the third train passes it, or using one length instead of two.",
  "C08B-third-train", "Two stages: recover the length from one crossing, then use it in another.",
  tita_answer=120, check=_c020, values=[120],
  tita_traps=[(60, "Uses one length, $\\frac{300}{5}$, instead of the sum of both lengths."),
              (30, "Ignores the slower train's motion: $L + 300 = 25 \\times 15$ gives $L = 75$, then $\\frac{150}{5} = 30$.")],
  exams=HARD)


def _c021():
    # simulate with sample speeds: the answer must not depend on them
    out = set()
    for ve, vg in [(30, 20), (25, 15), (Fraction(70, 3), 9)]:
        r = Fraction(ve) - vg
        Le = 30 * r      # express passes Ravi (a point in the goods train) in 30 s
        Lg = 20 * r      # Meera (a point in the express) goes from the goods rear to its front in 20 s
        t = symbols('t', positive=True)
        # goods rear at 0 at t = 0; express engine at 0 at t = 0
        express_rear = ve * t - Le
        goods_engine = vg * t + Lg
        out.add(solve(Eq(express_rear, goods_engine), t)[0])
    assert len(out) == 1
    return out.pop()
q("C08-B-021", "Trains", "Overtaking time from the timings of a passenger in each train", "Medium",
  "Conceptual/application",
  r"An express overtakes a goods train running in the same direction on a parallel track; both run at constant speeds. Ravi, sitting in the goods train, finds that the express takes $30$ seconds to go past him completely. Meera, sitting in the express, takes $20$ seconds to go from the rear end of the goods train to its engine. How long does the whole overtaking take, from the moment the express's engine draws level with the rear of the goods train until the rear of the express draws level with the engine of the goods train?",
  "MCQ",
  r"Both passengers see the other train move past at the same relative speed $r$, so the express is $30r$ long and the goods train is $20r$ long. To overtake completely the express must gain both lengths, $50r$, at the relative speed $r$, which takes $30 + 20 = 50$ seconds.",
  "Taking one passenger's timing as the whole overtaking, or averaging the two timings.",
  "C08B-passenger-timings", "Needs the insight that each timing measures one train's length at the same relative speed.",
  correct=r"$50$ seconds",
  distractors=[(r"$30$ seconds", "Takes Ravi's timing as the whole overtaking, since he sees the whole express go by."),
               (r"$25$ seconds", "Averages the two timings."),
               (r"$10$ seconds", "Subtracts the two timings, $30 - 20$.")],
  check=_c021, values=[50, 30, 25, 10], cognitive="Understanding", exams=ALL6)


def _c022():
    # poles every 50 m; pole 1 at t = 0, pole 30 at t = 60 s
    poles = [50 * k for k in range(40)]
    speed = Fraction(poles[29] - poles[0], 60)
    L, B = 290, 435
    return (L + B) / speed
q("C08-B-022", "Trains", "Speed from counting telegraph poles, then a bridge crossing", "Medium",
  "Multi-step word problem",
  r"Telegraph poles stand beside a railway line at equal intervals of $50$ m. Farhan, sitting in a train, numbers the poles in order as he passes them. He starts a stopwatch as he passes pole $1$ and stops it exactly $1$ minute later as he passes pole $30$. Running at the same speed, the train, which is $290$ m long, then crosses a bridge $435$ m long. How many seconds does the train take to cross the bridge completely?",
  "TITA",
  r"From pole $1$ to pole $30$ there are $29$ gaps, so the train covers $29 \times 50 = 1450$ m in $60$ s, a speed of $\frac{145}{6}$ m/s. To cross the bridge completely it covers $290 + 435 = 725$ m, which takes $725 \times \frac{6}{145} = 30$ seconds.",
  "Counting $30$ gaps between pole $1$ and pole $30$, or leaving out the train's own length.",
  "C08B-pole-counting", "A fencepost count for the speed, then a bridge crossing with the train's length.",
  tita_answer=30, check=_c022, values=[30],
  tita_traps=[(29, "Counts $30$ gaps: speed $25$ m/s, and $\\frac{725}{25} = 29$."),
              (18, "Leaves out the train's length: $435 \\times \\frac{6}{145} = 18$.")],
  exams=ALL6)


def _c023():
    v2, L2 = symbols('v2 L2', positive=True)  # m/s, m
    s = solve([Eq(L2, (v2 + ms(60)) * 6), Eq(200 + L2, (v2 + ms(60)) * 10)], [v2, L2], dict=True)[0]
    return kmh(Rational(s[v2]))
q("C08-B-023", "Trains", "Passenger's timing plus full crossing time give the other train's speed", "Medium",
  "Multi-step word problem",
  r"Kabir sits in a train $200$ m long running at $60$ km/h. A train on a parallel track, running in the opposite direction, takes $6$ seconds to pass Kabir, and the two trains take $10$ seconds to pass each other completely. What is the speed of the second train?",
  "MCQ",
  r"With relative speed $r$ and second train length $L$: $L = 6r$ and $200 + L = 10r$. Subtracting, the extra $4$ seconds cover Kabir's train's $200$ m, so $r = 50$ m/s $= 180$ km/h. Since the trains move in opposite directions, the second train runs at $180 - 60 = 120$ km/h.",
  "Reporting the relative speed, or assuming the two trains are equally long.",
  "C08B-man-in-train", "Two crossing events must be combined; the passenger sees only the other train's length.",
  correct=r"$120$ km/h",
  distractors=[(r"$180$ km/h", "Reports the relative speed."),
               (r"$240$ km/h", "Adds Kabir's train's speed to the relative speed."),
               (r"$60$ km/h", "Assumes both trains are $200$ m long: $\\frac{200}{6}$ m/s $= 120$ km/h relative, minus $60$.")],
  check=_c023, values=[120, 180, 240, 60], exams=ALL6)


def _c024():
    v, L = symbols('v L', positive=True)
    s = solve([Eq(L + 320, 30 * v), Eq(L, 16 * (v - ms(9)))], [v, L], dict=True)[0]
    return kmh(Rational(s[v]))
q("C08-B-024", "Trains", "Speed from a bridge crossing and overtaking a walker", "Medium",
  "Inverse/parameter",
  r"A train crosses a bridge $320$ m long completely in $30$ seconds. Running at the same speed, it overtakes a man walking beside the track at $9$ km/h in the same direction and passes him completely in $16$ seconds. What is the speed of the train, in km/h?",
  "TITA",
  r"Let the speed be $v$ m/s and the length $L$ m. The man walks at $2.5$ m/s, so $L + 320 = 30v$ and $L = 16(v - 2.5) = 16v - 40$. Then $30v - 320 = 16v - 40$ gives $14v = 280$, so $v = 20$ m/s $= 72$ km/h.",
  "Forgetting the man's speed, or leaving the answer in m/s.",
  "C08B-two-crossing-times", "Two equations, one of which involves relative speed.",
  tita_answer=72, check=_c024, values=[72],
  tita_traps=[(20, "Leaves the speed in m/s."),
              (280, "Reports the train's length in metres.")],
  exams=ALL6)


def _c025():
    v, c = symbols('v c', positive=True)
    s = solve(Eq((v - c) * 20, (v + c) * 10), v)[0]
    return simplify(s / c)
q("C08-B-025", "Relative speed", "Ratio of train and car speeds from overtaking and passing times", "Medium",
  "Conceptual/application",
  r"A train overtakes a car moving in the same direction on a road parallel to the track and passes it completely in $20$ seconds. On another day the same train, at the same speed, passes the same car moving at the same speed in the opposite direction completely in $10$ seconds. Treating the car as a point, the ratio of the train's speed to the car's speed is",
  "MCQ",
  r"The train's length is the same both times, so $(v - c) \times 20 = (v + c) \times 10$. This gives $2v - 2c = v + c$, so $v = 3c$ and the ratio is $3 : 1$.",
  "Taking the ratio of the times as the ratio of the speeds.",
  "C08B-time-inverse-relative-speed", "One equation from equal lengths; the trap is reading the time ratio as the answer.",
  correct=r"$3 : 1$",
  distractors=[(r"$2 : 1$", "Takes the ratio of the two times as the speed ratio."),
               (r"$1 : 1$", "Ignores the car's motion when overtaking: $20v = 10(v + c)$ gives $v = c$."),
               (r"$1 : 3$", "Solves correctly but reports the car-to-train ratio.")],
  check=_c025, values=[3, 2, 1, Fraction(1, 3)], cognitive="Understanding", exams=ALL6)


def _c026():
    L = symbols('L', positive=True)
    v1, v2 = L / 10, L / 15
    return simplify(2 * L / (v1 + v2))
q("C08-B-026", "Trains", "Equal-length trains crossing each other from their pole times", "Medium",
  "Conceptual/application",
  r"Two trains of equal length take $10$ seconds and $15$ seconds respectively to pass a telegraph pole. If they run in opposite directions on parallel tracks at these speeds, how long will they take to pass each other completely?",
  "MCQ",
  r"Let each length be $L$. The speeds are $\frac{L}{10}$ and $\frac{L}{15}$, so the relative speed is $\frac{L}{6}$. They must clear $2L$, which takes $\frac{2L}{L/6} = 12$ seconds.",
  "Averaging the two pole times instead of combining the speeds.",
  "C08B-pole-times-to-crossing", "Combining speeds expressed through an unknown common length.",
  correct=r"$12$ seconds",
  distractors=[(r"$12.5$ seconds", "Takes the arithmetic mean of $10$ and $15$."),
               (r"$6$ seconds", "Uses only one length: $\\frac{L}{L/6} = 6$."),
               (r"$60$ seconds", "Subtracts the speeds as if they moved the same way: $\\frac{2L}{L/30} = 60$.")],
  check=_c026, values=[12, Rational(25, 2), 6, 60], cognitive="Understanding", exams=ALL6)


def _c027():
    ve, g, Le, Lg = symbols('ve g Le Lg', positive=True)   # m/s, m
    T = 60
    s = solve([Eq(ve * T, 1500),               # express covers 1.5 km during the overtaking
               Eq(Le, 12 * ve),                # express passes the post in 12 s
               Eq(Lg, 20 * g),                 # goods train passes the post in 20 s
               Eq(Le + Lg, (ve - g) * T)],     # gain of both lengths in 60 s
              [ve, g, Le, Lg], dict=True)[0]
    return kmh(Rational(s[g]))
q("C08-B-027", "Trains", "Goods train's speed from post times, overtaking time and the ground distance covered", "Difficult",
  "Inverse/parameter",
  r"An express passes a signal post in $12$ seconds, and a goods train passes the same post in $20$ seconds. Later, running at these same constant speeds in the same direction on parallel tracks, the express overtakes the goods train. From the moment the express's engine draws level with the rear of the goods train until the rear of the express draws level with the goods train's engine takes $60$ seconds, and during this time the express travels $1.5$ km along the track. What is the speed of the goods train?",
  "MCQ",
  r"The express runs at $\frac{1500}{60} = 25$ m/s, so its length is $25 \times 12 = 300$ m. If the goods train runs at $g$ m/s, its length is $20g$. In $60$ s the express gains both lengths: $300 + 20g = 60(25 - g)$, so $80g = 1200$ and $g = 15$ m/s $= 54$ km/h. (Check: the goods train is $300$ m long and $\frac{600}{10} = 60$ s.)",
  "Reading the $1.5$ km as the distance gained on the goods train, or leaving out the goods train's length because it is not given.",
  "C08B-overtake-ground-distance", "Four unknowns linked by three crossings; the goods train's length depends on its unknown speed, and the ground distance must be separated from the relative distance.",
  correct=r"$54$ km/h",
  distractors=[(r"$36$ km/h", "Reports the relative speed, $10$ m/s."),
               (r"$90$ km/h", "Reports the express's speed, $25$ m/s."),
               (r"$72$ km/h", "Leaves out the goods train's length: $300 = 60(25 - g)$ gives $g = 20$ m/s.")],
  check=_c027, values=[54, 36, 90, 72], cognitive="Analysis", exams=HARD)


def _c028():
    L = symbols('L', positive=True)
    v = (L + Rational(2, 3) * L) / 20
    return simplify(L / (v - v / 4))
q("C08-B-028", "Trains", "Fractional-length platform, then a runner at a fraction of the train's speed", "Medium",
  "Multi-step word problem",
  r"A train crosses a platform whose length is $\frac{2}{3}$ of the train's length in $20$ seconds. How long will the same train, at the same speed, take to pass completely a man running beside the track in the same direction at $\frac{1}{4}$ of the train's speed?",
  "MCQ",
  r"The train covers $\frac{5}{3}L$ in $20$ s, so it covers its own length $L$ in $12$ s. Relative to the runner its speed is $\frac{3}{4}$ of its own, so passing him takes $12 \div \frac{3}{4} = 16$ seconds.",
  "Ignoring the runner's motion, or adjusting the time additively instead of through the relative speed.",
  "C08B-fractional-length", "Fraction of length and fraction of speed combined in two steps.",
  correct=r"$16$ seconds",
  distractors=[(r"$12$ seconds", "Ignores the runner and uses the train's full speed."),
               (r"$9.6$ seconds", "Adds the runner's speed, as if he were running towards the train: $12 \\div \\frac{5}{4}$."),
               (r"$15$ seconds", "Increases $12$ s by a quarter, $12 \\times \\frac{5}{4}$, instead of dividing by $\\frac{3}{4}$.")],
  check=_c028, values=[16, 12, Rational(48, 5), 15], exams=ALL6)


def _c029():
    v1 = Fraction(160, 8)
    v2, L2 = symbols('v2 L2', positive=True)
    s = solve([Eq(L2, 6 * v2), Eq(L2 + 150, 11 * v2)], [v2, L2], dict=True)[0]
    return (160 + s[L2]) / (s[v2] - v1)
q("C08-B-029", "Trains", "Overtaking time after recovering both trains' data from crossings", "Medium",
  "Multi-step word problem",
  r"A train $160$ m long passes a pole in $8$ seconds. A second train passes the same pole in $6$ seconds and crosses a bridge $150$ m long completely in $11$ seconds. If the two trains run in the same direction on parallel tracks at these speeds, how long does the faster train take to pass the slower one completely?",
  "MCQ",
  r"The first train runs at $\frac{160}{8} = 20$ m/s. For the second, the extra $5$ seconds cover the bridge, so its speed is $\frac{150}{5} = 30$ m/s and its length is $30 \times 6 = 180$ m. The faster train gains $10$ m/s and must gain $160 + 180 = 340$ m, which takes $34$ seconds.",
  "Adding the speeds, or using only one train's length.",
  "C08B-combine-crossing-data", "Three short computations before the relative-speed step.",
  correct=r"$34$ seconds",
  distractors=[(r"$6.8$ seconds", "Adds the speeds: $\\frac{340}{50}$."),
               (r"$18$ seconds", "Uses only the second train's length: $\\frac{180}{10}$."),
               (r"$16$ seconds", "Uses only the first train's length: $\\frac{160}{10}$.")],
  check=_c029, values=[34, Rational(34, 5), 18, 16], exams=ALL6)


def _c030():
    rel = Fraction(200) / Fraction(48, 5)       # m/s
    w = kmh(rel) - 72                           # km/h, positive means towards the train
    return w
q("C08-B-030", "Trains", "Deciding a walker's direction and speed from a passing time", "Medium",
  "Casework/optimisation",
  r"A train $200$ m long running at $72$ km/h passes Joseph, who is walking beside the track, completely in $9.6$ seconds. Which of the following correctly describes Joseph's walking?",
  "MCQ",
  r"At $72$ km/h $= 20$ m/s the train would pass a standing man in $10$ s, so it passed Joseph faster and he must be walking against the train's motion. The relative speed is $\frac{200}{9.6} = \frac{125}{6}$ m/s $= 75$ km/h, so Joseph walks at $75 - 72 = 3$ km/h opposite to the train.",
  "Assuming any passing train is overtaking, or not converting the speed difference to km/h.",
  "C08B-train-passes-walker", "Two cases for the direction must be compared against the standing-man time.",
  correct=r"Opposite to the train, at $3$ km/h",
  distractors=[(r"Same direction as the train, at $3$ km/h", "Finds the $3$ km/h gap but assumes the train is overtaking him."),
               (r"Opposite to the train, at $\frac{5}{6}$ km/h", "Takes $\\frac{125}{6} - 20 = \\frac{5}{6}$ m/s and writes it as km/h."),
               (r"Same direction as the train, at $\frac{5}{6}$ km/h", "Makes both slips: the m/s value written as km/h and the overtaking assumption.")],
  check=_c030, values=[3, -3, Fraction(5, 6), Fraction(-5, 6)], cognitive="Analysis", exams=ALL6)


# ---------------------------------------------------------------- DIFFICULT

def _c031():
    v, L = symbols('v L', positive=True)
    s = solve([Eq(L, (v - 1) * 10), Eq(L, (v + 1) * 9)], [v, L], dict=True)[0]
    V = s[v]
    # positions in metres, t in seconds after 9:00; Arjun at 0 at t=0, moves +1
    T = 600
    fatima_at_T = V * T
    t = symbols('t', positive=True)
    meet = solve(Eq(1 * t, fatima_at_T - 1 * (t - T)), t)[0]
    return (meet - T) / 60
q("C08-B-031", "Relative speed", "Train speed from two passing times, then when the two walkers meet", "Difficult",
  "Multi-step word problem",
  r"Arjun and Fatima each walk at $3.6$ km/h beside a straight track; Arjun walks in the direction of the trains and Fatima walks the opposite way, towards Arjun. A train running at a constant speed passes Arjun completely in $10$ seconds and passes Fatima completely in $9$ seconds. Its engine draws level with Arjun at $9{:}00$ am and with Fatima at $9{:}10$ am. How many minutes after $9{:}10$ am do Arjun and Fatima meet?",
  "TITA",
  r"Each walks at $1$ m/s. With train speed $v$ m/s, the length gives $10(v - 1) = 9(v + 1)$, so $v = 19$ m/s. At $9{:}10$ am Fatima is level with the engine, $19 \times 600 = 11400$ m beyond Arjun's $9{:}00$ am spot, while Arjun has walked $600$ m. The gap is $10800$ m and they close at $2$ m/s, so they meet after $5400$ s $= 90$ minutes.",
  "Ignoring Arjun's walk during the ten minutes, or measuring from $9{:}00$ am.",
  "C08B-two-persons-passed-meet", "Train speed from two relative speeds, then positions at the second event, then a closing time.",
  tita_answer=90, check=_c031, values=[90],
  tita_traps=[(95, "Ignores Arjun's $600$ m: $\\frac{11400}{2}$ s $= 95$ min."),
              (100, "Counts from $9{:}00$ am instead of $9{:}10$ am.")],
  cognitive="Analysis", exams=HARD)


def _c032():
    d, r = symbols('d r', positive=True)  # d = train's distance behind entrance (tunnel lengths), r = speed ratio
    f = Rational(2, 5)
    s = solve([Eq(d, r * f), Eq(d + 1, r * (1 - f))], [d, r], dict=True)[0]
    return s[r]
q("C08-B-032", "Relative speed", "Person in a tunnel escaping an approaching train either way", "Difficult",
  "Conceptual/application",
  r"Priya is walking through a straight railway tunnel. When she has covered $\frac{2}{5}$ of its length, she hears a train approaching the entrance she came in through. If she immediately runs back towards that entrance, she reaches it at exactly the moment the train does. If instead she immediately runs forward towards the exit at the same speed, the train catches up with her exactly at the exit. The train's speed is constant. The ratio of the train's speed to Priya's running speed is",
  "MCQ",
  r"Take the tunnel length as $1$ and let the train be $d$ behind the entrance, with speed ratio $r$. Running back, she covers $\frac{2}{5}$ while the train covers $d$, so $d = \frac{2}{5}r$. Running forward, she covers $\frac{3}{5}$ while the train covers $d + 1$, so $d + 1 = \frac{3}{5}r$. Subtracting, $1 = \frac{1}{5}r$, so $r = 5$, that is $5 : 1$.",
  "Assuming the train is already at the entrance, or comparing only her two distances.",
  "C08B-tunnel-escape", "A two-scenario model with an unknown starting gap; the subtraction trick is not obvious.",
  correct=r"$5 : 1$",
  distractors=[(r"$3 : 2$", "Compares only her two running distances, $\\frac{3}{5} : \\frac{2}{5}$."),
               (r"$5 : 2$", "Assumes the train covers the full tunnel while she covers $\\frac{2}{5}$ of it."),
               (r"$5 : 3$", "Assumes the train is at the entrance: it covers $1$ while she covers $\\frac{3}{5}$.")],
  check=_c032, values=[5, Fraction(3, 2), Fraction(5, 2), Fraction(5, 3)], cognitive="Analysis", exams=HARD)


def _c033():
    Le, Lg, t = symbols('Le Lg t', positive=True)
    ve, vg = ms(72), ms(54)
    # t = 0: express engine level with goods rear (goods rear at 0)
    e_engine = ve * t
    e_rear = ve * t - Le
    g_rear = vg * t
    g_engine = vg * t + Lg
    t_end = solve(Eq(e_rear, g_engine), t)[0]           # overtaking complete
    t_in = solve(Eq(e_rear, g_rear), t)[0]              # express rear passes goods rear
    t_out = solve(Eq(e_engine, g_engine), t)[0]         # express engine reaches goods engine
    s = solve([Eq(t_end, 75), Eq(t_out - t_in, 15)], [Le, Lg], dict=True)[0]
    assert s[Lg] > s[Le]
    return (s[Lg] + 315) / vg
q("C08-B-033", "Trains", "Train lengths from the total overtaking time and the time one train is fully alongside", "Difficult",
  "Conceptual/application",
  r"An express running at $72$ km/h overtakes a goods train running at $54$ km/h on a parallel track in the same direction; the goods train is the longer of the two. From the moment the express's engine draws level with the rear of the goods train until the rear of the express draws level with the goods train's engine takes $75$ seconds. For exactly $15$ seconds of this time the express is entirely alongside the goods train, with both of its ends between the two ends of the goods train. Running at its own speed, how many seconds does the goods train take to cross a platform $315$ m long completely?",
  "TITA",
  r"The relative speed is $72 - 54 = 18$ km/h $= 5$ m/s, so the two lengths add up to $5 \times 75 = 375$ m. The express is fully alongside from when its rear passes the goods train's rear (a relative gain of the express's length) until its engine reaches the goods train's engine (a relative gain of the goods train's length), so the difference of the lengths is $5 \times 15 = 75$ m. Hence the goods train is $225$ m and the express $150$ m long. At $15$ m/s the goods train crosses the platform in $\frac{225 + 315}{15} = 36$ seconds.",
  "Taking the fully-alongside time as the express's length divided by the relative speed, or swapping the two lengths.",
  "C08B-fully-inside-tunnel", "Requires modelling the fully-alongside window as the difference of lengths, then sum and difference, then a platform crossing.",
  tita_answer=36, check=_c033, values=[36],
  tita_traps=[(31, "Swaps the lengths, taking the goods train as $150$ m: $\\frac{465}{15} = 31$."),
              (41, "Takes the $15$ s as the express's length over the relative speed: express $75$ m, goods $300$ m, $\\frac{615}{15} = 41$."),
              (27, "Uses the express's speed for the platform crossing: $\\frac{540}{20} = 27$.")],
  cognitive="Analysis", exams=HARD)


def _c034():
    v1, v2, D = symbols('v1 v2 D', positive=True)
    s = solve([Eq(3 * v1 + 2 * v2, D), Eq(6 * v1, D)], [v2, D], dict=True)[0]
    hours_total = simplify(s[D] / s[v2])
    return 9 * 60 + hours_total * 60
q("C08-B-034", "Relative speed", "Staggered starts, meeting time and one arrival give the other arrival", "Medium",
  "Multi-step word problem",
  r"A train leaves station P for station Q at $8{:}00$ am, and another train leaves Q for P at $9{:}00$ am, on parallel tracks. Both run at constant speeds. They meet at $11{:}00$ am, and the first train reaches Q at $2{:}00$ pm. At what time does the second train reach P?",
  "MCQ",
  r"The first train takes $6$ hours for the whole distance $D$, so its speed is $\frac{D}{6}$. By $11{:}00$ am it has run $3$ hours, that is $\frac{D}{2}$, so the second train covered the other $\frac{D}{2}$ in $2$ hours. The second train therefore needs $4$ hours for the whole journey and reaches P at $1{:}00$ pm.",
  "Applying the square-root rule for simultaneous starts to trains that started an hour apart.",
  "C08B-meet-later-start-full-journey", "Three short linked steps (speed as a fraction of the distance, half the distance by the meeting, double the time); the trap is the square-root shortcut, which fails for staggered starts.",
  correct=r"$1{:}00$ pm",
  distractors=[(r"$2{:}00$ pm", "Applies $t^2 = t_1 t_2$ with $t = 3$ h and $t_1 = 3$ h, as if both started at $8{:}00$ am."),
               (r"$12{:}20$ pm", "Applies $t^2 = t_1 t_2$ with $t = 2$ h and $t_1 = 3$ h, giving $\\frac{4}{3}$ h after meeting."),
               (r"$3{:}00$ pm", "Adds the second train's full $4$ hour journey to the meeting time.")],
  check=_c034, values=[780, 840, 740, 900], cognitive="Analysis", exams=HARD)


def _c035():
    # simulate in minutes from 5:00 am; locals depart every 10 min from 5:00; express departs 6:05
    vl, ve = Fraction(45, 60), Fraction(75, 60)   # km per minute
    LINE = 120
    t_exp = 65
    count = 0
    for dep in range(0, 24 * 60, 10):
        if dep >= t_exp:
            continue
        # catch time: ve*(t - t_exp) = vl*(t - dep)
        t = (ve * t_exp - vl * dep) / (ve - vl)
        pos = ve * (t - t_exp)
        if pos <= LINE:
            count += 1
    return count
q("C08-B-035", "Relative speed", "Counting the slower trains an express overtakes on a finite line", "Difficult",
  "Casework/optimisation",
  r"Local trains leave station S every $10$ minutes, the first at $5{:}00$ am, and run non-stop at $45$ km/h to the end of a $120$ km line. An express leaves S at $6{:}05$ am on a parallel track and runs non-stop at $75$ km/h to the end of the same line. Treating all trains as points, how many local trains does the express overtake before it reaches the end of the line?",
  "TITA",
  r"A local that left $k$ minutes before the express is $\frac{45k}{60}$ km ahead when the express starts; the express gains $30$ km/h, so it draws level after $\frac{k}{40}$ h, at $75 \times \frac{k}{40} = 1.875k$ km from S. This must be at most $120$ km, so $k \le 64$. The locals that left $5, 15, 25, 35, 45, 55$ minutes earlier qualify; the $5{:}00$ am local ($k = 65$) would be caught at $121.875$ km, beyond the end. The answer is $6$.",
  "Assuming every local that left before the express is overtaken.",
  "C08B-overtaking-count", "Requires a general catch-up formula and a boundary case at the end of the line.",
  tita_answer=6, check=_c035, values=[6],
  tita_traps=[(7, "Counts every local that left before $6{:}05$ am, including the $5{:}00$ am train caught only beyond the line's end.")],
  cognitive="Analysis", exams=HARD)


def _c036():
    L = symbols('L', positive=True)
    q_ = symbols('q', positive=True)
    s = solve([Eq(2 * L, (ms(72) - ms(36)) * 40), Eq(2 * L, (ms(72) + q_) * 8)], [L, q_], dict=True)[0]
    return 2 * s[L] / (s[q_] + ms(36))
q("C08-B-036", "Trains", "Three equal-length trains: the third crossing from the other two", "Difficult",
  "Multi-step word problem",
  r"Three trains of the same length run at constant speeds on three parallel tracks. The first runs at $72$ km/h and the second at $36$ km/h, both in the same direction; the third runs in the opposite direction. The first train passes the second completely in $40$ seconds, and the first and third trains pass each other completely in $8$ seconds. How many seconds do the second and third trains take to pass each other completely?",
  "TITA",
  r"The first gains $10$ m/s on the second, so $2L = 10 \times 40 = 400$ m. With the first, the third closes at $\frac{400}{8} = 50$ m/s, so the third runs at $50 - 20 = 30$ m/s. The second and third close at $10 + 30 = 40$ m/s and take $\frac{400}{40} = 10$ seconds.",
  "Treating the second and third trains as moving in the same direction, or using a single length.",
  "C08B-third-train", "Three linked relative-speed equations across three trains.",
  tita_answer=10, check=_c036, values=[10],
  tita_traps=[(20, "Subtracts the speeds of the second and third trains: $\\frac{400}{30 - 10}$."),
              (5, "Uses one length, $\\frac{200}{40}$.")],
  cognitive="Analysis", exams=HARD)


def _c037():
    # minutes from 9:00, km
    c, v, D = 12, 60, 60
    t_dep = 30
    t_arr = t_dep + Fraction(D, v) * 60
    t_back = t_arr + 30
    # second passing: train returning position D - v*(t - t_back)/60, cyclist c*t/60
    t = symbols('t', positive=True)
    s = solve(Eq(c * t / 60, D - v * (t - t_back) / 60), t)[0]
    assert s > t_back and c * s / 60 < D
    return c * s / 60
q("C08-B-037", "Relative speed", "Train overtakes a cyclist, turns back after a halt and meets her again", "Difficult",
  "Multi-step word problem",
  r"Ananya leaves town P at $9{:}00$ am and cycles at a constant $12$ km/h along a road beside the railway towards town Q, $60$ km away. A train leaves P at $9{:}30$ am, runs to Q at a constant $60$ km/h, halts there for $30$ minutes and returns to P at the same speed. Treating the train as a point, at what distance from P does the train pass Ananya for the second time?",
  "MCQ",
  r"The train reaches Q at $10{:}30$ am and starts back at $11{:}00$ am, when Ananya has cycled $2$ hours, that is $24$ km. The gap of $36$ km closes at $60 + 12 = 72$ km/h, taking half an hour, in which Ananya rides $6$ km more. They pass at $30$ km from P.",
  "Ignoring the halt, or using the difference of speeds on the return leg.",
  "C08B-train-cyclist-return", "Several stages: first passing, arrival, halt, then an opposite-direction meeting.",
  correct=r"$30$ km",
  distractors=[(r"$7.5$ km", "Gives the first passing: a $6$ km head start closed at $48$ km/h, after $\\frac{1}{8}$ h."),
               (r"$25$ km", "Ignores the $30$ minute halt: from $10{:}30$ am the gap is $42$ km, closed in $\\frac{7}{12}$ h."),
               (r"$33$ km", "Uses $60 - 12 = 48$ km/h on the return leg: $24 + 12 \\times \\frac{36}{48}$.")],
  check=_c037, values=[30, Rational(15, 2), 25, 33], exams=HARD)


def _c038():
    L, v2 = symbols('L v2', positive=True)
    v1 = 2 * L / 30
    s = solve(Eq(Rational(5, 2) * L, (v1 + v2) * 15), v2)[0]
    return simplify((Rational(3, 2) * L + L) / s)
q("C08-B-038", "Trains", "Fractional lengths: second train's bridge time from a crossing", "Difficult",
  "Multi-step word problem",
  r"A train crosses a bridge, whose length equals the train's own length, in $30$ seconds. A second train, $1.5$ times as long as the first, runs on a parallel track in the opposite direction, and the two trains pass each other completely in $15$ seconds. How long will the second train take to cross the same bridge completely?",
  "MCQ",
  r"Let the first train's length be $L$. Its speed is $\frac{2L}{30} = \frac{L}{15}$. The trains clear $L + 1.5L = 2.5L$ in $15$ s, so their combined speed is $\frac{L}{6}$ and the second runs at $\frac{L}{6} - \frac{L}{15} = \frac{L}{10}$. Crossing the bridge it covers $1.5L + L = 2.5L$, which takes $25$ seconds.",
  "Assuming the second train has the same speed as the first, or omitting one length.",
  "C08B-fractional-length", "Everything is in terms of an unknown length; three linked steps with fractions.",
  correct=r"$25$ seconds",
  distractors=[(r"$37.5$ seconds", "Assumes the second train runs at the first train's speed: $\\frac{2.5L}{L/15}$."),
               (r"$15$ seconds", "Omits the bridge: $\\frac{1.5L}{L/10}$."),
               (r"$10$ seconds", "Uses only the bridge length: $\\frac{L}{L/10}$.")],
  check=_c038, values=[25, Rational(75, 2), 15, 10], cognitive="Analysis", exams=HARD)


def _c039():
    x, y = symbols('x y', positive=True)
    s = solve(Eq(21 * x + 13 * y, 18 * (x + y)), x)[0]   # x in terms of y
    return simplify((21 * s) / (13 * y))
q("C08-B-039", "Trains", "Ratio of lengths from standing-man times and a mutual crossing time", "Difficult",
  "Inverse/parameter",
  r"Two trains running in opposite directions on parallel tracks pass a man standing on a platform in $21$ seconds and $13$ seconds respectively, and pass each other completely in $18$ seconds. The ratio of the length of the first train to that of the second is",
  "MCQ",
  r"Let the speeds be $x$ and $y$. The lengths are $21x$ and $13y$, and $21x + 13y = 18(x + y)$, so $3x = 5y$ and $x : y = 5 : 3$. The lengths are in the ratio $21 \times 5 : 13 \times 3 = 105 : 39 = 35 : 13$.",
  "Stopping at the speed ratio, or using the time ratio as the length ratio.",
  "C08B-crossing-time-ratio", "A weighted-average set-up for the speeds followed by a second ratio step.",
  correct=r"$35 : 13$",
  distractors=[(r"$5 : 3$", "Stops at the ratio of the speeds."),
               (r"$21 : 13$", "Takes the ratio of the times as the ratio of the lengths."),
               (r"$63 : 65$", "Uses the inverted speed ratio $3 : 5$: $21 \\times 3 : 13 \\times 5$.")],
  check=_c039, values=[Fraction(35, 13), Fraction(5, 3), Fraction(21, 13), Fraction(63, 65)], cognitive="Analysis", exams=HARD)


def _c040():
    v, g, S = symbols('v g S', positive=True)   # S = sum of lengths
    s = solve([Eq(S, 30 * v), Eq(S, 20 * (v + g))], [S, g], dict=True)[0]
    return simplify(s[S] / (v - s[g]))
q("C08-B-040", "Trains", "Overtaking time from stationary and oncoming passing times alone", "Difficult",
  "Conceptual/application",
  r"An express passes a goods train standing on a parallel track completely in $30$ seconds. On another day it passes the same goods train, which is now moving in the opposite direction, completely in $20$ seconds. The express runs at the same speed both days and is faster than the goods train. How long would the express take to pass the goods train completely if the goods train were moving at that same speed in the same direction as the express?",
  "MCQ",
  r"The distance to clear is the same each time, so the time is inversely proportional to the relative speed. Relative speeds are $v$ and $v + g$ with times $30$ and $20$, so $v + g = \frac{3}{2}v$ and $g = \frac{1}{2}v$. In the same direction the relative speed is $v - g = \frac{1}{2}v$, so the time is $30 \times 2 = 60$ seconds.",
  "Assuming the passing time changes by equal steps, or averaging the given times.",
  "C08B-time-inverse-relative-speed", "No speeds or lengths are given; the solver must work purely with inverse proportion.",
  correct=r"$60$ seconds",
  distractors=[(r"$40$ seconds", "Assumes the time rises by the same $10$ s it fell: $30 + 10$."),
               (r"$45$ seconds", "Scales $30$ s by $\\frac{30}{20}$ again."),
               (r"$24$ seconds", "Takes the harmonic mean of $30$ and $20$.")],
  check=_c040, values=[60, 40, 45, 24], cognitive="Analysis", exams=HARD)
