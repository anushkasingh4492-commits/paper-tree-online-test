import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TB = "Percentage basics and conversions"
TS = "Successive percentage change"
CX = ("CAT", "XAT")


def pct(x):
    """x% as an exact Fraction multiplier part."""
    return F(x) / 100


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ================================================================ EASY (14)

def _c1():
    C = symbols('C', positive=True)
    return solve(Eq(Rational(3, 5) * C - 40, Rational(35, 100) * C), C)[0]
q("C01-A-001", TB, "Capacity from a fraction full and a percentage full after a known withdrawal", "Easy",
  "Multi-step word problem",
  r"A water tank is $\frac{3}{5}$ full. After $40$ litres of water are drawn from it, the tank is $35\%$ full. What is the capacity of the tank, in litres?",
  "TITA",
  r"$\frac{3}{5} = 60\%$, so the $40$ litres drawn are $60\% - 35\% = 25\%$ of the capacity. Capacity $= 40 \times 4 = 160$ litres.",
  "Answering with the volume of water present instead of the capacity.",
  "C01A-fraction-percent-difference", "One conversion of a fraction to a percent and one division; the trap is reporting a volume instead of the capacity.",
  tita_answer=160, check=_c1,
  tita_traps=[(56, r"Reports the water left, $35\%$ of $160$."),
              (96, r"Reports the water at the start, $\frac{3}{5}$ of $160$.")],
  cognitive="Application")


def _c2():
    K = symbols('K', positive=True)
    M = K * Rational(160, 100)
    return simplify((M - K) / M * 100)
q("C01-A-002", TB, "If one quantity is x% more than another, the other is how much less", "Easy",
  "Conceptual/application",
  r"Meera's monthly mobile data usage is $60\%$ more than Kabir's. By what percent is Kabir's usage less than Meera's?",
  "MCQ",
  r"Take Kabir's usage as $100$; then Meera's is $160$. Kabir's usage is $60$ less than Meera's, which is $\frac{60}{160} \times 100 = 37.5\%$ of Meera's usage.",
  "Assuming 'x% more' and 'x% less' are symmetric, so that the base does not change.",
  "C01A-more-than-less-than", "One idea: the base changes when the comparison is reversed.",
  correct=r"$37.5\%$",
  distractors=[(r"$60\%$", r"Assumes the same percentage applies in both directions."),
               (r"$40\%$", r"Subtracts $60$ from $100$."),
               (r"$62.5\%$", r"Computes Kabir's usage as a percentage of Meera's, $\frac{100}{160}$, and reports it.")],
  check=_c2, values=[F(75, 2), 60, 40, F(125, 2)], cognitive="Understanding")


def _c3():
    N = symbols('N', positive=True)
    n = solve(Eq(Rational(40, 100) * N - Rational(25, 100) * N, 18), N)[0]
    return n - Rational(40, 100) * n
q("C01-A-003", TB, "Total from the difference of two percentages of it, then the complementary share", "Easy",
  "Multi-step word problem",
  r"On a Saturday at a book fair, $40\%$ of the visitors bought at least one book and $25\%$ of the visitors bought at least two books. The number of visitors who bought at least one book exceeded the number who bought at least two books by $18$. How many visitors bought no book at all?",
  "TITA",
  r"The difference $40\% - 25\% = 15\%$ of the visitors equals $18$, so there were $\frac{18}{0.15} = 120$ visitors. Those who bought no book are $100\% - 40\% = 60\%$ of them: $0.6 \times 120 = 72$.",
  "Stopping at the total number of visitors, or reporting the number who bought at least one book.",
  "C01A-percent-difference-find-whole", "A difference of two percentages gives the whole in one step; the trap is answering the wrong group.",
  tita_answer=72, check=_c3,
  tita_traps=[(120, r"Reports the total number of visitors."),
              (48, r"Reports the visitors who bought at least one book, $40\%$ of $120$.")],
  cognitive="Application")


def _c4():
    return (F(130, 100) * F(80, 100) - 1) * 100
q("C01-A-004", TS, "Net effect of a rise followed by a smaller fall", "Easy",
  "Single-step computation",
  r"The number of followers of a cooking channel increased by $30\%$ in January and then decreased by $20\%$ in February, the February change being measured on the number at the end of January. Over the two months, the number of followers",
  "MCQ",
  r"The net multiplier is $1.3 \times 0.8 = 1.04$, so the number of followers increased by $4\%$. Equivalently, $30 - 20 + \frac{30 \times (-20)}{100} = 4$.",
  "Adding the two percentage changes as if they were on the same base.",
  "C01A-net-two-step", "Single successive-change computation; the trap is simple addition of rates.",
  correct=r"increased by $4\%$",
  distractors=[(r"increased by $10\%$", r"Adds the changes: $30 - 20 = 10$."),
               (r"increased by $16\%$", r"Uses the formula with the sign of the product term reversed: $30 - 20 + 6 = 16$."),
               (r"increased by $6\%$", r"Reports only the size of the product term, $\frac{30 \times 20}{100} = 6$, as the net change.")],
  check=_c4, values=[4, 10, 16, 6], cognitive="Application")


def _c5():
    return F(130, 100) * F(70, 100) * 100
q("C01-A-005", TS, "Equal percentage rise and fall: final as a percentage of the start", "Easy",
  "Conceptual/application",
  r"The water level in a reservoir rose by $30\%$ in one week and then fell by $30\%$ in the next week, the fall being measured on the level at the end of the first week. The level at the end of the second week, as a percentage of the level at the start, is",
  "MCQ",
  r"The level is multiplied by $1.3$ and then by $0.7$: $1.3 \times 0.7 = 0.91$. So the final level is $91\%$ of the starting level. An equal rise and fall always leave a net loss of $\frac{30^2}{100}\% = 9\%$.",
  "Believing that an equal percentage rise and fall cancel each other.",
  "C01A-equal-rise-fall", "Single multiplication; the trap is assuming the changes cancel.",
  correct=r"$91\%$",
  distractors=[(r"$100\%$", r"Assumes a $30\%$ rise and a $30\%$ fall cancel."),
               (r"$109\%$", r"Gets the size of the net change, $9\%$, but treats it as a gain."),
               (r"$99.1\%$", r"Computes $0.3^2 = 0.09$ and takes it as $0.9\%$ rather than $9\%$.")],
  check=_c5, values=[91, 100, 109, F(991, 10)], cognitive="Understanding")


def _c6():
    x = symbols('x', positive=True)
    return solve(Eq(x * Rational(135, 100), 5400), x)[0]
q("C01-A-006", TB, "Original value from the value after a percentage increase", "Easy",
  "Inverse/parameter",
  r"After a $35\%$ increase, the number of registered users of a fitness app is $5{,}400$. How many users were registered before the increase?",
  "TITA",
  r"The new number is $135\%$ of the old one, so the old number is $\frac{5400}{1.35} = 4000$.",
  r"Subtracting $35\%$ of the new value instead of dividing by $1.35$.",
  "C01A-reverse-percent-original", "One division; the trap is taking the percentage of the wrong base.",
  tita_answer=4000, check=_c6,
  tita_traps=[(3510, r"Subtracts $35\%$ of $5400$: $5400 \times 0.65 = 3510$."),
              (1400, r"Reports the increase, $35\%$ of $4000$, instead of the original number.")],
  cognitive="Application")


def _c7():
    old, new = F(8), F(10)
    return (new - old) / old * 100
q("C01-A-007", TB, "Percent change of a share versus its change in percentage points", "Easy",
  "Conceptual/application",
  r"The share of electric scooters in the two-wheeler sales of a city rose from $8\%$ of sales to $10\%$ of sales. By what percent did this share increase?",
  "MCQ",
  r"The share rose by $10 - 8 = 2$ percentage points. As a percentage of the original share this is $\frac{2}{8} \times 100 = 25\%$.",
  "Reporting the change in percentage points as the percentage change.",
  "C01A-points-vs-percent", "One subtraction and one division; the trap is percentage points versus percent.",
  correct=r"$25\%$",
  distractors=[(r"$2\%$", r"Reports the rise of $2$ percentage points as a $2\%$ increase."),
               (r"$20\%$", r"Divides the rise by the new share: $\frac{2}{10}$."),
               (r"$125\%$", r"Reports the new share as a percentage of the old share, $\frac{10}{8}$.")],
  check=_c7, values=[25, 2, 20, 125], cognitive="Understanding")


def _c8():
    T = F(1)
    maths = F(3, 8) * T
    eng = F(40, 100) * (T - maths)
    return (T - maths - eng) * 100
q("C01-A-008", TB, "Percentage left after a fraction and then a percentage of the remainder", "Easy",
  "Multi-step word problem",
  r"Rohan spends $\frac{3}{8}$ of his weekly study time on Mathematics and $40\%$ of the remaining study time on English. What percentage of his weekly study time is left for other subjects?",
  "MCQ",
  r"After Mathematics, $\frac{5}{8} = 62.5\%$ of the time remains. English takes $40\%$ of this, so $60\%$ of it is left: $0.6 \times 62.5\% = 37.5\%$.",
  r"Taking $40\%$ of the whole time instead of $40\%$ of the remaining time.",
  "C01A-fraction-of-remainder", "Two steps with a change of base; the trap is the base of the second percentage.",
  correct=r"$37.5\%$",
  distractors=[(r"$22.5\%$", r"Takes $40\%$ of the whole time: $100 - 37.5 - 40 = 22.5$."),
               (r"$62.5\%$", r"Stops after Mathematics and reports the remaining $\frac{5}{8}$."),
               (r"$25\%$", r"Reports the English share, $40\%$ of $62.5\%$, instead of the share left.")],
  check=_c8, values=[F(75, 2), F(45, 2), F(125, 2), 25], cognitive="Application")


def _c9():
    Q = F(100)
    P = Q * F(160, 100)
    R = Q * F(80, 100)
    return (P - R) / R * 100
q("C01-A-009", TB, "Comparing two quantities each given as a percentage of a third", "Easy",
  "Multi-step word problem",
  r"Tank P holds $60\%$ more water than tank Q, and tank R holds $20\%$ less water than tank Q. By what percent is the amount of water in P more than the amount in R?",
  "MCQ",
  r"Take Q as $100$ litres. Then P holds $160$ and R holds $80$. P exceeds R by $80$, which is $\frac{80}{80} \times 100 = 100\%$ of R.",
  "Adding the two percentages, which are measured on Q, not on R.",
  "C01A-compare-via-common-base", "Convert both to a common base and compare; the trap is adding rates with different bases.",
  correct=r"$100\%$",
  distractors=[(r"$80\%$", r"Adds the two percentages: $60 + 20$."),
               (r"$92\%$", r"Takes Q as $20\%$ more than R and multiplies $1.6 \times 1.2 = 1.92$."),
               (r"$50\%$", r"Finds by what percent R is less than P, $\frac{80}{160}$.")],
  check=_c9, values=[100, 80, 92, 50], cognitive="Application")


def _c10():
    x = symbols('x', positive=True)
    reduced = Rational(40, 100)
    return solve(Eq(reduced * (1 + x / 100), 1), x)[0]
q("C01-A-010", TS, "Percentage rise needed to undo a percentage fall", "Easy",
  "Inverse/parameter",
  r"During a month of track repairs, the number of daily passengers on a metro line fell by $60\%$. By what percent must the daily passenger count rise from this reduced level to return to its original level? Give the answer in percent.",
  "TITA",
  r"Take the original count as $100$. It falls to $40$. To return to $100$ it must rise by $60$, which is $\frac{60}{40} \times 100 = 150\%$ of the reduced level.",
  "Using the same percentage to undo a fall, or measuring the rise on the original level.",
  "C01A-restore-original", "One base change; the trap is reusing the size of the fall.",
  tita_answer=150, check=_c10,
  tita_traps=[(60, r"Assumes a $60\%$ rise undoes a $60\%$ fall."),
              (250, r"Reports the original level as a percentage of the reduced level, $\frac{100}{40}$.")],
  cognitive="Understanding")


def _c11():
    b, g = symbols('b g', positive=True)
    sol = solve(Eq(Rational(15, 100) * b, Rational(24, 100) * g), b)[0]
    return simplify(sol / g)
q("C01-A-011", TB, "Ratio of two groups from equal percentages of each", "Easy",
  "Conceptual/application",
  r"In a school, $15\%$ of the boys are equal in number to $24\%$ of the girls. What is the ratio of the number of boys to the number of girls?",
  "MCQ",
  r"$0.15b = 0.24g$ gives $\frac{b}{g} = \frac{24}{15} = \frac{8}{5}$. The ratio is $8 : 5$: the group with the smaller percentage taken must be the larger group.",
  "Writing the ratio in the order of the percentages instead of inverting it.",
  "C01A-equal-percent-ratio", "One equation; the trap is the inverse relation between the percentage and the group size.",
  correct=r"$8 : 5$",
  distractors=[(r"$5 : 8$", r"Writes the ratio as $15 : 24$, in the order of the percentages."),
               (r"$8 : 13$", r"Finds $8 : 5$ but reports boys to total students."),
               (r"$5 : 13$", r"Reports girls to total students.")],
  check=_c11, values=[F(8, 5), F(5, 8), F(8, 13), F(5, 13)], cognitive="Understanding")


def _c12():
    m = F(1)
    for r in (10, 20, -25):
        m *= 1 + F(r, 100)
    return (m - 1) * 100
q("C01-A-012", TS, "Net effect of three successive percentage changes", "Easy",
  "Multi-step word problem",
  r"The membership of a chess club rose by $10\%$ in its first year and by $20\%$ in its second year, and then fell by $25\%$ in its third year, each change being measured on the membership at the end of the previous year. Over the three years, the membership",
  "MCQ",
  r"The net multiplier is $1.1 \times 1.2 \times 0.75 = 1.32 \times 0.75 = 0.99$. So the membership decreased by $1\%$.",
  "Adding the percentages, or subtracting the last percentage as points from the running total.",
  "C01A-three-stage-net", "Three multipliers; the trap is adding the rates.",
  correct=r"decreased by $1\%$",
  distractors=[(r"increased by $5\%$", r"Adds the changes: $10 + 20 - 25 = 5$."),
               (r"increased by $1\%$", r"Gets the size of the net change right but the direction wrong."),
               (r"increased by $7\%$", r"Gets $132\%$ after two years and subtracts $25$ points: $132 - 25 = 107$.")],
  check=_c12, values=[-1, 5, 1, 7], cognitive="Application")


def _c13():
    v0 = F(1000)
    v1 = v0 - v0 * F(25, 100)
    v2 = v1 + v1 * F(40, 100)
    return (v2 - v0) / v0 * 100
q("C01-A-013", TS, "Net effect of a fall followed by a larger rise on the reduced base", "Easy",
  "Single-step computation",
  r"The number of orders received by a bakery's delivery app fell by $25\%$ in a week of heavy rain and then rose by $40\%$ in the following week, the rise being measured on the number of orders in the rainy week. Compared with the week before the rain, the number of orders in the week after the rain",
  "MCQ",
  r"The net multiplier is $0.75 \times 1.4 = 1.05$, so the number of orders increased by $5\%$. Equivalently, $-25 + 40 + \frac{(-25) \times 40}{100} = 15 - 10 = 5$.",
  "Adding the two percentage changes as if they were measured on the same base.",
  "C01A-net-two-step", "One product of two multipliers; the trap is simple addition of the rates.",
  correct=r"increased by $5\%$",
  distractors=[(r"increased by $15\%$", r"Adds the changes: $-25 + 40 = 15$."),
               (r"increased by $25\%$", r"Uses $a + b + \frac{ab}{100}$ with the sign of the product term reversed: $15 + 10 = 25$."),
               (r"decreased by $5\%$", r"Gets the size of the net change right but assumes a fall followed by a rise always leaves a net loss.")],
  check=_c13, values=[5, 15, 25, -5], cognitive="Application")


def _c14():
    N = 640
    maha = N * 45 // 100
    rest = N - maha
    guj = rest * 25 // 100
    assert N * 45 % 100 == 0 and rest * 25 % 100 == 0
    return rest - guj
q("C01-A-014", TB, "Count left after a percentage and then a percentage of the remainder", "Easy",
  "Multi-step word problem",
  r"A hostel has $640$ students. Of these, $45\%$ are from Maharashtra, and $25\%$ of the remaining students are from Gujarat. How many students in the hostel are from neither Maharashtra nor Gujarat?",
  "TITA",
  r"Students not from Maharashtra: $55\%$ of $640 = 352$. Of these, $25\%$ are from Gujarat, so $75\%$ are from neither: $0.75 \times 352 = 264$.",
  "Taking the second percentage of the whole hostel instead of the remainder.",
  "C01A-fraction-of-remainder", "Two percentage steps with a change of base.",
  tita_answer=264, check=_c14,
  tita_traps=[(192, r"Takes $25\%$ of all $640$ students: $640 \times (1 - 0.45 - 0.25) = 192$."),
              (88, r"Reports the students from Gujarat, $25\%$ of $352$.")],
  cognitive="Application")


# ================================================================ MEDIUM (20)

def _c15():
    x = symbols('x', positive=True)
    return solve(Eq(Rational(125, 100) * (1 - x / 100), Rational(90, 100)), x)[0]
q("C01-A-015", TS, "Second change needed for a target net change after a known first change", "Medium",
  "Inverse/parameter",
  r"The number of downloads of a mobile game in March was $25\%$ more than in February. By what percent must the downloads in April fall, compared with March, so that April's downloads are $10\%$ less than February's?",
  "MCQ",
  r"Take February as $100$. March is $125$ and April must be $90$. The required fall is $35$ out of $125$, that is $\frac{35}{125} \times 100 = 28\%$.",
  "Adding the two percentages, which are measured on different bases.",
  "C01A-missing-change-target", "Needs the base of the second change to be the March figure; two steps.",
  correct=r"$28\%$",
  distractors=[(r"$35\%$", r"Adds the changes: $25 + 10$."),
               (r"$30\%$", r"Takes $20\%$ to undo the rise and then adds the further $10\%$."),
               (r"$20\%$", r"Finds only the fall that brings April back to February's level.")],
  check=_c15, values=[28, 35, 30, 20], cognitive="Application")


def _c16():
    x = symbols('x', positive=True)
    return solve(Eq(Rational(120, 100) * Rational(75, 100) * (1 + x / 100), Rational(108, 100)), x)[0]
q("C01-A-016", TS, "Third change needed for a target net change after two known changes", "Medium",
  "Inverse/parameter",
  r"During a three-week festival, the weekly footfall at a museum rose by $20\%$ in the first week and fell by $25\%$ in the second week, each change being measured on the footfall of the previous week. By what percent must the footfall rise in the third week, compared with the second week, so that the third week's footfall is $8\%$ more than the footfall in the week before the festival? Give the answer in percent.",
  "TITA",
  r"Take the pre-festival footfall as $100$. After two weeks it is $100 \times 1.2 \times 0.75 = 90$. The target is $108$, so the rise needed is $\frac{18}{90} \times 100 = 20\%$.",
  "Adding and subtracting the percentages as if they were on the same base.",
  "C01A-missing-change-target", "Two successive changes, then an inverse step on the new base.",
  tita_answer=20, check=_c16,
  tita_traps=[(13, r"Adds the rates: $20 - 25 + x = 8$ gives $x = 13$."),
              (18, r"Finds the net $10\%$ fall and adds it to the target: $8 + 10 = 18$.")],
  cognitive="Application")


def _c17():
    x = symbols('x', positive=True)
    return _pos(solve(Eq((1 + x / 100) * (1 - 2 * x / 100), Rational(88, 100)), x))[0]
q("C01-A-017", TS, "Finding a rate when a rise of x% is followed by a fall of 2x%", "Medium",
  "Inverse/parameter",
  r"The number of visitors to a hill station rose by $x\%$ in one year and then fell by $2x\%$ in the next year, the fall being measured on the number of visitors at the end of the first year, after the rise. Over the two years the number of visitors fell by $12\%$. What is the value of $x$?",
  "MCQ",
  r"$(1 + \frac{x}{100})(1 - \frac{2x}{100}) = 0.88$. With $t = \frac{x}{100}$: $1 - t - 2t^2 = 0.88$, so $2t^2 + t - 0.12 = 0$, giving $t = \frac{-1 + 1.4}{4} = 0.1$. Hence $x = 10$. Check: $1.1 \times 0.8 = 0.88$.",
  r"Dropping the product term and solving $x - 2x = -12$.",
  "C01A-solve-for-rate", "Leads to a quadratic in the rate; option checking also works.",
  correct=r"$10$",
  distractors=[(r"$12$", r"Ignores the product term: $x - 2x = -12$."),
               (r"$20$", r"Reports the size of the fall, $2x$, instead of $x$."),
               (r"$6$", r"Ignores the rise and sets $2x = 12$.")],
  check=_c17, values=[10, 12, 20, 6], cognitive="Application")


def _c18():
    x = symbols('x', positive=True)
    return solve(Eq(x * Rational(120, 100) * Rational(85, 100), 2856), x)[0]
q("C01-A-018", TS, "Original value from the value after two successive changes", "Medium",
  "Inverse/parameter",
  r"The membership of a gym rose by $20\%$ in one quarter and then fell by $15\%$ in the next quarter, the fall being measured on the membership at the end of the first quarter. The gym now has $2{,}856$ members. How many members did it have at the start?",
  "MCQ",
  r"The net multiplier is $1.2 \times 0.85 = 1.02$. So the starting membership is $\frac{2856}{1.02} = 2800$.",
  r"Adding the rates to get $5\%$ and dividing by $1.05$, or reversing a percentage change by applying the opposite percentage.",
  "C01A-reverse-successive", "Net multiplier, then a reverse step; the traps are rate addition and wrong reversal.",
  correct=r"$2{,}800$",
  distractors=[(r"$2{,}720$", r"Adds the rates to get a net $5\%$ rise: $\frac{2856}{1.05} = 2720$."),
               (r"$2{,}737$", r"Reverses the rise correctly, $\frac{2856}{1.2} = 2380$, but reverses the fall by adding $15\%$: $2380 \times 1.15$."),
               (r"$3{,}360$", r"Reports the membership at the end of the first quarter, $2800 \times 1.2$.")],
  check=_c18, values=[2800, 2720, 2737, 3360], cognitive="Application")


def _c19():
    s = symbols('s', positive=True)
    return solve(Eq(3, Rational(25, 100) * s), s)[0]
q("C01-A-019", TB, "Original share when a rise in percentage points equals a given percent rise", "Medium",
  "Conceptual/application",
  r"Over a year, the percentage of households in a town that own a car rose by $3$ percentage points. This rise amounts to a $25\%$ increase in that percentage. What percentage of the households in the town owned a car at the start of the year? Give the answer in percent.",
  "TITA",
  r"If the starting share is $s\%$, a $25\%$ increase adds $0.25s$ percentage points. So $0.25s = 3$ and $s = 12$. The share rose from $12\%$ to $15\%$.",
  "Confusing the rise in percentage points with the relative rise, or reporting the new share.",
  "C01A-points-vs-percent", "Needs a clean separation of percentage points from percent change.",
  tita_answer=12, check=_c19,
  tita_traps=[(15, r"Reports the share at the end of the year."),
              (28, r"Adds the two figures: $25 + 3$.")],
  cognitive="Understanding")


def _c20():
    old, new = F(15, 2), F(6)
    return [old - new, (old - new) / old * 100]
q("C01-A-020", TB, "Identifying a correct statement about percentage points and percent change", "Medium",
  "Conceptual/application",
  r"The unemployment rate in a district fell from $7.5\%$ to $6\%$ over two years. Which of the following statements is correct?",
  "MCQ",
  r"The rate fell by $7.5 - 6 = 1.5$ percentage points. Relative to the starting rate, this is $\frac{1.5}{7.5} \times 100 = 20\%$. So the rate fell by $1.5$ percentage points, a decrease of $20\%$.",
  "Mixing up percentage points and percent, or measuring the relative change on the final value.",
  "C01A-points-vs-percent", "Four closely worded statements; needs both the point change and the relative change on the right base.",
  correct=r"It fell by $1.5$ percentage points, a decrease of $20\%$.",
  distractors=[(r"It fell by $1.5$ percentage points, a decrease of $25\%$.", r"Measures the relative change on the final rate, $\frac{1.5}{6}$."),
               (r"It fell by $1.5$ percentage points, a decrease of $1.5\%$.", r"Treats the change in percentage points as the percent change."),
               (r"It fell by $1.5$ percentage points, a decrease of $80\%$.", r"Computes the new rate as a percentage of the old one, $\frac{6}{7.5} = 80\%$, and reports that as the decrease.")],
  check=_c20, values=[[F(3, 2), 20], [F(3, 2), 25], [F(3, 2), F(3, 2)], [F(3, 2), 80]], cognitive="Understanding")


def _c21():
    a, d = F(3), F(2)
    new = a * F(120, 100) + d * F(150, 100)
    return (new - (a + d)) / (a + d) * 100
q("C01-A-021", TB, "Percentage change of a total when its parts change by different percentages", "Medium",
  "Multi-step word problem",
  r"A tea blend contains Assam and Darjeeling leaves in the ratio $3 : 2$ by weight. The blender increases the quantity of Assam leaves by $20\%$ and the quantity of Darjeeling leaves by $50\%$. By what percent does the total weight of the blend increase?",
  "MCQ",
  r"Take $3$ kg of Assam and $2$ kg of Darjeeling. The increases are $0.6$ kg and $1$ kg, a total of $1.6$ kg on $5$ kg, which is $32\%$. (This is the weighted mean $\frac{3 \times 20 + 2 \times 50}{5}$.)",
  "Taking the simple average of the two percentages, or attaching the weights to the wrong parts.",
  "C01A-weighted-combined-change", "Weighted average of two percentage changes; two traps on the weights.",
  correct=r"$32\%$",
  distractors=[(r"$35\%$", r"Takes the simple average of $20$ and $50$."),
               (r"$70\%$", r"Adds the two percentages."),
               (r"$38\%$", r"Swaps the weights: $\frac{2 \times 20 + 3 \times 50}{5}$.")],
  check=_c21, values=[32, 35, 70, 38], cognitive="Application")


def _c22():
    p = symbols('p', positive=True)
    return solve(Eq(p * Rational(110, 100) + (1200 - p) * Rational(95, 100), 1260), p)[0]
q("C01-A-022", TB, "Splitting a total from the net effect of different percentage changes on its parts", "Medium",
  "Inverse/parameter",
  r"Last year, Greenfield School and Riverside School together had $1{,}200$ students. This year Greenfield's enrolment rose by $10\%$ and Riverside's fell by $5\%$, and the two schools together now have $1{,}260$ students. How many students did Greenfield School have last year?",
  "TITA",
  r"Let Greenfield have $g$ students. The net change is $0.1g - 0.05(1200 - g) = 60$, so $0.15g = 120$ and $g = 800$. Check: $880 + 380 = 1260$.",
  "Reporting the other school, or this year's figure.",
  "C01A-weighted-combined-change", "One linear equation from two different percentage changes.",
  tita_answer=800, check=_c22,
  tita_traps=[(400, r"Reports Riverside's enrolment last year."),
              (880, r"Reports Greenfield's enrolment this year.")],
  cognitive="Application")


def _c23():
    Z = F(100)
    Y = Z * F(140, 100)
    X = Y * F(70, 100)
    return (X - Z) / Z * 100
q("C01-A-023", TB, "Chain of 'percent more' and 'percent less' to compare the ends", "Medium",
  "Multi-step word problem",
  r"Parcel X weighs $30\%$ less than parcel Y, and parcel Y weighs $40\%$ more than parcel Z. Compared with parcel Z, parcel X is",
  "MCQ",
  r"Take Z as $100$ g. Then Y is $140$ g and X is $0.7 \times 140 = 98$ g. So X is $2\%$ lighter than Z.",
  "Adding the two percentages, which have different bases.",
  "C01A-compare-via-common-base", "Two linked comparisons on different bases.",
  correct=r"$2\%$ lighter",
  distractors=[(r"$10\%$ heavier", r"Adds the changes: $40 - 30 = 10$."),
               (r"$2\%$ heavier", r"Gets the size of the gap right but the direction wrong."),
               (r"$22\%$ heavier", r"Uses $a + b + \frac{ab}{100}$ with the wrong sign of the product: $40 - 30 + 12$.")],
  check=_c23, values=[-2, 10, 2, 22], cognitive="Application")


def _c24():
    for N in range(1, 100000):
        v, ok = F(N), True
        for r in (15, -40, 25):
            v = v * (1 + F(r, 100))
            if v.denominator != 1:
                ok = False
                break
        if ok:
            return N
q("C01-A-024", TS, "Smallest starting count for which every stage of three successive changes is whole", "Medium",
  "Casework/optimisation",
  r"The number of saplings in a nursery rose by $15\%$ in the first month, fell by $40\%$ in the second month and rose by $25\%$ in the third month, each change being measured on the number at the end of the previous month. What is the smallest possible number of saplings in the nursery at the start of the first month?",
  "TITA",
  r"After the first month there are $\frac{23N}{20}$ saplings, so $20$ divides $N$. After the second month there are $\frac{3}{5} \times \frac{23N}{20} = \frac{69N}{100}$, so $100$ divides $N$. After the third month there are $\frac{5}{4} \times \frac{69N}{100} = \frac{69N}{80}$, so $80$ divides $N$. Hence $N$ is a multiple of $\mathrm{lcm}(100, 80) = 400$. Check: $400 \to 460 \to 276 \to 345$.",
  "Using only the net multiplier, which ignores the whole-number counts at the intermediate stages.",
  "C01A-integer-constraint", "Whole numbers are needed at every stage, not only at the end; the net multiplier alone gives a wrong answer.",
  tita_answer=400, check=_c24,
  tita_traps=[(80, r"Uses only the net multiplier $1.15 \times 0.6 \times 1.25 = \frac{69}{80}$, so needs only $80$ to divide $N$."),
              (100, r"Checks only the first two months, so needs only $100$ to divide $N$.")],
  cognitive="Analysis")


def _c25():
    x = symbols('x', positive=True)
    return solve(Eq(x * Rational(60, 100) * Rational(50, 100), 18), x)[0]
q("C01-A-025", TB, "Original amount from what is left after a percentage and a percentage of the remainder", "Medium",
  "Inverse/parameter",
  r"Ananya used $40\%$ of the paint in a drum on Monday and $50\%$ of the remaining paint on Tuesday. If $18$ litres of paint are left in the drum, how many litres of paint were in the drum at the start?",
  "TITA",
  r"After Monday $60\%$ remains; after Tuesday half of that, $30\%$, remains. So $0.3x = 18$ and $x = 60$ litres.",
  "Subtracting both percentages from the original amount.",
  "C01A-fraction-of-remainder", "A reverse step through two percentages on changing bases.",
  tita_answer=60, check=_c25,
  tita_traps=[(180, r"Subtracts $40\%$ and $50\%$ of the original, leaving $10\%$: $\frac{18}{0.1}$."),
              (30, r"Ignores Tuesday and treats $18$ litres as $60\%$ of the drum.")],
  cognitive="Application")


def _c26():
    n = symbols('n', positive=True)
    N = solve(Eq(n * Rational(120, 100) - n * Rational(80, 100), 96), n)[0]
    return N * Rational(120, 100)
q("C01-A-026", TB, "Number from the gap between a percentage increase and a percentage decrease of it", "Medium",
  "Multi-step word problem",
  r"Meera was asked to increase a number by $20\%$, but she decreased it by $20\%$ instead. Her result was $96$ less than the correct result. What was the correct result?",
  "MCQ",
  r"The correct result is $120\%$ of the number and hers is $80\%$, so the gap is $40\%$ of the number: $0.4n = 96$ gives $n = 240$. The correct result is $1.2 \times 240 = 288$.",
  "Stopping at the original number, or reporting the wrong result.",
  "C01A-percent-difference-find-whole", "Gap of two percentages gives the number; one further step gives the answer.",
  correct=r"$288$",
  distractors=[(r"$240$", r"Reports the original number."),
               (r"$192$", r"Reports Meera's result, $0.8 \times 240$."),
               (r"$336$", r"Increases the number by the $40\%$ gap: $240 \times 1.4$.")],
  check=_c26, values=[288, 240, 192, 336], cognitive="Application")


def _c27():
    s = F(1)
    a = s * (1 + F(300, 100))
    return s / (a + s) * 100
q("C01-A-027", TB, "'x% more than' versus 'x% of' when finding a share", "Medium",
  "Conceptual/application",
  r"The number of photos in Arjun's phone gallery is $300\%$ more than the number in Sneha's gallery. Sneha's photos make up what percent of the photos in the two galleries together?",
  "MCQ",
  r"$300\%$ more means $4$ times as many. If Sneha has $s$ photos, Arjun has $4s$ and together they have $5s$. Sneha's share is $\frac{s}{5s} = 20\%$.",
  r"Reading $300\%$ more than as $300\%$ of, that is three times.",
  "C01A-more-than-vs-of", "Single idea with a strong reading trap.",
  correct=r"$20\%$",
  distractors=[(r"$25\%$", r"Reads $300\%$ more as three times: $\frac{1}{1 + 3}$."),
               (r"$75\%$", r"Reads $300\%$ more as three times and reports Arjun's share, $\frac{3}{4}$."),
               (r"$80\%$", r"Reports Arjun's share, $\frac{4}{5}$.")],
  check=_c27, values=[20, 25, 75, 80], cognitive="Understanding")


def _c28():
    x = symbols('x', positive=True)
    m = Rational(125, 100) * Rational(80, 100) * Rational(110, 100)
    return solve(Eq(x * m - x, 15), x)[0]
q("C01-A-028", TS, "Original value from the net gain after three successive changes", "Medium",
  "Inverse/parameter",
  r"The stock of cartons in a warehouse rose by $25\%$ in the first week, fell by $20\%$ in the second week and rose by $10\%$ in the third week, each change being measured on the stock at the end of the previous week. At the end of the third week the stock was $15$ cartons more than at the start. How many cartons were in stock at the start?",
  "TITA",
  r"The net multiplier is $1.25 \times 0.8 \times 1.1 = 1 \times 1.1 = 1.1$, a net rise of $10\%$. So $10\%$ of the starting stock is $15$, and the starting stock is $150$ cartons.",
  r"Adding the three rates to get a $15\%$ net change.",
  "C01A-reverse-successive", "Three multipliers combine to a clean net rate; the trap is adding rates.",
  tita_answer=150, check=_c28,
  tita_traps=[(100, r"Adds the rates, $25 - 20 + 10 = 15\%$, and solves $0.15x = 15$."),
              (165, r"Reports the stock at the end of the third week.")],
  cognitive="Application")


def _c29():
    r = symbols('r', positive=True)
    return _pos(solve(Eq((1 + r) ** 2, Rational(1125, 1000) * Rational(128, 100)), r))[0] * 100
q("C01-A-029", TS, "Equal yearly rate equivalent to two unequal successive increases", "Medium",
  "Conceptual/application",
  r"The number of subscribers of a magazine grew by $12.5\%$ in one year and by $28\%$ in the next year, each growth being measured on the number at the start of that year. Had the number grown by the same percentage in each of the two years, reaching the same final number, what would that yearly percentage have been?",
  "MCQ",
  r"The two-year multiplier is $1.125 \times 1.28 = 1.44$. Equal yearly growth needs $(1 + \frac{r}{100})^2 = 1.44$, so $1 + \frac{r}{100} = 1.2$ and $r = 20$. The equal rate is $20\%$, slightly less than the simple average of the two rates.",
  "Taking the simple average of the two rates, which ignores compounding.",
  "C01A-equivalent-equal-changes", "Needs the net multiplier and then a square root; the tempting simple average is close but wrong.",
  correct=r"$20\%$",
  distractors=[(r"$20.25\%$", r"Takes the simple average of the two rates: $\frac{12.5 + 28}{2}$."),
               (r"$22\%$", r"Finds the net rise of $44\%$ and halves it."),
               (r"$44\%$", r"Reports the single two-year increase instead of the yearly rate.")],
  check=_c29, values=[20, F(81, 4), 22, 44], cognitive="Understanding")


def _c30():
    R = F(100)
    S = R * F(250, 100)
    Q = S * F(80, 100)
    P = Q * F(125, 100)
    return (P - R) / P * 100
q("C01-A-030", TB, "Chain of three 'more than' and 'less than' comparisons, asked in reverse", "Medium",
  "Multi-step word problem",
  r"Four broadband plans P, Q, R and S are compared by download speed. Plan P is $25\%$ faster than plan Q, plan Q is $20\%$ slower than plan S, and plan S is $150\%$ faster than plan R. By what percent is the speed of plan R less than the speed of plan P? Give the answer in percent.",
  "TITA",
  r"Take R as $100$. Then S is $250$, Q is $0.8 \times 250 = 200$ and P is $1.25 \times 200 = 250$. (The $25\%$ rise and the $20\%$ fall cancel, so P equals S.) R is $150$ less than P, which is $\frac{150}{250} \times 100 = 60\%$ of P.",
  "Measuring the gap on the smaller value instead of on the value being compared against.",
  "C01A-compare-via-common-base", "Three linked comparisons on different bases, then a reversed comparison.",
  tita_answer=60, check=_c30,
  tita_traps=[(150, r"Sees that P equals S and reports how much faster S is than R, measuring on R."),
              (40, r"Reports R as a percentage of P, $\frac{100}{250}$, instead of the shortfall.")],
  cognitive="Application")


def _c31():
    m = symbols('m', positive=True)
    n = Rational(24, 100) * m
    val = n / 100 * 50
    return simplify(val / m * 100)
q("C01-A-031", TB, "Using x% of y = y% of x to rewrite a nested percentage", "Medium",
  "Conceptual/application",
  r"For a positive number $m$, let $n$ be $24\%$ of $m$. Then $n\%$ of $50$ equals what percent of $m$?",
  "MCQ",
  r"$n\%$ of $50 = \frac{n}{100} \times 50 = \frac{n}{2}$. Since $n = 0.24m$, this is $0.12m$, that is $12\%$ of $m$. (Equivalently, $n\%$ of $50$ is $50\%$ of $n$.)",
  "Mishandling which quantity the percentage is taken of.",
  "C01A-percent-swap-symmetry", "Needs the swap property of percentages and a second substitution.",
  correct=r"$12\%$",
  distractors=[(r"$24\%$", r"Stops at $n$ being $24\%$ of $m$."),
               (r"$48\%$", r"Computes $n\%$ of $50$ as $\frac{100n}{50} = 2n$."),
               (r"$50\%$", r"Rewrites $n\%$ of $50$ as $50\%$ of $n$ and reports $50$.")],
  check=_c31, values=[12, 24, 48, 50], cognitive="Understanding")


def _c32():
    out = F(100)
    old = out * F(5, 100)
    new = out * F(150, 100) * F(4, 100)
    return (new - old) / old * 100
q("C01-A-032", TS, "Change in a count when its rate falls in percentage points and the base grows", "Medium",
  "Conceptual/application",
  r"A factory's defect rate (defective units as a percentage of total output) fell from $5\%$ to $4\%$, while its total output rose by $50\%$. Over this period, the number of defective units",
  "MCQ",
  r"The count is rate times output. Its multiplier is $\frac{4}{5} \times 1.5 = 1.2$, so the number of defective units increased by $20\%$, even though the rate fell.",
  "Treating the fall in percentage points as a fall in the count, or subtracting rates.",
  "C01A-share-and-total-change", "Combines a percentage-point change with a change in base.",
  correct=r"increased by $20\%$",
  distractors=[(r"increased by $30\%$", r"Subtracts the $20\%$ fall in the rate from the $50\%$ rise in output."),
               (r"increased by $49\%$", r"Subtracts the $1$ percentage point fall from the $50\%$ rise."),
               (r"decreased by $20\%$", r"Uses only the fall in the rate and ignores the rise in output.")],
  check=_c32, values=[20, 30, 49, -20], cognitive="Analysis")


def _c33():
    town = F(100)
    school = town * F(40, 100)
    return school * F(150, 100) / (town * F(120, 100)) * 100
q("C01-A-033", TB, "One quantity as a percentage of another after both change", "Medium",
  "Multi-step word problem",
  r"The number of books in a school library is $40\%$ of the number in the town library. The school library then increases its stock by $50\%$ and the town library increases its stock by $20\%$. The school library's stock is now what percent of the town library's stock?",
  "MCQ",
  r"The percentage is multiplied by $\frac{1.5}{1.2} = 1.25$, so it becomes $40 \times 1.25 = 50\%$.",
  "Adding or subtracting percentage changes directly to a percentage.",
  "C01A-ratio-after-changes", "A ratio whose two parts change by different percentages.",
  correct=r"$50\%$",
  distractors=[(r"$70\%$", r"Adds the changes as points: $40 + 50 - 20$."),
               (r"$52\%$", r"Takes a net change of $50 - 20 = 30\%$ and applies it: $40 \times 1.3$."),
               (r"$60\%$", r"Ignores the town library's increase: $40 \times 1.5$.")],
  check=_c33, values=[50, 70, 52, 60], cognitive="Application")


def _c34():
    m = symbols('m', positive=True)
    S = 1
    w1 = S * Rational(125, 100)
    w2 = w1 * m
    w3 = w2 * Rational(80, 100)
    mult = solve(Eq(w3, w1 * Rational(96, 100)), m)[0]
    return (mult - 1) * 100
q("C01-A-034", TS, "Missing middle change when the target is stated against an intermediate value", "Medium",
  "Inverse/parameter",
  r"The number of active listings on an online marketplace rose by $25\%$ in the first week of a month. It changed by some percentage in the second week and then fell by $20\%$ in the third week, each change being measured on the number at the end of the previous week. At the end of the third week the number of listings was $4\%$ less than at the end of the first week. In the second week, the number of listings",
  "MCQ",
  r"Measure everything from the end of the first week. The second and third weeks together must give a multiplier of $0.96$, so the second week's multiplier is $\frac{0.96}{0.8} = 1.2$: an increase of $20\%$. The first week's $25\%$ rise plays no part, because the target is set against the end of that week.",
  "Measuring the target against the start of the month instead of the end of the first week.",
  "C01A-target-vs-intermediate", "An inverse step whose base is an intermediate value; the first-week figure is a trap.",
  correct=r"increased by $20\%$",
  distractors=[(r"decreased by $4\%$", r"Measures the target on the start of the month: $1.25 \times m \times 0.8 = 0.96$ gives $m = 0.96$."),
               (r"increased by $16\%$", r"Adds the rates of the last two weeks: $x - 20 = -4$."),
               (r"decreased by $9\%$", r"Adds all three rates and measures the target on the start: $25 + x - 20 = -4$.")],
  check=_c34, values=[20, -4, 16, -9], cognitive="Application")


# ================================================================ DIFFICULT (11)

def _c35():
    ops = [lambda v: v * F(120, 100), lambda v: v * F(75, 100), lambda v: v + 60]
    best = None
    for perm in itertools.permutations(ops):
        v = F(500)
        for op in perm:
            v = op(v)
        best = v if best is None or v > best else best
    return best
q("C01-A-035", TS, "Maximising the result when percentage and absolute changes can be ordered freely", "Difficult",
  "Casework/optimisation",
  r"A tank contains $500$ litres of water and is large enough never to overflow. Three operations are to be carried out, each exactly once, in any order: (i) increase the amount of water in the tank by $20\%$; (ii) remove $25\%$ of the water in the tank; (iii) add $60$ litres of water. Each percentage is of the amount in the tank at that moment. What is the largest possible amount of water, in litres, in the tank after all three operations?",
  "TITA",
  r"The two percentage operations together multiply the original $500$ litres by $1.2 \times 0.75 = 0.9$ in either order, giving $450$. The $60$ litres added is multiplied only by the percentage operations that come after it: by $0.9$ if added first, $0.75$ if added between (i) and (ii), $1.2$ if added between (ii) and (i), and $1$ if added last. The best is $1.2$: remove $25\%$, add $60$ litres, then increase by $20\%$. Maximum $= 450 + 72 = 522$ litres.",
  "Assuming the absolute addition is best done last, or that order never matters.",
  "C01A-order-with-absolute-change", "Casework over orders; the non-obvious best order places the addition before the increase but after the removal.",
  tita_answer=522, check=_c35,
  tita_traps=[(510, r"Adds the $60$ litres last: $450 + 60$."),
              (504, r"Adds the $60$ litres first: $560 \times 0.9$.")],
  cognitive="Analysis", exams=CX)


def _c36():
    N = symbols('N', positive=True)
    women0 = Rational(25, 100) * N
    women1 = Rational(30, 100) * N * Rational(120, 100)
    return solve(Eq(women1 - women0, 132), N)[0]
q("C01-A-036", TB, "Original total from the change in a count whose share and base both change", "Difficult",
  "Multi-step word problem",
  r"At a firm, women made up $25\%$ of the employees. Over a year, the total number of employees rose by $20\%$ and the share of women among the employees rose to $30\%$. As a result, the firm had $132$ more women employees than at the start of the year. How many employees did the firm have at the start of the year?",
  "MCQ",
  r"Let the starting total be $N$. Women went from $0.25N$ to $0.30 \times 1.2N = 0.36N$, a rise of $0.11N$. So $0.11N = 132$ and $N = 1200$. (The number of women rose by $44\%$.)",
  r"Treating the $5$ percentage point rise in share as the percentage change in the number of women, or ignoring the growth of the total.",
  "C01A-share-and-total-change", "Combines a share change in percentage points with a change in the base, then a reverse step.",
  correct=r"$1{,}200$",
  distractors=[(r"$2{,}640$", r"Ignores the share change and takes the women to rise by $20\%$: $0.2 \times 0.25N = 132$."),
               (r"$2{,}200$", r"Takes the rise as $5$ percentage points of the new total: $0.05 \times 1.2N = 132$."),
               (r"$2{,}112$", r"Adds $20 + 5$ to get a $25\%$ rise in women: $0.25 \times 0.25N = 132$.")],
  check=_c36, values=[1200, 2640, 2200, 2112], cognitive="Analysis", exams=CX)


def _c37():
    N, t = symbols('N t', positive=True)
    sols = solve([Eq(t * N + t * (1 - t) * N, 1440), Eq(t * N - t * (1 - t) * N, 160)], [N, t], dict=True)
    good = [s for s in sols if 0 < s[t] < 1]
    assert len(good) == 1
    N0, t0 = good[0][N], good[0][t]
    after2 = N0 * (1 - t0) ** 2
    return (N0 - after2) / after2 * 100
q("C01-A-037", TS, "Equal successive falls found from the absolute losses, then the rise that restores the level", "Difficult",
  "Inverse/parameter",
  r"The number of daily users of a library's reading room fell by the same percentage in each of two consecutive months, each fall being measured on the figure at the end of the previous month. Over the two months $1{,}440$ daily users were lost in all, and the fall in the first month exceeded the fall in the second month by $160$ users. By what percent must the number of daily users rise in the third month, over the second month's figure, to return exactly to the original level?",
  "MCQ",
  r"From the sum and difference, the falls were $800$ and $640$ users. The second fall is the same rate applied to a base that is itself $(1 - r)$ times the first base, so $1 - r = \frac{640}{800} = 0.8$ and the monthly fall is $20\%$. The original number was $\frac{800}{0.2} = 4000$, and after two months it is $4000 - 1440 = 2560$. The rise needed is $\frac{1440}{2560} \times 100 = 56.25\%$ (that is, $\frac{1}{0.64} = 1.5625$).",
  "Undoing a fall by a rise of the same percentage, or adding the monthly rates.",
  "C01A-missing-change-target", "The monthly rate must be extracted from absolute losses on changing bases before the restoring rise can be found on the reduced base.",
  correct=r"$56.25\%$",
  distractors=[(r"$36\%$", r"Finds the overall fall, $\frac{1440}{4000} = 36\%$, and uses the same percentage as the rise."),
               (r"$40\%$", r"Finds the monthly fall of $20\%$ and doubles it."),
               (r"$43.75\%$", r"Undoes each $20\%$ fall with a $25\%$ rise, then combines the two rises with the sign of the product term reversed: $25 + 25 - \frac{25 \times 25}{100}$.")],
  check=_c37, values=[F(225, 4), 36, 40, F(175, 4)], cognitive="Analysis", exams=CX)


def _c38():
    U, L = symbols('U L', positive=True)
    sol = solve(Eq(U * Rational(130, 100) + L * Rational(80, 100), (U + L) * Rational(105, 100)), U)[0]
    U0, L0 = sol.subs(L, 1), 1
    end = U0 * Rational(130, 100) * Rational(90, 100) + L0 * Rational(80, 100) * Rational(110, 100)
    return simplify((end - (U0 + L0)) / (U0 + L0) * 100)
q("C01-A-038", TS, "Two-stage changes on two parts whose ratio must first be found", "Difficult",
  "Multi-step word problem",
  r"A town has two reservoirs, Upper and Lower. In the first month the water in Upper rose by $30\%$ and the water in Lower fell by $20\%$, so the total water in the two reservoirs rose by $5\%$. In the second month the water in Upper fell by $10\%$ and the water in Lower rose by $10\%$, each change being measured on the level at the end of the first month. Compared with the start of the first month, the total water at the end of the second month is",
  "MCQ",
  r"From $0.3U - 0.2L = 0.05(U + L)$ we get $0.25U = 0.25L$, so $U = L$; take each as $100$. After the first month they hold $130$ and $80$. After the second month they hold $130 \times 0.9 = 117$ and $80 \times 1.1 = 88$, a total of $205$ against the original $200$. So the total is $2.5\%$ more.",
  r"Assuming the opposite $10\%$ changes in the second month cancel, or applying them to the starting levels instead of the levels at the end of the first month.",
  "C01A-weighted-combined-change", "Must first deduce the ratio of the parts from the net change, then apply a second stage on new bases.",
  correct=r"$2.5\%$ more",
  distractors=[(r"$5\%$ more", r"Assumes the $10\%$ fall and the $10\%$ rise in the second month cancel."),
               (r"$7.5\%$ more", r"Applies the second month's changes to the wrong reservoirs: $130 \times 1.1 + 80 \times 0.9 = 215$."),
               (r"the same as at the start", r"Applies the second month's changes to the starting levels instead of the first-month levels: $100 \times 0.9 + 100 \times 1.1 = 200$.")],
  check=_c38, values=[F(5, 2), 5, F(15, 2), 0], cognitive="Analysis", exams=CX)


def _c39():
    w = F(1000)
    peak = w
    history = []
    for day in range(1, 60):
        w = w * F(120, 100)
        peak = max(peak, w)
        history.append((day, w))
        w = w * F(80, 100)
        history.append((day, w))
    peak = max(v for _, v in history)
    for day, v in history:
        if v < F(70, 100) * peak:
            return day
q("C01-A-039", TS, "Alternating equal rise and fall measured against the peak level", "Difficult",
  "Casework/optimisation",
  r"A large tank holds some water and never overflows. Every day, starting on Day $1$, the amount of water is increased by $20\%$ in the morning and then decreased by $20\%$ in the evening, each change being measured on the amount in the tank just before that change. At the end of which day does the amount of water first fall below $70\%$ of the largest amount the tank ever holds? Give the day number.",
  "TITA",
  r"Each full day multiplies the amount by $1.2 \times 0.8 = 0.96$, so every morning level is lower than the one before. The largest amount is therefore reached on the morning of Day $1$: $1.2$ times the start. The target is $0.7 \times 1.2 = 0.84$ times the start. Evening levels are $0.96^k$ times the start: $0.96^4 \approx 0.849$ and $0.96^5 \approx 0.815$. So the amount first falls below the target at the end of Day $5$.",
  "Measuring the threshold against the starting amount instead of the largest amount, or treating the daily loss as simple.",
  "C01A-alternating-change-peak", "Needs the compounding daily factor, the insight that the peak is the first morning, and a power comparison.",
  tita_answer=5, check=_c39,
  tita_traps=[(9, r"Measures $70\%$ against the starting amount: $0.96^9 \approx 0.693$ is the first evening level below $0.7$."),
              (4, r"Treats the daily $4\%$ loss as simple, so the evening level after Day $4$ is $1 - 4 \times 0.04 = 0.84$ of the start, and takes reaching $0.84$ as falling below the target (equal is not below).")],
  cognitive="Analysis", exams=CX)


def _c40():
    t, u = symbols('t u', positive=True)
    sol = solve([Eq((1 + t) * (1 - u), 1), Eq((1 - t) * (1 + u), Rational(9, 10))], [t, u], dict=True)
    good = [s for s in sol if 0 < s[t] < 1 and 0 < s[u] < 1]
    assert len(good) == 1
    return good[0][t] * 100
q("C01-A-040", TS, "Rates that restore a value in one order and produce a given loss in the reversed directions", "Difficult",
  "Inverse/parameter",
  r"If the water in a tank is increased by $x\%$ and the result is then decreased by $y\%$, the amount returns exactly to its original value. If instead the original amount is first decreased by $x\%$ and the result is then increased by $y\%$, the final amount is $10\%$ less than the original. What is the value of $x$?",
  "TITA",
  r"Let $t = \frac{x}{100}$. Restoring requires $1 - \frac{y}{100} = \frac{1}{1 + t}$, so $\frac{y}{100} = \frac{t}{1 + t}$. Then $(1 - t)(1 + \frac{t}{1 + t}) = 0.9$ gives $(1 - t)(1 + 2t) = 0.9(1 + t)$, that is $2t^2 - 0.1t - 0.1 = 0$, so $t = \frac{0.1 + 0.9}{4} = 0.25$. Hence $x = 25$ (and $y = 20$). Check: $0.75 \times 1.2 = 0.9$.",
  r"Assuming the rise and fall that restore a value are equal, or reporting $y$ instead of $x$.",
  "C01A-restore-original", "Two conditions, a substitution and a quadratic in the rate.",
  tita_answer=25, check=_c40,
  tita_traps=[(20, r"Reports $y$ instead of $x$."),
              (10, r"Takes the $10\%$ loss as the value of $x$.")],
  cognitive="Analysis", exams=CX)


def _c41():
    start = F(16)
    s1 = start * F(125, 100)
    s2 = s1 - 5
    target = start + 2
    return (target - s2) / s2 * 100
q("C01-A-041", TS, "Mixed chain of percent and percentage-point changes with a target", "Difficult",
  "Inverse/parameter",
  r"A smartphone brand held a $16\%$ share of a market. In the first year its share increased by $25\%$. In the second year its share decreased by $5$ percentage points. By what percent must its share change in the third year so that at the end of the third year its share is $2$ percentage points higher than at the start?",
  "MCQ",
  r"The share goes from $16\%$ to $16 \times 1.25 = 20\%$, then to $20 - 5 = 15\%$. The target is $16 + 2 = 18\%$. The required change is $\frac{18 - 15}{15} \times 100 = 20\%$, an increase.",
  "Treating percent changes and percentage-point changes as the same kind of number.",
  "C01A-points-percent-chain", "Three stages alternating between relative and absolute changes, ending with an inverse step.",
  correct=r"an increase of $20\%$",
  distractors=[(r"an increase of $3\%$", r"Finds the gap of $3$ percentage points and reports it as a percent change."),
               (r"a decrease of $18\%$", r"Adds all figures as if in the same unit: $25 - 5 + x = 2$."),
               (r"a decrease of $50\%$", r"Treats the $25\%$ rise as $25$ points: $41\%$, then $36\%$, and $\frac{18}{36}$.")],
  check=_c41, values=[20, 3, -18, -50], cognitive="Analysis", exams=CX)


def _c42():
    x, t = symbols('x t', positive=True)
    intended = x * (1 + t) * Rational(120, 100)
    actual = x * (1 - t) * Rational(120, 100)
    sols = solve([Eq(intended - actual, 288), Eq(x - actual, 48)], [x, t], dict=True)
    good = [s for s in sols if 0 < s[t] < 1]
    assert len(good) == 1
    return intended.subs(good[0])
q("C01-A-042", TS, "Recovering the input and the rate from a sign error in a two-step percentage process", "Difficult",
  "Inverse/parameter",
  r"A spreadsheet formula is meant to raise a figure by $p\%$ and then raise the result by $20\%$. Because of a sign error, the formula lowered the figure by $p\%$ at the first step; the second step worked as intended. For one input figure, the output was $288$ less than the intended output and $48$ less than the input figure itself. What was the intended output?",
  "MCQ",
  r"Let the input be $x$ and $t = \frac{p}{100}$. The intended and actual outputs are $1.2x(1 + t)$ and $1.2x(1 - t)$, so their gap is $2.4tx = 288$, giving $tx = 120$. Also $x - 1.2x(1 - t) = 48$, that is $-0.2x + 1.2tx = 48$, so $-0.2x + 144 = 48$ and $x = 480$. Then $t = \frac{120}{480} = 0.25$, and the intended output is $480 \times 1.25 \times 1.2 = 720$.",
  "Stopping at the input figure, or dropping the second step when computing the intended output.",
  "C01A-percent-difference-find-whole", "Two conditions link the unknown input and the unknown rate through their product; needs a substitution before either value appears.",
  correct=r"$720$",
  distractors=[(r"$480$", r"Reports the input figure."),
               (r"$432$", r"Reports the actual output, $480 \times 0.75 \times 1.2$."),
               (r"$600$", r"Applies only the intended $25\%$ rise and forgets the second step: $480 \times 1.25$.")],
  check=_c42, values=[720, 480, 432, 600], cognitive="Analysis", exams=CX)


def _c43():
    cnt = 0
    for N in range(100, 1000):
        a = F(N) * F(1125, 1000)
        if a.denominator != 1:
            continue
        b = a * F(80, 100)
        if b.denominator == 1:
            cnt += 1
    return cnt
q("C01-A-043", TB, "Counting values for which successive percentage changes give whole numbers", "Difficult",
  "Casework/optimisation",
  r"For how many three-digit numbers $N$ is it true that increasing $N$ by $12.5\%$ gives a whole number, and then decreasing that whole number by $20\%$ also gives a whole number?",
  "MCQ",
  r"$1.125N = \frac{9N}{8}$ is whole exactly when $8$ divides $N$. Then $0.8 \times \frac{9N}{8} = \frac{9N}{10}$ is whole exactly when $10$ divides $N$. So $N$ is a multiple of $\mathrm{lcm}(8, 10) = 40$. Three-digit multiples of $40$ run from $120$ to $960$: $\frac{960}{40} - \frac{120}{40} + 1 = 24 - 3 + 1 = 22$.",
  "Checking only one of the two conditions, or miscounting the multiples.",
  "C01A-integer-constraint", "Two divisibility conditions from two successive changes, then careful counting.",
  correct=r"$22$",
  distractors=[(r"$21$", r"Counts the multiples of $40$ as $\frac{960 - 120}{40} = 21$, forgetting to add $1$."),
               (r"$90$", r"Checks only the final result, so counts the multiples of $10$."),
               (r"$112$", r"Checks only the first increase, so counts the multiples of $8$.")],
  check=_c43, values=[22, 21, 90, 112], cognitive="Analysis", exams=CX)


def _c44():
    x, r = symbols('x r', positive=True)
    priya = x * Rational(20, 100)
    after1 = x - priya
    after2 = after1 + r
    sneha = after2 * Rational(25, 100)
    after3 = after2 - sneha
    after4 = after3 * Rational(150, 100)
    sol = solve([Eq(sneha - priya, 4), Eq(after4, 153)], [x, r], dict=True)
    assert len(sol) == 1
    return sol[0][x]
q("C01-A-044", TB, "Working backwards when an unknown absolute gift is fixed by a later percentage", "Difficult",
  "Multi-step word problem",
  r"Joseph gave $20\%$ of his marbles to Priya. Ravi then gave Joseph some marbles, after which Joseph gave $25\%$ of the marbles he then had to Sneha; Sneha received $4$ more marbles than Priya had received. Finally, Ananya gave Joseph a number of marbles equal to $50\%$ of what he then had, and he ended with $153$ marbles. How many marbles did Joseph have at the start?",
  "MCQ",
  r"Let Joseph start with $x$ and let Ravi give $r$. Priya gets $0.2x$; Sneha gets $0.25(0.8x + r) = 0.2x + 0.25r$. Their difference is $0.25r = 4$, so $r = 16$. Now work backwards: $\frac{153}{1.5} = 102$, $\frac{102}{0.75} = 136$, $136 - 16 = 120$ and $\frac{120}{0.8} = 150$.",
  "Taking the difference of $4$ marbles as Ravi's gift itself, or reversing a percentage change by applying the opposite percentage.",
  "C01A-work-backwards", "The absolute gift is not given and must first be found from a comparison of two percentage gifts on different bases; then four reverse steps.",
  correct=r"$150$",
  distractors=[(r"$165$", r"Takes Ravi's gift to be $4$ marbles: $\frac{102}{0.75} = 136$, $136 - 4 = 132$, $\frac{132}{0.8} = 165$."),
               (r"$144$", r"Finds Ravi's gift correctly but reverses the $20\%$ gift by adding $20\%$: $120 \times 1.2$."),
               (r"$120$", r"Forgets to reverse the gift to Priya.")],
  check=_c44, values=[150, 165, 144, 120], cognitive="Analysis", exams=CX)


def _c45():
    a = symbols('a', positive=True)
    b = 100 * a / (100 + a)
    return _pos(solve(Eq(a - b, 90), a))[0]
q("C01-A-045", TS, "Increase and decrease that cancel, with a given difference of rates", "Difficult",
  "Inverse/parameter",
  r"During a festival, the daily output of a bakery was increased by $a\%$. After the festival, the output was decreased by $b\%$ of the festival-time output, which brought it back exactly to its original level. If $a - b = 90$, what is the value of $a$?",
  "TITA",
  r"Restoring requires $(1 + \frac{a}{100})(1 - \frac{b}{100}) = 1$, which simplifies to $a - b = \frac{ab}{100}$. So $ab = 9000$ with $b = a - 90$: $a^2 - 90a - 9000 = 0 = (a - 150)(a + 60)$. Hence $a = 150$ and $b = 60$. Check: $2.5 \times 0.4 = 1$.",
  r"Reporting $b$ instead of $a$, or assuming the two rates are equal.",
  "C01A-restore-original", "Needs the restore relation a - b = ab/100 and a quadratic.",
  tita_answer=150, check=_c45,
  tita_traps=[(60, r"Reports $b$ instead of $a$."),
              (90, r"Reports the difference $a - b$.")],
  cognitive="Analysis", exams=CX)
