import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
import math as _m

T = "Polygons"
CX = ("CAT", "XAT")


def _fig(f, alt, req=False):
    return dict(svg=f.svg(alt=alt), alt=alt, required=req)


def _reg(n, R=1, start=0):
    """Exact vertices of a regular n-gon of circumradius R, first vertex at angle `start` (radians), anticlockwise."""
    return [(R * cos(start + 2 * pi * k / n), R * sin(start + 2 * pi * k / n)) for k in range(n)]


def _area(V):
    n = len(V)
    return nsimplify(simplify(Abs(sum(V[i][0] * V[(i + 1) % n][1] - V[(i + 1) % n][0] * V[i][1] for i in range(n))) / 2))


def _fpts(n, R=1.0, start_deg=90.0, clockwise=True):
    sg = -1 if clockwise else 1
    return [(R * _m.cos(_m.radians(start_deg + sg * 360.0 * k / n)), R * _m.sin(_m.radians(start_deg + sg * 360.0 * k / n))) for k in range(n)]


def _ang(u, v):
    """Angle in degrees between vectors u and v (numeric)."""
    du = _m.hypot(*u); dv = _m.hypot(*v)
    c = (u[0] * v[0] + u[1] * v[1]) / (du * dv)
    return _m.degrees(_m.acos(max(-1.0, min(1.0, c))))


def _interior(n):
    return Fraction(180) - Fraction(360, n)


# ================================================================ EASY

# ---------------------------------------------------------------- 001
def _c001():
    n = symbols('n', positive=True)
    N = solve(Eq(180 - Rational(360) / n, Rational(7, 2) * Rational(360) / n), n)[0]
    return N * (N - 3) / 2
q("C17-B-001", T, "Number of diagonals of a regular polygon from the ratio of interior to exterior angle", "Easy",
  "Multi-step word problem",
  r"Each interior angle of a regular polygon is to each of its exterior angles as $7 : 2$. How many diagonals does the polygon have?",
  "MCQ",
  r"Interior and exterior angles add to $180^\circ$, so the exterior angle is $\frac{2}{9} \times 180^\circ = 40^\circ$ and the polygon has $\frac{360}{40} = 9$ sides. The number of diagonals is $\frac{9 \times (9-3)}{2} = 27$.",
  "Counting all pairs of vertices (which includes the sides) or not halving $n(n-3)$.",
  "C17B-angle-ratio-to-sides", "Two short steps: exterior angle from the ratio, then the diagonal formula.",
  correct=r"$27$",
  distractors=[(r"$36$", "Counts all pairs of vertices $\\binom{9}{2} = 36$, which includes the $9$ sides."),
               (r"$54$", "Uses $n(n-3) = 54$ without dividing by $2$, so each diagonal is counted from both ends."),
               (r"$9$", "Reports the number of sides found in the first step.")],
  check=_c001, values=[27, 36, 54, 9], cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    n = symbols('n', positive=True, integer=True)
    N = [s for s in solve(Eq(n * (n - 3) / 2, 54), n) if s > 3][0]
    return 180 - Rational(360, N)
q("C17-B-002", T, "Interior angle of a regular polygon from its number of diagonals", "Easy",
  "Inverse/parameter",
  r"A regular polygon has exactly $54$ diagonals. What is the measure of each of its interior angles?",
  "MCQ",
  r"$\frac{n(n-3)}{2} = 54$ gives $n^2 - 3n - 108 = 0 = (n-12)(n+9)$, so $n = 12$. Each exterior angle is $\frac{360^\circ}{12} = 30^\circ$, so each interior angle is $180^\circ - 30^\circ = 150^\circ$.",
  "Dropping the factor $\\frac{1}{2}$ in the diagonal formula, using a wrong angle-sum formula, or reporting the exterior angle.",
  "C17B-diagonal-count-inverse", "One quadratic from the diagonal formula, then a standard angle step.",
  correct=r"$150^\circ$",
  distractors=[(r"$140^\circ$", "Solves $n(n-3) = 54$ without the half, getting $n = 9$ and interior angle $140^\\circ$."),
               (r"$30^\circ$", "Reports the exterior angle $\\frac{360^\\circ}{12}$."),
               (r"$165^\circ$", "Finds $n = 12$ but takes the angle sum as $(n-1) \\times 180^\\circ = 1980^\\circ$, giving $\\frac{1980^\\circ}{12} = 165^\\circ$.")],
  check=_c002, values=[150, 140, 30, 165], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    given = [120, 135, 140, 125, 130, 118]
    x = symbols('x')
    return solve(Eq(sum(given) + x, 180 * (7 - 2)), x)[0]
q("C17-B-003", T, "Missing interior angle of a convex heptagon from the angle sum", "Easy",
  "Single-step computation",
  r"A plot of land has the shape of a convex heptagon (seven sides). A surveyor measures six of its interior angles as $120^\circ$, $135^\circ$, $140^\circ$, $125^\circ$, $130^\circ$ and $118^\circ$. What is the measure, in degrees, of the seventh interior angle?",
  "TITA",
  r"The interior angles of a heptagon add to $(7-2) \times 180^\circ = 900^\circ$. The six measured angles add to $768^\circ$, so the seventh is $900^\circ - 768^\circ = 132^\circ$.",
  "Using $(n-1) \\times 180^\\circ$ or $n \\times 180^\\circ$ as the angle sum.",
  "C17B-angle-sum-missing", "A single application of the angle-sum formula.",
  tita_answer=132, check=_c003, cognitive="Recall",
  tita_traps=[(312, "Uses $(7-1) \\times 180^\\circ = 1080^\\circ$ as the angle sum."),
              (492, "Uses $7 \\times 180^\\circ = 1260^\\circ$ as the angle sum.")])

# ---------------------------------------------------------------- 004
def _c004():
    s = Rational(36, 6)
    return _area(_reg(6, s))  # circumradius of a regular hexagon equals its side
q("C17-B-004", T, "Area of a regular hexagon from its perimeter", "Easy",
  "Single-step computation",
  r"A garden is laid out in the shape of a regular hexagon whose boundary fence is $36$ m long in all. What is the area of the garden?",
  "MCQ",
  r"Each side is $\frac{36}{6} = 6$ m. A regular hexagon splits into $6$ equilateral triangles of side $6$ m, each of area $\frac{\sqrt{3}}{4} \times 36 = 9\sqrt{3}$, so the area is $6 \times 9\sqrt{3} = 54\sqrt{3}$ m$^2$.",
  "Treating the hexagon as three equilateral triangles, or using $\\frac{\\sqrt{3}}{2}$ for the area of an equilateral triangle.",
  "C17B-hexagon-area", "Direct use of the six-triangle decomposition.",
  correct=r"$54\sqrt{3}$ m$^2$",
  distractors=[(r"$9\sqrt{3}$ m$^2$", "Gives the area of only one of the six equilateral triangles."),
               (r"$108\sqrt{3}$ m$^2$", "Uses $\\frac{\\sqrt{3}}{2}s^2$ for each equilateral triangle: $6 \\times 18\\sqrt{3}$."),
               (r"$27\sqrt{3}$ m$^2$", "Splits the hexagon into only three equilateral triangles of side $6$ m.")],
  check=_c004, values=[54 * sqrt(3), 9 * sqrt(3), 108 * sqrt(3), 27 * sqrt(3)], cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    n = symbols('n', positive=True)
    N = solve(Eq(180 * (n - 2), 3240), n)[0]
    return Rational(360) / N
q("C17-B-005", T, "Exterior angle of a regular polygon from the sum of its interior angles", "Easy",
  "Inverse/parameter",
  r"The interior angles of a regular polygon add up to $3240^\circ$. What is the measure of each exterior angle of the polygon?",
  "MCQ",
  r"$(n-2) \times 180^\circ = 3240^\circ$ gives $n - 2 = 18$, so $n = 20$. Each exterior angle is $\frac{360^\circ}{20} = 18^\circ$.",
  "Taking $\\frac{3240}{180} = 18$ as the number of sides, or reporting the interior angle.",
  "C17B-angle-sum-missing", "Two quick steps; the trap is reading $18$ as the number of sides.",
  correct=r"$18^\circ$",
  distractors=[(r"$20^\circ$", "Takes $n = \\frac{3240}{180} = 18$ sides, giving $\\frac{360^\\circ}{18} = 20^\\circ$."),
               (r"$162^\circ$", "Reports the interior angle $180^\\circ - 18^\\circ$."),
               (r"$9^\circ$", "Finds $n = 20$ but divides $180^\\circ$ by $20$, using $180^\\circ$ as the sum of exterior angles.")],
  check=_c005, values=[18, 20, 162, 9], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    x = symbols('x', positive=True)
    X = solve(Eq(24 - 2 * x, x * sqrt(2)), x)[0]     # middle part of each square side equals the cut hypotenuse
    return simplify(X * sqrt(2))
_f = Fig()
_a = 24.0; _x = _a / (2 + _m.sqrt(2))
_S = [_f.pt("", 0, 0, dot=False), _f.pt("", _a, 0, dot=False), _f.pt("", _a, _a, dot=False), _f.pt("", 0, _a, dot=False)]
_f.poly(*_S, dashed=True)
_f.poly((_x, 0), (_a - _x, 0), (_a, _x), (_a, _a - _x), (_a - _x, _a), (_x, _a), (0, _a - _x), (0, _x))
_f.label_seg((0, 0), (_a, 0), "24 cm")
_alt = "A square of side 24 cm drawn dashed, with a regular octagon inside it formed by cutting off four equal isosceles right triangles at the corners."
q("C17-B-006", T, "Side of a regular octagon cut from a square sheet", "Easy",
  "Multi-step word problem",
  r"A carpenter cuts four equal isosceles right triangles off the corners of a square board of side $24$ cm, so that the remaining piece is a regular octagon. What is the length of each side of the octagon?",
  "MCQ",
  r"Let each cut triangle have legs $x$; its hypotenuse $x\sqrt{2}$ is a side of the octagon, and so is the middle part $24 - 2x$ of each side of the square. So $24 - 2x = x\sqrt{2}$, giving $x = \frac{24}{2+\sqrt{2}} = 24 - 12\sqrt{2}$, and the side is $x\sqrt{2} = 24\sqrt{2} - 24$ cm (about $9.94$ cm).",
  "Forgetting that each side of the square loses two cut legs, or reporting the leg of the cut triangle instead of its hypotenuse.",
  "C17B-cut-corners-regular", "One linear equation once the octagon side is equated to the cut hypotenuse.",
  correct=r"$(24\sqrt{2} - 24)$ cm",
  distractors=[(r"$(48 - 24\sqrt{2})$ cm", "Subtracts only one cut per side: $24 - x = x\\sqrt{2}$ with $x$ the leg, giving $x\\sqrt{2} = 48 - 24\\sqrt{2}$."),
               (r"$(24 - 12\sqrt{2})$ cm", "Reports the leg $x$ of the cut triangle, not its hypotenuse."),
               (r"$(12\sqrt{2} - 12)$ cm", "Splits only half the side, $12$ cm, in the regularity equation: $12 - 2x = x\\sqrt{2}$, giving $x\\sqrt{2} = 12\\sqrt{2} - 12$.")],
  check=_c006, values=[24 * sqrt(2) - 24, 48 - 24 * sqrt(2), 24 - 12 * sqrt(2), 12 * sqrt(2) - 12], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 007
def _c007():
    for n in range(3, 400):
        if _interior(3) + _interior(10) + _interior(n) == 360:
            return n
q("C17-B-007", T, "Third regular polygon completing the angle around a point", "Easy",
  "Inverse/parameter",
  r"Three tiles, each a regular polygon, are placed edge to edge around a point so that they fill the space around it exactly with no gap or overlap. One tile is an equilateral triangle and another is a regular decagon (ten sides). How many sides does the third tile have?",
  "TITA",
  r"The angles at the point add to $360^\circ$. The triangle gives $60^\circ$ and the decagon gives $180^\circ - 36^\circ = 144^\circ$, leaving $156^\circ$. A regular polygon with interior angle $156^\circ$ has exterior angle $24^\circ$, so it has $\frac{360}{24} = 15$ sides.",
  "Typing the interior angle $156$, or using the exterior angle of the decagon in place of its interior angle.",
  "C17B-tiles-around-point", "Angle sum at a point plus one inverse step.",
  tita_answer=15, check=_c007, cognitive="Application",
  tita_traps=[(156, "Types the interior angle of the third tile, not its number of sides."),
              (24, "Types the exterior angle $180^\\circ - 156^\\circ$ of the third tile.")])

# ---------------------------------------------------------------- 008
def _c008():
    V = _reg(6, 1)
    P, R, S = V[0], V[2], V[3]
    d = lambda a, b: sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)
    return simplify(d(P, R) / d(P, S))
_f = Fig()
_H = _fpts(6, 1.0, 180.0)
_L = "PQRSTU"
_hp = [_f.pt(_L[i], *_H[i]) for i in range(6)]
_f.poly(*_hp)
_f.seg(_hp[0], _hp[2], dashed=True); _f.seg(_hp[0], _hp[3], dashed=True)
_alt = "Regular hexagon PQRSTU with two dashed diagonals from P: one to R, which skips one vertex, and one to S, the opposite vertex."
q("C17-B-008", T, "Ratio of the shorter diagonal to the longer diagonal of a regular hexagon", "Easy",
  "Conceptual/application",
  r"$PQRSTU$ is a regular hexagon. What is the ratio of the length of diagonal $PR$ to the length of diagonal $PS$?",
  "MCQ",
  r"If the side is $a$, the long diagonal $PS$ passes through the centre and equals $2a$. In triangle $PQR$, $PQ = QR = a$ and $\angle PQR = 120^\circ$, so $PR = a\sqrt{3}$. The ratio is $a\sqrt{3} : 2a = \sqrt{3} : 2$.",
  "Comparing a side with a diagonal, or comparing squares of lengths.",
  "C17B-hexagon-diagonals", "Needs both diagonal lengths in terms of the side; one idea.",
  correct=r"$\sqrt{3} : 2$",
  distractors=[(r"$1 : 2$", "Compares the side $a$ with the long diagonal $2a$."),
               (r"$1 : \sqrt{3}$", "Compares the side $a$ with the short diagonal $a\\sqrt{3}$."),
               (r"$3 : 4$", "Compares the squares $3a^2$ and $4a^2$ and does not take square roots.")],
  check=_c008, values=[sqrt(3) / 2, Rational(1, 2), 1 / sqrt(3), Rational(3, 4)], cognitive="Understanding",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 009
def _c009():
    V = _fpts(9, 1.0, 110.0)           # P at 110 deg, then clockwise Q, R, ..., X
    P, Q, R, X = V[0], V[1], V[2], V[8]
    # line X->P extended beyond P, line R->Q extended beyond Q
    t, u = symbols('t u')
    sol = solve([Eq(P[0] + t * (P[0] - X[0]), Q[0] + u * (Q[0] - R[0])), Eq(P[1] + t * (P[1] - X[1]), Q[1] + u * (Q[1] - R[1]))], [t, u])
    Y = (P[0] + float(sol[t]) * (P[0] - X[0]), P[1] + float(sol[t]) * (P[1] - X[1]))
    assert float(sol[t]) > 0 and float(sol[u]) > 0
    return nsimplify(round(_ang((P[0] - Y[0], P[1] - Y[1]), (Q[0] - Y[0], Q[1] - Y[1])), 8))
_f = Fig()
_V = _fpts(9, 1.0, 110.0)
_L9 = "PQRSTUVWX"
_np = [_f.pt(_L9[i], *_V[i]) for i in range(9)]
_f.poly(*_np)
_k = 1.0 / (2 * _m.cos(_m.radians(40)))  # PY = PQ / (2 cos 40)
_side = _m.hypot(_V[1][0] - _V[0][0], _V[1][1] - _V[0][1])
_Yy = _V[0][1] + _side / 2 * _m.tan(_m.radians(40))
_Y = _f.pt("Y", 0.0, _Yy, offset=(0, 1))
_f.seg(_np[0], _Y, dashed=True); _f.seg(_np[1], _Y, dashed=True)
_alt = "Regular nonagon PQRSTUVWX with PQ at the top. Side XP is extended beyond P and side RQ is extended beyond Q; the two extensions meet at the point Y above PQ."
q("C17-B-009", T, "Angle formed where two extended sides of a regular nonagon meet", "Easy",
  "Conceptual/application",
  r"$PQRSTUVWX$ is a regular nonagon (nine sides). The sides $XP$ and $RQ$ are extended beyond $P$ and $Q$ respectively to meet at the point $Y$. What is the measure of $\angle PYQ$?",
  "MCQ",
  r"Each exterior angle of a regular nonagon is $\frac{360^\circ}{9} = 40^\circ$. Extending $XP$ beyond $P$ makes $\angle YPQ$ an exterior angle, so $\angle YPQ = 40^\circ$, and similarly $\angle YQP = 40^\circ$. Hence $\angle PYQ = 180^\circ - 80^\circ = 100^\circ$.",
  "Using the interior angle or the exterior angle itself as the answer.",
  "C17B-extended-sides-angle", "One observation: the base angles of triangle $PYQ$ are exterior angles.",
  correct=r"$100^\circ$",
  distractors=[(r"$140^\circ$", "Reports the interior angle of the nonagon."),
               (r"$40^\circ$", "Reports the exterior angle of the nonagon."),
               (r"$80^\circ$", "Adds the two base angles $40^\\circ + 40^\\circ$ and stops.")],
  check=_c009, values=[100, 140, 40, 80], cognitive="Understanding",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 010
def _c010():
    heading, pos, steps = 0, 0, 0
    while True:   # walk one side, turn 20 degrees, until heading returns to the start (first return to the corner)
        steps += 1
        heading = (heading + 20) % 360
        if heading == 0:
            break
    return steps * 50
q("C17-B-010", T, "Perimeter walked around a regular polygon from the turning angle at each corner", "Easy",
  "Multi-step word problem",
  r"Ravi walks along the boundary of a park shaped like a regular polygon, each side of which is $50$ m long. He starts at a corner, and at each corner he turns left through $20^\circ$ to walk along the next side. How many metres does he walk before he first returns to his starting corner?",
  "TITA",
  r"The turn at each corner is the exterior angle, and the exterior angles of any convex polygon add to $360^\circ$. So the polygon has $\frac{360}{20} = 18$ sides and one full round is $18 \times 50 = 900$ m.",
  "Treating the turning angle as the interior angle, or dividing $180^\\circ$ by the turn.",
  "C17B-exterior-angle-sum", "One idea: the turn is the exterior angle.",
  tita_answer=900, check=_c010, cognitive="Understanding",
  tita_traps=[(450, "Divides $180^\\circ$ by $20^\\circ$ to get $9$ sides."),
              (850, "Finds $18$ sides but counts only $17$ sides walked, a fencepost slip.")])

# ================================================================ MEDIUM

# ---------------------------------------------------------------- 011
def _c011():
    k = symbols('k', positive=True)
    K = solve(Eq((180 - Rational(360) / (3 * k)) - (180 - Rational(360) / (2 * k)), 10), k)[0]
    return 3 * K + 2 * K
q("C17-B-011", T, "Two regular polygons from the ratio of sides and the difference of interior angles", "Medium",
  "Inverse/parameter",
  r"The numbers of sides of two regular polygons are in the ratio $3 : 2$, and each interior angle of the first polygon is $10^\circ$ more than each interior angle of the second. What is the total number of sides of the two polygons?",
  "TITA",
  r"Let the polygons have $3k$ and $2k$ sides. The difference of interior angles equals the difference of exterior angles taken the other way: $\frac{360}{2k} - \frac{360}{3k} = \frac{60}{k} = 10$, so $k = 6$. The polygons have $18$ and $12$ sides (interior angles $160^\circ$ and $150^\circ$), a total of $30$.",
  "Using $180^\\circ$ for the sum of exterior angles, or reporting only one polygon.",
  "C17B-two-polygons-angle-gap", "Converting an interior-angle gap into an exterior-angle gap and solving for the scale factor.",
  tita_answer=30, check=_c011, cognitive="Application",
  tita_traps=[(15, "Uses $180$ for the exterior-angle sum: $\\frac{30}{k} = 10$, so $k = 3$ and sides $9$ and $6$."),
              (18, "Reports only the number of sides of the first polygon.")])

# ---------------------------------------------------------------- 012
def _c012():
    V = _reg(6, 1)
    t1 = [V[0], V[2], V[4]]; t2 = [V[1], V[3], V[5]]
    def X(a, b, c, d):
        return Line(Point(*a), Point(*b)).intersection(Line(Point(*c), Point(*d)))[0]
    star = []
    for i in range(6):   # tip i, then inner point between tip i and tip i+1
        star.append(V[i])
        a, b = V[(i - 1) % 6], V[(i + 1) % 6]
        c, d = V[i], V[(i + 2) % 6]
        p = X(a, b, c, d)
        star.append((p.x, p.y))
    ratio = _area(star) / _area(V)
    return simplify(180 * ratio)
_f = Fig()
_H = _fpts(6, 1.0, 180.0)
_hp = [_f.pt(_L[i], *_H[i]) for i in range(6)]
_f.poly(*_hp)
_f.poly(_hp[0], _hp[2], _hp[4]); _f.poly(_hp[1], _hp[3], _hp[5])
_alt = "Regular hexagon PQRSTU with triangles PRT and QSU drawn inside it; together the two triangles form a six-pointed star."
q("C17-B-012", T, "Area of the six-pointed star formed by the two triangles on alternate vertices of a regular hexagon", "Medium",
  "Conceptual/application",
  r"A regular hexagonal medallion $PQRSTU$ has area $180$ cm$^2$. The triangles $PRT$ and $QSU$ are engraved on it, forming a six-pointed star. What is the area of the star (the region covered by at least one of the two triangles)?",
  "MCQ",
  r"Triangle $PRT$ cuts off three corner triangles such as $PQR$, each $\frac{1}{6}$ of the hexagon, so $PRT$ is $\frac{1}{2}$ of it; the same holds for $QSU$. Their overlap is the inner hexagon, whose side is $\frac{1}{3}$ of $PR = s\sqrt{3}$, that is $\frac{s}{\sqrt{3}}$, so its area is $\frac{1}{3}$ of the hexagon. The star is $\frac{1}{2} + \frac{1}{2} - \frac{1}{3} = \frac{2}{3}$ of $180$, that is $120$ cm$^2$.",
  "Adding the two triangles without removing the overlap, or reporting one triangle or the overlap.",
  "C17B-hexagon-star", "Inclusion and exclusion with two area fractions (one half and one third) that must be known or derived.",
  correct=r"$120$ cm$^2$",
  distractors=[(r"$90$ cm$^2$", "Reports the area of one triangle, which is half the hexagon."),
               (r"$60$ cm$^2$", "Reports the inner hexagon where the triangles overlap, which is one third of the hexagon."),
               (r"$150$ cm$^2$", "Removes only three of the six corner pieces, each $\\frac{1}{18}$ of the hexagon: $180 \\times \\frac{5}{6}$.")],
  check=_c012, values=[120, 90, 60, 150], cognitive="Analysis",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 013
def _c013():
    x = symbols('x', positive=True)
    X = solve(Eq(30 - 2 * x, x * sqrt(2)), x)[0]
    return simplify(30**2 - 4 * X**2 / 2)
_f = Fig()
_a = 30.0; _x = _a / (2 + _m.sqrt(2))
_f.poly((0, 0), (_a, 0), (_a, _a), (0, _a), dashed=True)
_oct = [(_x, 0), (_a - _x, 0), (_a, _x), (_a, _a - _x), (_a - _x, _a), (_x, _a), (0, _a - _x), (0, _x)]
_f.shade(_oct); _f.poly(*_oct)
_f.label_seg((0, 0), (_a, 0), "30 cm")
_alt = "A square of side 30 cm drawn dashed, with a shaded regular octagon inside it obtained by cutting four equal isosceles right triangles off the corners."
q("C17-B-013", T, "Area of the regular octagon obtained by cutting the corners of a square", "Medium",
  "Multi-step word problem",
  r"Four equal isosceles right triangles are cut off the corners of a square tile of side $30$ cm so that the remaining piece is a regular octagon. What is the area of the octagon?",
  "MCQ",
  r"With legs $x$, the octagon side is $x\sqrt{2} = 30 - 2x$, so $x = \frac{30}{2 + \sqrt{2}} = 15(2 - \sqrt{2})$. The four triangles together have area $2x^2 = 450(6 - 4\sqrt{2}) = 900(3 - 2\sqrt{2})$. The octagon's area is $900 - 900(3 - 2\sqrt{2}) = 1800(\sqrt{2} - 1)$ cm$^2$, about $746$ cm$^2$.",
  "Subtracting only two corners, reporting the removed area, or dropping the factor $2$ in $2(1+\\sqrt{2})s^2$.",
  "C17B-cut-corners-regular", "Find the cut length from the regularity condition, then a surd subtraction.",
  correct=r"$1800(\sqrt{2} - 1)$ cm$^2$",
  distractors=[(r"$900(\sqrt{2} - 1)$ cm$^2$", "Uses $(1 + \\sqrt{2})s^2$ for the octagon, dropping the factor $2$ in $2(1+\\sqrt{2})s^2$."),
               (r"$900(3 - 2\sqrt{2})$ cm$^2$", "Reports the total area of the four triangles cut away."),
               (r"$450(2\sqrt{2} - 1)$ cm$^2$", "Subtracts only two of the four corner triangles: $900 - x^2$.")],
  check=_c013, values=[1800 * (sqrt(2) - 1), 900 * (sqrt(2) - 1), 900 * (3 - 2 * sqrt(2)), 450 * (2 * sqrt(2) - 1)],
  cognitive="Application", figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 014
def _c014():
    good = []
    for n in range(3, 200):
        angles = [100 + 10 * i for i in range(n)]
        if sum(angles) == 180 * (n - 2) and max(angles) < 180:
            good.append(n)
    assert len(good) == 1
    return good[0]
q("C17-B-014", T, "Number of sides of a convex polygon whose interior angles are in arithmetic progression", "Medium",
  "Casework/optimisation",
  r"The interior angles of a convex polygon are in arithmetic progression. The smallest angle is $100^\circ$ and the common difference is $10^\circ$. How many sides does the polygon have?",
  "TITA",
  r"With $n$ sides the angle sum is $\frac{n}{2}[200 + 10(n-1)] = 180(n-2)$, which simplifies to $n^2 - 17n + 72 = 0$, so $n = 8$ or $n = 9$. For $n = 9$ the largest angle would be $100^\circ + 80^\circ = 180^\circ$, impossible in a convex polygon. For $n = 8$ the largest angle is $170^\circ$. So $n = 8$.",
  "Accepting both roots or the larger root without checking convexity.",
  "C17B-angles-in-ap", "A quadratic with two roots where convexity rejects one.",
  tita_answer=8, check=_c014, cognitive="Analysis",
  tita_traps=[(9, "Takes the other root; then the largest angle is $180^\\circ$, impossible for a convex polygon."),
              (17, "Adds the two roots of $n^2 - 17n + 72 = 0$.")])

# ---------------------------------------------------------------- 015
def _c015():
    V = _fpts(9, 1.0, 90.0)
    P, R, U = V[0], V[2], V[5]
    return nsimplify(round(_ang((P[0] - R[0], P[1] - R[1]), (U[0] - R[0], U[1] - R[1])), 8))
_f = Fig()
_V = _fpts(9, 1.0, 90.0)
_np = [_f.pt(_L9[i], *_V[i]) for i in range(9)]
_f.poly(*_np)
_f.seg(_np[2], _np[0]); _f.seg(_np[2], _np[5])
_alt = "Regular nonagon PQRSTUVWX with the diagonals RP and RU drawn from the vertex R."
q("C17-B-015", T, "Angle between two diagonals from one vertex of a regular nonagon", "Medium",
  "Conceptual/application",
  r"$PQRSTUVWX$ is a regular nonagon. What is the measure of $\angle PRU$?",
  "MCQ",
  r"All vertices lie on a circle, and each side subtends $\frac{360^\circ}{9} = 40^\circ$ at the centre, so $20^\circ$ at any vertex on the remaining arc. $\angle PRU$ stands on the arc $P X W V U$ not containing $R$, which has $4$ sides. Hence $\angle PRU = 4 \times 20^\circ = 80^\circ$.",
  "Using the central angle instead of the angle at the circumference, or counting the wrong arc.",
  "C17B-inscribed-angle-polygon", "Needs the circumscribed circle and the inscribed angle theorem; arc counting is the trap.",
  correct=r"$80^\circ$",
  distractors=[(r"$100^\circ$", "Counts the arc $P Q R S T U$, which contains $R$: $5 \\times 20^\\circ$."),
               (r"$160^\circ$", "Uses the central angle $4 \\times 40^\\circ$ for the angle at $R$."),
               (r"$60^\circ$", "Counts the vertices strictly between $P$ and $U$ on the far arc ($X, W, V$), giving $3 \\times 20^\\circ$.")],
  check=_c015, values=[80, 100, 160, 60], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 016
def _c016():
    n = 20
    V = _fpts(n, 1.0, 0.0)
    cnt = 0
    for i, j in itertools.combinations(range(n), 2):
        if (j - i) % n in (1, n - 1):
            continue
        cross = V[i][0] * V[j][1] - V[i][1] * V[j][0]
        if abs(cross) > 1e-9:
            cnt += 1
    return cnt
q("C17-B-016", T, "Diagonals of a regular 20-gon that avoid the centre", "Medium",
  "Conceptual/application",
  r"A pavilion has a floor in the shape of a regular polygon with $20$ sides. A straight beam is to be laid along every diagonal of the floor, except that no beam may pass through the centre, where a pillar stands. How many beams are laid?",
  "MCQ",
  r"A regular $20$-gon has $\frac{20 \times 17}{2} = 170$ diagonals. A diagonal passes through the centre only if it joins opposite vertices, and the $20$ vertices form $10$ opposite pairs. So $170 - 10 = 160$ beams are laid.",
  "Counting $20$ diagonals through the centre, or counting pairs of vertices including sides.",
  "C17B-diagonals-through-centre", "Diagonal count combined with the idea that only the opposite-vertex diagonals pass through the centre.",
  correct=r"$160$",
  distractors=[(r"$170$", "Counts all diagonals without removing those through the centre."),
               (r"$150$", "Removes $20$ diagonals through the centre, counting each opposite pair twice."),
               (r"$180$", "Starts from $\\binom{20}{2} = 190$ pairs and removes only the $10$ diagonals through the centre, keeping the sides.")],
  check=_c016, values=[160, 170, 150, 180], cognitive="Understanding")

# ---------------------------------------------------------------- 017
def _c017():
    L = symbols('L', positive=True)
    c = L / 3                                       # regular hexagon: middle third of each side equals the cut
    tri = sqrt(3) / 4 * L**2
    hexa = tri - 3 * sqrt(3) / 4 * c**2
    Lv = solve(Eq(hexa, 96 * sqrt(3)), L)[0]
    return simplify(tri.subs(L, Lv))
q("C17-B-017", T, "Area of an equilateral triangular sheet from the regular hexagon left after cutting its corners", "Medium",
  "Multi-step word problem",
  r"Three equal equilateral triangles are cut off the corners of an equilateral triangular sheet so that the piece left is a regular hexagon of area $96\sqrt{3}$ cm$^2$. What was the area of the original sheet?",
  "MCQ",
  r"For the hexagon to be regular, each cut triangle has side equal to the hexagon's side $s$, so the sheet has side $3s$. In units of an equilateral triangle of side $s$, the sheet is $9$ units and the hexagon $6$ units. So the sheet's area is $96\sqrt{3} \times \frac{9}{6} = 144\sqrt{3}$ cm$^2$.",
  "Treating the hexagon as half the sheet, or using the side ratio instead of the area ratio.",
  "C17B-hexagon-from-triangle", "Needs the cut size from regularity and an area ratio $9 : 6$.",
  correct=r"$144\sqrt{3}$ cm$^2$",
  distractors=[(r"$192\sqrt{3}$ cm$^2$", "Assumes the hexagon is half of the sheet."),
               (r"$112\sqrt{3}$ cm$^2$", "Adds back only one corner triangle of area $16\\sqrt{3}$."),
               (r"$216\sqrt{3}$ cm$^2$", "Takes the hexagon's side as $\\frac{2}{3}$ of the sheet's side and scales the area by $\\frac{9}{4}$.")],
  check=_c017, values=[144 * sqrt(3), 192 * sqrt(3), 112 * sqrt(3), 216 * sqrt(3)], cognitive="Application")

# ---------------------------------------------------------------- 018
def _c018():
    H = _reg(6, 2)
    outer = []
    for i in range(6):
        a, b = H[i], H[(i + 1) % 6]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = sqrt(dx**2 + dy**2)
        nx, ny = dy / L, -dx / L                     # outward normal for an anticlockwise polygon
        outer.append((a[0] + 2 * nx, a[1] + 2 * ny)); outer.append((b[0] + 2 * nx, b[1] + 2 * ny))
    sides = {simplify(sqrt((outer[i][0] - outer[(i + 1) % 12][0])**2 + (outer[i][1] - outer[(i + 1) % 12][1])**2)) for i in range(12)}
    assert sides == {2}
    return simplify(_area(outer))
_f = Fig()
_H = _fpts(6, 2.0, 0.0, clockwise=False)
_f.poly(*_H)
_outer = []
for _i in range(6):
    _a, _b = _H[_i], _H[(_i + 1) % 6]
    _dx, _dy = _b[0] - _a[0], _b[1] - _a[1]; _Ln = _m.hypot(_dx, _dy)
    _n = (_dy / _Ln * 2, -_dx / _Ln * 2)
    _p1 = (_a[0] + _n[0], _a[1] + _n[1]); _p2 = (_b[0] + _n[0], _b[1] + _n[1])
    _f.poly(_a, _b, _p2, _p1)
    _outer += [_p1, _p2]
_f.poly(*_outer, dashed=True)
_f.label_seg(_H[4], _H[5], "2 cm")
_alt = "A regular hexagon of side 2 cm with a square drawn outward on each of its six sides. The twelve outer corners of the squares are joined by a dashed twelve-sided polygon."
q("C17-B-018", T, "Area of the dodecagon formed by squares erected on the sides of a regular hexagon", "Medium",
  "Multi-step word problem",
  r"On each side of a regular hexagon of side $2$ cm, a square is drawn outward. The $12$ outer corners of the six squares are joined in order to form a $12$-sided polygon. What is the area of this $12$-sided polygon?",
  "MCQ",
  r"The polygon consists of the hexagon, the six squares and six gap triangles between adjacent squares. At each hexagon vertex the gap angle is $360^\circ - 90^\circ - 90^\circ - 120^\circ = 60^\circ$, and its two sides are $2$ cm, so each gap triangle is equilateral with area $\sqrt{3}$. Total area $= 6\sqrt{3} + 6 \times 4 + 6\sqrt{3} = 24 + 12\sqrt{3}$ cm$^2$.",
  "Missing the six gap triangles or taking their angle to be $90^\\circ$.",
  "C17B-squares-on-hexagon", "Three pieces to identify, including the $60^\\circ$ gap angle.",
  correct=r"$(24 + 12\sqrt{3})$ cm$^2$",
  distractors=[(r"$(24 + 6\sqrt{3})$ cm$^2$", "Adds the hexagon and the squares but misses the six gap triangles."),
               (r"$(36 + 6\sqrt{3})$ cm$^2$", "Takes each gap triangle as right-angled isosceles with area $2$, adding $12$ in place of $6\\sqrt{3}$."),
               (r"$(24 + 18\sqrt{3})$ cm$^2$", "Uses $\\frac{\\sqrt{3}}{2}s^2$ for each gap triangle, giving $2\\sqrt{3}$ each.")],
  check=_c018, values=[24 + 12 * sqrt(3), 24 + 6 * sqrt(3), 36 + 6 * sqrt(3), 24 + 18 * sqrt(3)], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 019
def _c019():
    a = 4 + 4 * sqrt(2); x = 2 * sqrt(2)
    P, Q, Rv, S, Tv, U = (x, a), (a - x, a), (a, a - x), (a, x), (a - x, 0), (x, 0)
    oct8 = [P, Q, Rv, S, Tv, U, (0, x), (0, a - x)]
    sides = {simplify(sqrt((oct8[i][0] - oct8[(i + 1) % 8][0])**2 + (oct8[i][1] - oct8[(i + 1) % 8][1])**2)) for i in range(8)}
    assert sides == {4}
    return simplify(_area([P, Q, Tv, U]))
_f = Fig()
_a = 4 + 4 * _m.sqrt(2); _x = 2 * _m.sqrt(2)
_O = [(_x, _a), (_a - _x, _a), (_a, _a - _x), (_a, _x), (_a - _x, 0), (_x, 0), (0, _x), (0, _a - _x)]
_L8 = "PQRSTUVW"
_op = [_f.pt(_L8[i], *_O[i]) for i in range(8)]
_f.poly(*_op)
_f.seg(_op[1], _op[4], dashed=True); _f.seg(_op[0], _op[5], dashed=True)
_f.label_seg(_op[0], _op[1], "4 cm")
_alt = "Regular octagon PQRSTUVW with side PQ of 4 cm at the top and side TU at the bottom. Dashed segments QT and PU complete the quadrilateral PQTU."
q("C17-B-019", T, "Area of the rectangle formed by two opposite sides of a regular octagon", "Medium",
  "Multi-step word problem",
  r"$PQRSTUVW$ is a regular octagon of side $4$ cm. What is the area of the quadrilateral $PQTU$?",
  "MCQ",
  r"$PQ$ and $TU$ are opposite, parallel sides, and $PQTU$ is a rectangle with $PQ = 4$. Its other side equals the distance between the two parallel sides. Going from $Q$ down to $T$ passes the side $RS$ of length $4$ and two slanted sides each with vertical drop $\frac{4}{\sqrt{2}} = 2\sqrt{2}$, so $QT = 4 + 4\sqrt{2}$. The area is $4(4 + 4\sqrt{2}) = 16 + 16\sqrt{2}$ cm$^2$.",
  "Taking the height as $4\\sqrt{2}$ or including only one slanted side, or reporting the octagon's area.",
  "C17B-octagon-width", "Needs the width of the octagon across opposite sides, built from one straight side and two $45^\\circ$ sides.",
  correct=r"$(16 + 16\sqrt{2})$ cm$^2$",
  distractors=[(r"$(16 + 8\sqrt{2})$ cm$^2$", "Includes only one slanted side's drop: height $4 + 2\\sqrt{2}$."),
               (r"$16\sqrt{2}$ cm$^2$", "Takes the height as $4\\sqrt{2}$, the diagonal of a square on the side."),
               (r"$(32 + 32\sqrt{2})$ cm$^2$", "Reports the area $2(1+\\sqrt{2}) \\times 16$ of the whole octagon.")],
  check=_c019, values=[16 + 16 * sqrt(2), 16 + 8 * sqrt(2), 16 * sqrt(2), 32 + 32 * sqrt(2)], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 020
def _c020():
    return sum(1 for n in range(11, 1000) if _interior(n).denominator == 1)
q("C17-B-020", T, "Count of regular polygons with more than ten sides whose interior angle is a whole number of degrees", "Medium",
  "Casework/optimisation",
  r"How many regular polygons with more than $10$ sides have each interior angle equal to a whole number of degrees?",
  "MCQ",
  r"The interior angle $180^\circ - \frac{360^\circ}{n}$ is a whole number exactly when $n$ divides $360$. The divisors of $360$ greater than $10$ are $12, 15, 18, 20, 24, 30, 36, 40, 45, 60, 72, 90, 120, 180, 360$, which is $15$ values. So there are $15$ such polygons.",
  "Including $n = 10$, or counting all divisors of $360$ that are at least $3$.",
  "C17B-integer-angle-count", "Reduces to listing divisors of $360$ above a bound.",
  correct=r"$15$",
  distractors=[(r"$16$", "Includes $n = 10$, reading more than $10$ as at least $10$."),
               (r"$22$", "Counts all divisors of $360$ that are at least $3$, ignoring the bound."),
               (r"$24$", "Counts all $24$ divisors of $360$, including $1$ and $2$ and ignoring the bound.")],
  check=_c020, values=[15, 16, 22, 24], cognitive="Analysis")

# ---------------------------------------------------------------- 021
def _c021():
    ms = set()
    for n in range(3, 200):
        for m in range(3, 200):
            if _interior(n) + 2 * _interior(m) == 360:
                ms.add(m)
    return sum(ms)
q("C17-B-021", T, "All ways a regular polygon and two congruent regular polygons can fill the angle at a point", "Difficult",
  "Casework/optimisation",
  r"Three tiles, each a regular polygon, meet at a point and fill the space around it exactly. Two of the tiles are congruent regular polygons with $m$ sides each, and the third has $n$ sides, where $n$ may or may not equal $m$. What is the sum of all possible values of $m$?",
  "TITA",
  r"The condition is $\left(180 - \frac{360}{n}\right) + 2\left(180 - \frac{360}{m}\right) = 360$, that is $\frac{1}{n} + \frac{2}{m} = \frac{1}{2}$. Trying $m = 5, 6, 7, \ldots$: $m = 5$ gives $n = 10$; $m = 6$ gives $n = 6$; $m = 8$ gives $n = 4$; $m = 12$ gives $n = 3$; every other $m$ makes $n$ a non-integer or less than $3$. The sum is $5 + 6 + 8 + 12 = 31$.",
  "Assuming the single tile has fewer sides than the pair, missing $m = 5$ and $m = 6$.",
  "C17B-tiles-around-point", "Diophantine casework on a reciprocal equation over all values of $m$, with a non-obvious case ($m = 5$, $n = 10$) that most solvers miss; about $3$ minutes.",
  tita_answer=31, check=_c021, cognitive="Analysis", exams=CX,
  tita_traps=[(20, "Keeps only cases where the third tile has fewer sides: $8 + 12$."),
              (26, "Misses $m = 5$, $n = 10$, assuming the pair can never have fewer sides than the single tile.")])

# ---------------------------------------------------------------- 022
def _c022():
    return _area(_reg(12, 10))
_f = Fig()
_D = _fpts(12, 10.0, 90.0)
_f.circle((0, 0), 10.0, dashed=True)
_f.poly(*_D)
_Oc = _f.pt("O", 0, 0, offset=(0, -1))
_f.seg(_Oc, _D[0]); _f.label_seg((0, 0), _D[0], "10 m")
_alt = "A regular twelve-sided polygon inscribed in a dashed circle with centre O; a radius of 10 m is drawn from O to one vertex."
q("C17-B-022", T, "Area of a regular dodecagon from its circumradius", "Medium",
  "Conceptual/application",
  r"The floor of a bandstand is a regular $12$-sided polygon whose vertices lie on a circle of radius $10$ m. What is the area of the floor, in m$^2$?",
  "TITA",
  r"Joining the centre to all vertices gives $12$ isosceles triangles with two sides $10$ m and included angle $30^\circ$. Each has area $\frac{1}{2} \times 10 \times 10 \times \sin 30^\circ = 25$, so the floor's area is $12 \times 25 = 300$ m$^2$. (In general a regular dodecagon has area $3r^2$.)",
  "Using the circle's area, or dropping the half in the triangle area formula.",
  "C17B-area-from-circumradius", "Requires splitting into central triangles and using $\\sin 30^\\circ$; neat closed form $3r^2$.",
  tita_answer=300, check=_c022, cognitive="Application",
  tita_traps=[(600, "Drops the $\\frac{1}{2}$ in $\\frac{1}{2}ab\\sin C$."),
              (314, "Uses the area of the circle, $\\pi r^2 \\approx 314$.")],
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 023
def _c023():
    for n in range(4, 200):
        ext = [180 - 120] * 3 + [180 - 165] * (n - 3)
        if sum(ext) == 360:
            return n
q("C17-B-023", T, "Number of sides of a convex polygon with two kinds of interior angle", "Medium",
  "Inverse/parameter",
  r"A convex polygon has exactly three interior angles of $120^\circ$ each, and every other interior angle measures $165^\circ$. How many sides does the polygon have?",
  "TITA",
  r"Use exterior angles, which add to $360^\circ$. The three $120^\circ$ angles have exterior angles of $60^\circ$ each, a total of $180^\circ$. The remaining $180^\circ$ is shared among exterior angles of $15^\circ$, so there are $12$ such angles. The polygon has $3 + 12 = 15$ sides.",
  "Reporting only the number of $165^\\circ$ angles, or forgetting the three special angles in the exterior sum.",
  "C17B-exterior-angle-sum", "Two kinds of angle; the exterior-angle route avoids a longer equation.",
  tita_answer=15, check=_c023, cognitive="Application",
  tita_traps=[(12, "Reports only the count of $165^\\circ$ angles."),
              (24, "Ignores the three $120^\\circ$ angles and divides $360^\\circ$ by $15^\\circ$.")])

# ---------------------------------------------------------------- 024
def _c024():
    return _area(_reg(8, 10))
q("C17-B-024", T, "Area of a regular octagon inscribed in a circle", "Medium",
  "Multi-step word problem",
  r"A regular octagonal fountain basin is built so that all eight of its corners lie on a circle of diameter $20$ m. What is the area of the basin?",
  "MCQ",
  r"The radius is $10$ m. Joining the centre to the corners gives $8$ isosceles triangles with two sides $10$ m and included angle $45^\circ$, each of area $\frac{1}{2} \times 100 \times \frac{\sqrt{2}}{2} = 25\sqrt{2}$. The area is $8 \times 25\sqrt{2} = 200\sqrt{2}$ m$^2$.",
  "Using the diameter as the radius, dropping the half, or using the side-based formula with the radius as the side.",
  "C17B-area-from-circumradius", "Central triangle decomposition after converting diameter to radius.",
  correct=r"$200\sqrt{2}$ m$^2$",
  distractors=[(r"$800\sqrt{2}$ m$^2$", "Uses the diameter $20$ m as the radius."),
               (r"$400\sqrt{2}$ m$^2$", "Drops the $\\frac{1}{2}$ in $\\frac{1}{2}ab\\sin C$."),
               (r"$200(1 + \sqrt{2})$ m$^2$", "Uses the octagon formula $2(1+\\sqrt{2})s^2$ with the radius $10$ m taken as the side.")],
  check=_c024, values=[200 * sqrt(2), 800 * sqrt(2), 400 * sqrt(2), 200 * (1 + sqrt(2))], cognitive="Application")

# ---------------------------------------------------------------- 025
def _c025():
    V = _reg(6, 1, pi)       # P at angle 180 deg, anticlockwise naming
    V = [V[0]] + V[1:][::-1]  # make P, Q, R, ... go clockwise
    P, R, S, Tv = V[0], V[2], V[3], V[4]
    M = ((S[0] + Tv[0]) / 2, (S[1] + Tv[1]) / 2)
    return simplify(120 * _area([P, R, M]) / _area(V))
_f = Fig()
_H = _fpts(6, 1.0, 180.0)
_hp = [_f.pt(_L[i], *_H[i]) for i in range(6)]
_f.poly(*_hp)
_Mx = ((_H[3][0] + _H[4][0]) / 2, (_H[3][1] + _H[4][1]) / 2)
_Mp = _f.pt("M", *_Mx)
_f.shade([_hp[0], _hp[2], _Mp]); _f.poly(_hp[0], _hp[2], _Mp)
_alt = "Regular hexagon PQRSTU with M the midpoint of side ST. The shaded triangle PRM is drawn inside the hexagon."
q("C17-B-025", T, "Area of a triangle with two hexagon vertices and the midpoint of a side", "Medium",
  "Conceptual/application",
  r"$PQRSTU$ is a regular hexagon of area $120$ cm$^2$, and $M$ is the midpoint of side $ST$. What is the area of triangle $PRM$?",
  "MCQ",
  r"All triangles on base $PR$ have area proportional to the height from the apex. Triangle $PRS$ is $\frac{1}{3}$ of the hexagon ($40$) and triangle $PRT$ is $\frac{1}{2}$ of it ($60$). As $M$ is the midpoint of $ST$, its distance from line $PR$ is the average of those of $S$ and $T$, so the area is $\frac{40 + 60}{2} = 50$ cm$^2$.",
  "Using a vertex in place of the midpoint, or halving triangle $PRT$.",
  "C17B-hexagon-region-fraction", "Recognising that area varies linearly as the apex moves along $ST$.",
  correct=r"$50$ cm$^2$",
  distractors=[(r"$60$ cm$^2$", "Uses vertex $T$, giving triangle $PRT$, half the hexagon."),
               (r"$40$ cm$^2$", "Uses vertex $S$, giving triangle $PRS$, a third of the hexagon."),
               (r"$30$ cm$^2$", "Assumes moving the apex from $T$ to the midpoint of $ST$ halves the area of $PRT$.")],
  check=_c025, values=[50, 60, 40, 30], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 026
def _c026():
    s = symbols('s', positive=True)
    S = solve(Eq(2 * (sqrt(3) / 2 * s), 12), s)[0]      # across flats = twice the apothem
    return simplify(_area(_reg(6, S)))
q("C17-B-026", T, "Area of a regular hexagon from the distance between opposite sides", "Medium",
  "Multi-step word problem",
  r"The face of a hexagonal nut is a regular hexagon, and the distance between two opposite parallel sides of the face is $12$ mm. What is the area of the face?",
  "MCQ",
  r"The distance between opposite sides is twice the height of one of the six equilateral triangles, so $2 \times \frac{\sqrt{3}}{2}s = 12$ and $s = 4\sqrt{3}$ mm. The area is $\frac{3\sqrt{3}}{2}s^2 = \frac{3\sqrt{3}}{2} \times 48 = 72\sqrt{3}$ mm$^2$.",
  "Taking the distance across flats as the side or as twice the side.",
  "C17B-hexagon-area", "The width must first be converted to the side via the apothem.",
  correct=r"$72\sqrt{3}$ mm$^2$",
  distractors=[(r"$54\sqrt{3}$ mm$^2$", "Treats $12$ mm as the distance between opposite vertices, so $s = 6$."),
               (r"$216\sqrt{3}$ mm$^2$", "Takes the side itself as $12$ mm."),
               (r"$36\sqrt{3}$ mm$^2$", "Finds $s = 4\\sqrt{3}$ but counts only three equilateral triangles.")],
  check=_c026, values=[72 * sqrt(3), 54 * sqrt(3), 216 * sqrt(3), 36 * sqrt(3)], cognitive="Application")

# ================================================================ DIFFICULT

# ---------------------------------------------------------------- 027
def _c027():
    V = _fpts(15, 1.0, 90.0)
    v = lambda i: V[i - 1]
    a, b, c, d = v(1), v(6), v(3), v(10)
    # confirm the chords cross inside
    t, u = symbols('t u')
    sol = solve([Eq(a[0] + t * (b[0] - a[0]), c[0] + u * (d[0] - c[0])), Eq(a[1] + t * (b[1] - a[1]), c[1] + u * (d[1] - c[1]))], [t, u])
    assert 0 < float(sol[t]) < 1 and 0 < float(sol[u]) < 1
    th = _ang((b[0] - a[0], b[1] - a[1]), (d[0] - c[0], d[1] - c[1]))
    return nsimplify(round(min(th, 180 - th), 8))
q("C17-B-027", T, "Acute angle between two crossing diagonals of a regular 15-gon", "Difficult",
  "Conceptual/application",
  r"The vertices of a regular polygon with $15$ sides are labelled $V_1, V_2, \ldots, V_{15}$ in order. The diagonals $V_1V_6$ and $V_3V_{10}$ cross each other. What is the acute angle between them?",
  "MCQ",
  r"Place the vertices on the circumcircle; each side subtends $24^\circ$ at the centre. When two chords cross inside a circle, each angle between them is half the sum of the arcs it and its vertical angle intercept. One pair of vertical angles faces arcs $V_1V_3$ ($2$ sides, $48^\circ$) and $V_6V_{10}$ ($4$ sides, $96^\circ$), giving $\frac{48^\circ + 96^\circ}{2} = 72^\circ$. The other angle is $108^\circ$, so the acute angle is $72^\circ$.",
  "Using a single arc, using the difference of arcs (the rule for secants meeting outside), or using half the central angle per side before halving again.",
  "C17B-inscribed-angle-polygon", "Needs the crossing-chords angle theorem applied to a regular polygon with careful arc counting.",
  correct=r"$72^\circ$",
  distractors=[(r"$48^\circ$", "Uses only the arc $V_6V_{10}$: $\\frac{96^\\circ}{2}$."),
               (r"$24^\circ$", "Uses half the difference of the arcs, $\\frac{96^\\circ - 48^\\circ}{2}$, the rule for lines meeting outside the circle."),
               (r"$36^\circ$", "Takes $12^\\circ$ per side as the central angle and then halves the sum: $\\frac{(2 + 4) \\times 12^\\circ}{2}$.")],
  check=_c027, values=[72, 48, 24, 36], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 028
def _c028():
    dirs = [(cos(k * pi / 3), sin(k * pi / 3)) for k in range(6)]
    given = [2, 6, 4, 6, 2]
    x = symbols('x')
    sides = given + [x]
    ex = sum(sides[k] * dirs[k][0] for k in range(6)); ey = sum(sides[k] * dirs[k][1] for k in range(6))
    X = solve(ex, x)[0]
    assert simplify(ey.subs(x, X)) == 0
    sides = given + [X]
    pts = [(0, 0)]
    for k in range(5):
        pts.append((pts[-1][0] + sides[k] * dirs[k][0], pts[-1][1] + sides[k] * dirs[k][1]))
    return simplify(_area(pts))
_f = Fig()
_sd = [2, 6, 4, 6, 2, 8]
_pt = [(0.0, 0.0)]
for _k in range(5):
    _pt.append((_pt[-1][0] + _sd[_k] * _m.cos(_m.radians(60 * _k)), _pt[-1][1] + _sd[_k] * _m.sin(_m.radians(60 * _k))))
_Lh = "PQRSTU"
_qp = [_f.pt(_Lh[i], *_pt[i]) for i in range(6)]
_f.poly(*_qp)
for _k, _t in enumerate(["2", "6", "4", "6", "2"]):
    _f.label_seg(_qp[_k], _qp[_k + 1], _t)
_alt = "Hexagon PQRSTU with all interior angles equal, and sides PQ = 2, QR = 6, RS = 4, ST = 6 and TU = 2 marked; side UP is not marked."
q("C17-B-028", T, "Area of an equiangular hexagon with unequal sides", "Difficult",
  "Multi-step word problem",
  r"In hexagon $PQRSTU$ every interior angle is $120^\circ$, and $PQ = 2$, $QR = 6$, $RS = 4$, $ST = 6$ and $TU = 2$ (all in cm). What is the area of the hexagon?",
  "MCQ",
  r"Extend sides $PQ$, $RS$ and $TU$; they meet to form an equilateral triangle, because every corner cut off is an equilateral triangle (its angles are $180^\circ - 120^\circ = 60^\circ$). The cut corners are equilateral triangles on $QR$, $ST$ and $UP$, so the side of the big triangle lying along $RS$ is $QR + RS + ST = 6 + 4 + 6 = 16$. The side along $PQ$ is also $16$: $UP + PQ + QR = 16$ gives $UP = 8$. Area $= \frac{\sqrt{3}}{4}(16^2 - 6^2 - 6^2 - 8^2) = \frac{\sqrt{3}}{4} \times 120 = 30\sqrt{3}$ cm$^2$.",
  "Not cutting the corners from the big triangle, or subtracting the wrong set of corner triangles.",
  "C17B-equiangular-hexagon", "Requires the extend-to-a-triangle construction, solving for the sixth side, and pairing the correct corners with the correct triangle.",
  correct=r"$30\sqrt{3}$ cm$^2$",
  distractors=[(r"$64\sqrt{3}$ cm$^2$", "Reports the area $\\frac{\\sqrt{3}}{4} \\times 16^2$ of the big triangle without removing the corners."),
               (r"$58\sqrt{3}$ cm$^2$", "Subtracts the corners on $PQ$, $RS$, $TU$ ($2, 4, 2$) from the triangle of side $16$: $\\frac{\\sqrt{3}}{4}(256 - 24)$."),
               (r"$42\sqrt{3}$ cm$^2$", "Assumes $UP$ equals its opposite side $RS = 4$ and subtracts corners $6, 6, 4$: $\\frac{\\sqrt{3}}{4}(256 - 88)$.")],
  check=_c028, values=[30 * sqrt(3), 64 * sqrt(3), 58 * sqrt(3), 42 * sqrt(3)], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 029
def _c029():
    res = set()
    for n in range(3, 18):
        m = 20 - n
        if m >= 3 and n * (n - 3) // 2 + m * (m - 3) // 2 == 79:
            res.add(abs(n - m))
    assert len(res) == 1
    return res.pop()
q("C17-B-029", T, "Two polygons from the total of their sides and the total of their diagonals", "Medium",
  "Inverse/parameter",
  r"Two convex polygons together have $20$ sides and together have $79$ diagonals. What is the positive difference between their numbers of sides?",
  "TITA",
  r"With $n + m = 20$: $\frac{n(n-3)}{2} + \frac{m(m-3)}{2} = 79$ gives $n^2 + m^2 - 3(n+m) = 158$, so $n^2 + m^2 = 218$. Then $2nm = 400 - 218 = 182$, $nm = 91$, and $(n - m)^2 = 218 - 182 = 36$. The difference is $6$ (the polygons have $13$ and $7$ sides).",
  "Stopping at one polygon's number of sides, or mishandling the $-3(n+m)$ term.",
  "C17B-diagonal-system", "Two equations in two unknowns from the diagonal formula, solved by a sum-and-product step; about $2$ minutes.",
  tita_answer=6, check=_c029, cognitive="Analysis", exams=CX,
  tita_traps=[(13, "Reports the larger polygon's number of sides."),
              (7, "Reports the smaller polygon's number of sides.")])

# ---------------------------------------------------------------- 030
def _c030():
    pairs = set()
    for n in range(3, 2000):
        for m in range(3, 60):
            if _interior(n) * 3 == _interior(m) * 4:
                pairs.add((n, m))
    return len(pairs)
q("C17-B-030", T, "Pairs of regular polygons whose interior angles are in a given ratio", "Difficult",
  "Casework/optimisation",
  r"For how many pairs of regular polygons is each interior angle of the first polygon to each interior angle of the second as $4 : 3$? (Polygons are distinguished only by their numbers of sides.)",
  "TITA",
  r"With $n$ and $m$ sides: $3 \cdot \frac{(n-2)180}{n} = 4 \cdot \frac{(m-2)180}{m}$ gives $3m(n-2) = 4n(m-2)$, so $m(n+6) = 8n$ and $m = 8 - \frac{48}{n+6}$. We need $m \ge 3$, so $\frac{48}{n+6} \le 5$, and $n + 6$ must divide $48$: $n + 6 \in \{12, 16, 24, 48\}$. This gives $(n, m) = (6, 4), (10, 5), (18, 6), (42, 7)$, so there are $4$ pairs.",
  "Allowing $n + 6 = 8$, which gives a polygon with $2$ sides, or missing the large divisor $48$.",
  "C17B-angle-ratio-pairs", "Rearranging into a divisor condition and checking the lower bound on sides.",
  tita_answer=4, check=_c030, cognitive="Analysis", exams=CX,
  tita_traps=[(5, "Also counts $n + 6 = 8$, which gives $n = 2$ and $m = 2$, not polygons."),
              (3, "Misses $n + 6 = 48$, the pair $(42, 7)$.")])

# ---------------------------------------------------------------- 031
def _c031():
    # cut an isosceles triangle with legs x and apex 120 deg at every corner of a regular hexagon of side 6;
    # regularity: middle part 6 - 2x equals the base x*sqrt(3); then area by shoelace on the 12 vertices
    x = symbols('x', positive=True)
    X = solve(Eq(6 - 2 * x, x * sqrt(3)), x)[0]
    H = _reg(6, 6)
    D = []
    for i in range(6):
        a, b = H[i], H[(i + 1) % 6]
        u = ((b[0] - a[0]) / 6, (b[1] - a[1]) / 6)
        D += [(a[0] + u[0] * X, a[1] + u[1] * X), (b[0] - u[0] * X, b[1] - u[1] * X)]
    sides = {nsimplify(simplify(sqrt((D[i][0] - D[(i + 1) % 12][0])**2 + (D[i][1] - D[(i + 1) % 12][1])**2))) for i in range(12)}
    assert len(sides) == 1
    return simplify(_area(D))
_f = Fig()
_H = _fpts(6, 6.0, 0.0, clockwise=False)
_f.poly(*_H, dashed=True)
_xx = 6.0 / (2 + _m.sqrt(3))
_dd = []
for _i in range(6):
    _a, _b = _H[_i], _H[(_i + 1) % 6]
    _u = ((_b[0] - _a[0]) / 6.0, (_b[1] - _a[1]) / 6.0)
    _dd += [(_a[0] + _u[0] * _xx, _a[1] + _u[1] * _xx), (_b[0] - _u[0] * _xx, _b[1] - _u[1] * _xx)]
_f.poly(*_dd)
_f.label_seg(_H[4], _H[5], "6 cm")
_alt = "A regular hexagon of side 6 cm drawn dashed, with a regular twelve-sided polygon inside it obtained by cutting a small isosceles triangle off each of the six corners."
q("C17-B-031", T, "Area of the regular dodecagon obtained by cutting the corners of a regular hexagon", "Difficult",
  "Multi-step word problem",
  r"Six equal isosceles triangles are cut off the corners of a regular hexagonal sheet of side $6$ cm so that the remaining piece is a regular $12$-sided polygon. What is the area of the $12$-sided polygon?",
  "MCQ",
  r"Each cut triangle has its apex at a hexagon vertex, so its apex angle is $120^\circ$; with equal legs $x$, its base is $x\sqrt{3}$, and this base is a side of the new polygon. The middle part of each hexagon side, $6 - 2x$, is also a side, so $6 - 2x = x\sqrt{3}$ and $x = \frac{6}{2 + \sqrt{3}} = 6(2 - \sqrt{3})$, giving $x^2 = 36(7 - 4\sqrt{3})$. Each cut triangle has area $\frac{1}{2}x^2 \sin 120^\circ = \frac{\sqrt{3}}{4}x^2$, so the six together remove $\frac{3\sqrt{3}}{2} \times 36(7 - 4\sqrt{3}) = 378\sqrt{3} - 648$. The hexagon has area $\frac{3\sqrt{3}}{2} \times 36 = 54\sqrt{3}$, so the polygon has area $54\sqrt{3} - 378\sqrt{3} + 648 = 324(2 - \sqrt{3})$ cm$^2$ (about $86.8$ cm$^2$).",
  "Carrying over the right-angled corner from the octagon case, or reusing the dodecagon formula $3r^2$ with the side in place of the circumradius.",
  "C17B-cut-corners-regular", "Needs the $120^\\circ$ apex, the base $x\\sqrt{3}$, surd rationalisation and a $\\sin 120^\\circ$ area step with surd squaring; the octagon analogy is a strong trap.",
  correct=r"$324(2 - \sqrt{3})$ cm$^2$",
  distractors=[(r"$54(9\sqrt{3} - 14)$ cm$^2$", "Finds $x$ correctly but takes each cut triangle as right-angled, area $\\frac{1}{2}x^2$, as in the octagon case: $54\\sqrt{3} - 3 \\times 36(7 - 4\\sqrt{3})$."),
               (r"$54(7\sqrt{3} - 12)$ cm$^2$", "Reports the total area of the six triangles cut away."),
               (r"$324(7 - 4\sqrt{3})$ cm$^2$", "Finds the side $d = 12\\sqrt{3} - 18$ and uses $3d^2$, the dodecagon formula $3r^2$, with the side in place of the circumradius.")],
  check=_c031, values=[324 * (2 - sqrt(3)), 54 * (9 * sqrt(3) - 14), 54 * (7 * sqrt(3) - 12), 324 * (7 - 4 * sqrt(3))], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 032
def _c032():
    found = set()
    for n in range(6, 200):
        V = _fpts(n, 1.0, 90.0)
        a, b, c, d = V[0], V[3], V[1], V[5]
        th = _ang((b[0] - a[0], b[1] - a[1]), (d[0] - c[0], d[1] - c[1]))
        if abs(th - 135) < 1e-7 or abs((180 - th) - 135) < 1e-7:
            found.add(n)
    assert len(found) == 1
    return found.pop()
q("C17-B-032", T, "Number of sides of a regular polygon from the angle between two crossing diagonals", "Difficult",
  "Casework/optimisation",
  r"In a regular polygon $P_1P_2P_3 \ldots P_n$, the diagonals $P_1P_4$ and $P_2P_6$ cross each other, and one of the angles between them is $135^\circ$. What is the value of $n$?",
  "TITA",
  r"On the circumcircle each side subtends $\frac{360^\circ}{n}$ at the centre. The angle between the crossing chords that faces arcs $P_1P_2$ ($1$ side) and $P_4P_6$ ($2$ sides) is $\frac{1}{2} \times \frac{3 \times 360^\circ}{n} = \frac{540^\circ}{n}$, and the other angle is $180^\circ - \frac{540^\circ}{n}$. If $\frac{540}{n} = 135$ then $n = 4$, impossible since $P_6$ exists. So $180 - \frac{540}{n} = 135$, $\frac{540}{n} = 45$, $n = 12$.",
  "Setting the half-sum of arcs equal to $135^\\circ$ without checking which angle it gives.",
  "C17B-inscribed-angle-polygon", "Two cases for which angle is $135^\\circ$; one is rejected because the polygon must have at least $6$ vertices.",
  tita_answer=12, check=_c032, cognitive="Analysis", exams=CX,
  tita_traps=[(4, "Sets $\\frac{540}{n} = 135$; a polygon with $4$ vertices has no $P_6$."),
              (8, "Uses the full central angle $\\frac{3 \\times 360}{n} = 135$ without halving, giving $n = 8$.")])

# ---------------------------------------------------------------- 033
def _c033():
    n = 12
    V = _reg(n, 1)
    def dirv(i, j):
        return (V[j][0] - V[i][0], V[j][1] - V[i][1])
    sides = [dirv(i, (i + 1) % n) for i in range(n)]
    cnt = 0
    for i, j in itertools.combinations(range(n), 2):
        if (j - i) % n in (1, n - 1):
            continue
        d = dirv(i, j)
        if any(simplify(d[0] * s[1] - d[1] * s[0]) == 0 for s in sides):
            cnt += 1
    return cnt
q("C17-B-033", T, "Diagonals of a regular 12-gon parallel to at least one side", "Difficult",
  "Conceptual/application",
  r"How many diagonals of a regular polygon with $12$ sides are parallel to at least one of its sides?",
  "TITA",
  r"Label the vertices $0, 1, \ldots, 11$ on the circumcircle. The direction of chord $ij$ depends only on $i + j \pmod{12}$, and chords with the same value of $i + j$ are parallel. Every side $\{i, i+1\}$ has $i + j$ odd, and all six odd values occur. So a diagonal is parallel to a side exactly when $i + j$ is odd, that is when $j - i$ is odd. The odd gaps allowed for diagonals are $3$ and $5$ (gap $7$ and $9$ repeat them from the other side), each giving $12$ diagonals, so the total is $24$.",
  "Including the diameters (gap $6$), which are not parallel to any side, or counting only the gap $3$ diagonals.",
  "C17B-diagonals-parallel-to-sides", "Needs the parity of $i + j$ as the direction invariant; counting by gap classes.",
  tita_answer=24, check=_c033, cognitive="Analysis", exams=CX,
  tita_traps=[(12, "Counts only the diagonals that skip two vertices (gap $3$)."),
              (30, "Also counts the $6$ diameters, which are not parallel to any side of a $12$-gon.")])

# ---------------------------------------------------------------- 034
def _c034():
    import numpy as _np
    H = [(2 * _m.cos(_m.pi * k / 3), 2 * _m.sin(_m.pi * k / 3)) for k in range(6)]
    def inside(p):
        for k in range(6):
            a = H[k]; b = H[(k + 1) % 6]
            if (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) < -1e-12:
                return False
        return True
    def biggest(th, cx, cy):
        lo, hi = 0.0, 4.0
        for _ in range(45):
            t = (lo + hi) / 2
            ok = all(inside((cx + t / 2 * (_m.cos(th) * sx - _m.sin(th) * sy), cy + t / 2 * (_m.sin(th) * sx + _m.cos(th) * sy)))
                     for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)))
            lo, hi = (t, hi) if ok else (lo, t)
        return lo
    best, arg = 0, None
    for th in _np.linspace(0, _m.pi / 2, 91):
        for cx in (-0.2, 0.0, 0.2):
            for cy in (-0.2, 0.0, 0.2):
                b = biggest(th, cx, cy)
                if b > best:
                    best, arg = b, (th, cx, cy)
    # exact value for the optimal configuration found (axis-aligned, centred): corner (t/2, t/2) on sqrt(3) x + y = 2 sqrt(3)
    t = symbols('t', positive=True)
    exact = solve(Eq(sqrt(3) * t / 2 + t / 2, 2 * sqrt(3)), t)[0]
    assert abs(float(exact) - best) < 1e-6
    return simplify(exact)
q("C17-B-034", T, "Largest square that fits inside a regular hexagon", "Difficult",
  "Casework/optimisation",
  r"A square tile is to be cut from a regular hexagonal sheet of side $2$ m. What is the side of the largest square that can be cut?",
  "MCQ",
  r"Place the hexagon with two sides horizontal and centre at the origin; its width at height $y$ is $4 - \frac{2|y|}{\sqrt{3}}$. A square of side $t$ centred at the origin with horizontal sides fits when its top edge at $y = \frac{t}{2}$ is short enough: $t \le 4 - \frac{t}{\sqrt{3}}$, so $t = \frac{4\sqrt{3}}{\sqrt{3} + 1} = 6 - 2\sqrt{3} \approx 2.54$ m. The hexagon is symmetric about both axes, so the best square can be taken centred; tilting it, say to $45^\circ$, sends its corners towards the slanted sides, which close in faster than the horizontal top and bottom sides, so the tilted square that fits is smaller. Hence the axis-aligned centred square is the largest, of side $6 - 2\sqrt{3}$ m.",
  "Inscribing the square in the hexagon's incircle, or using the full height difference instead of half the side.",
  "C17B-largest-square-in-hexagon", "An optimisation over position and orientation with a surd answer; the incircle square is a near-miss trap.",
  correct=r"$(6 - 2\sqrt{3})$ m",
  distractors=[(r"$\sqrt{6}$ m", "Inscribes the square in the incircle of radius $\\sqrt{3}$: side $\\sqrt{3} \\times \\sqrt{2}$."),
               (r"$(8\sqrt{3} - 12)$ m", "Uses $t \\le 4 - \\frac{2t}{\\sqrt{3}}$, taking the top edge at height $t$ in place of $\\frac{t}{2}$."),
               (r"$2\sqrt{2}$ m", "Takes the square whose diagonal equals the long diagonal $4$ m of the hexagon; its corners stick out.")],
  check=_c034, values=[6 - 2 * sqrt(3), sqrt(6), 8 * sqrt(3) - 12, 2 * sqrt(2)], cognitive="Analysis", exams=CX,
  flags="")

# ---------------------------------------------------------------- 035
def _c035():
    # regular pentagon of side 2: circumradius R = 1 / sin 36
    R = 1 / sin(pi / 5)
    V = _reg(5, R, pi / 2)          # P, Q, R, S, T anticlockwise
    P, Q, Rv, S = [Point(*v) for v in V[:4]]
    assert simplify(P.distance(Q) - 2) == 0
    X = Line(P, Rv).intersection(Line(Q, S))[0]
    return nsimplify(simplify(X.distance(Rv)))
_f = Fig()
_Rr = 1.0 / _m.sin(_m.pi / 5)
_V5 = _fpts(5, _Rr, 90.0, clockwise=False)
_L5 = "PQRST"
_pp = [_f.pt(_L5[i], *_V5[i]) for i in range(5)]
_f.poly(*_pp)
_f.seg(_pp[0], _pp[2]); _f.seg(_pp[1], _pp[3])
def _isect(p1, p2, p3, p4):
    d = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0])
    t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / d
    return (p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1]))
_Xp = _f.pt("X", *_isect(_V5[0], _V5[2], _V5[1], _V5[3]), offset=(0, -1))
_f.label_seg(_pp[2], _pp[3], "2 cm")
_alt = "Regular pentagon PQRST with side RS marked 2 cm. The diagonals PR and QS are drawn and cross at the point X."
q("C17-B-035", T, "Length of a segment of a diagonal of a regular pentagon cut off by another diagonal", "Difficult",
  "Conceptual/application",
  r"$PQRST$ is a regular pentagon of side $2$ cm. The diagonals $PR$ and $QS$ meet at $X$. What is the length of $XR$?",
  "MCQ",
  r"Each interior angle is $108^\circ$, so in the isosceles triangles $PQR$ and $QRS$ the base angles are $36^\circ$: $\angle XRQ = \angle PRQ = 36^\circ$ and $\angle XQR = \angle SQR = 36^\circ$. So triangle $QXR$ is isosceles with base $QR = 2$ and base angles $36^\circ$, and $XR = \frac{1}{\cos 36^\circ}$. Also $\angle QXP = 72^\circ = \angle PQX$, so $PX = PQ = 2$. Triangle $QXR$ is similar to triangle $PQR$ (both have angles $36^\circ, 36^\circ, 108^\circ$), so $\frac{XR}{QR} = \frac{QR}{PR}$, that is $XR(2 + XR) = 4$. Hence $XR^2 + 2XR - 4 = 0$ and $XR = \sqrt{5} - 1$ cm (about $1.24$ cm).",
  "Assuming the diagonals bisect each other, or carrying over the hexagon value $s\\sqrt{3}$ for a diagonal.",
  "C17B-pentagon-diagonals", "Non-obvious angle chase in the pentagon, an isosceles triangle $PQX$ and a similarity that leads to a quadratic.",
  correct=r"$(\sqrt{5} - 1)$ cm",
  distractors=[(r"$\frac{\sqrt{5} + 1}{2}$ cm", "Assumes $X$ is the midpoint of $PR$ and halves the diagonal $PR = \\sqrt{5} + 1$."),
               (r"$(2\sqrt{3} - 2)$ cm", "Uses the hexagon fact that a short diagonal is $s\\sqrt{3}$, so $PR = 2\\sqrt{3}$, then subtracts $PX = 2$."),
               (r"$(\sqrt{5} + 1)$ cm", "Takes the base angles of triangle $QXR$ as $72^\\circ$, so $XR = \\frac{1}{\\cos 72^\\circ} = \\sqrt{5} + 1$.")],
  check=_c035, values=[sqrt(5) - 1, (sqrt(5) + 1) / 2, 2 * sqrt(3) - 2, sqrt(5) + 1], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))
