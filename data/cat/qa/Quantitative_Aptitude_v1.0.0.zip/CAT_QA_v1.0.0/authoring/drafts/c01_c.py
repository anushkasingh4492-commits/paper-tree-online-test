import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TE = "Elections and examinations"
TI = "Income, expenditure and savings"
CX = ("CAT", "XAT")


def _one(sol):
    sol = [s for s in sol if s.is_real]
    assert len(sol) == 1, sol
    return sol[0]


# ============================================================ ELECTIONS

def _e1():
    t = symbols('t', positive=True)
    valid = Rational(88, 100) * t
    return _one(solve(Eq(Rational(55, 100) * valid - Rational(45, 100) * valid, 2640), t))
q("C01-C-001", TE, "Two-candidate contest: total votes cast from the margin when some votes are invalid", "Easy",
  "Multi-step word problem",
  r"In an election between two candidates, $12\%$ of the votes cast were declared invalid. The winner received $55\%$ of the valid votes and won by a margin of $2{,}640$ votes. How many votes were cast in all?",
  "MCQ",
  r"The loser received $45\%$ of the valid votes, so the margin is $10\%$ of the valid votes. Valid votes $= 2640 \div 0.10 = 26{,}400$. These are $88\%$ of all votes cast, so the total is $26400 \div 0.88 = 30{,}000$.",
  r"Reporting the valid votes as the total, or adding $12\%$ to the valid votes rather than dividing by $0.88$.",
  "C01C-elec-turnout-registered", "Margin as a share of valid votes, then one scaling back to the total; the trap is the base.",
  correct=r"$30{,}000$",
  distractors=[(r"$26{,}400$", r"Stops at the valid votes: $2640 \div 0.10 = 26{,}400$."),
               (r"$29{,}568$", r"Adds $12\%$ of the valid votes to them: $26400 \times 1.12 = 29{,}568$, rather than dividing by $0.88$."),
               (r"$60{,}000$", r"Takes the margin as $55\% - 50\% = 5\%$ of the valid votes: $2640 \div 0.05 = 52{,}800$ valid, then $52800 \div 0.88 = 60{,}000$.")],
  check=_e1, values=[30000, 26400, 29568, 60000], cognitive="Application")


def _e2():
    reg = 80000
    cast = F(75, 100) * reg
    valid = cast - F(4, 100) * cast
    win = F(58, 100) * valid
    lose = valid - win
    return win - lose
q("C01-C-002", TE, "Margin of victory from registered voters, turnout and invalid votes", "Easy",
  "Multi-step word problem",
  r"A constituency has $80{,}000$ registered voters, of whom $75\%$ cast their votes. Of the votes cast, $4\%$ were invalid. In the two-candidate contest, the winner received $58\%$ of the valid votes. By how many votes did the winner win?",
  "TITA",
  r"Votes cast $= 0.75 \times 80000 = 60{,}000$. Valid votes $= 0.96 \times 60000 = 57{,}600$. The margin is $58\% - 42\% = 16\%$ of the valid votes: $0.16 \times 57600 = 9{,}216$.",
  "Applying the margin percentage to the votes cast or to the registered voters rather than to the valid votes.",
  "C01C-elec-turnout-registered", "Three successive bases (registered, cast, valid); the trap is the wrong base.",
  tita_answer=9216, check=_e2,
  tita_traps=[(9600, r"Takes $16\%$ of the $60{,}000$ votes cast, ignoring the invalid votes."),
              (12800, r"Takes $16\%$ of all $80{,}000$ registered voters.")],
  cognitive="Application")


def _e3():
    v = symbols('v', positive=True)
    valid = _one(solve(Eq(Rational(62, 100) * v, 18600), v))
    return valid - 18600
q("C01-C-003", TE, "Loser's votes from the winner's share and tally", "Easy",
  "Single-step computation",
  r"In a two-candidate election in which every vote cast was valid, Kavita won with $62\%$ of the votes, polling $18{,}600$ votes. How many votes did her opponent receive?",
  "MCQ",
  r"$62\%$ of the total is $18{,}600$, so the total is $18600 \div 0.62 = 30{,}000$. The opponent received $30000 - 18600 = 11{,}400$ votes (equivalently $18600 \times \frac{38}{62}$).",
  r"Taking $38\%$ of the winner's tally rather than of the total.",
  "C01C-elec-share-to-count", "One division to recover the total and one subtraction.",
  correct=r"$11{,}400$",
  distractors=[(r"$7{,}068$", r"Takes $38\%$ of Kavita's $18{,}600$ votes."),
               (r"$7{,}200$", r"Reports the margin $24\%$ of $30{,}000$."),
               (r"$14{,}136$", r"Takes the $24$ percentage point margin as $24\%$ of Kavita's votes and subtracts it: $18600 - 4464 = 14{,}136$.")],
  check=_e3, values=[11400, 7068, 7200, 14136], cognitive="Application")


def _e4():
    v = symbols('v', positive=True)
    tot = _one(solve(Eq(Rational(45, 100) * v - Rational(20, 100) * v, 7500), v))
    return Rational(35, 100) * tot
q("C01-C-004", TE, "Three-candidate contest: one candidate's votes from a margin between the other two", "Easy",
  "Multi-step word problem",
  r"In a three-candidate election in which all votes were valid, Pooja received $45\%$ of the votes, Rahul $35\%$, and Imran the rest. Pooja received $7{,}500$ more votes than Imran. How many votes did Rahul receive?",
  "MCQ",
  r"Imran's share is $100 - 45 - 35 = 20\%$, so Pooja's lead over him is $25\%$ of the total. Total $= 7500 \div 0.25 = 30{,}000$, and Rahul received $0.35 \times 30000 = 10{,}500$ votes.",
  "Using the gap between the two leading candidates rather than the gap named in the stem.",
  "C01C-elec-three-candidate-margin", "Find the third share, one division, one multiplication.",
  correct=r"$10{,}500$",
  distractors=[(r"$26{,}250$", r"Uses the $10\%$ gap between Pooja and Rahul: total $= 75{,}000$, so Rahul gets $26{,}250$."),
               (r"$13{,}500$", r"Reports Pooja's tally, $45\%$ of $30{,}000$."),
               (r"$6{,}000$", r"Reports Imran's tally, $20\%$ of $30{,}000$.")],
  check=_e4, values=[10500, 26250, 13500, 6000], cognitive="Application")


def _e5():
    v = symbols('v', positive=True)
    w = symbols('w')
    sol = solve([Eq(w / v * 100 - (v - w) / v * 100, 8), Eq(v - w, 9200)], [v, w], dict=True)
    return sol[0][v]
q("C01-C-005", TE, "Total valid votes from a percentage-point lead and the loser's tally", "Easy",
  "Conceptual/application",
  r"In a two-candidate election, the winner's share of the valid votes exceeded the loser's share by $8$ percentage points. The loser received $9{,}200$ valid votes. How many valid votes were there in all?",
  "TITA",
  r"If the shares are $50 + 4$ and $50 - 4$, the gap is $8$ percentage points, so the loser had $46\%$ of the valid votes. Total valid votes $= 9200 \div 0.46 = 20{,}000$.",
  r"Treating an $8$ percentage point lead as the winner polling $8\%$ more votes than the loser.",
  "C01C-elec-share-to-count", r"One idea (split the lead about $50\%$) and one division; the trap is percent versus percentage points.",
  tita_answer=20000, check=_e5,
  tita_traps=[(19136, r"Reads the lead as $8\%$ more votes than the loser: $9200 \times 1.08 = 9936$, total $19{,}136$."),
              (115000, r"Divides the loser's $9{,}200$ votes by $0.08$.")],
  cognitive="Understanding")


def _e6():
    n = symbols('n', positive=True)
    valid = Rational(80, 100) * n - 500
    return _one(solve(Eq(Rational(60, 100) * valid, Rational(45, 100) * n), n))
q("C01-C-006", TE, "Size of the voter list from turnout, invalid votes and the winner's share of the list", "Medium",
  "Inverse/parameter",
  r"In a two-candidate election, $20\%$ of the voters on the voter list did not vote, and $500$ of the votes cast were invalid. The winner received $60\%$ of the valid votes, and this tally was equal to $45\%$ of the number of voters on the list. How many voters were on the list?",
  "MCQ",
  r"Let the list have $N$ voters. Votes cast $= 0.8N$ and valid votes $= 0.8N - 500$. Then $0.6(0.8N - 500) = 0.45N$, so $0.48N - 300 = 0.45N$, giving $0.03N = 300$ and $N = 10{,}000$. Check: $8000$ cast, $7500$ valid, winner $4500 = 45\%$ of $10000$.",
  r"Taking the $45\%$ on the votes cast or reporting the votes cast or valid votes as the size of the list.",
  "C01C-elec-turnout-registered", "Two different bases (list and valid votes) tied in one linear equation.",
  correct=r"$10{,}000$",
  distractors=[(r"$8{,}000$", r"Reports the number of votes cast, $0.8 \times 10000$."),
               (r"$7{,}500$", r"Reports the number of valid votes, $8000 - 500$."),
               (r"$2{,}500$", r"Takes the winner's tally as $45\%$ of the votes cast: $0.6(0.8N - 500) = 0.36N$ gives $N = 2500$.")],
  check=_e6, values=[10000, 8000, 7500, 2500], cognitive="Application")


def _e7():
    t = symbols('t', positive=True)
    arjun = Rational(55, 100) * t
    meera = Rational(45, 100) * t
    return _one(solve(Eq((meera + 1500) - (arjun - 1500), Rational(2, 100) * t), t))
q("C01-C-007", TE, "Total votes from a margin that reverses when some voters switch", "Medium",
  "Multi-step word problem",
  r"In a two-candidate election in which all votes were valid, Arjun defeated Meera by a margin equal to $10\%$ of the total votes cast. Had $1{,}500$ of the people who voted for Arjun voted for Meera instead, Meera would have won by a margin equal to $2\%$ of the total votes cast. How many votes were cast in all?",
  "TITA",
  r"Arjun had $55\%$ and Meera $45\%$ of the total $T$. Each switching voter cuts Arjun's lead by $2$, so $1500$ switches change the margin by $3000$ votes, from $+10\%$ to $-2\%$ of $T$, a swing of $12\%$ of $T$. Hence $0.12T = 3000$ and $T = 25{,}000$.",
  "Forgetting that one switched vote changes the margin by two votes, or subtracting the two margins rather than adding them.",
  "C01C-elec-switch-reverse-result", "Recognising the swing of $2$ per switched voter and that the margin changes sign.",
  tita_answer=25000, check=_e7,
  tita_traps=[(12500, r"Treats the $1500$ switched votes as the change in margin: $0.12T = 1500$."),
              (37500, r"Uses a swing of $10 - 2 = 8\%$: $0.08T = 3000$.")],
  cognitive="Analysis")


def _e8():
    valid = 50000
    farah = valid * 58 // 100
    sameer = valid - farah
    k = 0
    while not (sameer + k > farah - k):
        k += 1
    return k
q("C01-C-008", TE, "Minimum number of voters who must switch for the loser to win outright", "Medium",
  "Casework/optimisation",
  r"In a two-candidate election there were $50{,}000$ valid votes. Farah received $58\%$ of them and Sameer received the rest. What is the minimum number of Farah's voters who would have had to vote for Sameer instead for Sameer to win outright, that is, to receive strictly more votes than Farah?",
  "TITA",
  r"Farah had $29{,}000$ votes and Sameer $21{,}000$, a gap of $8{,}000$. Each switch reduces the gap by $2$, so $4000$ switches produce a tie at $25{,}000$ each. One more is needed to win outright: $4{,}001$.",
  "Stopping at the tie, or forgetting that each switch moves the gap by two.",
  "C01C-elec-min-votes-to-win", "Gap halving plus a strict inequality; the tie is the trap.",
  tita_answer=4001, check=_e8,
  tita_traps=[(4000, "Stops at the tie, which is not an outright win."),
              (8001, "Treats each switch as reducing the gap by only one vote.")],
  cognitive="Analysis")


def _e9():
    v = symbols('v', positive=True)
    j = symbols('j', positive=True)
    jo = _one(solve(Eq(j + Rational(3, 2) * j, Rational(60, 100)), j))
    sn = Rational(3, 2) * jo
    valid = _one(solve(Eq((Rational(40, 100) - max(sn, jo)) * v, 1620), v))
    return valid / Rational(90, 100)
q("C01-C-009", TE, "Three-candidate contest with a ratio between two rivals and invalid votes", "Medium",
  "Multi-step word problem",
  r"In a three-candidate election, $10\%$ of the votes polled were invalid. Of the valid votes, Kabir received $40\%$, and Sneha received $1.5$ times as many votes as Joseph, the third candidate. Kabir won by $1{,}620$ votes over his nearest rival. How many votes were polled in all?",
  "MCQ",
  r"Sneha and Joseph share $60\%$ in the ratio $3 : 2$, so Sneha has $36\%$ and Joseph $24\%$. The nearest rival is Sneha, $4$ percentage points behind, so valid votes $= 1620 \div 0.04 = 40{,}500$. Votes polled $= 40500 \div 0.9 = 45{,}000$.",
  "Measuring the margin against the wrong rival, or forgetting to scale the valid votes up to the votes polled.",
  "C01C-elec-three-candidate-margin", "Split the remaining share by a ratio, identify the nearest rival, then two scalings.",
  correct=r"$45{,}000$",
  distractors=[(r"$40{,}500$", r"Reports the valid votes."),
               (r"$11{,}250$", r"Measures the margin against Joseph ($16\%$): $1620 \div 0.16 = 10{,}125$ valid, $11{,}250$ polled."),
               (r"$18{,}000$", r"Splits the $60\%$ equally ($30\%$ each), a $10\%$ margin: $16{,}200$ valid, $18{,}000$ polled.")],
  check=_e9, values=[45000, 40500, 11250, 18000], cognitive="Application")


def _e10():
    c, v = symbols('c v', positive=True)
    valid = _one(solve(Eq(Rational(60, 100) * v, Rational(48, 100) * c), v))
    sunil = valid - Rational(60, 100) * valid
    return simplify(sunil / c * 100)
q("C01-C-010", TE, "Loser's share of all votes cast from the winner's shares of the valid votes and of the votes cast", "Medium",
  "Conceptual/application",
  r"In a two-candidate election, some of the votes cast were declared invalid. Ravi received $60\%$ of the valid votes, and his tally was equal to $48\%$ of all the votes cast. His only opponent, Sunil, received all the other valid votes. Sunil's tally was what percentage of all the votes cast?",
  "MCQ",
  r"Ravi's tally is $0.6V = 0.48C$, where $V$ is the number of valid votes and $C$ the number cast, so $V = 0.8C$. Sunil received $40\%$ of the valid votes, that is $0.4 \times 0.8C = 0.32C$, or $32\%$ of the votes cast. (The other $20\%$ of the votes cast were invalid.)",
  r"Mixing up the two bases: quoting a share of the valid votes as a share of the votes cast, or shifting both shares by the same number of percentage points.",
  "C01C-elec-share-two-bases", "Two shares of one tally on different bases must be reconciled before converting the loser's share; two traps on the base.",
  correct=r"$32\%$",
  distractors=[(r"$40\%$", r"Reports Sunil's share of the valid votes, $100 - 60$."),
               (r"$52\%$", r"Takes everything Ravi did not get as Sunil's, $100 - 48$, ignoring the invalid votes."),
               (r"$28\%$", r"Sees Ravi's share drop by $60 - 48 = 12$ percentage points and subtracts the same $12$ points from Sunil's $40\%$.")],
  check=_e10, values=[32, 40, 52, 28], cognitive="Understanding")


def _e11():
    total, counted = 120000, 96000
    harp = counted * 55 // 100
    dinesh = counted - harp
    rem = total - counted
    for x in range(rem + 1):
        if dinesh + x > harp + (rem - x):
            return x
q("C01-C-011", TE, "Votes the trailing candidate needs from the uncounted votes to win outright", "Medium",
  "Casework/optimisation",
  r"In a two-candidate election there are $1{,}20{,}000$ valid votes. After $96{,}000$ of them have been counted, Harpreet has $55\%$ of the counted votes and Dinesh has the rest. What is the minimum number of the remaining valid votes that Dinesh must receive to win outright, that is, to finish with strictly more votes than Harpreet?",
  "MCQ",
  r"Harpreet has $52{,}800$ and Dinesh $43{,}200$; $24{,}000$ votes remain. If Dinesh gets $x$ of them, Harpreet gets $24000 - x$, and Dinesh wins outright when $43200 + x > 52800 + 24000 - x$, that is $2x > 33600$, so $x > 16800$. The minimum is $16{,}801$.",
  "Ignoring that Harpreet also collects the remaining votes Dinesh does not get, or stopping at the tie.",
  "C01C-elec-min-votes-to-win", "Both candidates share the remaining votes, and the strict inequality matters.",
  correct=r"$16{,}801$",
  distractors=[(r"$16{,}800$", "Stops at the tie, which is not an outright win."),
               (r"$9{,}601$", r"Only overtakes the current lead of $9{,}600$, as if Harpreet received none of the remaining votes."),
               (r"$12{,}001$", r"Takes a bare majority of the $24{,}000$ remaining votes, ignoring the current lead.")],
  check=_e11, values=[16801, 16800, 9601, 12001], cognitive="Analysis")


def _e12():
    s, j = symbols('s j', positive=True)
    sol = solve([Eq(s - j, 600),
                 Eq((Rational(9, 10) * j + Rational(2, 10) * s) - (Rational(8, 10) * s + Rational(1, 10) * j), 200)],
                [s, j], dict=True)[0]
    return sol[s] + sol[j]
q("C01-C-012", TE, "Size of a fixed electorate from cross-switching in a re-poll", "Difficult",
  "Multi-step word problem",
  r"In a two-candidate election, every member of a fixed electorate voted and every vote was valid; Sneha beat Joseph by $600$ votes. In a re-poll, the same electorate voted again and every vote was again valid. $20\%$ of those who had voted for Sneha now voted for Joseph, $10\%$ of those who had voted for Joseph now voted for Sneha, and everyone else voted as before. Joseph won the re-poll by $200$ votes. How many people are in the electorate?",
  "TITA",
  r"Let Sneha and Joseph first get $s$ and $j$ votes, with $s - j = 600$. In the re-poll Joseph gets $0.9j + 0.2s$ and Sneha $0.8s + 0.1j$, so $0.8j - 0.6s = 200$. Substituting $s = j + 600$ gives $0.2j - 360 = 200$, so $j = 2800$ and $s = 3400$. The electorate is $6{,}200$.",
  "Ignoring the voters who moved from Joseph to Sneha, or using the wrong sign for the new margin.",
  "C01C-elec-switch-reverse-result", "Two-way switching between two unknown groups, with a margin that changes sign.",
  tita_answer=6200, check=_e12,
  tita_traps=[(3400, r"Ignores the $10\%$ who moved from Joseph to Sneha: $j - 0.6s = 200$ gives $j = 1400$, $s = 2000$."),
              (2200, r"Writes the re-poll margin as $0.8j - 0.6s = -200$, giving $j = 800$, $s = 1400$.")],
  exams=CX, cognitive="Analysis")


def _e13():
    v, f = symbols('v f', positive=True)
    tot = _one(solve(Eq((Rational(42, 100) - Rational(33, 100)) * v, 3240), v))
    an, pr, ro = Rational(42, 100) * tot, Rational(33, 100) * tot, Rational(25, 100) * tot
    return _one(solve(Eq((pr + f * ro) - (an + (1 - f) * ro), 1800), f)) * 100
q("C01-C-013", TE, "Split of a withdrawn candidate's voters needed to reverse the result", "Difficult",
  "Inverse/parameter",
  r"In a three-candidate election in which all votes were valid, Ananya received $42\%$, Priya $33\%$ and Rohit $25\%$ of the votes, and Ananya led Priya by $3{,}240$ votes. Rohit then withdrew and a fresh poll was held among the same voters, all of whom voted again with all votes valid. Each of Rohit's earlier voters voted for Ananya or Priya, and everyone else voted as before. Priya won the fresh poll by $1{,}800$ votes. What percentage of Rohit's earlier voters voted for Priya?",
  "MCQ",
  r"Ananya's $9$ percentage point lead is $3240$ votes, so the total is $36{,}000$ and Rohit had $9{,}000$ voters. If a fraction $f$ of them chose Priya, the change in Priya's margin is $9000f - 9000(1 - f)$, which must turn $-3240$ into $+1800$: $18000f - 9000 = 5040$, so $f = 0.78$, that is $78\%$.",
  "Forgetting that Rohit's voters who do not choose Priya add to Ananya's tally.",
  "C01C-elec-withdrawal-transfer", "Requires the total from a percentage-point lead, then a two-sided transfer equation.",
  correct=r"$78\%$",
  distractors=[(r"$56\%$", r"Lets only Priya gain: $9000f = 3240 + 1800$ gives $f = 0.56$."),
               (r"$28\%$", r"Computes the extra share needed, $\frac{3240 + 1800}{2 \times 9000} = 0.28$, without adding the even split of $50\%$."),
               (r"$60\%$", r"Ignores Ananya's original lead: $9000(2f - 1) = 1800$ gives $f = 0.6$.")],
  check=_e13, values=[78, 56, 28, 60], exams=CX, cognitive="Analysis")


def _e14():
    m, w = symbols('m w', positive=True)
    men_cast, women_cast = Rational(70, 100) * m, Rational(80, 100) * w
    sol = solve(Eq(Rational(45, 100) * men_cast + Rational(60, 100) * women_cast,
                   Rational(50, 100) * (men_cast + women_cast)), m)
    return simplify(_one(sol) / w)
q("C01-C-014", TE, "Ratio of men to women on the voter list from turnout and vote shares by group", "Difficult",
  "Conceptual/application",
  r"In a two-candidate election in which all votes were valid, $70\%$ of the men and $80\%$ of the women on the voter list voted. Kabir received $45\%$ of the votes cast by men and $60\%$ of the votes cast by women, and exactly $50\%$ of all votes cast. What is the ratio of the number of men to the number of women on the voter list?",
  "MCQ",
  r"Let the men and women who voted number $p$ and $q$. Then $0.45p + 0.6q = 0.5(p + q)$, so $0.1q = 0.05p$ and $p = 2q$. If the list has $M$ men and $W$ women, $0.7M = 2 \times 0.8W$, so $\frac{M}{W} = \frac{1.6}{0.7} = \frac{16}{7}$, a ratio of $16 : 7$.",
  "Stopping at the ratio of voters who actually voted, or applying the turnouts the wrong way round.",
  "C01C-elec-weighted-gender-share", "A weighted-average step followed by a second conversion through different turnouts.",
  correct=r"$16 : 7$",
  distractors=[(r"$2 : 1$", "Stops at the ratio of men who voted to women who voted."),
               (r"$7 : 4$", r"Swaps the turnouts: $0.8M = 2 \times 0.7W$."),
               (r"$8 : 7$", r"Uses only the turnouts, $0.8 : 0.7$, as if equal numbers of men and women voted.")],
  check=_e14, values=[F(16, 7), 2, F(7, 4), F(8, 7)], exams=CX, cognitive="Analysis")


def _e15():
    best = None
    tot = 10000
    for t in range(0, tot + 1):
        s = 2 * t
        w = tot - s - t
        if w > s and w > t and s > t:
            if best is None or w < best:
                best = w
    return best
q("C01-C-015", TE, "Minimum winning tally in a three-candidate contest with a ratio between the others", "Difficult",
  "Casework/optimisation",
  r"In a three-candidate election there were $10{,}000$ valid votes. The winner received strictly more votes than each of the other two candidates, and the candidate who came second received exactly twice as many votes as the candidate who came third. What is the minimum number of votes the winner could have received?",
  "TITA",
  r"Let the third candidate have $t$ votes, so the second has $2t$ and the winner $10000 - 3t$. The winner must beat the second: $10000 - 3t > 2t$, so $t < 2000$, that is $t \le 1999$. The winner's tally is smallest when $t$ is largest: $10000 - 5997 = 4{,}003$ (tallies $4003$, $3998$, $1999$).",
  "Ignoring the ratio condition and splitting the votes as evenly as possible, or allowing a tie for first place.",
  "C01C-elec-min-winning-tally", "Optimisation under a strict inequality with an integer constraint.",
  tita_answer=4003, check=_e15,
  tita_traps=[(3334, r"Ignores the $2 : 1$ condition and uses the near-even split $3334, 3333, 3333$."),
              (4000, r"Allows $t = 2000$, which gives a tie at $4000$ for first place.")],
  exams=CX, cognitive="Analysis")


# ============================================================ EXAMINATIONS

def _x1():
    m, p = symbols('m p', positive=True)
    sol = solve([Eq(Rational(30, 100) * m + 24, p), Eq(Rational(42, 100) * m - 12, p)], [m, p], dict=True)[0]
    return sol[p]
q("C01-C-016", TE, "Pass mark from two candidates' percentages and their distances from it", "Easy",
  "Multi-step word problem",
  r"In an examination, Meera scored $30\%$ of the maximum marks and failed by $24$ marks. Arif scored $42\%$ of the maximum marks and got $12$ marks more than the pass mark. What is the pass mark?",
  "MCQ",
  r"The gap between the two scores is $42\% - 30\% = 12\%$ of the maximum, and it equals $24 + 12 = 36$ marks. So the maximum is $300$, Meera scored $90$, and the pass mark is $90 + 24 = 114$.",
  "Reporting the maximum marks or taking the pass percentage as the average of the two percentages.",
  "C01C-exam-pass-mark-two-conditions", "One difference gives the maximum, then one addition.",
  correct=r"$114$",
  distractors=[(r"$108$", r"Takes the pass mark as the average percentage, $36\%$ of $300$."),
               (r"$300$", "Reports the maximum marks."),
               (r"$90$", "Reports Meera's score.")],
  check=_x1, values=[114, 108, 300, 90], cognitive="Application")


def _x2():
    m = symbols('m', positive=True)
    return _one(solve(Eq(Rational(40, 100) * m, 185 + 15), m))
q("C01-C-017", TE, "Maximum marks from the pass percentage and a shortfall", "Easy",
  "Single-step computation",
  r"To pass an examination a candidate needs $40\%$ of the maximum marks. Kunal scored $185$ marks and failed by $15$ marks. What are the maximum marks?",
  "TITA",
  r"The pass mark is $185 + 15 = 200$, which is $40\%$ of the maximum. Maximum marks $= 200 \div 0.4 = 500$.",
  "Subtracting the shortfall rather than adding it, or reporting the pass mark.",
  "C01C-exam-pass-mark-single", "One addition and one division.",
  tita_answer=500, check=_x2,
  tita_traps=[(425, r"Subtracts the shortfall: $(185 - 15) \div 0.4 = 425$."),
              (200, "Reports the pass mark.")],
  cognitive="Application")


def _x3():
    n = 240
    phy = set(range(0, 84))            # 35% of 240 fail Physics
    both = set(range(54, 84))          # 30 students (12.5%) fail both
    chem = both | set(range(84, 84 + 18))  # 48 (20%) fail Chemistry
    assert len(phy) == 84 and len(chem) == 48 and len(phy & chem) == 30
    return n - len(phy | chem)
q("C01-C-018", TE, "Students passing both subjects from failure percentages", "Easy",
  "Multi-step word problem",
  r"In a class of $240$ students, $35\%$ failed in Physics, $20\%$ failed in Chemistry and $12.5\%$ failed in both subjects. How many students passed in both subjects?",
  "MCQ",
  r"Students who failed in at least one subject make up $35 + 20 - 12.5 = 42.5\%$. So $57.5\%$ passed in both: $0.575 \times 240 = 138$.",
  "Adding the two failure percentages without removing the overlap, or removing it twice.",
  "C01C-exam-fail-subjects", "One inclusion-exclusion step and one percentage of a count.",
  correct=r"$138$",
  distractors=[(r"$108$", r"Ignores the overlap: $100 - 55 = 45\%$ of $240$."),
               (r"$168$", r"Subtracts the overlap twice: $35 + 20 - 25 = 30\%$ failed, $70\%$ of $240$."),
               (r"$30$", r"Reports the students who failed in both, $12.5\%$ of $240$.")],
  check=_x3, values=[138, 108, 168, 30], cognitive="Application")


def _x4():
    need = F(60, 100) * (150 + 100 + 50)
    have = F(48, 100) * 150 + F(70, 100) * 100
    return need - have
q("C01-C-019", TE, "Marks needed in the last paper for an aggregate percentage when papers carry different maxima", "Easy",
  "Inverse/parameter",
  r"An examination has three papers carrying $150$, $100$ and $50$ maximum marks. A candidate qualifies by scoring at least $60\%$ of the aggregate maximum marks. Sana scored $48\%$ in the first paper and $70\%$ in the second. What is the minimum number of marks she must score in the third paper to qualify?",
  "TITA",
  r"She needs $0.6 \times 300 = 180$ marks in all. She has $0.48 \times 150 + 0.7 \times 100 = 72 + 70 = 142$. She needs $180 - 142 = 38$ marks out of $50$ in the third paper.",
  "Averaging the paper percentages as if every paper carried equal marks.",
  "C01C-exam-aggregate-marks-needed", "Converting each percentage to marks on its own base; the trap is the unequal maxima.",
  tita_answer=38, check=_x4,
  tita_traps=[(31, r"Averages percentages: $3 \times 60 - 48 - 70 = 62\%$, and $62\%$ of $50$ is $31$."),
              (76, r"Reports the percentage needed in the third paper, $\frac{38}{50} = 76\%$.")],
  cognitive="Application")


def _x5():
    m, p = symbols('m p', positive=True)
    sol = solve([Eq(Rational(25, 100) * m + 45, p), Eq(Rational(25, 100) * m + 15, p - Rational(5, 100) * m)],
                [m, p], dict=True)[0]
    return sol[p]
q("C01-C-020", TE, "Original pass mark from the effect of lowering it by percentage points", "Medium",
  "Inverse/parameter",
  r"Rohan scored $25\%$ of the maximum marks in an examination and failed by $45$ marks. Had the pass mark been lowered by $5$ percentage points of the maximum marks, he would have failed by only $15$ marks. What was the original pass mark?",
  "MCQ",
  r"Lowering the pass mark by $5\%$ of the maximum reduced his shortfall by $30$ marks, so the maximum is $30 \div 0.05 = 600$. Rohan scored $150$, so the original pass mark is $150 + 45 = 195$ (that is, $32.5\%$).",
  "Reporting the lowered pass mark or the candidate's own score.",
  "C01C-exam-pass-mark-two-conditions", "A percentage-point change must be read as a fixed share of the maximum.",
  correct=r"$195$",
  distractors=[(r"$165$", r"Reports the lowered pass mark, $195 - 30$."),
               (r"$150$", "Reports Rohan's score."),
               (r"$600$", "Reports the maximum marks.")],
  check=_x5, values=[195, 165, 150, 600], cognitive="Application")


def _x6():
    n = symbols('n', positive=True)
    boys, girls = Rational(60, 100) * n, Rational(40, 100) * n
    tot = _one(solve(Eq(boys * Rational(20, 100) + girls * Rational(10, 100), 48), n))
    return Rational(40, 100) * tot * Rational(90, 100)
q("C01-C-021", TE, "Girls who passed, from group pass rates and the number who failed", "Medium",
  "Multi-step word problem",
  r"In a class, $60\%$ of the students are boys and the rest are girls. In an examination, $80\%$ of the boys and $90\%$ of the girls passed, and $48$ students failed. How many girls passed?",
  "TITA",
  r"The failure rate for the class is $0.6 \times 20\% + 0.4 \times 10\% = 16\%$. So the class has $48 \div 0.16 = 300$ students, of whom $120$ are girls. Girls who passed $= 0.9 \times 120 = 108$.",
  "Averaging the two pass rates without weighting, or answering with the number of girls or of all who passed.",
  "C01C-exam-pass-rate-groups", "A weighted failure rate, then two percentages of counts.",
  tita_answer=108, check=_x6,
  tita_traps=[(120, "Reports the number of girls."),
              (252, "Reports the number of students who passed.")],
  cognitive="Application")


def _x7():
    b, g = symbols('b g', positive=True)
    return simplify(_one(solve(Eq(Rational(72, 100) * b + Rational(82, 100) * g, Rational(78, 100) * (b + g)), b)) / g)
q("C01-C-022", TE, "Ratio of boys to girls from group pass rates and the overall pass rate", "Medium",
  "Conceptual/application",
  r"In a school examination, $72\%$ of the boys and $82\%$ of the girls passed. Overall, $78\%$ of the students passed. What is the ratio of the number of boys to the number of girls?",
  "MCQ",
  r"The overall rate is a weighted average: $72b + 82g = 78(b + g)$, so $4g = 6b$ and $b : g = 4 : 6 = 2 : 3$. By alligation, the weights are the opposite distances $82 - 78 = 4$ for boys and $78 - 72 = 6$ for girls.",
  "Attaching the alligation distances to the wrong groups.",
  "C01C-exam-pass-rate-groups", "Weighted average solved for the weights; the trap is the reversed alligation.",
  correct=r"$2 : 3$",
  distractors=[(r"$3 : 2$", r"Attaches the distances to the wrong groups: $78 - 72 = 6$ for boys, $82 - 78 = 4$ for girls."),
               (r"$36 : 41$", r"Uses the ratio of the pass rates, $72 : 82$."),
               (r"$14 : 9$", r"Uses the ratio of the failure rates, $28 : 18$.")],
  check=_x7, values=[F(2, 3), F(3, 2), F(36, 41), F(14, 9)], cognitive="Understanding")


def _x8():
    need = F(72, 100) * (4 * 50 + 2 * 75)
    have = F(60, 100) * (4 * 50)
    return need - have
q("C01-C-023", TE, "Combined marks needed in the last tests for an aggregate percentage", "Medium",
  "Inverse/parameter",
  r"A course has six tests. Each of the first four tests carries $50$ maximum marks and each of the last two carries $75$. The final result is the aggregate percentage over all six tests. Ishaan averaged $60\%$ over the first four tests. What is the minimum combined score he needs in the last two tests to finish with an aggregate of $72\%$?",
  "MCQ",
  r"The aggregate maximum is $4 \times 50 + 2 \times 75 = 350$, so he needs $0.72 \times 350 = 252$ marks. He has $0.6 \times 200 = 120$. He needs $252 - 120 = 132$ marks out of $150$ in the last two tests.",
  "Averaging test percentages as if every test carried equal weight.",
  "C01C-exam-aggregate-marks-needed", "Two different maxima; percentage averages must be weighted by marks.",
  correct=r"$132$",
  distractors=[(r"$144$", r"Weights all six tests equally: $6 \times 72 - 4 \times 60 = 192$, so $96\%$ of $150$."),
               (r"$126$", r"Weights the two blocks equally: needs $72 + 12 = 84\%$ of $150$."),
               (r"$108$", r"Takes $72\%$ of $150$, ignoring the shortfall in the first four tests.")],
  check=_x8, values=[132, 144, 126, 108], cognitive="Application")


def _x9():
    n = symbols('n', positive=True)
    f1only, f2only = Rational(18, 100), Rational(12, 100)
    both = f1only / 3
    tot = _one(solve(Eq((1 - f1only - f2only - both) * n, 1152), n))
    return (f2only + both) * tot
q("C01-C-024", TE, "Candidates failing a paper from 'only' percentages and a count passing both", "Medium",
  "Multi-step word problem",
  r"In an examination with two papers, $18\%$ of the candidates failed in Paper I only and $12\%$ failed in Paper II only. The number who failed in both papers was one-third of the number who failed in Paper I only. If $1{,}152$ candidates passed in both papers, how many candidates failed in Paper II?",
  "MCQ",
  r"Failed in both $= \frac{18}{3} = 6\%$, so $18 + 12 + 6 = 36\%$ failed in at least one paper and $64\%$ passed both. Total $= 1152 \div 0.64 = 1800$. Failed in Paper II (only or both) $= 12 + 6 = 18\%$ of $1800 = 324$.",
  "Counting only those who failed Paper II alone, or using the wrong failure group.",
  "C01C-exam-fail-subjects", "Distinguishing 'only' from total failures, then two scalings.",
  correct=r"$324$",
  distractors=[(r"$216$", r"Counts only those who failed Paper II alone, $12\%$ of $1800$."),
               (r"$432$", r"Reports those who failed Paper I, $24\%$ of $1800$."),
               (r"$648$", r"Reports those who failed at least one paper, $36\%$ of $1800$.")],
  check=_x9, values=[324, 216, 432, 648], cognitive="Application")


def _x10():
    maxm = 250
    new_pass = F(44, 100) * maxm
    for x in range(0, maxm + 1):
        if x * F(115, 100) >= new_pass:
            return x
q("C01-C-025", TE, "Lowest original score that passes after moderation and a raised pass mark", "Medium",
  "Inverse/parameter",
  r"An examination has $250$ maximum marks, and the pass mark was $40\%$ of the maximum. After the papers were marked, every candidate's marks were raised by $15\%$ of the marks he or she had scored, with no rounding, and the pass mark was raised by $4$ percentage points, to $44\%$ of the maximum. What is the lowest original whole-number score with which a candidate passes after these changes?",
  "TITA",
  r"The new pass mark is $0.44 \times 250 = 110$. A candidate who scored $x$ now has $1.15x$, so we need $1.15x \ge 110$, that is $x \ge 95.65\ldots$. The lowest whole-number score is $96$ ($96 \times 1.15 = 110.4$, while $95 \times 1.15 = 109.25$ falls short).",
  r"Using the old pass mark, treating a rise of $4$ percentage points as a $4\%$ rise, or rounding the cut-off down.",
  "C01C-exam-moderation-threshold", "Two changes on different bases (the candidate's own marks and the maximum) followed by an integer cut-off; three distinct traps.",
  tita_answer=96, check=_x10,
  tita_traps=[(87, r"Keeps the old pass mark of $100$: $1.15x \ge 100$ gives $x \ge 86.96$."),
              (91, r"Raises the pass mark by $4\%$ instead of $4$ percentage points: $1.15x \ge 104$ gives $x \ge 90.43$."),
              (95, r"Rounds $95.65$ down; $95$ marks become only $109.25$.")],
  cognitive="Application")


def _x11():
    qs, att = 80, 60
    maxm = 4 * qs
    passm = F(40, 100) * maxm
    for c in range(att + 1):
        if 4 * c - (att - c) >= passm:
            return c
q("C01-C-026", TE, "Minimum correct answers to reach a pass mark with negative marking", "Medium",
  "Casework/optimisation",
  r"A test has $80$ questions. Each correct answer earns $4$ marks, each wrong answer costs $1$ mark, and an unattempted question scores $0$. The pass mark is $40\%$ of the maximum possible marks. Neha attempted exactly $60$ questions. What is the minimum number of questions she must have answered correctly to pass?",
  "MCQ",
  r"The maximum is $320$, so the pass mark is $128$. With $c$ correct out of $60$ attempted, her score is $4c - (60 - c) = 5c - 60 \ge 128$, so $c \ge 37.6$. The minimum is $38$ (score $130$; with $37$ she scores only $125$).",
  "Rounding down, ignoring the penalty, or charging the penalty on unattempted questions.",
  "C01C-exam-negative-marking-pass", "A linear inequality with an integer answer and two marking rules.",
  correct=r"$38$",
  distractors=[(r"$37$", r"Rounds $37.6$ down; $37$ correct gives only $125$ marks."),
               (r"$32$", r"Ignores the penalty: $4c \ge 128$."),
               (r"$42$", r"Charges the penalty on every question not answered correctly: $4c - (80 - c) \ge 128$ gives $c \ge 41.6$.")],
  check=_x11, values=[38, 37, 32, 42], cognitive="Application")


def _x12():
    best = -1
    for a in range(0, 101):
        for b in range(0, 151):
            passed = 100 * a >= 35 * 100 and 100 * b >= 35 * 150 and 100 * (a + b) >= 45 * 250
            if not passed:
                best = max(best, a + b)
    return best
q("C01-C-027", TE, "Highest aggregate with which a candidate can still fail under per-paper and aggregate rules", "Difficult",
  "Casework/optimisation",
  r"An examination has two papers: Paper I carries $100$ marks and Paper II carries $150$ marks. Marks are awarded in whole numbers. To pass, a candidate must score at least $35\%$ in each paper and at least $45\%$ of the aggregate maximum. What is the highest aggregate score with which a candidate can still fail?",
  "MCQ",
  r"There are three ways to fail. Failing Paper I means at most $34$ there, so with full marks in Paper II the aggregate can be $184$. Failing Paper II means at most $52$ there (since $35\%$ of $150$ is $52.5$), so at most $100 + 52 = 152$. Failing only the aggregate rule means at most $112$ (since $45\%$ of $250$ is $112.5$). The highest is $184$.",
  "Considering only the aggregate rule, or allowing the borderline score of $35$ in Paper I to count as a fail.",
  "C01C-exam-max-aggregate-fail", "Casework over three separate failure conditions with integer cut-offs.",
  correct=r"$184$",
  distractors=[(r"$185$", r"Treats $35$ marks in Paper I as failing, giving $35 + 150$."),
               (r"$152$", "Considers only failing Paper II: $100 + 52$."),
               (r"$112$", r"Considers only the aggregate rule: the largest whole number below $112.5$.")],
  check=_x12, values=[184, 185, 152, 112], exams=CX, cognitive="Analysis")


def _x13():
    for n in range(1, 2001):
        for b in range(0, n + 1):
            g = n - b
            pb, pg, pt = F(375, 1000) * b, F(45, 100) * g, F(41, 100) * n
            if pb.denominator == 1 and pg.denominator == 1 and pt.denominator == 1 and pb + pg == pt and b > 0 and g > 0:
                return n
q("C01-C-028", TE, "Smallest number of candidates consistent with exact group and overall pass percentages", "Difficult",
  "Casework/optimisation",
  r"Boys and girls took an examination. Exactly $37.5\%$ of the boys passed, exactly $45\%$ of the girls passed, and exactly $41\%$ of all the candidates passed. What is the smallest possible total number of candidates?",
  "TITA",
  r"From $37.5b + 45g = 41(b + g)$ we get $3.5b = 4g$, so $b : g = 8 : 7$; write $b = 8k$, $g = 7k$. Boys passing $= 3k$ is always whole, but girls passing $= 0.45 \times 7k = 3.15k$ is whole only when $k$ is a multiple of $20$. So $k = 20$: $160$ boys and $140$ girls, $300$ candidates ($60 + 63 = 123 = 41\%$ of $300$).",
  "Stopping at the ratio, or checking only some of the counts for being whole numbers.",
  "C01C-exam-integrality-min-candidates", "A weighted-average ratio followed by a divisibility condition on head counts.",
  tita_answer=300, check=_x13,
  tita_traps=[(15, r"Stops at the ratio $8 : 7$, though $45\%$ of $7$ girls is not a whole number."),
              (100, r"Makes only the overall $41\%$ a whole number.")],
  exams=CX, cognitive="Analysis")


def _x14():
    b = symbols('b', positive=True)
    both = _one(solve(Eq(72 + 64 - 2 * b, Rational(140, 100) * b), b))
    return 72 + 64 - 2 * both
q("C01-C-029", TE, "Share passing exactly one paper from pass rates and a relation between 'exactly one' and 'both'", "Medium",
  "Inverse/parameter",
  r"In an examination with two papers, $72\%$ of the candidates passed Paper I and $64\%$ passed Paper II. The number of candidates who passed exactly one of the two papers was $40\%$ more than the number who passed both. What percentage of the candidates passed exactly one paper?",
  "MCQ",
  r"Let $b\%$ pass both. Those passing exactly one are $(72 - b) + (64 - b) = 136 - 2b$ percent, and this equals $1.4b$. So $3.4b = 136$, $b = 40$, and exactly one paper was passed by $136 - 80 = 56\%$. (Check: $40 + 56 = 96\%$ passed at least one, so $4\%$ failed both.)",
  r"Answering with the share who passed both or at least one, or with those who failed both.",
  "C01C-exam-fail-subjects", "The overlap is unknown and must be found from one linear equation relating two derived groups; a two-step Medium.",
  correct=r"$56\%$",
  distractors=[(r"$40\%$", "Reports the share who passed both papers."),
               (r"$96\%$", "Reports the share who passed at least one paper."),
               (r"$4\%$", "Reports the share who failed both papers.")],
  check=_x14, values=[56, 40, 96, 4], cognitive="Application")


# ============================================================ INCOME, EXPENDITURE AND SAVINGS

def _i1():
    s = symbols('s', positive=True)
    left = s * Rational(70, 100)
    left = left * Rational(75, 100)
    left = left * Rational(80, 100)
    return _one(solve(Eq(left, 16800), s))
q("C01-C-030", TI, "Monthly salary from successive spending on remainders and the amount saved", "Easy",
  "Multi-step word problem",
  r"Fatima spends $30\%$ of her monthly salary on rent, $25\%$ of the remainder on groceries and $20\%$ of what is then left on transport. She saves the remaining Rs. $16{,}800$. What is her monthly salary?",
  "MCQ",
  r"After the three expenses she keeps $0.7 \times 0.75 \times 0.8 = 0.42$ of her salary. Salary $= 16800 \div 0.42 =$ Rs. $40{,}000$.",
  "Adding the three percentages as if each were a share of the whole salary.",
  "C01C-inc-spending-chain", "One chain of three multipliers and one division.",
  correct=r"Rs. $40{,}000$",
  distractors=[(r"Rs. $67{,}200$", r"Adds the percentages: $30 + 25 + 20 = 75\%$ spent, so $16800 \div 0.25$."),
               (r"Rs. $28{,}000$", r"Leaves out the rent: $16800 \div (0.75 \times 0.8)$."),
               (r"Rs. $24{,}000$", r"Applies only the rent: $16800 \div 0.7$.")],
  check=_i1, values=[40000, 67200, 28000, 24000], cognitive="Application")


def _i2():
    b = symbols('b', positive=True)
    return _one(solve(Eq(b + Rational(40, 100) * b + Rational(20, 100) * b + 4000, 52000), b))
q("C01-C-031", TI, "Basic pay from gross salary with allowances as percentages of basic", "Easy",
  "Single-step computation",
  r"Rajesh's gross monthly salary consists of his basic pay, a dearness allowance equal to $40\%$ of the basic pay, a house rent allowance equal to $20\%$ of the basic pay, and a fixed allowance of Rs. $4{,}000$. His gross monthly salary is Rs. $52{,}000$. What is his basic pay, in rupees?",
  "TITA",
  r"Gross $= 1.6 \times \text{basic} + 4000 = 52000$, so $1.6 \times \text{basic} = 48000$ and the basic pay is Rs. $30{,}000$.",
  "Dividing the whole gross by $1.6$ without first removing the fixed allowance.",
  "C01C-inc-salary-components", "One linear equation; the trap is the fixed component.",
  tita_answer=30000, check=_i2,
  tita_traps=[(32500, r"Divides the whole gross by $1.6$: $52000 \div 1.6$."),
              (40000, r"Leaves out the dearness allowance: $48000 \div 1.2$.")],
  cognitive="Application")


def _i3():
    inc = 100
    exp = F(80, 100) * inc
    s0 = inc - exp
    s1 = inc * F(115, 100) - exp * F(110, 100)
    return (s1 - s0) / s0 * 100
q("C01-C-032", TI, "Percentage change in savings when income and expenditure rise at different rates", "Easy",
  "Multi-step word problem",
  r"Ritu saves $20\%$ of her monthly income and spends the rest. Her income rises by $15\%$ and her expenditure rises by $10\%$. By what percentage do her savings increase?",
  "MCQ",
  r"Take income $100$: expenditure $80$, savings $20$. New income $115$, new expenditure $88$, new savings $27$. The increase is $\frac{7}{20} = 35\%$.",
  "Subtracting or adding the two percentage changes.",
  "C01C-inc-savings-change", "Take $100$ and recompute; the trap is combining percentages directly.",
  correct=r"$35\%$",
  distractors=[(r"$5\%$", r"Subtracts the changes: $15 - 10$."),
               (r"$25\%$", r"Adds the changes: $15 + 10$."),
               (r"$15\%$", "Assumes savings rise at the same rate as income.")],
  check=_i3, values=[35, 5, 25, 15], cognitive="Application")


def _i4():
    k_inc, n_inc = 60000, 40000
    sav = F(25, 100) * k_inc + F(40, 100) * n_inc
    return sav / (k_inc + n_inc) * 100
q("C01-C-033", TI, "Household savings rate from two earners' incomes and savings rates", "Easy",
  "Conceptual/application",
  r"Kabir earns Rs. $60{,}000$ a month and saves $25\%$ of it. His wife Nisha earns Rs. $40{,}000$ a month and saves $40\%$ of it. Their combined savings are what percentage of their combined income? Enter the number of percent.",
  "TITA",
  r"Kabir saves Rs. $15{,}000$ and Nisha Rs. $16{,}000$, a total of Rs. $31{,}000$ out of Rs. $1{,}00{,}000$, which is $31\%$.",
  "Averaging the two savings rates without weighting by income, or weighting them the wrong way round.",
  "C01C-inc-household-rate-weighted", "A weighted average of two rates.",
  tita_answer=31, check=_i4,
  tita_traps=[(65, r"Adds the two rates: $25 + 40$."),
              (34, r"Swaps the incomes: $0.25 \times 40000 + 0.4 \times 60000 = 34000$.")],
  cognitive="Understanding")


def _i5():
    inc0, rate0 = 100, F(25, 100)
    inc1, rate1 = inc0 * F(120, 100), rate0 + F(5, 100)
    return (inc1 * rate1 - inc0 * rate0) / (inc0 * rate0) * 100
q("C01-C-034", TI, "Change in the amount saved when income and the savings rate (in percentage points) both rise", "Easy",
  "Conceptual/application",
  r"Last year Arun saved $25\%$ of his income. This year his income is $20\%$ higher, and his savings, as a percentage of income, are $5$ percentage points higher than last year. By what percentage has the amount he saves increased?",
  "MCQ",
  r"Take last year's income as $100$: savings $25$. This year income is $120$ and the savings rate is $30\%$, so savings are $36$. The increase is $\frac{11}{25} = 44\%$.",
  r"Treating the $5$ percentage point rise as a $5\%$ rise, or adding the changes.",
  "C01C-inc-amount-from-rate-and-base", "A rate change in percentage points combined with a base change.",
  correct=r"$44\%$",
  distractors=[(r"$25\%$", r"Adds $20$ and $5$."),
               (r"$26\%$", r"Treats the rate rise as $5\%$: $1.2 \times 1.05 = 1.26$."),
               (r"$40\%$", r"Sees that $5$ points on $25$ is a $20\%$ rise and adds it to the $20\%$ rise in income.")],
  check=_i5, values=[44, 25, 26, 40], cognitive="Understanding")


def _i6():
    x = symbols('x')
    inc, exp = 100, 80
    return _one(solve(Eq(inc * Rational(125, 100) - exp * (1 + x / 100), (inc - exp) * Rational(105, 100)), x))
q("C01-C-035", TI, "Permitted rise in expenditure for a target rise in savings", "Medium",
  "Inverse/parameter",
  r"Deepa saves $20\%$ of her income and spends the rest. Her income is to rise by $25\%$, and she wants her savings to rise by exactly $5\%$. By what percentage can her expenditure rise?",
  "MCQ",
  r"Take income $100$: expenditure $80$, savings $20$. New income $125$ and new savings $21$, so new expenditure is $104$. The rise is $\frac{24}{80} = 30\%$.",
  "Subtracting the two percentages, or measuring the extra expenditure against the old income.",
  "C01C-inc-savings-change", "Working backwards to expenditure from targets on income and savings.",
  correct=r"$30\%$",
  distractors=[(r"$20\%$", r"Subtracts the changes: $25 - 5$."),
               (r"$25\%$", "Assumes expenditure rises at the same rate as income."),
               (r"$24\%$", r"Divides the extra expenditure of $24$ by the old income $100$, not by the old expenditure $80$.")],
  check=_i6, values=[30, 20, 25, 24], cognitive="Application")


def _i7():
    s = symbols('s', positive=True)
    return _one(solve(Eq(Rational(150, 100) * s * Rational(20, 100) + s * Rational(30, 100), 24000), s))
q("C01-C-036", TI, "One earner's income from a household's combined savings", "Medium",
  "Multi-step word problem",
  r"Anil earns $50\%$ more than his wife Sunita. Anil saves $20\%$ of his income and Sunita saves $30\%$ of hers. Together they save Rs. $24{,}000$ a month. What is Sunita's monthly income, in rupees?",
  "TITA",
  r"If Sunita earns $s$, Anil earns $1.5s$. Savings: $0.2 \times 1.5s + 0.3s = 0.6s = 24000$, so $s =$ Rs. $40{,}000$.",
  "Averaging the two savings rates without weighting, or reporting Anil's income.",
  "C01C-inc-two-earners-solve", "One unknown linked through a percentage, then a weighted sum.",
  tita_answer=40000, check=_i7,
  tita_traps=[(60000, "Reports Anil's income."),
              (38400, r"Uses the simple average rate $25\%$ on the household income $2.5s$: $0.625s = 24000$.")],
  cognitive="Application")


def _i8():
    b = symbols('b', positive=True)
    da = Rational(50, 100) * b
    gross = b + da + 4000
    pf = Rational(10, 100) * (b + da)
    return _one(solve(Eq(gross - pf, 41800), b))
q("C01-C-037", TI, "Basic pay from in-hand salary with a deduction on part of the salary", "Medium",
  "Multi-step word problem",
  r"Vikram's monthly salary consists of his basic pay, a dearness allowance equal to $50\%$ of the basic pay, and a travel allowance of Rs. $4{,}000$. Each month, $10\%$ of the sum of his basic pay and dearness allowance is deducted for his provident fund, and nothing else is deducted. His in-hand salary is Rs. $41{,}800$. What is his basic pay?",
  "MCQ",
  r"Let the basic be $b$. Basic plus dearness allowance is $1.5b$, the deduction is $0.15b$, so the in-hand salary is $1.35b + 4000 = 41800$. Then $1.35b = 37800$ and $b =$ Rs. $28{,}000$.",
  "Ignoring the deduction, or applying it to the basic pay alone.",
  "C01C-inc-salary-components", "Two percentage components on different bases plus a fixed amount.",
  correct=r"Rs. $28{,}000$",
  distractors=[(r"Rs. $25{,}200$", r"Ignores the deduction: $1.5b + 4000 = 41800$."),
               (r"Rs. $27{,}000$", r"Deducts $10\%$ of the basic only: $1.4b + 4000 = 41800$."),
               (r"Rs. $42{,}000$", "Reports the basic pay plus dearness allowance.")],
  check=_i8, values=[28000, 25200, 27000, 42000], cognitive="Application")


def _i9():
    inc, ex = symbols('inc ex', positive=True)
    sol = solve([Eq(inc - ex, 9000), Eq(Rational(110, 100) * inc - Rational(115, 100) * ex, 9000 - 1500)],
                [inc, ex], dict=True)[0]
    return sol[inc]
q("C01-C-038", TI, "Original income from changes in income and expenditure and the fall in savings", "Medium",
  "Inverse/parameter",
  r"Mohan saved Rs. $9{,}000$ a month. Then his monthly income rose by $10\%$ and his monthly expenditure rose by $15\%$, and his monthly savings fell by Rs. $1{,}500$. What was his original monthly income, in rupees?",
  "TITA",
  r"Let the original expenditure be $e$, so income is $e + 9000$. New savings: $1.1(e + 9000) - 1.15e = 7500$, so $9900 - 0.05e = 7500$, $e = 48000$. The original income was Rs. $57{,}000$.",
  "Reporting the expenditure, or forgetting that the savings base also grows with income.",
  "C01C-inc-savings-fall-solve", "Two unknowns linked by a fixed savings amount and two different growth rates.",
  tita_answer=57000, check=_i9,
  tita_traps=[(48000, "Reports the original expenditure."),
              (39000, r"Sets the fall of Rs. $1500$ equal to $0.05e$, giving $e = 30000$ and income $39000$.")],
  cognitive="Application")


def _i10():
    a, ea = symbols('a ea', positive=True)
    sol = solve([Eq(a - ea, 12000), Eq(a / Rational(125, 100) - ea / Rational(140, 100), 12000)], [a, ea], dict=True)[0]
    return sol[a]
q("C01-C-039", TI, "Income of one earner when two people save equal amounts", "Medium",
  "Multi-step word problem",
  r"Arjun earns $25\%$ more than his brother Varun and spends $40\%$ more than Varun. Each of them saves Rs. $12{,}000$ a month. What is Arjun's monthly income?",
  "MCQ",
  r"Let Varun earn $v$ and spend $e$, so $v - e = 12000$ and $1.25v - 1.4e = 12000$. Substituting $v = e + 12000$: $1.25e + 15000 - 1.4e = 12000$, so $0.15e = 3000$ and $e = 20000$. Then $v = 32000$ and Arjun earns $1.25 \times 32000 =$ Rs. $40{,}000$.",
  r"Reporting Varun's income or Arjun's expenditure, or attaching the $40\%$ rise to income instead of the $25\%$ rise.",
  "C01C-inc-two-earners-solve", "Two simultaneous conditions with percentages on different bases.",
  correct=r"Rs. $40{,}000$",
  distractors=[(r"Rs. $32{,}000$", "Reports Varun's income."),
               (r"Rs. $28{,}000$", "Reports Arjun's expenditure."),
               (r"Rs. $44{,}800$", r"Applies the $40\%$ rise to Varun's income instead of the $25\%$: $1.4 \times 32000 = 44{,}800$.")],
  check=_i10, values=[40000, 32000, 28000, 44800], cognitive="Application")


def _i11():
    i = symbols('i', positive=True)
    def savings(x, food):
        left = x - 12000
        left = left * (1 - food)
        left = left * Rational(80, 100)
        return left
    old = savings(i, Rational(25, 100))
    new = savings(i * Rational(120, 100), Rational(30, 100))
    return _one(solve(Eq(new - old, 3360), i))
q("C01-C-040", TI, "Original income from the rise in savings when rent is fixed and the food share changes", "Difficult",
  "Inverse/parameter",
  r"Joseph pays a fixed rent of Rs. $12{,}000$ a month. Of the income left after rent, he spends $25\%$ on food, then $20\%$ of what remains on travel, and saves the rest. His income then rises by $20\%$. The rent stays Rs. $12{,}000$, his food spending becomes $30\%$ of the income left after rent, he still spends $20\%$ of what then remains on travel, and he saves the rest. His monthly savings rise by Rs. $3{,}360$. What was his original monthly income?",
  "MCQ",
  r"Let the original income be $I$. Savings were $0.75 \times 0.8 = 0.6$ of $(I - 12000)$ and are now $0.7 \times 0.8 = 0.56$ of $(1.2I - 12000)$. So $0.56(1.2I - 12000) - 0.6(I - 12000) = 0.072I + 480 = 3360$, giving $0.072I = 2880$ and $I =$ Rs. $40{,}000$. Check: savings go from $0.6 \times 28000 = 16800$ to $0.56 \times 36000 = 20160$.",
  r"Ignoring the change in the food share, applying the new percentages only to the raise, or reporting the new income.",
  "C01C-inc-spending-chain", "Three stages (fixed rent, a changed share, a chained percentage) on two incomes, solved backwards from a rise in savings.",
  correct=r"Rs. $40{,}000$",
  distractors=[(r"Rs. $28{,}000$", r"Keeps the food share at $25\%$: $0.6(1.2I - 12000) - 0.6(I - 12000) = 0.12I = 3360$."),
               (r"Rs. $30{,}000$", r"Applies the new food and travel percentages only to the raise: $0.56 \times 0.2I = 3360$."),
               (r"Rs. $48{,}000$", r"Reports the new income, $1.2 \times 40000$.")],
  check=_i11, values=[40000, 28000, 30000, 48000], exams=CX, cognitive="Analysis")


def _i12():
    inc0 = 100
    exp0 = inc0 - F(25, 100) * inc0
    inc1, exp1 = inc0 * F(120, 100), exp0 * F(112, 100)
    return (inc1 - exp1) / inc1 * 100
q("C01-C-041", TI, "New savings rate after income and expenditure rise by different percentages", "Medium",
  "Conceptual/application",
  r"Pallavi used to save $25\%$ of her income and spend the rest. Her income then rose by $20\%$ and her expenditure rose by $12\%$. Her savings are now what percentage of her new income? Enter the number of percent.",
  "TITA",
  r"Take the old income as $100$: expenditure $75$, savings $25$. New income $120$, new expenditure $75 \times 1.12 = 84$, new savings $36$. The new rate is $\frac{36}{120} = 30\%$.",
  "Combining the percentage changes directly on the savings rate, or dividing the new savings by the old income.",
  "C01C-inc-savings-change", r"The expenditure change applies to $75\%$ of income, and the new rate needs the new income as its base.",
  tita_answer=30, check=_i12,
  tita_traps=[(33, r"Adds and subtracts the changes on the rate: $25 + 20 - 12$."),
              (36, r"Divides the new savings of $36$ by the old income of $100$."),
              (28, r"Applies the $12\%$ rise to the savings rate itself: $25 \times 1.12$.")],
  cognitive="Understanding")


def _i13():
    h, w = 50, 50
    sh0, sw0 = F(20, 100) * h, F(30, 100) * w
    eh, ew = h - sh0, w - sw0
    h1, w1 = h * F(110, 100), w * F(90, 100)
    s1 = (h1 - eh * F(115, 100)) + (w1 - ew)
    s0 = sh0 + sw0
    return (s1 - s0) / s0 * 100
q("C01-C-042", TI, "Change in household savings when two earners' incomes and expenses move differently", "Difficult",
  "Multi-step word problem",
  r"A husband and wife earn equal incomes. The husband saves $20\%$ of his income and the wife saves $30\%$ of hers. Next year the husband's income rises by $10\%$ and his expenditure by $15\%$, while the wife's income falls by $10\%$ and her expenditure stays the same. What is the percentage change in their combined savings?",
  "MCQ",
  r"Take each income as $100$. Savings now: $20 + 30 = 50$. Next year the husband earns $110$ and spends $80 \times 1.15 = 92$, saving $18$; the wife earns $90$ and spends $70$, saving $20$. Combined savings $38$, a fall of $\frac{12}{50} = 24\%$.",
  "Letting the wife's expenditure fall with her income, or reporting the fall in percentage points of income.",
  "C01C-inc-household-savings-change", "Four separate changes over two people; the trap is percent versus percentage points.",
  correct=r"A decrease of $24\%$",
  distractors=[(r"A decrease of $10\%$", r"Lets the wife's expenditure fall by $10\%$ with her income, so she still saves $27$ and the total is $45$."),
               (r"A decrease of $6\%$", r"Reports the fall in the household savings rate, from $25\%$ to $19\%$ of an unchanged combined income of $200$, as the percentage change."),
               (r"A decrease of $4\%$", r"Applies only the husband's changes, so the total is $18 + 30 = 48$.")],
  check=_i13, values=[-24, -10, -6, -4], exams=CX, cognitive="Analysis")


def _i14():
    x = symbols('x', positive=True)
    rent = 25
    others = _one(solve(Eq(120 - rent - Rational(110, 100) * x, Rational(160, 100) * (100 - rent - x)), x))
    return 100 - rent - others
q("C01-C-043", TI, "Original savings rate when one expense is fixed and the rest grow at a different rate", "Difficult",
  "Inverse/parameter",
  r"Kavya spends $25\%$ of her income on rent, spends some more on other expenses, and saves the rest. Her income then rises by $20\%$, her rent stays the same in rupees, and her other expenses rise by $10\%$. As a result her savings rise by $60\%$. What percentage of her original income was she saving?",
  "MCQ",
  r"Take the original income as $100$, rent $25$, other expenses $x$, savings $75 - x$. New savings $= 120 - 25 - 1.1x = 95 - 1.1x$, and this equals $1.6(75 - x) = 120 - 1.6x$. So $0.5x = 25$, $x = 50$, and she was saving $25\%$.",
  "Letting the rent grow with income or with the other expenses.",
  "C01C-inc-fixed-variable-expense", "Three expense types behave differently; one equation after taking $100$.",
  correct=r"$25\%$",
  distractors=[(r"$20\%$", r"Lets the rent rise by $10\%$ along with the other expenses: $0.5x = 27.5$, savings $20$."),
               (r"$15\%$", r"Lets the rent rise by $20\%$ with income: $0.5x = 30$, savings $15$."),
               (r"$50\%$", "Reports the share spent on other expenses.")],
  check=_i14, values=[25, 20, 15, 50], exams=CX, cognitive="Analysis")


def _i15():
    p = symbols('p')
    w = 100
    h = Rational(150, 100) * w
    return _one(solve(Eq(h * p / 100 + w * Rational(35, 100), Rational(26, 100) * (h + w)), p)) - 10
q("C01-C-044", TI, "Rise in one earner's savings rate needed for a target household savings rate", "Difficult",
  "Inverse/parameter",
  r"Rahul earns $1.5$ times as much as his wife Ayesha. Rahul saves $10\%$ of his income and Ayesha saves $35\%$ of hers. They want their combined savings to be $26\%$ of their combined income, with incomes unchanged and only Rahul changing how much he saves. By how many percentage points must Rahul's savings rate rise?",
  "MCQ",
  r"Take Ayesha's income as $100$ and Rahul's as $150$. Current savings: $15 + 35 = 50$, which is $20\%$ of $250$. The target is $0.26 \times 250 = 65$, so Rahul must save $30$ of his $150$, a rate of $20\%$. His rate rises by $10$ percentage points.",
  "Using the household gap of $6$ points directly, or measuring the extra savings against the wrong income.",
  "C01C-inc-household-rate-weighted", "The household rate is a weighted average; the extra savings must be re-based on one earner's income.",
  correct=r"$10$ percentage points",
  distractors=[(r"$6$ percentage points", r"Takes the household gap $26 - 20 = 6$ as Rahul's required rise."),
               (r"$15$ percentage points", r"Measures the extra savings of $15$ against Ayesha's income of $100$."),
               (r"$9$ percentage points", r"Scales the $6$-point gap by the income ratio $1.5$ rather than by $\frac{250}{150}$.")],
  check=_i15, values=[10, 6, 15, 9], exams=CX, cognitive="Analysis")


def _i16():
    h = symbols('h')
    m_inc, hu_inc = 25, 75
    hr = _one(solve(Eq(m_inc * Rational(40, 100) + hu_inc * h, Rational(25, 100) * 100), h))
    m1 = 2 * m_inc
    return (m1 * Rational(40, 100) + hu_inc * hr) / (m1 + hu_inc) * 100
q("C01-C-045", TI, "New household savings rate after one earner's income doubles", "Difficult",
  "Conceptual/application",
  r"In a two-earner household, Meera earns $25\%$ of the household income and saves $40\%$ of her income. The household as a whole saves $25\%$ of its income. Next year Meera's income doubles, her husband's income is unchanged, and each keeps the same savings rate as before. What percentage of the new household income will the household save?",
  "MCQ",
  r"Take the household income as $100$: Meera $25$ (saves $10$), husband $75$. The household saves $25$, so the husband saves $15$, a rate of $20\%$. Next year Meera earns $50$ and saves $20$; the husband still saves $15$. That is $35$ out of $125$, or $28\%$.",
  "Averaging the two rates without weights, or forgetting that the household income also grows.",
  "C01C-inc-household-rate-weighted", "First recover the husband's rate, then re-weight with the new income shares.",
  correct=r"$28\%$",
  distractors=[(r"$30\%$", r"Takes the simple average of the two rates, $40\%$ and $20\%$."),
               (r"$35\%$", r"Divides the new savings of $35$ by the old household income of $100$."),
               (r"$25\%$", "Assumes the household rate stays the same because each person's rate is unchanged.")],
  check=_i16, values=[28, 30, 35, 25], exams=CX, cognitive="Analysis")
