import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Roots and coefficients"
CX = ("CAT", "XAT")
x = symbols('x')


def _rts(expr):
    """Roots of a quadratic in x, listed with multiplicity (exact)."""
    d = roots(Poly(expand(expr), x))
    out = []
    for r, m in d.items():
        out += [r] * m
    assert len(out) == 2, out
    return out


def _val(expr, f):
    """Evaluate a symmetric expression f(alpha, beta) on the actual roots of expr."""
    a, b = _rts(expr)
    return nsimplify(simplify(expand(f(a, b))))


def _m(poly):
    """Monic form of a quadratic in x, so that equations are compared up to scaling."""
    P = Poly(expand(poly), x)
    return expand(P.as_expr() / P.LC())


def _eq(r1, r2):
    """Monic quadratic with roots r1, r2, built from the actual roots."""
    return expand(x**2 - nsimplify(simplify(expand(r1 + r2))) * x + nsimplify(simplify(expand(r1 * r2))))


def _isq(n):
    return n >= 0 and math.isqrt(n) ** 2 == n


# ================================================================ EASY

def _c1():
    return _val(2*x**2 - 9*x + 6, lambda a, b: a + b + a*b)
q("C10-A-001", T, "Value of sum plus product of roots of a non-monic quadratic", "Easy",
  "Single-step computation",
  r"If $p$ and $q$ are the roots of $2x^2 - 9x + 6 = 0$, then $p + q + pq$ equals",
  "MCQ",
  r"For $ax^2 + bx + c = 0$ the sum of the roots is $-\frac{b}{a}$ and the product is $\frac{c}{a}$. Here $p + q = \frac{9}{2}$ and $pq = \frac{6}{2} = 3$, so $p + q + pq = \frac{9}{2} + 3 = \frac{15}{2}$.",
  r"Taking the sum of the roots as $\frac{b}{a}$, or not dividing the constant term by the leading coefficient.",
  "C10A-vieta-direct", "One application of the sum and product formulas with a leading coefficient other than $1$.",
  correct=r"$\frac{15}{2}$",
  distractors=[(r"$-\frac{3}{2}$", r"Takes the sum of the roots as $\frac{b}{a} = -\frac{9}{2}$: $-\frac{9}{2} + 3 = -\frac{3}{2}$."),
               (r"$\frac{21}{2}$", r"Takes the product as $c = 6$ without dividing by $a$: $\frac{9}{2} + 6 = \frac{21}{2}$."),
               (r"$-\frac{15}{2}$", r"Swaps both signs, using sum $\frac{b}{a} = -\frac{9}{2}$ and product $-\frac{c}{a} = -3$: total $-\frac{15}{2}$.")],
  check=_c1, values=[Rational(15, 2), Rational(-3, 2), Rational(21, 2), Rational(-15, 2)], cognitive="Recall")


def _c2():
    return _val(x**2 - 11*x + 19, lambda a, b: a**2 + b**2)
q("C10-A-002", T, "Sum of squares of the roots from sum and product", "Easy",
  "Single-step computation",
  r"The roots of $x^2 - 11x + 19 = 0$ are $\alpha$ and $\beta$. What is the value of $\alpha^2 + \beta^2$?",
  "TITA",
  r"$\alpha + \beta = 11$ and $\alpha\beta = 19$. So $\alpha^2 + \beta^2 = (\alpha + \beta)^2 - 2\alpha\beta = 121 - 38 = 83$.",
  r"Subtracting $\alpha\beta$ only once, or adding $2\alpha\beta$ instead of subtracting it.",
  "C10A-sum-squares-and-difference", "Direct use of the identity $\\alpha^2 + \\beta^2 = (\\alpha+\\beta)^2 - 2\\alpha\\beta$.",
  tita_answer=83, check=_c2,
  tita_traps=[(102, r"Subtracts $\alpha\beta$ once: $121 - 19$."), (159, r"Adds $2\alpha\beta$: $121 + 38$.")],
  cognitive="Recall")


def _c3():
    return _val(4*x**2 - 12*x + 5, lambda a, b: 1/a + 1/b)
q("C10-A-003", T, "Sum of reciprocals of the roots", "Easy",
  "Single-step computation",
  r"If $\alpha$ and $\beta$ are the roots of $4x^2 - 12x + 5 = 0$, then $\frac{1}{\alpha} + \frac{1}{\beta}$ equals",
  "MCQ",
  r"$\frac{1}{\alpha} + \frac{1}{\beta} = \frac{\alpha + \beta}{\alpha\beta}$. Here $\alpha + \beta = \frac{12}{4} = 3$ and $\alpha\beta = \frac{5}{4}$, so the value is $3 \times \frac{4}{5} = \frac{12}{5}$.",
  "Inverting the ratio, writing product over sum.",
  "C10A-reciprocal-and-ratio-sums", "One identity, sum over product.",
  correct=r"$\frac{12}{5}$",
  distractors=[(r"$\frac{5}{12}$", r"Writes $\frac{\alpha\beta}{\alpha + \beta} = \frac{5/4}{3} = \frac{5}{12}$."),
               (r"$-\frac{12}{5}$", r"Takes the sum of the roots as $-3$: $\frac{-3}{5/4} = -\frac{12}{5}$."),
               (r"$\frac{1}{3}$", r"Treats $\frac{1}{\alpha} + \frac{1}{\beta}$ as $\frac{1}{\alpha + \beta} = \frac{1}{3}$.")],
  check=_c3, values=[Rational(12, 5), Rational(5, 12), Rational(-12, 5), Rational(1, 3)], cognitive="Recall")


def _c4():
    p = symbols('p')
    sol = solve(Eq(8**2 - p*8 + 72, 0), p)
    return sol[0]
q("C10-A-004", T, "Coefficient of x from one known root and the constant term", "Easy",
  "Inverse/parameter",
  r"One root of the equation $x^2 - px + 72 = 0$ is $8$. What is the value of $p$?",
  "TITA",
  r"The product of the roots is $72$, so the other root is $\frac{72}{8} = 9$. Then $p$ is the sum of the roots: $p = 8 + 9 = 17$.",
  "Reporting the other root instead of the coefficient.",
  "C10A-one-root-given", "One division and one addition using Vieta's relations.",
  tita_answer=17, check=_c4,
  tita_traps=[(9, r"Reports the other root $\frac{72}{8}$."), (1, r"Takes $p$ as the difference of the roots, $9 - 8$.")],
  cognitive="Application")


def _c5():
    k = symbols('k')
    D = (2*(k + 1))**2 - 4*(9*k - 5)
    return sum(solve(Eq(D, 0), k))
q("C10-A-005", T, "Sum of parameter values that give equal roots", "Easy",
  "Inverse/parameter",
  r"Find the sum of all real values of $k$ for which the equation $x^2 - 2(k+1)x + 9k - 5 = 0$ has equal roots.",
  "TITA",
  r"Equal roots need the discriminant to be zero: $4(k+1)^2 - 4(9k - 5) = 0$, that is $k^2 + 2k + 1 - 9k + 5 = k^2 - 7k + 6 = 0$. So $k = 1$ or $k = 6$, and the sum is $7$.",
  "Stopping at one value of $k$, or taking the sum of the roots of the $k$ equation with the wrong sign.",
  "C10A-equal-roots-parameter", "Set the discriminant to zero and add the resulting values.",
  tita_answer=7, check=_c5,
  tita_traps=[(6, r"Reports only the larger value $k = 6$."), (2, r"Counts the values of $k$ instead of adding them.")],
  cognitive="Application")


def _c6():
    a, b = _rts(x**2 - 7*x + 11)
    return _eq(a + 2, b + 2)
q("C10-A-006", T, "Equation whose roots are the given roots increased by 2", "Easy",
  "Single-step computation",
  r"The roots of $x^2 - 7x + 11 = 0$ are $\alpha$ and $\beta$. The quadratic equation whose roots are $\alpha + 2$ and $\beta + 2$ is",
  "MCQ",
  r"New sum $= (\alpha + \beta) + 4 = 7 + 4 = 11$. New product $= \alpha\beta + 2(\alpha + \beta) + 4 = 11 + 14 + 4 = 29$. The equation is $x^2 - 11x + 29 = 0$. (Equivalently, replace $x$ by $x - 2$ in the original equation.)",
  "Replacing $x$ by $x + 2$, which lowers each root by $2$, or dropping the cross term $2(\\alpha + \\beta)$ in the product.",
  "C10A-linear-transformed-roots", "One substitution or one sum-and-product update.",
  correct=r"$x^2 - 11x + 29 = 0$",
  distractors=[(r"$x^2 - 3x + 1 = 0$", r"Replaces $x$ by $x + 2$: $(x+2)^2 - 7(x+2) + 11 = x^2 - 3x + 1$, whose roots are $\alpha - 2$ and $\beta - 2$."),
               (r"$x^2 - 11x + 15 = 0$", r"Takes the new product as $\alpha\beta + 4 = 15$, dropping $2(\alpha + \beta)$."),
               (r"$x^2 - 11x + 25 = 0$", r"Takes the new product as $\alpha\beta + 2(\alpha + \beta) = 25$, dropping the $+4$.")],
  check=_c6, values=[x**2 - 11*x + 29, x**2 - 3*x + 1, x**2 - 11*x + 15, x**2 - 11*x + 25], cognitive="Application")


def _c7():
    a, b = _rts(x**2 - 19*x + 84)
    return a**2 + b**2
q("C10-A-007", T, "Square on the diagonal of a rectangle whose sides are roots", "Easy",
  "Multi-step word problem",
  r"The length and the breadth, in metres, of a rectangular garden are the two roots of $x^2 - 19x + 84 = 0$. A square lawn is laid out whose side is equal to the diagonal of the garden. What is the area of the square lawn, in m$^2$?",
  "TITA",
  r"The area of the square is the square of the diagonal, $l^2 + b^2 = (l + b)^2 - 2lb = 19^2 - 2 \times 84 = 361 - 168 = 193$ m$^2$.",
  "Using $(l+b)^2 - lb$ or $(l+b)^2 - 4lb$ in place of $(l+b)^2 - 2lb$.",
  "C10A-roots-as-dimensions", "One identity applied in a short geometric setting.",
  tita_answer=193, check=_c7,
  tita_traps=[(277, r"Computes $361 - 84$."), (25, r"Computes $(l - b)^2 = 361 - 336$."), (361, r"Squares the sum of the sides.")],
  cognitive="Application")


def _c8():
    p, r = symbols('p r', nonzero=True)
    qq = -p - r
    return _m(p*x**2 + qq*x + r)
_P8, _R8 = symbols('p r', nonzero=True)
q("C10-A-008", T, "Roots of a quadratic whose coefficients add up to zero", "Easy",
  "Conceptual/application",
  r"The real numbers $p$, $q$, $r$ satisfy $p + q + r = 0$, with $p \neq 0$. The roots of $px^2 + qx + r = 0$ are",
  "MCQ",
  r"Putting $x = 1$ in the equation gives $p + q + r$, which is $0$, so $1$ is a root. The product of the roots is $\frac{r}{p}$, so the other root is $\frac{r}{p} \div 1 = \frac{r}{p}$. The roots are $1$ and $\frac{r}{p}$.",
  "Linking a zero coefficient sum with the root $-1$, or using the product with the wrong sign.",
  "C10A-root-from-coefficient-sum", "One observation (the coefficient sum is the value at $x = 1$) and one use of the product of roots.",
  correct=r"$1$ and $\frac{r}{p}$",
  distractors=[(r"$-1$ and $-\frac{r}{p}$", r"Believes a zero coefficient sum makes $-1$ a root, then divides the product $\frac{r}{p}$ by $-1$."),
               (r"$1$ and $-\frac{r}{p}$", r"Spots the root $1$ but takes the product of the roots as $-\frac{r}{p}$."),
               (r"$1$ and $-\frac{q}{p}$", r"Spots the root $1$ but reports the sum of the roots $-\frac{q}{p}$ as the other root.")],
  check=_c8, values=[expand((x - 1)*(x - _R8/_P8)), expand((x + 1)*(x + _R8/_P8)),
                     expand((x - 1)*(x + _R8/_P8)), expand((x - 1)*(x - (_P8 + _R8)/_P8))],
  cognitive="Understanding")


def _c9():
    k, t = symbols('k t')
    sol = solve([Eq(2*t + 3*t, 15), Eq(2*t*3*t, k)], [t, k], dict=True)
    return sol[0][k]
q("C10-A-009", T, "Constant term when the roots are in a given ratio", "Easy",
  "Inverse/parameter",
  r"The roots of $x^2 - 15x + k = 0$ are in the ratio $2 : 3$. What is the value of $k$?",
  "MCQ",
  r"Let the roots be $2t$ and $3t$. Their sum is $5t = 15$, so $t = 3$ and the roots are $6$ and $9$. Hence $k = 6 \times 9 = 54$.",
  "Forgetting that the product of $2t$ and $3t$ is $6t^2$, not $6t$.",
  "C10A-roots-ratio-or-power-relation", "One unknown scale factor from the sum, then the product.",
  correct=r"$54$",
  distractors=[(r"$18$", r"Writes the product as $6t$ with $t = 3$."),
               (r"$270$", r"Uses $mn\,b^2 = (m+n)^2 ac$ without squaring $m + n$: $6 \times 225 = 5k$."),
               (r"$50$", r"Reads $2 : 3$ as the ratio of one root to the sum, getting roots $10$ and $5$.")],
  check=_c9, values=[54, 18, 270, 50], cognitive="Application")


def _c10():
    k = symbols('k')
    s = 13
    return solve(Eq(s**2 - 4*k, 5**2), k)[0]
q("C10-A-010", T, "Constant term when the roots differ by a given amount", "Easy",
  "Inverse/parameter",
  r"The two roots of $x^2 - 13x + k = 0$ differ by $5$. What is the value of $k$?",
  "MCQ",
  r"$(\alpha - \beta)^2 = (\alpha + \beta)^2 - 4\alpha\beta$, so $25 = 169 - 4k$ and $k = 36$. (The roots are $9$ and $4$.)",
  "Using $2\\alpha\\beta$ in place of $4\\alpha\\beta$ in the identity for $(\\alpha - \\beta)^2$.",
  "C10A-roots-differ-by", "One identity linking the difference of roots to sum and product.",
  correct=r"$36$",
  distractors=[(r"$72$", r"Uses $(\alpha - \beta)^2 = (\alpha + \beta)^2 - 2\alpha\beta$: $25 = 169 - 2k$."),
               (r"$144$", r"Uses $(\alpha - \beta)^2 = (\alpha + \beta)^2 - \alpha\beta$: $25 = 169 - k$."),
               (r"$41$", r"Does not square the difference: $5 = 169 - 4k$ gives $k = 41$.")],
  check=_c10, values=[36, 72, 144, 41], cognitive="Application")


def _c11():
    return _val(x**2 - 6*x + 4, lambda a, b: a/b + b/a)
q("C10-A-011", T, "Sum of the ratios of the roots", "Easy",
  "Single-step computation",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 6x + 4 = 0$, what is the value of $\frac{\alpha}{\beta} + \frac{\beta}{\alpha}$?",
  "TITA",
  r"$\frac{\alpha}{\beta} + \frac{\beta}{\alpha} = \frac{\alpha^2 + \beta^2}{\alpha\beta} = \frac{(\alpha+\beta)^2 - 2\alpha\beta}{\alpha\beta} = \frac{36 - 8}{4} = 7$.",
  "Dropping the $-2\\alpha\\beta$ term, or subtracting $4\\alpha\\beta$.",
  "C10A-reciprocal-and-ratio-sums", "Combine the fractions and use the sum-of-squares identity.",
  tita_answer=7, check=_c11,
  tita_traps=[(9, r"Uses $\frac{(\alpha+\beta)^2}{\alpha\beta} = \frac{36}{4}$."), (5, r"Subtracts $4\alpha\beta$: $\frac{36 - 16}{4}$.")],
  cognitive="Application")


def _c12():
    a, b = _rts(3*x**2 - 10*x + 2)
    return simplify(Abs(a - b))
q("C10-A-012", T, "Positive difference of the roots from the discriminant", "Easy",
  "Single-step computation",
  r"The positive difference between the roots of $3x^2 - 10x + 2 = 0$ is",
  "MCQ",
  r"For $ax^2 + bx + c = 0$ the difference of the roots is $\frac{\sqrt{b^2 - 4ac}}{|a|}$. Here $b^2 - 4ac = 100 - 24 = 76$, so the difference is $\frac{\sqrt{76}}{3} = \frac{2\sqrt{19}}{3}$.",
  "Not dividing by $a$, or dividing by $2a$, or using $4c$ in place of $4ac$.",
  "C10A-sum-squares-and-difference", "One formula; the trap is the denominator.",
  correct=r"$\frac{2\sqrt{19}}{3}$",
  distractors=[(r"$2\sqrt{19}$", r"Takes $\sqrt{b^2 - 4ac} = \sqrt{76}$ without dividing by $a$."),
               (r"$\frac{2\sqrt{23}}{3}$", r"Uses $b^2 - 4c = 100 - 8 = 92$ and divides by $3$."),
               (r"$\frac{\sqrt{19}}{3}$", r"Divides $\sqrt{76}$ by $2a = 6$, the denominator of the root formula.")],
  check=_c12, values=[2*sqrt(19)/3, 2*sqrt(19), 2*sqrt(23)/3, sqrt(19)/3], cognitive="Recall")


def _c13():
    a, b = _rts(2*x**2 - 5*x - 3)
    return _eq(3*a, 3*b)
q("C10-A-013", T, "Equation whose roots are three times the given roots", "Easy",
  "Single-step computation",
  r"The roots of $2x^2 - 5x - 3 = 0$ are $\alpha$ and $\beta$. The equation whose roots are $3\alpha$ and $3\beta$ is",
  "MCQ",
  r"Replace $x$ by $\frac{x}{3}$: $2 \cdot \frac{x^2}{9} - 5 \cdot \frac{x}{3} - 3 = 0$, and multiplying by $9$ gives $2x^2 - 15x - 27 = 0$. Check: sum $= 3 \times \frac{5}{2} = \frac{15}{2}$ and product $= 9 \times \left(-\frac{3}{2}\right) = -\frac{27}{2}$.",
  "Replacing $x$ by $3x$ instead of $\\frac{x}{3}$, or scaling the product by $3$ instead of $9$.",
  "C10A-linear-transformed-roots", "One substitution; the trap is the direction of the scaling.",
  correct=r"$2x^2 - 15x - 27 = 0$",
  distractors=[(r"$6x^2 - 5x - 1 = 0$", r"Replaces $x$ by $3x$, which gives the equation with roots $\frac{\alpha}{3}$ and $\frac{\beta}{3}$."),
               (r"$2x^2 - 15x - 9 = 0$", r"Multiplies the product of the roots by $3$ instead of $9$."),
               (r"$2x^2 + 15x - 27 = 0$", r"Takes the new sum as $-\frac{15}{2}$.")],
  check=_c13, values=[_m(2*x**2 - 15*x - 27), _m(6*x**2 - 5*x - 1), _m(2*x**2 - 15*x - 9), _m(2*x**2 + 15*x - 27)],
  cognitive="Application")


# ================================================================ MEDIUM

def _c14():
    return _val(x**2 - 5*x + 3, lambda a, b: a**3 + b**3)
q("C10-A-014", T, "Sum of cubes of the roots", "Medium",
  "Single-step computation",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 5x + 3 = 0$, what is the value of $\alpha^3 + \beta^3$?",
  "TITA",
  r"$\alpha^3 + \beta^3 = (\alpha + \beta)^3 - 3\alpha\beta(\alpha + \beta) = 125 - 3 \times 3 \times 5 = 125 - 45 = 80$.",
  "Dropping the factor $(\\alpha + \\beta)$ in the correction term, or adding it.",
  "C10A-cubes-and-fourth-powers", "Needs the cube identity in terms of sum and product.",
  tita_answer=80, check=_c14,
  tita_traps=[(116, r"Uses $(\alpha+\beta)^3 - 3\alpha\beta = 125 - 9$."), (170, r"Adds the correction: $125 + 45$.")],
  cognitive="Application")


def _c15():
    return _val(x**2 - 3*x - 5, lambda a, b: a**4 + b**4)
q("C10-A-015", T, "Sum of fourth powers of the roots with a negative product", "Medium",
  "Single-step computation",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 3x - 5 = 0$, then $\alpha^4 + \beta^4$ equals",
  "MCQ",
  r"$\alpha + \beta = 3$, $\alpha\beta = -5$. First $\alpha^2 + \beta^2 = 9 + 10 = 19$. Then $\alpha^4 + \beta^4 = (\alpha^2 + \beta^2)^2 - 2\alpha^2\beta^2 = 361 - 2 \times 25 = 311$.",
  "Forgetting to subtract $2\\alpha^2\\beta^2$, or subtracting $2\\alpha\\beta$ instead.",
  "C10A-cubes-and-fourth-powers", "Two stages of squaring, with a sign to track in the product.",
  correct=r"$311$",
  distractors=[(r"$361$", r"Squares $\alpha^2 + \beta^2 = 19$ and stops."),
               (r"$371$", r"Subtracts $2\alpha\beta = -10$ instead of $2\alpha^2\beta^2$: $361 + 10$."),
               (r"$411$", r"Adds $2\alpha^2\beta^2$: $361 + 50$.")],
  check=_c15, values=[311, 361, 371, 411], cognitive="Application")


def _c16():
    return _val(3*x**2 + 7*x - 2, lambda a, b: 1/a**2 + 1/b**2)
q("C10-A-016", T, "Sum of squares of reciprocals of the roots", "Medium",
  "Single-step computation",
  r"If $\alpha$ and $\beta$ are the roots of $3x^2 + 7x - 2 = 0$, then $\frac{1}{\alpha^2} + \frac{1}{\beta^2}$ equals",
  "MCQ",
  r"$\alpha + \beta = -\frac{7}{3}$ and $\alpha\beta = -\frac{2}{3}$. Then $\alpha^2 + \beta^2 = \frac{49}{9} + \frac{4}{3} = \frac{61}{9}$, and $\frac{1}{\alpha^2} + \frac{1}{\beta^2} = \frac{\alpha^2 + \beta^2}{(\alpha\beta)^2} = \frac{61/9}{4/9} = \frac{61}{4}$.",
  "Mishandling the negative product in $-2\\alpha\\beta$, or dividing by $\\alpha\\beta$ instead of $(\\alpha\\beta)^2$.",
  "C10A-reciprocal-and-ratio-sums", "Fractional sum and a negative product; two places for sign slips.",
  correct=r"$\frac{61}{4}$",
  distractors=[(r"$\frac{37}{4}$", r"Writes $\alpha^2 + \beta^2 = \frac{49}{9} - \frac{4}{3} = \frac{37}{9}$, losing the sign of the product."),
               (r"$\frac{49}{4}$", r"Squares $\frac{1}{\alpha} + \frac{1}{\beta} = \frac{7}{2}$ and stops."),
               (r"$\frac{61}{6}$", r"Divides $\frac{61}{9}$ by $|\alpha\beta| = \frac{2}{3}$ instead of $(\alpha\beta)^2$.")],
  check=_c16, values=[Rational(61, 4), Rational(37, 4), Rational(49, 4), Rational(61, 6)], cognitive="Application")


def _c17():
    a, b = _rts(x**2 - 5*x + 2)
    return _eq(a**2, b**2)
q("C10-A-017", T, "Equation whose roots are the squares of the given roots", "Medium",
  "Conceptual/application",
  r"The roots of $x^2 - 5x + 2 = 0$ are $\alpha$ and $\beta$. The equation whose roots are $\alpha^2$ and $\beta^2$ is",
  "MCQ",
  r"New sum $= \alpha^2 + \beta^2 = 25 - 4 = 21$; new product $= (\alpha\beta)^2 = 4$. The equation is $x^2 - 21x + 4 = 0$.",
  "Mis-applying the sum-of-squares identity or keeping the old product.",
  "C10A-nonlinear-transformed-roots", "Two symmetric functions combined into a new equation.",
  correct=r"$x^2 - 21x + 4 = 0$",
  distractors=[(r"$x^2 - 23x + 4 = 0$", r"Takes $\alpha^2 + \beta^2 = 25 - 2$, subtracting $\alpha\beta$ once."),
               (r"$x^2 - 25x + 4 = 0$", r"Takes $\alpha^2 + \beta^2 = (\alpha + \beta)^2 = 25$."),
               (r"$x^2 - 21x + 2 = 0$", r"Keeps the old product $\alpha\beta = 2$ instead of $(\alpha\beta)^2$.")],
  check=_c17, values=[x**2 - 21*x + 4, x**2 - 23*x + 4, x**2 - 25*x + 4, x**2 - 21*x + 2], cognitive="Application")


def _c18():
    a, b = _rts(2*x**2 - 7*x + 4)
    return _eq(a + 1/b, b + 1/a)
q("C10-A-018", T, "Equation whose roots are each root plus the reciprocal of the other", "Medium",
  "Conceptual/application",
  r"The roots of $2x^2 - 7x + 4 = 0$ are $\alpha$ and $\beta$. The equation whose roots are $\alpha + \frac{1}{\beta}$ and $\beta + \frac{1}{\alpha}$ is",
  "MCQ",
  r"$\alpha + \beta = \frac{7}{2}$, $\alpha\beta = 2$. New sum $= (\alpha + \beta) + \frac{\alpha + \beta}{\alpha\beta} = \frac{7}{2} + \frac{7}{4} = \frac{21}{4}$. New product $= \alpha\beta + 1 + 1 + \frac{1}{\alpha\beta} = 2 + 2 + \frac{1}{2} = \frac{9}{2}$. So $x^2 - \frac{21}{4}x + \frac{9}{2} = 0$, that is $4x^2 - 21x + 18 = 0$.",
  "Missing the two cross terms $\\alpha \\cdot \\frac{1}{\\alpha}$ and $\\beta \\cdot \\frac{1}{\\beta}$ when expanding the product.",
  "C10A-nonlinear-transformed-roots", "Needs a careful four-term expansion of the new product.",
  correct=r"$4x^2 - 21x + 18 = 0$",
  distractors=[(r"$4x^2 - 21x + 10 = 0$", r"Takes the new product as $\alpha\beta + \frac{1}{\alpha\beta} = \frac{5}{2}$, missing both cross terms."),
               (r"$4x^2 - 21x + 14 = 0$", r"Counts only one cross term: new product $\frac{7}{2}$."),
               (r"$4x^2 + 21x + 18 = 0$", r"Writes the equation as $x^2 + (\text{sum})x + \text{product} = 0$.")],
  check=_c18, values=[_m(4*x**2 - 21*x + 18), _m(4*x**2 - 21*x + 10), _m(4*x**2 - 21*x + 14), _m(4*x**2 + 21*x + 18)],
  cognitive="Application")


def _c19():
    # Ravi: constant wrong, so his sum is right. Meera: x-coefficient wrong, so her product is right.
    s = 3 + 8
    p = (-3) * (-6)
    a, b = _rts(x**2 - s*x + p)
    return abs(a - b)
q("C10-A-019", T, "Recovering the true roots when two solvers miscopy different coefficients", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera try to solve the same equation $x^2 + bx + c = 0$. Ravi copies the constant term wrongly but the coefficient of $x$ correctly, and gets roots $3$ and $8$. Meera copies the coefficient of $x$ wrongly but the constant term correctly, and gets roots $-3$ and $-6$. What is the positive difference between the roots of the correct equation?",
  "TITA",
  r"Ravi's roots carry the correct sum, $3 + 8 = 11$. Meera's roots carry the correct product, $(-3)(-6) = 18$. The correct equation is $x^2 - 11x + 18 = 0 = (x - 2)(x - 9)$, so the roots are $2$ and $9$ and their difference is $7$.",
  "Taking the sum from the solver who miscopied the coefficient of $x$.",
  "C10A-misread-coefficients", "Must decide which solver's sum and which solver's product to trust.",
  tita_answer=7, check=_c19,
  tita_traps=[(5, r"Reports the difference of Ravi's roots, $8 - 3$."), (3, r"Reports the difference of Meera's roots.")],
  cognitive="Analysis", exams=("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET"))


def _c20():
    a, c = symbols('a c')
    sols = solve([Eq(a + a**2, 12), Eq(a * a**2, c)], [a, c], dict=True)
    cs = set(s[c] for s in sols if s[a].is_real)
    return sum(cs)
q("C10-A-020", T, "Constant term when one root is the square of the other", "Medium",
  "Casework/optimisation",
  r"One root of $x^2 - 12x + c = 0$ is the square of the other root. The sum of all possible values of $c$ is",
  "MCQ",
  r"Let the roots be $t$ and $t^2$. Then $t + t^2 = 12$, so $(t + 4)(t - 3) = 0$ and $t = 3$ or $t = -4$. The roots are $3, 9$ (so $c = 27$) or $-4, 16$ (so $c = -64$). The sum of the possible values is $27 - 64 = -37$.",
  "Discarding the negative value of $t$, which is perfectly valid here.",
  "C10A-roots-ratio-or-power-relation", "Two cases from a quadratic in the smaller root; the negative case is easy to drop.",
  correct=r"$-37$",
  distractors=[(r"$37$", r"Finds $c = 27$ and $c = -64$ correctly but combines them as $64 - 27 = 37$, a sign slip in the final addition."),
               (r"$27$", r"Keeps only $t = 3$."),
               (r"$91$", r"Takes the product of the roots for $t = -4$ as $+64$ and adds $27 + 64$.")],
  check=_c20, values=[-37, 37, 27, 91], cognitive="Analysis")


def _c21():
    p, qq = symbols('p q', positive=True)
    # (a-b)^2 = 9, a^2 + b^2 = 29
    sol = solve([Eq(p**2 - 4*qq, 9), Eq(p**2 - 2*qq, 29)], [p, qq], dict=True)
    return sol[0][p] + sol[0][qq]
q("C10-A-021", T, "Sum and product from the difference and the sum of squares of the roots", "Medium",
  "Inverse/parameter",
  r"The roots of $x^2 - px + q = 0$, where $p$ and $q$ are positive, differ by $3$, and the sum of their squares is $29$. What is the value of $p + q$?",
  "TITA",
  r"$(\alpha - \beta)^2 = \alpha^2 + \beta^2 - 2\alpha\beta$ gives $9 = 29 - 2q$, so $q = 10$. Then $p^2 = (\alpha + \beta)^2 = \alpha^2 + \beta^2 + 2\alpha\beta = 29 + 20 = 49$, and $p = 7$ because $p > 0$. So $p + q = 17$. (The roots are $5$ and $2$.)",
  "Stopping after finding one of $p$ and $q$.",
  "C10A-roots-differ-by", "Two identities used together, plus the sign of $p$.",
  tita_answer=17, check=_c21,
  tita_traps=[(10, r"Reports $q$ alone."), (7, r"Reports $p$ alone.")],
  cognitive="Application")


def _c22():
    k = symbols('k', real=True)
    good = set()
    for sol in solve(Eq((2*(k - 2))**2 - 4*(k - 2)*(3*k - 2), 0), k):
        if sol - 2 != 0:  # must remain a quadratic
            good.add(sol)
    return FiniteSet(*good)
q("C10-A-022", T, "Equal roots when the leading coefficient depends on the parameter", "Medium",
  "Conceptual/application",
  r"For which real value or values of $k$ does the equation $(k - 2)x^2 - 2(k - 2)x + 3k - 2 = 0$ have two equal roots?",
  "MCQ",
  r"The discriminant condition is $4(k-2)^2 - 4(k-2)(3k-2) = 0$, that is $(k - 2)(k - 2 - 3k + 2) = -2k(k - 2) = 0$, so $k = 0$ or $k = 2$. But at $k = 2$ the equation becomes $4 = 0$, which has no roots at all. At $k = 0$ it is $-2x^2 + 4x - 2 = -2(x - 1)^2 = 0$, with equal roots $1, 1$. So only $k = 0$ works.",
  "Accepting a parameter value that makes the leading coefficient zero.",
  "C10A-equal-roots-parameter", "The discriminant gives a spurious value that kills the $x^2$ term.",
  correct=r"$k = 0$ only",
  distractors=[(r"$k = 2$ only", r"Cancels the factor $k$ in $-2k(k - 2) = 0$ and keeps only $k = 2$."),
               (r"$k = 0$ or $k = 2$", r"Accepts both roots of the discriminant equation without checking the leading coefficient."),
               (r"$k = 1$ or $k = 2$", r"Adds instead of subtracting in the discriminant: $(k-2)^2 + (k-2)(3k-2) = 4(k-2)(k-1)$.")],
  check=_c22, values=[FiniteSet(0), FiniteSet(2), FiniteSet(0, 2), FiniteSet(1, 2)], cognitive="Analysis")


def _c23():
    p, qq, r = symbols('p q r', real=True)
    D1 = (2*p)**2 - 4*qq*r
    D2 = (2*(qq + r))**2 - 4*(p**2 + qq**2 + qq*r + r**2)
    # D2 is exactly -D1, so D1 > 0 forces D2 < 0: no real roots (code 0)
    assert simplify(D2 + D1) == 0
    return 0
q("C10-A-023", T, "Nature of roots of a second equation built from the coefficients of the first", "Medium",
  "Conceptual/application",
  r"The real numbers $p$, $q$, $r$ are such that $x^2 - 2px + qr = 0$ has real and distinct roots. Then the equation $x^2 - 2(q + r)x + p^2 + q^2 + qr + r^2 = 0$ has",
  "MCQ",
  r"For the first equation, real distinct roots mean $4p^2 - 4qr > 0$, that is $p^2 > qr$. For the second, the discriminant divided by $4$ is $(q + r)^2 - (p^2 + q^2 + qr + r^2) = qr - p^2$, which is negative. So the second equation has no real roots.",
  "Expanding $(q + r)^2$ with the wrong middle term, which flips the sign of the discriminant.",
  "C10A-coefficient-condition-nature", "The two discriminants must be compared symbolically.",
  correct=r"no real roots",
  distractors=[(r"real and distinct roots", r"Gets $p^2 - qr$ for the second discriminant after a sign slip, and concludes it is positive."),
               (r"real and equal roots", r"Expects the second discriminant to cancel to $0$."),
               (r"real roots for some values of $p$, $q$, $r$ only", r"Reduces the second discriminant to $qr - p^2$ but does not use the condition $p^2 > qr$, so treats its sign as depending on the values.")],
  check=_c23, values=[0, 1, 2, 3], cognitive="Analysis")


def _c24():
    primes = [n for n in range(2, 60) if isprime(n)]
    cs = set()
    for p1 in primes:
        for p2 in primes:
            if p1 <= p2 and (p1 + p2) + p1 * p2 == 59:
                cs.add(p1 * p2)
    assert len(cs) == 1
    return cs.pop()
q("C10-A-024", T, "Both roots prime with a condition on the coefficients", "Medium",
  "Casework/optimisation",
  r"Both roots of $x^2 - bx + c = 0$ are prime numbers, and $b + c = 59$. What is the value of $c$?",
  "TITA",
  r"If the roots are $m$ and $n$, then $b + c = m + n + mn = 59$, so $(m + 1)(n + 1) = 60$. Writing $60$ as a product of two factors, each at least $3$: $3 \times 20$, $4 \times 15$, $5 \times 12$, $6 \times 10$. These give $(m, n) = (2, 19), (3, 14), (4, 11), (5, 9)$, and only $(2, 19)$ has both numbers prime. So $c = 2 \times 19 = 38$.",
  "Not converting $m + n + mn$ into $(m+1)(n+1) - 1$, and guessing.",
  "C10A-prime-integer-roots", "Factorisation trick plus a prime check over a short list.",
  tita_answer=38, check=_c24,
  tita_traps=[(21, r"Reports $b = 2 + 19$."), (19, r"Reports the larger root.")],
  cognitive="Analysis")


def _c25():
    tot = 0
    for k in range(1, 200):
        a, b = _rts(x**2 - 6*x + k)
        if a.is_rational and b.is_rational:
            tot += k
    return tot
q("C10-A-025", T, "Positive constants that make both roots rational", "Medium",
  "Casework/optimisation",
  r"Find the sum of all positive integers $k$ for which both roots of $x^2 - 6x + k = 0$ are rational numbers.",
  "TITA",
  r"With integer coefficients, the roots are rational exactly when the discriminant $36 - 4k = 4(9 - k)$ is a perfect square, that is when $9 - k \in \{0, 1, 4, 9, \dots\}$. For positive $k$ this gives $k = 9, 8, 5$ (roots $3, 3$; $2, 4$; $1, 5$). The sum is $22$.",
  "Leaving out $k = 9$, where both roots are equal to $3$ and are still rational.",
  "C10A-rational-roots-square-discriminant", "Turning rationality into a perfect-square condition and listing cases.",
  tita_answer=22, check=_c25,
  tita_traps=[(13, r"Leaves out $k = 9$ (equal roots)."), (3, r"Counts the values of $k$ instead of adding them.")],
  cognitive="Analysis")


def _c26():
    a, b = _rts(x**2 - 6*x + 2)
    g, h = _rts(x**2 - 5*x + 5)
    return nsimplify(simplify(expand((a - g) * (a - h) * (b - g) * (b - h))))
q("C10-A-026", T, "Product of all differences between the roots of two quadratics", "Difficult",
  "Conceptual/application",
  r"The roots of $x^2 - 6x + 2 = 0$ are $\alpha, \beta$, and the roots of $x^2 - 5x + 5 = 0$ are $\gamma, \delta$. What is the value of $(\alpha - \gamma)(\alpha - \delta)(\beta - \gamma)(\beta - \delta)$?",
  "TITA",
  r"Since $\gamma, \delta$ are the roots of $g(x) = x^2 - 5x + 5$, we have $(\alpha - \gamma)(\alpha - \delta) = g(\alpha)$. As $\alpha^2 = 6\alpha - 2$, $g(\alpha) = 6\alpha - 2 - 5\alpha + 5 = \alpha + 3$, and similarly $g(\beta) = \beta + 3$. The required value is $(\alpha + 3)(\beta + 3) = \alpha\beta + 3(\alpha + \beta) + 9 = 2 + 18 + 9 = 29$.",
  "Expanding $(\\alpha + 3)(\\beta + 3)$ without the cross term or the constant.",
  "C10A-product-over-two-quadratics", "Non-obvious model: the four-factor product must be seen as $g(\\alpha)g(\\beta)$, each factor reduced with the first equation, then sum and product used; direct expansion with surds is a trap.",
  tita_answer=29, check=_c26,
  tita_traps=[(11, r"Writes $(\alpha+3)(\beta+3) = \alpha\beta + 9$."), (20, r"Writes $(\alpha+3)(\beta+3) = \alpha\beta + 3(\alpha + \beta)$, dropping the $9$.")],
  cognitive="Analysis", exams=CX)


def _c27b():
    b, c = symbols('b c')
    root = 3 + sqrt(2)
    # b, c integers: split the root condition into its rational part and its sqrt(2) part
    e = expand(root**2 + b*root + c)
    rat = e.subs(sqrt(2), 0)
    irr = expand((e - rat) / sqrt(2))
    s = solve([rat, irr], [b, c], dict=True)[0]
    return s[b] + s[c]
q("C10-A-027", T, "Conjugate irrational root when the coefficients are integers", "Medium",
  "Conceptual/application",
  r"The equation $x^2 + bx + c = 0$, where $b$ and $c$ are integers, has $3 + \sqrt{2}$ as one of its roots. The value of $b + c$ is",
  "MCQ",
  r"With integer (hence rational) coefficients, irrational roots of this form come in conjugate pairs, so the other root is $3 - \sqrt{2}$. Sum $= 6$, product $= 9 - 2 = 7$. The equation is $x^2 - 6x + 7 = 0$, so $b = -6$, $c = 7$ and $b + c = 1$.",
  "Mis-signing $b$, or expanding $(3 + \\sqrt{2})(3 - \\sqrt{2})$ as $9 + 2$.",
  "C10A-conjugate-irrational-roots", "Uses the conjugate-pair property, then sum and product with signs.",
  correct=r"$1$",
  distractors=[(r"$13$", r"Takes $b = 6$, the sum of the roots, instead of $-6$."),
               (r"$5$", r"Takes the product as $9 + 2 = 11$: $-6 + 11$."),
               (r"$3$", r"Takes the product as $9$, ignoring the $\sqrt{2}$ parts: $-6 + 9$.")],
  check=_c27b, values=[1, 13, 5, 3], cognitive="Understanding")


def _c28():
    S = [2, 2]  # S0, S1 for x^2 - 2x - 1; recurrence S_n = 2 S_{n-1} + S_{n-2}
    for _ in range(4):
        S.append(2 * S[-1] + S[-2])
    a, b = _rts(x**2 - 2*x - 1)
    v = nsimplify(simplify(expand(a**5 + b**5)))
    assert v == S[5]
    return v
q("C10-A-028", T, "Fifth-power sum of the roots by a recurrence", "Medium",
  "Conceptual/application",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 2x - 1 = 0$, what is the value of $\alpha^5 + \beta^5$?",
  "TITA",
  r"Each root satisfies $t^2 = 2t + 1$, so $S_n = \alpha^n + \beta^n$ obeys $S_n = 2S_{n-1} + S_{n-2}$. With $S_0 = 2$, $S_1 = 2$: $S_2 = 6$, $S_3 = 14$, $S_4 = 34$, $S_5 = 82$.",
  "Using $S_n = 2S_{n-1} - S_{n-2}$, the wrong sign for the second coefficient.",
  "C10A-power-sum-recurrence", "Requires a power-sum recurrence or repeated reduction.",
  tita_answer=82, check=_c28,
  tita_traps=[(34, r"Stops one step early at $S_4$."), (2, r"Uses $S_n = 2S_{n-1} - S_{n-2}$, which gives $2$ every time.")],
  cognitive="Application", exams=CX)


def _c29():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(a + b, 23), Eq(a**2 + b**2, 17**2)], [a, b], dict=True)
    return sol[0][a] * sol[0][b]
q("C10-A-029", T, "Area of a rectangle from the sum of its sides and its diagonal", "Medium",
  "Multi-step word problem",
  r"The length and breadth, in cm, of a rectangular card are the roots of $x^2 - 23x + k = 0$. The diagonal of the card is $17$ cm. What is the area of the card?",
  "MCQ",
  r"The sides $l, b$ satisfy $l + b = 23$ and $l^2 + b^2 = 17^2 = 289$. So $2lb = 529 - 289 = 240$ and the area is $lb = k = 120$ cm$^2$. (The sides are $15$ cm and $8$ cm.)",
  "Not halving $2lb$, or using the diagonal unsquared.",
  "C10A-roots-as-dimensions", "Combines Pythagoras with the sum-of-squares identity.",
  correct=r"$120$ cm$^2$",
  distractors=[(r"$240$ cm$^2$", r"Stops at $2lb = 240$."),
               (r"$60$ cm$^2$", r"Uses $4lb = 529 - 289$, mixing up the identity for $(l - b)^2$."),
               (r"$256$ cm$^2$", r"Uses the diagonal unsquared: $529 - 2k = 17$.")],
  check=_c29, values=[120, 240, 60, 256], cognitive="Application")


def _c30():
    a, b = _rts(x**2 - 6*x + 2)
    return _eq(a**2 * b, a * b**2)
q("C10-A-030", T, "Equation whose roots are alpha squared beta and alpha beta squared", "Medium",
  "Conceptual/application",
  r"The roots of $x^2 - 6x + 2 = 0$ are $\alpha$ and $\beta$. The equation whose roots are $\alpha^2\beta$ and $\alpha\beta^2$ is",
  "MCQ",
  r"New sum $= \alpha^2\beta + \alpha\beta^2 = \alpha\beta(\alpha + \beta) = 2 \times 6 = 12$. New product $= \alpha^3\beta^3 = 2^3 = 8$. The equation is $x^2 - 12x + 8 = 0$.",
  "Squaring instead of cubing $\\alpha\\beta$ for the new product, or adding sum and product for the new sum.",
  "C10A-nonlinear-transformed-roots", "Factor the new sum; cube the product.",
  correct=r"$x^2 - 12x + 8 = 0$",
  distractors=[(r"$x^2 - 12x + 4 = 0$", r"Takes the new product as $(\alpha\beta)^2 = 4$."),
               (r"$x^2 - 8x + 8 = 0$", r"Takes the new sum as $\alpha\beta + (\alpha + \beta) = 8$."),
               (r"$x^2 - 12x + 16 = 0$", r"Takes the new product as $(\alpha\beta)^4 = 16$, counting four factors.")],
  check=_c30, values=[x**2 - 12*x + 8, x**2 - 12*x + 4, x**2 - 8*x + 8, x**2 - 12*x + 16], cognitive="Application")


def _c31():
    ps = set()
    for r in range(-40, 41):
        if r == 0 or 36 % r:
            continue
        s = 36 // r
        ps.add(-(r + s))
    return len(ps)
q("C10-A-031", T, "Number of integer coefficients giving integer roots for a fixed constant", "Medium",
  "Casework/optimisation",
  r"For how many integer values of $p$ does the equation $x^2 + px + 36 = 0$ have both roots integers?",
  "MCQ",
  r"The roots $m, n$ are integers with $mn = 36$, and $p = -(m + n)$. Unordered factor pairs with both positive: $(1, 36), (2, 18), (3, 12), (4, 9), (6, 6)$, giving $p = -37, -20, -15, -13, -12$. The pairs with both negative give $p = 37, 20, 15, 13, 12$. In all, $10$ values.",
  "Counting ordered pairs, or forgetting the negative pairs.",
  "C10A-integer-roots-parameter", "Casework over factor pairs including negative ones.",
  correct=r"$10$",
  distractors=[(r"$5$", r"Uses only the positive factor pairs."),
               (r"$9$", r"Counts the positive divisors of $36$, one value of $p$ per divisor."),
               (r"$18$", r"Counts ordered pairs $(m, n)$ with both signs, so each $p$ except those from $(6, 6)$ is counted twice.")],
  check=_c31, values=[10, 5, 9, 18], cognitive="Analysis",
  flags="")


def _c32():
    return _val(x**2 + 3*x - 7, lambda a, b: 1/(a + 2) + 1/(b + 2))
q("C10-A-032", T, "Sum of reciprocals of the roots shifted by a constant", "Medium",
  "Conceptual/application",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 + 3x - 7 = 0$, then $\frac{1}{\alpha + 2} + \frac{1}{\beta + 2}$ equals",
  "MCQ",
  r"The value is $\frac{(\alpha + \beta) + 4}{(\alpha + 2)(\beta + 2)}$. Numerator: $-3 + 4 = 1$. Denominator: $\alpha\beta + 2(\alpha + \beta) + 4 = -7 - 6 + 4 = -9$ (this is the value of $x^2 + 3x - 7$ at $x = -2$). So the answer is $-\frac{1}{9}$.",
  "Losing the cross term $2(\\alpha + \\beta)$ in the denominator, or mis-signing the sum or product.",
  "C10A-shifted-root-expressions", "Combining fractions and evaluating the quadratic at $-2$.",
  correct=r"$-\frac{1}{9}$",
  distractors=[(r"$\frac{7}{3}$", r"Takes $\alpha + \beta = 3$: $\frac{3 + 4}{-7 + 6 + 4} = \frac{7}{3}$."),
               (r"$-\frac{1}{3}$", r"Writes the denominator as $\alpha\beta + 4 = -3$."),
               (r"$\frac{1}{5}$", r"Takes $\alpha\beta = 7$: denominator $7 - 6 + 4 = 5$.")],
  check=_c32, values=[Rational(-1, 9), Rational(7, 3), Rational(-1, 3), Rational(1, 5)], cognitive="Application")


def _c33():
    p, qq = symbols('p q')
    # roots of x^2 + p x + 2 shifted by 3 must satisfy x^2 - 10x + q: substitute x -> x + 3
    shifted = expand((x - 3)**2 + p*(x - 3) + 2)
    sol = solve(Poly(shifted - (x**2 - 10*x + qq), x).all_coeffs(), [p, qq], dict=True)[0]
    return sol[p] + sol[qq]
q("C10-A-033", T, "Coefficients of a quadratic whose roots are those of another shifted by 3", "Medium",
  "Inverse/parameter",
  r"Each root of $x^2 - 10x + q = 0$ is $3$ more than a corresponding root of $x^2 + px + 2 = 0$. The value of $p + q$ is",
  "MCQ",
  r"Let the roots of the second equation be $r, s$. Then $(r + 3) + (s + 3) = 10$ gives $r + s = 4$, so $p = -4$. Also $q = (r + 3)(s + 3) = rs + 3(r + s) + 9 = 2 + 12 + 9 = 23$. So $p + q = 19$.",
  "Mis-signing $p$, or dropping a term of $(r + 3)(s + 3)$.",
  "C10A-linear-transformed-roots", "Reverse use of a shift, with two coefficients to find.",
  correct=r"$19$",
  distractors=[(r"$27$", r"Takes $p = 4$, the sum of the roots."),
               (r"$7$", r"Takes $q = rs + 9 = 11$, dropping $3(r + s)$."),
               (r"$10$", r"Takes $q = rs + 3(r + s) = 14$, dropping the $9$.")],
  check=_c33, values=[19, 27, 7, 10], cognitive="Application")


def _c34():
    return _val(x**2 - 5*x + 3, lambda a, b: a**2 + 5*b)
q("C10-A-034", T, "An unsymmetric expression in the roots reduced using the equation", "Medium",
  "Conceptual/application",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 5x + 3 = 0$, then $\alpha^2 + 5\beta$ equals",
  "MCQ",
  r"Since $\alpha$ is a root, $\alpha^2 = 5\alpha - 3$. So $\alpha^2 + 5\beta = 5(\alpha + \beta) - 3 = 25 - 3 = 22$. The expression has the same value whichever root is called $\alpha$.",
  "Mis-signing the reduction $\\alpha^2 = 5\\alpha - 3$ or the sum of the roots.",
  "C10A-reduce-powers-using-equation", "The expression is not symmetric, so the reduction step is essential.",
  correct=r"$22$",
  distractors=[(r"$28$", r"Writes $\alpha^2 = 5\alpha + 3$."),
               (r"$-28$", r"Uses the correct reduction $\alpha^2 = 5\alpha - 3$ but takes $\alpha + \beta = -5$: $5(-5) - 3 = -28$."),
               (r"$25$", r"Drops the constant after the reduction: $5(\alpha + \beta)$.")],
  check=_c34, values=[22, 28, -28, 25], cognitive="Analysis")


# ================================================================ DIFFICULT

def _c35():
    # Arjun: leading coefficient wrong -> -b/c preserved (ratio sum/product).
    sA = Rational(1) + Rational(3, 4); pA = Rational(1) * Rational(3, 4)
    # Kabir: constant wrong -> sum preserved.
    sK = Rational(4) - Rational(1, 2)
    s = sK
    p = s / (sA / pA)
    return _m(x**2 - s*x + p)
q("C10-A-035", T, "True equation when one solver miscopies the leading coefficient", "Difficult",
  "Multi-step word problem",
  r"Arjun and Kabir try to solve the same quadratic equation. Arjun copies the coefficient of $x^2$ wrongly but the other two coefficients correctly, and gets roots $1$ and $\frac{3}{4}$. Kabir copies only the constant term wrongly and gets roots $4$ and $-\frac{1}{2}$. The correct equation is",
  "MCQ",
  r"For $ax^2 + bx + c = 0$, sum $= -\frac{b}{a}$ and product $= \frac{c}{a}$. A wrong $a$ changes both, but their ratio $\frac{\text{sum}}{\text{product}} = -\frac{b}{c}$ survives, so from Arjun: $\frac{7/4}{3/4} = \frac{7}{3}$. A wrong $c$ leaves the sum intact, so from Kabir: sum $= \frac{7}{2}$. Then product $= \frac{7}{2} \div \frac{7}{3} = \frac{3}{2}$, and the equation is $x^2 - \frac{7}{2}x + \frac{3}{2} = 0$, that is $2x^2 - 7x + 3 = 0$ (roots $3$ and $\frac{1}{2}$).",
  "Assuming that a wrong leading coefficient leaves the product of the roots intact.",
  "C10A-misread-coefficients", "Must see that only the ratio of sum to product survives a wrong leading coefficient.",
  correct=r"$2x^2 - 7x + 3 = 0$",
  distractors=[(r"$4x^2 - 14x + 3 = 0$", r"Uses Kabir's sum $\frac{7}{2}$ with Arjun's product $\frac{3}{4}$, as in the usual miscopy rule."),
               (r"$4x^2 - 7x - 8 = 0$", r"Uses Arjun's sum $\frac{7}{4}$ with Kabir's product $-2$."),
               (r"$6x^2 - 21x + 49 = 0$", r"Inverts the preserved ratio, taking product $= \frac{7}{2} \times \frac{7}{3} = \frac{49}{6}$.")],
  check=_c35, values=[_m(2*x**2 - 7*x + 3), _m(4*x**2 - 14*x + 3), _m(4*x**2 - 7*x - 8), _m(6*x**2 - 21*x + 49)],
  cognitive="Analysis", exams=CX)


def _c36():
    k = symbols('k', real=True)
    a2b2 = (2*k)**2 - 2*(k + 12)                      # alpha^2 + beta^2 from sum 2k, product k + 12
    allowed = solve_univariate_inequality((2*k)**2 - 4*(k + 12) >= 0, k, relational=False)
    crit = [c for c in solve(diff(a2b2, k), k) if c in allowed]
    cands = crit + [e for e in allowed.boundary if e.is_finite]
    return min(a2b2.subs(k, c) for c in cands)
q("C10-A-036", T, "Least sum of squares of the roots subject to the roots being real", "Difficult",
  "Casework/optimisation",
  r"For real values of $k$, the equation $x^2 - 2kx + k + 12 = 0$ has real roots $\alpha$ and $\beta$ (equal roots allowed). What is the least possible value of $\alpha^2 + \beta^2$?",
  "TITA",
  r"$\alpha^2 + \beta^2 = 4k^2 - 2(k + 12) = 4k^2 - 2k - 24$, whose unrestricted minimum at $k = \frac{1}{4}$ is negative and not allowed. Real roots need $k^2 - (k + 12) \geq 0$, that is $(k - 4)(k + 3) \geq 0$, so $k \leq -3$ or $k \geq 4$. The parabola in $k$ decreases until $k = \frac{1}{4}$ and increases after it, so on $k \le -3$ the least value is at $k = -3$: $36 + 6 - 24 = 18$; on $k \ge 4$ it is at $k = 4$: $64 - 8 - 24 = 32$. The least value is $18$.",
  "Minimising without the real-roots restriction, or checking only one end of the allowed region.",
  "C10A-min-symmetric-function-real-roots", "An optimisation whose unconstrained answer is impossible; two boundary cases to compare.",
  tita_answer=18, check=_c36,
  tita_traps=[(32, r"Checks only the region $k \geq 4$."), (54, r"Uses $\alpha^2 + \beta^2 = (\alpha+\beta)^2 + 2\alpha\beta$ and evaluates at $k = -3$: $36 + 18$.")],
  cognitive="Analysis", exams=CX)


def _c37():
    n = 0
    for a in range(1, 8):
        for b in range(1, 8):
            for c in range(1, 8):
                if b*b - 4*a*c > 0:
                    n += 1
    return n
q("C10-A-037", T, "Counting coefficient triples that give distinct real roots", "Difficult",
  "Casework/optimisation",
  r"Each of $a$, $b$ and $c$ is chosen from the integers $1, 2, \dots, 7$ (repetition allowed). For how many ordered triples $(a, b, c)$ does the equation $ax^2 + bx + c = 0$ have two distinct real roots?",
  "TITA",
  r"We need $b^2 > 4ac$, that is $ac < \frac{b^2}{4}$. Count ordered pairs $(a, c)$ for each $b$. $b = 1, 2$: none (for $b = 2$, $ac < 1$ is impossible). $b = 3$: $ac \le 2$, $3$ pairs. $b = 4$: $ac < 4$, so $ac \le 3$: $3 + 1 + 1 = 5$ pairs. $b = 5$: $ac \le 6$: $6 + 3 + 2 + 1 + 1 + 1 = 14$. $b = 6$: $ac < 9$, so $ac \le 8$: $7 + 4 + 2 + 2 + 1 + 1 + 1 = 18$. $b = 7$: $ac \le 12$: $7 + 6 + 4 + 3 + 2 + 2 + 1 = 25$. Total $3 + 5 + 14 + 18 + 25 = 65$.",
  "Allowing $b^2 = 4ac$ for even $b$, which counts equal roots as distinct.",
  "C10A-count-quadratics-by-nature", "Three-parameter casework with a strict boundary that matters only for even $b$, and a divisor-style count for each $b$.",
  tita_answer=65, check=_c37,
  tita_traps=[(70, r"Uses $b^2 \ge 4ac$, which also counts the $5$ equal-root triples with $b = 2, 4, 6$."), (37, r"Treats $(a, b, c)$ and $(c, b, a)$ as the same equation, counting only $a \le c$.")],
  cognitive="Analysis", exams=CX)


def _c38():
    ks = set()
    for k in range(-2000, 2001):
        D = k*k - 12*k
        if _isq(D):
            r = math.isqrt(D)
            if (k + r) % 2 == 0:
                ks.add(k)
    return len(ks)
q("C10-A-038", T, "Number of parameter values giving integer roots via factorisation", "Difficult",
  "Casework/optimisation",
  r"For how many integer values of $k$ are both roots of $x^2 - kx + 3k = 0$ integers?",
  "MCQ",
  r"If the integer roots are $m$ and $n$, then $m + n = k$ and $mn = 3k = 3(m + n)$. So $mn - 3m - 3n + 9 = 9$, that is $(m - 3)(n - 3) = 9$. Unordered pairs: $(1, 9), (3, 3), (-1, -9), (-3, -3)$, giving $(m, n) = (4, 12), (6, 6), (2, -6), (0, 0)$ and $k = 16, 12, -4, 0$. That is $4$ values.",
  "Ignoring negative factor pairs or the equal-root cases, or counting ordered pairs.",
  "C10A-integer-roots-parameter", "Needs the factorisation trick and full casework on signs.",
  correct=r"$4$",
  distractors=[(r"$2$", r"Drops the equal-root cases $(3, 3)$ and $(-3, -3)$."),
               (r"$6$", r"Counts ordered factor pairs of $9$, so $(1, 9)$ and $(9, 1)$ are counted separately."),
               (r"$3$", r"Takes one value of $k$ for each positive divisor $1, 3, 9$ of $9$.")],
  check=_c38, values=[4, 2, 6, 3], cognitive="Analysis", exams=CX)


def _c39():
    return _val(x**2 - 4*x + 2, lambda a, b: a**6 + b**6)
q("C10-A-039", T, "Sum of sixth powers of the roots", "Medium",
  "Conceptual/application",
  r"If $\alpha$ and $\beta$ are the roots of $x^2 - 4x + 2 = 0$, then $\alpha^6 + \beta^6$ equals",
  "MCQ",
  r"$\alpha^2 + \beta^2 = 16 - 4 = 12$ and $\alpha^2\beta^2 = 4$. Treat $\alpha^2, \beta^2$ as a pair with sum $12$ and product $4$: $\alpha^6 + \beta^6 = 12^3 - 3 \times 4 \times 12 = 1728 - 144 = 1584$.",
  "Using $\\alpha\\beta$ instead of $\\alpha^2\\beta^2$ in the cube identity.",
  "C10A-cubes-and-fourth-powers", "Two layers of standard identities: squares first, then the cube identity on the squares.",
  correct=r"$1584$",
  distractors=[(r"$1728$", r"Cubes $\alpha^2 + \beta^2 = 12$ and stops."),
               (r"$1872$", r"Adds the correction: $1728 + 144$."),
               (r"$1656$", r"Uses $\alpha\beta = 2$ in place of $\alpha^2\beta^2$: $1728 - 3 \times 2 \times 12$.")],
  check=_c39, values=[1584, 1728, 1872, 1656], cognitive="Application", exams=CX)


def _c40():
    n = 0
    for b in range(-3000, 3001):
        if _isq(b*b + 24):
            n += 1
    return n
q("C10-A-040", T, "Number of integer coefficients giving rational roots", "Difficult",
  "Casework/optimisation",
  r"For how many integers $b$ does the equation $2x^2 + bx - 3 = 0$ have rational roots?",
  "TITA",
  r"With integer coefficients the roots are rational exactly when $b^2 + 24$ is a perfect square, say $m^2$ with $m \geq 0$. Then $(m - b)(m + b) = 24$, and both factors have the same parity, so both are even: $2 \times 12$ or $4 \times 6$ (and the same with the factors swapped). This gives $b = \pm 5$ and $b = \pm 1$, so $4$ integers. (For example $2x^2 + x - 3 = (2x + 3)(x - 1)$.)",
  "Counting only positive $b$, or accepting factor pairs of $24$ with opposite parity.",
  "C10A-rational-roots-square-discriminant", "Perfect-square discriminant turned into a factor-pair search with a parity condition.",
  tita_answer=4, check=_c40,
  tita_traps=[(2, r"Counts only positive $b$."), (8, r"Counts the factor pairs of $24$ (four unordered pairs) with both signs, without solving for $b$ or checking parity.")],
  cognitive="Analysis", exams=CX)


def _c41():
    vals = set()
    for r in _rts(x**2 + 4*x - 2):
        vals.add(nsimplify(simplify(expand(r*(r + 1)*(r + 3)*(r + 4)))))
    assert len(vals) == 1
    return vals.pop()
q("C10-A-041", T, "Product of four linear expressions in a root, paired using the equation", "Difficult",
  "Conceptual/application",
  r"Let $r$ be a root of $x^2 + 4x - 2 = 0$. What is the value of $r(r + 1)(r + 3)(r + 4)$?",
  "TITA",
  r"From the equation, $r^2 + 4r = 2$. Pair the factors so that each pair contains $r^2 + 4r$: $r(r + 4) = r^2 + 4r = 2$ and $(r + 1)(r + 3) = r^2 + 4r + 3 = 5$. The product is $2 \times 5 = 10$, for either root.",
  "Pairing the factors in order, $r(r+1)$ and $(r+3)(r+4)$, which leaves an expression that does not simplify.",
  "C10A-reduce-powers-using-equation", "The right pairing of four factors is not obvious.",
  tita_answer=10, check=_c41,
  tita_traps=[(12, r"Multiplies only the constants $1 \times 3 \times 4$."), (-2, r"Takes $r^2 + 4r = -2$: $(-2)(1)$.")],
  cognitive="Analysis", exams=CX)


def _c42():
    seen = set()
    for b in range(1, 11):
        for c in range(1, 11):
            ok = False
            for m in range(-20, 21):
                n = b - m
                if m * n == c:
                    ok = True
            if ok:
                seen.add((b, c))
    return len(seen)
q("C10-A-042", T, "Counting equations with bounded coefficients and integer roots", "Difficult",
  "Casework/optimisation",
  r"Each of $b$ and $c$ is an integer from $1$ to $10$ (they may be equal). For how many ordered pairs $(b, c)$ are both roots of $x^2 - bx + c = 0$ integers?",
  "MCQ",
  r"The roots have sum $b > 0$ and product $c > 0$, so both are positive integers $m \leq n$ with $m + n \leq 10$ and $mn \leq 10$. For $m = 1$: $n = 1, \dots, 9$ ($9$ cases). For $m = 2$: $n = 2, 3, 4, 5$ ($4$ cases). For $m = 3$: $n = 3$ ($1$ case). For $m \ge 4$, $mn \ge 16$. Each unordered pair gives a different $(b, c)$, so the count is $14$.",
  "Counting ordered pairs of roots, or excluding equal roots.",
  "C10A-count-quadratics-by-nature", "Translate to root pairs, then casework with two bounds at once.",
  correct=r"$14$",
  distractors=[(r"$11$", r"Excludes the equal-root cases $(1, 1), (2, 2), (3, 3)$."),
               (r"$25$", r"Counts ordered pairs of roots, so $(1, 2)$ and $(2, 1)$ are counted separately."),
               (r"$9$", r"Considers only equations with $1$ as a root.")],
  check=_c42, values=[14, 11, 25, 9], cognitive="Analysis", exams=CX)


def _c43():
    y = symbols('y')
    a, b = _rts(x**2 - 28*x + 16)
    assert a > 0 and b > 0
    v = a**Rational(1, 4) + b**Rational(1, 4)
    mp = minimal_polynomial(v, y)
    pos = [r for r in solve(mp, y) if r.is_positive]
    assert len(pos) == 1 and abs(N(v - pos[0], 50)) < 1e-40
    return pos[0]
q("C10-A-043", T, "Sum of the fourth roots of the roots", "Difficult",
  "Conceptual/application",
  r"The roots of $x^2 - 28x + 16 = 0$ are $\alpha$ and $\beta$. The value of $\sqrt[4]{\alpha} + \sqrt[4]{\beta}$ is",
  "MCQ",
  r"Both roots are positive (sum $28 > 0$, product $16 > 0$, discriminant $720 > 0$), so the roots taken are real. First $(\sqrt{\alpha} + \sqrt{\beta})^2 = \alpha + \beta + 2\sqrt{\alpha\beta} = 28 + 8 = 36$, so $\sqrt{\alpha} + \sqrt{\beta} = 6$. Then $(\sqrt[4]{\alpha} + \sqrt[4]{\beta})^2 = \sqrt{\alpha} + \sqrt{\beta} + 2\sqrt[4]{\alpha\beta} = 6 + 2 \times 2 = 10$, so the value is $\sqrt{10}$.",
  "Using $\\sqrt{\\alpha\\beta}$ instead of $\\sqrt[4]{\\alpha\\beta}$ in the cross term of the second squaring.",
  "C10A-square-roots-of-roots", "Two nested squaring stages, each with its own cross term, plus a positivity check of the roots.",
  correct=r"$\sqrt{10}$",
  distractors=[(r"$\sqrt{14}$", r"Uses $2\sqrt{\alpha\beta} = 8$ as the cross term in the second squaring: $6 + 8$."),
               (r"$\sqrt{6}$", r"Drops the cross term in the second squaring: $\sqrt{\sqrt{\alpha} + \sqrt{\beta}}$."),
               (r"$\sqrt{2}$", r"Subtracts the cross term in the second squaring, which gives $\sqrt[4]{\alpha} - \sqrt[4]{\beta}$ in size.")],
  check=_c43, values=[sqrt(10), sqrt(14), sqrt(6), sqrt(2)], cognitive="Analysis", exams=CX)


def _c44():
    p = symbols('p', real=True)
    e = expand((x - p)*(x - 3) + (x - 3)*(x - 7) + (x - 7)*(x - p))
    P = Poly(e, x)
    A, B, C = P.all_coeffs()
    D = expand(B**2 - 4*A*C)
    crit = solve(diff(D, p), p)
    mn = min(D.subs(p, c) for c in crit)
    # D is a quadratic in p with positive leading coefficient, so mn is its global minimum
    assert Poly(D, p).LC() > 0
    return 0 if mn > 0 else 1
q("C10-A-044", T, "Nature of roots of a cyclic sum of products for every value of a parameter", "Difficult",
  "Conceptual/application",
  r"For a real number $p$, consider the equation $(x - p)(x - 3) + (x - 3)(x - 7) + (x - 7)(x - p) = 0$. Its roots are",
  "MCQ",
  r"Expanding, $3x^2 - 2(p + 10)x + (10p + 21) = 0$. The discriminant divided by $4$ is $(p + 10)^2 - 3(10p + 21) = p^2 - 10p + 37 = (p - 5)^2 + 12$, which is at least $12$ for every real $p$. So the roots are real and distinct for every real $p$.",
  "Mis-expanding the constant term and finding a value of $p$ that makes the discriminant zero.",
  "C10A-coefficient-condition-nature", "Expansion of three products and a completed square in the parameter.",
  correct=r"real and distinct for every real $p$",
  distractors=[(r"real and equal for exactly one real $p$", r"Drops the $+12$ after completing the square and solves $(p - 5)^2 = 0$."),
               (r"real only when $3 \leq p \leq 7$", r"Assumes $p$ must lie between the other two numbers for real roots."),
               (r"not real for some real values of $p$", r"Takes the discriminant as $(p - 5)^2 - 12$ after a sign slip.")],
  check=_c44, values=[0, 1, 2, 3], cognitive="Analysis", exams=CX)


def _c45():
    a, b = _rts(2*x**2 - 5*x + 1)
    return _eq((a - 1)/(a + 1), (b - 1)/(b + 1))
q("C10-A-045", T, "Equation whose roots are a fractional linear transform of the given roots", "Difficult",
  "Conceptual/application",
  r"The roots of $2x^2 - 5x + 1 = 0$ are $\alpha$ and $\beta$. The equation whose roots are $\frac{\alpha - 1}{\alpha + 1}$ and $\frac{\beta - 1}{\beta + 1}$ is",
  "MCQ",
  r"If $y = \frac{x - 1}{x + 1}$ then $x = \frac{1 + y}{1 - y}$. Substituting into $2x^2 - 5x + 1 = 0$ and multiplying by $(1 - y)^2$: $2(1 + y)^2 - 5(1 + y)(1 - y) + (1 - y)^2 = 0$, that is $2 + 4y + 2y^2 - 5 + 5y^2 + 1 - 2y + y^2 = 8y^2 + 2y - 2 = 0$. So the equation is $4x^2 + x - 1 = 0$.",
  "Substituting the transform itself rather than its inverse, or not multiplying the constant term by $(1 - y)^2$.",
  "C10A-fractional-transformed-roots", "Requires inverting a fractional transform and a careful three-term expansion.",
  correct=r"$4x^2 + x - 1 = 0$",
  distractors=[(r"$x^2 + x - 4 = 0$", r"Substitutes $x = \frac{y - 1}{y + 1}$, the transform itself, instead of its inverse."),
               (r"$x^2 - x - 4 = 0$", r"Uses the inverse but writes $+5(1 + y)(1 - y)$, a sign slip in the middle term."),
               (r"$7x^2 + 4x - 2 = 0$", r"Does not multiply the constant term $1$ by $(1 - y)^2$.")],
  check=_c45, values=[_m(4*x**2 + x - 1), _m(x**2 + x - 4), _m(x**2 - x - 4), _m(7*x**2 + 4*x - 2)],
  cognitive="Analysis", exams=CX)
