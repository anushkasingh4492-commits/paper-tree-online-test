import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Functions"
CX = ("CAT", "XAT")
x = symbols('x', real=True)


# ---------------------------------------------------------------- 001
def _c001():
    cnt = 0
    for v in range(-100, 101):
        if 12 + v - v * v >= 0 and v + 2 > 0:
            cnt += 1
    return cnt
q("C14-A-001", T, "Number of integers in the domain of a sum of a square root and a reciprocal square root", "Easy",
  "Single-step computation",
  r"Let $f(x) = \sqrt{12 + x - x^2} + \frac{1}{\sqrt{x + 2}}$, where $f$ takes only real values. How many integers $x$ lie in the domain of $f$?",
  "TITA",
  r"The first root needs $12 + x - x^2 \ge 0$, that is $(4 - x)(x + 3) \ge 0$, so $-3 \le x \le 4$. The second term needs $x + 2 > 0$ (strictly, since it sits in a denominator), so $x > -2$. Together $-2 < x \le 4$, and the integers are $-1, 0, 1, 2, 3, 4$: $6$ integers.",
  "Allowing $x + 2 = 0$ for a square root that sits in a denominator, or ignoring the second condition.",
  "C14A-domain-intersection", "Two conditions to intersect, with a strict inequality from the denominator as the trap.",
  tita_answer=6, check=_c001, cognitive="Application",
  tita_traps=[(8, "Uses only the first condition, $-3 \\le x \\le 4$."),
              (7, "Allows $x = -2$, treating $x + 2 \\ge 0$ as enough.")])

# ---------------------------------------------------------------- 002
def _c002():
    c1 = solve_univariate_inequality(2 - log(x + 1, 3) >= 0, x, relational=False)
    c1 = Intersection(c1, Interval.open(-1, oo))
    c2 = solve_univariate_inequality(x**2 - 4 > 0, x, relational=False)
    return Intersection(c1, c2)
q("C14-A-002", T, "Domain of a function combining a logarithm under a root and a reciprocal root", "Medium",
  "Conceptual/application",
  r"The domain of the real function $f(x) = \sqrt{2 - \log_3 (x + 1)} + \frac{1}{\sqrt{x^2 - 4}}$ is",
  "MCQ",
  r"The logarithm needs $x + 1 > 0$, and the first root needs $\log_3(x + 1) \le 2$, that is $x + 1 \le 9$; so $-1 < x \le 8$. The second term needs $x^2 - 4 > 0$, so $x < -2$ or $x > 2$. Since $x > -1$, only $x > 2$ survives, and the domain is $(2, 8]$.",
  "Including the endpoint where a root in the denominator becomes zero, or dropping the condition that the log argument is positive.",
  "C14A-domain-intersection", "Three separate conditions (log argument, root, denominator) must be combined correctly.",
  correct=r"$(2, 8]$",
  distractors=[(r"$(-1, 8]$", "Uses only the conditions from the first term and ignores $x^2 - 4 > 0$."),
               (r"$[2, 8]$", "Uses $x^2 - 4 \\ge 0$, letting the denominator become $0$ at $x = 2$."),
               (r"$(-\infty, -2) \cup (2, 8]$", "Forgets that the logarithm needs $x + 1 > 0$, so keeps the branch $x < -2$.")],
  check=_c002,
  values=[Interval.Lopen(2, 8), Interval.Lopen(-1, 8), Interval(2, 8),
          Union(Interval.open(-oo, -2), Interval.Lopen(2, 8))],
  cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    arg = (x - 3) / (x + 2)
    pos = solve_univariate_inequality(arg > 0, x, relational=False)
    le1 = solve_univariate_inequality(arg <= 1, x, relational=False)
    c3 = solve_univariate_inequality(20 - x >= 0, x, relational=False)
    return Intersection(pos, le1, c3)
q("C14-A-003", T, "Domain when a logarithm with base less than 1 sits under a square root", "Medium",
  "Conceptual/application",
  r"The domain of the real function $f(x) = \sqrt{\log_{1/2}\left(\frac{x - 3}{x + 2}\right)} + \sqrt{20 - x}$ is",
  "MCQ",
  r"The logarithm needs $\frac{x-3}{x+2} > 0$, so $x < -2$ or $x > 3$. Because the base $\frac{1}{2}$ is less than $1$, $\log_{1/2} t \ge 0$ means $t \le 1$: $\frac{x-3}{x+2} - 1 = \frac{-5}{x+2} \le 0$, so $x > -2$. These two give $x > 3$, and $\sqrt{20 - x}$ needs $x \le 20$. The domain is $(3, 20]$.",
  "Keeping the inequality direction for a logarithm whose base is less than $1$.",
  "C14A-domain-intersection", "Needs the base-less-than-one reversal and a rational inequality; two traps at once.",
  correct=r"$(3, 20]$",
  distractors=[(r"$[3, 20]$", "Lets the argument of the logarithm be $0$ at $x = 3$."),
               (r"$(-\infty, -2)$", "Reverses the base rule, requiring $\\frac{x-3}{x+2} \\ge 1$, which gives $x < -2$."),
               (r"$(-\infty, -2) \cup (3, 20]$", "Uses only the positivity of the argument and drops the condition that the log is non-negative.")],
  check=_c003,
  values=[Interval.Lopen(3, 20), Interval(3, 20), Interval.open(-oo, -2),
          Union(Interval.open(-oo, -2), Interval.Lopen(3, 20))],
  cognitive="Analysis")

# ---------------------------------------------------------------- 004
def _c004():
    y = symbols('y', real=True)
    # y = (2x^2+14)/(x^2+1)  =>  x^2 = (14 - y)/(y - 2) must be >= 0
    return solve_univariate_inequality((14 - y) / (y - 2) >= 0, y, relational=False)
q("C14-A-004", T, "Range of a rational function in x squared", "Easy",
  "Single-step computation",
  r"The range of the function $f(x) = \frac{2x^2 + 14}{x^2 + 1}$, $x$ real, is",
  "MCQ",
  r"Write $f(x) = 2 + \frac{12}{x^2 + 1}$. As $x^2$ runs over $[0, \infty)$, $\frac{12}{x^2+1}$ runs over $(0, 12]$, reaching $12$ at $x = 0$ but never reaching $0$. So the range is $(2, 14]$.",
  "Treating a limiting value as attained, or the attained maximum as not attained.",
  "C14A-range-rational", "One rewrite and a check of which endpoint is attained.",
  correct=r"$(2, 14]$",
  distractors=[(r"$[2, 14]$", "Takes the limiting value $2$ as attained."),
               (r"$(2, 14)$", "Misses that $14$ is attained at $x = 0$."),
               (r"$[2, 14)$", "Swaps which endpoint is attained.")],
  check=_c004,
  values=[Interval.Lopen(2, 14), Interval(2, 14), Interval.open(2, 14), Interval.Ropen(2, 14)],
  cognitive="Understanding")

# ---------------------------------------------------------------- 005
def _c005():
    y = symbols('y', real=True)
    # y(x-1) = x^2 - 2x + 5  ->  x^2 - (2+y)x + (5+y) = 0, need real root x != 1
    taken = solve_univariate_inequality((2 + y)**2 - 4*(5 + y) >= 0, y, relational=False)
    # x = 1 is never a root (1 - 2 - y + 5 + y = 4), so no further exclusion
    return Complement(Reals, taken)
q("C14-A-005", T, "Values not taken by a rational function of the form t + 4/t", "Medium",
  "Conceptual/application",
  r"Consider $f(x) = \frac{x^2 - 2x + 5}{x - 1}$ for all real $x \ne 1$. The set of all real numbers that are NOT values of $f$ is",
  "MCQ",
  r"Put $t = x - 1 \ne 0$; then $x^2 - 2x + 5 = t^2 + 4$, so $f = t + \frac{4}{t}$. For $t > 0$ this is at least $4$ (equality at $t = 2$) and takes every value in $[4, \infty)$; for $t < 0$ it takes every value in $(-\infty, -4]$. The values missed are exactly $(-4, 4)$.",
  "Using only positive $t$, or misplacing the endpoints, or slipping in the AM-GM bound.",
  "C14A-range-rational", "Needs a substitution and both signs of $t$, with endpoint care.",
  correct=r"$(-4, 4)$",
  distractors=[(r"$[-4, 4]$", "Thinks the bounds $\\pm 4$ are not attained."),
               (r"$(-2, 2)$", "Uses $t + \\frac{4}{t} \\ge \\sqrt{4} = 2$ in AM-GM, dropping the factor $2$."),
               (r"$(-\infty, 4)$", "Considers only $x > 1$, so gets range $[4, \\infty)$ and misses the negative branch.")],
  check=_c005,
  values=[Interval.open(-4, 4), Interval(-4, 4), Interval.open(-2, 2), Interval.open(-oo, 4)],
  cognitive="Analysis")

# ---------------------------------------------------------------- 007
def _c007():
    f = Lambda(x, 2*x - 3); g = Lambda(x, x**2 + 1)
    return f(g(2)) - g(f(2))
q("C14-A-006", T, "Difference of the two compositions of a linear and a quadratic function", "Easy",
  "Single-step computation",
  r"If $f(x) = 2x - 3$ and $g(x) = x^2 + 1$, then $f(g(2)) - g(f(2))$ equals",
  "MCQ",
  r"$g(2) = 5$, so $f(g(2)) = f(5) = 7$. $f(2) = 1$, so $g(f(2)) = g(1) = 2$. The difference is $7 - 2 = 5$.",
  "Treating composition as multiplication, or applying the functions in the wrong order.",
  "C14A-composition-evaluate", "Two direct evaluations; the only trap is the order of composition.",
  correct=r"$5$",
  distractors=[(r"$-5$", "Computes $g(f(2)) - f(g(2))$, taking the compositions in the opposite order."),
               (r"$0$", "Reads $f(g(2))$ as $f(2)\\,g(2) = 5$ and $g(f(2))$ as $g(2)\\,f(2) = 5$."),
               (r"$6$", "Evaluates $g(1)$ as $1^2 = 1$, dropping the $+1$, giving $7 - 1$.")],
  check=_c007, values=[5, -5, 0, 6], cognitive="Application")

# ---------------------------------------------------------------- 009
def _c009():
    f = lambda t: t**2 - 4*t
    cnt = 0
    for k in range(-60, 120):
        p = Poly(expand(f(f(x)) - k), x)
        if len(set(real_roots(p))) == 4:
            cnt += 1
    return cnt
q("C14-A-007", T, "Integer values of k for which f(f(x)) = k has exactly four distinct real solutions", "Difficult",
  "Casework/optimisation",
  r"Let $f(x) = x^2 - 4x$ for all real $x$. For how many integers $k$ does the equation $f(f(x)) = k$ have exactly four distinct real solutions $x$?",
  "TITA",
  r"Put $y = f(x)$; then $y^2 - 4y = k$ gives $y = 2 \pm \sqrt{4 + k}$, real only for $k \ge -4$. Since $f(x) = (x - 2)^2 - 4$, an inner value $y$ gives two values of $x$ if $y > -4$, one if $y = -4$ and none if $y < -4$. The larger value $2 + \sqrt{4 + k} \ge 2$ always gives two. The smaller value $2 - \sqrt{4 + k}$ gives two exactly when $\sqrt{4 + k} < 6$, that is $k < 32$, and it must differ from the larger one, so $k > -4$. Hence four solutions exactly for $-4 < k < 32$, the integers $-3, -2, \ldots, 31$: $35$ of them. (At $k = -4$ there are $2$ solutions and at $k = 32$ there are $3$.)",
  "Including an endpoint value of $k$ where the two inner values merge or one inner value equals the least value of $f$.",
  "C14A-composition-solve", "Parameter casework over two inner values, each checked against the least value of $f$, with two boundary values of $k$ to exclude.",
  tita_answer=35, check=_c009, cognitive="Analysis", exams=CX,
  tita_traps=[(36, "Includes $k = 32$, where the inner value $-4$ is the least value of $f$ and gives only one $x$, so there are $3$ solutions."),
              (37, "Includes both $k = -4$ and $k = 32$."),
              (32, "Takes only $0 \\le k \\le 31$, assuming $k$ cannot be negative because it is a value of $f(f(x))$.")])

# ---------------------------------------------------------------- 010
def _c010():
    f = lambda t: t**2 - 6
    num = expand(f(f(x)) - x)
    fixed = x**2 - x - 6
    qt, r = div(num, fixed, x)
    assert r == 0
    return qt
q("C14-A-008", T, "Two-cycles of a quadratic map beyond its fixed points", "Difficult",
  "Conceptual/application",
  r"Let $f(x) = x^2 - 6$. Every real solution of $f(f(x)) = x$ that is not a solution of $f(x) = x$ satisfies which of the following equations?",
  "MCQ",
  r"If $f(a) = b$ and $f(b) = a$ with $a \ne b$, then $a^2 - 6 = b$ and $b^2 - 6 = a$. Subtracting, $a^2 - b^2 = b - a$, so $a + b = -1$. Then $a^2 - 6 = -1 - a$, that is $a^2 + a - 5 = 0$. (Equivalently, $x^4 - 12x^2 - x + 30$ divided by $x^2 - x - 6$ leaves $x^2 + x - 5$.)",
  "Confusing points of period two with fixed points, or a sign slip in the relation between the two cycle points.",
  "C14A-iterated-two-cycle", "Requires separating fixed points from period-two points via symmetric functions or a quartic division.",
  correct=r"$x^2 + x - 5 = 0$",
  distractors=[(r"$x^2 - x - 6 = 0$", "Gives the fixed-point equation $f(x) = x$ itself."),
               (r"$x^2 + x - 7 = 0$", "Takes $a + b = 1$ after subtracting, so $a^2 - 6 = 1 - a$."),
               (r"$x^2 - x - 5 = 0$", "Flips the sign of the $x$ term while dividing the quartic by $x^2 - x - 6$.")],
  check=_c010, values=[x**2 + x - 5, x**2 - x - 6, x**2 + x - 7, x**2 - x - 5],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 011
def _c011():
    f = (3*x + 2) / (x - 4)
    return [s for s in solve(Eq(f, 5), x)][0]
q("C14-A-009", T, "Value of the inverse of a linear fractional function", "Easy",
  "Single-step computation",
  r"Let $f(x) = \frac{3x + 2}{x - 4}$ for $x \ne 4$. The value of $f^{-1}(5)$ is",
  "MCQ",
  r"$f^{-1}(5)$ is the $x$ with $f(x) = 5$: $3x + 2 = 5(x - 4) = 5x - 20$, so $2x = 22$ and $x = 11$. Check: $f(11) = \frac{35}{7} = 5$.",
  "Computing $f(5)$ instead of solving $f(x) = 5$, or mishandling the bracket.",
  "C14A-inverse-evaluate", "One linear equation once the meaning of the inverse is clear.",
  correct=r"$11$",
  distractors=[(r"$17$", "Computes $f(5) = \\frac{17}{1}$ rather than $f^{-1}(5)$."),
               (r"$-9$", "Writes $5(x - 4)$ as $5x + 20$, so $-2x = 18$."),
               (r"$3$", "Writes $5(x - 4)$ as $5x - 4$, so $2x = 6$.")],
  check=_c011, values=[11, 17, -9, 3], cognitive="Application")

# ---------------------------------------------------------------- 012
def _c012():
    tot = 0
    for c in (11, 38):
        s = [r for r in solve(Eq(x**2 - 6*x + 11, c), x) if r >= 3]
        assert len(s) == 1
        tot += s[0]
    return tot
q("C14-A-010", T, "Inverse of a quadratic restricted to one side of its vertex", "Medium",
  "Single-step computation",
  r"Let $f(x) = x^2 - 6x + 11$ for $x \ge 3$, and let $g$ be the inverse of $f$. The value of $g(11) + g(38)$ is",
  "MCQ",
  r"$f(x) = (x - 3)^2 + 2$, and on $x \ge 3$ the inverse is $g(y) = 3 + \sqrt{y - 2}$. So $g(11) = 3 + 3 = 6$ and $g(38) = 3 + 6 = 9$, giving $15$. Check: $f(6) = 11$ and $f(9) = 38$.",
  "Taking the wrong square-root branch, or dropping the shift from completing the square.",
  "C14A-inverse-evaluate", "Needs completing the square and choosing the branch that matches the restricted domain.",
  correct=r"$15$",
  distractors=[(r"$9$", "Uses $g(y) = \\sqrt{y - 2}$, dropping the $+3$: $3 + 6$."),
               (r"$-3$", "Uses the other branch $g(y) = 3 - \\sqrt{y - 2}$: $0 + (-3)$."),
               (r"$3$", "Writes the inverse as $\\sqrt{y - 2} - 3$: $0 + 3$.")],
  check=_c012, values=[15, 9, -3, 3], cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    k = symbols('k')
    f = lambda t: (3*t + 7) / (t + k)
    num = numer(together(f(f(x)) - x))
    eqs = Poly(expand(num), x).all_coeffs()
    sols = solve(eqs, k, dict=True)
    return [s[k] for s in sols][0]
q("C14-A-011", T, "Parameter that makes a linear fractional function its own inverse", "Medium",
  "Inverse/parameter",
  r"For a real constant $k$, let $f(x) = \frac{3x + 7}{x + k}$ for $x \ne -k$. For which value of $k$ is $f$ its own inverse, that is, $f(f(x)) = x$ for every $x$ in its domain?",
  "MCQ",
  r"Solve $y = \frac{3x + 7}{x + k}$ for $x$: $xy + ky = 3x + 7$, so $x = \frac{-ky + 7}{y - 3}$. For this to be the same rule as $\frac{3y + 7}{y + k}$ we need $-k = 3$ and $-3 = k$, both giving $k = -3$. (For a function $\frac{ax + b}{cx + d}$ this is the condition $a + d = 0$.)",
  "Matching the wrong coefficients, or choosing the value that makes the function constant.",
  "C14A-inverse-parameter", "Requires finding the inverse symbolically and matching coefficients.",
  correct=r"$-3$",
  distractors=[(r"$3$", "Sets $d = a$ instead of $d = -a$."),
               (r"$\frac{7}{3}$", "Makes numerator and denominator proportional, which makes $f$ the constant $3$ and not invertible."),
               (r"$-\frac{7}{3}$", "Sign slip on the proportionality value $3k = 7$.")],
  check=_c013, values=[-3, 3, Rational(7, 3), Rational(-7, 3)], cognitive="Analysis")

# ---------------------------------------------------------------- 014
def _c014():
    # f(x) = x^2 - 4x + 6 on x >= 2, inverse g(y) = 2 + sqrt(y - 2) on y >= 2
    sols = solve(Eq(x**2 - 4*x + 6, 2 + sqrt(x - 2)), x)
    sols = [s for s in sols if s.is_real and s >= 2]
    return sum(s**2 for s in sols)
q("C14-A-012", T, "Points where an increasing function equals its inverse", "Medium",
  "Conceptual/application",
  r"Let $f(x) = x^2 - 4x + 6$ for $x \ge 2$, so that $f$ has an inverse $f^{-1}$ defined for $x \ge 2$. Find the sum of the squares of all real numbers $x \ge 2$ for which $f(x) = f^{-1}(x)$.",
  "TITA",
  r"$f$ is increasing on $x \ge 2$, so $f(x) = f^{-1}(x)$ happens exactly when $f(x) = x$ (if $f(x) > x$ then applying the increasing $f^{-1}$ gives $x > f^{-1}(x)$, so $f(x) > f^{-1}(x)$; similarly for $<$). Then $x^2 - 5x + 6 = 0$, so $x = 2$ or $x = 3$, both allowed. The sum of squares is $4 + 9 = 13$.",
  "Discarding the boundary point $x = 2$, or reporting the sum instead of the sum of squares.",
  "C14A-inverse-meets-function", "Uses the principle that an increasing function meets its inverse only on the line $y = x$.",
  tita_answer=13, check=_c014, cognitive="Understanding",
  tita_traps=[(5, "Reports the sum $2 + 3$ rather than the sum of squares."),
              (9, "Discards the endpoint $x = 2$ of the domain.")])

# ---------------------------------------------------------------- 015
def _c015():
    # f(x+y) = f(x)+f(y)+xy, f(1)=3 ; step through integers
    f = {1: Integer(3)}
    f[2] = f[1] + f[1] + 1 * 1
    f[4] = f[2] + f[2] + 2 * 2
    # cross-check through 3
    f3 = f[2] + f[1] + 2 * 1
    assert f3 + f[1] + 3 * 1 == f[4]
    return f[4]
q("C14-A-013", T, "Additive functional equation with an extra product term", "Easy",
  "Single-step computation",
  r"A function $f$ satisfies $f(x + y) = f(x) + f(y) + xy$ for all real $x$ and $y$, and $f(1) = 3$. Then $f(4)$ equals",
  "MCQ",
  r"Put $x = y = 1$: $f(2) = 3 + 3 + 1 = 7$. Put $x = y = 2$: $f(4) = 7 + 7 + 4 = 18$.",
  "Dropping the extra $xy$ term and treating $f$ as linear.",
  "C14A-fe-additive-plus-term", "Two substitutions into the equation.",
  correct=r"$18$",
  distractors=[(r"$12$", "Ignores the $xy$ term and takes $f(4) = 4 f(1)$."),
               (r"$20$", "Adds $x + y$ in place of $xy$: $f(2) = 8$, then $f(4) = 8 + 8 + 4$."),
               (r"$14$", "Includes $xy$ for $f(2) = 7$ but drops it in the second step: $7 + 7$.")],
  check=_c015, values=[18, 12, 20, 14], cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    a, b = symbols('a b')
    r = Rational(27, 2)
    fac = factorrat(r)  # {2: -1, 3: 3}
    return fac.get(2, 0) * a + fac.get(3, 0) * b
q("C14-A-014", T, "Logarithmic functional equation f(xy) = f(x) + f(y)", "Medium",
  "Conceptual/application",
  r"A function $f$ defined on the positive real numbers satisfies $f(xy) = f(x) + f(y)$ for all positive $x$ and $y$. If $f(2) = a$ and $f(3) = b$, then $f(13.5)$ equals",
  "MCQ",
  r"First $f(1) = f(1) + f(1)$ gives $f(1) = 0$, and $f(2) + f(\frac{1}{2}) = f(1) = 0$ gives $f(\frac{1}{2}) = -a$. Also $f(27) = 3f(3) = 3b$. Since $13.5 = \frac{27}{2}$, $f(13.5) = f(27) + f(\frac{1}{2}) = 3b - a$.",
  "Treating division inside $f$ as division of values, or getting the sign of $f(\\frac{1}{2})$ wrong.",
  "C14A-fe-cauchy-log", "Needs $f(1) = 0$ and $f(\\frac{1}{x}) = -f(x)$ before combining.",
  correct=r"$3b - a$",
  distractors=[(r"$3b + a$", "Takes $f(\\frac{1}{2}) = f(2) = a$."),
               (r"$a - 3b$", "Gets the overall sign reversed, writing $f(\\frac{27}{2}) = f(2) - f(27)$."),
               (r"$\frac{3b}{a}$", "Assumes $f(\\frac{p}{q}) = \\frac{f(p)}{f(q)}$.")],
  check=_c016,
  values=[Symbol('b')*3 - Symbol('a'), 3*Symbol('b') + Symbol('a'), Symbol('a') - 3*Symbol('b'), 3*Symbol('b')/Symbol('a')],
  cognitive="Application")

# ---------------------------------------------------------------- 017
def _c017():
    # f(x+y) = f(x) f(y); f(2) = 9; f(1) = f(1/2)^2 >= 0 and f(1)^2 = 9
    c = symbols('c', real=True)
    roots = [r for r in solve(Eq(c**2, 9), c) if r >= 0]
    f1 = roots[0]
    return sum(f1**k for k in range(1, 6))
q("C14-A-015", T, "Exponential functional equation f(x + y) = f(x) f(y) with a sign check", "Medium",
  "Conceptual/application",
  r"A real-valued function $f$ satisfies $f(x + y) = f(x)\,f(y)$ for all real $x$ and $y$, and $f(2) = 9$. Find the value of $f(1) + f(2) + f(3) + f(4) + f(5)$.",
  "TITA",
  r"$f(1) = f(\frac{1}{2})^2 \ge 0$ and $f(1)^2 = f(2) = 9$, so $f(1) = 3$. Then $f(k) = 3^k$ for positive integers $k$, and the sum is $3 + 9 + 27 + 81 + 243 = 363$.",
  "Not noticing that $f(1)$ must be non-negative, or summing the wrong range of terms.",
  "C14A-fe-cauchy-exp", "Needs the observation $f(x) = f(x/2)^2 \\ge 0$ to fix the sign of $f(1)$.",
  tita_answer=363, check=_c017, cognitive="Application",
  tita_traps=[(243, "Reports $f(5)$ alone."),
              (120, "Stops at $f(4)$: $3 + 9 + 27 + 81$.")])

# ---------------------------------------------------------------- 018
def _c018():
    # f(x+y) = f(x)+f(y)+6xy, f(2)=10. Work on integers from f(0), f(1).
    f1 = symbols('f1')
    f0 = 0  # f(0) = 2 f(0) gives f(0) = 0
    f2 = f1 + f1 + 6
    v1 = solve(Eq(f2, 10), f1)[0]
    vals = {0: Integer(f0), 1: v1}
    for n in range(2, 4):
        vals[n] = vals[n - 1] + vals[1] + 6 * (n - 1) * 1
    # f(3) + f(-3) = f(0) - 6*3*(-3)  ->  f(-3) = 54 - f(3)
    return vals[0] + 54 - vals[3]
q("C14-A-016", T, "Value at a negative argument for f(x + y) = f(x) + f(y) + 6xy", "Medium",
  "Conceptual/application",
  r"A function $f$ satisfies $f(x + y) = f(x) + f(y) + 6xy$ for all real $x$ and $y$, and $f(2) = 10$. Then $f(-3)$ equals",
  "MCQ",
  r"$x = y = 0$ gives $f(0) = 0$. From $f(2) = 2f(1) + 6 = 10$, $f(1) = 2$, then $f(3) = f(2) + f(1) + 12 = 24$. Finally $x = 3$, $y = -3$: $0 = f(3) + f(-3) - 54$, so $f(-3) = 54 - 24 = 30$. (Indeed $f(x) = 3x^2 - x$.)",
  "Assuming $f$ is odd, or ignoring the product term.",
  "C14A-fe-additive-plus-term", "Several substitutions, including a negative argument where the odd-function shortcut fails.",
  correct=r"$30$",
  distractors=[(r"$-15$", "Ignores the $6xy$ term, takes $f(x) = 5x$."),
               (r"$-24$", "Assumes $f(-3) = -f(3)$ as for a purely additive function."),
               (r"$24$", "Reports $f(3)$ and stops before the step to $-3$.")],
  check=_c018, values=[30, -15, -24, 24], cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    p, r = symbols('p r')  # p = f(5), r = f(-4)
    rhs = lambda t: t**2 + 2
    s = solve([Eq(p + 2*r, rhs(5)), Eq(r + 2*p, rhs(-4))], [p, r])
    return s[p]
q("C14-A-017", T, "Functional equation pairing x with 1 - x", "Medium",
  "Single-step computation",
  r"A function $f$ satisfies $f(x) + 2f(1 - x) = x^2 + 2$ for all real $x$. Then $f(5)$ equals",
  "MCQ",
  r"$x = 5$ gives $f(5) + 2f(-4) = 27$; $x = -4$ gives $f(-4) + 2f(5) = 18$. Doubling the second, $2f(-4) + 4f(5) = 36$; subtracting the first, $3f(5) = 9$, so $f(5) = 3$ (and $f(-4) = 12$).",
  "Assuming $f(1 - x) = f(x)$, or solving the pair of equations for the wrong unknown.",
  "C14A-fe-substitution-system", "Requires the replacement $x \\to 1 - x$ and a two-equation elimination.",
  correct=r"$3$",
  distractors=[(r"$9$", "Treats $f(1 - x)$ as $f(x)$: $3f(5) = 27$."),
               (r"$12$", "Solves the system but reports $f(-4)$."),
               (r"$-3$", "Subtracts the equations in the wrong order, getting $-3f(5) = 9$.")],
  check=_c019, values=[3, 9, 12, -3], cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    h = lambda t: -(t + 1) / t
    a = Integer(2); b = h(a); c = h(b)
    assert h(c) == a
    fa, fb, fc = symbols('fa fb fc')
    s = solve([Eq(fa + fb, 12*a), Eq(fb + fc, 12*b), Eq(fc + fa, 12*c)], [fa, fb, fc])
    return s[fa]
q("C14-A-018", T, "Functional equation along a three-cycle of the map x to -(x + 1)/x", "Difficult",
  "Conceptual/application",
  r"A function $f$ is defined for all real $x$ other than $0$ and $-1$, and satisfies $f(x) + f\left(-\frac{x + 1}{x}\right) = 12x$ for every such $x$. Find the value of $f(2)$.",
  "TITA",
  r"Under $x \to -\frac{x + 1}{x} = -1 - \frac{1}{x}$: $2 \to -\frac{3}{2} \to -\frac{1}{3} \to 2$. So $f(2) + f(-\frac{3}{2}) = 24$, $f(-\frac{3}{2}) + f(-\frac{1}{3}) = -18$, $f(-\frac{1}{3}) + f(2) = -4$. Adding, twice the sum of the three values is $2$, so the sum is $1$, and $f(2) = 1 - (-18) = 19$.",
  "Guessing $f(x) = 6x$, or stopping at the sum of the three values.",
  "C14A-fe-substitution-system", "Requires spotting a three-cycle of substitutions and solving a cyclic linear system.",
  tita_answer=19, check=_c021, cognitive="Analysis", exams=CX,
  tita_traps=[(12, "Guesses $f(x) = 6x$, which does not satisfy the equation."),
              (1, "Reports the sum $f(2) + f(-\\frac{3}{2}) + f(-\\frac{1}{3})$."),
              (5, r"Solves the cyclic system correctly but reports $f(-\frac{3}{2}) = 24 - 19 = 5$ instead of $f(2)$.")])

# ---------------------------------------------------------------- 022
def _c022():
    f = lambda t: Integer(25)**t / (Integer(25)**t + 5)
    return nsimplify(sum(f(Rational(k, 41)) for k in range(1, 41)).simplify())
q("C14-A-019", T, "Sum using the pairing f(x) + f(1 - x) = 1", "Medium",
  "Conceptual/application",
  r"Let $f(x) = \frac{25^x}{25^x + 5}$. Find the value of $f\left(\frac{1}{41}\right) + f\left(\frac{2}{41}\right) + f\left(\frac{3}{41}\right) + \cdots + f\left(\frac{40}{41}\right)$.",
  "TITA",
  r"With $t = 25^x$, $25^{1 - x} = \frac{25}{t}$, so $f(1 - x) = \frac{25/t}{25/t + 5} = \frac{5}{t + 5}$ and $f(x) + f(1 - x) = \frac{t + 5}{t + 5} = 1$. The $40$ terms form $20$ pairs $\frac{k}{41}, \frac{41 - k}{41}$, each summing to $1$. The total is $20$.",
  "Miscounting the pairs or treating each term as contributing $1$.",
  "C14A-fe-pairing-sum", "Needs the complementary pairing identity; direct computation is impossible.",
  tita_answer=20, check=_c022, cognitive="Understanding",
  tita_traps=[(40, "Treats each of the $40$ terms, rather than each pair, as worth $1$."),
              (21, "Sums from $k = 0$ to $k = 41$, adding the extra pair $f(0) + f(1) = 1$.")])

# ---------------------------------------------------------------- 023
def _c023():
    f = lambda t: t**2 / (1 + t**2)
    s = sum(f(Rational(1, k)) for k in range(2, 11)) + sum(f(Integer(k)) for k in range(1, 11))
    return nsimplify(s)
q("C14-A-020", T, "Sum using the pairing f(x) + f(1/x) = 1 with an unpaired middle term", "Medium",
  "Conceptual/application",
  r"Let $f(x) = \frac{x^2}{1 + x^2}$. The value of $f\left(\frac{1}{10}\right) + f\left(\frac{1}{9}\right) + \cdots + f\left(\frac{1}{2}\right) + f(1) + f(2) + \cdots + f(10)$ is",
  "MCQ",
  r"$f\left(\frac{1}{x}\right) = \frac{1/x^2}{1 + 1/x^2} = \frac{1}{x^2 + 1}$, so $f(x) + f\left(\frac{1}{x}\right) = 1$. The terms $f(k), f(\frac{1}{k})$ for $k = 2, \ldots, 10$ give $9$ pairs, total $9$. The term $f(1) = \frac{1}{2}$ is unpaired. Total $\frac{19}{2}$.",
  "Treating $f(1)$ as a complete pair, or omitting it.",
  "C14A-fe-pairing-sum", "Pairing identity plus correct treatment of the self-paired term.",
  correct=r"$\frac{19}{2}$",
  distractors=[(r"$10$", "Counts $f(1)$ as a full pair worth $1$, giving $10$ pairs."),
               (r"$9$", "Pairs $k = 2$ to $10$ and leaves out $f(1)$."),
               (r"$\frac{17}{2}$", "Miscounts the pairs for $k = 2$ to $10$ as $8$, then adds $f(1) = \\frac{1}{2}$.")],
  check=_c023, values=[Rational(19, 2), 10, 9, Rational(17, 2)], cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    f = lambda t: 1 / (1 - t)
    v = Rational(2, 5)
    for _ in range(2027):
        v = f(v)
    return v
q("C14-A-021", T, "Large iterate of a map of period three", "Medium",
  "Conceptual/application",
  r"Let $f(x) = \frac{1}{1 - x}$ for $x \ne 0, 1$, and let $f^{n}$ denote $f$ applied $n$ times, so $f^{2}(x) = f(f(x))$. The value of $f^{2027}\left(\frac{2}{5}\right)$ is",
  "MCQ",
  r"$f\left(\frac{2}{5}\right) = \frac{5}{3}$, $f\left(\frac{5}{3}\right) = \frac{1}{-2/3} = -\frac{3}{2}$, $f\left(-\frac{3}{2}\right) = \frac{1}{5/2} = \frac{2}{5}$. So $f^3$ is the identity here. Since $2027 = 3 \times 675 + 2$, $f^{2027}\left(\frac{2}{5}\right) = f^{2}\left(\frac{2}{5}\right) = -\frac{3}{2}$.",
  "Using the wrong remainder, or slipping in the formula for $f(f(x))$.",
  "C14A-iterated-mobius-cycle", "Requires discovering the period and reducing a large index.",
  correct=r"$-\frac{3}{2}$",
  distractors=[(r"$\frac{5}{3}$", "Takes the remainder of $2027$ on division by $3$ as $1$."),
               (r"$\frac{2}{5}$", "Takes $2027$ as a multiple of $3$."),
               (r"$-\frac{2}{3}$", "Uses $f(f(x)) = \\frac{x}{x - 1}$ in place of $\\frac{x - 1}{x}$.")],
  check=_c024, values=[Rational(-3, 2), Rational(5, 3), Rational(2, 5), Rational(-2, 3)], cognitive="Application")

# ---------------------------------------------------------------- 025
def _c025():
    f = lambda t: (t + 1) / (t - 1)
    v = Rational(7, 3)
    for _ in range(51):
        v = f(v)
    return v
q("C14-A-022", T, "Odd iterate of a self-inverse function", "Easy",
  "Conceptual/application",
  r"Let $f(x) = \frac{x + 1}{x - 1}$ for $x \ne 1$. If $f$ is applied $51$ times in succession, starting with the input $\frac{7}{3}$, the final output is",
  "MCQ",
  r"$f(f(x)) = \frac{\frac{x+1}{x-1} + 1}{\frac{x+1}{x-1} - 1} = \frac{2x}{2} = x$, so applying $f$ twice returns the input. After $51$ applications (odd) the output is $f\left(\frac{7}{3}\right) = \frac{10/3}{4/3} = \frac{5}{2}$.",
  "Assuming an even outcome, or inverting the formula.",
  "C14A-iterated-mobius-cycle", "One observation ($f$ is its own inverse) and one evaluation.",
  correct=r"$\frac{5}{2}$",
  distractors=[(r"$\frac{7}{3}$", "Takes $51$ applications to return the input, as for an even count."),
               (r"$\frac{2}{5}$", "Uses $\\frac{x - 1}{x + 1}$, the reciprocal formula."),
               (r"$-\frac{5}{2}$", "Writes the denominator as $1 - x$.")],
  check=_c025, values=[Rational(5, 2), Rational(7, 3), Rational(2, 5), Rational(-5, 2)], cognitive="Understanding")

# ---------------------------------------------------------------- 026
def _c026():
    f = {1: Integer(2), 2: Integer(5)}
    for n in range(1, 2025):
        f[n + 2] = (1 + f[n + 1]) / f[n]
    return sum(f[n] for n in range(1, 2027))
q("C14-A-023", T, "Sum of values of a function on the positive integers given by a two-term recurrence with a hidden period of five", "Difficult",
  "Conceptual/application",
  r"A function $f$ on the positive integers satisfies $f(1) = 2$, $f(2) = 5$ and $f(n + 2) = \frac{1 + f(n + 1)}{f(n)}$ for every $n \ge 1$. The value of $f(1) + f(2) + f(3) + \cdots + f(2026)$ is",
  "MCQ",
  r"$f(3) = \frac{6}{2} = 3$, $f(4) = \frac{4}{5}$, $f(5) = \frac{9/5}{3} = \frac{3}{5}$, $f(6) = \frac{8/5}{4/5} = 2$, $f(7) = \frac{3}{3/5} = 5$. Since $f(6), f(7)$ repeat $f(1), f(2)$ and each value is fixed by the two before it, the values repeat with period $5$. One block sums to $2 + 5 + 3 + \frac{4}{5} + \frac{3}{5} = \frac{57}{5}$. As $2026 = 5 \times 405 + 1$, the sum is $405 \times \frac{57}{5} + f(2026) = 81 \times 57 + f(1) = 4617 + 2 = 4619$.",
  "Ignoring or misidentifying the leftover term after the complete periods.",
  "C14A-integer-periodic-recurrence", "The period of five is not visible until five fractional terms are computed from a two-term rule, and the block sum and leftover term must then be handled correctly.",
  correct=r"$4619$",
  distractors=[(r"$4617$", "Treats $2026$ as a whole number of periods and ignores the leftover term."),
               (r"$4622$", "Takes the leftover term as $f(2) = 5$ instead of $f(1) = 2$."),
               (r"$4624$", "Counts two leftover terms after the $405$ blocks, adding $f(1) + f(2) = 7$.")],
  check=_c026, values=[4619, 4617, 4622, 4624], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 027
def _c027():
    f = lambda t: 3*t - 2
    return solve(Eq(f(f(f(x))), 55), x)[0]
q("C14-A-024", T, "Solving a threefold iterate of a linear function", "Easy",
  "Inverse/parameter",
  r"Let $f(x) = 3x - 2$. Find the real number $x$ for which $f(f(f(x))) = 55$.",
  "TITA",
  r"$f(f(x)) = 3(3x - 2) - 2 = 9x - 8$ and $f(f(f(x))) = 3(9x - 8) - 2 = 27x - 26$. So $27x = 81$ and $x = 3$. (Working backwards also works: $55 \to 19 \to 7 \to 3$ via $y \to \frac{y + 2}{3}$.)",
  "Stopping after undoing one or two applications of $f$.",
  "C14A-iterated-linear", "Short composition or backward working.",
  tita_answer=3, check=_c027, cognitive="Application",
  tita_traps=[(19, "Solves $f(x) = 55$ only."),
              (7, "Solves $f(f(x)) = 55$, undoing only two applications.")])

# ---------------------------------------------------------------- 028
def _c028():
    v, n = 1, 0
    while v < 10000:
        v = 3 * v + 2
        n += 1
    return n
q("C14-A-025", T, "Least number of iterations of a linear map to exceed a threshold", "Medium",
  "Inverse/parameter",
  r"Let $f(x) = 3x + 2$. Starting with the number $1$, the function $f$ is applied repeatedly, giving $f(1), f(f(1)), \ldots$. What is the least number of applications of $f$ after which the result is at least $10{,}000$?",
  "TITA",
  r"Since $f(x) + 1 = 3(x + 1)$, after $n$ applications the value is $3^n \times (1 + 1) - 1 = 2 \cdot 3^n - 1$. We need $2 \cdot 3^n \ge 10001$, that is $3^n \ge 5000.5$. As $3^7 = 2187$ and $3^8 = 6561$, the least $n$ is $8$ (value $13121$; after $7$ steps it is only $4373$).",
  "Approximating the $n$-th value by $3^n$ and forgetting the factor $2$.",
  "C14A-iterated-linear", "Needs the closed form of an iterated affine map and a threshold comparison.",
  tita_answer=8, check=_c028, cognitive="Application",
  tita_traps=[(9, "Uses $3^n \\ge 10000$, ignoring the factor $2$; or counts the seed $1$ as a term, since $1, 5, 17, \\ldots, 13121$ is $9$ numbers."),
              (7, "Reports the last count still below the threshold: after $7$ applications the value is only $4373$.")])

# ---------------------------------------------------------------- 029
def _c029():
    f = {1: 1}
    for n in range(2, 101):
        f[n] = f[n // 2] if n % 2 == 0 else f[n // 2] + 1
    return sum(1 for n in range(1, 101) if f[n] == 3)
q("C14-A-026", T, "Counting integers with a given value of a recursively defined function (binary digit count)", "Difficult",
  "Casework/optimisation",
  r"A function $f$ on the positive integers satisfies $f(1) = 1$, and for every positive integer $n$, $f(2n) = f(n)$ and $f(2n + 1) = f(n) + 1$. For how many integers $n$ with $1 \le n \le 100$ is $f(n) = 3$?",
  "TITA",
  r"The rules say $f(n)$ is the number of $1$s in the binary form of $n$ (appending $0$ keeps the count, appending $1$ adds one). Numbers below $64$ have at most $6$ binary digits, so there are $\binom{6}{3} = 20$ of them with three $1$s. From $64$ to $100$, write $n = 64 + m$ with $0 \le m \le 36$ and $m$ having two $1$s: pairs from $\{1, 2, 4, 8, 16\}$ give $\binom{5}{2} = 10$, and $32$ with $1, 2$ or $4$ gives $33, 34, 36$, so $3$ more. Total $20 + 10 + 3 = 33$.",
  "Counting all $7$-digit binary numbers up to $127$, or stopping at $63$.",
  "C14A-integer-binary-recursion", "Requires decoding the recursion as a binary digit count and then a bounded count with casework.",
  tita_answer=33, check=_c029, cognitive="Analysis", exams=CX,
  tita_traps=[(35, "Counts all numbers below $128$, $\\binom{7}{3}$, ignoring the bound $100$."),
              (20, "Counts only numbers below $64$.")])

# ---------------------------------------------------------------- 030
def _c030():
    f = lambda n: n // 2 if n % 2 == 0 else n + 5
    v, s = 1, 0
    for _ in range(50):
        v = f(v)
        s += v
    return s
q("C14-A-027", T, "Sum of iterates of a piecewise function on integers that enters a cycle", "Medium",
  "Conceptual/application",
  r"A function on the positive integers is defined by $f(n) = \frac{n}{2}$ if $n$ is even and $f(n) = n + 5$ if $n$ is odd. Starting from $1$, let $a_1 = f(1)$ and $a_{k+1} = f(a_k)$ for $k \ge 1$. Find $a_1 + a_2 + \cdots + a_{50}$.",
  "TITA",
  r"$a_1 = 6, a_2 = 3, a_3 = 8, a_4 = 4, a_5 = 2, a_6 = 1$, after which the pattern repeats with period $6$ and block sum $24$. Since $50 = 6 \times 8 + 2$, the sum is $8 \times 24 + a_{49} + a_{50} = 192 + 6 + 3 = 201$.",
  "Ignoring the leftover terms, or starting the sum from the seed value $1$.",
  "C14A-integer-piecewise-iteration", "Find the cycle and handle a partial block.",
  tita_answer=201, check=_c030, cognitive="Application",
  tita_traps=[(192, "Counts only the $8$ complete cycles."),
              (199, "Sums $1, f(1), \\ldots$ fifty terms starting from the seed $1$, so $192 + 1 + 6$.")])

# ---------------------------------------------------------------- 031
def _c031():
    f = lambda n: n // 2 if n % 2 == 0 else n + 5
    c = 0
    for n in range(1, 41):
        seen, m = set(), n
        while m not in seen:
            seen.add(m); m = f(m)
        c += 1 in seen
    return c
q("C14-A-028", T, "Which starting integers reach 1 under a piecewise map (invariant under divisibility by 5)", "Difficult",
  "Casework/optimisation",
  r"A function on the positive integers is defined by $f(n) = \frac{n}{2}$ if $n$ is even and $f(n) = n + 5$ if $n$ is odd. For a starting integer $n$, consider the sequence $n, f(n), f(f(n)), \ldots$. For how many $n$ in $\{1, 2, \ldots, 40\}$ does this sequence contain the number $1$?",
  "MCQ",
  r"$f(n)$ is a multiple of $5$ exactly when $n$ is ($n + 5$ differs from $n$ by $5$, and $\frac{n}{2}$ is a multiple of $5$ exactly when $n$ is), so multiples of $5$ never reach $1$; they fall into $5 \to 10 \to 5$. For other $n$, an odd $n > 5$ goes to $\frac{n + 5}{2} < n$ after two steps and an even $n$ halves, so the values drop until they are at most $5$, where $1 \to 6 \to 3 \to 8 \to 4 \to 2 \to 1$ contains $1$. So the count is $40 - 8 = 32$.",
  "Thinking even multiples of $5$ escape by halving, or reporting the complementary count.",
  "C14A-integer-piecewise-iteration", "Needs an invariant (divisibility by $5$) and a descent argument rather than case by case iteration.",
  correct=r"$32$",
  distractors=[(r"$8$", "Reports the number of starting values that never reach $1$."),
               (r"$36$", "Excludes only the odd multiples of $5$, believing $10, 20, 30, 40$ escape by halving."),
               (r"$39$", "Excludes only $5$ itself, the one value seen to be stuck.")],
  check=_c031, values=[32, 8, 36, 39], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 032
def _c032():
    S = range(4)
    return sum(1 for f in itertools.product(S, repeat=4) if all(f[f[i]] == f[i] for i in S))
q("C14-A-029", T, "Counting functions on a four-element set with f(f(x)) = f(x)", "Difficult",
  "Casework/optimisation",
  r"How many functions $f$ from the set $\{1, 2, 3, 4\}$ to itself satisfy $f(f(x)) = f(x)$ for every $x$ in the set?",
  "TITA",
  r"The condition says $f$ fixes every value in its image. Choose the image $I$ with $|I| = k$: the elements of $I$ map to themselves and each of the other $4 - k$ elements maps to any element of $I$, giving $k^{4-k}$ ways. Total $\binom{4}{1}1^3 + \binom{4}{2}2^2 + \binom{4}{3}3^1 + \binom{4}{4}4^0 = 4 + 24 + 12 + 1 = 41$.",
  "Counting only image sets, or forgetting that elements outside the image can map anywhere in it.",
  "C14A-counting-functions", "Needs a structural characterisation of the condition and a case sum over the image size.",
  tita_answer=41, check=_c032, cognitive="Analysis", exams=CX,
  tita_traps=[(15, "Counts only the possible non-empty image sets, $2^4 - 1$."),
              (40, "Leaves out the identity function.")])

# ---------------------------------------------------------------- 033
def _c033():
    S = range(6)
    return sum(1 for f in itertools.product(S, repeat=6) if all(f[f[i]] == i for i in S))
q("C14-A-030", T, "Counting self-inverse functions on a six-element set", "Difficult",
  "Casework/optimisation",
  r"How many functions $f$ from the set $\{1, 2, 3, 4, 5, 6\}$ to itself satisfy $f(f(x)) = x$ for every $x$ in the set?",
  "TITA",
  r"Such an $f$ is a bijection made of fixed points and swapped pairs. With $0$ swaps: $1$ (the identity). With $1$ swap: $\binom{6}{2} = 15$. With $2$ swaps: choose the four elements in $\binom{6}{4} = 15$ ways and split them into two pairs in $3$ ways, $45$. With $3$ swaps: split all six into three pairs in $5 \times 3 \times 1 = 15$ ways. Total $1 + 15 + 45 + 15 = 76$.",
  "Forgetting the identity, missing the case with three swaps, or overcounting the pairings by treating the pairs as ordered.",
  "C14A-counting-functions", "Needs the structural characterisation as fixed points plus swaps and four cases, two of which need careful counting of unordered pairings.",
  tita_answer=76, check=_c033, cognitive="Analysis", exams=CX,
  tita_traps=[(75, "Leaves out the identity function."),
              (61, "Misses the case with three swaps and no fixed point."),
              (196, "Picks the pairs one after another without dividing by their orderings: $\\binom{6}{2}\\binom{4}{2} = 90$ for two swaps and $\\binom{6}{2}\\binom{4}{2}\\binom{2}{2} = 90$ for three swaps.")])

# ---------------------------------------------------------------- 034
def _c034():
    cands = [x*Abs(x), x**2 + x, Abs(x)**3, x**3 + 1]
    odd = [c for c in cands if all(simplify(c.subs(x, v) + c.subs(x, -v)) == 0 for v in (1, 2, Rational(7, 3), 5))]
    assert len(odd) == 1
    c = odd[0]
    return c.subs(x, 2) + c.subs(x, -2)
q("C14-A-031", T, "Identifying an odd function among simple algebraic functions", "Easy",
  "Conceptual/application",
  r"Which of the following functions, defined for all real $x$, is an odd function?",
  "MCQ",
  r"An odd function satisfies $f(-x) = -f(x)$. For $f(x) = x|x|$: $f(-x) = (-x)|-x| = -x|x| = -f(x)$, so it is odd. The others fail: $x^2 + x$ at $x = 1, -1$ gives $2$ and $0$; $|x|^3$ is even; $x^3 + 1$ gives $f(0) = 1 \ne 0$.",
  "Calling a function odd because it contains an odd power, ignoring added constants or absolute values.",
  "C14A-even-odd-identify", "Direct test of the definition.",
  correct=r"$f(x) = x|x|$",
  distractors=[(r"$f(x) = x^2 + x$", "Sees the odd term $x$ and overlooks the even part $x^2$."),
               (r"$f(x) = |x|^3$", "Associates the cube with oddness, ignoring the absolute value."),
               (r"$f(x) = x^3 + 1$", "Ignores the constant term, which breaks $f(-x) = -f(x)$.")],
  check=_c034, values=[0, 8, 16, 2], cognitive="Understanding")

# ---------------------------------------------------------------- 035
def _c035():
    f2, g2 = 7, 4
    fm2, gm2 = -f2, g2           # odd and even
    h = lambda fv, gv: fv * gv + fv**2
    return h(f2, g2) - h(fm2, gm2)
q("C14-A-032", T, "Evaluating an expression built from an odd and an even function at x and -x", "Easy",
  "Single-step computation",
  r"$f$ is an odd function and $g$ is an even function, both defined for all real numbers, with $f(2) = 7$ and $g(2) = 4$. Let $h(x) = f(x)\,g(x) + [f(x)]^2$. Find the value of $h(2) - h(-2)$.",
  "TITA",
  r"$f(-2) = -7$ and $g(-2) = 4$. So $h(2) = 28 + 49 = 77$ and $h(-2) = -28 + 49 = 21$. The difference is $56$. (The square term is even and cancels; the product term is odd and doubles: $2 \times 28$.)",
  "Treating the whole of $h$ as even, or squaring a negative value carelessly.",
  "C14A-even-odd-properties", "Uses the definitions directly with one sign trap.",
  tita_answer=56, check=_c035, cognitive="Application",
  tita_traps=[(0, "Assumes $h(-2) = h(2)$."),
              (154, "Takes $[f(-2)]^2 = -49$, so $h(-2) = -77$.")])

# ---------------------------------------------------------------- 036
def _c036():
    v = symbols('v0:6')
    eqs = [Eq(v[r], -v[(-r) % 6]) for r in range(6)] + [Eq(v[1], 5), Eq(v[2], 2)]
    s = solve(eqs, v, dict=True)[0]
    return sum(s[v[n % 6]] for n in (2025, 2026, 2027, 2028))
q("C14-A-033", T, "Odd periodic function: values at large arguments", "Medium",
  "Conceptual/application",
  r"A function $f$ defined for all real numbers is odd and satisfies $f(x + 6) = f(x)$ for every $x$. If $f(1) = 5$ and $f(2) = 2$, then $f(2025) + f(2026) + f(2027) + f(2028)$ equals",
  "MCQ",
  r"$2022$ is a multiple of $6$, so the four values are $f(3), f(4), f(5), f(6)$. Oddness and period give $f(3) = f(-3) = -f(3)$, so $f(3) = 0$; $f(4) = f(-2) = -2$; $f(5) = f(-1) = -5$; $f(6) = f(0) = 0$. The sum is $0 - 2 - 5 + 0 = -7$.",
  "Using the evenness rule for an odd function, or reducing the arguments with the wrong multiple of $6$.",
  "C14A-even-odd-periodic", "Combines oddness with periodicity, including the forced zeros at $f(0)$ and $f(3)$.",
  correct=r"$-7$",
  distractors=[(r"$7$", "Keeps $f(3) = f(6) = 0$ but uses $f(-x) = f(x)$ for the other two, so $f(4) = 2$ and $f(5) = 5$."),
               (r"$5$", "Treats $2024$ as a multiple of $6$, giving $f(1) + f(2) + f(3) + f(4) = 5 + 2 + 0 - 2$."),
               (r"$-3$", "Gets $f(5) = -5$ right but takes $f(4) = 2$.")],
  check=_c036, values=[-7, 7, 5, -3], cognitive="Application")

# ---------------------------------------------------------------- 037
def _c037():
    a, b = symbols('a b', real=True)
    s = solve([Eq(a**2, 9), Eq(a*b + b, 8)], [a, b], dict=True)
    s = [d for d in s if d[a] > 0][0]
    return s[a] * 5 + s[b]
q("C14-A-034", T, "Recovering a linear function from its composition with itself", "Easy",
  "Inverse/parameter",
  r"A function $f(x) = ax + b$ with $a > 0$ satisfies $f(f(x)) = 9x + 8$ for all real $x$. Find $f(5)$.",
  "TITA",
  r"$f(f(x)) = a(ax + b) + b = a^2 x + (a + 1)b$. So $a^2 = 9$ with $a > 0$ gives $a = 3$, and $4b = 8$ gives $b = 2$. Then $f(5) = 17$.",
  "Writing $f(f(x)) = a^2x + b$, missing the factor $(a + 1)$ on $b$.",
  "C14A-composition-linear-unknown", "Matching coefficients after one composition.",
  tita_answer=17, check=_c037, cognitive="Application",
  tita_traps=[(23, "Takes $f(f(x)) = a^2 x + b$, so $b = 8$."),
              (15, "Finds $a = 3$ and forgets to add $b$.")])

# ---------------------------------------------------------------- 038
def _c038():
    k = symbols('k')
    f = lambda t: 3*t + 4
    g = lambda t: 5*t + k
    return solve(Eq(expand(f(g(x)) - g(f(x))), 0), k)[0]
q("C14-A-035", T, "Parameter for which two linear functions commute under composition", "Medium",
  "Inverse/parameter",
  r"Let $f(x) = 3x + 4$ and $g(x) = 5x + k$, where $k$ is a real constant. For which value of $k$ is $f(g(x)) = g(f(x))$ for every real $x$?",
  "MCQ",
  r"$f(g(x)) = 3(5x + k) + 4 = 15x + 3k + 4$ and $g(f(x)) = 5(3x + 4) + k = 15x + 20 + k$. Equating constants, $3k + 4 = 20 + k$, so $k = 8$.",
  "Not distributing the outer coefficient over the inner constant.",
  "C14A-composition-linear-unknown", "Two compositions and one equation; the trap is the distribution step.",
  correct=r"$8$",
  distractors=[(r"$0$", "Writes $g(f(x))$ as $15x + 4 + k$, not multiplying $4$ by $5$."),
               (r"$-8$", "Multiplies $k$ by $5$ as well: $3k + 4 = 20 + 5k$."),
               (r"$12$", "Solves $3k + 4 = 20 + k$ as $2k = 24$.")],
  check=_c038, values=[8, 0, -8, 12], cognitive="Application")

# ---------------------------------------------------------------- 039
def _c039():
    inner = 5 - x**2
    return solve_univariate_inequality(inner - 1 >= 0, x, relational=False)
q("C14-A-036", T, "Domain of a composite function with a square root outside", "Easy",
  "Conceptual/application",
  r"Let $f(x) = \sqrt{x - 1}$ and $g(x) = 5 - x^2$. The domain of the real function $f(g(x))$ is",
  "MCQ",
  r"$f(g(x)) = \sqrt{5 - x^2 - 1} = \sqrt{4 - x^2}$, which needs $x^2 \le 4$. The domain is $[-2, 2]$.",
  "Giving the domain of $f$ alone, or requiring only $g(x) \\ge 0$.",
  "C14A-composition-domain", "One substitution and one quadratic inequality.",
  correct=r"$[-2, 2]$",
  distractors=[(r"$[1, \infty)$", "Gives the domain of $f$ itself."),
               (r"$(-\infty, -2] \cup [2, \infty)$", "Reverses the inequality $x^2 \\le 4$."),
               (r"$[-\sqrt{5}, \sqrt{5}]$", "Requires $g(x) \\ge 0$ rather than $g(x) \\ge 1$.")],
  check=_c039,
  values=[Interval(-2, 2), Interval(1, oo), Union(Interval(-oo, -2), Interval(2, oo)), Interval(-sqrt(5), sqrt(5))],
  cognitive="Understanding")

# ---------------------------------------------------------------- 040
def _c040():
    f = lambda t: t**2 - 2*t
    sols = solve(Eq(f(f(f(x))), 0), x)
    return len(set(simplify(s) for s in sols if s.is_real))
q("C14-A-037", T, "Number of real roots of a threefold composition of a quadratic", "Difficult",
  "Casework/optimisation",
  r"Let $f(x) = x^2 - 2x$ for all real $x$. The number of distinct real solutions of $f(f(f(x))) = 0$ is",
  "MCQ",
  r"$f(y) = 0$ means $y \in \{0, 2\}$. So $f(f(x)) \in \{0, 2\}$ means $f(x) \in \{0, 2, 1 + \sqrt{3}, 1 - \sqrt{3}\}$ (from $y^2 - 2y = 2$). The least value of $f$ is $f(1) = -1$, and all four targets exceed $-1$ (note $1 - \sqrt{3} \approx -0.73$), so each gives two distinct real $x$. The targets differ, so all $8$ solutions are distinct.",
  "Discarding the negative target value, or stopping one level early.",
  "C14A-composition-solve", "Three levels of preimages with a check against the minimum value of $f$.",
  correct=r"$8$",
  distractors=[(r"$6$", "Rejects $f(x) = 1 - \\sqrt{3}$, assuming $f(x)$ cannot be negative."),
               (r"$4$", "Counts the solutions of $f(f(x)) = 0$, one level short."),
               (r"$2$", "Uses only the root $0$ of $f(y) = 0$ at the two outer levels, so only $f(x) = 0$ remains.")],
  check=_c040, values=[8, 6, 4, 2], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 041
def _c041():
    def lod(n):
        while n % 2 == 0:
            n //= 2
        return n
    return sum(lod(n) for n in range(1, 101))
q("C14-A-038", T, "Sum of a recursively defined function on integers (largest odd divisor)", "Difficult",
  "Conceptual/application",
  r"A function $f$ on the positive integers satisfies $f(n) = n$ for every odd $n$ and $f(2n) = f(n)$ for every positive integer $n$. The value of $f(1) + f(2) + f(3) + \cdots + f(100)$ is",
  "MCQ",
  r"Let $S(m) = f(1) + \cdots + f(m)$. The odd $n \le m$ contribute $1 + 3 + \cdots$, which is $\lceil m/2 \rceil^2$, and the even $n = 2j$ contribute $f(j)$ for $j \le \lfloor m/2 \rfloor$. So $S(m) = \lceil m/2 \rceil^2 + S(\lfloor m/2 \rfloor)$. Then $S(1) = 1$, $S(3) = 4 + 1 = 5$, $S(6) = 9 + 5 = 14$, $S(12) = 36 + 14 = 50$, $S(25) = 169 + 50 = 219$, $S(50) = 625 + 219 = 844$, $S(100) = 2500 + 844 = 3344$.",
  "Stopping the recursion early, or mishandling the base case.",
  "C14A-integer-binary-recursion", "Requires setting up a halving recursion with care at odd sizes over six levels.",
  correct=r"$3344$",
  distractors=[(r"$2500$", "Adds only the odd numbers up to $99$."),
               (r"$3125$", "Uses only two levels: $2500 + 625$."),
               (r"$3343$", "Takes the base case $S(1)$ as $0$.")],
  check=_c041, values=[3344, 2500, 3125, 3343], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 042
def _c042():
    h = lambda t: Integer(2)**t + t**3 + t**2
    f = lambda t: (h(t) + h(-t)) / 2
    g = lambda t: (h(t) - h(-t)) / 2
    return simplify(f(2) - g(2))
q("C14-A-039", T, "Even and odd parts of a function that is neither", "Medium",
  "Conceptual/application",
  r"$f$ is an even function and $g$ is an odd function, both defined for all real numbers, such that $f(x) + g(x) = 2^x + x^3 + x^2$ for every real $x$. The value of $f(2) - g(2)$ is",
  "MCQ",
  r"Replace $x$ by $-x$: $f(-x) + g(-x) = f(x) - g(x)$. So $f(2) - g(2)$ equals the right side at $x = -2$: $2^{-2} + (-2)^3 + (-2)^2 = \frac{1}{4} - 8 + 4 = -\frac{15}{4}$.",
  "Treating $2^x$ as even or odd, or not changing the sign of the odd term at $-x$.",
  "C14A-even-odd-decomposition", "Upper Medium: one substitution $x \\to -x$ gives $f(x) - g(x)$ as the right side at $-x$, then a three-term evaluation with a sign trap.",
  correct=r"$-\frac{15}{4}$",
  distractors=[(r"$\frac{15}{4}$", "Computes $g(2) - f(2)$."),
               (r"$-\frac{17}{4}$", "Takes $2^{-2}$ as $-\\frac{1}{4}$."),
               (r"$\frac{49}{4}$", "Leaves the odd term unchanged: $\\frac{1}{4} + 8 + 4$.")],
  check=_c042, values=[Rational(-15, 4), Rational(15, 4), Rational(-17, 4), Rational(49, 4)],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 043
def _c043():
    return Intersection(solve_univariate_inequality(5 - 2*x >= 1, x, relational=False),
                        solve_univariate_inequality(5 - 2*x <= 7, x, relational=False))
q("C14-A-040", T, "Domain of f(5 - 2x) given the domain of f (decreasing inner map)", "Easy",
  "Single-step computation",
  r"A function $f$ is defined only for $1 \le x \le 7$. The function $h(x) = f(5 - 2x)$ is defined exactly for",
  "MCQ",
  r"$h(x)$ is defined when $5 - 2x$ lies in $[1, 7]$: $1 \le 5 - 2x \le 7$, so $-4 \le -2x \le 2$. Dividing by $-2$ reverses both inequalities: $2 \ge x \ge -1$, that is $-1 \le x \le 2$.",
  "Not reversing the inequalities when dividing by a negative number, or applying the inner map to the given interval.",
  "C14A-composition-domain", "One double inequality with a division by a negative number.",
  correct=r"$-1 \le x \le 2$",
  distractors=[(r"$-2 \le x \le 1$", "Inverts the inner map with the wrong sign, as $\\frac{x - 5}{2}$, and applies it to $[1, 7]$."),
               (r"$-9 \le x \le 3$", "Applies $5 - 2x$ to the interval $[1, 7]$, giving values from $-9$ to $3$."),
               (r"$3 \le x \le 6$", "Drops the minus sign and solves $1 \\le 2x - 5 \\le 7$.")],
  check=_c043, values=[Interval(-1, 2), Interval(-2, 1), Interval(-9, 3), Interval(3, 6)],
  cognitive="Understanding")
