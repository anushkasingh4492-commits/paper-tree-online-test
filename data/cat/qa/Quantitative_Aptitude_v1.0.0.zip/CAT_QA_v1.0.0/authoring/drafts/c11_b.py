import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Modulus"
CX = ("CAT", "XAT")
X = symbols('x', real=True)
R = Rational


# ---------------------------------------------------------------- helpers

def _abs_eq_set(expr):
    """Real solution set of expr = 0, expr built from polynomials in X and (non-nested) Abs.
    Splits the line at the zeros of every Abs argument, removes the Abs signs on each
    piece using the sign at a test point, and solves the resulting polynomial there."""
    crit = set()
    for a in expr.atoms(Abs):
        for r in solve(a.args[0], X):
            if r.is_real:
                crit.add(r)
    crit = sorted(crit)
    pts = set(c for c in crit if simplify(expr.subs(X, c)) == 0)
    ivs = []
    edges = [-oo] + crit + [oo]
    for lo, hi in zip(edges[:-1], edges[1:]):
        if lo == -oo and hi == oo:
            m = 0
        elif lo == -oo:
            m = hi - 1
        elif hi == oo:
            m = lo + 1
        else:
            m = (lo + hi) / 2
        e = expr.replace(lambda t: isinstance(t, Abs),
                         lambda t: t.args[0] * sign(t.args[0].subs(X, m)))
        e = expand(e)
        if e == 0:
            ivs.append(Interval.open(lo, hi))
            continue
        for r in solve(e, X):
            if r.is_real and lo < r < hi:
                pts.add(r)
    return Union(FiniteSet(*pts), *ivs)


def _pl_zero_set(f, bps):
    """Zero set of a piecewise-linear f (Python function on Rationals) whose kinks lie in bps."""
    bps = sorted(set(R(b) for b in bps))
    pts = set(p for p in bps if f(p) == 0)
    ivs = []
    edges = [None] + bps + [None]
    for lo, hi in zip(edges[:-1], edges[1:]):
        if lo is None:
            a, b = hi - 2, hi - 1
        elif hi is None:
            a, b = lo + 1, lo + 2
        else:
            a, b = lo + (hi - lo) / 3, lo + 2 * (hi - lo) / 3
        fa, fb = f(a), f(b)
        m = (fb - fa) / (b - a)
        if m == 0:
            if fa == 0:
                ivs.append(Interval.open(-oo if lo is None else lo, oo if hi is None else hi))
            continue
        r = a - fa / m
        if (lo is None or r > lo) and (hi is None or r < hi):
            pts.add(r)
    return Union(FiniteSet(*pts), *ivs)


def _n(S):
    return len(S) if isinstance(S, FiniteSet) else (0 if S == EmptySet else oo)


def _level_set(count, crit, want):
    """Set of k for which count(k) == want, given all the values of k where count can change."""
    crit = sorted(set(R(c) for c in crit))
    parts = [FiniteSet(c) for c in crit if count(c) == want]
    tests = [(crit[0] - 1, -oo, crit[0])]
    tests += [((a + b) / 2, a, b) for a, b in zip(crit, crit[1:])]
    tests += [(crit[-1] + 1, crit[-1], oo)]
    for t, lo, hi in tests:
        if count(t) == want:
            parts.append(Interval.open(lo, hi))
    return Union(*parts)


def _grid_min(f, lo, hi, den=4):
    return min(f(R(i, den)) for i in range(lo * den, hi * den + 1))


BP = range(-60, 61)

# ---------------------------------------------------------------- EASY (12)

def _c1():
    S = _abs_eq_set(Abs(3 * X - 7) - 11)
    return sum(S)
q("C11-B-001", T, "Sum of the roots of a single linear modulus equation", "Easy",
  "Single-step computation",
  r"The sum of all real values of $x$ that satisfy $|3x - 7| = 11$ is",
  "MCQ",
  r"Either $3x - 7 = 11$, giving $x = 6$, or $3x - 7 = -11$, giving $3x = -4$ and $x = -\frac{4}{3}$. The sum is $6 - \frac{4}{3} = \frac{14}{3}$. (Quick check: the two roots are symmetric about $x = \frac{7}{3}$, so they add to $2 \times \frac{7}{3}$.)",
  "Dropping the negative case, or mishandling the constant when solving $3x - 7 = -11$.",
  "C11B-linear-modulus-equation", "One modulus split into two linear cases; the trap is the sign work in the negative case.",
  correct=r"$\frac{14}{3}$",
  distractors=[(r"$\frac{22}{3}$", r"Writes the second case as $3x + 7 = 11$, getting $x = \frac{4}{3}$, so the sum is $6 + \frac{4}{3} = \frac{22}{3}$."),
               (r"$6$", r"Solves only $3x - 7 = 11$ and ignores the case $3x - 7 = -11$."),
               (r"$0$", r"In the case $3x - 7 = -11$ moves $7$ across with the wrong sign, $3x = -18$, so $x = -6$ and the sum is $6 - 6 = 0$.")],
  check=_c1, values=[R(14, 3), R(22, 3), 6, 0], cognitive="Application")


def _c2():
    return sum(1 for x in range(-200, 201) if abs(2 * x - 5) < 9)
q("C11-B-002", T, "Counting integers in a strict modulus inequality", "Easy",
  "Single-step computation",
  r"How many integers $x$ satisfy $|2x - 5| < 9$?",
  "TITA",
  r"$|2x - 5| < 9$ means $-9 < 2x - 5 < 9$, so $-4 < 2x < 14$, that is $-2 < x < 7$. The integers are $-1, 0, 1, \ldots, 6$: $8$ integers.",
  "Treating the strict inequality as non-strict, or subtracting the endpoints instead of counting.",
  "C11B-modulus-inequality-interval", "Convert one modulus inequality to an interval and count; the trap is the strict endpoints.",
  tita_answer=8, check=_c2,
  tita_traps=[(10, r"Uses $\le$ in place of $<$, which adds $x = -2$ and $x = 7$."),
              (9, r"Subtracts the endpoints, $7 - (-2) = 9$, instead of counting the integers strictly between them.")],
  cognitive="Application")


def _c3():
    lo, hi = R("48.6"), R("51.0")
    return ((lo + hi) / 2, (hi - lo) / 2, 0)
q("C11-B-003", T, "Writing a closed tolerance interval as a modulus inequality", "Easy",
  "Conceptual/application",
  r"A quality inspector accepts a bolt only if its length is at least $48.6$ mm and at most $51.0$ mm. If $L$ is the length of a bolt in mm, the bolt is accepted exactly when",
  "MCQ",
  r"Write the interval as centre plus or minus half-width. Centre $= \frac{48.6 + 51.0}{2} = 49.8$ and half-width $= \frac{51.0 - 48.6}{2} = 1.2$. Both limits are acceptable, so the condition is $|L - 49.8| \le 1.2$.",
  "Using the full width of the interval as the allowed deviation, or measuring from one end instead of the centre.",
  "C11B-tolerance-as-modulus", "One idea: centre and half-width; the traps are the width and the endpoints.",
  correct=r"$|L - 49.8| \le 1.2$",
  distractors=[(r"$|L - 49.8| < 1.2$", r"Uses a strict inequality, which rejects bolts of exactly $48.6$ mm and $51.0$ mm."),
               (r"$|L - 49.8| \le 2.4$", r"Uses the full width $51.0 - 48.6 = 2.4$ as the allowed deviation from the centre."),
               (r"$|L - 48.6| \le 2.4$", r"Measures the deviation from the lower limit $48.6$ with the full width $2.4$.")],
  check=_c3, values=[(R("49.8"), R("1.2"), 0), (R("49.8"), R("1.2"), 1), (R("49.8"), R("2.4"), 0), (R("48.6"), R("2.4"), 0)],
  cognitive="Understanding")


def _c4():
    roots = set()
    for s in (1, -1):  # x >= 0 : |x| = x ; x < 0 : |x| = -x
        for r in solve(X**2 - s * X - 12, X):
            if (s == 1 and r >= 0) or (s == -1 and r < 0):
                roots.add(r)
    return sum(r**2 for r in roots)
q("C11-B-004", T, "Quadratic in |x| with one inadmissible value of |x|", "Easy",
  "Conceptual/application",
  r"Find the sum of the squares of all real roots of the equation $x^2 - |x| - 12 = 0$.",
  "TITA",
  r"Since $x^2 = |x|^2$, the equation is $|x|^2 - |x| - 12 = 0$, that is $(|x| - 4)(|x| + 3) = 0$. As $|x| \ge 0$, only $|x| = 4$ is possible, so the roots are $x = 4$ and $x = -4$. The sum of their squares is $16 + 16 = 32$.",
  "Accepting the negative value $|x| = -3$, or treating $|x|$ as $x$.",
  "C11B-quadratic-in-mod-x", "One substitution $x^2 = |x|^2$; the trap is the inadmissible root.",
  tita_answer=32, check=_c4,
  tita_traps=[(50, r"Accepts $|x| = -3$ as $x = \pm 3$ too: $16 + 16 + 9 + 9 = 50$."),
              (25, r"Treats $|x|$ as $x$: the roots of $x^2 - x - 12 = 0$ are $4$ and $-3$, giving $16 + 9 = 25$."),
              (16, r"Keeps only the positive root $x = 4$.")],
  cognitive="Application")


def _c5():
    return sum(_abs_eq_set(Abs(X - 6) - 2 * X))
q("C11-B-005", T, "Modulus equal to a linear expression, with an extraneous root", "Easy",
  "Single-step computation",
  r"The sum of all real values of $x$ satisfying $|x - 6| = 2x$ is",
  "MCQ",
  r"The right side must be non-negative, so $x \ge 0$. If $x - 6 = 2x$, then $x = -6$, which fails $x \ge 0$ (the right side would be $-12$). If $x - 6 = -2x$, then $3x = 6$ and $x = 2$; indeed $|2 - 6| = 4 = 2 \times 2$. So $x = 2$ is the only solution and the sum is $2$.",
  "Not checking that the right side of $|E| = g(x)$ is non-negative, so keeping an extraneous root.",
  "C11B-modulus-equals-linear", "Two linear cases and one validity check; the trap is the extraneous root.",
  correct=r"$2$",
  distractors=[(r"$-4$", r"Keeps the extraneous root $x = -6$ without checking that $2x \ge 0$: $2 + (-6) = -4$."),
               (r"$-6$", r"Solves only the first case $x - 6 = 2x$ and reports its root $x = -6$ without checking it."),
               (r"$4$", r"Squares both sides to get $3x^2 + 12x - 36 = 0$, skips the check, and takes the sum of its roots as $+\frac{12}{3} = 4$ instead of $-\frac{12}{3}$.")],
  check=_c5, values=[2, -4, -6, 4], cognitive="Application")


def _c6():
    m = [2, 5, 9, 14, 20]
    return _grid_min(lambda x: sum(abs(x - a) for a in m), 0, 25)
q("C11-B-006", T, "Meeting point minimising total distance for five people on a road (median)", "Easy",
  "Conceptual/application",
  r"Five friends live along a straight road, at the $2$ km, $5$ km, $9$ km, $14$ km and $20$ km markers. They will all travel along the road to meet at one point on it. If the meeting point is chosen so that the total distance travelled by the five friends is as small as possible, what is that total distance?",
  "MCQ",
  r"The total distance $|x - 2| + |x - 5| + |x - 9| + |x - 14| + |x - 20|$ is least at the median marker, $x = 9$. Pair the friends from the outside: any point between $2$ and $20$ costs that pair $18$ km, any point between $5$ and $14$ costs the next pair $9$ km, and the middle friend travels $0$ km when $x = 9$. The minimum total is $18 + 9 + 0 = 27$ km.",
  "Meeting at the average position or at the midpoint of the extremes instead of at the median.",
  "C11B-sum-of-moduli-median", "One insight: a sum of distances is least at the median; the trap is the mean.",
  correct=r"$27$ km",
  distractors=[(r"$28$ km", r"Meets at the mean position $\frac{2 + 5 + 9 + 14 + 20}{5} = 10$: $8 + 5 + 1 + 4 + 10 = 28$."),
               (r"$29$ km", r"Meets midway between the two extreme friends, at $11$: $9 + 6 + 2 + 3 + 9 = 29$."),
               (r"$18$ km", r"Takes the total as the gap $20 - 2$ between the two farthest friends, ignoring the others.")],
  check=_c6, values=[27, 28, 29, 18], cognitive="Understanding")


def _c7():
    return solve_univariate_inequality(Abs(5 - X) > 3, X, relational=False)
q("C11-B-007", T, "Solution set of a strict 'greater than' modulus inequality", "Easy",
  "Single-step computation",
  r"The set of all real numbers $x$ satisfying $|5 - x| > 3$ is",
  "MCQ",
  r"$|5 - x| = |x - 5|$ is the distance of $x$ from $5$. It exceeds $3$ when $x - 5 > 3$ or $x - 5 < -3$, that is $x > 8$ or $x < 2$. At $x = 2$ and $x = 8$ the distance is exactly $3$, so these are excluded.",
  "Turning $|E| > c$ into $-c < E < c$, or dropping one of the two branches.",
  "C11B-modulus-inequality-interval", "One modulus inequality of the 'greater than' type; traps are the direction and the endpoints.",
  correct=r"$x < 2$ or $x > 8$",
  distractors=[(r"$2 < x < 8$", r"Solves $|5 - x| > 3$ as if it were $|5 - x| < 3$."),
               (r"$x \le 2$ or $x \ge 8$", r"Includes the endpoints, where $|5 - x| = 3$ exactly."),
               (r"$x > 8$", r"Keeps only the branch $x - 5 > 3$ and drops $x - 5 < -3$.")],
  check=_c7,
  values=[Union(Interval.open(-oo, 2), Interval.open(8, oo)), Interval.open(2, 8),
          Union(Interval(-oo, 2), Interval(8, oo)), Interval.open(8, oo)],
  cognitive="Application")


def _c8():
    S = _pl_zero_set(lambda x: abs(x - 3) - 2 * abs(x - 15), BP)
    pts = sorted(S)
    return pts[-1] - pts[0]
q("C11-B-008", T, "Points on a road whose distances from two posts are in ratio 2 : 1", "Easy",
  "Multi-step word problem",
  r"Two signal posts P and Q stand beside a straight road at the $3$ km and $15$ km markers. A relay box is to be placed beside the road at a point whose distance from P is exactly twice its distance from Q. There are two such points. What is the distance between them, in km?",
  "TITA",
  r"Let the box be at marker $x$, so $|x - 3| = 2|x - 15|$. Between the posts, $x - 3 = 2(15 - x)$ gives $x = 11$. Beyond Q, $x - 3 = 2(x - 15)$ gives $x = 27$. Before P, $3 - x = 2(15 - x)$ gives $x = 27$, which is not before P, so there is no third point. The two points are $27 - 11 = 16$ km apart.",
  "Finding only the point between the posts and missing the one beyond Q.",
  "C11B-distance-ratio-on-line", "Translate to one modulus equation and check the pieces; the trap is the external point.",
  tita_answer=16, check=_c8,
  tita_traps=[(12, r"Reports the distance $15 - 3$ between the posts."),
              (8, r"Finds only the point $x = 11$ between the posts and reports its distance from P, $11 - 3$.")],
  cognitive="Application")


def _c9():
    return sum(1 for x in range(-200, 201) if abs(x - 2) + abs(x + 6) == 8)
q("C11-B-009", T, "Integer solutions when the constant equals the gap between the two points", "Easy",
  "Conceptual/application",
  r"How many integers $x$ satisfy $|x - 2| + |x + 6| = 8$?",
  "MCQ",
  r"$|x - 2| + |x + 6|$ is the sum of the distances of $x$ from $2$ and from $-6$. These two points are $8$ apart, so the sum equals $8$ exactly when $x$ lies between them, $-6 \le x \le 2$. That interval contains $9$ integers.",
  "Expecting two roots as in a single-modulus equation, and missing the flat middle piece.",
  "C11B-sum-of-two-moduli-equation", "One distance insight; the trap is assuming exactly two roots.",
  correct=r"$9$",
  distractors=[(r"$2$", r"Solves only the outer pieces, $2x + 4 = 8$ and $-2x - 4 = 8$, getting $x = 2$ and $x = -6$, and misses the flat middle piece."),
               (r"$8$", r"Takes the length $2 - (-6)$ of the interval as the number of integers in it."),
               (r"$7$", r"Counts only the integers strictly between $-6$ and $2$.")],
  check=_c9, values=[9, 2, 8, 7], cognitive="Understanding")


def _c10():
    return max(abs(x - 3) - abs(x + 5) for x in [R(i, 4) for i in range(-80, 81)])
q("C11-B-010", T, "Greatest value of a difference of two moduli", "Easy",
  "Conceptual/application",
  r"The greatest value of $|x - 3| - |x + 5|$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"For $x \le -5$ the expression is $(3 - x) - (-x - 5) = 8$. For $-5 \le x \le 3$ it is $(3 - x) - (x + 5) = -2x - 2$, which falls from $8$ to $-8$, and for $x \ge 3$ it is $-8$. So the greatest value is $8$, the distance between $3$ and $-5$.",
  "Evaluating at a convenient point such as $x = 0$, or reporting the least value.",
  "C11B-difference-of-moduli-range", "Three linear pieces, or the distance view; one idea.",
  correct=r"$8$",
  distractors=[(r"$-8$", r"Reports the least value of the expression, reached for $x \ge 3$."),
               (r"$-2$", r"Evaluates the expression at $x = 0$: $3 - 5 = -2$."),
               (r"$2$", r"Takes the greatest value as $5 - 3$, the difference of the constants.")],
  check=_c10, values=[8, -8, -2, 2], cognitive="Understanding")


def _c11():
    return sum(1 for x in range(-10, 11) for y in range(-10, 11) if abs(x) + abs(y) == 4)
q("C11-B-011", T, "Integer points on |x| + |y| = 4", "Easy",
  "Casework/optimisation",
  r"How many ordered pairs of integers $(x, y)$ satisfy $|x| + |y| = 4$?",
  "TITA",
  r"If neither is zero, $|x|$ can be $1, 2$ or $3$ with $|y| = 4 - |x|$, and each choice gives $4$ sign combinations: $3 \times 4 = 12$ pairs. If one of them is zero, the other is $\pm 4$: the $4$ pairs $(\pm 4, 0)$ and $(0, \pm 4)$. Total $12 + 4 = 16$.",
  "Counting only non-negative solutions, or multiplying every solution by $4$ including those on the axes.",
  "C11B-lattice-points-modulus", "Two short cases; the trap is the sign count for points on the axes.",
  tita_answer=16, check=_c11,
  tita_traps=[(5, r"Counts only the non-negative solutions $(0,4), (1,3), \ldots, (4,0)$."),
              (20, r"Multiplies the $5$ non-negative solutions by $4$, counting each axis point twice."),
              (12, r"Leaves out the four points on the axes.")],
  cognitive="Application")


def _c12():
    lo, hi = R(27 - 4), R(27 + 4)
    Flo, Fhi = R(9, 5) * lo + 32, R(9, 5) * hi + 32
    return ((Flo + Fhi) / 2, (Fhi - Flo) / 2)
q("C11-B-012", T, "Converting a modulus condition under a linear change of units", "Easy",
  "Conceptual/application",
  r"The temperature $T$ in a hill town, in degrees Celsius, is called comfortable when $|T - 27| \le 4$. A visitor reads temperatures in degrees Fahrenheit, where $F = \frac{9}{5}T + 32$. In terms of $F$, the temperature is comfortable exactly when",
  "MCQ",
  r"$|T - 27| \le 4$ means $23 \le T \le 31$, so $\frac{9}{5}(23) + 32 \le F \le \frac{9}{5}(31) + 32$, that is $73.4 \le F \le 87.8$. The centre is $80.6$ and the half-width $7.2$, so the condition is $|F - 80.6| \le 7.2$. (A temperature difference scales by $\frac{9}{5}$ only: $4 \times \frac{9}{5} = 7.2$.)",
  "Converting the allowed deviation as if it were a temperature, or not scaling it at all.",
  "C11B-tolerance-as-modulus", "One linear change of variable inside a modulus; the trap is how the width transforms.",
  correct=r"$|F - 80.6| \le 7.2$",
  distractors=[(r"$|F - 80.6| \le 39.2$", r"Converts the deviation $4$ with the full formula, $\frac{9}{5}(4) + 32 = 39.2$."),
               (r"$|F - 80.6| \le 4$", r"Converts the centre but keeps the deviation $4$ unscaled."),
               (r"$|F - 48.6| \le 7.2$", r"Converts the centre as $\frac{9}{5}(27) = 48.6$ without adding $32$.")],
  check=_c12, values=[(R("80.6"), R("7.2")), (R("80.6"), R("39.2")), (R("80.6"), 4), (R("48.6"), R("7.2"))],
  cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM (18)

def _c13():
    return _abs_eq_set(Abs(X - 1) + Abs(X - 7) - Abs(2 * X - 8))
q("C11-B-013", T, "When |u| + |v| = |u + v| for two linear expressions", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ for which $|x - 1| + |x - 7| = |2x - 8|$ is",
  "MCQ",
  r"Put $u = x - 1$ and $v = x - 7$; then $u + v = 2x - 8$. The equality $|u| + |v| = |u + v|$ holds exactly when $u$ and $v$ do not have opposite signs, that is $uv \ge 0$. So $(x - 1)(x - 7) \ge 0$, giving $x \le 1$ or $x \ge 7$.",
  "Reversing the condition for equality in the triangle inequality, or losing the endpoints where one term is zero.",
  "C11B-triangle-inequality-equality", r"Needs the equality case of $|u| + |v| \ge |u + v|$; otherwise three pieces.",
  correct=r"$x \le 1$ or $x \ge 7$",
  distractors=[(r"$1 \le x \le 7$", r"Takes the equality condition as $uv \le 0$, opposite signs."),
               (r"$x < 1$ or $x > 7$", r"Requires $uv > 0$ and so drops $x = 1$ and $x = 7$, where one term is zero."),
               (r"$x \ge 7$", r"Considers only the case where both $x - 1$ and $x - 7$ are non-negative.")],
  check=_c13,
  values=[Union(Interval(-oo, 1), Interval(7, oo)), Interval(1, 7),
          Union(Interval.open(-oo, 1), Interval.open(7, oo)), Interval(7, oo)],
  cognitive="Analysis")


def _c14():
    towns = [(0, 5), (10, 1), (25, 3), (40, 2)]
    return _grid_min(lambda x: 2 * sum(w * abs(x - a) for a, w in towns), -10, 50)
q("C11-B-014", T, "Hub location with weighted round trips along a highway (weighted median)", "Medium",
  "Multi-step word problem",
  r"A courier company will build a hub beside a straight highway along which four towns lie, at the $0$ km, $10$ km, $25$ km and $40$ km markers. Each day the hub must make $5$, $1$, $3$ and $2$ deliveries to these towns respectively, and every delivery is a separate round trip from the hub to the town and back along the highway. If the hub is placed so that the total daily distance travelled is as small as possible, that distance is",
  "MCQ",
  r"The daily distance is $2\,(5|x| + |x - 10| + 3|x - 25| + 2|x - 40|)$. List the $11$ deliveries by position: $5$ at $0$, $1$ at $10$, $3$ at $25$, $2$ at $40$. A sum of distances is least at the median item, the $6$th delivery, which is at $10$ km. There the bracket is $50 + 0 + 45 + 60 = 155$, so the least daily distance is $2 \times 155 = 310$ km.",
  "Placing the hub at the weighted average position, or at the busiest town, instead of at the weighted median.",
  "C11B-weighted-sum-of-moduli", "Weighted median plus the round-trip factor; two ideas combined.",
  correct=r"$310$ km",
  distractors=[(r"$155$ km", r"Finds the best position correctly but counts each delivery one way only."),
               (r"$320$ km", r"Places the hub at the weighted average position $\frac{0 + 10 + 75 + 80}{11} = 15$: $2(75 + 5 + 30 + 50) = 320$."),
               (r"$330$ km", r"Places the hub at the town with the most deliveries, the $0$ km marker: $2(0 + 10 + 75 + 80) = 330$.")],
  check=_c14, values=[310, 155, 320, 330], cognitive="Application")


def _c15():
    return _grid_min(lambda x: 4 * abs(x - 1) + abs(x - 5) + 2 * abs(x - 8), -5, 15)
q("C11-B-015", T, "Least value of a weighted sum of three moduli", "Medium",
  "Casework/optimisation",
  r"The least value of $4|x - 1| + |x - 5| + 2|x - 8|$ over all real $x$ is",
  "MCQ",
  r"The expression is piecewise linear, so its least value is at the break-point where the slope turns from negative to non-negative. For $x < 1$ the slope is $-(4 + 1 + 2) = -7$; just after $x = 1$ it is $4 - 1 - 2 = 1 > 0$. (The weight $4$ at $x = 1$ is more than half of the total $7$.) So the minimum is at $x = 1$: $0 + 4 + 14 = 18$.",
  "Using the ordinary median of the break-points and ignoring the weights.",
  "C11B-weighted-sum-of-moduli", "Needs the slope (weighted median) argument; the plain median trap is strong.",
  correct=r"$18$",
  distractors=[(r"$22$", r"Uses the plain median break-point $x = 5$: $16 + 0 + 6 = 22$."),
               (r"$7$", r"Takes the least value as the distance $8 - 1$ between the extreme break-points, which holds only for two unit-weight terms."),
               (r"$21$", r"Rounds the weighted mean $\frac{4 + 5 + 16}{7} = \frac{25}{7}$ to $4$ and evaluates there: $12 + 1 + 8 = 21$.")],
  check=_c15, values=[18, 22, 7, 21], cognitive="Analysis")


def _c16():
    cnt = 0
    for k in range(1, 21):
        if _n(_pl_zero_set(lambda x: abs(x - 3) + abs(x + 5) - k, BP)) == 2:
            cnt += 1
    return cnt
q("C11-B-016", T, "Values of k giving exactly two roots of |x - a| + |x - b| = k", "Medium",
  "Inverse/parameter",
  r"For how many integers $k$ with $1 \le k \le 20$ does the equation $|x - 3| + |x + 5| = k$ have exactly two real solutions?",
  "TITA",
  r"$|x - 3| + |x + 5|$ is the sum of the distances from $3$ and $-5$, which are $8$ apart. Its least value is $8$, taken at every $x$ in $[-5, 3]$. So there is no solution for $k < 8$, infinitely many for $k = 8$, and exactly two (one on each side of the interval) for $k > 8$. The valid values are $k = 9, 10, \ldots, 20$: $12$ values.",
  "Including $k = 8$, where every point between $-5$ and $3$ is a solution.",
  "C11B-sum-of-two-moduli-equation", "Requires the full picture of how the root count depends on $k$.",
  tita_answer=12, check=_c16,
  tita_traps=[(13, r"Includes $k = 8$, which gives infinitely many solutions."),
              (11, r"Counts the values from $9$ to $20$ as $20 - 9$.")],
  cognitive="Analysis")


def _c17():
    return _n(_pl_zero_set(lambda x: abs(abs(abs(x) - 3) - 2) - 1, BP))
q("C11-B-017", T, "Number of roots of a triply nested modulus equation", "Medium",
  "Casework/optimisation",
  r"How many real numbers $x$ satisfy $\left| \left| |x| - 3 \right| - 2 \right| = 1$?",
  "TITA",
  r"Peel one layer at a time. $\left||x| - 3\right| - 2 = \pm 1$ gives $\left||x| - 3\right| = 3$ or $1$. Then $|x| - 3 = \pm 3$ gives $|x| = 6$ or $0$, and $|x| - 3 = \pm 1$ gives $|x| = 4$ or $2$. Each positive value of $|x|$ gives two values of $x$, but $|x| = 0$ gives only $x = 0$. Total $2 + 1 + 2 + 2 = 7$.",
  "Assuming every value of $|x|$ gives two roots, including $|x| = 0$.",
  "C11B-nested-modulus", "Three layers of case splitting with a degenerate branch.",
  tita_answer=7, check=_c17,
  tita_traps=[(8, r"Counts $|x| = 0$ as giving two values of $x$."),
              (3, r"Keeps only the branch $\left||x| - 3\right| = 3$, giving $x = 0$ and $x = \pm 6$.")],
  cognitive="Analysis", exams=CX)


def _c18():
    h = lambda x: abs(abs(x - 1) - 4)
    count = lambda k: _n(_pl_zero_set(lambda x: h(x) - k, BP))
    crit = [h(R(p)) for p in (1, -3, 5)] + [0]
    return _level_set(count, crit, 4)
q("C11-B-018", T, "Parameter range for exactly four roots of a nested modulus equation", "Medium",
  "Inverse/parameter",
  r"The equation $\left| |x - 1| - 4 \right| = k$, where $k$ is a real constant, has exactly four distinct real solutions if and only if",
  "MCQ",
  r"The equation means $|x - 1| = 4 + k$ or $|x - 1| = 4 - k$ (with $k \ge 0$). Each of these gives two values of $x$ when its right side is positive, one when it is $0$, none when negative. For four solutions both $4 + k$ and $4 - k$ must be positive and different, so $k > 0$ and $k < 4$. At $k = 0$ the two equations coincide (two solutions) and at $k = 4$ the second gives only $x = 1$ (three solutions).",
  "Not checking the boundary values of $k$, or forgetting that $4 - k$ must stay positive.",
  "C11B-nested-modulus", "Parameter analysis with two boundary cases to test.",
  correct=r"$0 < k < 4$",
  distractors=[(r"$0 \le k < 4$", r"Includes $k = 0$, where both cases reduce to $|x - 1| = 4$ and give only two solutions."),
               (r"$0 < k \le 4$", r"Includes $k = 4$, where $|x - 1| = 0$ gives a single root and the total is three."),
               (r"$k > 0$", r"Assumes $|x - 1| = 4 - k$ always gives two roots, forgetting that $4 - k$ must be positive.")],
  check=_c18,
  values=[Interval.open(0, 4), Interval.Ropen(0, 4), Interval.Lopen(0, 4), Interval.open(0, oo)],
  cognitive="Analysis", exams=CX)


def _c19():
    def count(k):
        roots = set()
        for rhs in (k, -k):
            for r in solve(X**2 - 8 * X + 7 - rhs, X):
                if r.is_real:
                    roots.add(r)
        return len(roots)
    return sum(1 for k in range(0, 40) if count(k) == 4)
q("C11-B-019", T, "Integer k for which |quadratic| = k has four roots", "Medium",
  "Inverse/parameter",
  r"For how many integer values of $k$ does the equation $|x^2 - 8x + 7| = k$ have exactly four distinct real solutions?",
  "TITA",
  r"$x^2 - 8x + 7 = (x - 4)^2 - 9$ is negative between its roots $1$ and $7$, with least value $-9$ at $x = 4$. Taking the modulus turns this dip into a hump of height $9$ between $x = 1$ and $x = 7$. A line $y = k$ with $0 < k < 9$ cuts the hump twice and the two outer arms once each: four solutions. At $k = 9$ it touches the hump only at $x = 4$ (three solutions), and for $k = 0$ or $k > 9$ there are two. So $k = 1, 2, \ldots, 8$: $8$ values.",
  "Including the peak value $k = 9$, where the hump is only touched.",
  "C11B-modulus-of-quadratic-level", "Graph reflection plus boundary cases of $k$.",
  tita_answer=8, check=_c19,
  tita_traps=[(9, r"Includes $k = 9$, which gives only three solutions."),
              (10, r"Counts every integer from $0$ to $9$.")],
  cognitive="Analysis", exams=CX)


def _c20():
    y = symbols('y', real=True)
    sols = set()
    for sx in (1, -1):
        for sy in (1, -1):
            s = solve([sx * X + y - 9, X + sy * y - 5], [X, y], dict=True)
            for d in s:
                if X in d and y in d and sx * d[X] >= 0 and sy * d[y] >= 0 \
                        and abs(d[X]) + d[y] == 9 and d[X] + abs(d[y]) == 5:
                    sols.add((d[X], d[y]))
    (a, b), = sols
    return 3 * a + b
q("C11-B-020", T, "Two equations each containing one modulus, solved by sign cases", "Medium",
  "Casework/optimisation",
  r"Real numbers $x$ and $y$ satisfy $|x| + y = 9$ and $x + |y| = 5$. The value of $3x + y$ is",
  "MCQ",
  r"Try the sign cases. If $x \ge 0, y \ge 0$, both equations read $x + y$, which cannot be both $9$ and $5$. If $x \ge 0, y < 0$: $x + y = 9$ and $x - y = 5$ give $y = 2$, contradicting $y < 0$. If $x < 0, y < 0$: $-x + y = 9$ and $x - y = 5$ add to $0 = 14$, impossible. If $x < 0, y \ge 0$: $-x + y = 9$ and $x + y = 5$ give $y = 7$, $x = -2$, which fits. So $3x + y = -6 + 7 = 1$.",
  "Solving a sign case and not checking that the solution has the assumed signs.",
  "C11B-modulus-system-two-variables", "Four sign cases, three of which must be rejected for different reasons.",
  correct=r"$1$",
  distractors=[(r"$23$", r"Keeps $(x, y) = (7, 2)$ from the case $x \ge 0, y < 0$ without checking the sign of $y$: $21 + 2$."),
               (r"$-13$", r"Gets $x = -2$ and $y = 7$ correctly but evaluates $3x - y$ in place of $3x + y$: $-6 - 7$."),
               (r"$13$", r"Uses $|x| = 2$ in place of $x = -2$: $6 + 7$.")],
  check=_c20, values=[1, 23, -13, 13], cognitive="Analysis", exams=CX)


def _c21():
    return sum(1 for x in range(-10, 11) for y in range(-10, 11) if abs(x) + abs(y) <= 5)
q("C11-B-021", T, "Integer points inside the region |x| + |y| <= 5", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of integers $(x, y)$ satisfy $|x| + |y| \le 5$?",
  "MCQ",
  r"For each $x$ with $|x| \le 5$, $y$ can be any integer with $|y| \le 5 - |x|$, which is $2(5 - |x|) + 1$ values. For $x = 0$ this is $11$; for $x = \pm 1, \pm 2, \ldots, \pm 5$ it is $2(9 + 7 + 5 + 3 + 1) = 50$. Total $11 + 50 = 61$.",
  "Multiplying the first-quadrant count by $4$, which counts points on the axes more than once.",
  "C11B-lattice-points-modulus", "Column-by-column counting; the trap is the overlap on the axes.",
  correct=r"$61$",
  distractors=[(r"$41$", r"Counts the pairs with $|x| + |y| < 5$ (strict) instead of $\le 5$."),
               (r"$84$", r"Counts the $21$ non-negative pairs and multiplies by $4$, counting axis points more than once."),
               (r"$21$", r"Counts only the pairs with $x \ge 0$ and $y \ge 0$.")],
  check=_c21, values=[61, 41, 84, 21], cognitive="Application")


def _c22():
    yv = lambda xx: R(12 - abs(2 * xx), 3)   # |3y| <= 12 - |2x|
    # exact area of a piecewise-linear profile by trapezoids on a grid containing every kink
    pts = [R(i, 2) for i in range(-12, 13)]
    return sum((pts[i + 1] - pts[i]) * (2 * yv(pts[i]) + 2 * yv(pts[i + 1])) / 2 for i in range(len(pts) - 1))
q("C11-B-022", T, "Area enclosed by |ax| + |by| = c", "Medium",
  "Conceptual/application",
  r"The area of the region enclosed by the curve $|2x| + |3y| = 12$ in the $xy$-plane, in square units, is",
  "MCQ",
  r"The curve meets the axes at $(\pm 6, 0)$ and $(0, \pm 4)$ and is a straight segment in each quadrant, so it is a rhombus with diagonals $12$ and $8$. Its area is $\frac{1}{2} \times 12 \times 8 = 48$.",
  "Taking the bounding rectangle, or ignoring the coefficients of $x$ and $y$.",
  "C11B-modulus-region-area", "Recognising the rhombus and its intercepts; one step each.",
  correct=r"$48$",
  distractors=[(r"$96$", r"Takes the bounding rectangle $12 \times 8$ instead of the rhombus inside it."),
               (r"$288$", r"Ignores the coefficients and uses $|x| + |y| = 12$, a rhombus with diagonals $24$ and $24$."),
               (r"$24$", r"Multiplies the half-diagonals $6 \times 4$.")],
  check=_c22, values=[48, 96, 288, 24], cognitive="Application")


def _c23():
    def overlap(a):
        I = Intersection(Interval.open(a - 3, a + 3), Interval.open(-2 - 4, -2 + 4))
        return I.measure
    ok = set()   # overlap length is piecewise linear in a with integer kinks, so a grid of quarters is exhaustive

    for i in range(-80, 81):
        a = R(i, 4)
        if overlap(a) == 2:
            ok.add(a)
    return FiniteSet(*ok)
q("C11-B-023", T, "Parameter values for which two modulus inequalities overlap in an interval of given length", "Medium",
  "Inverse/parameter",
  r"For a real constant $a$, the set of all real $x$ satisfying both $|x - a| < 3$ and $|x + 2| < 4$ is an interval of length exactly $2$. The possible values of $a$ are",
  "MCQ",
  r"$|x + 2| < 4$ is the interval $(-6, 2)$, of length $8$ and centre $-2$; $|x - a| < 3$ is $(a - 3, a + 3)$, of length $6$ and centre $a$. An overlap of length $2$, shorter than both intervals, means they cross at one end, and then the overlap length is (sum of half-lengths) minus (distance between centres), so the centres are $3 + 4 - 2 = 5$ apart. So $|a + 2| = 5$, giving $a = 3$ (overlap $(0, 2)$) or $a = -7$ (overlap $(-6, -4)$).",
  "Reading the centre of $|x + 2| < 4$ as $+2$, or finding only the overlap on one side.",
  "C11B-modulus-interval-overlap", "Translate two modulus inequalities into intervals and impose a condition on their overlap, on both sides.",
  correct=r"$a = -7$ or $a = 3$",
  distractors=[(r"$a = 3$ only", r"Considers only the case where the interval $(a - 3, a + 3)$ lies to the right of $(-6, 2)$."),
               (r"$a = -3$ or $a = 7$", r"Takes the centre of $|x + 2| < 4$ as $+2$, so solves $|a - 2| = 5$."),
               (r"$a = -14$ or $a = 10$", r"Uses the full lengths instead of the half-lengths, setting the distance between centres to $6 + 8 - 2 = 12$.")],
  check=_c23,
  values=[FiniteSet(-7, 3), FiniteSet(3), FiniteSet(-3, 7), FiniteSet(-14, 10)],
  cognitive="Application")


def _c24():
    return sum(1 for x in range(-200, 201) if abs(abs(x - 3) - abs(x + 5)) < 6)
q("C11-B-024", T, "Integers where a difference of moduli lies in a band", "Medium",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $\left| |x - 3| - |x + 5| \right| < 6$?",
  "TITA",
  r"Let $g(x) = |x - 3| - |x + 5|$. For $x \le -5$, $g = 8$; for $x \ge 3$, $g = -8$; in between, $g = -2x - 2$. Only the middle piece can give $|g| < 6$: $-6 < -2x - 2 < 6$ gives $-4 < x < 2$, so $x = -3, -2, -1, 0, 1$. That is $5$ integers.",
  "Treating the whole middle stretch as valid, or including the endpoints of a strict inequality.",
  "C11B-difference-of-moduli-range", "Piecewise form of $g$, then an inequality on one piece.",
  tita_answer=5, check=_c24,
  tita_traps=[(7, r"Uses $\le 6$, which adds $x = -4$ and $x = 2$."),
              (9, r"Counts every integer from $-5$ to $3$, assuming $|g| < 6$ throughout the middle piece.")],
  cognitive="Analysis")


def _c25():
    S = solve_univariate_inequality(Abs(X - 10) <= 2 * Abs(X - 40), X, relational=False)
    return Intersection(S, Interval(0, 100)).measure
q("C11-B-025", T, "Stretch of road where one distance is at most twice another", "Medium",
  "Multi-step word problem",
  r"A straight road runs from the $0$ km marker to the $100$ km marker, and two villages P and Q lie beside it at the $10$ km and $40$ km markers. A water tank may be built at any point of the road whose distance from P is at most twice its distance from Q. What is the total length of road on which the tank may be built?",
  "MCQ",
  r"With the tank at marker $x$, the condition is $|x - 10| \le 2|x - 40|$. Both sides are non-negative, so square: $(x - 10)^2 \le 4(x - 40)^2$, which simplifies to $3x^2 - 300x + 6300 \ge 0$, that is $(x - 30)(x - 70) \ge 0$. So $x \le 30$ or $x \ge 70$. On the road this is $0 \le x \le 30$ and $70 \le x \le 100$, a total of $30 + 30 = 60$ km.",
  "Solving only between the villages and missing the stretch beyond Q.",
  "C11B-distance-ratio-on-line", "Modulus inequality by squaring, then measuring a union of intervals on a bounded road.",
  correct=r"$60$ km",
  distractors=[(r"$30$ km", r"Finds only the stretch $x \le 30$ and misses the stretch beyond $x = 70$."),
               (r"$40$ km", r"Reports the length of the forbidden stretch from $30$ to $70$."),
               (r"$80$ km", r"Reverses the roles of P and Q and solves $|x - 40| \le 2|x - 10|$, that is $3x^2 \ge 1200$, so $x \ge 20$ on the road, a length of $80$ km.")],
  check=_c25, values=[60, 30, 40, 80], cognitive="Application")


def _c26():
    S = _abs_eq_set(Abs(X**2 - 9) - (X + 3))
    return sum(r**2 for r in S)
q("C11-B-026", T, "Modulus of a quadratic equal to a linear expression; repeated root across cases", "Medium",
  "Casework/optimisation",
  r"Find the sum of the squares of all distinct real solutions of $|x^2 - 9| = x + 3$.",
  "TITA",
  r"The right side must be non-negative, so $x \ge -3$. If $x^2 - 9 = x + 3$, then $x^2 - x - 12 = 0$, so $x = 4$ or $x = -3$. If $x^2 - 9 = -(x + 3)$, then $x^2 + x - 6 = 0$, so $x = 2$ or $x = -3$. All of these satisfy the original equation ($|7| = 7$, $|0| = 0$, $|-5| = 5$), and the distinct solutions are $-3, 2, 4$. The sum of their squares is $9 + 4 + 16 = 29$.",
  "Counting a root that appears in both cases twice.",
  "C11B-modulus-equals-linear", "Two quadratic cases with a shared root and validity checks.",
  tita_answer=29, check=_c26,
  tita_traps=[(38, r"Counts $x = -3$ twice, once from each case."),
              (20, r"Discards $x = -3$ because the right side is zero there."),
              (25, r"Uses only the case $x^2 - 9 = x + 3$: $16 + 9$.")],
  cognitive="Analysis")


def _c27():
    return solve_univariate_inequality(X**2 - 7 * Abs(X) + 10 < 0, X, relational=False)
q("C11-B-027", T, "Quadratic inequality in |x|", "Medium",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $x^2 - 7|x| + 10 < 0$ is",
  "MCQ",
  r"Write $x^2 = |x|^2$: the inequality is $|x|^2 - 7|x| + 10 < 0$, that is $(|x| - 2)(|x| - 5) < 0$, so $2 < |x| < 5$. Hence $-5 < x < -2$ or $2 < x < 5$.",
  "Treating $|x|$ as $x$ and losing the negative half of the solution.",
  "C11B-quadratic-in-mod-x", "Substitution $t = |x|$, a quadratic inequality, then back to $x$.",
  correct=r"$-5 < x < -2$ or $2 < x < 5$",
  distractors=[(r"$2 < x < 5$", r"Treats $|x|$ as $x$ and solves $x^2 - 7x + 10 < 0$."),
               (r"$x < -5$ or $-2 < x < 2$ or $x > 5$", r"Solves $(|x| - 2)(|x| - 5) > 0$, reversing the inequality."),
               (r"$-5 < x < -2$", r"Replaces $|x|$ by $-x$ throughout and solves $x^2 + 7x + 10 < 0$.")],
  check=_c27,
  values=[Union(Interval.open(-5, -2), Interval.open(2, 5)), Interval.open(2, 5),
          Union(Interval.open(-oo, -5), Interval.open(-2, 2), Interval.open(5, oo)), Interval.open(-5, -2)],
  cognitive="Application")


def _c28():
    shops = [0, 20, 30, 50, 240, 300]
    vals = {x: sum(abs(x - s) for s in shops) for x in range(0, 301)}
    m = min(vals.values())
    return sum(1 for v in vals.values() if v == m)
q("C11-B-028", T, "Even number of points: the whole middle stretch minimises the sum of distances", "Medium",
  "Conceptual/application",
  r"Six shops stand along one side of a straight street at distances of $0$ m, $20$ m, $30$ m, $50$ m, $240$ m and $300$ m from the street's starting corner. A storeroom is to be placed on the street so that the sum of its distances from the six shops is as small as possible. At how many points of the street, each a whole number of metres from the starting corner, can the storeroom be placed?",
  "TITA",
  r"For an even number of points, $\sum |x - a_i|$ is least at every point between the two middle points, here $30$ m and $50$ m: moving within that stretch brings the storeroom closer to three shops and farther from the other three by the same amount. So any $x$ with $30 \le x \le 50$ is optimal, which gives $50 - 30 + 1 = 21$ whole-metre positions.",
  "Assuming the minimising point is unique, as it is for an odd number of points.",
  "C11B-sum-of-moduli-median", "Needs the flat-bottom property of the sum for an even count, then an endpoint-inclusive count.",
  tita_answer=21, check=_c28,
  tita_traps=[(20, r"Subtracts the endpoints, $50 - 30$, instead of counting inclusively."),
              (1, r"Assumes a single best point, as with an odd number of shops."),
              (19, r"Excludes the two positions $30$ m and $50$ m themselves.")],
  cognitive="Understanding")


def _c29():
    return sum(_abs_eq_set(Abs(X - 4) - Abs(2 * X + 1) - 1))
q("C11-B-029", T, "Equation with a modulus on each side and an extra constant", "Medium",
  "Casework/optimisation",
  r"The sum of all real values of $x$ for which $|x - 4| = |2x + 1| + 1$ is",
  "MCQ",
  r"Split at $x = -\frac{1}{2}$ and $x = 4$. For $x < -\frac{1}{2}$: $4 - x = -(2x + 1) + 1 = -2x$, so $x = -4$, which is in range. For $-\frac{1}{2} \le x < 4$: $4 - x = 2x + 2$, so $x = \frac{2}{3}$, in range. For $x \ge 4$: $x - 4 = 2x + 2$ gives $x = -6$, not in range. The solutions are $-4$ and $\frac{2}{3}$, with sum $-\frac{10}{3}$.",
  "Treating $|P| = |Q| + 1$ like $|P| = |Q|$, or keeping a root outside its piece.",
  "C11B-linear-modulus-equation", r"Three pieces with range checks; the constant breaks the usual $P = \pm Q$ shortcut.",
  correct=r"$-\frac{10}{3}$",
  distractors=[(r"$-\frac{28}{3}$", r"Also keeps $x = -6$ from the piece $x \ge 4$ without checking its range: $-4 + \frac{2}{3} - 6$."),
               (r"$-\frac{16}{3}$", r"Writes the equation as $x - 4 = \pm(2x + 1 + 1)$, getting $x = -6$ and $x = \frac{2}{3}$."),
               (r"$\frac{2}{3}$", r"Solves only the middle piece $-\frac{1}{2} \le x < 4$ and misses $x = -4$.")],
  check=_c29, values=[R(-10, 3), R(-28, 3), R(-16, 3), R(2, 3)], cognitive="Analysis")


def _c30():
    roots = set()
    for r in solve(X**2 - 5 * X + 6, X):     # x >= 0: x|x| = x^2
        if r >= 0:
            roots.add(r)
    for r in solve(-X**2 - 5 * X + 6, X):    # x < 0: x|x| = -x^2
        if r < 0:
            roots.add(r)
    for r in roots:
        assert r * abs(r) - 5 * r + 6 == 0
    return sum(roots)
q("C11-B-030", T, "Equation involving x|x|", "Medium",
  "Casework/optimisation",
  r"The sum of all real solutions of $x|x| - 5x + 6 = 0$ is",
  "MCQ",
  r"For $x \ge 0$, $x|x| = x^2$: $x^2 - 5x + 6 = 0$ gives $x = 2$ and $x = 3$, both valid. For $x < 0$, $x|x| = -x^2$: $-x^2 - 5x + 6 = 0$, that is $x^2 + 5x - 6 = 0$, giving $x = -6$ or $x = 1$; only $x = -6$ is negative. The solutions are $2, 3, -6$, with sum $-1$.",
  "Treating $x|x|$ as $x^2$ for all $x$, or keeping a root from the wrong range.",
  "C11B-x-times-mod-x", "Two cases with a range check in each.",
  correct=r"$-1$",
  distractors=[(r"$5$", r"Treats $x|x|$ as $x^2$ for every $x$, so only $x = 2$ and $x = 3$ appear."),
               (r"$0$", r"Keeps $x = 1$ from the case $x < 0$: $2 + 3 - 6 + 1 = 0$."),
               (r"$4$", r"For $x < 0$ gets $x^2 - 5x - 6 = 0$ by a sign slip, whose negative root is $-1$: $2 + 3 - 1 = 4$.")],
  check=_c30, values=[-1, 5, 0, 4], cognitive="Analysis")


# ---------------------------------------------------------------- DIFFICULT (10)

def _c31():
    return _grid_min(lambda x: sum(k * abs(x - k) for k in range(1, 11)), 0, 11, den=2)
q("C11-B-031", T, "Least value of sum k|x - k| for k = 1 to 10", "Difficult",
  "Casework/optimisation",
  r"Find the least value of $|x - 1| + 2|x - 2| + 3|x - 3| + \cdots + 10|x - 10|$ over all real $x$.",
  "TITA",
  r"This is a weighted sum of distances, least at the weighted median. The weights total $1 + 2 + \cdots + 10 = 55$, and the running totals are $1, 3, 6, 10, 15, 21, 28, \ldots$. Just before $x = 7$ the slope is $21 - 34 = -13$, and just after it is $28 - 27 = 1$, so the minimum is at $x = 7$. The value there is $6 + 10 + 12 + 12 + 10 + 6 + 0 + 8 + 18 + 30 = 112$.",
  "Using the middle of the break-points, or the point with the largest coefficient, instead of the weighted median.",
  "C11B-weighted-sum-of-moduli", "Ten weighted terms; the minimiser must be located by slope or running totals.",
  tita_answer=112, check=_c31,
  tita_traps=[(165, r"Places $x$ at $10$, the term with the largest coefficient."),
              (125, r"Stops at $x = 6$, where the running total $21$ is still below half of $55$.")],
  cognitive="Analysis", exams=CX)


def _c32():
    f = lambda x: abs(x - 6) + 2 * abs(x - 15) + abs(x - 33)
    return sum(1 for x in range(-200, 301) if f(x) <= 50)
q("C11-B-032", T, "Integer positions where a weighted sum of distances stays within a bound", "Difficult",
  "Multi-step word problem",
  r"Three bus stops lie beside a straight highway at the $6$ km, $15$ km and $33$ km markers. A supply depot is to be built beside the highway at a whole-number km marker. Each day a van makes one run from the depot to the stop at $6$ km, two runs to the stop at $15$ km and one run to the stop at $33$ km. Counting only the outward distance of each run, measured along the highway, the total daily outward distance must be at most $50$ km. How many markers are possible for the depot?",
  "TITA",
  r"The total is $f(x) = |x - 6| + 2|x - 15| + |x - 33|$. For $x < 6$: $f = 69 - 4x \le 50$ gives $x \ge 4.75$, so $x = 5$. For $6 \le x \le 15$: $f = 57 - 2x \le 50$ gives $x \ge 3.5$, so all of $6$ to $15$ work. For $15 \le x \le 33$: $f = 2x - 3 \le 50$ gives $x \le 26.5$, so $x$ up to $26$. Beyond $33$, $f = 4x - 69 > 50$. The markers are $5$ to $26$: $22$ in all.",
  "Ignoring the weight of the stop with two runs, assuming the whole stretch between the outer stops is valid, or rounding a boundary the wrong way.",
  "C11B-sum-of-moduli-inequality", "Weighted, non-symmetric sum of moduli: four regimes, part of the middle stretch fails, and two boundaries need integer rounding.",
  tita_answer=22, check=_c32,
  tita_traps=[(33, r"Ignores the weight $2$ and solves $|x - 6| + |x - 15| + |x - 33| \le 50$, getting $x = 2$ to $34$."),
              (24, r"Rounds $4.75$ down to $4$ and $26.5$ up to $27$."),
              (28, r"Assumes every marker from $6$ to $33$ works.")],
  cognitive="Analysis", exams=CX)


def _c33():
    f = lambda x: abs(x - 1) + abs(x - 3) + abs(x - 6)
    def count(m):
        return _n(_pl_zero_set(lambda x: f(x) - m * x, [1, 3, 6]))
    crit = [R(-3), R(-1), R(4, 3), R(5, 3), R(3), R(7)]
    return _level_set(count, crit, 2)
q("C11-B-033", T, "Range of m for which a sum of three moduli equals mx at exactly two points", "Difficult",
  "Inverse/parameter",
  r"For a real constant $m$, the equation $|x - 1| + |x - 3| + |x - 6| = mx$ has exactly two real solutions if and only if",
  "MCQ",
  r"Let $f(x) = |x - 1| + |x - 3| + |x - 6|$, a convex broken line with corners $(1, 7)$, $(3, 5)$, $(6, 8)$, and slope $3$ for $x > 6$. The line $y = mx$ passes through the origin, which lies below the graph since $f(0) = 10$. For $x > 0$ the line meets the graph twice exactly when it rises above the graph somewhere but is eventually overtaken by it. It rises above the graph when $m$ exceeds the least value of $\frac{f(x)}{x}$, which occurs at a corner: $\frac{7}{1}, \frac{5}{3}, \frac{8}{6}$, least $\frac{4}{3}$ at $x = 6$. It is eventually overtaken only if $m < 3$, the final slope. For $x < 0$, $f(x) = 10 - 3x$ meets $mx$ only when $m < -3$, giving one solution. Hence exactly two solutions for $\frac{4}{3} < m < 3$.",
  r"Using the minimum point of $f$ instead of the least ratio $\frac{f(x)}{x}$, or ignoring the final slope of $f$.",
  "C11B-modulus-equals-linear", "Convexity, a tangent line from the origin and the asymptotic slope must all be combined; several plausible wrong ranges.",
  correct=r"$\frac{4}{3} < m < 3$",
  distractors=[(r"$\frac{5}{3} < m < 3$", r"Takes the line through the lowest corner $(3, 5)$ of the graph as the boundary, instead of the corner with the least ratio $\frac{f(x)}{x}$."),
               (r"$m > \frac{4}{3}$", r"Finds the lower boundary correctly but forgets that for $m \ge 3$ the line is never overtaken by the last piece of slope $3$, so only one crossing remains."),
               (r"$\frac{4}{3} < m < 7$", r"Takes the upper boundary as the slope $7$ of the line through the corner $(1, 7)$.")],
  check=_c33,
  values=[Interval.open(R(4, 3), 3), Interval.open(R(5, 3), 3), Interval.open(R(4, 3), oo), Interval.open(R(4, 3), 7)],
  cognitive="Analysis", exams=CX)


def _c34():
    r = range(-5, 6)
    return sum(1 for x in r for y in r for z in r if abs(x) + abs(y) + abs(z) == 4)
q("C11-B-034", T, "Integer triples on |x| + |y| + |z| = 4", "Difficult",
  "Casework/optimisation",
  r"How many ordered triples of integers $(x, y, z)$ satisfy $|x| + |y| + |z| = 4$?",
  "TITA",
  r"Split by the number of zero coordinates. No zeros: positive solutions of $a + b + c = 4$ number $\binom{3}{2} = 3$, each with $2^3 = 8$ sign choices: $24$. Exactly one zero: $3$ positions for the zero, $3$ positive solutions of $a + b = 4$, and $4$ sign choices: $36$. Two zeros: $3$ positions for the non-zero entry and $2$ signs: $6$. Total $24 + 36 + 6 = 66$.",
  "Applying $8$ sign choices to every non-negative solution, including those with zeros.",
  "C11B-lattice-points-modulus", "Casework on zero coordinates with different sign multipliers.",
  tita_answer=66, check=_c34,
  tita_traps=[(15, r"Counts only the non-negative solutions, $\binom{6}{2} = 15$."),
              (120, r"Multiplies the $15$ non-negative solutions by $8$ sign patterns, overcounting those with zeros."),
              (24, r"Counts only the triples with no zero coordinate.")],
  cognitive="Analysis", exams=CX)


def _c35():
    hgt = lambda xx: max(0, 2 - abs(abs(xx) - 2))      # half-height of the region at abscissa x
    pts = [R(i, 2) for i in range(-12, 13)]
    return sum((pts[i + 1] - pts[i]) * (2 * hgt(pts[i]) + 2 * hgt(pts[i + 1])) / 2 for i in range(len(pts) - 1))
q("C11-B-035", T, "Area of the region ||x| - 2| + |y| <= 2", "Difficult",
  "Conceptual/application",
  r"The area, in square units, of the region of the $xy$-plane satisfying $\left| |x| - 2 \right| + |y| \le 2$ is",
  "MCQ",
  r"For $x \ge 0$ the condition is $|x - 2| + |y| \le 2$, a rhombus centred at $(2, 0)$ with both diagonals of length $4$, of area $\frac{1}{2} \times 4 \times 4 = 8$. Replacing $x$ by $-x$ does not change the condition, so the part with $x \le 0$ is the mirror rhombus centred at $(-2, 0)$. The two touch only at the origin, so the total area is $16$.",
  "Removing the inner modulus incorrectly, which turns the two small rhombi into one large one.",
  "C11B-modulus-region-area", "Nested modulus in two variables; must see the reflection symmetry and the two rhombi.",
  correct=r"$16$",
  distractors=[(r"$8$", r"Finds only the rhombus centred at $(2, 0)$."),
               (r"$32$", r"Replaces $\left||x| - 2\right|$ by $|x| - 2$, getting $|x| + |y| \le 4$."),
               (r"$24$", r"Takes the region as lying between $|x| + |y| = 2$ and $|x| + |y| = 4$: $32 - 8$.")],
  check=_c35, values=[16, 8, 32, 24], cognitive="Analysis", exams=CX)


def _c36():
    d = set()
    for s1, s2, s3 in itertools.product((1, -1), repeat=3):
        # Ravi at 0, Meera at +-3, Arjun 5 from Meera, Fatima 7 from Arjun
        m = s1 * 3
        a = m + s2 * 5
        f = a + s3 * 7
        assert abs(m - 0) == 3 and abs(a - m) == 5 and abs(f - a) == 7
        d.add(abs(f))
    return sum(d)
q("C11-B-036", T, "Possible values of |a - d| given three consecutive absolute differences", "Difficult",
  "Casework/optimisation",
  r"Four friends, Ravi, Meera, Arjun and Fatima, live in houses beside a straight road. Ravi's house is $3$ km from Meera's, Meera's is $5$ km from Arjun's, and Arjun's is $7$ km from Fatima's. Find the sum of all the different possible values of the distance, in km, between Ravi's house and Fatima's house.",
  "TITA",
  r"Put Ravi at $0$ on a number line. Each step can go either way, so Fatima is at $\pm 3 \pm 5 \pm 7$ and the distance is $|\pm 3 \pm 5 \pm 7|$. Flipping all three signs gives the same distance, so fix $+3$: $3 + 5 + 7 = 15$, $3 + 5 - 7 = 1$, $3 - 5 + 7 = 5$, $3 - 5 - 7 = -9$. The different distances are $1, 5, 9, 15$, with sum $30$.",
  "Assuming the houses are in the order named along the road.",
  "C11B-chain-of-absolute-differences", "Eight sign patterns reduced by symmetry to four, then distinct values.",
  tita_answer=30, check=_c36,
  tita_traps=[(15, r"Assumes the houses lie in the order named, so the only distance is $3 + 5 + 7$."),
              (60, r"Adds the distance for all eight sign patterns, counting each distance twice.")],
  cognitive="Analysis", exams=CX)


def _c37():
    return sum(1 for x in range(-20, 21) for y in range(-20, 21) if abs(x - y) + abs(x + y) == 8)
q("C11-B-037", T, "Integer pairs with |x - y| + |x + y| = 8 (the max identity)", "Difficult",
  "Conceptual/application",
  r"How many ordered pairs of integers $(x, y)$ satisfy $|x - y| + |x + y| = 8$?",
  "MCQ",
  r"For real $x$ and $y$, $|x - y| + |x + y| = 2\max(|x|, |y|)$: if $|x| \ge |y|$, then $x - y$ and $x + y$ both have the sign of $x$ (or one is $0$), so the sum is $2|x|$, and similarly with $y$. So the equation is $\max(|x|, |y|) = 4$: the integer points on the boundary of the square with corners $(\pm 4, \pm 4)$. Each side has $9$ such points and the $4$ corners are shared, giving $4 \times 9 - 4 = 32$.",
  "Reading the equation as $|x| + |y| = 4$, or double counting the corners of the square.",
  "C11B-max-identity-lattice", r"Needs the identity $|x - y| + |x + y| = 2\max(|x|, |y|)$ and a careful boundary count.",
  correct=r"$32$",
  distractors=[(r"$36$", r"Counts $9$ points on each side of the square and does not remove the $4$ shared corners."),
               (r"$81$", r"Counts all integer points with $\max(|x|, |y|) \le 4$, the whole square."),
               (r"$16$", r"Treats the equation as $|x| + |y| = 4$.")],
  check=_c37, values=[32, 36, 81, 16], cognitive="Analysis", exams=CX)


def _c38():
    cnt = 0
    for a in range(-40, 41):
        S = _pl_zero_set(lambda x: abs(x - 2) + abs(x - a) - 5, BP)
        if isinstance(S, FiniteSet) and len(S) == 2 and all(s.is_integer for s in S):
            cnt += 1
    return cnt
q("C11-B-038", T, "Parameter values giving exactly two integer roots of |x - 2| + |x - a| = 5", "Difficult",
  "Inverse/parameter",
  r"For how many integers $a$ does the equation $|x - 2| + |x - a| = 5$ have exactly two real solutions, both of them integers?",
  "MCQ",
  r"The left side is at least $|a - 2|$, with equality on the whole segment between $2$ and $a$. So there are exactly two solutions when $|a - 2| < 5$, that is $-3 < a < 7$; they lie outside the segment and are $x = \frac{a + 2 \pm 5}{2}$. These are integers exactly when $a + 7$ is even, that is when $a$ is odd. The odd integers in $(-3, 7)$ are $-1, 1, 3, 5$: $4$ values.",
  "Ignoring the integrality condition, or including the boundary values of $a$ that give infinitely many solutions.",
  "C11B-sum-of-two-moduli-equation", "Root-count analysis in a parameter, then a parity condition on the roots.",
  correct=r"$4$",
  distractors=[(r"$9$", r"Counts all integers $a$ from $-2$ to $6$ and ignores the condition that the roots be integers."),
               (r"$6$", r"Includes $a = -3$ and $a = 7$; at those values every $x$ between $2$ and $a$ is a solution."),
               (r"$5$", r"Takes the roots to be integers when $a$ is even, giving $-2, 0, 2, 4, 6$.")],
  check=_c38, values=[4, 9, 6, 5], cognitive="Analysis", exams=CX)


def _c39():
    def count(k):
        roots = set()
        for rhs in (k, -k):
            for r in solve(X**2 - 6 * X + 5 - rhs, X):     # x >= 0 branch
                if r.is_real and r >= 0:
                    roots.add(r)
            for r in solve(X**2 + 6 * X + 5 - rhs, X):     # x < 0 branch
                if r.is_real and r < 0:
                    roots.add(r)
        return len(roots)
    h = lambda t: abs(t**2 - 6 * abs(t) + 5)
    crit = [h(R(p)) for p in (0, 1, -1, 3, -3, 5, -5)] + [0]
    return _level_set(count, crit, 4)
q("C11-B-039", T, "Parameter values for exactly four roots of |x^2 - 6|x| + 5| = k", "Difficult",
  "Inverse/parameter",
  r"The equation $\left| x^2 - 6|x| + 5 \right| = k$, where $k$ is a real constant, has exactly four distinct real solutions if and only if",
  "MCQ",
  r"The left side is even in $x$, so count roots with $x > 0$ and double, then check $x = 0$. For $x \ge 0$, $g(x) = (x - 1)(x - 5)$ dips to $-4$ at $x = 3$, so $|g|$ is $5$ at $x = 0$, $0$ at $x = 1$, a hump of height $4$ at $x = 3$, $0$ at $x = 5$, then rises. For $k = 0$: $x = 1, 5$ (four roots with the mirror). For $0 < k < 4$: four positive roots (eight in all). For $k = 4$: three positive roots (six). For $4 < k < 5$: two positive roots (four in all). For $k = 5$: $x = 0$ and $x = 6$ (three in all). For $k > 5$: one positive root (two). So exactly four when $k = 0$ or $4 < k < 5$.",
  r"Overlooking $k = 0$, counting only $x \ge 0$, or counting $x = 0$ twice at $k = 5$.",
  "C11B-modulus-of-quadratic-level", "Full root-count analysis of an even function with several thresholds, including an isolated value.",
  correct=r"$k = 0$ or $4 < k < 5$",
  distractors=[(r"$4 < k < 5$", r"Overlooks $k = 0$, where $|x| = 1$ and $|x| = 5$ give four roots."),
               (r"$0 < k < 4$", r"Counts roots only for $x \ge 0$, where this range gives four, and forgets the mirror roots."),
               (r"$4 < k \le 5$", r"At $k = 5$ counts $x = 0$ twice, once from each side, and so includes $k = 5$.")],
  check=_c39,
  values=[Union(FiniteSet(0), Interval.open(4, 5)), Interval.open(4, 5), Interval.open(0, 4), Interval.Lopen(4, 5)],
  cognitive="Analysis", exams=CX)


def _c40():
    return _abs_eq_set(Abs(X**2 - 3 * X) + Abs(X - 3) - Abs(X**2 - 2 * X - 3))
q("C11-B-040", T, "Equality case |u| + |v| = |u + v| with polynomial u, v", "Difficult",
  "Conceptual/application",
  r"The set of all real $x$ satisfying $|x^2 - 3x| + |x - 3| = |x^2 - 2x - 3|$ is",
  "MCQ",
  r"Note that $(x^2 - 3x) + (x - 3) = x^2 - 2x - 3$. With $u = x^2 - 3x = x(x - 3)$ and $v = x - 3$, the equation is $|u| + |v| = |u + v|$, which holds exactly when $uv \ge 0$. Here $uv = x(x - 3)^2$, and since $(x - 3)^2 \ge 0$ this is non-negative exactly when $x \ge 0$ (the value $x = 3$ already lies in this range). So the solution set is $x \ge 0$.",
  "Requiring both expressions to be non-negative, and forgetting that both may be non-positive.",
  "C11B-triangle-inequality-equality", r"Must spot that the right side is the sum of the two left terms and analyse $uv \ge 0$.",
  correct=r"$x \ge 0$",
  distractors=[(r"$x \ge 3$", r"Requires $u \ge 0$ and $v \ge 0$ only, and misses the case where both are non-positive."),
               (r"$0 \le x \le 3$", r"Requires $u \le 0$ and $v \le 0$ only, and misses the case where both are non-negative."),
               (r"$x \le 0$ or $x = 3$", r"Uses the condition $uv \le 0$ in place of $uv \ge 0$.")],
  check=_c40,
  values=[Interval(0, oo), Interval(3, oo), Interval(0, 3), Union(Interval(-oo, 0), FiniteSet(3))],
  cognitive="Analysis", exams=CX)
