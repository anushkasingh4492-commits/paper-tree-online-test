import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig

T = "Plane mensuration"
CX = ("CAT", "XAT")
P7 = Rational(22, 7)


def _arc(c, rad, a0, a1, n=48):
    """Points along an arc (degrees, a1 may be smaller than a0)."""
    return [(c[0] + rad * math.cos(math.radians(a0 + (a1 - a0) * k / n)),
             c[1] + rad * math.sin(math.radians(a0 + (a1 - a0) * k / n))) for k in range(n + 1)]


def _rect(f, x0, y0, x1, y1, dashed=False):
    f.poly((x0, y0), (x1, y0), (x1, y1), (x0, y1), dashed=dashed)


def _ghost(f, x, y):
    f.pt("", x, y, dot=False)


def _cell_perim(cells):
    """Perimeter of a union of unit grid cells: count cell edges not shared with another cell."""
    cells = set(cells)
    return sum(1 for (i, j) in cells for (di, dj) in ((1, 0), (-1, 0), (0, 1), (0, -1)) if (i + di, j + dj) not in cells)


def _area(poly):
    """Shoelace area (float) of a simple polygon given as (x, y) tuples."""
    return abs(sum(poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
                   for i in range(len(poly)))) / 2


def _clip(subject, clipper):
    """Sutherland-Hodgman: part of polygon `subject` inside the convex counter-clockwise polygon `clipper`."""
    out = list(subject)
    for i in range(len(clipper)):
        a, b = clipper[i], clipper[(i + 1) % len(clipper)]
        side = lambda p: (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
        inp, out = out, []
        for k in range(len(inp)):
            p, q_ = inp[k], inp[(k + 1) % len(inp)]
            sp, sq = side(p), side(q_)
            if sp >= 0:
                out.append(p)
            if (sp >= 0) != (sq >= 0):
                t = sp / (sp - sq)
                out.append((p[0] + t * (q_[0] - p[0]), p[1] + t * (q_[1] - p[1])))
        if not out:
            return []
    return out


# ============================================================ EASY (13)

# ---------------------------------------------------------------- 001
def _c001():
    l, b, w = 40, 25, Rational(5, 2)
    return (l + 2 * w) * (b + 2 * w) - l * b
f = Fig()
_rect(f, -2.5, -2.5, 42.5, 27.5); _rect(f, 0, 0, 40, 25)
f.text((20, 12.5), "lawn"); f.text((20, 2.2), "40 m"); f.text((36.5, 12.5), "25 m")
f.text((20, 30.2), "path, 2.5 m wide"); _ghost(f, 20, 31.5)
alt = "A rectangular lawn 40 m by 25 m surrounded on all sides by a path 2.5 m wide drawn outside it."
q("C18-A-001", T, "Area of a uniform path around the outside of a rectangular lawn", "Easy",
  "Multi-step word problem",
  r"A rectangular lawn measures $40$ m by $25$ m. A gravel path of uniform width $2.5$ m is laid all around the lawn, outside it. What is the area of the path, in m$^2$?",
  "TITA",
  r"The outer rectangle measures $(40 + 5)$ m by $(25 + 5)$ m, that is $45$ m by $30$ m, with area $1350$ m$^2$. Subtracting the lawn, the path has area $1350 - 40 \times 25 = 1350 - 1000 = 350$ m$^2$.",
  "Adding the path width only once to each dimension, or leaving out the four corner squares of the path.",
  "C18A-path-around-rectangle", "Single idea (outer minus inner rectangle) with the corner-square trap.",
  tita_answer=350, check=_c001, values=[350],
  tita_traps=[(325, r"Uses $2 \times 2.5 \times (40 + 25)$, which leaves out the four corner squares of the path."),
              (300, r"Places the path inside the lawn: $1000 - 35 \times 20$.")],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 002
def _c002():
    cells = sum(1 for x in range(80) for y in range(50) if 38 <= x < 42 or 23 <= y < 27)
    return cells * 15
f = Fig()
f.shade([(38, 0), (42, 0), (42, 50), (38, 50)]); f.shade([(0, 23), (80, 23), (80, 27), (0, 27)])
_rect(f, 0, 0, 80, 50)
f.seg((38, 0), (38, 50)); f.seg((42, 0), (42, 50)); f.seg((0, 23), (80, 23)); f.seg((0, 27), (80, 27))
f.label_seg((0, 0), (80, 0), "80 m"); f.label_seg((0, 0), (0, 50), "50 m")
f.text((62, 29.5), "road 4 m wide"); f.text((53.5, 44), "road 4 m wide")
alt = "A rectangular field 80 m by 50 m with two shaded roads 4 m wide crossing at the middle, one parallel to each side."
q("C18-A-002", T, "Cost of gravelling two crossroads through a rectangular field", "Easy",
  "Multi-step word problem",
  r"A rectangular field measures $80$ m by $50$ m. Two roads, each $4$ m wide, run through the middle of the field, one parallel to the length and one parallel to the breadth, so that they cross each other. Gravelling the roads costs Rs. $15$ per m$^2$. What is the total cost of gravelling the roads?",
  "MCQ",
  r"Road area $= 4 \times 80 + 4 \times 50 - 4 \times 4 = 320 + 200 - 16 = 504$ m$^2$, since the $4 \times 4$ square where the roads cross is counted in both strips. Cost $= 504 \times 15 = $ Rs. $7{,}560$.",
  "Not removing the common square where the roads cross, or mishandling it.",
  "C18A-crossroads-in-field", "Two strips plus the overlap correction; one step of cost.",
  correct=r"Rs. $7{,}560$",
  distractors=[(r"Rs. $7{,}800$", r"Adds the two strips, $320 + 200 = 520$ m$^2$, without removing the $16$ m$^2$ crossing counted twice."),
               (r"Rs. $7{,}320$", r"Subtracts the $16$ m$^2$ crossing twice: $520 - 32 = 488$ m$^2$."),
               (r"Rs. $7{,}680$", r"Takes the crossing as $4 + 4 = 8$ m$^2$: $520 - 8 = 512$ m$^2$.")],
  check=_c002, values=[7560, 7800, 7320, 7680],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 003
def _c003():
    r, w = 14, 7
    return P7 * ((r + w) ** 2 - r ** 2)
f = Fig()
O = f.pt("O", 0, 0, offset=(-0.7, 0.7)); f.circle(O, 14); f.circle(O, 21)
f.seg((0, 0), (14, 0)); f.seg((14, 0), (21, 0), dashed=True)
f.text((7, 1.6), "14 m"); f.text((17.5, 1.6), "7 m")
f.text((0, -8), "pond")
alt = "A circular pond of radius 14 m with centre O, surrounded by a circular path 7 m wide outside it."
q("C18-A-003", T, "Area of a circular path around a circular pond", "Easy",
  "Single-step computation",
  r"A circular pond has radius $14$ m. A path $7$ m wide is built all around it, outside the pond. Taking $\pi = \frac{22}{7}$, what is the area of the path, in m$^2$?",
  "TITA",
  r"The outer radius is $14 + 7 = 21$ m. Path area $= \pi(21^2 - 14^2) = \frac{22}{7} \times (21 - 14)(21 + 14) = \frac{22}{7} \times 7 \times 35 = 770$ m$^2$.",
  "Using the width as a radius, or multiplying the inner circumference by the width.",
  "C18A-circular-ring", "Direct difference of two circle areas.",
  tita_answer=770, check=_c003, values=[770],
  tita_traps=[(154, r"Computes $\pi \times 7^2$, treating the width as a radius."),
              (616, r"Multiplies the inner circumference by the width: $88 \times 7$.")],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 004
def _c004():
    s, r = 28, 14
    # four quarter circles, one per corner; they do not overlap since 2r = s
    return s ** 2 - 4 * Rational(1, 4) * P7 * r ** 2
f = Fig()
_rect(f, 0, 0, 28, 28)
f.arc((0, 0), 14, 0, 90); f.arc((28, 0), 14, 90, 180); f.arc((28, 28), 14, 180, 270); f.arc((0, 28), 14, 270, 360)
f.seg((0, 0), (14 * math.cos(math.radians(45)), 14 * math.sin(math.radians(45))), dashed=True)
f.text((7.5, 3.6), "14 cm")
f.label_seg((0, 28), (28, 28), "28 cm")
alt = "A square of side 28 cm with a quarter circle of radius 14 cm drawn inside it at each of the four corners."
q("C18-A-004", T, "Square minus four corner quadrants", "Easy",
  "Single-step computation",
  r"A square tile has side $28$ cm. With each corner of the tile as centre, a quarter circle of radius $14$ cm is drawn inside the tile, and the four quarter circles are painted. Taking $\pi = \frac{22}{7}$, what is the area of the unpainted part of the tile?",
  "MCQ",
  r"The four quarter circles of radius $14$ cm together make one full circle of area $\frac{22}{7} \times 196 = 616$ cm$^2$. They do not overlap, because adjacent ones only meet at the midpoint of a side. Unpainted area $= 28^2 - 616 = 784 - 616 = 168$ cm$^2$.",
  "Subtracting only part of the quadrants, or reporting the painted area.",
  "C18A-square-corner-quadrants", "One observation (four quadrants make a circle) and one subtraction.",
  correct=r"$168$ cm$^2$",
  distractors=[(r"$616$ cm$^2$", "Reports the painted area, the total of the four quarter circles."),
               (r"$630$ cm$^2$", r"Subtracts only one quarter circle: $784 - 154$."),
               (r"$476$ cm$^2$", r"Subtracts only two of the quarter circles: $784 - 308$.")],
  check=_c004, values=[168, 616, 630, 476],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 005
def _c005():
    r = symbols('r', positive=True)
    rr = solve(Eq(2 * P7 * r, 4 * 33), r)[0]
    return P7 * rr ** 2
q("C18-A-005", T, "Wire bent from a square into a circle", "Easy",
  "Single-step computation",
  r"A wire is bent to form a square of side $33$ cm. The same wire is then straightened and bent to form a circle. Taking $\pi = \frac{22}{7}$, what is the area enclosed by the circle?",
  "MCQ",
  r"The wire is $4 \times 33 = 132$ cm long. So $2\pi r = 132$, giving $r = \frac{132 \times 7}{44} = 21$ cm. Area $= \frac{22}{7} \times 21^2 = 1386$ cm$^2$.",
  r"Assuming the area stays the same when the shape changes, or using $\pi r$ for the circumference.",
  "C18A-wire-reshaped", "Equal perimeters, then one circle area.",
  correct=r"$1386$ cm$^2$",
  distractors=[(r"$1089$ cm$^2$", "Assumes the enclosed area is unchanged and reports the square's area $33^2$."),
               (r"$5544$ cm$^2$", r"Uses $\pi r = 132$ for the circumference, so $r = 42$."),
               (r"$693$ cm$^2$", r"Uses $\frac{\pi r^2}{2}$ for the area of the circle.")],
  check=_c005, values=[1386, 1089, 5544, 693])

# ---------------------------------------------------------------- 006
def _c006():
    th = Rational(90, 360)
    outer = th * P7 * 28 ** 2          # sector of radius 28 cm (tip of the blade)
    inner = th * P7 * 14 ** 2          # sector of radius 14 cm (inner end of the blade) is not wiped
    return outer - inner
q("C18-A-006", T, "Area wiped by a windscreen wiper blade (part of a ring between two radii)", "Easy",
  "Multi-step word problem",
  r"A windscreen wiper arm turns about a pivot. The rubber blade is fixed along the arm and covers the part of the arm from $14$ cm to $28$ cm from the pivot. In one sweep the arm turns through $90^\circ$. Taking $\pi = \frac{22}{7}$, what area of the windscreen does the blade wipe in one sweep?",
  "MCQ",
  r"The wiped region is the part of a $90^\circ$ sector of radius $28$ cm that lies outside the $90^\circ$ sector of radius $14$ cm. Area $= \frac{1}{4} \times \frac{22}{7} \times (28^2 - 14^2) = \frac{1}{4} \times \frac{22}{7} \times 588 = \frac{1}{4} \times 1848 = 462$ cm$^2$.",
  "Taking the whole sector up to the tip, or using the blade length as the radius.",
  "C18A-sector-swept", "One sector-of-a-ring idea and one quarter-turn fraction.",
  correct=r"$462$ cm$^2$",
  distractors=[(r"$616$ cm$^2$", r"Takes the full quarter circle of radius $28$ cm, ignoring that the blade starts $14$ cm from the pivot."),
               (r"$154$ cm$^2$", r"Uses the blade length $14$ cm as the radius of a quarter circle."),
               (r"$1848$ cm$^2$", r"Finds the full ring $\frac{22}{7}(28^2 - 14^2)$ and forgets that the arm turns only $90^\circ$.")],
  check=_c006, values=[462, 616, 154, 1848])

# ---------------------------------------------------------------- 007
def _c007():
    l, b = symbols('l b', positive=True)
    new = (l * Rational(6, 5)) * (b * Rational(9, 10))
    return simplify((new - l * b) / (l * b) * 100)
q("C18-A-007", T, "Percentage change in area of a rectangle", "Easy",
  "Single-step computation",
  r"The length of a rectangular plot is increased by $20\%$ and its breadth is decreased by $10\%$. By what percentage does the area of the plot increase?",
  "MCQ",
  r"The new area is $1.2 \times 0.9 = 1.08$ times the old area, an increase of $8\%$. Equivalently, $20 - 10 + \frac{20 \times (-10)}{100} = 8$.",
  "Adding or subtracting the percentages without the product term.",
  "C18A-percent-change-dimensions", "One multiplication of scale factors.",
  correct=r"$8\%$",
  distractors=[(r"$10\%$", r"Takes $20 - 10$ and ignores the product term."),
               (r"$12\%$", r"Adds the product term with the wrong sign: $20 - 10 + 2$."),
               (r"$30\%$", r"Adds the sizes of the two changes, $20 + 10$.")],
  check=_c007, values=[8, 10, 12, 30])

# ---------------------------------------------------------------- 008
def _c008():
    s = symbols('s', positive=True)
    side = solve(Eq(2 * (s + s / 4), 50), s)[0]        # each strip is s by s/4
    return side ** 2
q("C18-A-008", T, "Side of a square from the perimeter of the identical strips cut from it", "Easy",
  "Inverse/parameter",
  r"A square sheet of paper is cut into $4$ identical rectangular strips by three straight cuts, all parallel to one side of the square. The perimeter of each strip is $50$ cm. What was the area of the square sheet?",
  "MCQ",
  r"If the square has side $s$, each strip measures $s$ by $\frac{s}{4}$. Its perimeter is $2\left(s + \frac{s}{4}\right) = \frac{5s}{2} = 50$, so $s = 20$ cm and the sheet's area was $400$ cm$^2$.",
  "Using the half perimeter as the perimeter, or treating the strip's perimeter as a quarter of the square's.",
  "C18A-cut-into-strips", "One equation from the strip's dimensions.",
  correct=r"$400$ cm$^2$",
  distractors=[(r"$1600$ cm$^2$", r"Writes $s + \frac{s}{4} = 50$, forgetting the factor $2$ in the perimeter, so $s = 40$."),
               (r"$2500$ cm$^2$", r"Takes the square's perimeter as $4 \times 50 = 200$ cm, so $s = 50$."),
               (r"$100$ cm$^2$", r"Reports the area of one strip, $20 \times 5$.")],
  check=_c008, values=[400, 1600, 2500, 100])

# ---------------------------------------------------------------- 009
def _c009():
    L, B = 720, 504                     # in cm
    best = max(t for t in range(1, B + 1) if L % t == 0 and B % t == 0)
    return (L // best) * (B // best)
q("C18-A-009", T, "Least number of identical square tiles for a floor", "Easy",
  "Single-step computation",
  r"The floor of a hall measures $7.2$ m by $5.04$ m. It is to be covered completely with square tiles, all of the same size, with no tile cut or broken. What is the least number of tiles needed?",
  "TITA",
  r"Fewest tiles means the largest tile. In centimetres the floor is $720$ by $504$, and $\gcd(720, 504) = 72$. So the tile side is $72$ cm and the number of tiles is $\frac{720}{72} \times \frac{504}{72} = 10 \times 7 = 70$.",
  "Reporting the tile size, or mixing metres and centimetres when finding the HCF.",
  "C18A-tiles-largest-square", "One HCF and one division.",
  tita_answer=70, check=_c009, values=[70],
  tita_traps=[(72, "Reports the side of the tile in centimetres."),
              (7, r"Writes $7.2$ m as $72$ cm, so $\gcd(72, 504) = 72$ and $1 \times 7$ tiles.")])

# ---------------------------------------------------------------- 010
def _c010():
    L, W = symbols('L W', positive=True)
    sol = solve([Eq(2 * L, 3 * W), Eq(5 * L * W, 1080)], [L, W], dict=True)[0]
    width, height = 2 * sol[L], sol[W] + sol[L]          # top row: two tiles lengthwise; bottom row: three upright
    assert 3 * sol[W] == width
    return 2 * (width + height)
q("C18-A-010", T, "Perimeter of a rectangle assembled from five identical tiles", "Medium",
  "Multi-step word problem",
  r"Five identical rectangular tiles are placed without gaps or overlaps to form one large rectangle. In the top row, two tiles lie lengthwise, end to end. In the bottom row, three tiles stand upright, side by side. The area of the large rectangle is $1080$ cm$^2$. What is the perimeter of the large rectangle?",
  "MCQ",
  r"Let each tile be $L$ by $W$ with $L > W$. The two rows have the same width, so $2L = 3W$. Each tile has area $\frac{1080}{5} = 216$, so $LW = \frac{3W}{2} \times W = 216$, giving $W = 12$ and $L = 18$. The large rectangle is $2L = 36$ cm wide and $W + L = 30$ cm tall, so its perimeter is $2(36 + 30) = 132$ cm.",
  "Reporting a tile's perimeter or the half perimeter, or misreading which tile side sets each row's height.",
  "C18A-identical-tiles-rectangle", "Reading the arrangement to get $2L = 3W$, then the area, then the outline.",
  correct=r"$132$ cm",
  distractors=[(r"$66$ cm", r"Adds the width and the height once, $36 + 30$, giving the half perimeter."),
               (r"$60$ cm", r"Reports the perimeter of one tile, $2(18 + 12)$."),
               (r"$144$ cm", r"Takes the top row's height as the tile length too, so the outline is $36$ cm by $36$ cm.")],
  check=_c010, values=[132, 66, 60, 144])

# ---------------------------------------------------------------- 011
def _c011():
    s = 12
    Pp, Qp, Rp = Point(0, 0), Point(s, 0), Point(Rational(s, 2), s * sqrt(3) / 2)
    circ = Triangle(Pp, Qp, Rp).circumcircle
    return simplify(pi * circ.radius ** 2 - Triangle(Pp, Qp, Rp).area)
q("C18-A-011", T, "Circumcircle minus an equilateral triangle", "Easy",
  "Multi-step word problem",
  r"An equilateral triangle of side $12$ cm is drawn with all three of its vertices on a circle. What is the area of the region inside the circle but outside the triangle?",
  "MCQ",
  r"The circumradius of an equilateral triangle of side $a$ is $\frac{a}{\sqrt{3}}$, here $4\sqrt{3}$ cm, so the circle has area $48\pi$ cm$^2$. The triangle has area $\frac{\sqrt{3}}{4} \times 144 = 36\sqrt{3}$ cm$^2$. Required area $= (48\pi - 36\sqrt{3})$ cm$^2$.",
  "Taking the circumradius equal to the height or the side, or misusing the triangle area formula.",
  "C18A-circle-minus-polygon", "Two standard formulas combined.",
  correct=r"$(48\pi - 36\sqrt{3})$ cm$^2$",
  distractors=[(r"$(108\pi - 36\sqrt{3})$ cm$^2$", r"Takes the circumradius equal to the height, $6\sqrt{3}$ cm."),
               (r"$(48\pi - 72\sqrt{3})$ cm$^2$", r"Uses $\frac{\sqrt{3}}{2}a^2$ for the triangle's area."),
               (r"$(144\pi - 36\sqrt{3})$ cm$^2$", r"Takes the circumradius equal to the side, $12$ cm.")],
  check=_c011, values=[48 * pi - 36 * sqrt(3), 108 * pi - 36 * sqrt(3), 48 * pi - 72 * sqrt(3), 144 * pi - 36 * sqrt(3)])

# ---------------------------------------------------------------- 012
_stair = [(0, 0), (30, 0), (30, 3), (24, 3), (24, 9), (15, 9), (15, 13), (8, 13), (8, 18), (0, 18)]
def _c012():
    per = 0
    for i in range(len(_stair)):
        (x1, y1), (x2, y2) = _stair[i], _stair[(i + 1) % len(_stair)]
        per += abs(x2 - x1) + abs(y2 - y1)
    return per
f = Fig()
f.poly(*_stair)
f.label_seg((0, 0), (30, 0), "30 m"); f.label_seg((0, 0), (0, 18), "18 m")
alt = "A plot with a straight bottom edge of 30 m, a straight left edge of 18 m, and a boundary that steps down from the top of the left edge to the right end of the bottom edge."
q("C18-A-012", T, "Perimeter of a stepped (staircase) plot", "Easy",
  "Conceptual/application",
  r"A plot of land has a boundary made only of horizontal and vertical straight segments. Its bottom edge is one straight segment $30$ m long and its left edge is one straight segment $18$ m long. From the top of the left edge, the rest of the boundary descends in steps of unequal sizes to the right end of the bottom edge: every horizontal segment of the steps runs to the right and every vertical segment runs downward. What is the perimeter of the plot, in metres?",
  "TITA",
  r"The horizontal segments of the steps together cover the full width, $30$ m, and the vertical segments together cover the full height, $18$ m, whatever the individual step sizes. So the perimeter is $30 + 18 + 30 + 18 = 96$ m, the same as that of a $30 \times 18$ rectangle.",
  "Believing the step sizes are needed, or counting only the two straight edges.",
  "C18A-rectilinear-perimeter", "One insight: the steps project onto the full width and height.",
  tita_answer=96, check=_c012, values=[96], cognitive="Understanding",
  tita_traps=[(48, "Adds only the two straight edges, $30 + 18$.")],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 013
def _c013():
    Pp, Qp, Rp, Sp = Point(0, 0), Point(30, 0), Point(30, 16), Point(0, 16)
    Tp = Point(12, 16)                    # ST = 12 along SR
    return abs(Polygon(Pp, Tp, Sp).area) + abs(Polygon(Qp, Rp, Tp).area)
q("C18-A-013", T, "Triangle on a side of a rectangle covers half of it", "Easy",
  "Conceptual/application",
  r"A rectangular plot $PQRS$ has $PQ = 30$ m and $QR = 16$ m. A point $T$ lies on side $RS$ with $ST = 12$ m. The triangular portion $PQT$ is a flower bed and the rest of the plot is lawn. What is the area of the lawn?",
  "MCQ",
  r"Triangle $PQT$ has base $PQ = 30$ m and height $16$ m, so its area is $\frac{1}{2} \times 30 \times 16 = 240$ m$^2$, exactly half the rectangle, wherever $T$ lies on $RS$. The lawn is the other half: $480 - 240 = 240$ m$^2$ (check: triangles $PST$ and $QRT$ have areas $96$ and $144$).",
  "Reporting only one of the two lawn triangles, or the whole plot.",
  "C18A-triangle-half-rectangle", "One principle: a triangle on a side with apex on the opposite side is half the rectangle.",
  correct=r"$240$ m$^2$",
  distractors=[(r"$96$ m$^2$", r"Finds only triangle $PST$, $\frac{1}{2} \times 12 \times 16$."),
               (r"$144$ m$^2$", r"Finds only triangle $QRT$, $\frac{1}{2} \times 18 \times 16$."),
               (r"$480$ m$^2$", "Reports the area of the whole plot.")],
  check=_c013, values=[240, 96, 144, 480], cognitive="Understanding")

# ============================================================ MEDIUM (21)

# ---------------------------------------------------------------- 014
def _c014():
    w = symbols('w', positive=True)
    return solve(Eq((24 + 2 * w) * (16 + 2 * w) - 24 * 16, 24 * 16), w)[0]
q("C18-A-014", T, "Width of an outside path whose area equals the garden's", "Medium",
  "Inverse/parameter",
  r"A rectangular garden measures $24$ m by $16$ m. A path of uniform width runs all around the outside of the garden, and the area of the path equals the area of the garden. What is the width of the path, in metres?",
  "TITA",
  r"Let the width be $w$. The outer rectangle has area twice the garden's: $(24 + 2w)(16 + 2w) = 768$. So $4w^2 + 80w + 384 = 768$, that is $w^2 + 20w - 96 = 0 = (w + 24)(w - 4)$. Hence $w = 4$ m.",
  "Adding the width only once to each dimension.",
  "C18A-path-around-rectangle", "Sets up and solves a quadratic from an area condition.",
  tita_answer=4, check=_c014, values=[4],
  tita_traps=[(8, r"Uses $(24 + w)(16 + w) = 768$, adding the width once to each dimension.")])

# ---------------------------------------------------------------- 015
def _c015():
    w = symbols('w', positive=True)
    sols = []
    for ww in solve(Eq(60 * 40 - (60 * w + 40 * w - w ** 2), 2109), w):
        if 0 < ww < 40:
            sols.append(ww)
    assert len(sols) == 1
    return sols[0]
q("C18-A-015", T, "Width of crossroads from the remaining lawn area", "Medium",
  "Inverse/parameter",
  r"A rectangular field measures $60$ m by $40$ m. Two roads of the same width run through the middle of the field, one parallel to each side, and cross each other. The rest of the field, $2109$ m$^2$ in all, is lawn. What is the width of each road, in metres?",
  "TITA",
  r"Slide the roads to two adjacent edges: the lawn becomes a single rectangle $(60 - w)$ by $(40 - w)$. So $(60 - w)(40 - w) = 2109$, giving $w^2 - 100w + 291 = 0 = (w - 3)(w - 97)$. Since $w < 40$, $w = 3$ m.",
  "Ignoring the overlap square, or keeping the impossible root.",
  "C18A-crossroads-in-field", "Requires the shifting insight and rejecting one root of a quadratic.",
  tita_answer=3, check=_c015, values=[3],
  tita_traps=[(97, "Keeps the other root of the quadratic, which is wider than the field.")])

# ---------------------------------------------------------------- 016
_f16 = [(0, 0), (30, 24), (80, 30), (100, 0), (50, -36)]          # P, U, V, Q, W
def _c016():
    pts = [Point(*p) for p in _f16]
    return abs(Polygon(*pts).area)
f = Fig()
f.poly(*_f16)
f.seg((0, 0), (100, 0), dashed=True)
f.seg((30, 0), (30, 24), dashed=True); f.seg((80, 0), (80, 30), dashed=True); f.seg((50, 0), (50, -36), dashed=True)
f.right_angle((0, 0), (30, 0), (30, 24)); f.right_angle((100, 0), (80, 0), (80, 30)); f.right_angle((0, 0), (50, 0), (50, -36))
f.pt("P", 0, 0, offset=(-1, 0)); f.pt("Q", 100, 0, offset=(1, 0)); f.pt("U", 30, 24, offset=(-0.6, 0.8))
f.pt("V", 80, 30, offset=(0.4, 1)); f.pt("W", 50, -36, offset=(0, -1))
f.text((35.5, 12), "24"); f.text((85.5, 15), "30"); f.text((55.5, -18), "36")
f.text((15, 3.5), "30"); f.text((55, 3.5), "50"); f.text((90, 3.5), "20")
alt = "Field PUVQW with base line PQ of 100 m drawn dashed. Perpendiculars from U (24 m) and V (30 m) meet PQ 30 m and 80 m from P on one side; the perpendicular from W (36 m) meets PQ 50 m from P on the other side."
q("C18-A-016", T, "Area of a field from a base line and perpendicular offsets", "Medium",
  "Multi-step word problem",
  r"A surveyor measures a field along a straight base line $PQ$ of length $100$ m, where $P$ and $Q$ are corners of the field. On one side of $PQ$ the field has two more corners, $U$ and $V$: the perpendicular from $U$ to $PQ$ is $24$ m long and meets $PQ$ at a point $30$ m from $P$, and the perpendicular from $V$ to $PQ$ is $30$ m long and meets $PQ$ at a point $80$ m from $P$. On the other side of $PQ$ the field has one more corner, $W$, whose perpendicular to $PQ$ is $36$ m long and meets $PQ$ at a point $50$ m from $P$. The boundary of the field runs in straight lines from $P$ to $U$ to $V$ to $Q$ to $W$ and back to $P$. What is the area of the field?",
  "MCQ",
  r"On the side of $U$ and $V$ the perpendiculars cut the region into a triangle ($\frac{1}{2} \times 30 \times 24 = 360$), a trapezium ($\frac{1}{2}(24 + 30) \times 50 = 1350$) and a triangle ($\frac{1}{2} \times 20 \times 30 = 300$), total $2010$ m$^2$. On the other side, triangle $PWQ$ has area $\frac{1}{2} \times 100 \times 36 = 1800$ m$^2$. The field's area is $2010 + 1800 = 3810$ m$^2$.",
  r"Dropping a factor $\frac{1}{2}$ on a triangle or the trapezium.",
  "C18A-field-offsets", "Splitting the field into triangles and a trapezium on both sides of the base line.",
  correct=r"$3{,}810$ m$^2$",
  distractors=[(r"$5{,}610$ m$^2$", r"Takes triangle $PWQ$ as $100 \times 36$, forgetting the $\frac{1}{2}$."),
               (r"$4{,}470$ m$^2$", r"Treats the two end triangles on the $U$, $V$ side as rectangles, $30 \times 24$ and $20 \times 30$."),
               (r"$5{,}160$ m$^2$", r"Takes the trapezium as $(24 + 30) \times 50$, forgetting the $\frac{1}{2}$.")],
  check=_c016, values=[3810, 5610, 4470, 5160],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 017
def _c017():
    s, a = 4, 2
    r = symbols('r', positive=True)
    rc = solve(Eq(sqrt(2) * s / 2, a + r), r)[0]          # centre-to-corner = a + r
    return expand(s ** 2 - 4 * pi * a ** 2 / 4 - pi * rc ** 2)
f = Fig()
_rect(f, 0, 0, 4, 4)
f.arc((0, 0), 2, 0, 90); f.arc((4, 0), 2, 90, 180); f.arc((4, 4), 2, 180, 270); f.arc((0, 4), 2, 270, 360)
f.circle((2, 2), 2 * math.sqrt(2) - 2)
f.label_seg((0, 0), (4, 0), "4 cm")
f.seg((0, 4), (0, 2), dashed=False); f.text((-0.45, 3), "2 cm")
alt = "A square of side 4 cm with a quarter circle of radius 2 cm at each corner and a small circle at the centre touching all four quarter circles."
q("C18-A-017", T, "Square minus corner quadrants and a central touching circle", "Medium",
  "Multi-step word problem",
  r"In a square of side $4$ cm, a quarter circle of radius $2$ cm is drawn inside the square at each corner, centred at that corner. A circle centred at the centre of the square touches each of the four quarter circles externally. What is the area of the part of the square that lies outside all five of these circular regions?",
  "MCQ",
  r"The centre of the square is $2\sqrt{2}$ cm from each corner, so the central circle has radius $2\sqrt{2} - 2$ and area $\pi(12 - 8\sqrt{2})$. The four quarter circles make one circle of radius $2$, area $4\pi$. Required area $= 16 - 4\pi - (12 - 8\sqrt{2})\pi = 16 - (16 - 8\sqrt{2})\pi$ cm$^2$.",
  "Getting the central circle's radius from the half side instead of the half diagonal, or dropping a piece.",
  "C18A-square-corner-quadrants", "Needs the half diagonal for the central radius and an exact surd square.",
  correct=r"$16 - (16 - 8\sqrt{2})\pi$ cm$^2$",
  distractors=[(r"$16 - 4\pi$ cm$^2$", "Leaves out the central circle."),
               (r"$16 - (7 - 2\sqrt{2})\pi$ cm$^2$", r"Takes the central radius as half of $2\sqrt{2} - 2$, that is $\sqrt{2} - 1$."),
               (r"$16 - (13 - 8\sqrt{2})\pi$ cm$^2$", r"Counts the four quarter circles as a single quarter circle, area $\pi$.")],
  check=_c017, values=[16 - (16 - 8 * sqrt(2)) * pi, 16 - 4 * pi, 16 - (7 - 2 * sqrt(2)) * pi, 16 - (13 - 8 * sqrt(2)) * pi],
  exams=CX, figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 018
def _c018():
    x = symbols('x', real=True)
    lo = 5 - sqrt(25 - x ** 2)            # lower arc: semicircle on the left side, centre (0, 5)
    hi = sqrt(25 - (x - 5) ** 2)          # upper arc: semicircle on the bottom side, centre (5, 0)
    leaf = integrate(hi - lo, (x, 0, 5))
    return simplify(4 * leaf)
f = Fig()
leaves = []
leaves.append(_arc((0, 5), 5, 270, 360) + _arc((5, 0), 5, 90, 180))
leaves.append(_arc((5, 0), 5, 0, 90) + _arc((10, 5), 5, 180, 270))
leaves.append(_arc((10, 5), 5, 90, 180) + _arc((5, 10), 5, 270, 360))
leaves.append(_arc((5, 10), 5, 180, 270) + _arc((0, 5), 5, 0, 90))
for lf in leaves:
    f.shade(lf)
_rect(f, 0, 0, 10, 10)
f.arc((5, 0), 5, 0, 180); f.arc((10, 5), 5, 90, 270); f.arc((5, 10), 5, 180, 360); f.arc((0, 5), 5, 270, 450)
f.label_seg((0, 0), (10, 0), "10 cm")
alt = "A square of side 10 cm with a semicircle drawn inward on each side; the four overlapping leaf-shaped regions are shaded."
q("C18-A-018", T, "Leaf regions formed by four inward semicircles in a square", "Medium",
  "Conceptual/application",
  r"Inside a square of side $10$ cm, a semicircle is drawn on each side of the square as diameter, all four semicircles lying inside the square. Adjacent semicircles overlap in four leaf-shaped regions. What is the total area of the four leaf-shaped regions?",
  "MCQ",
  r"The four semicircles have total area $4 \times \frac{1}{2}\pi \times 5^2 = 50\pi$. Together they cover the square exactly once, except that each leaf is covered twice. So $50\pi = 100 + (\text{leaves})$, and the leaves total $(50\pi - 100)$ cm$^2$.",
  "Counting each leaf as a single circular segment, or finding the unshaded region instead.",
  "C18A-inward-semicircles-leaves", "Needs the double-counting insight rather than direct integration.",
  correct=r"$(50\pi - 100)$ cm$^2$",
  distractors=[(r"$(200 - 50\pi)$ cm$^2$", "Finds the part of the square outside the leaves."),
               (r"$(25\pi - 50)$ cm$^2$", r"Takes each leaf as one segment, $\frac{25\pi}{4} - \frac{25}{2}$, though a leaf is two such segments."),
               (r"$(100 - 25\pi)$ cm$^2$", "Subtracts an inscribed circle of radius $5$ from the square.")],
  check=_c018, values=[50 * pi - 100, 200 - 50 * pi, 25 * pi - 50, 100 - 25 * pi],
  cognitive="Analysis", exams=CX, figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 019
def _c019():
    a, b = symbols('a b', positive=True)
    sols = solve([Eq(4 * (a + b), 56), Eq(a * b, 40)], [a, b], dict=True)
    longer = {max(s_[a], s_[b]) for s_ in sols}
    assert len(longer) == 1
    lo = min(sols[0][a], sols[0][b])
    assert (longer.pop() - lo) > 0                       # the central hole really exists
    return max(sols[0][a], sols[0][b])
f = Fig()
_rect(f, 0, 0, 10, 4); _rect(f, 10, 0, 14, 10); _rect(f, 4, 10, 14, 14); _rect(f, 0, 4, 4, 14)
f.shade([(4, 4), (10, 4), (10, 10), (4, 10)])
alt = "Four identical rectangular tiles in a pinwheel pattern forming a large square, with a small square hole, shaded, at the centre."
q("C18-A-019", T, "Tile dimensions in a pinwheel square from its perimeter and tile area", "Medium",
  "Conceptual/application",
  r"Four identical rectangular tiles are arranged in a pinwheel pattern to form a large square with a square hole at its centre: each side of the large square consists of the longer side of one tile followed by the shorter side of the next tile. The perimeter of the large square is $56$ cm and each tile has area $40$ cm$^2$. What is the length of the longer side of each tile?",
  "MCQ",
  r"Let the tile be $a$ by $b$ with $a < b$. Each side of the large square is $a + b = \frac{56}{4} = 14$, and $ab = 40$. So $a$ and $b$ are the roots of $t^2 - 14t + 40 = 0$, that is $4$ and $10$. The longer side is $10$ cm (the hole then has side $b - a = 6$ cm, and $196 - 4 \times 40 = 36 = 6^2$ checks).",
  "Reporting the shorter side, the hole's side or the large square's side.",
  "C18A-pinwheel-tiles", "Reading $a + b$ off the outline and combining it with $ab$.",
  correct=r"$10$ cm",
  distractors=[(r"$4$ cm", "Reports the shorter side of the tile."),
               (r"$6$ cm", r"Reports the side of the central hole, $b - a$."),
               (r"$14$ cm", r"Reports the side of the large square, $a + b$.")],
  check=_c019, values=[10, 4, 6, 14],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 020
def _c020():
    # work in half-metre cells: pool 40 x 24 cells, path 3 cells wide on every side
    n = sum(1 for i in range(-3, 43) for j in range(-3, 27) if not (0 <= i < 40 and 0 <= j < 24))
    return n
q("C18-A-020", T, "Number of square tiles to pave a path around a pool", "Medium",
  "Multi-step word problem",
  r"A rectangular swimming pool measures $20$ m by $12$ m. A path $1.5$ m wide is built all around the pool, outside it, and is paved with square tiles of side $50$ cm laid edge to edge without cutting any tile. How many tiles are needed?",
  "TITA",
  r"The outer rectangle is $23$ m by $15$ m, area $345$ m$^2$, so the path has area $345 - 240 = 105$ m$^2$. Each tile covers $0.5 \times 0.5 = 0.25$ m$^2$, so $\frac{105}{0.25} = 420$ tiles are needed. (In tile units the outer rectangle is $46 \times 30$ and the pool $40 \times 24$: $1380 - 960 = 420$.)",
  "Leaving out the corner squares of the path, or taking the tile's area as $0.5$ m$^2$.",
  "C18A-paving-tiles-count", "Path area, then a unit conversion for the tile area.",
  tita_answer=420, check=_c020, values=[420],
  tita_traps=[(384, r"Uses $2 \times 1.5 \times (20 + 12) = 96$ m$^2$, leaving out the four corner squares of the path."),
              (210, r"Takes the tile's area as $0.5$ m$^2$."),
              (105, r"Reports the path's area in m$^2$ as the number of tiles.")])

# ---------------------------------------------------------------- 021
def _c021():
    r, k = symbols('r k', positive=True)
    rr = solve(Eq(P7 * r ** 2, 616), r)[0]
    kk = solve(Eq(2 * (6 * k + 5 * k), 2 * P7 * rr), k)[0]
    return 6 * kk * 5 * kk
q("C18-A-021", T, "Wire reshaped from a circle into a rectangle of given side ratio", "Medium",
  "Multi-step word problem",
  r"A wire bent into a circle encloses an area of $616$ cm$^2$. The wire is straightened and bent into a rectangle whose length and breadth are in the ratio $6 : 5$. Taking $\pi = \frac{22}{7}$, what is the area of the rectangle?",
  "MCQ",
  r"$\frac{22}{7} r^2 = 616$ gives $r^2 = 196$, $r = 14$ cm, so the wire is $2 \times \frac{22}{7} \times 14 = 88$ cm. With sides $6k$ and $5k$, $2(11k) = 88$, so $k = 4$. The rectangle is $24$ cm by $20$ cm, area $480$ cm$^2$.",
  "Equating the full perimeter to $11k$, or assuming the area is conserved.",
  "C18A-wire-reshaped", "Three linked steps: radius, length, ratio split.",
  correct=r"$480$ cm$^2$",
  distractors=[(r"$1920$ cm$^2$", r"Sets $11k = 88$, using the half perimeter as the whole, so $k = 8$ and the sides are $48$ and $40$."),
               (r"$484$ cm$^2$", r"Ignores the ratio and bends the wire into a square of side $22$."),
               (r"$616$ cm$^2$", "Assumes the enclosed area stays the same.")],
  check=_c021, values=[480, 1920, 484, 616])

# ---------------------------------------------------------------- 022
def _c022():
    d = symbols('d', positive=True)                       # distance in cm
    ds = solve(Eq(d / (2 * P7 * 28) - d / (2 * P7 * 35), 120), d)[0]
    return ds / 100
q("C18-A-022", T, "Distance from the difference in revolutions of two wheels", "Medium",
  "Inverse/parameter",
  r"A cart has front wheels of radius $28$ cm and rear wheels of radius $35$ cm. The wheels roll without slipping. Over a certain journey, each front wheel makes $120$ more revolutions than each rear wheel. Taking $\pi = \frac{22}{7}$, how long is the journey, in metres?",
  "TITA",
  r"The circumferences are $2 \times \frac{22}{7} \times 28 = 176$ cm and $2 \times \frac{22}{7} \times 35 = 220$ cm. If the distance is $d$ cm, $\frac{d}{176} - \frac{d}{220} = 120$, so $d \times \frac{44}{176 \times 220} = 120$, giving $d = 105600$ cm $= 1056$ m. (Front: $600$ revolutions; rear: $480$.)",
  "Using radius or diameter in place of circumference, or forgetting the centimetre to metre conversion.",
  "C18A-wheel-revolutions", "Circumference, an equation in the distance, and a unit conversion.",
  tita_answer=1056, check=_c022, values=[1056],
  tita_traps=[(2112, r"Uses $2\pi \times$ diameter as the circumference, doubling both circumferences."),
              (168, r"Divides the distance by the radii instead of the circumferences: $\frac{d}{28} - \frac{d}{35} = 120$.")])

# ---------------------------------------------------------------- 023
_t23 = [(0, 0), (24, 0), (0, 10)]
def _c023():
    M = Point(12, 5)                                     # midpoint of the hypotenuse
    N = Point(12, 0)                                     # midpoint of the 24 cm side
    small = [N, Point(24, 0), M]
    turned = [Point(2 * M.x - p.x, 2 * M.y - p.y) for p in small]     # half turn about M
    trap = [Point(0, 0), N, M, Point(0, 10)]
    pieces = [Polygon(*trap), Polygon(*turned)]
    assert sum(abs(p.area) for p in pieces) == 120
    corners = {(p.x, p.y) for p in trap + turned}
    xs = sorted({c[0] for c in corners}); ys = sorted({c[1] for c in corners})
    w, h = xs[-1] - xs[0], ys[-1] - ys[0]
    assert w * h == 120                                  # the two pieces fill the bounding rectangle exactly
    return 2 * (w + h)
f = Fig()
f.poly(*_t23); f.seg((12, 0), (12, 5), dashed=True)
f.pt("", 12, 5); f.pt("", 12, 0)
f.label_seg((0, 0), (24, 0), "24 cm"); f.label_seg((0, 0), (0, 10), "10 cm"); _ghost(f, -4, 5)
f.right_angle((24, 0), (0, 0), (0, 10))
alt = "A right triangle with perpendicular sides 24 cm and 10 cm; a dashed cut joins the midpoint of the hypotenuse to the midpoint of the 24 cm side."
q("C18-A-023", T, "Perimeter after a right triangle is cut and rearranged into a rectangle", "Medium",
  "Conceptual/application",
  r"A sheet in the shape of a right triangle has its two perpendicular sides $24$ cm and $10$ cm long. It is cut along the straight line joining the midpoint of the hypotenuse to the midpoint of the $24$ cm side. The smaller piece is turned through half a turn about the midpoint of the hypotenuse, so that the two pieces together form a rectangle. What is the perimeter of the rectangle?",
  "MCQ",
  r"The cut is parallel to the $10$ cm side and is $5$ cm long. The smaller piece is a triangle with legs $12$ and $5$; after the half turn about the midpoint of the hypotenuse its $12$ cm leg lies along the top, level with the top vertex, and the pieces form a rectangle $12$ cm by $10$ cm (area $120$, the same as the triangle's). Its perimeter is $2(12 + 10) = 44$ cm.",
  "Assuming the perimeter is unchanged, or picturing the rectangle from the other midline.",
  "C18A-cut-and-rearrange", "Must track where the turned piece lands to read off the rectangle.",
  correct=r"$44$ cm",
  distractors=[(r"$58$ cm", r"Pictures the rectangle $24$ cm by $5$ cm, which comes from cutting parallel to the $24$ cm side."),
               (r"$60$ cm", r"Assumes the perimeter is unchanged: $24 + 10 + 26$."),
               (r"$68$ cm", r"Takes the rectangle as $24$ cm by $10$ cm, the one the triangle is half of.")],
  check=_c023, values=[44, 58, 60, 68],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 024
def _c024():
    # all edge lengths of the L-shaped floor, in cm
    W, H, cw, ch = 600, 420, 150, 90
    edges = [W, H, W - cw, cw, ch, H - ch]
    t = 0
    for e in edges:
        t = math.gcd(t, e)
    assert (W - cw) % 60 != 0 or cw % 60 != 0              # the HCF of the outer sides alone does not fit
    cells = sum(1 for i in range(W // t) for j in range(H // t)
                if not (i * t >= W - cw and j * t >= H - ch))
    return cells
q("C18-A-024", T, "Least number of identical square tiles for an L-shaped floor", "Medium",
  "Casework/optimisation",
  r"An L-shaped floor is formed by removing a $1.5$ m by $0.9$ m rectangle from one corner of a $6$ m by $4.2$ m rectangle, with the $1.5$ m side of the removed piece along a $6$ m side. The floor is to be covered exactly with identical square tiles, without cutting any tile. What is the least number of tiles needed?",
  "TITA",
  r"Fewest tiles means the largest tile whose side divides every edge of the L. In centimetres the edges are $600$, $420$, $450$, $150$, $90$ and $330$, whose HCF is $30$ (the HCF $60$ of the outer sides does not divide $150$ or $90$). The floor's area is $25.2 - 1.35 = 23.85$ m$^2$, so the number of tiles is $\frac{238500}{900} = 265$.",
  "Using only the outer dimensions to choose the tile, or not removing the cut-out.",
  "C18A-tiles-largest-square", "The tile must fit every edge of the L, not just the outer rectangle.",
  tita_answer=265, check=_c024, values=[265],
  tita_traps=[(280, r"Uses $30$ cm tiles but covers the whole $6$ m by $4.2$ m rectangle."),
              (70, r"Uses the HCF $60$ cm of the outer sides and the whole rectangle: $10 \times 7$.")])

# ---------------------------------------------------------------- 025
def _c025():
    return sum(1 for a in range(1, 21) for b in range(a, 21) if 2 * (a + b) == 40 and a * b > 90)
q("C18-A-025", T, "Counting integer rectangles with fixed perimeter and an area bound", "Medium",
  "Casework/optimisation",
  r"How many rectangles with integer side lengths (in cm), perimeter $40$ cm and area greater than $90$ cm$^2$ are there? Congruent rectangles are counted once, and a square counts as a rectangle.",
  "TITA",
  r"With sides $a \le b$, $a + b = 20$ and $a \le 10$. The area $a(20 - a)$ rises as $a$ rises: $a = 6$ gives $84$, $a = 7$ gives $91$. So $a = 7, 8, 9, 10$ work (areas $91, 96, 99, 100$): $4$ rectangles.",
  "Counting each non-square rectangle twice, or dropping the area condition.",
  "C18A-integer-rectangle-count", "Short casework on one variable with an inequality.",
  tita_answer=4, check=_c025, values=[4],
  tita_traps=[(7, r"Counts $7 \times 13$ and $13 \times 7$ as different rectangles."),
              (10, "Counts every integer rectangle with perimeter $40$ cm, ignoring the area condition.")])

# ---------------------------------------------------------------- 026
def _c026():
    p, h = symbols('p h', positive=True)
    sol = solve([Eq(p ** 2 + h ** 2, 13 ** 2), Eq((14 - p) ** 2 + h ** 2, 15 ** 2)], [p, h], dict=True)
    hh = [s_[h] for s_ in sol][0]
    return Rational(1, 2) * (25 + 11) * hh
f = Fig()
f.poly((0, 0), (25, 0), (16, 12), (5, 12))
f.label_seg((0, 0), (25, 0), "25 m"); f.label_seg((5, 12), (16, 12), "11 m")
f.label_seg((0, 0), (5, 12), "13 m"); f.label_seg((25, 0), (16, 12), "15 m")
alt = "A trapezium-shaped field with parallel sides 25 m and 11 m and non-parallel sides 13 m and 15 m."
q("C18-A-026", T, "Area of a trapezium given all four sides", "Medium",
  "Multi-step word problem",
  r"A field is in the shape of a trapezium whose parallel sides are $25$ m and $11$ m long and whose non-parallel sides are $13$ m and $15$ m long. What is the area of the field, in m$^2$?",
  "TITA",
  r"Cut off a parallelogram with sides $11$ and $13$; what remains is a triangle with sides $13$, $14$ $(= 25 - 11)$ and $15$. By Heron's formula ($s = 21$) its area is $\sqrt{21 \times 8 \times 7 \times 6} = 84$, so the height on the side $14$ is $\frac{2 \times 84}{14} = 12$ m. The trapezium's area is $\frac{1}{2}(25 + 11) \times 12 = 216$ m$^2$.",
  "Missing the height, or forgetting the half in the trapezium formula.",
  "C18A-trapezium-via-triangle", "Needs the reduction to a $13$-$14$-$15$ triangle to find the height.",
  tita_answer=216, check=_c026, values=[216],
  tita_traps=[(432, r"Forgets the factor $\frac{1}{2}$: $36 \times 12$."),
              (252, r"Takes the height as the difference of the parallel sides, $14$ m.")],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 027
def _c027():
    straight, r, w = 100, 35, 7
    inner = 2 * straight + 2 * P7 * r
    outer = 2 * straight + 2 * P7 * (r + w)
    return outer - inner
f = Fig()
for rad, dsh in ((35, False), (42, False)):
    f.arc((100, 0), rad, -90, 90, dashed=dsh); f.arc((0, 0), rad, 90, 270, dashed=dsh)
    f.seg((0, rad), (100, rad), dashed=dsh); f.seg((0, -rad), (100, -rad), dashed=dsh)
f.seg((100, 0), (135, 0), dashed=True); f.text((117.5, 6), "35 m")
f.text((50, -48), "track 7 m wide"); _ghost(f, 50, -50); f.text((50, 30), "100 m")
alt = "A running track: two straight stretches of 100 m joined by semicircular ends, inner radius 35 m, track width 7 m."
q("C18-A-027", T, "Difference between outer and inner boundaries of a running track", "Easy",
  "Conceptual/application",
  r"A running track is the region between two closed boundaries. The inner boundary consists of two parallel straight stretches of $100$ m joined at each end by a semicircle of radius $35$ m. The track has a uniform width of $7$ m, so the outer boundary consists of two parallel straight stretches of $100$ m joined at each end by a semicircle of radius $42$ m. Taking $\pi = \frac{22}{7}$, by how much does the length of the outer boundary exceed that of the inner boundary?",
  "MCQ",
  r"The straight stretches are equal and cancel. The two semicircular ends together form a full circle, so the difference is $2\pi \times 42 - 2\pi \times 35 = 2\pi \times 7 = 44$ m. It depends only on the width of the track.",
  "Counting only one curved end, or adding the width to the straight parts.",
  "C18A-stadium-track", r"One insight (the straights cancel, so the difference is $2\pi w$) and one multiplication.",
  correct=r"$44$ m",
  distractors=[(r"$22$ m", r"Counts only one semicircular end: $\pi \times 7$."),
               (r"$88$ m", r"Uses the difference of diameters, $14$ m, as the radius difference: $2\pi \times 14$."),
               (r"$58$ m", r"Adds $7$ m to each straight stretch as well: $44 + 14$.")],
  check=_c027, values=[44, 22, 88, 58], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 028
def _c028():
    L, r, w = 80, 28, 7
    outer = L * 2 * (r + w) + P7 * (r + w) ** 2
    inner = L * 2 * r + P7 * r ** 2
    return outer - inner
q("C18-A-028", T, "Area of a track around a ground with semicircular ends", "Medium",
  "Multi-step word problem",
  r"A sports ground consists of a rectangle $80$ m long and $56$ m wide with a semicircle attached to each of its two $56$ m sides, the semicircles lying outside the rectangle. A track of uniform width $7$ m runs all around the outside of the ground. Taking $\pi = \frac{22}{7}$, what is the area of the track?",
  "MCQ",
  r"Along each straight side the track is an $80 \times 7$ strip: $2 \times 560 = 1120$ m$^2$. The two curved ends together form a full ring with radii $28$ m and $35$ m: $\frac{22}{7}(35^2 - 28^2) = \frac{22}{7} \times 7 \times 63 = 1386$ m$^2$. Total $= 1120 + 1386 = 2506$ m$^2$.",
  "Missing a straight strip, or treating each curved end as a full ring.",
  "C18A-stadium-track", "Splitting the track into straight strips and two half-rings.",
  correct=r"$2506$ m$^2$",
  distractors=[(r"$1386$ m$^2$", "Counts only the curved ends."),
               (r"$1946$ m$^2$", r"Counts only one straight strip: $560 + 1386$."),
               (r"$3892$ m$^2$", r"Treats each curved end as a full ring: $1120 + 2 \times 1386$.")],
  check=_c028, values=[2506, 1386, 1946, 3892])

# ---------------------------------------------------------------- 029
def _c029():
    r, s1, s2 = symbols('r s1 s2', positive=True)
    a1 = solve(Eq((s1 / 2) ** 2 + s1 ** 2, r ** 2), s1)[0] ** 2
    a2 = solve(Eq(s2 ** 2 + s2 ** 2, (2 * r) ** 2), s2)[0] ** 2
    return simplify(a1 / a2)
q("C18-A-029", T, "Square in a semicircle versus square in a circle", "Medium",
  "Conceptual/application",
  r"Square $S_1$ is drawn inside a semicircle of radius $r$ with one side on the diameter and its other two vertices on the arc. Square $S_2$ is drawn inside a full circle of radius $r$ with all four vertices on the circle. What is the ratio of the area of $S_1$ to the area of $S_2$?",
  "MCQ",
  r"For $S_1$ with side $a$, the centre of the semicircle is the midpoint of the base, so $\left(\frac{a}{2}\right)^2 + a^2 = r^2$ and $a^2 = \frac{4r^2}{5}$. For $S_2$ the diagonal is $2r$, so its area is $2r^2$. Ratio $= \frac{4r^2}{5} : 2r^2 = 2 : 5$.",
  "Assuming the semicircle square is half the circle square, or comparing with $r^2$.",
  "C18A-square-in-semicircle", "Locating the semicircle's centre at the midpoint of the base is the key step.",
  correct=r"$2 : 5$",
  distractors=[(r"$1 : 2$", "Assumes halving the circle halves the area of the largest square."),
               (r"$4 : 5$", r"Compares $\frac{4r^2}{5}$ with $r^2$ rather than $2r^2$."),
               (r"$1 : 4$", "Assumes the semicircle square has half the side of the circle square.")],
  check=_c029, values=[Rational(2, 5), Rational(1, 2), Rational(4, 5), Rational(1, 4)])

# ---------------------------------------------------------------- 030
def _c030():
    results = set()
    for hx, hy, vx, vy in ((0, 4, 7, 0), (0, 2, 3, 0), (0, 5, 8, 0)):
        horiz = {(i, j) for i in range(hx, hx + 12) for j in range(hy, hy + 3)}     # 12 m by 3 m
        vert = {(i, j) for i in range(vx, vx + 3) for j in range(vy, vy + 10)}      # 3 m by 10 m
        assert hx < vx and vx + 3 < hx + 12 and vy < hy and hy + 3 < vy + 10       # each crosses the other fully
        results.add(_cell_perim(horiz | vert))
    assert len(results) == 1
    return results.pop()
q("C18-A-030", T, "Perimeter of the region covered by two crossing rectangular mats", "Medium",
  "Conceptual/application",
  r"Two rectangular mats, one $12$ m by $3$ m and the other $10$ m by $3$ m, lie flat on a floor and cross each other at right angles: each mat passes right across the other, so that both ends of each mat stick out beyond the other mat. What is the perimeter of the region of the floor covered by the mats?",
  "MCQ",
  r"The two perimeters add to $2(12 + 3) + 2(10 + 3) = 56$ m. Where the mats cross, each mat has two $3$ m pieces of its boundary lying inside the other mat, and these $4 \times 3 = 12$ m are not on the outline. The perimeter is $56 - 12 = 44$ m, wherever the crossing is.",
  "Adding the two perimeters, or removing the hidden edges of only one mat or too many.",
  "C18A-overlapping-mats", "Needs the hidden-edge accounting, independent of where the mats cross.",
  correct=r"$44$ m",
  distractors=[(r"$56$ m", "Adds the two perimeters without removing the edges hidden under the crossing."),
               (r"$50$ m", r"Removes only the two $3$ m edges of one mat that lie inside the other."),
               (r"$32$ m", r"Removes the whole $12$ m perimeter of the crossing square twice: $56 - 24$.")],
  check=_c030, values=[44, 56, 50, 32])

# ---------------------------------------------------------------- 031
def _c031():
    a, b, total = 45, 32, 0
    while a > 0 and b > 0:
        s = min(a, b)
        total += 4 * s
        if a >= b:
            a -= s
        else:
            b -= s
    return total
q("C18-A-031", T, "Total perimeter of the squares cut greedily from a rectangular board", "Medium",
  "Multi-step word problem",
  r"A carpenter has a rectangular board $45$ cm by $32$ cm. He cuts off the largest possible square piece, then cuts the largest possible square piece from the rectangle that is left, and continues in this way until the piece that is left is itself a square, which he keeps as his last piece. What is the sum of the perimeters of all the square pieces, in centimetres?",
  "TITA",
  r"$45 \times 32$: one $32$ square leaves $13 \times 32$. Then two $13$ squares leave $13 \times 6$; two $6$ squares leave $1 \times 6$; and that strip gives six $1$ cm squares, the last being the leftover square. The sides total $32 + 2(13) + 2(6) + 6(1) = 76$ cm, so the perimeters total $4 \times 76 = 304$ cm.",
  "Losing the final leftover square, or taking one square of each size.",
  "C18A-largest-square-cuts", "A four-stage cutting process with a count at each stage.",
  tita_answer=304, check=_c031, values=[304],
  tita_traps=[(300, r"Misses the final leftover $1$ cm square: $4 \times 75$."),
              (208, r"Takes one square of each size: $4(32 + 13 + 6 + 1)$.")])

# ---------------------------------------------------------------- 032
def _c032():
    depth, rise, n = 30, 15, 10
    # step k (k = 1 .. n, counted from the front) has its top at height k * rise over a width of one step depth
    return sum(depth * rise * k for k in range(1, n + 1))
f = Fig()
_st = [(0, 0), (300, 0), (300, 150)]
for k in range(10, 0, -1):
    _st.append((30 * (k - 1), 15 * k)); _st.append((30 * (k - 1), 15 * (k - 1)))
f.poly(*_st[:-1])
f.label_seg((270, 150), (300, 150), "30 cm"); f.text((-24, 7.5), "15 cm"); _ghost(f, -48, 8)
alt = "Side view of a staircase of 10 equal steps, each 30 cm deep and 15 cm high, resting on the floor against a vertical back wall."
q("C18-A-032", T, "Area of the side face of a staircase", "Medium",
  "Multi-step word problem",
  r"A solid concrete staircase has $10$ equal steps, each $30$ cm deep (front to back) and $15$ cm high. The staircase stands on a level floor, its back is a vertical wall face, and each step is filled solid down to the floor. What is the area of one side face of the staircase, the stepped region seen from the side?",
  "MCQ",
  r"Seen from the side, the face is $10$ vertical columns, each $30$ cm wide, of heights $15, 30, \ldots, 150$ cm. Area $= 30 \times 15 \times (1 + 2 + \cdots + 10) = 450 \times 55 = 24{,}750$ cm$^2$.",
  "Treating the stepped face as a triangle or a rectangle, or summing one step too few.",
  "C18A-staircase-profile", "Recognising an arithmetic series of column areas.",
  correct=r"$24{,}750$ cm$^2$",
  distractors=[(r"$22{,}500$ cm$^2$", r"Treats the face as a triangle, $\frac{1}{2} \times 300 \times 150$."),
               (r"$20{,}250$ cm$^2$", r"Sums $1 + 2 + \cdots + 9$ only: $450 \times 45$."),
               (r"$45{,}000$ cm$^2$", r"Treats the face as a full rectangle, $300 \times 150$.")],
  check=_c032, values=[24750, 22500, 20250, 45000],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 033
def _c033():
    poly = [(0, 0), (40, 0), (40, 25), (25, 25), (25, 19), (15, 19), (15, 25), (0, 25)]
    return sum(abs(poly[i][0] - poly[(i + 1) % 8][0]) + abs(poly[i][1] - poly[(i + 1) % 8][1]) for i in range(8))
q("C18-A-033", T, "Perimeter after a rectangular notch is cut from a sheet", "Medium",
  "Conceptual/application",
  r"From a rectangular metal sheet $40$ cm long and $25$ cm wide, a rectangular piece $10$ cm wide and $6$ cm deep is cut out from the middle of one of the $40$ cm edges. What is the perimeter of the remaining sheet?",
  "MCQ",
  r"The original perimeter is $2(40 + 25) = 130$ cm. Cutting the notch removes $10$ cm of edge and adds the notch's three inner edges, $6 + 10 + 6 = 22$ cm. New perimeter $= 130 - 10 + 22 = 142$ cm, that is, the original plus twice the depth.",
  "Assuming the perimeter does not change, or not removing the cut-away edge.",
  "C18A-rectilinear-perimeter", "Accounting correctly for removed and added edges.",
  correct=r"$142$ cm",
  distractors=[(r"$130$ cm", "Assumes the perimeter is unchanged, as for a corner cut."),
               (r"$152$ cm", r"Adds the notch edges $22$ cm without removing the $10$ cm cut away."),
               (r"$120$ cm", r"Removes the $10$ cm cut away but does not add the notch edges.")],
  check=_c033, values=[142, 130, 152, 120], cognitive="Understanding")

# ---------------------------------------------------------------- 034
def _c034():
    w = 2
    # lawn occupies x in [0, 30), y in [0, 20); the wall lies along y = 20 (one 30 m side)
    path = sum(1 for i in range(-w, 30 + w) for j in range(-w, 20) if not (0 <= i < 30 and 0 <= j < 20))
    return path * 50
q("C18-A-034", T, "Cost of paving a path along three sides of a lawn beside a wall", "Medium",
  "Multi-step word problem",
  r"A rectangular lawn measures $30$ m by $20$ m. One of its $30$ m sides runs along a wall. A path $2$ m wide is laid outside the lawn along its other three sides (the two $20$ m sides and the remaining $30$ m side), running right up to the wall. Paving costs Rs. $50$ per m$^2$. What is the cost of paving the path?",
  "MCQ",
  r"Lawn and path together make a rectangle $(30 + 4)$ m by $(20 + 2)$ m, since the path adds $2$ m at both ends of the $30$ m length but only on one side of the $20$ m breadth. Path area $= 34 \times 22 - 600 = 148$ m$^2$, and the cost is $148 \times 50 = $ Rs. $7{,}400$.",
  "Adding the path on all four sides, or leaving out its two corner squares.",
  "C18A-path-around-rectangle", "Three-sided path: the width is added twice to one dimension and once to the other.",
  correct=r"Rs. $7{,}400$",
  distractors=[(r"Rs. $10{,}800$", r"Puts the path on all four sides: $34 \times 24 - 600 = 216$ m$^2$."),
               (r"Rs. $7{,}000$", r"Adds three strips $2 \times 20 + 2 \times 20 + 2 \times 30 = 140$ m$^2$, leaving out the two corner squares."),
               (r"Rs. $8{,}400$", r"Puts the path along both $30$ m sides and one $20$ m side: $32 \times 24 - 600 = 168$ m$^2$.")],
  check=_c034, values=[7400, 10800, 7000, 8400])

# ============================================================ DIFFICULT (11)

# ---------------------------------------------------------------- 035
def _c035():
    L, B, pa, la = symbols('L B pa la', positive=True)
    ar = solve([Eq(25 * pa + 5 * la, 11280), Eq(5 * pa + 25 * la, 24720)], [pa, la], dict=True)[0]
    path, lawn = ar[pa], ar[la]
    sols = solve([Eq((L - 4) * (B - 4), lawn), Eq(L * B - (L - 4) * (B - 4), path)], [L, B], dict=True)
    lengths = {max(s_[L], s_[B]) for s_ in sols if s_[L] > 4 and s_[B] > 4}
    assert len(lengths) == 1
    return lengths.pop()
q("C18-A-035", T, "Length of a field from the costs of an inner path and the lawn", "Difficult",
  "Inverse/parameter",
  r"A rectangular field has a path $2$ m wide running along the inside of all four of its sides, and the rest of the field is lawn. Gravelling the path at Rs. $25$ per m$^2$ and turfing the lawn at Rs. $5$ per m$^2$ together cost Rs. $11{,}280$. Had the two rates been interchanged, the total cost would have been Rs. $24{,}720$. What is the length (the longer side) of the field?",
  "MCQ",
  r"Let the path and lawn areas be $p$ and $l$ m$^2$: $25p + 5l = 11{,}280$ and $5p + 25l = 24{,}720$. Adding, $30(p + l) = 36{,}000$, so $p + l = 1{,}200$; subtracting, $20(l - p) = 13{,}440$, so $l - p = 672$. Hence $l = 936$, $p = 264$ and $LB = 1{,}200$. The path is $LB - (L - 4)(B - 4) = 4(L + B) - 16 = 264$, so $L + B = 70$. Then $L$ and $B$ are the roots of $t^2 - 70t + 1200 = 0$, that is $40$ and $30$. The length is $40$ m.",
  "Mixing up the field and the lawn, or reporting the breadth.",
  "C18A-path-cost-dimensions", "Four stages: a linear system for the two areas from the combined costs, the area of the field, the corner correction in the path area, then a sum and product of the sides.",
  correct=r"$40$ m",
  distractors=[(r"$30$ m", "Reports the breadth of the field."),
               (r"$36$ m", r"Reports the length of the lawn, $40 - 4$."),
               (r"$26$ m", r"Reports the breadth of the lawn, $30 - 4$.")],
  check=_c035, values=[40, 30, 36, 26], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 036
def _c036():
    best = None
    for m in range(5, 400):
        for n in range(m, 400):
            dark = m * n - (m - 4) * (n - 4)
            if dark == (m - 4) * (n - 4):
                best = m * n if best is None else min(best, m * n)
    return best
q("C18-A-036", T, "Least floor size when a two-tile border has as many tiles as the interior", "Difficult",
  "Casework/optimisation",
  r"A rectangular floor is covered exactly by identical square tiles arranged in rows and columns, with more than $4$ tiles along each side of the floor. The tiles forming a border two tiles wide along all four edges are dark, and all the other tiles are light. The number of dark tiles equals the number of light tiles. What is the least possible total number of tiles on the floor?",
  "TITA",
  r"With $m \times n$ tiles, the light tiles form an $(m - 4) \times (n - 4)$ block, which must be half of all the tiles: $2(m - 4)(n - 4) = mn$. This rearranges to $mn - 8m - 8n + 32 = 0$, that is $(m - 8)(n - 8) = 32$. With $m, n > 4$ both factors must be positive (negative factors would force a side of at most $4$), so $(m, n) = (9, 40), (10, 24), (12, 16)$, with $360$, $240$ and $192$ tiles. The least is $192$.",
  "Using a border one tile wide, or stopping at the first factor pair found.",
  "C18A-border-tiles", "Turning the equal-count condition into a factorable product and checking every case.",
  tita_answer=192, check=_c036, values=[192], cognitive="Analysis", exams=CX,
  tita_traps=[(48, r"Uses a border one tile wide: $(m - 4)(n - 4) = 8$ gives $6 \times 8$."),
              (360, r"Stops at the first factor pair, $1 \times 32$, giving $9 \times 40$."),
              (240, r"Takes the pair $2 \times 16$, giving $10 \times 24$.")])

# ---------------------------------------------------------------- 037
def _c037():
    x = symbols('x', real=True)
    s = 6
    # segment cut from a circle of radius s by a chord of length s (distance from centre s*sqrt(3)/2)
    dch = s * sqrt(3) / 2
    seg = 2 * integrate(sqrt(s ** 2 - x ** 2) - dch, (x, 0, Rational(s, 2)))
    tri = sqrt(3) / 4 * s ** 2
    return simplify(tri + 3 * seg)
f = Fig()
h3 = 3 * math.sqrt(3)
f.shade(_arc((3, h3), 6, 240, 300) + _arc((0, 0), 6, 0, 60) + _arc((6, 0), 6, 120, 180))
f.pt("P", 0, 0); f.pt("Q", 6, 0); f.pt("R", 3, h3)
f.poly((0, 0), (6, 0), (3, h3), dashed=True)
f.arc((3, h3), 6, 240, 300); f.arc((0, 0), 6, 0, 60); f.arc((6, 0), 6, 120, 180)
f.text((3, 0.9), "6 cm")
alt = "Equilateral triangle PQR of side 6 cm, shown dashed, with three circular arcs each centred at one vertex joining the other two; the curved region bounded by the arcs is shaded."
q("C18-A-037", T, "Area of the curved triangle formed by three arcs on an equilateral triangle", "Difficult",
  "Multi-step word problem",
  r"$PQR$ is an equilateral triangle of side $6$ cm. Three circular arcs are drawn: arc $QR$ with centre $P$, arc $RP$ with centre $Q$, and arc $PQ$ with centre $R$, each of radius $6$ cm and each bulging away from the triangle. What is the area of the region bounded by the three arcs?",
  "MCQ",
  r"The region is the triangle plus three circular segments. Each segment is a $60^\circ$ sector minus the triangle: $6\pi - 9\sqrt{3}$. Area $= 9\sqrt{3} + 3(6\pi - 9\sqrt{3}) = (18\pi - 18\sqrt{3})$ cm$^2$.",
  "Adding whole sectors instead of segments, or subtracting the triangle the wrong number of times.",
  "C18A-curved-triangle-arcs", "Needs triangle plus three segments; easy to over- or under-count the triangle.",
  correct=r"$(18\pi - 18\sqrt{3})$ cm$^2$",
  distractors=[(r"$(18\pi - 9\sqrt{3})$ cm$^2$", r"Adds the three $60^\circ$ sectors and subtracts the triangle only once."),
               (r"$(18\pi - 27\sqrt{3})$ cm$^2$", r"Adds the three sectors and subtracts the triangle three times."),
               (r"$(18\pi + 9\sqrt{3})$ cm$^2$", r"Adds the three whole sectors to the triangle.")],
  check=_c037, values=[18 * pi - 18 * sqrt(3), 18 * pi - 9 * sqrt(3), 18 * pi - 27 * sqrt(3), 18 * pi + 9 * sqrt(3)],
  cognitive="Analysis", exams=CX, figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 038
def _c038():
    big = [(-8.0, -8.0), (8.0, -8.0), (8.0, 8.0), (-8.0, 8.0)]
    seen = set()
    for deg in (0, 10, 25, 37, 45, 63, 80):
        t = math.radians(deg)
        u, v = (math.cos(t), math.sin(t)), (-math.sin(t), math.cos(t))
        small = [(0.0, 0.0), (12 * u[0], 12 * u[1]), (12 * (u[0] + v[0]), 12 * (u[1] + v[1])), (12 * v[0], 12 * v[1])]
        overlap = _area(_clip(small, big))
        seen.add(round(256 + 144 - overlap, 9))
    assert len(seen) == 1
    return nsimplify(seen.pop())
f = Fig()
_t38 = math.radians(25)
_u = (12 * math.cos(_t38), 12 * math.sin(_t38)); _v = (-12 * math.sin(_t38), 12 * math.cos(_t38))
f.poly((-8, -8), (8, -8), (8, 8), (-8, 8))
f.poly((0, 0), _u, (_u[0] + _v[0], _u[1] + _v[1]), _v)
f.pt("O", 0, 0, offset=(-0.6, -0.8))
f.label_seg((-8, -8), (8, -8), "16 cm", side=-1); f.label_seg((0, 0), _u, "12 cm", side=-1)
alt = "A square card of side 16 cm with centre O; a square card of side 12 cm has one corner at O and is turned at an angle so that it sticks out beyond two sides of the larger card."
q("C18-A-038", T, "Area covered by two square cards when a corner of one is at the centre of the other", "Difficult",
  "Conceptual/application",
  r"A square card of side $12$ cm is laid on a square card of side $16$ cm so that one corner of the smaller card is exactly at the centre $O$ of the larger card. The smaller card is then turned about $O$ to some position and left there, flat. What is the total area of the table covered by the two cards together?",
  "MCQ",
  r"The two sides of the smaller card from $O$ are perpendicular and each is longer than $8\sqrt{2} \approx 11.3$ cm, the farthest the larger card's edge is from $O$, so they always cross its boundary. So the overlap is the part of the larger card between two perpendicular rays from $O$. Compared with the quarter of the larger card between the lines from $O$ to two adjacent corners, turning the rays adds one triangle and removes a congruent one (they match under a quarter turn about $O$), so the overlap is always one quarter of the larger card, $\frac{256}{4} = 64$ cm$^2$, whatever the turn. Covered area $= 256 + 144 - 64 = 336$ cm$^2$.",
  "Taking the overlap as a quarter of the smaller card, or not removing it exactly once.",
  "C18A-overlapping-squares-centre", "Needs the rotation-invariance argument for the overlap; the turn is not given.",
  correct=r"$336$ cm$^2$",
  distractors=[(r"$400$ cm$^2$", "Adds the two card areas without removing the overlap."),
               (r"$364$ cm$^2$", r"Takes the overlap as a quarter of the smaller card, $36$ cm$^2$."),
               (r"$272$ cm$^2$", r"Removes the $64$ cm$^2$ overlap from both cards: $400 - 128$.")],
  check=_c038, values=[336, 400, 364, 272], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 039
def _c039():
    t = symbols('t', real=True)
    R = 28
    # polar: semicircle on OP is r <= R cos t, on OQ is r <= R sin t; outside both up to r = R
    a1 = integrate(Rational(1, 2) * (R ** 2 - (R * cos(t)) ** 2), (t, 0, pi / 4))      # max is cos on [0, pi/4]
    a2 = integrate(Rational(1, 2) * (R ** 2 - (R * sin(t)) ** 2), (t, pi / 4, pi / 2))
    return simplify((a1 + a2).subs(pi, P7))
f = Fig()
f.shade(_arc((0, 0), 28, 0, 90) + _arc((0, 14), 14, 90, 0) + _arc((14, 0), 14, 90, 0))
f.pt("O", 0, 0); f.pt("P", 28, 0); f.pt("Q", 0, 28)
f.seg((0, 0), (28, 0)); f.seg((0, 0), (0, 28)); f.arc((0, 0), 28, 0, 90)
f.arc((14, 0), 14, 0, 180); f.arc((0, 14), 14, -90, 90)
f.label_seg((0, 0), (28, 0), "28 cm")
alt = "Quarter circle OPQ of radius 28 cm with semicircles drawn inside on OP and OQ as diameters; the part of the quarter circle outside both semicircles is shaded."
q("C18-A-039", T, "Quadrant minus two semicircles on its radii", "Difficult",
  "Conceptual/application",
  r"$OPQ$ is a quarter circle with centre $O$ and radius $28$ cm, so that $\angle POQ = 90^\circ$. Semicircles are drawn inside it on $OP$ and $OQ$ as diameters. Taking $\pi = \frac{22}{7}$, what is the area, in cm$^2$, of the part of the quarter circle that lies outside both semicircles?",
  "TITA",
  r"The quarter circle has area $\frac{1}{4} \times \frac{22}{7} \times 784 = 616$, and the two semicircles each have area $\frac{1}{2} \times \frac{22}{7} \times 196 = 308$, total $616$. Since they overlap in a leaf, the uncovered part equals the leaf. The leaf is two segments of a radius-$14$ circle cut by a quarter-turn chord: $2\left(\frac{1}{4} \times \frac{22}{7} \times 196 - \frac{1}{2} \times 196\right) = 2(154 - 98) = 112$ cm$^2$.",
  "Subtracting both semicircles as if they did not overlap.",
  "C18A-inward-semicircles-leaves", "Insight that the uncovered region equals the overlap, then a two-segment leaf.",
  tita_answer=112, check=_c039, values=[112], cognitive="Analysis", exams=CX,
  tita_traps=[(0, r"Subtracts both semicircles from the quarter circle, $616 - 616$, ignoring their overlap."),
              (56, "Takes the leaf as a single segment.")],
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 040
def _c040():
    x = symbols('x', real=True)
    s = 6
    # quarter of the central region nearest P(0,0): binding constraint is distance to R(s,s) <= s
    x0 = s - s * sqrt(3) / 2
    ymin = s - sqrt(s ** 2 - (s - x) ** 2)
    quarter = integrate(Rational(s, 2) - ymin, (x, x0, Rational(s, 2)))
    return simplify(4 * quarter)
f = Fig()
r3 = 3 * math.sqrt(3)
central = (_arc((0, 0), 6, 60, 30) + _arc((0, 6), 6, -30, -60) + _arc((6, 6), 6, 240, 210) + _arc((6, 0), 6, 150, 120))
f.shade(central)
f.pt("P", 0, 0); f.pt("Q", 6, 0); f.pt("R", 6, 6); f.pt("S", 0, 6)
f.poly((0, 0), (6, 0), (6, 6), (0, 6))
f.arc((0, 0), 6, 0, 90); f.arc((6, 0), 6, 90, 180); f.arc((6, 6), 6, 180, 270); f.arc((0, 6), 6, 270, 360)
f.label_seg((0, 0), (6, 0), "6 cm")
alt = "Square PQRS of side 6 cm with four quarter circles of radius 6 cm centred at the vertices; the central region inside all four arcs is shaded."
q("C18-A-040", T, "Central region common to four quarter circles in a square", "Difficult",
  "Multi-step word problem",
  r"$PQRS$ is a square of side $6$ cm. With each vertex as centre, a quarter circle of radius $6$ cm is drawn inside the square, joining the two vertices adjacent to that centre. What is the area of the region at the centre of the square that lies inside all four quarter circles?",
  "MCQ",
  r"Take $P = (0, 0)$, $Q = (6, 0)$, $R = (6, 6)$, $S = (0, 6)$. The arcs centred at $P$ and $Q$ meet at $(3, 3\sqrt{3})$; by symmetry the region has corners $(3, 3\sqrt{3})$, $(3\sqrt{3}, 3)$, $(3, 6 - 3\sqrt{3})$, $(6 - 3\sqrt{3}, 3)$, which form a square with diagonal $6\sqrt{3} - 6$ and area $\frac{(6\sqrt{3} - 6)^2}{2} = 72 - 36\sqrt{3}$. Each side of this square cuts off a segment subtending $30^\circ$ at a vertex of $PQRS$ (for instance $(3, 3\sqrt{3})$ and $(3\sqrt{3}, 3)$ are at $60^\circ$ and $30^\circ$ from $P$): segment $= 3\pi - 9$. Total $= 72 - 36\sqrt{3} + 4(3\pi - 9) = (36 + 12\pi - 36\sqrt{3})$ cm$^2$.",
  "Omitting the segments, or using sectors or the wrong angle for them.",
  "C18A-four-quadrant-overlap", r"Needs coordinates of the corner points and four $30^\circ$ segments.",
  correct=r"$(36 + 12\pi - 36\sqrt{3})$ cm$^2$",
  distractors=[(r"$(72 - 36\sqrt{3})$ cm$^2$", "Finds the square joining the four corner points and leaves out the four curved segments."),
               (r"$(72 + 12\pi - 36\sqrt{3})$ cm$^2$", r"Adds four $30^\circ$ sectors to the inner square without subtracting their triangles."),
               (r"$(72 + 24\pi - 72\sqrt{3})$ cm$^2$", r"Uses $60^\circ$ segments, $6\pi - 9\sqrt{3}$ each.")],
  check=_c040, values=[36 + 12 * pi - 36 * sqrt(3), 72 - 36 * sqrt(3), 72 + 12 * pi - 36 * sqrt(3), 72 + 24 * pi - 72 * sqrt(3)],
  cognitive="Analysis", exams=CX, figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 041
def _c041():
    hits = []
    for k in range(2, 41):
        L, B = 3 * k, 2 * k
        n = 0
        for i in range(2 * L):             # half-metre cells; centres at (2i+1)/4 m, work in quarter metres
            for j in range(2 * B):
                cx_, cy_ = 2 * i + 1, 2 * j + 1
                border = cx_ < 12 or cx_ > 4 * L - 12 or cy_ < 12 or cy_ > 4 * B - 12
                road = abs(cx_ - 2 * L) < 6 or abs(cy_ - 2 * B) < 6
                if border or road:
                    n += 1
        if Rational(n, 4) == 819:
            hits.append(L)
    assert len(hits) == 1
    return hits[0]
q("C18-A-041", T, "Park dimensions from the area of a border path and crossroads", "Difficult",
  "Inverse/parameter",
  r"The length and breadth of a rectangular park are in the ratio $3 : 2$. Inside the park, a path $3$ m wide runs along all four boundaries. In addition, two roads, each $3$ m wide, run through the centre of the park, one parallel to the length and one parallel to the breadth, each joining the boundary path on opposite sides. The boundary path and the two roads together cover $819$ m$^2$. What is the length of the park, in metres?",
  "TITA",
  r"Let the park be $3k$ by $2k$. The boundary path covers $6k^2 - (3k - 6)(2k - 6) = 30k - 36$. Inside the path the roads run across a $(3k - 6)$ by $(2k - 6)$ rectangle and cover $3(3k - 6) + 3(2k - 6) - 9 = 15k - 45$. So $45k - 81 = 819$, $k = 20$, and the length is $3k = 60$ m.",
  "Double counting where the roads meet each other or the boundary path.",
  "C18A-border-path-and-crossroads", "Two overlap corrections inside a parameterised set-up.",
  tita_answer=60, check=_c041, values=[60], exams=CX,
  tita_traps=[(40, "Reports the breadth."),
              (54, r"Reports the inner length $3k - 6$.")])

# ---------------------------------------------------------------- 042
def _c042():
    seen = set()
    for ya, xb0, xb1 in ((18, 10, 40), (5, 50, 2), (30, 20, 21)):
        road_a = [(0.0, ya), (60.0, ya), (60.0, ya + 4.0), (0.0, ya + 4.0)]        # 4 m wide, along the length
        road_b = [(xb0, 0.0), (xb0 + 5.0, 0.0), (xb1 + 5.0, 40.0), (xb1, 40.0)]     # meets each long side in 5 m
        inter = _clip(road_b, road_a)
        seen.add(round(_area(road_a) + _area(road_b) - _area(inter), 9))
    assert len(seen) == 1
    return nsimplify(seen.pop())
f = Fig()
_rect(f, 0, 0, 60, 40)
f.shade([(0, 18), (60, 18), (60, 22), (0, 22)]); f.shade([(10, 0), (15, 0), (45, 40), (40, 40)])
f.seg((0, 18), (60, 18)); f.seg((0, 22), (60, 22)); f.seg((10, 0), (40, 40)); f.seg((15, 0), (45, 40))
f.label_seg((0, 40), (60, 40), "60 m"); f.text((-4, 30), "40 m"); _ghost(f, -7, 30)
f.text((12.5, -2.4), "5 m"); f.text((50, 24.2), "4 m wide")
alt = "A rectangular field 60 m by 40 m with a shaded road 4 m wide parallel to the length and a shaded oblique road whose parallel edges meet each 60 m side along a 5 m stretch; the roads cross."
q("C18-A-042", T, "Area of a straight road and an oblique road crossing a field", "Difficult",
  "Conceptual/application",
  r"A rectangular field is $60$ m long and $40$ m wide. A straight road $4$ m wide runs parallel to the length, right across the field. A second straight road runs obliquely from one $60$ m side of the field to the other: its two edges are parallel straight lines, and it meets each $60$ m side along a stretch of $5$ m. The two roads cross. What is the total area of the field covered by the roads?",
  "MCQ",
  r"The first road covers $60 \times 4 = 240$ m$^2$. The oblique road is a parallelogram with base $5$ m on a long side and height $40$ m (the width of the field), so it covers $200$ m$^2$ whatever its slant. Their crossing is also a parallelogram, with horizontal base $5$ m and height $4$ m, area $20$ m$^2$. Total $= 240 + 200 - 20 = 420$ m$^2$.",
  r"Treating the crossing as a $4 \times 4$ square, or believing the slant length is needed.",
  "C18A-crossroads-in-field", "Parallelogram areas twice, including a slanted crossing that is not a square.",
  correct=r"$420$ m$^2$",
  distractors=[(r"$440$ m$^2$", "Adds the two road areas without removing the crossing."),
               (r"$424$ m$^2$", r"Takes the crossing as a $4$ m by $4$ m square, as for perpendicular roads."),
               (r"$400$ m$^2$", r"Removes the $20$ m$^2$ crossing twice.")],
  check=_c042, values=[420, 440, 424, 400], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=alt), alt=alt, required=False))

# ---------------------------------------------------------------- 043
def _c043():
    l, b, s = symbols('l b s', positive=True)
    sol = solve([Eq(2 * (l + b), 4 * s), Eq(l * b, Rational(84, 100) * s ** 2), Eq(l - b, 24)], [l, b, s], dict=True)
    assert len(sol) == 1
    return sol[0][l] * sol[0][b]
q("C18-A-043", T, "Rectangle and square with equal perimeters: area from the difference of sides", "Difficult",
  "Inverse/parameter",
  r"A square plot and a rectangular plot have equal perimeters. The area of the rectangular plot is $84\%$ of the area of the square plot, and its length exceeds its breadth by $24$ m. What is the area of the rectangular plot?",
  "MCQ",
  r"Let the square have side $s$; equal perimeters let the rectangle's sides be $s + d$ and $s - d$. Then $s^2 - d^2 = 0.84s^2$, so $d^2 = 0.16s^2$ and $d = 0.4s$. The sides differ by $2d = 0.8s = 24$, so $s = 30$, the sides are $42$ m and $18$ m, and the area is $756$ m$^2$.",
  r"Forgetting the square root in $d^2 = 0.16s^2$, or taking the difference of sides as $d$ instead of $2d$.",
  "C18A-equal-perimeter-tradeoff", r"Needs the symmetric set-up $s \pm d$, a square root and the factor $2$ in the difference of sides.",
  correct=r"$756$ m$^2$",
  distractors=[(r"$900$ m$^2$", r"Reports the area of the square plot, $30^2$."),
               (r"$4{,}725$ m$^2$", r"Takes $d = 0.16s$ without the square root, so $0.32s = 24$, $s = 75$ and the area is $0.84 \times 5625$."),
               (r"$3{,}024$ m$^2$", r"Takes the difference of sides as $d = 0.4s = 24$, so $s = 60$ and the area is $0.84 \times 3600$.")],
  check=_c043, values=[756, 900, 4725, 3024], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 044
def _c044():
    best = None
    for x1 in range(1, 41):
        for y1 in range(1, 41):
            if x1 * y1 != 24 or 36 % y1 or 40 % x1:
                continue
            x2, y2 = 36 // y1, 40 // x1
            per = 2 * (x1 + x2 + y1 + y2)
            best = per if best is None else min(best, per)
    return best
q("C18-A-044", T, "Least perimeter of a field split into four plots with given areas and whole-number sides", "Difficult",
  "Casework/optimisation",
  r"A rectangular field is divided into four rectangular plots by one straight fence parallel to its length and one straight fence parallel to its breadth. The top-left, top-right and bottom-left plots have areas $24$ m$^2$, $36$ m$^2$ and $40$ m$^2$. Every plot has sides that are whole numbers of metres. What is the least possible perimeter of the field?",
  "MCQ",
  r"Let the columns have widths $x_1, x_2$ and the rows heights $y_1, y_2$ (top row first), so $x_1y_1 = 24$, $x_2y_1 = 36$, $x_1y_2 = 40$. Then $y_1$ divides $\gcd(24, 36) = 12$ and $x_1 = \frac{24}{y_1}$ must divide $40$. Only $y_1 = 3, 6, 12$ work, with $x_1 = 8, 4, 2$, $x_2 = 12, 6, 3$, $y_2 = 5, 10, 20$, giving perimeters $56$, $52$ and $74$ m. The least is $52$ m (a $10$ m by $16$ m field).",
  "Stopping at the first arrangement that works, or adding the perimeters of the plots.",
  "C18A-grid-of-plots", "Divisibility casework over the possible row heights, then a comparison.",
  correct=r"$52$ m",
  distractors=[(r"$56$ m", r"Stops at the first arrangement found, $y_1 = 3$: a $20$ m by $8$ m field."),
               (r"$74$ m", r"Takes $y_1 = 12$, the largest common divisor, giving a $5$ m by $32$ m field."),
               (r"$104$ m", r"Adds the perimeters of the four plots of the best arrangement: $20 + 24 + 28 + 32$.")],
  check=_c044, values=[52, 56, 74, 104], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 045
def _c045():
    for n in range(1, 60):
        cells, x = set(), 0
        for s in range(1, n + 1):
            cells |= {(x + i, j) for i in range(s) for j in range(s)}
            x += s
        if _cell_perim(cells) == 180:
            return len(cells)
q("C18-A-045", T, "Area of a row of squares of sides 1, 2, ..., n from its perimeter", "Difficult",
  "Inverse/parameter",
  r"Squares of sides $1$ cm, $2$ cm, $3$ cm, $\ldots$, $n$ cm are placed in a row in increasing order of size, with their bottom sides on one straight line and each square touching the next along part of a side. The outer boundary of the resulting figure has perimeter $180$ cm. What is the area of the figure, in cm$^2$?",
  "TITA",
  r"The bottom edge and the stepped top each have total horizontal length $1 + 2 + \cdots + n = \frac{n(n + 1)}{2}$; the vertical parts are the left side $1$, the right side $n$ and the rises, which total $n - 1$. So the perimeter is $n(n + 1) + 2n = n^2 + 3n = 180$, giving $n = 12$. The area is $1^2 + 2^2 + \cdots + 12^2 = \frac{12 \times 13 \times 25}{6} = 650$ cm$^2$.",
  "Adding the perimeters of the separate squares, or summing sides instead of their squares.",
  "C18A-rectilinear-perimeter", "Perimeter by projection, a quadratic for $n$, then a sum of squares.",
  tita_answer=650, check=_c045, values=[650], cognitive="Analysis", exams=CX,
  tita_traps=[(285, r"Takes the perimeter as the sum of the squares' perimeters, $4 \times \frac{n(n + 1)}{2} = 180$, so $n = 9$ and the area is $285$."),
              (78, r"Finds $n = 12$ but adds the sides, $1 + 2 + \cdots + 12$, instead of their squares.")])

