import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig

T = "Quadrilaterals"
CX = ("CAT", "XAT")
x, y, p, w, a, b, c, h, k = symbols('x y p w a b c h k', real=True)


# ---------------------------------------------------------------- helpers
def _area(*pts):
    """Absolute shoelace area with exact sympy arithmetic."""
    s = 0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        s += Rational(1) * x1 * y2 - Rational(1) * x2 * y1
    return Abs(s) / 2


def _meet(P1, P2, P3, P4):
    """Intersection of line P1P2 with line P3P4 (exact)."""
    t, u = symbols('t u')
    sol = solve([P1[0] + t * (P2[0] - P1[0]) - P3[0] - u * (P4[0] - P3[0]),
                 P1[1] + t * (P2[1] - P1[1]) - P3[1] - u * (P4[1] - P3[1])], [t, u], dict=True)[0]
    return (simplify(P1[0] + sol[t] * (P2[0] - P1[0])), simplify(P1[1] + sol[t] * (P2[1] - P1[1])))


def _mid(P1, P2):
    return ((P1[0] + P2[0]) / 2, (P1[1] + P2[1]) / 2)


def _dist(P1, P2):
    return sqrt((P1[0] - P2[0]) ** 2 + (P1[1] - P2[1]) ** 2)


def _angle_deg(A, V, B):
    ax, ay = float(A[0] - V[0]), float(A[1] - V[1])
    bx, by = float(B[0] - V[0]), float(B[1] - V[1])
    return math.degrees(math.atan2(abs(ax * by - ay * bx), ax * bx + ay * by))


def _fig(f, alt, required=False):
    return dict(svg=f.svg(alt=alt), alt=alt, required=required)


def _cs(deg):
    return math.cos(math.radians(deg)), math.sin(math.radians(deg))


# ================================================================ EASY
# ---------------------------------------------------------------- 001
def _c001():
    d1, d2 = 16, 30
    side = sqrt(Rational(d1, 2) ** 2 + Rational(d2, 2) ** 2)
    return 4 * side
q("C17-A-001", T, "Perimeter of a rhombus from its two diagonals", "Easy",
  "Single-step computation",
  r"A floor tile is in the shape of a rhombus whose diagonals measure $16$ cm and $30$ cm. What is the perimeter of the tile?",
  "MCQ",
  r"The diagonals of a rhombus bisect each other at right angles, so each side is the hypotenuse of a right triangle with legs $8$ cm and $15$ cm. The side is $\sqrt{64 + 225} = 17$ cm, and the perimeter is $4 \times 17 = 68$ cm.",
  "Using the full diagonals as the legs of the right triangle, or stopping at one side.",
  "C17A-rhombus-diagonals-side", "One right triangle from the half-diagonals, then multiply by $4$.",
  correct=r"$68$ cm",
  distractors=[(r"$17$ cm", r"Finds the side $\sqrt{8^2 + 15^2} = 17$ and reports it as the perimeter."),
               (r"$136$ cm", r"Uses the full diagonals as legs: $\sqrt{16^2 + 30^2} = 34$, then $4 \times 34 = 136$."),
               (r"$92$ cm", r"Takes the perimeter as twice the sum of the diagonals, $2(16 + 30) = 92$.")],
  check=_c001, values=[68, 17, 136, 92], cognitive="Application")


# ---------------------------------------------------------------- 002
def _c002():
    s1, s2, h1 = 24, 18, 12
    area = s1 * h1
    hh = symbols('hh', positive=True)
    return solve(Eq(s2 * hh, area), hh)[0]
q("C17-A-002", T, "Second height of a parallelogram from its sides and one height", "Easy",
  "Inverse/parameter",
  r"A parallelogram has sides of length $24$ cm and $18$ cm. The perpendicular distance between its two longer sides is $12$ cm. What is the perpendicular distance between its two shorter sides?",
  "MCQ",
  r"Area $=$ base $\times$ corresponding height. Taking the longer side as base, the area is $24 \times 12 = 288$ cm$^2$. Taking the shorter side as base, $18 \times h = 288$, so $h = 16$ cm.",
  "Pairing a height with the wrong side, which gives the heights in the wrong proportion.",
  "C17A-parallelogram-area-two-heights", "A single area equation written two ways.",
  correct=r"$16$ cm",
  distractors=[(r"$9$ cm", r"Pairs the height $12$ with the shorter side: area $18 \times 12 = 216$, then $216 \div 24 = 9$."),
               (r"$12$ cm", r"Assumes the distance between either pair of opposite sides is the same."),
               (r"$8$ cm", r"Uses half base times height, $\frac{1}{2} \times 24 \times 12 = 144$, then $144 \div 18 = 8$.")],
  check=_c002, values=[16, 9, 12, 8], cognitive="Application")


# ---------------------------------------------------------------- 003
def _c003():
    sol = solve([Eq(2 * (x + y), 68), Eq(x ** 2 + y ** 2, 26 ** 2)], [x, y], dict=True)
    s = [d for d in sol if d[x] > 0 and d[y] > 0][0]
    return s[x] * s[y]
q("C17-A-003", T, "Area of a rectangle from its perimeter and diagonal", "Easy",
  "Multi-step word problem",
  r"A rectangular garden has a perimeter of $68$ m, and a straight path joining two opposite corners is $26$ m long. What is the area of the garden?",
  "MCQ",
  r"Let the sides be $l$ and $b$. Then $l + b = 34$ and $l^2 + b^2 = 26^2 = 676$. Since $(l + b)^2 = l^2 + b^2 + 2lb$, we get $2lb = 1{,}156 - 676 = 480$, so the area $lb = 240$ m$^2$. (The sides are $24$ m and $10$ m.)",
  "Stopping at $2lb$, or treating the rectangle as a square and using half the square of the diagonal.",
  "C17A-sum-and-squares-identity", "Uses $(l+b)^2 = l^2 + b^2 + 2lb$ once.",
  correct=r"$240$ m$^2$",
  distractors=[(r"$480$ m$^2$", r"Stops at $2lb = 34^2 - 26^2 = 480$ and forgets to halve."),
               (r"$338$ m$^2$", r"Uses the square formula, area $= \frac{1}{2} \times 26^2 = 338$, as if the garden were a square."),
               (r"$120$ m$^2$", r"Halves twice, treating $480$ as $4lb$.")],
  check=_c003, values=[240, 480, 338, 120], cognitive="Application")


# ---------------------------------------------------------------- 004
def _c004():
    # general quadrilateral with perpendicular diagonals of lengths 14 and 20 (intersection placed off-centre)
    Pp, Rr = (Rational(-5), 0), (Rational(9), 0)
    Qq, Ss = (0, Rational(13)), (0, Rational(-7))
    M = [_mid(Pp, Qq), _mid(Qq, Rr), _mid(Rr, Ss), _mid(Ss, Pp)]
    return _area(*M)
q("C17-A-004", T, "Area of the midpoint quadrilateral when the diagonals are perpendicular", "Easy",
  "Conceptual/application",
  r"A plot of land is in the shape of a quadrilateral $PQRS$ whose diagonals $PR$ and $QS$ are perpendicular to each other, with $PR = 14$ m and $QS = 20$ m. The midpoints of the four sides are joined in order to mark out a flower bed. What is the area of the flower bed?",
  "MCQ",
  r"Each side of the midpoint quadrilateral is parallel to a diagonal and half as long, so the flower bed is a parallelogram with sides $7$ m and $10$ m. Because the diagonals are perpendicular, its sides are perpendicular, so it is a rectangle of area $7 \times 10 = 70$ m$^2$. (In general, the midpoint quadrilateral has half the area of the original, and $\frac{1}{2} \times \frac{1}{2} \times 14 \times 20 = 70$.)",
  "Reporting the area of the original plot, or using the full diagonals as the sides of the inner figure.",
  "C17A-midpoint-quadrilateral", "Needs the midpoint theorem applied to both diagonals.",
  correct=r"$70$ m$^2$",
  distractors=[(r"$140$ m$^2$", r"Reports the area of the whole plot, $\frac{1}{2} \times 14 \times 20 = 140$."),
               (r"$280$ m$^2$", r"Takes the sides of the inner rectangle as the full diagonals, $14 \times 20 = 280$."),
               (r"$35$ m$^2$", r"Halves the area of the plot twice, $\frac{140}{4} = 35$.")],
  check=_c004, values=[70, 140, 280, 35], cognitive="Understanding")


# ---------------------------------------------------------------- 005
def _c005():
    s = symbols('s', positive=True)
    side = solve(Eq(s ** 2, 288), s)[0]
    return simplify(side * sqrt(2))
q("C17-A-005", T, "Diagonal of a square from its area", "Easy",
  "Single-step computation",
  r"A square courtyard has an area of $288$ m$^2$. What is the length, in metres, of a diagonal of the courtyard?",
  "TITA",
  r"For a square, area $= \frac{1}{2}d^2$, where $d$ is a diagonal. So $d^2 = 2 \times 288 = 576$ and $d = 24$ m.",
  "Using area $= d^2$ or area $= 2d^2$, or computing the side instead of the diagonal.",
  "C17A-square-diagonal-area", "One formula, area of a square as half the square of its diagonal.",
  tita_answer=24, check=_c005, cognitive="Recall",
  tita_traps=[(12, r"Uses $d^2 = \frac{288}{2} = 144$, halving instead of doubling."),
              (17, r"Computes the side $\sqrt{288} \approx 16.97$ and rounds it, instead of the diagonal.")])


# ---------------------------------------------------------------- 006
f = Fig()
_b6 = 6.0
_S6 = (_b6 * _cs(70)[0], _b6 * _cs(70)[1])
_a6 = _S6[1] / math.tan(math.radians(30)) - _S6[0]
_P6 = (0.0, 0.0); _Q6 = (_a6, 0.0); _R6 = (_a6 + _S6[0], _S6[1])
P_ = f.pt("P", *_P6); Q_ = f.pt("Q", *_Q6); R_ = f.pt("R", *_R6); S_ = f.pt("S", *_S6)
f.poly(P_, Q_, R_, S_); f.seg(P_, R_)
f.angle_mark(_Q6, _P6, _R6, "30^\\circ", r=1.6)
f.angle_mark(_Q6, _P6, _S6, "", r=0.9)
f.text((1.25 * _cs(52)[0], 1.25 * _cs(52)[1]), "70^\\circ")
_alt6 = "Parallelogram PQRS with PQ along the bottom and the diagonal PR drawn. Angle SPQ is marked 70 degrees and angle RPQ is marked 30 degrees."


def _c006():
    # build the parallelogram from the givens for two different side lengths; the angle must not depend on them
    out = set()
    for bb in (4.0, 6.0, 9.0):
        Pp = (0.0, 0.0)
        Sp = (bb * math.cos(math.radians(70)), bb * math.sin(math.radians(70)))
        aa = Sp[1] / math.tan(math.radians(30)) - Sp[0]          # makes angle RPQ = 30
        Qp = (aa, 0.0); Rp = (aa + Sp[0], Sp[1])
        assert abs(_angle_deg(Qp, Pp, Rp) - 30) < 1e-9 and abs(_angle_deg(Qp, Pp, Sp) - 70) < 1e-9
        ang = _angle_deg(Pp, Rp, Qp)
        assert abs(ang - round(ang)) < 1e-9
        out.add(round(ang))
    assert len(out) == 1
    return Integer(out.pop())
q("C17-A-006", T, "Angle between a diagonal and a side of a parallelogram from the angles at one vertex", "Easy",
  "Conceptual/application",
  r"In a parallelogram $PQRS$, $\angle SPQ = 70^\circ$ and the diagonal $PR$ makes an angle of $30^\circ$ with the side $PQ$, that is, $\angle RPQ = 30^\circ$. What is $\angle PRQ$?",
  "MCQ",
  r"The diagonal splits $\angle SPQ$, so $\angle SPR = 70^\circ - 30^\circ = 40^\circ$. Since $PS \parallel QR$, the alternate angles $\angle PRQ$ and $\angle RPS$ are equal, so $\angle PRQ = 40^\circ$. (Check in triangle $PQR$: $\angle PQR = 180^\circ - 70^\circ = 110^\circ$ and $30^\circ + 110^\circ + 40^\circ = 180^\circ$.)",
  r"Using the wrong pair of parallel sides for the alternate angles, or assuming the diagonal of a parallelogram bisects the angle.",
  "C17A-parallelogram-angle-chasing", "One subtraction at $P$ and one pair of alternate angles.",
  correct=r"$40^\circ$",
  distractors=[(r"$30^\circ$", r"Uses $PQ \parallel SR$ instead of $PS \parallel QR$, which gives $\angle PRS = \angle RPQ = 30^\circ$, not $\angle PRQ$."),
               (r"$80^\circ$", r"Takes $\angle PQR$ equal to $\angle SPQ = 70^\circ$ instead of supplementary to it: $180 - 70 - 30 = 80$."),
               (r"$35^\circ$", r"Assumes the diagonal bisects $\angle SPQ$ as in a rhombus and takes $\angle PRQ = \frac{70}{2} = 35$.")],
  check=_c006, values=[40, 30, 80, 35], cognitive="Understanding",
  figure=_fig(f, _alt6))


# ---------------------------------------------------------------- 007
def _c007():
    big, small, leg = 22, 10, 10
    over = Rational(big - small, 2)
    hh = sqrt(leg ** 2 - over ** 2)
    return Rational(big + small, 2) * hh
q("C17-A-007", T, "Area of an isosceles trapezium from its sides", "Easy",
  "Multi-step word problem",
  r"The cross-section of a water channel is an isosceles trapezium. Its parallel sides are $22$ m (top) and $10$ m (bottom), and each sloping side is $10$ m long. What is the area of the cross-section, in m$^2$?",
  "TITA",
  r"Dropping perpendiculars from the ends of the bottom side, each overhang on the top side is $\frac{22 - 10}{2} = 6$ m. The depth is $\sqrt{10^2 - 6^2} = 8$ m. Area $= \frac{1}{2}(22 + 10) \times 8 = 128$ m$^2$.",
  r"Using the sloping side as the height, or forgetting the factor $\frac{1}{2}$.",
  "C17A-isosceles-trapezium-height", "One right triangle for the height, then the trapezium formula.",
  tita_answer=128, check=_c007, cognitive="Application",
  tita_traps=[(160, r"Uses the sloping side $10$ as the height: $16 \times 10$."),
              (256, r"Forgets the $\frac{1}{2}$: $(22 + 10) \times 8$.")])


# ---------------------------------------------------------------- 008
f = Fig()
_r3 = math.sqrt(3)
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 16, 0); R_ = f.pt("R", 21, 5 * _r3); S_ = f.pt("S", 5, 5 * _r3)
T_ = f.pt("T", 15, 5 * _r3, offset=(0, 1))
f.poly(P_, Q_, R_, S_); f.seg(P_, T_)
f.label_seg((0, 0), (16, 0), "16 cm"); f.label_seg((0, 0), (5, 5 * _r3), "10 cm")
_alt8 = "Parallelogram PQRS with PQ = 16 cm along the bottom and PS = 10 cm. The bisector of angle P is drawn from P and meets side RS at T."


def _c008():
    r3 = sqrt(3)
    Pp, Qp = (0, 0), (16, 0)
    ang = pi / 3                         # any angle works; the answer must not depend on it
    Sp = (10 * cos(ang), 10 * sin(ang)); Rp = (16 + Sp[0], Sp[1])
    bis = (cos(ang / 2), sin(ang / 2))
    Tp = _meet(Pp, bis, Sp, Rp)
    return simplify(_dist(Tp, Rp))
q("C17-A-008", T, "Angle bisector from a vertex of a parallelogram cuts off an isosceles triangle", "Easy",
  "Conceptual/application",
  r"In a parallelogram $PQRS$, $PQ = 16$ cm and $PS = 10$ cm. The bisector of $\angle SPQ$ meets the side $RS$ at $T$. What is the length of $TR$?",
  "MCQ",
  r"Since $PQ \parallel SR$, $\angle STP = \angle TPQ = \angle SPT$, so triangle $SPT$ is isosceles with $ST = SP = 10$ cm. Then $TR = SR - ST = 16 - 10 = 6$ cm.",
  "Assuming the bisector meets the opposite side at its midpoint, or reporting $ST$.",
  "C17A-parallelogram-bisector-segment", "One alternate-angle step gives an isosceles triangle.",
  correct=r"$6$ cm",
  distractors=[(r"$10$ cm", r"Reports $ST = SP = 10$ cm, the other part of $RS$."),
               (r"$8$ cm", r"Assumes the bisector meets $RS$ at its midpoint, $\frac{16}{2} = 8$."),
               (r"$5$ cm", r"Assumes $T$ cuts off half of $PS$ on $RS$, taking $TR = \frac{PS}{2} = \frac{10}{2} = 5$.")],
  check=_c008, values=[6, 10, 8, 5], cognitive="Understanding")


# ---------------------------------------------------------------- 009
def _c009():
    s, ang = 14, pi / 6
    # rhombus as two congruent triangles with sides s, s and included angle ang
    tri = Rational(1, 2) * s * s * sin(ang)
    return simplify(2 * tri)
q("C17-A-009", T, "Area of a rhombus from its side and an angle", "Easy",
  "Single-step computation",
  r"A rhombus-shaped signboard has each side $14$ cm long, and one of its angles is $30^\circ$. What is the area of the signboard, in cm$^2$?",
  "TITA",
  r"A rhombus is a parallelogram, so its area is $s^2 \sin\theta = 14^2 \times \sin 30^\circ = 196 \times \frac{1}{2} = 98$ cm$^2$. Equivalently, the height on a side is $14 \sin 30^\circ = 7$ cm and the area is $14 \times 7 = 98$ cm$^2$.",
  "Multiplying the two sides as if the rhombus were a square, or finding only one of the two triangles.",
  "C17A-rhombus-side-angle-area", "One formula, base times height for a rhombus.",
  tita_answer=98, check=_c009, cognitive="Application",
  tita_traps=[(196, r"Treats the rhombus as a square: $14 \times 14$."),
              (49, r"Finds the area of only one of the two triangles cut off by a diagonal.")])


# ---------------------------------------------------------------- 010
f = Fig()
S_ = f.pt("S", 0, 0); R_ = f.pt("R", 27, 0); Q_ = f.pt("Q", 23, 9); P_ = f.pt("P", 2, 9)
H_ = f.pt("H", 2, 0, offset=(0, -1))
f.poly(P_, Q_, R_, S_); f.seg(P_, H_, dashed=True); f.right_angle(P_, H_, R_)
f.label_seg((2, 9), (2, 0), "9 cm", side=-1)
_alt10 = "Trapezium PQRS with the shorter side PQ on top parallel to the longer side SR at the bottom. A dashed perpendicular PH from P to SR is marked 9 cm."


def _c010():
    lo, sh = symbols('lo sh', positive=True)
    sol = solve([Eq(Rational(1, 2) * (lo + sh) * 9, 216), Eq(lo - sh, 6)], [lo, sh], dict=True)[0]
    return sol[lo]
q("C17-A-010", T, "Longer parallel side of a trapezium from its area, height and the difference of the parallel sides", "Easy",
  "Inverse/parameter",
  r"A trapezium $PQRS$ has $PQ \parallel SR$, with $SR$ longer than $PQ$ by $6$ cm. The distance between $PQ$ and $SR$ is $9$ cm and the area of the trapezium is $216$ cm$^2$. What is the length of $SR$?",
  "MCQ",
  r"Area $= \frac{1}{2}(PQ + SR) \times 9 = 216$, so $PQ + SR = 48$. With $SR - PQ = 6$, $SR = \frac{48 + 6}{2} = 27$ cm (and $PQ = 21$ cm).",
  r"Forgetting the $\frac{1}{2}$ in the area formula, or reporting the mean of the parallel sides.",
  "C17A-trapezium-area-inverse", "One area equation and a sum-difference pair.",
  correct=r"$27$ cm",
  distractors=[(r"$21$ cm", r"Reports the shorter side $PQ = \frac{48 - 6}{2}$."),
               (r"$15$ cm", r"Forgets the $\frac{1}{2}$: $(PQ + SR) \times 9 = 216$ gives $PQ + SR = 24$, so $SR = \frac{24 + 6}{2} = 15$."),
               (r"$24$ cm", r"Stops at the mean of the parallel sides, $\frac{216}{9} = 24$.")],
  check=_c010, values=[27, 21, 15, 24], cognitive="Application",
  figure=_fig(f, _alt10))


# ================================================================ MEDIUM
# ---------------------------------------------------------------- 011
def _c011():
    side = Rational(116, 4)
    sol = solve([Eq(x + y, 82), Eq((x / 2) ** 2 + (y / 2) ** 2, side ** 2)], [x, y], dict=True)
    s = [d for d in sol if d[x] > 0 and d[y] > 0][0]
    return s[x] * s[y] / 2
q("C17-A-011", T, "Area of a rhombus from its perimeter and the sum of its diagonals", "Medium",
  "Multi-step word problem",
  r"A rhombus has a perimeter of $116$ cm, and the sum of the lengths of its two diagonals is $82$ cm. What is the area of the rhombus?",
  "MCQ",
  r"The side is $\frac{116}{4} = 29$ cm. If the diagonals are $p$ and $q$, then $\left(\frac{p}{2}\right)^2 + \left(\frac{q}{2}\right)^2 = 29^2$, so $p^2 + q^2 = 3{,}364$. With $p + q = 82$: $2pq = 82^2 - 3{,}364 = 6{,}724 - 3{,}364 = 3{,}360$, so $pq = 1{,}680$. Area $= \frac{1}{2}pq = 840$ cm$^2$. (The diagonals are $40$ and $42$ cm.)",
  r"Forgetting that the side relates to the half-diagonals, or forgetting the $\frac{1}{2}$ in the area formula.",
  "C17A-sum-and-squares-identity", "Combines the side and half-diagonal relation with the identity for $(p+q)^2$.",
  correct=r"$840$ cm$^2$",
  distractors=[(r"$1{,}680$ cm$^2$", r"Finds $pq = 1{,}680$ and takes it as the area, missing the $\frac{1}{2}$."),
               (r"$420$ cm$^2$", r"Finds the diagonals $40$ and $42$ cm but uses a half-diagonal for one of them: $\frac{1}{2} \times 40 \times 21 = 420$."),
               (r"$3{,}360$ cm$^2$", r"Stops at $2pq = 3{,}360$ and reports it as the area.")],
  check=_c011, values=[840, 1680, 420, 3360], cognitive="Application")


# ---------------------------------------------------------------- 012
def _c012():
    # build the parallelogram explicitly: sides 7 and 9, diagonal PR = 8
    th = symbols('th')
    # P=(0,0), Q=(9,0), S=(7cos th, 7 sin th); diagonal QS has length 8
    sols = solve(Eq((9 - 7 * cos(th)) ** 2 + (7 * sin(th)) ** 2, 64), th)
    t0 = [s for s in sols if s.is_real and 0 < float(s) < float(pi)][0]
    Sp = (7 * cos(t0), 7 * sin(t0)); Rp = (9 + Sp[0], Sp[1])
    return simplify(_dist((0, 0), Rp))
q("C17-A-012", T, "Second diagonal of a parallelogram from its sides and one diagonal", "Medium",
  "Inverse/parameter",
  r"A parallelogram has sides of length $7$ cm and $9$ cm, and one of its diagonals is $8$ cm long. What is the length, in cm, of the other diagonal?",
  "TITA",
  r"In any parallelogram the sum of the squares of the diagonals equals the sum of the squares of the four sides: $d_1^2 + d_2^2 = 2(a^2 + b^2)$. So $64 + d_2^2 = 2(49 + 81) = 260$, giving $d_2^2 = 196$ and $d_2 = 14$ cm.",
  "Assuming the diagonals are equal, or using $a^2 + b^2$ without the factor $2$.",
  "C17A-parallelogram-diagonal-law", "Needs the parallelogram law for diagonals.",
  tita_answer=14, check=_c012, cognitive="Application",
  tita_traps=[(8, "Assumes both diagonals are equal, as in a rectangle."),
              (7, r"Finds $d_2^2 = 196$ but reports half of $d_2$, the length from a vertex to the centre.")])


# ---------------------------------------------------------------- 013
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 15, 0); R_ = f.pt("R", 21, 12); S_ = f.pt("S", 6, 12)
T_ = f.pt("T", 15.0, 20 / 3.0, offset=(0, 1))
f.poly(P_, Q_, R_, S_)
for V in (P_, Q_, R_, S_):
    f.seg(T_, V)
f.text((10.0, 2.0), "50"); f.text((16.9, 5.6), "20")
_alt13 = "Parallelogram PQRS with a point T inside joined to all four vertices. Triangle TPQ is marked with area 50 and triangle TQR with area 20."


def _c013():
    Pp, Qp, Rp, Sp = (0, 0), (15, 0), (21, 12), (6, 12)      # area 180
    assert _area(Pp, Qp, Rp, Sp) == 180
    sol = solve([Eq(Rational(1, 2) * 15 * y, 50),
                 Eq(Rational(1, 2) * ((Qp[0] - x) * (Rp[1] - y) - (Rp[0] - x) * (Qp[1] - y)), 20)], [x, y], dict=True)[0]
    Tp = (sol[x], sol[y])
    assert _area(Tp, Pp, Qp) + _area(Tp, Qp, Rp) + _area(Tp, Rp, Sp) + _area(Tp, Sp, Pp) == 180   # T is inside
    return _area(Tp, Sp, Pp)
q("C17-A-013", T, "Areas of the four triangles from an interior point of a parallelogram", "Medium",
  "Conceptual/application",
  r"A point $T$ lies inside a parallelogram $PQRS$ of area $180$ cm$^2$, and $T$ is joined to all four vertices. The areas of triangles $TPQ$ and $TQR$ are $50$ cm$^2$ and $20$ cm$^2$ respectively. What is the area of triangle $TSP$?",
  "MCQ",
  r"Triangles $TPQ$ and $TRS$ stand on the opposite sides $PQ$ and $RS$, and their heights add up to the distance between those sides, so their areas add up to half the parallelogram, $90$ cm$^2$. The same holds for $TQR$ and $TSP$. Hence $TSP = 90 - 20 = 70$ cm$^2$.",
  "Pairing adjacent triangles instead of opposite ones, or assuming opposite triangles are equal.",
  "C17A-parallelogram-interior-point", "Needs the half-area property of opposite triangles from an interior point.",
  correct=r"$70$ cm$^2$",
  distractors=[(r"$40$ cm$^2$", r"Computes $90 - 50 = 40$, which is the area of $TRS$, the triangle opposite $TPQ$."),
               (r"$110$ cm$^2$", r"Subtracts both given areas from the whole, $180 - 50 - 20 = 110$, which is $TRS + TSP$ together."),
               (r"$20$ cm$^2$", r"Assumes opposite triangles $TQR$ and $TSP$ have equal areas.")],
  check=_c013, values=[70, 40, 110, 20], cognitive="Analysis",
  figure=_fig(f, _alt13))


# ---------------------------------------------------------------- 014
def _c014():
    l, bb = 40, 9
    Pp, Qp, Rp, Sp = (0, 0), (l, 0), (l, bb), (0, bb)
    M = [_mid(Pp, Qp), _mid(Qp, Rp), _mid(Rp, Sp), _mid(Sp, Pp)]
    per = sum(_dist(M[i], M[(i + 1) % 4]) for i in range(4))
    return simplify(per)
q("C17-A-014", T, "Perimeter of the rhombus formed by the midpoints of a rectangle", "Medium",
  "Multi-step word problem",
  r"A rectangular sheet of metal measures $40$ cm by $9$ cm. The midpoints of its four sides are joined in order and the sheet is cut along these four lines. What is the perimeter, in cm, of the piece in the middle?",
  "TITA",
  r"Each side of the middle piece joins the midpoints of two adjacent sides, so by the midpoint theorem it is half of a diagonal of the rectangle. The diagonal is $\sqrt{40^2 + 9^2} = \sqrt{1{,}681} = 41$ cm, so each side is $20.5$ cm and the perimeter is $4 \times 20.5 = 82$ cm (the sum of the two diagonals).",
  "Assuming the middle piece is the rectangle scaled by one half, so its perimeter is half the original.",
  "C17A-midpoint-quadrilateral", "Midpoint theorem plus a diagonal by Pythagoras.",
  tita_answer=82, check=_c014, cognitive="Application",
  tita_traps=[(49, r"Halves the perimeter of the rectangle, $\frac{1}{2} \times 98$, as if the middle piece were a scaled copy."),
              (41, r"Takes each side as a quarter of a diagonal, or reports a single diagonal.")])


# ---------------------------------------------------------------- 015
def _c015():
    bot, top, diag = 42, 22, 40
    # isosceles trapezium: bottom from (0,0) to (42,0); top from (o, hh) to (42-o, hh)
    o = Rational(bot - top, 2)
    hh = symbols('hh', positive=True)
    hv = solve(Eq((bot - o) ** 2 + hh ** 2, diag ** 2), hh)[0]
    return _area((0, 0), (bot, 0), (bot - o, hv), (o, hv))
q("C17-A-015", T, "Area of an isosceles trapezium from its parallel sides and diagonal", "Medium",
  "Multi-step word problem",
  r"A plot is shaped like an isosceles trapezium with parallel sides $42$ m and $22$ m. Each of its diagonals is $40$ m long. What is the area of the plot?",
  "MCQ",
  r"Drop a perpendicular from an end of the $22$ m side to the $42$ m side. Its foot is $\frac{42 - 22}{2} = 10$ m from the near corner, so it is $42 - 10 = 32$ m from the far corner. The diagonal is the hypotenuse over this $32$ m, so the height is $\sqrt{40^2 - 32^2} = 24$ m. Area $= \frac{1}{2}(42 + 22) \times 24 = 768$ m$^2$.",
  "Forgetting to average the parallel sides, or multiplying by the diagonal instead of the height.",
  "C17A-isosceles-trapezium-height", "Needs the horizontal projection of the diagonal, which is the mean of the parallel sides.",
  correct=r"$768$ m$^2$",
  distractors=[(r"$1{,}536$ m$^2$", r"Forgets the $\frac{1}{2}$: $(42 + 22) \times 24$."),
               (r"$1{,}008$ m$^2$", r"Multiplies the longer parallel side by the height, $42 \times 24$."),
               (r"$960$ m$^2$", r"Multiplies the diagonal by the height, $40 \times 24$.")],
  check=_c015, values=[768, 1536, 1008, 960], cognitive="Application")


# ---------------------------------------------------------------- 016
def _c016():
    top, bot = 10, 16
    # isosceles trapezium with perpendicular diagonals: place the diagonal intersection at the origin
    # diagonals along y = x and y = -x; the parallel sides are horizontal
    Pp, Qp = (-Rational(top, 2), Rational(top, 2)), (Rational(top, 2), Rational(top, 2))
    Rp, Sp = (Rational(bot, 2), -Rational(bot, 2)), (-Rational(bot, 2), -Rational(bot, 2))
    # verify the diagonals PR and QS are perpendicular and the trapezium is isosceles
    v1 = (Rp[0] - Pp[0], Rp[1] - Pp[1]); v2 = (Sp[0] - Qp[0], Sp[1] - Qp[1])
    assert v1[0] * v2[0] + v1[1] * v2[1] == 0 and _dist(Pp, Sp) == _dist(Qp, Rp)
    return _area(Pp, Qp, Rp, Sp)
q("C17-A-016", T, "Area of an isosceles trapezium whose diagonals are perpendicular", "Medium",
  "Conceptual/application",
  r"The diagonals of an isosceles trapezium are perpendicular to each other. Its parallel sides are $10$ cm and $16$ cm long. What is the area of the trapezium?",
  "MCQ",
  r"Let the diagonals meet at $O$. By symmetry the triangles on the parallel sides are isosceles right triangles, so the distance from $O$ to each parallel side is half that side: $5$ cm and $8$ cm. The height is $5 + 8 = 13$ cm, and the area is $\frac{1}{2}(10 + 16) \times 13 = 169$ cm$^2$.",
  r"Using only one of the two parts of the height, or forgetting the $\frac{1}{2}$.",
  "C17A-trapezium-perpendicular-diagonals", "Needs the insight that each part of the height equals half a parallel side.",
  correct=r"$169$ cm$^2$",
  distractors=[(r"$338$ cm$^2$", r"Forgets the $\frac{1}{2}$: $(10 + 16) \times 13$."),
               (r"$104$ cm$^2$", r"Takes the height as $8$ cm only, the part below $O$: $13 \times 8$."),
               (r"$208$ cm$^2$", r"Multiplies the longer parallel side by the height, $16 \times 13$.")],
  check=_c016, values=[169, 338, 104, 208], cognitive="Analysis")


# ---------------------------------------------------------------- 017
f = Fig()
_s7 = 7 * math.sin(math.radians(60)); _c7 = 3.5
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 20, 0); R_ = f.pt("R", 20 + _c7, _s7); S_ = f.pt("S", _c7, _s7)
X_ = f.pt("X", _c7 + 7, _s7, offset=(0, 1)); Y_ = f.pt("Y", 16.5, _s7, offset=(0, 1))
f.poly(P_, Q_, R_, S_); f.seg(P_, X_); f.seg(Q_, Y_)
f.label_seg((0, 0), (20, 0), "20 cm"); f.label_seg((0, 0), (_c7, _s7), "7 cm")
_alt17 = "Parallelogram PQRS with PQ = 20 cm along the bottom and PS = 7 cm. The bisector of angle P meets RS at X and the bisector of angle Q meets RS at Y."


def _c017():
    ang = pi / 3
    Pp, Qp = (0, 0), (20, 0)
    Sp = (7 * cos(ang), 7 * sin(ang)); Rp = (20 + Sp[0], Sp[1])
    Xp = _meet(Pp, (cos(ang / 2), sin(ang / 2)), Sp, Rp)
    qa = pi - ang                                    # interior angle at Q
    dq = (cos(pi - qa / 2), sin(pi - qa / 2))
    Yp = _meet(Qp, (20 + dq[0], dq[1]), Sp, Rp)
    return simplify(_dist(Xp, Yp))
q("C17-A-017", T, "Gap between the points where two adjacent angle bisectors meet the opposite side", "Medium",
  "Multi-step word problem",
  r"In a parallelogram $PQRS$, $PQ = 20$ cm and $PS = 7$ cm. The bisector of $\angle SPQ$ meets $RS$ at $X$, and the bisector of $\angle PQR$ meets $RS$ at $Y$. What is the length of $XY$?",
  "MCQ",
  r"As $PQ \parallel SR$, the bisector from $P$ makes triangle $SPX$ isosceles, so $SX = SP = 7$ cm. Similarly the bisector from $Q$ makes triangle $RQY$ isosceles, so $RY = RQ = 7$ cm. Since $7 + 7 < 20$, the points are in the order $S, X, Y, R$ and $XY = 20 - 7 - 7 = 6$ cm.",
  "Subtracting only one of the two isosceles pieces from $RS$.",
  "C17A-parallelogram-bisector-segment", "The isosceles-triangle step is needed twice and the order of points must be checked.",
  correct=r"$6$ cm",
  distractors=[(r"$13$ cm", r"Subtracts only one isosceles piece from $RS$: $20 - 7$."),
               (r"$14$ cm", r"Reports $SX + RY = 7 + 7$ instead of what is left of $RS$."),
               (r"$7$ cm", r"Reports $SX = SP = 7$ cm as the gap between the two points.")],
  check=_c017, values=[6, 13, 14, 7], cognitive="Application",
  figure=_fig(f, _alt17))


# ---------------------------------------------------------------- 018
def _c018():
    # realise the configuration for several heights of T; the answer must not depend on the rectangle
    out = set()
    for yy in (Rational(2), Rational(3), Rational(4)):
        xx = sqrt(10 ** 2 - yy ** 2)                     # TP = 10 with P = (0, 0)
        aa = xx + sqrt(5 ** 2 - yy ** 2)                 # TQ = 5 with Q = (aa, 0)
        bb = yy + sqrt(11 ** 2 - (aa - xx) ** 2)         # TR = 11 with R = (aa, bb)
        Pp, Qp, Rp, Sp, Tp = (0, 0), (aa, 0), (aa, bb), (0, bb), (xx, yy)
        assert simplify(_dist(Tp, Pp) - 10) == 0 and simplify(_dist(Tp, Qp) - 5) == 0 and simplify(_dist(Tp, Rp) - 11) == 0
        assert 0 < xx < aa and 0 < yy < bb
        out.add(simplify(_dist(Tp, Sp)))
    assert len(out) == 1
    return out.pop()
q("C17-A-018", T, "Distance from an interior point to the fourth corner of a rectangle", "Medium",
  "Conceptual/application",
  r"A lamp post $T$ stands inside a rectangular park $PQRS$ (corners in that order). The distances of $T$ from the corners $P$, $Q$ and $R$ are $10$ m, $5$ m and $11$ m respectively. What is the distance of $T$ from the corner $S$, in metres?",
  "TITA",
  r"Drop perpendiculars from $T$ to the four sides; they cut $PQ$ into parts $x$ and $x'$ and $PS$ into parts $y$ and $y'$. Then $TP^2 = x^2 + y^2$, $TQ^2 = x'^2 + y^2$, $TR^2 = x'^2 + y'^2$ and $TS^2 = x^2 + y'^2$, so $TP^2 + TR^2 = TQ^2 + TS^2$ (opposite corners pair up). Hence $TS^2 = 100 + 121 - 25 = 196$ and $TS = 14$ m.",
  "Pairing adjacent corners instead of opposite corners, or applying the relation to the distances instead of their squares.",
  "C17A-rectangle-interior-point-distances", "Needs the opposite-corner relation, which comes from splitting each distance into two perpendicular parts.",
  tita_answer=14, check=_c018, cognitive="Understanding",
  tita_traps=[(2, r"Pairs adjacent corners: $TS^2 = TP^2 + TQ^2 - TR^2 = 100 + 25 - 121 = 4$."),
              (16, r"Uses the distances instead of their squares: $TS = 10 + 11 - 5$.")])


# ---------------------------------------------------------------- 019
f = Fig()
P_ = f.pt("P", 0, 12); Q_ = f.pt("Q", 12, 12); R_ = f.pt("R", 12, 0); S_ = f.pt("S", 0, 0)
M_ = f.pt("M", 12, 6); N_ = f.pt("N", 6, 0)
f.shade([(0, 12), (12, 6), (6, 0)])
f.poly(P_, Q_, R_, S_); f.poly(P_, M_, N_)
f.label_seg((0, 12), (12, 12), "12 cm")
_alt19 = "Square PQRS of side 12 cm. M is the midpoint of QR and N is the midpoint of RS. Triangle PMN is shaded."


def _c019():
    Pp, Qp, Rp, Sp = (0, 12), (12, 12), (12, 0), (0, 0)
    return _area(Pp, _mid(Qp, Rp), _mid(Rp, Sp))
q("C17-A-019", T, "Area of the triangle joining a vertex of a square to midpoints of the far sides", "Medium",
  "Multi-step word problem",
  r"$PQRS$ is a square of side $12$ cm. $M$ is the midpoint of $QR$ and $N$ is the midpoint of $RS$. What is the area of triangle $PMN$?",
  "MCQ",
  r"Subtract the three corner triangles from the square. Triangle $PQM$ has area $\frac{1}{2} \times 12 \times 6 = 36$, triangle $PSN$ also has area $36$, and triangle $MRN$ has area $\frac{1}{2} \times 6 \times 6 = 18$. So the area of $PMN$ is $144 - 36 - 36 - 18 = 54$ cm$^2$.",
  "Missing the small corner triangle at $R$, or giving it the same area as the other two.",
  "C17A-corner-triangles-complement", "Complement method with three corner triangles of two sizes.",
  correct=r"$54$ cm$^2$",
  distractors=[(r"$72$ cm$^2$", r"Subtracts only the two large triangles, $144 - 36 - 36$, missing triangle $MRN$."),
               (r"$36$ cm$^2$", r"Gives the corner triangle $MRN$ area $36$ as well: $144 - 3 \times 36$."),
               (r"$90$ cm$^2$", r"Gives all three corner triangles area $18$: $144 - 3 \times 18$.")],
  check=_c019, values=[54, 72, 36, 90], cognitive="Application",
  figure=_fig(f, _alt19))


# ---------------------------------------------------------------- 020
f = Fig()
P_ = f.pt("P", 0, 23); Q_ = f.pt("Q", 23, 23); R_ = f.pt("R", 23, 0); S_ = f.pt("S", 0, 0)
W_ = f.pt("W", 8, 23); X_ = f.pt("X", 23, 15); Y_ = f.pt("Y", 15, 0); Z_ = f.pt("Z", 0, 8)
f.poly(P_, Q_, R_, S_); f.poly(W_, X_, Y_, Z_)
f.label_seg((0, 23), (8, 23), "8 cm"); f.text((26.2, 9.5), "23 cm")
_alt20 = "Square PQRS of side 23 cm. Points W, X, Y, Z lie on PQ, QR, RS, SP with PW = QX = RY = SZ = 8 cm, and WXYZ is drawn inside the square."


def _c020():
    Pp, Qp, Rp, Sp = (0, 23), (23, 23), (23, 0), (0, 0)
    Wp, Xp, Yp, Zp = (8, 23), (23, 15), (15, 0), (0, 8)
    assert _dist(Pp, Wp) == _dist(Qp, Xp) == _dist(Rp, Yp) == _dist(Sp, Zp) == 8
    return _area(Wp, Xp, Yp, Zp)
q("C17-A-020", T, "Area of the square formed by points cutting equal lengths on the sides of a square", "Medium",
  "Multi-step word problem",
  r"$PQRS$ is a square tile of side $23$ cm. Points $W$, $X$, $Y$, $Z$ are marked on $PQ$, $QR$, $RS$, $SP$ respectively so that $PW = QX = RY = SZ = 8$ cm. What is the area, in cm$^2$, of the quadrilateral $WXYZ$?",
  "TITA",
  r"Each corner triangle is right-angled with legs $8$ and $15$ cm, so $WXYZ$ has four equal sides and is a square. Its area is $23^2 - 4 \times \frac{1}{2} \times 8 \times 15 = 529 - 240 = 289$ cm$^2$ (equivalently, side$^2 = 8^2 + 15^2 = 289$).",
  "Subtracting too few corner triangles, or confusing it with the small square of side $15 - 8$.",
  "C17A-square-inside-square", "Recognise the four congruent corner triangles.",
  tita_answer=289, check=_c020, cognitive="Application",
  tita_traps=[(409, r"Subtracts only two corner triangles, $529 - 120$."),
              (49, r"Computes $(15 - 8)^2$, the small central square of the other classic dissection.")],
  figure=_fig(f, _alt20))


# ---------------------------------------------------------------- 021
def _c021():
    sol = solve([Eq(x - y, 23), Eq(x ** 2 + y ** 2, 37 ** 2)], [x, y], dict=True)
    s = [d for d in sol if d[x] > 0 and d[y] > 0][0]
    return s[x] * s[y]
q("C17-A-021", T, "Area of a rectangle from its diagonal and the difference of its sides", "Medium",
  "Multi-step word problem",
  r"The diagonal of a rectangular field is $37$ m, and its length exceeds its breadth by $23$ m. What is the area of the field?",
  "MCQ",
  r"With length $l$ and breadth $b$: $l - b = 23$ and $l^2 + b^2 = 37^2 = 1{,}369$. Since $(l - b)^2 = l^2 + b^2 - 2lb$, we have $2lb = 1{,}369 - 529 = 840$, so the area $lb = 420$ m$^2$. (The sides are $35$ m and $12$ m.)",
  "Stopping at $2lb$, or subtracting $23$ instead of $23^2$.",
  "C17A-sum-and-squares-identity", "Uses $(l-b)^2 = l^2 + b^2 - 2lb$; a quick route avoids solving for the sides.",
  correct=r"$420$ m$^2$",
  distractors=[(r"$840$ m$^2$", r"Stops at $2lb = 1{,}369 - 529 = 840$."),
               (r"$673$ m$^2$", r"Subtracts $23$ rather than $23^2$: $\frac{1{,}369 - 23}{2} = 673$."),
               (r"$210$ m$^2$", r"Halves twice, taking $840$ as $4lb$.")],
  check=_c021, values=[420, 840, 673, 210], cognitive="Application")


# ---------------------------------------------------------------- 022
def _c022():
    seen = set()
    for l in range(1, 200):
        for bb in range(1, 200):
            if l * bb == 3 * 2 * (l + bb):
                seen.add(tuple(sorted((l, bb))))
    return len(seen)
q("C17-A-022", T, "Counting integer-sided rectangles whose area is three times the perimeter", "Medium",
  "Casework/optimisation",
  r"A rectangle has integer side lengths (in cm), and the numerical value of its area (in cm$^2$) is exactly $3$ times the numerical value of its perimeter (in cm). Counting a square as a rectangle and counting congruent rectangles only once, how many such rectangles are there?",
  "TITA",
  r"With sides $l \le b$: $lb = 6(l + b)$, so $lb - 6l - 6b + 36 = 36$, that is $(l - 6)(b - 6) = 36$. Both factors must be positive (if both were negative, each would be at least $-5$ and their product at most $25$). The factor pairs of $36$ with the first not larger are $1 \times 36$, $2 \times 18$, $3 \times 12$, $4 \times 9$, $6 \times 6$, giving the rectangles $7 \times 42$, $8 \times 24$, $9 \times 18$, $10 \times 15$, $12 \times 12$. That is $5$ rectangles.",
  "Counting ordered pairs, or leaving out the square.",
  "C17A-rectangle-integer-sides-count", "Needs the factorisation trick and careful counting of unordered pairs.",
  tita_answer=5, check=_c022, cognitive="Analysis", exams=CX,
  tita_traps=[(9, r"Counts ordered pairs $(l, b)$, one for each of the $9$ divisors of $36$."),
              (4, r"Leaves out the square $12 \times 12$.")])


# ---------------------------------------------------------------- 023
def _c023():
    sol = solve([Eq(x * 12, y * 8), Eq(2 * (x + y), 60)], [x, y], dict=True)[0]
    return sol[x] * 12
q("C17-A-023", T, "Area of a parallelogram from both heights and the perimeter", "Medium",
  "Multi-step word problem",
  r"A parallelogram has a perimeter of $60$ cm. The distance between one pair of opposite sides is $12$ cm and the distance between the other pair is $8$ cm. What is the area of the parallelogram?",
  "MCQ",
  r"Let the sides be $a$ and $b$, with $12$ cm the distance between the sides of length $a$. Then the area is $12a = 8b$, so $a : b = 2 : 3$. Since $a + b = 30$, $a = 12$ and $b = 18$. The area is $12 \times 12 = 144$ cm$^2$ (check: $8 \times 18 = 144$).",
  "Pairing each height with the wrong side, which reverses the ratio of the sides.",
  "C17A-parallelogram-area-two-heights", "Turns two area expressions into a ratio of sides and combines it with the perimeter.",
  correct=r"$144$ cm$^2$",
  distractors=[(r"$216$ cm$^2$", r"Pairs the height $12$ with the longer side $18$: $18 \times 12$."),
               (r"$96$ cm$^2$", r"Pairs the height $8$ with the shorter side $12$: $12 \times 8$."),
               (r"$180$ cm$^2$", r"Assumes equal sides of $15$ cm and uses the height $12$: $15 \times 12$.")],
  check=_c023, values=[144, 216, 96, 180], cognitive="Application")


# ---------------------------------------------------------------- 024
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 30, 0); R_ = f.pt("R", 23, 10); S_ = f.pt("S", 5, 10)
f.poly(P_, Q_, R_, S_); f.seg(P_, R_); f.seg(Q_, S_)
M_ = f.pt("M", 11.5, 5, offset=(0, -1)); N_ = f.pt("N", 17.5, 5, offset=(0, -1))
f.label_seg((0, 0), (30, 0), "30 cm"); f.label_seg((5, 10), (23, 10), "18 cm")
_alt24 = "Trapezium PQRS with PQ = 30 cm at the bottom parallel to SR = 18 cm at the top. Diagonals PR and QS are drawn; M is the midpoint of PR and N is the midpoint of QS."


def _c024():
    Pp, Qp, Rp, Sp = (0, 0), (30, 0), (Rational(47, 2), 10), (Rational(11, 2), 10)
    assert _dist(Sp, Rp) == 18
    return simplify(_dist(_mid(Pp, Rp), _mid(Qp, Sp)))
q("C17-A-024", T, "Segment joining the midpoints of the diagonals of a trapezium", "Medium",
  "Conceptual/application",
  r"In a trapezium $PQRS$, $PQ \parallel SR$, $PQ = 30$ cm and $SR = 18$ cm. $M$ and $N$ are the midpoints of the diagonals $PR$ and $QS$ respectively. What is the length of $MN$?",
  "MCQ",
  r"The line through the midpoints of the legs (the mid-segment) is parallel to the bases and has length $\frac{30 + 18}{2} = 24$ cm; it passes through $M$ and $N$. In triangle $PSR$ the piece from the midpoint of $PS$ to $M$ is half of $SR$, that is $9$ cm, and in triangle $QRS$ the piece from $N$ to the midpoint of $QR$ is also $9$ cm. So $MN = 24 - 9 - 9 = 6$ cm, which is $\frac{30 - 18}{2}$.",
  "Confusing this segment with the mid-segment of the trapezium, or forgetting to halve the difference.",
  "C17A-trapezium-midline-segments", "Needs the midpoint theorem inside the trapezium, not a memorised formula.",
  correct=r"$6$ cm",
  distractors=[(r"$24$ cm", r"Gives the mid-segment joining the midpoints of the legs, $\frac{30 + 18}{2}$."),
               (r"$12$ cm", r"Takes the full difference of the parallel sides, $30 - 18$."),
               (r"$9$ cm", r"Takes half the shorter parallel side, which is only one of the pieces of the mid-segment.")],
  check=_c024, values=[6, 24, 12, 9], cognitive="Understanding",
  figure=_fig(f, _alt24))


# ---------------------------------------------------------------- 025
f = Fig()
P_ = f.pt("P", 0, 12); Q_ = f.pt("Q", 16, 12); R_ = f.pt("R", 9, 0); S_ = f.pt("S", 0, 0)
f.poly(P_, Q_, R_, S_); f.seg(P_, R_); f.seg(Q_, S_)
f.right_angle((16, 12), (0, 12), (0, 0)); f.right_angle((0, 12), (0, 0), (9, 0))
f.label_seg((0, 12), (16, 12), "16 cm"); f.text((-1.8, 6), "12 cm"); f.pts.append((-3.6, 6))
_alt25 = "Trapezium PQRS with PQ = 16 cm on top parallel to SR at the bottom, and PS = 12 cm perpendicular to both. The diagonals PR and QS are drawn and cross at right angles."


def _c025():
    r_ = symbols('r_', positive=True)
    Pp, Qp, Sp = (0, 12), (16, 12), (0, 0)
    Rp = (r_, 0)
    v1 = (Rp[0] - Pp[0], Rp[1] - Pp[1]); v2 = (Sp[0] - Qp[0], Sp[1] - Qp[1])
    rv = solve(Eq(v1[0] * v2[0] + v1[1] * v2[1], 0), r_)
    assert len(rv) == 1
    return _area(Pp, Qp, (rv[0], 0), Sp)
q("C17-A-025", T, "Area of a right trapezium whose diagonals are perpendicular", "Medium",
  "Conceptual/application",
  r"In a trapezium $PQRS$, $PQ \parallel SR$ and $\angle QPS = \angle PSR = 90^\circ$. The diagonals $PR$ and $QS$ are perpendicular to each other. If $PQ = 16$ cm and $PS = 12$ cm, what is the area of the trapezium, in cm$^2$?",
  "TITA",
  r"Let the diagonals meet at $O$. In right triangle $PSR$, $\angle PRS = 90^\circ - \angle SPR$, and in right triangle $POS$, $\angle PSQ = 90^\circ - \angle SPO$, so $\angle PRS = \angle PSQ$. Hence the right triangles $PSR$ and $QPS$ are similar and $\frac{SR}{PS} = \frac{PS}{PQ}$, giving $SR = \frac{12^2}{16} = 9$ cm. Area $= \frac{1}{2}(16 + 9) \times 12 = 150$ cm$^2$.",
  r"Assuming the second parallel side equals the height, or treating the figure as a rectangle.",
  "C17A-trapezium-perpendicular-diagonals", r"Needs the similar right triangles that perpendicular diagonals create, giving $PS^2 = PQ \times SR$.",
  tita_answer=150, check=_c025, cognitive="Analysis",
  tita_traps=[(300, r"Finds $SR = 9$ but forgets the $\frac{1}{2}$: $25 \times 12$."),
              (192, r"Treats the trapezium as a rectangle: $16 \times 12$."),
              (168, r"Takes $SR = PS = 12$: $\frac{1}{2}(16 + 12) \times 12$.")],
  figure=_fig(f, _alt25))


# ---------------------------------------------------------------- 026
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 12, 0); R_ = f.pt("R", 12, 10); S_ = f.pt("S", 0, 10)
X_ = f.pt("X", 12, 4, offset=(1, 0)); Y_ = f.pt("Y", 6, 10, offset=(0, 1))
f.shade([(0, 0), (12, 4), (6, 10)])
f.poly(P_, Q_, R_, S_); f.poly(P_, X_, Y_)
f.text((8.0, 1.3), "24"); f.text((10.0, 8.0), "18"); f.text((2.0, 7.0), "30")
_alt26 = "Rectangle PQRS with X on side QR and Y on side RS. Segments PX, XY and YP divide it into four triangles; triangles PQX, XRY and YSP are marked 24, 18 and 30, and triangle PXY is shaded."


def _c026():
    # fix PQ at two different lengths and solve for the rest; the area of PXY must be the same
    out = set()
    for L in (12, 15):
        Wd, u, v = symbols('Wd u v', positive=True)
        sols = solve([Eq(L * u / 2, 24), Eq((Wd - u) * v / 2, 18), Eq(Wd * (L - v) / 2, 30)], [Wd, u, v], dict=True)
        good = [s for s in sols if 0 < s[u] < s[Wd] and 0 < s[v] < L]
        assert len(good) == 1
        s = good[0]
        Pp, Qp, Rp, Sp = (0, 0), (L, 0), (L, s[Wd]), (0, s[Wd])
        Xp, Yp = (L, s[u]), (L - s[v], s[Wd])
        assert _area(Pp, Qp, Xp) == 24 and _area(Xp, Rp, Yp) == 18 and _area(Yp, Sp, Pp) == 30
        out.add(_area(Pp, Xp, Yp))
    assert len(out) == 1
    return out.pop()
q("C17-A-026", T, "Area of the middle triangle when a rectangle is cut by lines from a vertex to two sides", "Difficult",
  "Multi-step word problem",
  r"$PQRS$ is a rectangular plot (corners in that order). $X$ is a point on side $QR$ and $Y$ is a point on side $RS$. Fences along $PX$, $XY$ and $YP$ divide the plot into four triangular parts. The areas of triangles $PQX$, $XRY$ and $YSP$ are $24$ m$^2$, $18$ m$^2$ and $30$ m$^2$ respectively. What is the area of triangle $PXY$?",
  "MCQ",
  r"Let the rectangle have area $A$, with $QX = x \cdot QR$ and $RY = y \cdot RS$ as fractions of the sides. Then $PQX = \frac{xA}{2} = 24$, $YSP = \frac{(1 - y)A}{2} = 30$ and $XRY = \frac{(1 - x)yA}{2} = 18$. So $x = \frac{48}{A}$ and $y = 1 - \frac{60}{A}$, and $(A - 48)(A - 60) = 36A$, that is $A^2 - 144A + 2{,}880 = 0$, giving $A = 120$ or $24$. Since $A > 72$, $A = 120$ and $PXY = 120 - 24 - 18 - 30 = 48$ m$^2$.",
  "Stopping at the area of the rectangle, or assuming the middle triangle is half of the rectangle.",
  "C17A-corner-triangles-complement", "The unknown dimensions lead to a quadratic in the area of the rectangle, with one root to be rejected.",
  correct=r"$48$ m$^2$",
  distractors=[(r"$72$ m$^2$", r"Reports the total of the three given triangles, $24 + 18 + 30$, as the middle triangle."),
               (r"$60$ m$^2$", r"Finds the plot area $120$ and assumes triangle $PXY$ is half of it, as for a triangle standing on a full side."),
               (r"$120$ m$^2$", r"Finds the area of the whole plot and reports it.")],
  check=_c026, values=[48, 72, 60, 120], cognitive="Analysis", exams=CX,
  figure=_fig(f, _alt26))


# ================================================================ DIFFICULT
# ---------------------------------------------------------------- 027
def _c027():
    r_, hh = symbols('r_ hh', real=True)
    # P = (0, 0), Q = (12, 0), R = (r_, hh), S = (r_ - 9, hh), with PQ parallel to SR
    sols = solve([Eq(r_ ** 2 + hh ** 2, 13 ** 2), Eq((r_ - 9 - 12) ** 2 + hh ** 2, 20 ** 2)], [r_, hh], dict=True)
    areas = set()
    for s in sols:
        if s[hh] > 0:
            Pp, Qp, Rp, Sp = (0, 0), (12, 0), (s[r_], s[hh]), (s[r_] - 9, s[hh])
            areas.add(_area(Pp, Qp, Rp, Sp))
    assert len(areas) == 1
    return areas.pop()
q("C17-A-027", T, "Area of a trapezium from its parallel sides and its two diagonals", "Difficult",
  "Conceptual/application",
  r"A plot is in the shape of a trapezium whose parallel sides are $12$ m and $9$ m long. Its two diagonals are $13$ m and $20$ m long. What is the area of the plot, in m$^2$?",
  "TITA",
  r"Let the trapezium be $PQRS$ with $PQ = 12$, $SR = 9$, $PR = 13$ and $QS = 20$. Extend $PQ$ beyond $Q$ to $T$ with $QT = SR = 9$. Then $QTRS$ is a parallelogram, so $RT = QS = 20$, and triangle $PRT$ has sides $13$, $20$ and $PT = 21$. It has the same height as the trapezium and base $PQ + SR$, so its area equals the area of the trapezium. By Heron's formula with $s = 27$: $\sqrt{27 \times 14 \times 7 \times 6} = \sqrt{15{,}876} = 126$ m$^2$. (The height is $\frac{2 \times 126}{21} = 12$ m.)",
  "Treating the diagonals as perpendicular, or forgetting that the triangle and the trapezium have the same area.",
  "C17A-trapezium-diagonal-translation", "Needs the non-obvious step of sliding one diagonal to form a triangle of equal area.",
  tita_answer=126, check=_c027, cognitive="Analysis", exams=CX,
  tita_traps=[(130, r"Uses $\frac{1}{2} \times 13 \times 20$, as if the diagonals were perpendicular."),
              (252, r"Finds the height $12$ m but multiplies by the full sum of the parallel sides: $21 \times 12$.")])


# ---------------------------------------------------------------- 028
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 12, 0); R_ = f.pt("R", 16, 8); S_ = f.pt("S", 4, 8)
M_ = f.pt("M", 14, 4)
# X = intersection of PM and QS (computed exactly below; P + t(14,4) = Q + s(-8,8) -> t = 2/3)
X_ = f.pt("X", 14 * 2 / 3.0, 4 * 2 / 3.0, offset=(0, -1))
f.shade([(14 * 2 / 3.0, 4 * 2 / 3.0), (14, 4), (16, 8), (4, 8)])
f.poly(P_, Q_, R_, S_); f.seg(P_, M_); f.seg(Q_, S_)
_alt28 = "Parallelogram PQRS. M is the midpoint of QR. The segment PM meets the diagonal QS at X. The quadrilateral XMRS is shaded."


def _c028():
    Pp, Qp, Rp, Sp = (0, 0), (12, 0), (16, 8), (4, 8)
    scale = Rational(240) / _area(Pp, Qp, Rp, Sp)
    Mp = _mid(Qp, Rp)
    Xp = _meet(Pp, Mp, Qp, Sp)
    return _area(Xp, Mp, Rp, Sp) * scale
q("C17-A-028", T, "Area cut off by a line from a vertex to a midpoint and a diagonal of a parallelogram", "Difficult",
  "Multi-step word problem",
  r"$PQRS$ is a parallelogram of area $240$ cm$^2$. $M$ is the midpoint of $QR$, and the segment $PM$ meets the diagonal $QS$ at $X$. What is the area of the quadrilateral $XMRS$?",
  "MCQ",
  r"Triangles $XQM$ and $XSP$ are similar because $QM \parallel SP$, with ratio $QM : SP = 1 : 2$, so $QX : XS = 1 : 2$, giving $QX = \frac{1}{3}QS$. Triangle $QSM$ has half the area of triangle $QRS$, that is $\frac{1}{2} \times 120 = 60$, and triangle $QXM$ is $\frac{1}{3}$ of it, $20$ cm$^2$. Hence $XMRS = 120 - 20 = 100$ cm$^2$.",
  "Taking $X$ as the midpoint of $QS$, or taking triangle $QXM$ as a third of triangle $QRS$.",
  "C17A-parallelogram-cevian-ratio", "Needs a similar-triangle ratio on the diagonal and two equal-height area ratios.",
  correct=r"$100$ cm$^2$",
  distractors=[(r"$90$ cm$^2$", r"Takes $X$ as the midpoint of $QS$: $QXM = \frac{1}{2} \times 60 = 30$, so $120 - 30 = 90$."),
               (r"$105$ cm$^2$", r"Uses $QX : XS = 1 : 3$: $QXM = \frac{1}{4} \times 60 = 15$, so $120 - 15 = 105$."),
               (r"$80$ cm$^2$", r"Takes triangle $QXM$ as one third of triangle $QRS$: $120 - 40 = 80$.")],
  check=_c028, values=[100, 90, 105, 80], cognitive="Analysis", exams=CX,
  figure=_fig(f, _alt28))


# ---------------------------------------------------------------- 029
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 15, 0); R_ = f.pt("R", 20, 9); S_ = f.pt("S", 5, 9)
E_ = f.pt("E", 10, 0, offset=(0, -1))
# X = SE meets PR: PX : XR = 2 : 3
X_ = f.pt("X", 20 * 0.4, 9 * 0.4, offset=(1.3, -0.4))
f.shade([(0, 0), (10, 0), (8, 3.6)])
f.poly(P_, Q_, R_, S_); f.seg(S_, E_); f.seg(P_, R_)
f.text((6.0, 1.2), "24")
_alt29 = "Parallelogram PQRS with E on PQ such that PE : EQ = 2 : 1. The segment SE meets the diagonal PR at X. Triangle PXE is shaded and marked 24."


def _c029():
    Ar = symbols('Ar', positive=True)
    # unit model: P(0,0), Q(3,0), S(1,2), R(4,2), E(2,0); then scale areas
    Pp, Qp, Rp, Sp, Ep = (0, 0), (3, 0), (4, 2), (1, 2), (2, 0)
    Xp = _meet(Sp, Ep, Pp, Rp)
    frac = _area(Pp, Xp, Ep) / _area(Pp, Qp, Rp, Sp)
    return solve(Eq(frac * Ar, 24), Ar)[0]
q("C17-A-029", T, "Area of a parallelogram from a small triangle cut by a diagonal and a cevian", "Difficult",
  "Inverse/parameter",
  r"In a parallelogram $PQRS$, $E$ is the point on $PQ$ with $PE : EQ = 2 : 1$. The segment $SE$ meets the diagonal $PR$ at $X$. If the area of triangle $PXE$ is $24$ cm$^2$, what is the area of the parallelogram, in cm$^2$?",
  "TITA",
  r"Let the area be $A$. As $PE \parallel SR$, triangles $PXE$ and $RXS$ are similar with $PX : XR = PE : SR = 2 : 3$, so $PX = \frac{2}{5}PR$. Triangle $PER$ has base $PE = \frac{2}{3}PQ$ and the same height as triangle $PQR$, so its area is $\frac{2}{3} \times \frac{A}{2} = \frac{A}{3}$. Then triangle $PXE$ is $\frac{2}{5}$ of that: $\frac{2A}{15} = 24$, so $A = 180$ cm$^2$.",
  "Using $PE : EQ$ instead of $PE : SR$ for the division of the diagonal, or forgetting that triangle $PQR$ is half the parallelogram.",
  "C17A-parallelogram-cevian-ratio", "Two area ratios and a similar-triangle ratio must be chained correctly.",
  tita_answer=180, check=_c029, cognitive="Analysis", exams=CX,
  tita_traps=[(108, r"Takes $PX : XR = 2 : 1$ (the ratio $PE : EQ$), giving $\frac{2}{3} \times \frac{A}{3} = 24$."),
              (90, r"Treats triangle $PQR$ as having area $A$: $\frac{2}{5} \times \frac{2A}{3} = 24$.")],
  figure=_fig(f, _alt29))


# ---------------------------------------------------------------- 030
def _c030():
    pp, qq = symbols('pp qq', positive=True)
    sols = solve([Eq(pp + qq, 31)], [pp, qq], dict=True)
    # build Q2 explicitly for symbolic diagonals and match perimeter 25
    Pp, Qp, Rp, Ss = (-pp / 3, 0), (0, qq / 2), (2 * pp / 3, 0), (0, -qq / 2)   # diagonals on the axes, perpendicular
    M1 = [_mid(Pp, Qp), _mid(Qp, Rp), _mid(Rp, Ss), _mid(Ss, Pp)]
    M2 = [_mid(M1[i], M1[(i + 1) % 4]) for i in range(4)]
    per2 = sum(_dist(M2[i], M2[(i + 1) % 4]) for i in range(4))
    sol = solve([Eq(pp + qq, 31), Eq(simplify(per2) ** 2, 625)], [pp, qq], dict=True)
    vals = set(simplify(d[pp] * d[qq] / 2) for d in sol)
    assert len(vals) == 1
    return vals.pop()
q("C17-A-030", T, "Area of a quadrilateral from the perimeter of its second midpoint quadrilateral", "Difficult",
  "Inverse/parameter",
  r"The diagonals of a quadrilateral $PQRS$ are perpendicular to each other, and their lengths add up to $31$ cm. The midpoints of the sides of $PQRS$ are joined in order to form a quadrilateral $F_1$, and the midpoints of the sides of $F_1$ are joined in order to form a quadrilateral $F_2$. If the perimeter of $F_2$ is $25$ cm, what is the area of $PQRS$?",
  "MCQ",
  r"Let the diagonals be $p$ and $q$. By the midpoint theorem $F_1$ has sides $\frac{p}{2}$ and $\frac{q}{2}$, and since the diagonals are perpendicular it is a rectangle. Its diagonals are each $\frac{1}{2}\sqrt{p^2 + q^2}$, and $F_2$ is a rhombus whose sides are half of that, so the perimeter of $F_2$ is $4 \times \frac{1}{4}\sqrt{p^2 + q^2} = \sqrt{p^2 + q^2} = 25$. Then $2pq = 31^2 - 25^2 = 336$, so $pq = 168$, and the area of $PQRS$ is $\frac{1}{2}pq = 84$ cm$^2$.",
  r"Stopping at an intermediate figure, or forgetting the $\frac{1}{2}$ in the area of a quadrilateral with perpendicular diagonals.",
  "C17A-midpoint-quadrilateral", "Two successive midpoint constructions, then an algebraic identity.",
  correct=r"$84$ cm$^2$",
  distractors=[(r"$168$ cm$^2$", r"Takes $pq = 168$ as the area, missing the $\frac{1}{2}$."),
               (r"$42$ cm$^2$", r"Reports the area of the rectangle $F_1$, $\frac{p}{2} \times \frac{q}{2} = 42$."),
               (r"$21$ cm$^2$", r"Reports the area of the rhombus $F_2$, half of $42$.")],
  check=_c030, values=[84, 168, 42, 21], cognitive="Analysis", exams=CX)


# ---------------------------------------------------------------- 031
def _c031():
    aa, bb, cs, sn = symbols('aa bb cs sn', real=True)
    # sides aa, bb with included angle theta (cos = cs, sin = sn); diagonals 19 and 11; area 80
    sols = solve([Eq(aa ** 2 + bb ** 2 + 2 * aa * bb * cs, 19 ** 2),
                  Eq(aa ** 2 + bb ** 2 - 2 * aa * bb * cs, 11 ** 2),
                  Eq(aa * bb * sn, 80), Eq(cs ** 2 + sn ** 2, 1)], [aa, bb, cs, sn], dict=True)
    per = set()
    for s in sols:
        if all(v.is_real for v in s.values()) and s[aa] > 0 and s[bb] > 0 and s[sn] > 0:
            per.add(simplify(2 * (s[aa] + s[bb])))
    assert len(per) == 1
    return per.pop()
q("C17-A-031", T, "Perimeter of a parallelogram from its diagonals and its area", "Difficult",
  "Inverse/parameter",
  r"The diagonals of a parallelogram-shaped plot are $19$ m and $11$ m long, and the area of the plot is $80$ m$^2$. What is the perimeter of the plot, in metres?",
  "TITA",
  r"Let the sides be $a$ and $b$ with included angle $\theta$. By the cosine rule the diagonals satisfy $a^2 + b^2 \pm 2ab\cos\theta = 19^2, 11^2$. Adding, $a^2 + b^2 = \frac{361 + 121}{2} = 241$; subtracting, $ab\cos\theta = \frac{361 - 121}{4} = 60$. The area gives $ab\sin\theta = 80$, so $ab = \sqrt{60^2 + 80^2} = 100$. Then $(a + b)^2 = 241 + 200 = 441$, so $a + b = 21$ and the perimeter is $42$ m.",
  r"Taking $ab$ equal to the area (ignoring the angle), or reporting $a + b$.",
  "C17A-parallelogram-diagonal-law", "The angle between the sides is unknown and has to be eliminated using both the diagonals and the area.",
  tita_answer=42, check=_c031, cognitive="Analysis", exams=CX,
  tita_traps=[(21, r"Reports the semi-perimeter $a + b$."),
              (40, r"Takes $ab = 80$, the area, and gets $(a + b)^2 = 241 + 160 = 401$, so the perimeter is $2\sqrt{401} \approx 40.05$, which the student types as $40$.")])


# ---------------------------------------------------------------- 032
f = Fig()
_ang32 = 100
_Qp = (0.0, 0.0); _Rp = (1.0, 0.0); _Pp = _cs(_ang32); _Sp = (_Pp[0] + 1, _Pp[1]); _Tp = _cs(60)
P_ = f.pt("P", *_Pp); Q_ = f.pt("Q", *_Qp); R_ = f.pt("R", *_Rp); S_ = f.pt("S", *_Sp)
T_ = f.pt("T", *_Tp, offset=(0, -1.4))
f.poly(P_, Q_, R_, S_); f.poly(Q_, R_, T_); f.seg(P_, T_); f.seg(S_, T_)
f.angle_mark(_Rp, _Qp, _Pp, "100^\\circ", r=0.16)
_alt32 = "Rhombus PQRS with angle PQR = 100 degrees. A point T inside the rhombus forms an equilateral triangle QRT, and T is joined to P and S."


def _c032():
    ang = 100
    Qp = (0.0, 0.0); Rp = (1.0, 0.0)
    Pp = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
    Sp = (Pp[0] + 1, Pp[1])
    Tp = (math.cos(math.radians(60)), math.sin(math.radians(60)))   # equilateral on QR, on the rhombus side
    # T must be inside the rhombus
    def side(a, bq, pt):
        return (bq[0] - a[0]) * (pt[1] - a[1]) - (bq[1] - a[1]) * (pt[0] - a[0])
    poly = [Qp, Rp, Sp, Pp]
    assert all(side(poly[i], poly[(i + 1) % 4], Tp) > 0 for i in range(4))
    ang_pts = _angle_deg(Pp, Tp, Sp)
    # angle PTS on the side away from Q and R (the angle facing PS); check it is that one
    tot = _angle_deg(Pp, Tp, Qp) + _angle_deg(Qp, Tp, Rp) + _angle_deg(Rp, Tp, Sp) + ang_pts
    assert abs(tot - 360) < 1e-9
    assert abs(ang_pts - round(ang_pts)) < 1e-9
    return Integer(round(ang_pts))
q("C17-A-032", T, "Angle chasing in a rhombus with an equilateral triangle on one side", "Medium",
  "Conceptual/application",
  r"$PQRS$ is a rhombus with $\angle PQR = 100^\circ$. A point $T$ inside the rhombus is chosen so that triangle $QRT$ is equilateral. What is the measure of $\angle PTS$?",
  "MCQ",
  r"Since $QT = QR = QP$, triangle $QPT$ is isosceles with apex angle $\angle PQT = 100^\circ - 60^\circ = 40^\circ$, so $\angle PTQ = \frac{180^\circ - 40^\circ}{2} = 70^\circ$. Adjacent angles of a rhombus are supplementary, so $\angle QRS = 80^\circ$. Since $RT = RQ = RS$, triangle $RST$ is isosceles with apex angle $80^\circ - 60^\circ = 20^\circ$, so $\angle RTS = 80^\circ$. The angles around $T$ add up to $360^\circ$: $\angle PTS = 360^\circ - 70^\circ - 60^\circ - 80^\circ = 150^\circ$.",
  "Assuming the two isosceles triangles at $T$ are congruent, or reporting the reflex angle.",
  "C17A-parallelogram-angle-chasing", "Two isosceles-triangle angle computations and the angle sum at a point, an upper Medium.",
  correct=r"$150^\circ$",
  distractors=[(r"$160^\circ$", r"Assumes both base angles at $T$ equal $70^\circ$, as if the figure were symmetric: $360 - 70 - 60 - 70$."),
               (r"$140^\circ$", r"Assumes both base angles at $T$ equal $80^\circ$: $360 - 80 - 60 - 80$."),
               (r"$210^\circ$", r"Adds $\angle PTQ$, $\angle QTR$ and $\angle RTS$, $70 + 60 + 80 = 210$, and reports that sum.")],
  check=_c032, values=[150, 160, 140, 210], cognitive="Analysis", exams=CX,
  figure=_fig(f, _alt32))


# ---------------------------------------------------------------- 033
f = Fig()
_V = [(20, 0), (0, 15), (-20, 0), (0, -15)]
P_ = f.pt("P", -20, 0); Q_ = f.pt("Q", 0, -15); R_ = f.pt("R", 20, 0); S_ = f.pt("S", 0, 15)
f.poly(P_, Q_, R_, S_); f.seg(Q_, S_)
# height from S to side PQ: foot of perpendicular
_dx, _dy = 20.0, -15.0; _L2 = _dx * _dx + _dy * _dy
_t33 = ((0 - (-20)) * _dx + (15 - 0) * _dy) / _L2
_F33 = (-20 + _t33 * _dx, 0 + _t33 * _dy)
H_ = f.pt("H", *_F33)
f.seg(S_, H_, dashed=True); f.right_angle(S_, H_, Q_)
f.text((3.2, 3), "30 cm"); f.label_seg(S_, H_, "24 cm", side=-1)
_alt33 = "Rhombus PQRS with diagonal QS = 30 cm drawn. A perpendicular SH from S to side PQ has length 24 cm."


def _c033():
    sd, hq = symbols('sd hq', positive=True)
    sol = solve([Eq(sd * 24, Rational(1, 2) * 30 * hq), Eq(sd ** 2, 15 ** 2 + (hq / 2) ** 2)], [sd, hq], dict=True)
    sol = [d for d in sol if d[hq] > 30]           # 30 cm is the shorter diagonal
    assert len(sol) == 1
    return sol[0][sd] * 24
q("C17-A-033", T, "Area of a rhombus from its shorter diagonal and its height", "Difficult",
  "Inverse/parameter",
  r"The shorter diagonal of a rhombus is $30$ cm, and the perpendicular distance between two of its opposite sides is $24$ cm. What is the area of the rhombus?",
  "MCQ",
  r"Let the side be $s$ and the longer diagonal $d$. Area $= 24s = \frac{1}{2} \times 30 \times d$, so $d = \frac{8s}{5}$. The half-diagonals and a side form a right triangle: $s^2 = 15^2 + \left(\frac{4s}{5}\right)^2$, so $\frac{9s^2}{25} = 225$, $s = 25$ cm and $d = 40$ cm. The area is $24 \times 25 = 600$ cm$^2$.",
  "Treating the diagonal as the base for the given height, or multiplying the diagonal by the side.",
  "C17A-rhombus-diagonals-side", "Two different area expressions must be combined with the half-diagonal triangle.",
  correct=r"$600$ cm$^2$",
  distractors=[(r"$720$ cm$^2$", r"Multiplies the shorter diagonal by the height, $30 \times 24$, as if the diagonal were the base."),
               (r"$360$ cm$^2$", r"Uses $\frac{1}{2} \times 30 \times 24$, treating the height as the other diagonal."),
               (r"$750$ cm$^2$", r"Finds the side $25$ cm and multiplies it by the shorter diagonal, $25 \times 30$.")],
  check=_c033, values=[600, 720, 360, 750], cognitive="Analysis", exams=CX,
  figure=_fig(f, _alt33))


# ---------------------------------------------------------------- 034
f = Fig()
P_ = f.pt("P", 0, 0); Q_ = f.pt("Q", 30, 0); R_ = f.pt("R", 30, 30); S_ = f.pt("S", 0, 30)
X_ = f.pt("X", 30, 10, offset=(1, 0)); Y_ = f.pt("Y", 20, 30, offset=(0, 1))
Z_ = f.pt("Z", 0, 20, offset=(-1, 0)); W_ = f.pt("W", 10, 0, offset=(0, -1))
_K34 = [(27.0, 9.0), (21.0, 27.0), (3.0, 21.0), (9.0, 3.0)]
f.shade(_K34)
f.poly(P_, Q_, R_, S_); f.seg(P_, X_); f.seg(Q_, Y_); f.seg(R_, Z_); f.seg(S_, W_)
f.label_seg((0, 0), (30, 0), "30 m", side=1); f.label_seg((30, 0), (30, 10), "10 m")
_alt34 = "Square PQRS of side 30 m. X, Y, Z, W lie on QR, RS, SP, PQ with QX = RY = SZ = PW = 10 m. Paths PX, QY, RZ and SW enclose a shaded square in the middle."


def _c034():
    Pp, Qp, Rp, Sp = (0, 0), (30, 0), (30, 30), (0, 30)
    Xp, Yp, Zp, Wp = (30, 10), (20, 30), (0, 20), (10, 0)
    assert _dist(Qp, Xp) == _dist(Rp, Yp) == _dist(Sp, Zp) == _dist(Pp, Wp) == 10
    K = [_meet(Pp, Xp, Qp, Yp), _meet(Qp, Yp, Rp, Zp), _meet(Rp, Zp, Sp, Wp), _meet(Sp, Wp, Pp, Xp)]
    sides = [simplify(_dist(K[i], K[(i + 1) % 4])) for i in range(4)]
    assert len(set(sides)) == 1
    return _area(*K)
q("C17-A-034", T, "Area of the square enclosed by four paths from the corners of a square", "Difficult",
  "Conceptual/application",
  r"$PQRS$ is a square garden of side $30$ m (corners in that order). Points $X$, $Y$, $Z$, $W$ lie on $QR$, $RS$, $SP$, $PQ$ respectively, with $QX = RY = SZ = PW = 10$ m. Straight paths $PX$, $QY$, $RZ$ and $SW$ are laid, and they enclose a square region in the middle of the garden. What is the area of this region?",
  "MCQ",
  r"By the rotational symmetry the paths meet at right angles, so the region outside the middle square is made of four congruent right triangles, each with a side of the garden as hypotenuse. For the one on $PQ$, the path $PX$ rises $1$ m for every $3$ m, so its legs are in the ratio $3 : 1$; with hypotenuse $30$, the legs are $\frac{90}{\sqrt{10}}$ and $\frac{30}{\sqrt{10}}$ and the area is $\frac{1}{2} \times \frac{2{,}700}{10} = 135$ m$^2$. The middle square has area $900 - 4 \times 135 = 360$ m$^2$ (its side is $\frac{90 - 30}{\sqrt{10}}$).",
  "Subtracting overlapping corner triangles, or carrying over the one-fifth result that holds only when the points are midpoints.",
  "C17A-square-pinwheel-paths", "Needs to see the four right triangles on the sides of the square and to get their legs from the slope of a path.",
  correct=r"$360$ m$^2$",
  distractors=[(r"$300$ m$^2$", r"Subtracts the four triangles $PQX$, $QRY$, $RSZ$, $SPW$ of area $\frac{1}{2} \times 30 \times 10 = 150$ each, which overlap: $900 - 600$."),
               (r"$180$ m$^2$", r"Uses the one-fifth rule for paths to the midpoints of the sides: $\frac{900}{5}$."),
               (r"$400$ m$^2$", r"Takes the side of the middle square as $30 - 10 = 20$ m.")],
  check=_c034, values=[360, 300, 180, 400], cognitive="Analysis", exams=CX,
  figure=_fig(f, _alt34))


# ---------------------------------------------------------------- 035
def _c035():
    count = 0
    for s in range(1, 31):
        for d1 in range(1, 2 * s):
            for d2 in range(d1 + 1, 2 * s):
                # half-diagonals d1/2, d2/2 and side s form a right triangle
                if d1 * d1 + d2 * d2 == 4 * s * s:
                    count += 1
    return count
q("C17-A-035", T, "Counting rhombuses with integer side and integer diagonals", "Difficult",
  "Casework/optimisation",
  r"A rhombus has an integer side length of at most $30$ cm, and both of its diagonals also have integer lengths in cm. Counting congruent rhombuses only once, how many such rhombuses are possible?",
  "MCQ",
  r"If the diagonals are $p < q$ and the side is $s$, then $p^2 + q^2 = 4s^2$; this forces $p$ and $q$ to be even (a sum of two squares divisible by $4$ needs both even), so $\left(\frac{p}{2}, \frac{q}{2}, s\right)$ is a Pythagorean triple ($p = q$ is impossible since $\sqrt{2}$ is irrational). Hypotenuses up to $30$: $5, 10, 13, 15, 17, 20, 25, 26, 29, 30$, each with one triple except $25$, which has two ($7, 24, 25$ and $15, 20, 25$). That gives $10 + 1 = 11$ rhombuses.",
  "Missing that $25$ is the hypotenuse of two different triples, or counting only primitive triples.",
  "C17A-rhombus-integer-diagonals-count", "Reduces to listing Pythagorean triples with hypotenuse up to $30$ and spotting the double case.",
  correct=r"$11$",
  distractors=[(r"$10$", r"Lists each hypotenuse once and misses the second triple $(15, 20, 25)$."),
               (r"$22$", r"Counts the ordered pairs $(p, q)$ and $(q, p)$ as different rhombuses."),
               (r"$5$", r"Counts only primitive triples, with hypotenuses $5, 13, 17, 25, 29$.")],
  check=_c035, values=[11, 10, 22, 5], cognitive="Analysis", exams=CX)
