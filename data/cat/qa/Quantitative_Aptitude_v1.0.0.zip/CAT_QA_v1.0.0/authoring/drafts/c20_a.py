import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
import math as _m

T_ = "Trigonometry and heights and distances"
TWO = ("CAT", "XAT")


def _rad(d):
    return d * pi / 180


def _tn(d):
    return tan(_rad(d))


def _ct(d):
    return 1 / tan(_rad(d))


def _ft(d):
    return _m.tan(_m.radians(d))


def _pos(expr_list):
    return [s for s in expr_list if s.is_positive]


# =====================================================================
# EASY
# =====================================================================

# 001
def _c001():
    return nsimplify(simplify(sin(_rad(30)) ** 2 + cos(_rad(45)) ** 2 + tan(_rad(60)) ** 2))
q("C20-A-001", T_, "Evaluating an expression in standard angle values", "Easy",
  "Single-step computation",
  r"The value of $\sin^2 30^\circ + \cos^2 45^\circ + \tan^2 60^\circ$ is",
  "MCQ",
  r"Use $\sin 30^\circ = \frac{1}{2}$, $\cos 45^\circ = \frac{1}{\sqrt{2}}$ and $\tan 60^\circ = \sqrt{3}$. The sum is $\frac{1}{4} + \frac{1}{2} + 3 = \frac{15}{4}$.",
  r"Mixing up the standard values, such as $\tan 60^\circ$ with $\tan 30^\circ$ or $\cos 45^\circ$ with $\cos 60^\circ$.",
  "C20A-std-angle-values", "Direct recall of three standard values; one trap in swapping a value.",
  correct=r"$\frac{15}{4}$",
  distractors=[(r"$\frac{13}{12}$", r"Takes $\tan 60^\circ = \frac{1}{\sqrt{3}}$: $\frac{1}{4} + \frac{1}{2} + \frac{1}{3} = \frac{13}{12}$."),
               (r"$\frac{17}{4}$", r"Takes $\sin 30^\circ = \frac{\sqrt{3}}{2}$: $\frac{3}{4} + \frac{1}{2} + 3 = \frac{17}{4}$."),
               (r"$\frac{7}{2}$", r"Takes $\cos 45^\circ = \frac{1}{2}$: $\frac{1}{4} + \frac{1}{4} + 3 = \frac{7}{2}$.")],
  check=_c001, values=[Rational(15, 4), Rational(13, 12), Rational(17, 4), Rational(7, 2)], cognitive="Recall")


# 002
def _c002():
    L = 120
    return nsimplify(L * sin(_rad(30)))
_f = Fig()
_O = _f.pt("", 0, 0); _K = _f.pt("", 120 * _m.cos(_m.radians(30)), 60); _F = _f.pt("", 120 * _m.cos(_m.radians(30)), 0, dot=False)
_f.seg((-8, 0), (112, 0)); _f.seg(_O, _K); _f.seg(_K, _F, dashed=True)
_f.right_angle(_O, _F, _K); _f.angle_mark(_F, _O, _K, "30^\\circ"); _f.label_seg(_O, _K, "120 m")
_f.text((_K["xy"][0], _K["xy"][1] + 7), "kite")
_alt = "A straight kite string of length 120 m rises from a point on level ground to the kite, making an angle of 30 degrees with the ground; a dashed vertical drops from the kite to the ground."
q("C20-A-002", T_, "Height of a kite from string length and angle", "Easy",
  "Single-step computation",
  r"A kite is flying at the end of a taut, straight string of length $120$ m. The lower end of the string is held at ground level, and the string makes an angle of $30^\circ$ with the level ground. At what height above the ground is the kite, in metres?",
  "TITA",
  r"The string is the hypotenuse and the height is the side opposite the $30^\circ$ angle. Height $= 120 \sin 30^\circ = 120 \times \frac{1}{2} = 60$ m.",
  "Using cosine instead of sine, or dividing by the sine instead of multiplying.",
  "C20A-single-right-triangle", "One right triangle with a standard angle; the only trap is choosing sine.",
  tita_answer=60, check=_c002,
  tita_traps=[(104, r"Uses $120 \cos 30^\circ = 60\sqrt{3} \approx 103.9$ and rounds."),
              (240, r"Divides by $\sin 30^\circ$ instead of multiplying: $\frac{120}{1/2} = 240$.")],
  cognitive="Application", figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 003
def _c003():
    h = 45
    x = symbols('x', positive=True)
    return solve(Eq(tan(_rad(30)), h / x), x)[0]
_f = Fig()
_s3 = _m.sqrt(3)
_T = _f.pt("", 0, 45); _F = _f.pt("", 0, 0); _B = _f.pt("", 45 * _s3, 0); _H = _f.pt("", 45 * _s3, 45, dot=False)
_f.seg((-6, 0), (45 * _s3 + 8, 0)); _f.seg(_F, _T); _f.seg(_T, _B); _f.seg(_T, _H, dashed=True)
_f.right_angle(_T, _F, _B); _f.angle_mark(_H, _T, _B, "30^\\circ"); _f.text((-7, 22.5), "45 m")
_f.text((45 * _s3, -6), "boat")
_alt = "A vertical lighthouse 45 m high on level shore; a dashed horizontal line from its top and a line of sight down to a boat at an angle of depression of 30 degrees."
q("C20-A-003", T_, "Distance of a boat from a lighthouse using angle of depression", "Easy",
  "Single-step computation",
  r"From the top of a lighthouse $45$ m high, standing on the sea shore, the angle of depression of a boat is $30^\circ$. The boat and the foot of the lighthouse are at the same level. How far is the boat from the foot of the lighthouse?",
  "MCQ",
  r"The angle of depression from the top equals the angle of elevation of the top from the boat, so $\tan 30^\circ = \frac{45}{x}$. Hence $x = 45 \cot 30^\circ = 45\sqrt{3}$ m.",
  r"Multiplying by $\tan 30^\circ$ instead of dividing, or treating the given height as a slant length.",
  "C20A-depression-single", "One right triangle; the trap is converting depression to elevation and using cot.",
  correct=r"$45\sqrt{3}$ m",
  distractors=[(r"$15\sqrt{3}$ m", r"Computes $45 \tan 30^\circ = 15\sqrt{3}$, multiplying by the tangent instead of dividing."),
               (r"$\frac{45\sqrt{3}}{2}$ m", r"Treats $45$ m as the line of sight and takes its horizontal part: $45 \cos 30^\circ = \frac{45\sqrt{3}}{2}$."),
               (r"$30\sqrt{3}$ m", r"Divides the height by $\cos 30^\circ$: $\frac{45}{\sqrt{3}/2} = 30\sqrt{3}$.")],
  check=_c003, values=[45 * sqrt(3), 15 * sqrt(3), 45 * sqrt(3) / 2, 30 * sqrt(3)], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 004
def _c004():
    # shadow = sqrt(3) * height; tan(altitude) = height / shadow; search integer degrees
    for d in range(1, 90):
        if simplify(tan(_rad(d)) - 1 / sqrt(3)) == 0:
            return d
q("C20-A-004", T_, "Sun's altitude from the shadow to height ratio", "Easy",
  "Conceptual/application",
  r"At a certain time of day, the shadow of a vertical pole on level ground is $\sqrt{3}$ times as long as the pole. What is the angle of elevation of the sun at that time, in degrees?",
  "TITA",
  r"If the pole has height $h$, the shadow has length $\sqrt{3}h$, and the sun's altitude $\theta$ satisfies $\tan \theta = \frac{h}{\sqrt{3}h} = \frac{1}{\sqrt{3}}$. So $\theta = 30^\circ$.",
  "Writing $\\tan \\theta = \\frac{\\text{shadow}}{\\text{height}}$, which gives $60^\\circ$.",
  "C20A-shadow", "One ratio and one standard angle; trap is inverting the tangent ratio.",
  tita_answer=30, check=_c004,
  tita_traps=[(60, r"Takes $\tan \theta = \frac{\text{shadow}}{\text{height}} = \sqrt{3}$.")],
  cognitive="Understanding")


# 005
def _c005():
    th = atan(Rational(3, 4))
    return nsimplify(simplify((sin(th) + cos(th)) / (sin(th) - cos(th))))
q("C20-A-005", T_, "Value of a sine-cosine ratio given tan", "Easy",
  "Single-step computation",
  r"If $\theta$ is an acute angle with $\tan \theta = \frac{3}{4}$, then $\frac{\sin \theta + \cos \theta}{\sin \theta - \cos \theta}$ equals",
  "MCQ",
  r"Divide numerator and denominator by $\cos \theta$: the expression becomes $\frac{\tan \theta + 1}{\tan \theta - 1} = \frac{7/4}{-1/4} = -7$.",
  r"Losing the sign of the denominator, since $\sin \theta < \cos \theta$ here.",
  "C20A-tan-ratio-expression", "One division trick; the trap is the negative denominator.",
  correct=r"$-7$",
  distractors=[(r"$7$", r"Writes the denominator as $1 - \tan \theta = \frac{1}{4}$, dropping the sign."),
               (r"$-\frac{1}{7}$", r"Inverts the expression and evaluates $\frac{\tan \theta - 1}{\tan \theta + 1}$."),
               (r"$\frac{7}{5}$", r"Evaluates only the numerator $\sin \theta + \cos \theta = \frac{3}{5} + \frac{4}{5}$.")],
  check=_c005, values=[-7, 7, Rational(-1, 7), Rational(7, 5)], cognitive="Application")


# 006
def _c006():
    y = symbols('y', positive=True)
    return solve(Eq(tan(_rad(60)), y / 6), y)[0]
q("C20-A-006", T_, "Height reached by a ladder from foot distance and angle", "Easy",
  "Single-step computation",
  r"A ladder leans against a vertical wall and makes an angle of $60^\circ$ with the level ground. The foot of the ladder is $6$ m from the wall. How high up the wall does the top of the ladder reach?",
  "MCQ",
  r"The height $y$ is opposite the $60^\circ$ angle and the $6$ m is adjacent to it, so $y = 6 \tan 60^\circ = 6\sqrt{3}$ m.",
  "Using the wrong ratio or treating the given $6$ m as the ladder's length.",
  "C20A-single-right-triangle", "One right triangle; trap is picking the correct ratio for opposite over adjacent.",
  correct=r"$6\sqrt{3}$ m",
  distractors=[(r"$2\sqrt{3}$ m", r"Uses $6 \tan 30^\circ = 2\sqrt{3}$, the angle at the top of the ladder."),
               (r"$3\sqrt{3}$ m", r"Treats $6$ m as the ladder's length: $6 \sin 60^\circ = 3\sqrt{3}$."),
               (r"$4\sqrt{3}$ m", r"Divides by $\cos 30^\circ$: $\frac{6}{\sqrt{3}/2} = 4\sqrt{3}$.")],
  check=_c006, values=[6 * sqrt(3), 2 * sqrt(3), 3 * sqrt(3), 4 * sqrt(3)], cognitive="Application")


# 007
def _c007():
    sols = []
    for x in range(1, 90):
        for y in range(1, x):
            if abs(_m.sin(_m.radians(x + y)) - 1) < 1e-12 and abs(_m.cos(_m.radians(x - y)) - _m.sqrt(3) / 2) < 1e-12:
                sols.append(x)
    assert len(sols) == 1
    return sols[0]
q("C20-A-007", T_, "Solving for angles from sin of a sum and cos of a difference", "Easy",
  "Inverse/parameter",
  r"Angles $x$ and $y$, measured in degrees, satisfy $0^\circ < y < x < 90^\circ$, $\sin(x + y) = 1$ and $\cos(x - y) = \frac{\sqrt{3}}{2}$. What is the value of $x$, in degrees?",
  "TITA",
  r"Since $0^\circ < x + y < 180^\circ$, $\sin(x + y) = 1$ gives $x + y = 90^\circ$. Since $0^\circ < x - y < 90^\circ$, $\cos(x - y) = \frac{\sqrt{3}}{2}$ gives $x - y = 30^\circ$. Adding, $2x = 120^\circ$, so $x = 60^\circ$.",
  "Mixing up $\\cos 30^\\circ$ and $\\cos 60^\\circ$, or reporting $y$.",
  "C20A-std-angle-values", "Two standard-value recalls and a pair of linear equations.",
  tita_answer=60, check=_c007,
  tita_traps=[(30, r"Reports $y$ instead of $x$."),
              (75, r"Takes $x - y = 60^\circ$, so $x = \frac{90 + 60}{2} = 75$.")],
  cognitive="Application")


# 008
def _c008():
    h = symbols('h', positive=True)
    return solve(Eq(h * _ct(30) - h * _ct(60), 50), h)[0]
_f = Fig()
_h8 = 25 * _s3
_P = _f.pt("P", -_h8 * _s3, 0, offset=(0, -1.1)); _Q = _f.pt("Q", -_h8 / _s3, 0, offset=(0, -1.1))
_Ft = _f.pt("", 0, 0); _Tt = _f.pt("", 0, _h8)
_f.seg((-_h8 * _s3 - 5, 0), (6, 0)); _f.seg(_Ft, _Tt); _f.seg(_P, _Tt); _f.seg(_Q, _Tt)
_f.right_angle(_Q, _Ft, _Tt)
_f.angle_mark(_Ft, _P, _Tt, "30^\\circ"); _f.angle_mark(_Ft, _Q, _Tt, "60^\\circ")
_f.label_seg(_P, _Q, "50 m", side=-1)
_alt = "Level ground with points P and Q in line with the foot of a vertical tower, P farther away; PQ = 50 m; elevation of the top is 30 degrees from P and 60 degrees from Q."
q("C20-A-008", T_, "Tower height when an observer walks towards it", "Easy",
  "Multi-step word problem",
  r"Sneha stands at a point P on level ground, in line with the foot of a vertical tower, and sees the top of the tower at an angle of elevation of $30^\circ$. She walks $50$ m straight towards the tower to a point Q, from where the angle of elevation of the top is $60^\circ$. What is the height of the tower?",
  "MCQ",
  r"In the triangle formed by P, Q and the top, the angle at the top is $60^\circ - 30^\circ = 30^\circ$, equal to the angle at P, so the line from Q to the top is also $50$ m. Hence the height is $50 \sin 60^\circ = 25\sqrt{3}$ m. (Equivalently, $h(\cot 30^\circ - \cot 60^\circ) = h \cdot \frac{2}{\sqrt{3}} = 50$.)",
  "Taking the 50 m walk as a distance from the foot, or using a difference of tangents in place of cotangents.",
  "C20A-two-angles-same-side", "Two right triangles sharing the height; quick via the isosceles triangle.",
  correct=r"$25\sqrt{3}$ m",
  distractors=[(r"$50\sqrt{3}$ m", r"Assumes Q is $50$ m from the foot: $50 \tan 60^\circ = 50\sqrt{3}$."),
               (r"$\frac{50\sqrt{3}}{3}$ m", r"Assumes P is $50$ m from the foot: $50 \tan 30^\circ = \frac{50}{\sqrt{3}}$."),
               (r"$\frac{100\sqrt{3}}{3}$ m", r"Uses $h = 50(\tan 60^\circ - \tan 30^\circ) = 50 \cdot \frac{2}{\sqrt{3}}$, tangents in place of cotangents.")],
  check=_c008, values=[25 * sqrt(3), 50 * sqrt(3), 50 * sqrt(3) / 3, 100 * sqrt(3) / 3], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 009
def _c009():
    t = symbols('t', real=True)
    # sec = sqrt(1 + tan^2) for acute angle
    sols = solve(Eq(sqrt(1 + t ** 2) + t, 3), t)
    t0 = [s for s in sols if s > 0][0]
    return nsimplify(sqrt(1 + t0 ** 2))
q("C20-A-009", T_, "Using sec^2 - tan^2 = 1 with a given sum", "Easy",
  "Single-step computation",
  r"For an acute angle $\theta$, $\sec \theta + \tan \theta = 3$. The value of $\sec \theta$ is",
  "MCQ",
  r"Since $\sec^2 \theta - \tan^2 \theta = 1$, we get $\sec \theta - \tan \theta = \frac{1}{3}$. Adding the two equations, $2 \sec \theta = 3 + \frac{1}{3} = \frac{10}{3}$, so $\sec \theta = \frac{5}{3}$.",
  "Forgetting to halve after adding, or reporting $\\tan \\theta$ or $\\cos \\theta$.",
  "C20A-sec-tan-pair", "One identity and one addition step.",
  correct=r"$\frac{5}{3}$",
  distractors=[(r"$\frac{4}{3}$", r"Subtracts the equations and reports $\tan \theta = \frac{1}{2}(3 - \frac{1}{3})$."),
               (r"$\frac{3}{5}$", r"Reports $\cos \theta$, the reciprocal of the required value."),
               (r"$\frac{10}{3}$", r"Adds the two equations but does not divide by $2$.")],
  check=_c009, values=[Rational(5, 3), Rational(4, 3), Rational(3, 5), Rational(10, 3)], cognitive="Application")


# =====================================================================
# MEDIUM
# =====================================================================

# 010
def _c010():
    h = symbols('h', positive=True)
    hv = solve(Eq(h * _ct(30) - h * _ct(60), 30), h)[0]
    return nsimplify(simplify(hv * _ct(60)))
q("C20-A-010", T_, "Shadow length at two sun altitudes", "Medium",
  "Conceptual/application",
  r"The shadow of a vertical tower on level ground is $30$ m longer when the sun's altitude is $30^\circ$ than when it is $60^\circ$. What is the length of the shadow, in metres, when the sun's altitude is $60^\circ$?",
  "TITA",
  r"For height $h$, the shadows are $h \cot 60^\circ = \frac{h}{\sqrt{3}}$ and $h \cot 30^\circ = \sqrt{3}h$, so the longer one is exactly $3$ times the shorter. If the shorter is $s$, then $3s - s = 30$, giving $s = 15$ m.",
  "Reporting the longer shadow or the tower's height instead of the shorter shadow.",
  "C20A-two-angles-same-side", "Needs the insight that the two shadows are in ratio $3 : 1$; otherwise surds must be handled.",
  tita_answer=15, check=_c010,
  tita_traps=[(45, r"Reports the shadow at $30^\circ$, which is $3 \times 15$."),
              (26, r"Finds the height $15\sqrt{3} \approx 25.98$ and rounds.")],
  cognitive="Analysis")


# 011
def _c011():
    h = 60
    return nsimplify(h * _ct(30) + h * _ct(45))
_f = Fig()
_K = _f.pt("", -60 * _s3, 0); _M = _f.pt("", 60, 0); _Fo = _f.pt("", 0, 0); _To = _f.pt("", 0, 60)
_f.seg((-60 * _s3 - 6, 0), (66, 0)); _f.seg(_Fo, _To); _f.seg(_K, _To); _f.seg(_M, _To)
_f.right_angle(_K, _Fo, _To)
_f.angle_mark(_Fo, _K, _To, "30^\\circ"); _f.angle_mark(_Fo, _M, _To, "45^\\circ")
_f.label_seg(_Fo, _To, "60 m", side=-1)
_f.text((-60 * _s3, -7), "Kabir"); _f.text((60, -7), "Meera")
_alt = "A vertical tower 60 m high with Kabir on the left and Meera on the right on level ground, in line with its foot; elevation of the top is 30 degrees from Kabir and 45 degrees from Meera."
q("C20-A-011", T_, "Distance between two observers on opposite sides of a tower", "Medium",
  "Multi-step word problem",
  r"A vertical tower is $60$ m high. Kabir and Meera stand on level ground on opposite sides of the tower, in a straight line with its foot. The angle of elevation of the top of the tower is $30^\circ$ from Kabir's position and $45^\circ$ from Meera's. How far apart are Kabir and Meera?",
  "MCQ",
  r"Kabir is $60 \cot 30^\circ = 60\sqrt{3}$ m from the foot and Meera is $60 \cot 45^\circ = 60$ m from it. Being on opposite sides, they are $60\sqrt{3} + 60 = 60(\sqrt{3} + 1)$ m apart.",
  "Subtracting the distances as if both were on the same side, or using tan where cot is needed.",
  "C20A-opposite-sides", "Two right triangles; the traps are the side arrangement and cot versus tan.",
  correct=r"$60(\sqrt{3} + 1)$ m",
  distractors=[(r"$60(\sqrt{3} - 1)$ m", r"Treats both observers as on the same side and subtracts the distances."),
               (r"$20(\sqrt{3} + 3)$ m", r"Takes Kabir's distance as $60 \tan 30^\circ = 20\sqrt{3}$, then adds $60$."),
               (r"$20(3 - \sqrt{3})$ m", r"Takes Kabir's distance as $60 \tan 30^\circ = 20\sqrt{3}$ and also subtracts: $60 - 20\sqrt{3}$.")],
  check=_c011, values=[60 * (sqrt(3) + 1), 60 * (sqrt(3) - 1), 20 * (sqrt(3) + 3), 20 * (3 - sqrt(3))], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 012
def _c012():
    h, t = symbols('h t', positive=True)
    # tan(alpha) = h/5, tan(90 - alpha) = h/45  =>  (h/5)(h/45) = 1
    return solve(Eq((h / 5) * (h / 45), 1), h)[0]
q("C20-A-012", T_, "Complementary angles of elevation give a geometric mean height", "Medium",
  "Conceptual/application",
  r"Ravi and Harpreet stand on level ground on the same side of a vertical pole, in line with its foot, at distances of $5$ m and $45$ m from the foot respectively. The angles of elevation of the top of the pole from their two positions are complementary. What is the height of the pole?",
  "MCQ",
  r"Let the angles be $\alpha$ and $90^\circ - \alpha$. Then $\tan \alpha = \frac{h}{5}$ and $\tan(90^\circ - \alpha) = \cot \alpha = \frac{h}{45}$. Multiplying, $\frac{h^2}{225} = 1$, so $h = 15$ m, the geometric mean of the two distances.",
  "Using the arithmetic mean or a sum or difference of the distances.",
  "C20A-complementary-angles", "Requires spotting $\\tan \\alpha \\cot \\alpha = 1$ to get $h^2 = 5 \\times 45$.",
  correct=r"$15$ m",
  distractors=[(r"$25$ m", r"Takes the arithmetic mean $\frac{5 + 45}{2}$ instead of the geometric mean."),
               (r"$40$ m", r"Takes the height as the difference of the distances, $45 - 5$."),
               (r"$50$ m", r"Takes the height as the sum of the distances, $5 + 45$.")],
  check=_c012, values=[15, 25, 40, 50], cognitive="Understanding")


# 013
def _c013():
    b = 20
    d = b * _ct(30)          # horizontal distance from depression of the foot
    return nsimplify(simplify(b + d * _tn(60)))
_f = Fig()
_d13 = 20 * _s3
_f.poly((-6, 0), (0, 0), (0, 20), (-6, 20))
_Bt = _f.pt("", 0, 20); _Tf = _f.pt("", _d13, 0); _Tt = _f.pt("", _d13, 80); _Hh = _f.pt("", _d13, 20, dot=False)
_f.seg((-10, 0), (_d13 + 6, 0)); _f.seg(_Tf, _Tt); _f.seg(_Bt, _Tt); _f.seg(_Bt, _Tf); _f.seg(_Bt, _Hh, dashed=True)
_f.angle_mark(_Hh, _Bt, _Tt, "60^\\circ"); _f.angle_mark(_Tf, _Bt, _Hh, "30^\\circ")
_f.text((-12, 10), "20 m")
_f.text((-10, 24), "building"); _f.text((_d13 + 7, 40), "tower")
_alt = "A 20 m building and a vertical tower on level ground; from the top of the building a dashed horizontal line, with elevation 60 degrees to the tower top and depression 30 degrees to the tower foot."
q("C20-A-013", T_, "Tower height from elevation and depression seen from a building", "Medium",
  "Multi-step word problem",
  r"From the top of a building $20$ m high, the angle of elevation of the top of a vertical tower is $60^\circ$ and the angle of depression of the foot of the tower is $30^\circ$. The building and the tower stand on the same level ground. What is the height of the tower, in metres?",
  "TITA",
  r"The depression of the foot gives the horizontal gap: $d = 20 \cot 30^\circ = 20\sqrt{3}$ m. The part of the tower above the level of the building's top is $d \tan 60^\circ = 20\sqrt{3} \times \sqrt{3} = 60$ m. The tower's height is $20 + 60 = 80$ m.",
  "Reporting only the part of the tower above the building's top, or using tan for the horizontal gap.",
  "C20A-two-buildings", "Two linked right triangles through the common horizontal distance.",
  tita_answer=80, check=_c013,
  tita_traps=[(60, r"Reports only the part above the level of the building's top."),
              (40, r"Takes the gap as $20 \tan 30^\circ = \frac{20}{\sqrt{3}}$, so the upper part is $20$ and the total $40$.")],
  cognitive="Application", figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 014
def _c014():
    h, x = symbols('h x', positive=True)
    s = solve([Eq(h, x * _tn(45)), Eq(h + 10, x * _tn(60))], [h, x], dict=True)[0]
    return radsimp(s[h])
q("C20-A-014", T_, "Building height from elevations of a flagpole's bottom and top", "Medium",
  "Multi-step word problem",
  r"A flagpole $10$ m tall stands vertically on the flat roof of a building, at the edge of the roof nearest to a point $P$ on the level ground. From $P$, the angles of elevation of the bottom and the top of the flagpole are $45^\circ$ and $60^\circ$ respectively. What is the height of the building?",
  "MCQ",
  r"Let the building be $h$ m high and the point be $x$ m from it. Then $h = x \tan 45^\circ = x$ and $h + 10 = x\sqrt{3}$. Subtracting, $x(\sqrt{3} - 1) = 10$, so $h = \frac{10}{\sqrt{3} - 1} = \frac{10(\sqrt{3} + 1)}{2} = 5(\sqrt{3} + 1)$ m.",
  "Slips in rationalising, or reporting the height of the top of the flagpole.",
  "C20A-flagpole-on-building", "Two equations with a shared base and a rationalisation step.",
  correct=r"$5(\sqrt{3} + 1)$ m",
  distractors=[(r"$5(\sqrt{3} - 1)$ m", r"Rationalises $\frac{10}{\sqrt{3} - 1}$ with a sign slip, getting $\frac{10(\sqrt{3} - 1)}{2}$."),
               (r"$10(\sqrt{3} + 1)$ m", r"Multiplies by $\sqrt{3} + 1$ but forgets to divide by $(\sqrt{3})^2 - 1 = 2$."),
               (r"$5(3 + \sqrt{3})$ m", r"Reports the height of the top of the flagpole, $5(\sqrt{3} + 1) + 10$.")],
  check=_c014, values=[5 * (sqrt(3) + 1), 5 * (sqrt(3) - 1), 10 * (sqrt(3) + 1), 5 * (3 + sqrt(3))], cognitive="Application")


# 015
def _c015():
    # simulate: cliff height 1 (scale-free); speed fixed by first 18 minutes
    h = 1
    x1, x2 = h * _ct(30), h * _ct(60)
    v = (x1 - x2) / 18
    return nsimplify(simplify(x2 / v))
q("C20-A-015", T_, "Remaining time for a boat approaching a cliff", "Medium",
  "Multi-step word problem",
  r"A man standing on top of a vertical cliff watches a boat that is moving at a constant speed in a straight line directly towards the foot of the cliff. The angle of depression of the boat changes from $30^\circ$ to $60^\circ$ in $18$ minutes. How many more minutes will the boat take to reach the foot of the cliff?",
  "TITA",
  r"For cliff height $h$, the boat's distance from the foot changes from $h\sqrt{3}$ to $\frac{h}{\sqrt{3}}$, a drop of $\frac{2h}{\sqrt{3}}$ in $18$ minutes. The remaining distance $\frac{h}{\sqrt{3}}$ is half of that, so it takes $9$ more minutes.",
  "Assuming the remaining time equals the time already taken, or reporting the total time.",
  "C20A-moving-boat-time", "Height is unknown and cancels; requires comparing two distances in ratio.",
  tita_answer=9, check=_c015,
  tita_traps=[(18, r"Assumes the remaining stretch takes as long as the first."),
              (27, r"Reports the total time from the first sighting, $18 + 9$.")],
  cognitive="Analysis")


# 016
def _c016():
    H = 1500 * sqrt(3)
    d = H * _ct(30) - H * _ct(60)       # metres in 15 s
    v = d / 15                            # m/s
    return nsimplify(simplify(v * Rational(18, 5)))
_f = Fig()
_H16 = 1500 * _s3
_O = _f.pt("", 0, 0); _A1 = _f.pt("", 1500, _H16); _A2 = _f.pt("", 4500, _H16)
_f.seg((-200, 0), (4700, 0)); _f.seg(_O, _A1); _f.seg(_O, _A2); _f.seg(_A1, _A2, dashed=True)
_f.seg(_A1, (1500, 0), dashed=True)
_f.angle_mark((4700, 0), _O, _A2, "30^\\circ", r=1000); _f.angle_mark((4700, 0), _O, _A1, "", r=450); _f.text((60, 640), "60^\\circ")
_f.text((2250, 1950), "1500\u221a3 m")
_f.text((-150, -220), "observer")
_alt = "An observer on level ground sees an aeroplane flying horizontally at height 1500 root 3 m; its angle of elevation is first 60 degrees and later 30 degrees."
q("C20-A-016", T_, "Speed of a horizontally flying aeroplane from two elevations", "Medium",
  "Multi-step word problem",
  r"An aeroplane flies horizontally in a straight line at a constant height of $1500\sqrt{3}$ m and at a constant speed, moving directly away from an observer standing on level ground, in the vertical plane through the observer. The angle of elevation of the aeroplane from the observer changes from $60^\circ$ to $30^\circ$ in $15$ seconds. What is the speed of the aeroplane, in km/h?",
  "TITA",
  r"The horizontal distances are $1500\sqrt{3} \cot 60^\circ = 1500$ m and $1500\sqrt{3} \cot 30^\circ = 4500$ m, so the plane covers $3000$ m in $15$ s, that is $200$ m/s. In km/h this is $200 \times \frac{18}{5} = 720$.",
  "Leaving the answer in m/s, or using a single horizontal distance as the distance flown.",
  "C20A-aeroplane-speed", "Two right triangles, a difference and a unit conversion.",
  tita_answer=720, check=_c016,
  tita_traps=[(200, r"Leaves the speed in m/s."),
              (1080, r"Uses the whole horizontal distance $4500$ m at $30^\circ$ as the distance flown: $300$ m/s.")],
  cognitive="Application", figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 017
def _c017():
    th = symbols('th', positive=True)
    s, c = symbols('s c', positive=True)
    sols = solve([Eq(s + c, Rational(7, 5)), Eq(s ** 2 + c ** 2, 1)], [s, c], dict=True)
    vals = set(simplify(d[s] / d[c] + d[c] / d[s]) for d in sols)
    assert len(vals) == 1
    return vals.pop()
q("C20-A-017", T_, "tan + cot from a given sin + cos via squaring", "Medium",
  "Multi-step word problem",
  r"For an acute angle $\theta$, $\sin \theta + \cos \theta = \frac{7}{5}$. The value of $\tan \theta + \cot \theta$ is",
  "MCQ",
  r"Squaring, $1 + 2\sin \theta \cos \theta = \frac{49}{25}$, so $\sin \theta \cos \theta = \frac{12}{25}$. Now $\tan \theta + \cot \theta = \frac{\sin^2 \theta + \cos^2 \theta}{\sin \theta \cos \theta} = \frac{1}{\sin \theta \cos \theta} = \frac{25}{12}$.",
  "Stopping at $\\sin \\theta \\cos \\theta$ or $2 \\sin \\theta \\cos \\theta$, or inverting the wrong quantity.",
  "C20A-sum-square-identity", "Squaring plus the identity $\\tan + \\cot = \\frac{1}{\\sin \\cos}$; two linked steps.",
  correct=r"$\frac{25}{12}$",
  distractors=[(r"$\frac{12}{25}$", r"Reports $\sin \theta \cos \theta$ itself."),
               (r"$\frac{24}{25}$", r"Reports $2 \sin \theta \cos \theta = \frac{49}{25} - 1$."),
               (r"$\frac{25}{24}$", r"Takes the reciprocal of $2 \sin \theta \cos \theta$ instead of $\sin \theta \cos \theta$.")],
  check=_c017, values=[Rational(25, 12), Rational(12, 25), Rational(24, 25), Rational(25, 24)], cognitive="Application")


# 018
def _c018():
    t = symbols('t', real=True)
    sols = [s for s in solve(Eq(3 * sin(t) + 4 * cos(t), 5), t) if 0 < s.evalf() < pi.evalf() / 2]
    vals = set(nsimplify(simplify(tan(s))) for s in sols)
    assert len(vals) == 1
    return vals.pop()
q("C20-A-018", T_, "tan from a linear combination of sin and cos at its maximum", "Medium",
  "Inverse/parameter",
  r"For an acute angle $\theta$, $3 \sin \theta + 4 \cos \theta = 5$. The value of $\tan \theta$ is",
  "MCQ",
  r"Note $(3 \sin \theta + 4 \cos \theta)^2 + (3 \cos \theta - 4 \sin \theta)^2 = 9 + 16 = 25$. Since the first term is $25$, $3 \cos \theta - 4 \sin \theta = 0$, so $\tan \theta = \frac{3}{4}$. (Indeed $\sin \theta = \frac{3}{5}$, $\cos \theta = \frac{4}{5}$ gives $\frac{9}{5} + \frac{16}{5} = 5$.)",
  "Matching $3$ with $\\cos$ and $4$ with $\\sin$, or reporting $\\sin \\theta$ or $\\cos \\theta$.",
  "C20A-linear-combo-identity", "Needs the companion-square identity or recognising the maximum value $5$.",
  correct=r"$\frac{3}{4}$",
  distractors=[(r"$\frac{4}{3}$", r"Pairs $4$ with $\sin \theta$ and $3$ with $\cos \theta$, getting $\cot \theta$ instead."),
               (r"$\frac{3}{5}$", r"Reports $\sin \theta$."),
               (r"$\frac{4}{5}$", r"Reports $\cos \theta$.")],
  check=_c018, values=[Rational(3, 4), Rational(4, 3), Rational(3, 5), Rational(4, 5)], cognitive="Analysis")


# 019
def _c019():
    h = symbols('h', positive=True)
    hv = solve(Eq(h * _ct(30) + h * _ct(60), 100), h)[0]
    return nsimplify(simplify(hv * _ct(30)))
q("C20-A-019", T_, "Locating an observer when two observers on opposite sides are a known distance apart", "Medium",
  "Inverse/parameter",
  r"Arjun and Priya stand on level ground on opposite sides of a vertical tower, in a straight line with its foot, and are $100$ m apart. The angle of elevation of the top of the tower is $30^\circ$ from Arjun's position and $60^\circ$ from Priya's. How far is Arjun from the foot of the tower, in metres?",
  "TITA",
  r"For height $h$, Arjun is $h\sqrt{3}$ m and Priya is $\frac{h}{\sqrt{3}}$ m from the foot, so their distances are in ratio $3 : 1$. Splitting $100$ m in ratio $3 : 1$, Arjun is $75$ m from the foot.",
  "Reporting Priya's distance or the tower's height.",
  "C20A-opposite-sides", "Ratio insight $\\cot 30^\\circ : \\cot 60^\\circ = 3 : 1$ avoids solving for the height.",
  tita_answer=75, check=_c019,
  tita_traps=[(25, r"Reports Priya's distance, the smaller share."),
              (43, r"Reports the height $25\sqrt{3} \approx 43.3$, rounded.")],
  cognitive="Application")


# 020
def _c020():
    H = 30
    x1, x2 = H * _ct(45), H * _ct(60)
    return nsimplify(simplify(x1 - x2))
q("C20-A-020", T_, "Distance between two cars seen from a tower at two depressions", "Medium",
  "Multi-step word problem",
  r"From the top of a vertical tower $30$ m high, the angles of depression of two cars on a straight level road that leads to the foot of the tower are $45^\circ$ and $60^\circ$. Both cars are on the same side of the tower. What is the distance between the two cars?",
  "MCQ",
  r"The cars are $30 \cot 45^\circ = 30$ m and $30 \cot 60^\circ = 10\sqrt{3}$ m from the foot. On the same side, the gap is $30 - 10\sqrt{3} = 10(3 - \sqrt{3})$ m.",
  "Adding the distances, using tan instead of cot, or reporting one car's distance.",
  "C20A-two-angles-same-side", "Two right triangles sharing the height, with a cot-versus-tan trap.",
  correct=r"$10(3 - \sqrt{3})$ m",
  distractors=[(r"$10(3 + \sqrt{3})$ m", r"Adds the distances as if the cars were on opposite sides."),
               (r"$30(\sqrt{3} - 1)$ m", r"Uses $30 \tan 60^\circ - 30 \tan 45^\circ$, tangents in place of cotangents."),
               (r"$10\sqrt{3}$ m", r"Reports the distance of the nearer car from the foot.")],
  check=_c020, values=[10 * (3 - sqrt(3)), 10 * (3 + sqrt(3)), 30 * (sqrt(3) - 1), 10 * sqrt(3)], cognitive="Application")


# 021
def _c021():
    H, s = symbols('H s', positive=True)
    sol = solve([Eq(H, 30 * _tn(60)), Eq(H - s, 30 * _tn(30))], [H, s], dict=True)[0]
    return simplify(sol[s])
_f = Fig()
_H21 = 30 * _s3; _s21 = 20 * _s3
_f.poly((-4, 0), (0, 0), (0, _s21), (-4, _s21)); _f.poly((30, 0), (34, 0), (34, _H21), (30, _H21))
_Sf = _f.pt("", 0, 0); _St = _f.pt("", 0, _s21); _Tt = _f.pt("", 30, _H21); _Hz = _f.pt("", 30, _s21, dot=False)
_f.seg((-8, 0), (38, 0)); _f.seg(_Sf, _Tt); _f.seg(_St, _Tt); _f.seg(_St, _Hz, dashed=True)
_f.angle_mark((30, 0), _Sf, _Tt, "60^\\circ", r=4.5); _f.angle_mark(_Hz, _St, _Tt, "30^\\circ", r=6)
_f.label_seg(_Sf, (30, 0), "30 m", side=-1)
_alt = "Two vertical buildings on level ground 30 m apart; from the foot of the shorter the top of the taller is seen at 60 degrees, and from the top of the shorter at 30 degrees."
q("C20-A-021", T_, "Height of the shorter building from two elevations of the taller one", "Medium",
  "Multi-step word problem",
  r"Two vertical buildings stand on level ground, $30$ m apart. From the foot of the shorter building, the angle of elevation of the top of the taller building is $60^\circ$; from the top of the shorter building, it is $30^\circ$. What is the height of the shorter building?",
  "MCQ",
  r"The taller building is $30 \tan 60^\circ = 30\sqrt{3}$ m high. From the top of the shorter one, the taller rises a further $30 \tan 30^\circ = 10\sqrt{3}$ m. So the shorter building is $30\sqrt{3} - 10\sqrt{3} = 20\sqrt{3}$ m high.",
  "Reporting the difference in heights or the taller height, or adding instead of subtracting.",
  "C20A-two-buildings", "Two right triangles on one horizontal base, then a subtraction.",
  correct=r"$20\sqrt{3}$ m",
  distractors=[(r"$10\sqrt{3}$ m", r"Reports the difference in heights, $30 \tan 30^\circ$."),
               (r"$30\sqrt{3}$ m", r"Reports the height of the taller building."),
               (r"$40\sqrt{3}$ m", r"Adds the difference to the taller height instead of subtracting.")],
  check=_c021, values=[20 * sqrt(3), 10 * sqrt(3), 30 * sqrt(3), 40 * sqrt(3)], cognitive="Application",
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 022
def _c022():
    L = symbols('L', positive=True)
    return radsimp(solve(Eq(L * sin(_rad(60)) - L * sin(_rad(30)), 6), L)[0])
q("C20-A-022", T_, "Ladder length from the drop of its top as the angle changes", "Medium",
  "Multi-step word problem",
  r"A ladder rests against a vertical wall, making an angle of $60^\circ$ with the level ground. The top of the ladder slides down the wall until the ladder makes an angle of $30^\circ$ with the ground, and in doing so the top moves down by $6$ m. What is the length of the ladder?",
  "MCQ",
  r"For length $L$, the top's height changes from $L \sin 60^\circ$ to $L \sin 30^\circ$, so $L \cdot \frac{\sqrt{3} - 1}{2} = 6$. Hence $L = \frac{12}{\sqrt{3} - 1} = \frac{12(\sqrt{3} + 1)}{2} = 6(\sqrt{3} + 1)$ m.",
  "Slips in rationalising the denominator $\\sqrt{3} - 1$.",
  "C20A-ladder-slide", "Two positions of a fixed length plus rationalisation.",
  correct=r"$6(\sqrt{3} + 1)$ m",
  distractors=[(r"$6(\sqrt{3} - 1)$ m", r"Rationalises $\frac{12}{\sqrt{3} - 1}$ with a sign slip, multiplying by $\sqrt{3} - 1$."),
               (r"$12(\sqrt{3} + 1)$ m", r"Multiplies by $\sqrt{3} + 1$ but forgets to divide by $(\sqrt{3})^2 - 1 = 2$."),
               (r"$3(\sqrt{3} + 1)$ m", r"Takes $(\sqrt{3} - 1)(\sqrt{3} + 1)$ as $4$ instead of $2$.")],
  check=_c022, values=[6 * (sqrt(3) + 1), 6 * (sqrt(3) - 1), 12 * (sqrt(3) + 1), 3 * (sqrt(3) + 1)], cognitive="Application")


# 023
def _c023():
    s = sum(_m.sin(_m.radians(d)) ** 2 for d in range(3, 88, 3))
    return Rational(round(2 * s), 2)
q("C20-A-023", T_, "Sum of sin^2 over complementary angle pairs", "Medium",
  "Conceptual/application",
  r"The value of $\sin^2 3^\circ + \sin^2 6^\circ + \sin^2 9^\circ + \cdots + \sin^2 84^\circ + \sin^2 87^\circ$ is",
  "MCQ",
  r"There are $29$ terms. Pair $\sin^2 k^\circ$ with $\sin^2 (90 - k)^\circ = \cos^2 k^\circ$: the pairs $(3, 87), (6, 84), \ldots, (42, 48)$ give $14$ pairs, each summing to $1$. The middle term is $\sin^2 45^\circ = \frac{1}{2}$. The total is $14 + \frac{1}{2} = \frac{29}{2}$.",
  "Mishandling the unpaired middle term $\\sin^2 45^\\circ$.",
  "C20A-complementary-sum", "Needs counting terms and pairing complementary angles; the middle term is the trap.",
  correct=r"$\frac{29}{2}$",
  distractors=[(r"$15$", r"Takes the middle term $\sin^2 45^\circ$ as $1$."),
               (r"$14$", r"Counts the $14$ pairs and omits the middle term."),
               (r"$\frac{31}{2}$", r"Includes an extra term $\sin^2 90^\circ = 1$, as if the series ran to $90^\circ$.")],
  check=_c023, values=[Rational(29, 2), 15, 14, Rational(31, 2)], cognitive="Understanding")


# =====================================================================
# DIFFICULT
# =====================================================================

# 024
def _c024():
    x = symbols('x', positive=True)
    tanang = (9 / x - 4 / x) / (1 + 36 / x ** 2)
    crit = solve(diff(tanang, x), x)
    best = max(crit, key=lambda c: tanang.subs(x, c))
    # confirm by a grid scan
    grid = max((Fraction(k, 100) for k in range(1, 3001)), key=lambda c: 5 * c / (c * c + 36))
    assert grid == best
    return best
_f = Fig()
_E = _f.pt("", 11, 0); _Pf = _f.pt("", 0, 0); _Pt = _f.pt("", 0, 4); _St = _f.pt("", 0, 9)
_f.poly((-0.6, 0), (0, 0), (0, 4), (-0.6, 4))
_f.seg((-2, 0), (13, 0)); _f.seg(_Pt, _St); _f.seg(_E, _Pt, dashed=True); _f.seg(_E, _St, dashed=True)
_f.label_seg(_Pt, _St, "5 m", side=-1); _f.label_seg(_Pf, _Pt, "4 m", side=-1)
_f.text((11, -0.7), "eye")
_f.angle_mark(_Pt, _E, _St, "", r=1.3)
_alt = "A statue 5 m tall standing on a pedestal 4 m high on level ground; lines of sight from an eye at ground level to the bottom and top of the statue."
q("C20-A-024", T_, "Distance at which a statue on a pedestal subtends the greatest angle", "Difficult",
  "Casework/optimisation",
  r"A statue $5$ m tall stands on a pedestal $4$ m high on level ground. Ananya, whose eye may be taken to be at ground level, stands on the ground in front of the statue. At what distance from the foot of the pedestal, in metres, should she stand so that the statue subtends the largest possible angle at her eye?",
  "TITA",
  r"At distance $x$, the tops of the pedestal and statue are seen at angles with tangents $\frac{4}{x}$ and $\frac{9}{x}$. The statue subtends angle $\phi$ with $\tan \phi = \frac{\frac{9}{x} - \frac{4}{x}}{1 + \frac{36}{x^2}} = \frac{5}{x + \frac{36}{x}}$. This is largest when $x + \frac{36}{x}$ is smallest, which by AM-GM happens at $x = \sqrt{36} = 6$ m.",
  "Thinking that standing closer always gives a bigger angle, or equating the distance to a height.",
  "C20A-statue-max-angle", "Requires setting up tan of a difference of angles and minimising $x + \\frac{36}{x}$.",
  tita_answer=6, check=_c024,
  tita_traps=[(9, r"Stands so that the top of the statue is at $45^\circ$, equating the distance to the total height."),
              (5, r"Equates the distance to the statue's height.")],
  cognitive="Analysis", exams=TWO, figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 025
def _c025():
    H, x = symbols('H x', positive=True)
    e = 20
    sol = solve([Eq(H - e, x * _tn(30)), Eq(H + e, x * _tn(60))], [H, x], dict=True)[0]
    return simplify(sol[H])
_f = Fig()
_x25 = 20 * _s3
_E = _f.pt("", 0, 20); _C = _f.pt("", _x25, 40); _R = _f.pt("", _x25, -40); _W = _f.pt("", 0, 0, dot=False)
_f.seg((-8, 0), (_x25 + 8, 0)); _f.seg(_W, _E); _f.seg(_E, _C); _f.seg(_E, _R); _f.seg(_C, _R, dashed=True)
_f.seg(_E, (_x25, 20), dashed=True)
_f.angle_mark((_x25, 20), _E, _C, "30^\\circ", r=6); _f.angle_mark(_R, _E, (_x25, 20), "60^\\circ", r=6)
_f.label_seg(_W, _E, "20 m", side=1)
_f.text((_x25 + 9, 40), "cloud"); _f.text((_x25 + 13, -40), "reflection"); _f.text((8, -4), "lake")
_alt = "An eye 20 m above a still lake; a dashed horizontal line from the eye; the cloud is seen at 30 degrees elevation and its reflection in the lake at 60 degrees depression."
q("C20-A-025", T_, "Height of a cloud from elevation and depression of its reflection", "Difficult",
  "Conceptual/application",
  r"Fatima stands on a jetty with her eye $20$ m above the still surface of a lake. She sees a stationary cloud at an angle of elevation of $30^\circ$ and the reflection of the same cloud in the lake at an angle of depression of $60^\circ$. How high is the cloud above the surface of the lake, in metres?",
  "TITA",
  r"Let the cloud be $H$ m above the lake and $x$ m away horizontally. Its reflection appears $H$ m below the surface, so it is $H + 20$ m below her eye, while the cloud is $H - 20$ m above it. Then $H - 20 = \frac{x}{\sqrt{3}}$ and $H + 20 = x\sqrt{3}$, so $H + 20 = 3(H - 20)$, giving $H = 40$.",
  "Placing the reflection $H$ m below the eye instead of $H$ m below the lake surface.",
  "C20A-reflection-lake", "The mirror-image model is non-obvious; two equations with the eye height on both.",
  tita_answer=40, check=_c025,
  tita_traps=[(30, r"Takes the reflection as $H$ m below the eye: $H = 3(H - 20)$ gives $30$."),
              (20, r"Reports the height of the cloud above her eye, $H - 20$.")],
  cognitive="Analysis", exams=TWO, figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 026
def _c026():
    h = symbols('h', positive=True)
    OP = h * _ct(45); OQ = h * _ct(30)
    # P due south of O, Q due west of P: angle OPQ = 90
    return solve(Eq(OQ ** 2, OP ** 2 + 60 ** 2), h)[0]
q("C20-A-026", T_, "Tower height from two observation points not in line with its foot", "Difficult",
  "Multi-step word problem",
  r"A vertical tower stands at a point O on level ground. A point P is due south of O, and from P the angle of elevation of the top of the tower is $45^\circ$. A point Q is due west of P with $PQ = 60$ m, and from Q the angle of elevation of the top of the tower is $30^\circ$. What is the height of the tower?",
  "MCQ",
  r"For height $h$, $OP = h \cot 45^\circ = h$ and $OQ = h \cot 30^\circ = \sqrt{3}h$. Since OP points north-south and PQ east-west, the angle OPQ is $90^\circ$, so $OQ^2 = OP^2 + PQ^2$: $3h^2 = h^2 + 3600$. Hence $h^2 = 1800$ and $h = 30\sqrt{2}$ m.",
  "Treating O, P and Q as collinear, or putting the right angle at the wrong vertex.",
  "C20A-bearing-3d", "Three-dimensional setting: the right angle lies on the ground at P, not in line with the tower.",
  correct=r"$30\sqrt{2}$ m",
  distractors=[(r"$30(\sqrt{3} + 1)$ m", r"Treats O, P, Q as collinear: $\sqrt{3}h - h = 60$."),
               (r"$20\sqrt{3}$ m", r"Takes $OQ$ as the line of sight $\frac{h}{\sin 30^\circ} = 2h$: $4h^2 = h^2 + 3600$."),
               (r"$30$ m", r"Puts the right angle at O instead of P: $OP^2 + OQ^2 = PQ^2$ gives $h^2 + 3h^2 = 3600$, so $h = 30$.")],
  check=_c026, values=[30 * sqrt(2), 30 * (sqrt(3) + 1), 20 * sqrt(3), 30], cognitive="Analysis", exams=TWO)


# 027
def _c027():
    # simulate with an arbitrary cliff height; speed fixed by the first 12 minutes, halved afterwards
    h = Integer(7)
    x30, x45, x60 = h * _ct(30), h * _ct(45), h * _ct(60)
    v = (x30 - x45) / 12
    t2 = (x45 - x60) / (v / 2)
    return radsimp(simplify(12 + t2))
q("C20-A-027", T_, "Total time for a boat's depression to go from 30 to 60 degrees when its speed halves midway", "Difficult",
  "Multi-step word problem",
  r"From the top of a vertical cliff, Harpreet watches a boat moving in a straight line directly towards the foot of the cliff. While the angle of depression of the boat changes from $30^\circ$ to $45^\circ$, the boat moves at a constant speed, and this takes $12$ minutes. At the moment the angle of depression becomes $45^\circ$, the boat reduces its speed to half and then keeps that new constant speed. How many minutes after the angle of depression was $30^\circ$ does it become $60^\circ$?",
  "MCQ",
  r"For cliff height $h$, the boat is $h\sqrt{3}$, $h$ and $\frac{h}{\sqrt{3}}$ from the foot at $30^\circ$, $45^\circ$ and $60^\circ$. The first stretch is $h(\sqrt{3} - 1)$ and the second is $h - \frac{h}{\sqrt{3}} = \frac{h(\sqrt{3} - 1)}{\sqrt{3}}$, which is $\frac{1}{\sqrt{3}}$ of the first. At the original speed it would take $\frac{12}{\sqrt{3}} = 4\sqrt{3}$ minutes; at half speed it takes $8\sqrt{3}$ minutes. The total is $12 + 8\sqrt{3} = 4(3 + 2\sqrt{3})$ minutes.",
  "Ignoring the change of speed, or thinking that halving the speed halves the time.",
  "C20A-moving-boat-time", "Three positions, a ratio of surd distances in which the height cancels, and a speed change that reverses the usual time scaling.",
  correct=r"$4(3 + 2\sqrt{3})$ minutes",
  distractors=[(r"$4(3 + \sqrt{3})$ minutes", r"Ignores the change of speed: $12 + 4\sqrt{3}$."),
               (r"$2(6 + \sqrt{3})$ minutes", r"Halves the time instead of doubling it when the speed halves: $12 + 2\sqrt{3}$."),
               (r"$4(6 + \sqrt{3})$ minutes", r"Takes the second stretch as the boat's distance $\frac{h}{\sqrt{3}}$ from the foot at $60^\circ$; at half speed that takes $\frac{24}{3 - \sqrt{3}} = 4(3 + \sqrt{3})$ minutes, so the total is $24 + 4\sqrt{3}$.")],
  check=_c027, values=[4 * (3 + 2 * sqrt(3)), 4 * (3 + sqrt(3)), 2 * (6 + sqrt(3)), 4 * (6 + sqrt(3))], cognitive="Analysis", exams=TWO)


# 028
def _c028():
    # P at distance x from the shorter (16 m) pole, 50 - x from the taller (36 m) pole.
    # complementary: tan(a) * tan(b) = 1 with tan a = 16/x, tan b = 36/(50 - x)
    hits = []
    for k in range(1, 5000):
        x = Fraction(k, 100)
        if Fraction(16) / x * Fraction(36) / (50 - x) == 1:
            hits.append(x)
    assert len(hits) == 2
    near = [x for x in hits if x < 25]
    assert len(near) == 1
    return near[0]
_f = Fig()
_P = _f.pt("P", 21, 0, offset=(0, -1.1)); _S0 = _f.pt("", 0, 0); _S1 = _f.pt("", 0, 16); _L0 = _f.pt("", 50, 0); _L1 = _f.pt("", 50, 36)
_f.seg((-3, 0), (53, 0)); _f.seg(_S0, _S1); _f.seg(_L0, _L1); _f.seg(_P, _S1); _f.seg(_P, _L1)
_f.label_seg(_S0, _S1, "16 m", side=1); _f.label_seg(_L0, _L1, "36 m", side=1)
_f.seg((0, -6), (50, -6)); _f.seg((0, -4.5), (0, -7.5)); _f.seg((50, -4.5), (50, -7.5))
_f.seg((0, -6), (1.6, -5.2)); _f.seg((0, -6), (1.6, -6.8)); _f.seg((50, -6), (48.4, -5.2)); _f.seg((50, -6), (48.4, -6.8))
_f.text((25, -9.5), "50 m")
_alt = "Two vertical poles 16 m and 36 m high on level ground, 50 m apart; a point P on the ground between their feet with lines to both tops; a dimension line below the ground marks the 50 m between the feet."
q("C20-A-028", T_, "Point between two poles where elevations are complementary", "Difficult",
  "Casework/optimisation",
  r"Two vertical poles of heights $16$ m and $36$ m stand on level ground with their feet $50$ m apart. A point P on the straight line segment joining their feet is such that the angles of elevation of the tops of the two poles from P are complementary. If P is nearer to the shorter pole, how far is P from the foot of the shorter pole, in metres?",
  "TITA",
  r"Let P be $x$ m from the shorter pole. Complementary angles have tangents whose product is $1$: $\frac{16}{x} \cdot \frac{36}{50 - x} = 1$, so $x(50 - x) = 576$, that is $x^2 - 50x + 576 = 0$, giving $x = 18$ or $32$. Both positions work; the one nearer the shorter pole is $x = 18$.",
  "Ignoring the second root, or using the same-side geometric mean $\\sqrt{16 \\times 36}$.",
  "C20A-complementary-angles", "Leads to a quadratic with two valid positions; the stem's condition selects one.",
  tita_answer=18, check=_c028,
  tita_traps=[(32, r"Takes the other root, which is nearer the taller pole."),
              (24, r"Takes P's distance as the geometric mean of the two pole heights, $\sqrt{16 \times 36} = 24$, misapplying the complementary-angle rule.")],
  cognitive="Analysis", exams=TWO, figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False))


# 029
def _c029():
    h = symbols('h', positive=True)
    # P at h cot15, Q at h cot30, PQ = 60
    hv = solve(Eq(h * _ct(15) - h * _ct(30), 60), h)[0]
    hv = nsimplify(radsimp(simplify(hv)))
    return radsimp(simplify(hv * _ct(30) - hv * _ct(45)))
q("C20-A-029", T_, "Elevations of 15, 30 and 45 degrees along a road; isosceles insight", "Difficult",
  "Conceptual/application",
  r"Joseph walks along a straight, level road towards the foot of a vertical tower that stands on the road. At a point P, the angle of elevation of the top of the tower is $15^\circ$. After he walks $60$ m further to a point Q, it is $30^\circ$. He continues to a point R, where it is $45^\circ$. What is the distance QR?",
  "MCQ",
  r"In the triangle formed by P, Q and the top, the angle at the top is $30^\circ - 15^\circ = 15^\circ$, equal to the angle at P, so the line from Q to the top is $60$ m. The height is therefore $60 \sin 30^\circ = 30$ m, Q is $30 \cot 30^\circ = 30\sqrt{3}$ m from the foot and R is $30 \cot 45^\circ = 30$ m from it. So $QR = 30(\sqrt{3} - 1)$ m.",
  "Treating the $60$ m slant length as the height or as Q's horizontal distance.",
  "C20A-isosceles-angle-doubling", "Needs the isosceles-triangle insight to avoid $\\tan 15^\\circ$; three positions.",
  correct=r"$30(\sqrt{3} - 1)$ m",
  distractors=[(r"$60(\sqrt{3} - 1)$ m", r"Takes the height as $60$ m, so Q and R are $60\sqrt{3}$ and $60$ m from the foot."),
               (r"$20(3 - \sqrt{3})$ m", r"Takes Q's distance from the foot as $60$ m, so the height is $20\sqrt{3}$ and R is $20\sqrt{3}$ m away."),
               (r"$30(\sqrt{3} + 1)$ m", r"Reports PR, which is $60 + 30(\sqrt{3} - 1)$.")],
  check=_c029, values=[30 * (sqrt(3) - 1), 60 * (sqrt(3) - 1), 20 * (3 - sqrt(3)), 30 * (sqrt(3) + 1)], cognitive="Analysis", exams=TWO)


# 030
def _c030():
    u = symbols('u', positive=True)        # u = tan(theta), theta = elevation from the farther point
    sols = [s for s in solve(Eq(2 * u / (1 - u ** 2), 3 * u), u) if s < 1]
    assert len(sols) == 1
    return nsimplify(simplify(90 * sols[0]))
q("C20-A-030", T_, "Height when one elevation is double the other", "Difficult",
  "Inverse/parameter",
  r"Points P and Q lie on level ground on the same side of a vertical tower, in a straight line with its foot, at distances of $30$ m and $90$ m from the foot respectively. The angle of elevation of the top of the tower from P is twice the angle of elevation from Q. What is the height of the tower?",
  "MCQ",
  r"Let the elevation from Q be $\theta$, so from P it is $2\theta$. In the triangle formed by Q, P and the top, the angle at the top is $2\theta - \theta = \theta$, so the line from P to the top equals $PQ = 60$ m. Then $\cos 2\theta = \frac{30}{60}$, so $2\theta = 60^\circ$, and the height is $60 \sin 60^\circ = 30\sqrt{3}$ m.",
  "Reporting the slant length, or using the wrong angle with the slant length.",
  "C20A-isosceles-angle-doubling", "Needs the isosceles insight (or a double-angle equation) before any standard angle appears.",
  correct=r"$30\sqrt{3}$ m",
  distractors=[(r"$60$ m", r"Reports the slant distance from P to the top, $PQ = 60$ m."),
               (r"$30$ m", r"Uses $60 \sin 30^\circ$, taking the smaller angle $\theta$ with the slant length."),
               (r"$60\sqrt{3}$ m", r"Uses $60 \tan 60^\circ$, treating the slant length as the horizontal base.")],
  check=_c030, values=[30 * sqrt(3), 60, 30, 60 * sqrt(3)], cognitive="Analysis", exams=TWO)
