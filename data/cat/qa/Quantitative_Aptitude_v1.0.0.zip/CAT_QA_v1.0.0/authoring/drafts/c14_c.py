import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Maxima and minima"
HARD = ("CAT", "XAT")


def _extreme(f, x, lo, hi, kind):
    """Max or min of a smooth f on [lo, hi] (None = unbounded side) via stationary points and ends."""
    cands = []
    for s in solve(diff(f, x), x):
        if s.is_real and (lo is None or s >= lo) and (hi is None or s <= hi):
            cands.append(f.subs(x, s))
    for e in (lo, hi):
        if e is not None:
            cands.append(f.subs(x, e))
    return max(cands) if kind == "max" else min(cands)


def _grid(lo, hi, steps):
    """Exact Fraction grid from lo to hi inclusive."""
    lo, hi = Fraction(lo), Fraction(hi)
    return [lo + (hi - lo) * Fraction(i, steps) for i in range(steps + 1)]


# ---------------------------------------------------------------- 001
def _c001():
    t = symbols('t', real=True)
    return _extreme(60 + 16 * t - 2 * t**2, t, 0, 10, "max")
q("C14-C-001", TOPIC, "Greatest value of a downward quadratic in a height context", "Easy",
  "Single-step computation",
  r"A delivery drone takes off from the roof of a building. Its height above the ground $t$ seconds after take-off is $h(t) = 60 + 16t - 2t^2$ metres, for $0 \le t \le 10$. What is the greatest height above the ground that the drone reaches?",
  "MCQ",
  r"Complete the square: $h(t) = 60 - 2(t^2 - 8t) = 60 - 2(t - 4)^2 + 32 = 92 - 2(t - 4)^2$. The square is zero at $t = 4$, which lies in $0 \le t \le 10$, so the greatest height is $92$ m.",
  "Misapplying the vertex value formula $c - \\frac{b^2}{4a}$ (wrong denominator or wrong sign).",
  "C14C-quadratic-vertex-word", "One completion of the square; the trap is the vertex formula.",
  correct=r"$92$ m",
  distractors=[(r"$124$ m", r"Uses $c - \frac{b^2}{2a} = 60 + \frac{256}{4}$, with $2a$ in place of $4a$."),
               (r"$28$ m", r"Sign slip: $c + \frac{b^2}{4a} = 60 - 32$."),
               (r"$60$ m", r"Takes the peak time as $t = -\frac{b}{a} = 8$, where $h = 60 + 128 - 128$.")],
  check=_c001, values=[92, 124, 28, 60], cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    x = symbols('x', positive=True)
    return _extreme(3 * x**2 - 36 * x + 150, x, None, None, "min")
q("C14-C-002", TOPIC, "Least value of an upward quadratic in an average-cost context", "Easy",
  "Single-step computation",
  r"A workshop finds that when it produces $x$ thousand units in a month ($x > 0$), its average cost per unit is $3x^2 - 36x + 150$ rupees. What is the least possible average cost per unit, in rupees?",
  "TITA",
  r"$3x^2 - 36x + 150 = 3(x^2 - 12x) + 150 = 3(x - 6)^2 - 108 + 150 = 3(x - 6)^2 + 42$. The least value is at $x = 6$ (that is, $6$ thousand units) and equals Rs. $42$ per unit.",
  "Reporting the output level at which the minimum occurs instead of the minimum cost.",
  "C14C-quadratic-vertex-word", "A single completion of the square.",
  tita_answer=42, check=_c002, values=[42],
  tita_traps=[(6, "Reports the output level $x = 6$ instead of the cost."),
              (114, r"Completes the square as $3(x - 6)^2 - 36 + 150$, subtracting $36$ instead of $3 \times 36$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    t, a, b = symbols('t a b', real=True)
    h = a * t**2 + b * t
    sol = solve([Eq(diff(h, t).subs(t, 3), 0), Eq(h.subs(t, 3), 45)], [a, b], dict=True)[0]
    return h.subs(sol).subs(t, 5)
q("C14-C-003", TOPIC, "Rebuilding a quadratic from its peak and finding a later value", "Easy",
  "Inverse/parameter",
  r"A ball is thrown straight up from ground level. Its height after $t$ seconds is $h(t) = at^2 + bt$ metres, where $a$ and $b$ are constants. The ball reaches its greatest height, $45$ m, at $t = 3$ seconds. What is its height at $t = 5$ seconds?",
  "MCQ",
  r"With the peak at $t = 3$ of height $45$, write $h(t) = 45 - k(t - 3)^2$. Since $h(0) = 0$, $45 - 9k = 0$, so $k = 5$. Then $h(5) = 45 - 5 \times 2^2 = 25$ m. (By symmetry about $t = 3$, this equals $h(1)$.)",
  "Treating the fall after the peak as linear, or forgetting to square $(t - 3)$.",
  "C14C-quadratic-vertex-word", "Needs the vertex form and one condition to fix the coefficient.",
  correct=r"$25$ m",
  distractors=[(r"$15$ m", r"Assumes the height falls in a straight line from $45$ m at $t = 3$ to $0$ at $t = 6$."),
               (r"$35$ m", r"Uses $k = 5$ but evaluates $45 - 5 \times 2$, not squaring $(t - 3)$."),
               (r"$41$ m", r"Takes $h(t) = 45 - (t - 3)^2$, assuming the coefficient is $1$.")],
  check=_c003, values=[25, 15, 35, 41], cognitive="Application")

# ---------------------------------------------------------------- 004
def _c004():
    x = symbols('x', real=True)
    S = sum((x - a)**2 for a in (1, 6, 8, 12, 18))
    return _extreme(S, x, None, None, "min")
q("C14-C-004", TOPIC, "Least sum of squared deviations occurs at the mean", "Medium",
  "Conceptual/application",
  r"For a real number $x$, let $S(x) = (x - 1)^2 + (x - 6)^2 + (x - 8)^2 + (x - 12)^2 + (x - 18)^2$. What is the least possible value of $S(x)$?",
  "TITA",
  r"$S(x) = 5x^2 - 2(1 + 6 + 8 + 12 + 18)x + \ldots = 5x^2 - 90x + \ldots$, an upward parabola with vertex at $x = \frac{90}{10} = 9$, the mean of the five numbers. Then $S(9) = 64 + 9 + 1 + 9 + 81 = 164$.",
  "Minimising at the median, which is correct for a sum of absolute deviations but not for squares.",
  "C14C-sum-of-squares-at-mean", "Recognising the vertex of a sum of squares as the mean.",
  tita_answer=164, check=_c004, values=[164],
  tita_traps=[(169, r"Uses the median $x = 8$: $49 + 4 + 0 + 16 + 100$."),
              (9, r"Reports the minimising value $x = 9$ instead of $S(9)$.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 005
def _c005():
    x = symbols('x', real=True)
    return _extreme(2 * (x - 2)**2 + 3 * (x - 12)**2, x, None, None, "min")
q("C14-C-005", TOPIC, "Least weighted sum of squares occurs at the weighted mean", "Medium",
  "Conceptual/application",
  r"Two warehouses stand beside a straight highway at kilometre marks $2$ and $12$. A hub is to be built at kilometre mark $x$ on the highway, and the daily running cost, in Rs. hundred, is $2(x - 2)^2 + 3(x - 12)^2$. What is the least possible daily running cost, in Rs. hundred?",
  "MCQ",
  r"The cost is $5x^2 - 2(4 + 36)x + \ldots = 5x^2 - 80x + \ldots$, with vertex at $x = 8$, the weighted mean $\frac{2 \times 2 + 3 \times 12}{5}$. The least cost is $2 \times 36 + 3 \times 16 = 72 + 48 = 120$.",
  "Placing the hub at the plain midpoint or attaching the weights to the wrong warehouses.",
  "C14C-sum-of-squares-at-mean", "Two ideas: recognise that the weighted sum of squares is least at the weighted mean (not the midpoint), then evaluate the cost there.",
  correct=r"$120$",
  distractors=[(r"$125$", r"Uses the midpoint $x = 7$: $2 \times 25 + 3 \times 25$."),
               (r"$140$", r"Swaps the weights in the mean: $x = \frac{3 \times 2 + 2 \times 12}{5} = 6$, cost $32 + 108$."),
               (r"$200$", r"Places the hub at the warehouse with the larger weight, $x = 12$: $2 \times 100$.")],
  check=_c005, values=[120, 125, 140, 200], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    xs = _grid(-20, 30, 5000)
    return min(max(x + 6, 14 - x, 3 * x - 10) for x in xs)
q("C14-C-006", TOPIC, "Least value of the largest of three linear expressions", "Medium",
  "Casework/optimisation",
  r"For real $x$, let $g(x)$ be the largest of the three numbers $x + 6$, $14 - x$ and $3x - 10$. The least possible value of $g(x)$ is",
  "MCQ",
  r"$g$ is the upper envelope of the three lines. The only falling line is $14 - x$, so the least value of $g$ is where $14 - x$ meets the higher of the two rising lines. $x + 6 = 14 - x$ gives $x = 4$, value $10$; at $x = 4$, $3x - 10 = 2 < 10$, so $g(4) = 10$. For $x < 4$, $14 - x > 10$; for $x > 4$, $x + 6 > 10$. The least value is $10$.",
  "Equating the wrong pair of lines, or forgetting to check the third line at the crossing.",
  "C14C-three-lines-envelope", "Needs the upper envelope and a check of which crossing is relevant.",
  correct=r"$10$",
  distractors=[(r"$8$", r"Equates $14 - x$ with $3x - 10$ ($x = 6$) and reports their common value, though $x + 6 = 12$ is larger there."),
               (r"$14$", r"Equates the two rising lines $x + 6$ and $3x - 10$ ($x = 8$)."),
               (r"$12$", r"Uses the crossing $x = 6$ of $14 - x$ and $3x - 10$ and evaluates $g(6)$ correctly, which is not the minimum.")],
  check=_c006, values=[10, 8, 14, 12], cognitive="Analysis")

# ---------------------------------------------------------------- 007
def _c007():
    x = symbols('x', real=True)
    f1 = x**2 - 4 * x
    def least(cv):
        f2 = 2 * x + cv
        pts = [s for s in solve(Eq(f1, f2), x) if s.is_real] + [Integer(2)]
        return min((max(f1.subs(x, p), f2.subs(x, p), key=lambda e: N(e, 50)) for p in pts), key=lambda e: N(e, 50))
    hits, prev = [], None
    for cv in _grid(-20, 10, 120):
        cs = Rational(cv.numerator, cv.denominator)
        v = least(cs)
        if prev is not None:
            assert N(v - prev, 50) >= -1e-40          # least value never falls as c rises
        prev = v
        if simplify(v + 3) == 0:
            hits.append(cs)
    assert len(hits) == 1
    # confirm on a fine grid that the least value for the found c is -3
    cv = hits[0]
    g = min(max(Fraction(t)**2 - 4 * Fraction(t), 2 * Fraction(t) + Fraction(int(cv))) for t in _grid(-10, 15, 2500))
    assert g == -3
    return cv
q("C14-C-007", TOPIC, "Constant fixed by the least value of the larger of a parabola and a line", "Difficult",
  "Inverse/parameter",
  r"For a real constant $c$, let $h(x) = \max(x^2 - 4x,\ 2x + c)$ for real $x$. The least value of $h(x)$ over all real $x$ is $-3$. The value of $c$ is",
  "MCQ",
  r"$x^2 - 4x$ has least value $-4$ at $x = 2$. If $2 \times 2 + c \le -4$, that is $c \le -8$, then $h(2) = -4$ and the least value would be $-4$, so $c > -8$ and the line passes above the vertex. Then $h$ is least where the falling left part of the parabola meets the rising line, a crossing to the left of $x = 2$. That point is on the parabola with value $-3$: $x^2 - 4x = -3$ gives $x = 1$ or $x = 3$, and only $x = 1$ is left of the vertex. So $2 + c = -3$ and $c = -5$. Check: $x^2 - 4x = 2x - 5$ at $x = 1$ and $x = 5$, and between them $h = 2x - 5 \ge -3$.",
  "Using the crossing to the right of the vertex, or assuming the least value sits above the parabola's vertex.",
  "C14C-curve-envelope-crossing", "Inverse of a min-of-max: casework on whether the vertex is exposed, then choosing the correct one of two crossings.",
  correct=r"$-5$",
  distractors=[(r"$-9$", r"Uses the crossing $x = 3$, right of the vertex: $6 + c = -3$. With $c = -9$ the line is below the vertex and the least value is $-4$."),
               (r"$-7$", r"Assumes the least value is on the line directly above the vertex $x = 2$: $4 + c = -3$."),
               (r"$-1$", r"Finds the crossing $x = 1$ correctly but slips a sign solving $2 + c = -3$, taking $c = -3 + 2$.")],
  check=_c007, values=[-5, -9, -7, -1], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 008
def _c008():
    # minutes to reach x: Ravi |x|/1, Sneha |24 - x|/1, Joseph 2|x - 21| (60 km/h = 1 km/min)
    xs = _grid(-10, 40, 5000)
    return int(min(max(abs(x), abs(24 - x), 2 * abs(x - 21)) for x in xs))
q("C14-C-008", TOPIC, "Meeting point that minimises the latest arrival time", "Difficult",
  "Casework/optimisation",
  r"Ravi, Sneha and Joseph are at kilometre marks $0$, $24$ and $21$ respectively on a straight highway. They agree to meet at some point on the highway and start driving towards it at the same moment, Ravi and Sneha at a constant $60$ km/h and Joseph at a constant $30$ km/h. The meeting point is chosen so that the last of the three to arrive gets there as early as possible. How many minutes after the start does the last person arrive?",
  "TITA",
  r"At $60$ km/h a person takes $1$ minute per km, and at $30$ km/h, $2$ minutes per km. Meeting at mark $x$, the last arrival is $\max(x,\ 24 - x,\ 2|x - 21|)$ minutes. For a time $T$ we need $x \le T$, $x \ge 24 - T$ and $x \ge 21 - \frac{T}{2}$. With $T = 12$ (the midpoint $x = 12$) Joseph needs $18$ minutes, so $T > 12$; the binding pair is $x \le T$ and $x \ge 21 - \frac{T}{2}$, giving $T \ge 21 - \frac{T}{2}$, so $T \ge 14$. At $x = 14$: Ravi $14$, Sneha $10$, Joseph $14$ minutes. The answer is $14$.",
  "Choosing the midpoint of the two outer people and ignoring the slower driver.",
  "C14C-word-minimax", "Three time functions; the slower driver changes which constraints bind.",
  tita_answer=14, check=_c008, values=[14],
  tita_traps=[(12, "Meets at the midpoint $x = 12$ and ignores Joseph."),
              (18, "Meets at the midpoint $x = 12$ and reports Joseph's time there.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 009
def _c009():
    best = None
    for p in _grid(0, 30000, 30000):           # rupees in P, step Re 1
        good = p * Fraction(15, 100) + (30000 - p) * Fraction(5, 100)
        bad = -p * Fraction(5, 100) + (30000 - p) * Fraction(10, 100)
        v = min(good, bad)
        best = v if best is None else max(best, v)
    return int(best)
q("C14-C-009", TOPIC, "Investment split that maximises the guaranteed gain", "Medium",
  "Conceptual/application",
  r"Meera will split Rs. $30{,}000$ between two schemes, P and Q, in any proportion. In a good year, P returns $15\%$ and Q returns $5\%$. In a bad year, P loses $5\%$ of the amount invested in it, while Q returns $10\%$. She wants to make the smaller of her two possible one-year gains (good year or bad year) as large as possible. What is this largest guaranteed gain, in rupees?",
  "TITA",
  r"Let $x$ thousand rupees go into P. Good-year gain: $0.15x + 0.05(30 - x) = 1.5 + 0.1x$ (rising). Bad-year gain: $-0.05x + 0.10(30 - x) = 3 - 0.15x$ (falling). The smaller of the two is largest where they are equal: $1.5 + 0.1x = 3 - 0.15x$, so $x = 6$, and the gain is $1.5 + 0.6 = 2.1$ thousand, that is Rs. $2{,}100$.",
  "Putting everything in the scheme that looks safer, or reporting the amount invested.",
  "C14C-word-minimax", "Maximising the minimum of a rising and a falling line in a word setting.",
  tita_answer=2100, check=_c009, values=[2100],
  tita_traps=[(1500, "Puts all the money in Q: gains Rs. $1{,}500$ and Rs. $3{,}000$, smaller one $1{,}500$."),
              (6000, "Reports the amount to put in P instead of the gain.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 010
def _c010():
    xs = _grid(-20, 30, 5000)
    return max(min(x + 4, 16 - 2 * x, 4 * x - 14) for x in xs)
q("C14-C-010", TOPIC, "Greatest value of the smallest of three linear expressions", "Medium",
  "Casework/optimisation",
  r"For real $x$, let $m(x)$ be the smallest of the three numbers $x + 4$, $16 - 2x$ and $4x - 14$. The greatest possible value of $m(x)$ is",
  "MCQ",
  r"$m$ is the lower envelope of the lines. The only falling line is $16 - 2x$, so the peak is where it meets the rising line that is lowest there. $16 - 2x = 4x - 14$ gives $x = 5$, value $6$, and $x + 4 = 9 > 6$ there, so $m(5) = 6$. For $x < 5$, $4x - 14 < 6$; for $x > 5$, $16 - 2x < 6$. The greatest value is $6$.",
  "Equating the first pair of lines one notices without checking the third line.",
  "C14C-three-lines-envelope", "Lower envelope of three lines; the obvious crossing is the wrong one.",
  correct=r"$6$",
  distractors=[(r"$8$", r"Equates $x + 4$ and $16 - 2x$ ($x = 4$) and ignores $4x - 14 = 2$ there."),
               (r"$10$", r"Equates the two rising lines $x + 4$ and $4x - 14$ ($x = 6$)."),
               (r"$9$", r"Finds the correct point $x = 5$ but evaluates $x + 4$ there.")],
  check=_c010, values=[6, 8, 10, 9], cognitive="Analysis")

# ---------------------------------------------------------------- 011
def _c011():
    xs = _grid(-10, 10, 4000)
    return max(min(4 - x * x, x + 2) for x in xs)
q("C14-C-011", TOPIC, "Greatest value of the smaller of a parabola and a line", "Medium",
  "Casework/optimisation",
  r"For real $x$, let $f(x) = \min(4 - x^2,\ x + 2)$. The greatest possible value of $f(x)$ is",
  "MCQ",
  r"The graphs meet where $4 - x^2 = x + 2$, that is $x^2 + x - 2 = 0$, so $x = -2$ or $x = 1$. Between them the line is lower, so $f(x) = x + 2$, which rises to $3$ at $x = 1$. For $x > 1$, $f(x) = 4 - x^2 < 3$, and for $x < -2$, $f(x) = 4 - x^2 < 0$. The greatest value is $3$.",
  "Reporting the peak of the parabola, where the line is lower.",
  "C14C-curve-envelope-crossing", "Comparing a parabola and a line to locate the lower envelope's peak.",
  correct=r"$3$",
  distractors=[(r"$4$", r"Takes the peak of $4 - x^2$ at $x = 0$, where the line gives only $2$."),
               (r"$2$", r"Evaluates $f$ at the parabola's vertex $x = 0$: $\min(4, 2)$."),
               (r"$0$", r"Uses the other crossing $x = -2$.")],
  check=_c011, values=[3, 4, 2, 0], cognitive="Analysis")

# ---------------------------------------------------------------- 012
def _c012():
    t = symbols('t', real=True)
    T = t**2 - 10 * t + 30
    return _extreme(T, t, 0, 3, "max") - _extreme(T, t, 0, 3, "min")
q("C14-C-012", TOPIC, "Range of a quadratic on an interval that excludes its vertex", "Easy",
  "Conceptual/application",
  r"The temperature of a liquid $t$ hours after a process starts is $T(t) = t^2 - 10t + 30$ degrees Celsius. During the first $3$ hours ($0 \le t \le 3$), what is the difference between the highest and the lowest temperatures reached?",
  "MCQ",
  r"$T(t) = (t - 5)^2 + 5$ has its vertex at $t = 5$, outside $0 \le t \le 3$, so $T$ is decreasing throughout the interval. The highest value is $T(0) = 30$ and the lowest is $T(3) = 9 - 30 + 30 = 9$. The difference is $21$ degrees Celsius.",
  "Using the vertex value as the minimum even though the vertex lies outside the interval.",
  "C14C-quadratic-on-interval", "Endpoint evaluation once the vertex is seen to be outside the interval.",
  correct=r"$21$ degrees Celsius",
  distractors=[(r"$25$ degrees Celsius", r"Uses the vertex value $T(5) = 5$ as the lowest: $30 - 5$."),
               (r"$9$ degrees Celsius", r"Reports the lowest temperature $T(3)$ instead of the difference."),
               (r"$30$ degrees Celsius", r"Reports the highest temperature $T(0)$ instead of the difference.")],
  check=_c012, values=[21, 25, 9, 30], cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    k, x = symbols('k x', real=True)
    sols = []
    for kv in solve(Eq(17 - 4 * k, -11), k) + [s for s in solve(Eq(-k**2 + 2 * k + 8, -11), k)]:
        f = x**2 - 2 * kv * x + 2 * kv + 8
        if kv.is_real and _extreme(f, x, 1, 3, "min") == -11:
            sols.append(kv)
    # also confirm no k < 1 works (min there is f(1) = 9)
    assert len(sols) == 1
    return sols[0]
q("C14-C-013", TOPIC, "Parameter fixed by the least value of a quadratic on an interval", "Difficult",
  "Inverse/parameter",
  r"Let $f(x) = x^2 - 2kx + 2k + 8$, where $k$ is a real constant. The least value of $f(x)$ over the interval $1 \le x \le 3$ is $-11$. What is the value of $k$?",
  "TITA",
  r"The vertex is at $x = k$. If $k < 1$, the least value is $f(1) = 9$. If $1 \le k \le 3$, it is $f(k) = -k^2 + 2k + 8$, which lies between $5$ and $9$ on that range, so it cannot be $-11$. If $k > 3$, $f$ decreases on the interval and the least value is $f(3) = 17 - 4k$. Then $17 - 4k = -11$ gives $k = 7$, which satisfies $k > 3$.",
  "Assuming the vertex lies inside the interval and solving $-k^2 + 2k + 8 = -11$.",
  "C14C-quadratic-on-interval", "Three cases by vertex position; the natural vertex case gives no valid answer.",
  tita_answer=7, check=_c013, values=[7],
  tita_traps=[(9, r"Reports the least value $f(1) = 9$ from the case $k < 1$ in place of $k$."),
              (5, r"Drops the constant $8$ when evaluating $f(3)$: $9 - 4k = -11$ gives $k = 5$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 014
def _c014():
    x = symbols('x', real=True)
    return _extreme(x**2 - 6 * x + 4, x, -1, 4, "max")
q("C14-C-014", TOPIC, "Greatest value of an upward parabola on a closed interval", "Easy",
  "Conceptual/application",
  r"For $-1 \le x \le 4$, the greatest value of $x^2 - 6x + 4$ is",
  "MCQ",
  r"$x^2 - 6x + 4 = (x - 3)^2 - 5$ opens upward, so on a closed interval its greatest value is at the endpoint farther from the vertex $x = 3$. That endpoint is $x = -1$ (distance $4$, against $1$ for $x = 4$), giving $16 - 5 = 11$.",
  "Treating the vertex of an upward parabola as a maximum, or picking the larger endpoint.",
  "C14C-quadratic-on-interval", "One idea: the maximum of an upward parabola sits at the farther endpoint.",
  correct=r"$11$",
  distractors=[(r"$-5$", r"Reports the vertex value, which is the least value, not the greatest."),
               (r"$-4$", r"Evaluates at the larger endpoint $x = 4$."),
               (r"$4$", r"Evaluates at $x = 0$, reading off the constant term.")],
  check=_c014, values=[11, -5, -4, 4], cognitive="Understanding")

# ---------------------------------------------------------------- 015
def _c015():
    x, a, h, k = symbols('x a h k', real=True)
    f = a * (x - 2)**2 + 3
    av = solve(Eq(f.subs(x, 0), 11), a)[0]
    assert av > 0
    return f.subs(a, av).subs(x, 5)
q("C14-C-015", TOPIC, "Quadratic rebuilt from its least value and one point", "Easy",
  "Inverse/parameter",
  r"A quadratic function $f$ takes its least value, $3$, at $x = 2$, and $f(0) = 11$. What is the value of $f(5)$?",
  "TITA",
  r"Write $f(x) = a(x - 2)^2 + 3$. From $f(0) = 4a + 3 = 11$, $a = 2$. Then $f(5) = 2 \times 9 + 3 = 21$.",
  "Assuming the leading coefficient is $1$, or using $f(0)$ incorrectly.",
  "C14C-vertex-information", "Vertex form plus one condition.",
  tita_answer=21, check=_c015, values=[21],
  tita_traps=[(12, r"Takes $a = 1$: $f(5) = 9 + 3$."),
              (18, r"Drops the $+3$: $2 \times 9$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    x = symbols('x', real=True)
    return _extreme((x - 3) * (x - 11), x, None, None, "min")
q("C14-C-016", TOPIC, "Least value of a quadratic given in factored form", "Easy",
  "Conceptual/application",
  r"The least value of $(x - 3)(x - 11)$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"The parabola is symmetric about the midpoint of its roots, $x = 7$, so the least value is $(7 - 3)(7 - 11) = 4 \times (-4) = -16$.",
  "Thinking the least value occurs at a root, or squaring the full gap between the roots.",
  "C14C-vertex-information", "One symmetry idea: the vertex is midway between the roots.",
  correct=r"$-16$",
  distractors=[(r"$0$", "Takes the least value at a root."),
               (r"$-64$", r"Uses $-(11 - 3)^2$, squaring the whole gap instead of half of it."),
               (r"$-32$", r"Uses $-\frac{(11 - 3)^2}{2}$, halving instead of dividing by $4$.")],
  check=_c016, values=[-16, 0, -64, -32], cognitive="Understanding")

# ---------------------------------------------------------------- 017
def _c017():
    x, k = symbols('x k', real=True)
    f = x**2 - 2 * (k - 1) * x + k + 5
    m = f.subs(x, solve(diff(f, x), x)[0])
    return _extreme(expand(m), k, None, None, "max")
q("C14-C-017", TOPIC, "Greatest value, over a parameter, of a quadratic's least value", "Difficult",
  "Inverse/parameter",
  r"For each real number $k$, let $m(k)$ be the least value of $x^2 - 2(k - 1)x + k + 5$ over all real $x$. The greatest possible value of $m(k)$ is",
  "MCQ",
  r"Completing the square in $x$: $x^2 - 2(k - 1)x + k + 5 = (x - (k - 1))^2 + k + 5 - (k - 1)^2$, so $m(k) = -k^2 + 3k + 4$. This is a downward parabola in $k$ with vertex at $k = \frac{3}{2}$, giving $m = -\frac{9}{4} + \frac{9}{2} + 4 = \frac{25}{4}$.",
  "Restricting $k$ to integers, or slipping a sign when completing the square.",
  "C14C-vertex-information", "Two nested optimisations: first in $x$, then in the parameter.",
  correct=r"$\frac{25}{4}$",
  distractors=[(r"$6$", r"Tries only integer $k$; $k = 1$ or $k = 2$ gives $m = 6$."),
               (r"$\frac{17}{4}$", r"Misreads the coefficient as $-2(k + 1)$ and subtracts $(k + 1)^2$: $m = -k^2 - k + 4$, maximum at $k = -\frac{1}{2}$."),
               (r"$7$", r"Subtracts $\frac{(k - 1)^2}{4}$ instead of $(k - 1)^2$; the maximum of $k + 5 - \frac{(k - 1)^2}{4}$ is $7$ at $k = 3$.")],
  check=_c017, values=[Rational(25, 4), 6, Rational(17, 4), 7], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 018
def _c018():
    x = symbols('x', real=True)
    return _extreme((x**2 - 6 * x)**2 + 22 * (x**2 - 6 * x) + 150, x, None, None, "min")
q("C14-C-018", TOPIC, "Quadratic in a substituted quantity whose range is restricted", "Medium",
  "Casework/optimisation",
  r"The least value of $(x^2 - 6x)^2 + 22(x^2 - 6x) + 150$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"Put $t = x^2 - 6x = (x - 3)^2 - 9$, so $t \ge -9$. The expression is $g(t) = t^2 + 22t + 150 = (t + 11)^2 + 29$, whose vertex $t = -11$ is not allowed. On $t \ge -9$, $g$ is increasing, so the least value is $g(-9) = 81 - 198 + 150 = 33$, at $x = 3$.",
  "Using the vertex of $g(t)$ without checking that $t$ can actually reach it.",
  "C14C-substitution-restricted-range", "Requires the range of the substituted variable; the free vertex is a trap.",
  correct=r"$33$",
  distractors=[(r"$29$", r"Uses the vertex $t = -11$, which $x^2 - 6x$ can never reach."),
               (r"$150$", r"Takes $t = 0$ (for example $x = 0$), reading off the constant term."),
               (r"$93$", r"Takes the least value of $x^2 - 6x$ as $-3$ (half the coefficient) instead of $-9$, and evaluates $g(-3)$.")],
  check=_c018, values=[33, 29, 150, 93], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 019
def _c019():
    u = symbols('u', positive=True)        # u = 2^x
    return _extreme(u**2 - 8 * u + 20, u, 0, None, "min")
q("C14-C-019", TOPIC, "Least value of an exponential expression via a quadratic substitution", "Medium",
  "Conceptual/application",
  r"The least value of $4^x - 2^{x+3} + 20$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"Let $u = 2^x > 0$. Then $4^x = u^2$ and $2^{x+3} = 8u$, so the expression is $u^2 - 8u + 20 = (u - 4)^2 + 4$. The value $u = 4$ is allowed ($x = 2$), so the least value is $4$.",
  "Misreading $2^{x+3}$ or misapplying the vertex formula.",
  "C14C-substitution-restricted-range", "One substitution turns the expression into a quadratic.",
  correct=r"$4$",
  distractors=[(r"$13$", r"Evaluates at $x = 0$: $1 - 8 + 20$."),
               (r"$-12$", r"Uses $c - \frac{b^2}{2a} = 20 - 32$ instead of $20 - 16$."),
               (r"$16$", r"Finds $2^x = 4$ and reports $4^x = 16$.")],
  check=_c019, values=[4, 13, -12, 16], cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    x = symbols('x', positive=True)
    f = x**2 + 1 / x**2 - 6 * (x + 1 / x) + 12
    v = _extreme(f, x, None, None, "min")
    return nsimplify(simplify(v))
q("C14-C-020", TOPIC, "Least value via the substitution t = x + 1/x with t at least 2", "Medium",
  "Conceptual/application",
  r"For $x > 0$, what is the least possible value of $x^2 + \frac{1}{x^2} - 6\left(x + \frac{1}{x}\right) + 12$?",
  "TITA",
  r"Let $t = x + \frac{1}{x}$, so $t \ge 2$ and $x^2 + \frac{1}{x^2} = t^2 - 2$. The expression becomes $t^2 - 6t + 10 = (t - 3)^2 + 1$. The value $t = 3$ is allowed (it is reached at $x = \frac{3 \pm \sqrt{5}}{2}$), so the least value is $1$.",
  "Assuming the least value is at $x = 1$, where each bracket is individually least.",
  "C14C-substitution-restricted-range", "Needs the identity for $x^2 + \\frac{1}{x^2}$ and a check that the vertex is reachable.",
  tita_answer=1, check=_c020, values=[1],
  tita_traps=[(2, r"Takes $x = 1$ ($t = 2$): $2 - 12 + 12$."),
              (3, r"Uses $x^2 + \frac{1}{x^2} = t^2$, dropping the $-2$: $(t - 3)^2 + 3$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    x, y = symbols('x y', real=True)
    f = (x**2 - 3 * x + 4) / (x**2 + 3 * x + 4)
    # values y attained: (y-1)x^2 + 3(y+1)x + 4(y-1) = 0 has a real root
    disc = expand((3 * (y + 1))**2 - 16 * (y - 1)**2)
    ends = solve(Eq(disc, 0), y)
    M = max(ends)
    xs = solve(Eq(f, M), x)
    assert any(s.is_real for s in xs)
    return M
q("C14-C-021", TOPIC, "Greatest value of a ratio of two quadratics", "Difficult",
  "Conceptual/application",
  r"The greatest value of $\frac{x^2 - 3x + 4}{x^2 + 3x + 4}$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"The denominator is always positive. Set the ratio equal to $y$: $(y - 1)x^2 + 3(y + 1)x + 4(y - 1) = 0$ must have a real root, so $9(y + 1)^2 \ge 16(y - 1)^2$, that is $3|y + 1| \ge 4|y - 1|$. This gives $\frac{1}{7} \le y \le 7$. The value $7$ is reached at $x = -2$: $\frac{4 + 6 + 4}{4 - 6 + 4} = 7$.",
  "Testing a few convenient values of $x$ instead of finding the true range.",
  "C14C-ratio-of-quadratics-range", "Needs the discriminant method for the range of a rational function.",
  correct=r"$7$",
  distractors=[(r"$4$", r"Tests only $x = -1$: $\frac{8}{2}$."),
               (r"$\frac{43}{7}$", r"Evaluates at $x = -\frac{3}{2}$, where the denominator is least, assuming the ratio peaks there."),
               (r"$\frac{1}{7}$", r"Reports the least value of the ratio instead of the greatest.")],
  check=_c021, values=[7, 4, Rational(43, 7), Rational(1, 7)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 022
def _c022():
    def P(t):
        return 400 * t if t <= 60 else 400 * 60 + 700 * (t - 60)
    def Q(t):
        return 600 * t if t < 50 else 450 * t
    return min(P(100 - y) + Q(y) for y in _grid(0, 100, 1000))
q("C14-C-022", TOPIC, "Least total cost when one transporter offers an all-units discount", "Difficult",
  "Casework/optimisation",
  r"A company must send exactly $100$ tonnes of cement to a site and may split the load between two transporters in any way (fractions of a tonne allowed). Transporter P charges Rs. $400$ per tonne for the first $60$ tonnes it carries and Rs. $700$ per tonne for every tonne beyond $60$. Transporter Q charges Rs. $600$ per tonne if it carries less than $50$ tonnes, but if it carries $50$ tonnes or more, it charges Rs. $450$ per tonne for every tonne it carries. What is the least possible total charge?",
  "MCQ",
  r"Let Q carry $y$ tonnes. If $y < 50$: for $40 \le y < 50$ the total is $400(100 - y) + 600y = 40{,}000 + 200y$, and for $y < 40$ it is $24{,}000 + 700(40 - y) + 600y = 52{,}000 - 100y$; the least in this case is Rs. $48{,}000$ at $y = 40$. If $y \ge 50$, P carries at most $50$ tonnes, so the total is $400(100 - y) + 450y = 40{,}000 + 50y$, least at $y = 50$: Rs. $42{,}500$. The least possible charge is Rs. $42{,}500$, with $50$ tonnes each.",
  "Filling the cheapest per-tonne rates first, which ignores that Q's discount applies only once its load reaches $50$ tonnes.",
  "C14C-piecewise-marginal-cost", "The cost is not convex, so greedy filling fails; needs casework on whether Q reaches its discount threshold.",
  correct=r"Rs. $42{,}500$",
  distractors=[(r"Rs. $48{,}000$", r"Fills the cheapest rates first: P's $60$ tonnes at Rs. $400$, then $40$ tonnes with Q at Rs. $600$: $24{,}000 + 24{,}000$."),
               (r"Rs. $42{,}000$", r"Gives P $60$ tonnes and Q $40$ tonnes but charges Q the discounted Rs. $450$, though $40 < 50$: $24{,}000 + 18{,}000$."),
               (r"Rs. $45{,}000$", r"Gives all $100$ tonnes to Q at the discounted rate: $100 \times 450$.")],
  check=_c022, values=[42500, 48000, 42000, 45000], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 023
def _c023():
    def fare(d):
        if d <= 3:
            return Fraction(60)
        if d <= 12:
            return 60 + 15 * (d - 3)
        return 195 + 25 * (d - 12)
    # dynamic programme on a half-km grid (all slab boundaries are whole km)
    N = 48
    best = [Fraction(0)] + [None] * N
    for i in range(1, N + 1):
        best[i] = min(best[j] + fare(Fraction(i - j, 2)) for j in range(i))
    return int(best[N])
q("C14-C-023", TOPIC, "Splitting a journey into rides to minimise a piecewise fare", "Difficult",
  "Casework/optimisation",
  r"A taxi company charges Rs. $60$ for any ride of up to $3$ km. For a longer ride it charges Rs. $60$ plus Rs. $15$ per km for each km beyond $3$, up to $12$ km, and Rs. $25$ per km for each km beyond $12$. Fatima must travel $24$ km along a road. She may end a ride at any point and immediately start a new ride from there, each ride being charged separately. What is the least total fare, in rupees, for the $24$ km?",
  "TITA",
  r"A ride of $d$ km with $3 < d \le 12$ costs $60 + 15(d - 3)$, an average of $15 + \frac{15}{d}$ per km, which is least at $d = 12$: Rs. $195$, or Rs. $16.25$ per km. Rides up to $3$ km cost at least Rs. $20$ per km, and beyond $12$ km each extra km costs Rs. $25$, so no ride does better than Rs. $16.25$ per km. Two rides of $12$ km achieve this exactly: $2 \times 195 = 390$.",
  "Taking a single ride, or splitting into more rides than needed and paying the base charge again.",
  "C14C-piecewise-fare-splitting", "Requires comparing per-km averages of a piecewise fare and choosing the number of rides.",
  tita_answer=390, check=_c023, values=[390],
  tita_traps=[(495, r"Takes one ride: $195 + 25 \times 12$."),
              (405, r"Uses three rides of $8$ km: $3 \times (60 + 75)$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 024
def _c024():
    def cost(n):
        return 50 * n if n <= 99 else (45 * n if n <= 199 else 40 * n)
    return min(cost(n) for n in range(180, 400))
q("C14-C-024", TOPIC, "Buying more than needed to reach a cheaper price slab", "Easy",
  "Conceptual/application",
  r"A wholesaler prices notebooks by the size of the order: Rs. $50$ each for orders of up to $99$ notebooks, Rs. $45$ each for orders of $100$ to $199$ notebooks, and Rs. $40$ each for orders of $200$ or more (the rate applies to every notebook in the order). Kabir needs at least $180$ notebooks and may buy more. What is the least amount he must spend?",
  "MCQ",
  r"Buying exactly $180$ costs $180 \times 45 = 8{,}100$. Buying $200$ costs $200 \times 40 = 8{,}000$, which is less. Any order of $200$ or more costs at least $8{,}000$, and any order from $180$ to $199$ costs at least $8{,}100$, so the least amount is Rs. $8{,}000$.",
  "Assuming the cost always rises with the quantity bought.",
  "C14C-quantity-discount-piecewise", "One comparison across a slab boundary.",
  correct=r"Rs. $8{,}000$",
  distractors=[(r"Rs. $8{,}100$", r"Buys exactly $180$ notebooks at Rs. $45$."),
               (r"Rs. $9{,}000$", r"Prices $180$ notebooks at the first slab rate, Rs. $50$."),
               (r"Rs. $7{,}200$", r"Applies the Rs. $40$ rate to only $180$ notebooks.")],
  check=_c024, values=[8000, 8100, 9000, 7200], cognitive="Application")

# ---------------------------------------------------------------- 025
def _c025():
    def cost(n):
        return 50 * n if n <= 99 else (45 * n if n <= 199 else 40 * n)
    return sum(1 for n in range(1, 251) if any(cost(m) < cost(n) for m in range(n + 1, 501)))
q("C14-C-025", TOPIC, "Counting order sizes where a larger order is strictly cheaper", "Difficult",
  "Casework/optimisation",
  r"A printer charges for copies by the size of the order: Rs. $50$ per copy for orders of up to $99$ copies, Rs. $45$ per copy for orders of $100$ to $199$ copies, and Rs. $40$ per copy for orders of $200$ or more (the rate applies to every copy in the order). For how many order sizes $n$, with $1 \le n \le 250$, is there some larger order size that costs strictly less than an order of $n$ copies?",
  "TITA",
  r"The cost is $50n$, then $45n$, then $40n$, rising within each slab, so a larger order can only be cheaper if it is at the start of a higher slab. For $n \le 99$: $100$ copies cost $4{,}500 < 50n$ when $n > 90$, giving $n = 91$ to $99$, that is $9$ values ($200$ copies at $8{,}000$ never beat $50n \le 4{,}950$). For $100 \le n \le 199$: $200$ copies cost $8{,}000 < 45n$ when $n > 177.8$, giving $n = 178$ to $199$, that is $22$ values. For $n \ge 200$, no larger order is cheaper. Total $9 + 22 = 31$.",
  "Including the tie at $n = 90$ or miscounting the integers in a range.",
  "C14C-quantity-discount-piecewise", "Two slab boundaries, strict inequalities and careful integer counting.",
  tita_answer=31, check=_c025, values=[31],
  tita_traps=[(32, r"Counts $n = 90$, where $50 \times 90 = 4{,}500$ only ties with $100$ copies."),
              (30, r"Counts $178$ to $199$ as $21$ values.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 026
def _c026():
    h = symbols('h', real=True)
    S = 16 * h - h**2 + 12 * (10 - h) - (10 - h)**2
    return _extreme(S, h, 0, 10, "max")
q("C14-C-026", TOPIC, "Splitting fixed time between two activities with quadratic returns", "Medium",
  "Multi-step word problem",
  r"Sneha has $10$ hours of revision time left and will spend all of it on Mathematics and English (time can be split in any way). If she spends $m$ hours on Mathematics, her expected gain in Mathematics marks is $16m - m^2$; if she spends $e$ hours on English, her expected gain in English marks is $12e - e^2$. What is the greatest total expected gain in marks?",
  "TITA",
  r"With $e = 10 - m$, the total is $16m - m^2 + 12(10 - m) - (10 - m)^2 = -2m^2 + 24m + 20 = -2(m - 6)^2 + 92$. The best split is $6$ hours on Mathematics and $4$ on English, giving $60 + 32 = 92$ marks.",
  "Optimising each subject separately, which needs $8 + 6 = 14$ hours.",
  "C14C-allocation-two-quadratics", "Substitute the constraint, then one completion of the square.",
  tita_answer=92, check=_c026, values=[92],
  tita_traps=[(100, r"Adds the separate maxima $64 + 36$, which would need $14$ hours."),
              (90, r"Splits the time equally: $55 + 35$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 027
def _c027():
    best = None
    for x in _grid(0, 15, 300):
        for y in _grid(0, 15, 300):
            if x + y <= 15:
                v = 24 * x - 2 * x * x + 12 * y - y * y
                best = v if best is None else max(best, v)
    return best
q("C14-C-027", TOPIC, "Budget allocation when the budget need not be fully spent", "Medium",
  "Conceptual/application",
  r"A firm has up to Rs. $15$ lakh for advertising and need not spend all of it. Spending $x$ lakh on television brings extra sales of $24x - 2x^2$ lakh rupees, and spending $y$ lakh on radio brings extra sales of $12y - y^2$ lakh rupees (too much exposure reduces the response). What is the greatest total extra sales the firm can achieve?",
  "MCQ",
  r"Each response is a downward parabola: television peaks at $x = 6$ with $72$, radio at $y = 6$ with $36$. Together these need only $12 \le 15$ lakh, so both peaks are affordable and the greatest total is $72 + 36 = 108$ lakh rupees.",
  "Forcing the whole budget to be spent, which pushes both channels past their peaks.",
  "C14C-allocation-two-quadratics", "Must notice the budget constraint is slack and not substitute $x + y = 15$.",
  correct=r"Rs. $108$ lakh",
  distractors=[(r"Rs. $102$ lakh", r"Forces $x + y = 15$: maximising $-3x^2 + 42x - 45$ gives $x = 7$, $y = 8$, total $70 + 32$."),
               (r"Rs. $72$ lakh", "Spends only on television, the channel with the larger peak."),
               (r"Rs. $36$ lakh", "Spends only on radio.")],
  check=_c027, values=[108, 102, 72, 36], cognitive="Analysis")

# ---------------------------------------------------------------- 028
def _c028():
    t = symbols('t', real=True)
    lead = 50 + 20 * t - 2 * t**2
    tover = max(s for s in solve(Eq(lead, 0), t) if s.is_real)
    return _extreme(lead, t, 0, tover, "max")
q("C14-C-028", TOPIC, "Greatest lead between a uniform mover and an accelerating one", "Medium",
  "Multi-step word problem",
  r"Two cars are on a straight road. At $t = 0$, car Q is $50$ m ahead of car P and both start moving forward in the same direction. In the first $t$ seconds, P covers $2t^2$ metres and Q covers $20t$ metres. Before P overtakes Q, what is the greatest lead that Q has over P?",
  "MCQ",
  r"Q's lead is $50 + 20t - 2t^2 = 100 - 2(t - 5)^2$. It is greatest at $t = 5$ s, before P catches up (the lead is still positive), and equals $100$ m.",
  "Ignoring P's own distance, or using the wrong vertex time.",
  "C14C-lead-as-quadratic", "Model the gap as a quadratic, then find its vertex.",
  correct=r"$100$ m",
  distractors=[(r"$150$ m", r"Uses $t = 5$ but adds only Q's distance: $50 + 20 \times 5$."),
               (r"$50$ m", r"Takes the vertex time as $t = -\frac{b}{a} = 10$, where the lead is $50 + 200 - 200$."),
               (r"$0$ m", r"Sign slip in the vertex value: $c + \frac{b^2}{4a} = 50 - 50$.")],
  check=_c028, values=[100, 150, 50, 0], cognitive="Application")

# ---------------------------------------------------------------- 029
def _c029():
    x, a, b, c = symbols('x a b c', real=True)
    P = a * x**2 + b * x + c
    sol = solve([Eq(P.subs(x, 4), -12), Eq(P.subs(x, 10), 300), Eq(P.subs(x, 28), 372)], [a, b, c], dict=True)[0]
    Pf = P.subs(sol)
    assert sol[a] < 0
    return _extreme(Pf, x, None, None, "max")
q("C14-C-029", TOPIC, "Fitting a quadratic to three data points and finding its peak", "Medium",
  "Multi-step word problem",
  r"A factory's weekly profit $P$, in Rs. thousand, is a quadratic function of its weekly output $x$, in hundred units. Records show $P = -12$ at $x = 4$, $P = 300$ at $x = 10$ and $P = 372$ at $x = 28$. What is the greatest weekly profit the factory can make, in Rs. thousand?",
  "MCQ",
  r"Let $P = ax^2 + bx + c$. Then $P(10) - P(4) = 84a + 6b = 312$, so $14a + b = 52$; and $P(28) - P(10) = 684a + 18b = 72$, so $38a + b = 4$. Subtracting, $24a = -48$, so $a = -2$, $b = 80$, and $c = 300 - (-200 + 800) = -300$. The vertex is at $x = 20$, where $P = -800 + 1600 - 300 = 500$.",
  "Assuming the peak lies midway between two recorded outputs, or at the best recorded value.",
  "C14C-quadratic-from-data", "Three equations for the coefficients, then the vertex.",
  correct=r"$500$",
  distractors=[(r"$372$", "Takes the largest recorded profit as the greatest possible."),
               (r"$498$", r"Assumes the peak is midway between $x = 10$ and $x = 28$, at $x = 19$."),
               (r"$468$", r"Assumes the peak is midway between $x = 4$ and $x = 28$, at $x = 16$.")],
  check=_c029, values=[500, 372, 498, 468], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 030
def _c030():
    return max(120 + 13 * n - n * n for n in range(1, 200))
q("C14-C-030", TOPIC, "Largest term of a sequence given by a quadratic in n", "Easy",
  "Conceptual/application",
  r"The $n$th term of a sequence is $a_n = 120 + 13n - n^2$, for $n = 1, 2, 3, \ldots$. What is the largest term of the sequence?",
  "TITA",
  r"As a function of a real variable, $120 + 13n - n^2$ peaks at $n = 6.5$. For integers, the nearest values $n = 6$ and $n = 7$ give $120 + 78 - 36 = 162$ and $120 + 91 - 49 = 162$. The largest term is $162$.",
  "Reporting the real maximum $162.25$ or rounding it.",
  "C14C-quadratic-integer-domain", "Vertex at a half-integer; evaluate the two nearest integers.",
  tita_answer=162, check=_c030, values=[162],
  tita_traps=[(160, r"Evaluates at $n = 5$ or $n = 8$, misplacing the vertex."),
              (163, r"Rounds the real maximum $162.25$ up.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 031
def _c031():
    return min(3 * n * n - 44 * n + 200 for n in range(1, 200))
q("C14-C-031", TOPIC, "Least value of a quadratic over positive integers, vertex not an integer", "Medium",
  "Casework/optimisation",
  r"The least value of $3n^2 - 44n + 200$ as $n$ runs over the positive integers is",
  "MCQ",
  r"The real vertex is at $n = \frac{44}{6} \approx 7.33$. Check the integers on either side: $n = 7$ gives $147 - 308 + 200 = 39$ and $n = 8$ gives $192 - 352 + 200 = 40$. The least value is $39$.",
  "Using the real minimum, or rounding the vertex the wrong way.",
  "C14C-quadratic-integer-domain", "Non-integer vertex; must compare the two neighbouring integers.",
  correct=r"$39$",
  distractors=[(r"$38$", r"Takes the real minimum $200 - \frac{44^2}{12} \approx 38.67$ and rounds it down."),
               (r"$40$", r"Rounds the vertex $7.33$ up to $n = 8$."),
               (r"$215$", r"Uses $n = -\frac{b}{a} \approx 14.67$ as the vertex and rounds to $n = 15$: $675 - 660 + 200$.")],
  check=_c031, values=[39, 38, 40, 215], cognitive="Application")

# ---------------------------------------------------------------- 032
def _c032():
    total, best = 0, 0
    for d in range(1, 100):
        total += 40 - 3 * (d - 1)
        best = max(best, total)
    return best
q("C14-C-032", TOPIC, "Greatest cumulative total of a decreasing arithmetic sequence", "Medium",
  "Multi-step word problem",
  r"On day $1$ a reservoir's stored water rises by a net $40$ kilolitres. On each later day the net rise is $3$ kilolitres less than on the previous day, so after some days the stored water starts to fall. Measured at the end of a day, what is the greatest amount by which the stored water exceeds its level at the start of day $1$?",
  "MCQ",
  r"The daily changes are $40, 37, 34, \ldots$, with day $n$ change $43 - 3n$. They are positive up to day $14$ (change $1$) and negative from day $15$ (change $-2$). The cumulative total is therefore greatest after day $14$: $\frac{14}{2}(40 + 1) = 287$ kilolitres.",
  "Stopping one day early or one day late, or mis-indexing the $n$th term.",
  "C14C-quadratic-integer-domain", "The cumulative sum is a quadratic in $n$; stop when the terms change sign.",
  correct=r"$287$ kilolitres",
  distractors=[(r"$286$ kilolitres", r"Stops after day $13$, taking the floor of the real vertex $n = \frac{83}{6}$."),
               (r"$285$ kilolitres", r"Includes day $15$, whose change $-2$ is a fall."),
               (r"$266$ kilolitres", r"Uses $a_n = a + nd$, so the day-$14$ term is $-2$: $\frac{14}{2}(40 - 2)$.")],
  check=_c032, values=[287, 286, 285, 266], cognitive="Application")

# ---------------------------------------------------------------- 033
def _c033():
    xs = _grid(0, 7, 7000)
    return max(abs(x * x - 4 * x - 5) for x in xs)
q("C14-C-033", TOPIC, "Greatest value of the modulus of a quadratic on an interval", "Easy",
  "Conceptual/application",
  r"For $0 \le x \le 7$, the greatest value of $|x^2 - 4x - 5|$ is",
  "MCQ",
  r"$x^2 - 4x - 5 = (x - 2)^2 - 9$ ranges from $-9$ (at $x = 2$) up to $(7 - 2)^2 - 9 = 16$ (at $x = 7$) on the interval. The modulus is therefore at most $\max(9, 16) = 16$, reached at $x = 7$.",
  "Assuming the largest modulus occurs at the vertex.",
  "C14C-modulus-of-quadratic-interval", "Compare the vertex value and the endpoint values after taking the modulus.",
  correct=r"$16$",
  distractors=[(r"$9$", r"Takes the vertex value $|-9|$ as the greatest."),
               (r"$5$", r"Evaluates only at the left endpoint $x = 0$."),
               (r"$0$", r"Reports the least value, reached at the root $x = 5$.")],
  check=_c033, values=[16, 9, 5, 0], cognitive="Understanding")

# ---------------------------------------------------------------- 034
def _c034():
    xs = _grid(1, 7, 600)
    vals = [x * x - 6 * x for x in xs]
    best = None
    for a in _grid(-20, 20, 4000):
        M = max(abs(v - a) for v in (min(vals), max(vals)))
        best = M if best is None else min(best, M)
    return int(best)
q("C14-C-034", TOPIC, "Choosing a shift to minimise the greatest deviation of a quadratic", "Difficult",
  "Inverse/parameter",
  r"For a real number $a$, let $M(a)$ be the greatest value of $|x^2 - 6x - a|$ over $1 \le x \le 7$. What is the least possible value of $M(a)$?",
  "TITA",
  r"On $1 \le x \le 7$, $x^2 - 6x = (x - 3)^2 - 9$ takes every value from $-9$ (at $x = 3$) to $7$ (at $x = 7$). So $M(a) = \max(|{-9} - a|, |7 - a|)$, the larger distance from $a$ to the ends of $[-9, 7]$. This is least when $a$ is the midpoint $-1$, giving $M = 8$.",
  "Leaving $a = 0$, or taking the full width of the range instead of half.",
  "C14C-minimax-shift", "Needs the range of the quadratic on the interval and then a min of a max over the parameter.",
  tita_answer=8, check=_c034, values=[8],
  tita_traps=[(9, r"Keeps $a = 0$: $\max(9, 7)$."),
              (16, r"Reports the width of the range $7 - (-9)$ instead of half of it.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 035
def _c035():
    xs = _grid(-10, 20, 3000)
    return min(max((x - 2)**2, (x - 6)**2) for x in xs)
q("C14-C-035", TOPIC, "Least value of the larger of two congruent parabolas", "Easy",
  "Conceptual/application",
  r"For real $x$, let $f(x)$ be the larger of $(x - 2)^2$ and $(x - 6)^2$. The least possible value of $f(x)$ is",
  "MCQ",
  r"$f(x)$ is the square of the larger of the distances from $x$ to $2$ and to $6$. That larger distance is least, equal to $2$, at the midpoint $x = 4$. So the least value is $2^2 = 4$.",
  "Thinking either square can be made zero while the other is ignored.",
  "C14C-max-of-two-parabolas", "One symmetry idea: balance the two distances.",
  correct=r"$4$",
  distractors=[(r"$0$", r"Makes one square zero (at $x = 2$ or $x = 6$) and ignores the other."),
               (r"$16$", r"Evaluates at $x = 2$ or $x = 6$, where the other square is $16$."),
               (r"$2$", r"Reports the least larger distance $2$ without squaring it.")],
  check=_c035, values=[4, 0, 16, 2], cognitive="Understanding")

# ---------------------------------------------------------------- 036
def _c036():
    x = symbols('x', real=True)
    f1, f2 = x**2 - 6 * x, 8 - x**2
    pts = set(solve(Eq(f1, f2), x)) | set(solve(diff(f1, x), x)) | set(solve(diff(f2, x), x))
    best = min(max(f1.subs(x, p), f2.subs(x, p)) for p in pts)
    g = min(max(Fraction(v)**2 - 6 * Fraction(v), 8 - Fraction(v)**2) for v in _grid(-10, 15, 2500))
    assert g >= best
    return best
q("C14-C-036", TOPIC, "Least value of the larger of an upward and a downward parabola", "Medium",
  "Casework/optimisation",
  r"For real $x$, let $g(x) = \max(x^2 - 6x,\ 8 - x^2)$. The least possible value of $g(x)$ is",
  "MCQ",
  r"The parabolas meet where $x^2 - 6x = 8 - x^2$, that is $x^2 - 3x - 4 = 0$, so $x = -1$ or $x = 4$. Between these, $8 - x^2$ is on top (at $x = 0$ it is $8$ against $0$), and on $[-1, 4]$ it is least at $x = 4$, value $-8$. Outside, $g = x^2 - 6x$, which exceeds $-8$ for $x > 4$ and exceeds $7$ for $x < -1$. The least value is $-8$.",
  "Using the vertex of $x^2 - 6x$, where the other parabola is higher.",
  "C14C-curve-envelope-crossing", "Two curves, two crossings, and the minimum at a crossing rather than a vertex.",
  correct=r"$-8$",
  distractors=[(r"$-9$", r"Reports the least value of $x^2 - 6x$ at $x = 3$, where $8 - x^2 = -1$ is larger."),
               (r"$-1$", r"Evaluates $g$ at the vertex $x = 3$: $\max(-9, -1)$."),
               (r"$7$", r"Uses the other crossing $x = -1$.")],
  check=_c036, values=[-8, -9, -1, 7], cognitive="Analysis")

# ---------------------------------------------------------------- 037
def _c037():
    def f(x):
        if x <= -1:
            return x * x + 6 * x + 4
        if x <= 2:
            return 2 * x - 1
        return x * x - 8 * x + 15
    xs = _grid(-20, 20, 8000)
    return min(f(x) for x in xs)
q("C14-C-037", TOPIC, "Least value of a function defined piece by piece", "Medium",
  "Casework/optimisation",
  r"A function is defined by $f(x) = x^2 + 6x + 4$ for $x \le -1$, $f(x) = 2x - 1$ for $-1 < x \le 2$, and $f(x) = x^2 - 8x + 15$ for $x > 2$. The least value of $f(x)$ over all real $x$ is",
  "MCQ",
  r"First piece: $(x + 3)^2 - 5$, and $x = -3$ lies in $x \le -1$, so it reaches $-5$. Second piece: $2x - 1 > -3$ on $-1 < x \le 2$. Third piece: $(x - 4)^2 - 1$, with $x = 4$ in $x > 2$, so its least value is $-1$. The overall least value is $-5$.",
  "Checking only the junction points, or only one of the quadratic pieces.",
  "C14C-piecewise-defined-extremes", "Three pieces, each with its own extreme to locate and compare.",
  correct=r"$-5$",
  distractors=[(r"$-1$", r"Finds only the vertex value of the third piece."),
               (r"$-3$", r"Uses the second piece at $x = -1$, which belongs to the first piece."),
               (r"$3$", r"Checks only the junction at $x = 2$.")],
  check=_c037, values=[-5, -1, -3, 3], cognitive="Application")

# ---------------------------------------------------------------- 038
def _c038():
    xs = _grid(0, 16, 1600)
    return int(max(min(abs(x - 2), abs(x - 5), abs(x - 11)) for x in xs))
q("C14-C-038", TOPIC, "Greatest distance from the nearest of several points on a segment", "Easy",
  "Conceptual/application",
  r"A straight road runs from kilometre mark $0$ to kilometre mark $16$. There are petrol pumps at marks $2$, $5$ and $11$. For a point on the road, consider its distance to the nearest pump. What is the greatest value of this distance over all points on the road, in km?",
  "TITA",
  r"Between two adjacent pumps the worst point is the midpoint, at half the gap: $1.5$ km for the $2$ to $5$ gap and $3$ km for the $5$ to $11$ gap. At the ends there is no pump beyond, so the worst points are the ends: $2$ km at mark $0$ and $16 - 11 = 5$ km at mark $16$. The greatest is $5$ km.",
  "Halving every gap, including the stretches at the ends of the road.",
  "C14C-nearest-point-distance", "Max of a min of distances; the end stretch behaves differently.",
  tita_answer=5, check=_c038, values=[5],
  tita_traps=[(3, r"Takes half the largest gap between pumps, $\frac{11 - 5}{2}$, ignoring the end of the road."),
              (6, r"Takes the largest gap between pumps, $11 - 5$, without halving.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 039
def _c039():
    xs = _grid(0, 20, 400)
    best = None
    for p in _grid(0, 20, 400):
        w = max(min(abs(x - 3), abs(x - 9), abs(x - 12), abs(x - p)) for x in xs)
        best = w if best is None else min(best, w)
    return int(best)
q("C14-C-039", TOPIC, "Adding one point to minimise the greatest distance to the nearest point", "Medium",
  "Casework/optimisation",
  r"A straight highway runs from kilometre mark $0$ to kilometre mark $20$, with ATMs at marks $3$, $9$ and $12$. One more ATM is to be installed somewhere on the highway so that the greatest distance from any point of the highway to its nearest ATM is as small as possible. What is this least possible greatest distance, in km?",
  "TITA",
  r"Without the new ATM, the worst stretches are the end $12$ to $20$ (up to $8$ km), the start $0$ to $3$ ($3$ km) and the middle of the $3$ to $9$ gap ($3$ km). One new ATM can fix only one region. Placing it in $12$ to $20$, say at mark $17$, reduces that stretch to at most $3$ km (from mark $20$) and $2.5$ km (between $12$ and $17$). The start and the $3$ to $9$ gap still give $3$ km, and no single placement can improve those too. The answer is $3$ km.",
  "Optimising the end stretch alone and ignoring the distances that the new ATM cannot affect.",
  "C14C-nearest-point-distance", "Min of a max of min-distances; must see which stretch a single new point can fix.",
  tita_answer=3, check=_c039, values=[3],
  tita_traps=[(4, r"Puts the new ATM at mark $16$, the midpoint of $12$ to $20$, leaving $4$ km at mark $20$."),
              (8, r"Puts the new ATM inside the $3$ to $9$ gap, leaving the $8$ km end stretch.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 040
def _c040():
    def f(v):
        return 2 * v * v - 8 * v + 3
    best = None
    for a in _grid(-3, 5, 1600):
        pts = [a, a + 3] + ([Fraction(2)] if a <= 2 <= a + 3 else [])
        d = max(f(v) for v in pts) - min(f(v) for v in pts)
        best = d if best is None else min(best, d)
    return best
q("C14-C-040", TOPIC, "Window of fixed width that minimises the spread of a quadratic", "Difficult",
  "Conceptual/application",
  r"For a real number $a$, let $D(a)$ be the difference between the greatest and the least values of $2x^2 - 8x + 3$ over the interval $a \le x \le a + 3$. The least possible value of $D(a)$ is",
  "MCQ",
  r"$2x^2 - 8x + 3 = 2(x - 2)^2 - 5$. If the vertex $x = 2$ is outside the window, the function is monotonic there and the spread is at least as large as when the vertex is inside. With the vertex inside, the least value is $-5$ and the greatest is at the farther endpoint, at distance at least $1.5$ from $x = 2$; this is smallest when the window is centred at $2$, that is $a = \frac{1}{2}$. Then $D = 2(1.5)^2 = \frac{9}{2}$.",
  "Placing the vertex at an end of the window, or dropping the leading coefficient.",
  "C14C-window-spread", "Needs the symmetry argument for where to place a fixed-width window on a parabola.",
  correct=r"$\frac{9}{2}$",
  distractors=[(r"$\frac{9}{4}$", r"Drops the leading coefficient $2$: $(1.5)^2$."),
               (r"$18$", r"Puts the vertex at an end of the window ($a = 2$): $2 \times 3^2$."),
               (r"$8$", r"Takes $a = 1$, a window centred at $2.5$: greatest $f(4) = 3$, least $-5$.")],
  check=_c040, values=[Rational(9, 2), Rational(9, 4), 18, 8], cognitive="Analysis", exams=HARD)
