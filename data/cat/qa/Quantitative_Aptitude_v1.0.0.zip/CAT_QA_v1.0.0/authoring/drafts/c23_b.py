import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Bases and factorials"
HARD = ("CAT", "XAT")


def _to_base(n, b):
    if n == 0:
        return "0"
    ds = []
    while n:
        ds.append(str(n % b))
        n //= b
    return "".join(reversed(ds))


def _val(s, b):
    v = 0
    for ch in s:
        v = v * b + int(ch)
    return v


def _trailing_zeros_dec(n):
    s = str(n)
    return len(s) - len(s.rstrip("0"))


def _mult(n, d):
    # largest k with d^k | n, by repeated division
    k = 0
    while n % d == 0:
        n //= d
        k += 1
    return k


# 001
def _c1():
    return 3 * 5**3 + 1 * 5**2 + 4 * 5 + 2
q("C23-B-001", T, "Convert a base-5 numeral to decimal", "Easy",
  "Single-step computation",
  r"A toy robot counts in base $5$. It reports that a jar holds $3142$ marbles, this numeral being in base $5$. How many marbles does the jar hold, written in the usual decimal system?",
  "MCQ",
  r"The place values in base $5$ are $125, 25, 5, 1$. So $3142_5 = 3 \times 125 + 1 \times 25 + 4 \times 5 + 2 = 375 + 25 + 20 + 2 = 422$.",
  "Misplacing digits against their place values, or shifting all place values by one power.",
  "C23B-base-positional-conversion", "One positional expansion with small powers of 5.",
  correct=r"$422$",
  distractors=[(r"$482$", "Swaps the middle digits: $3 \\times 125 + 4 \\times 25 + 1 \\times 5 + 2 = 482$."),
               (r"$358$", "Reads the numeral from the right: $2 \\times 125 + 4 \\times 25 + 1 \\times 5 + 3 = 358$."),
               (r"$2110$", "Shifts every place value up one power: $3 \\times 625 + 1 \\times 125 + 4 \\times 25 + 2 \\times 5 = 2110$.")],
  check=_c1, values=[422, 482, 358, 2110], cognitive="Recall")

# 002
def _c2():
    return int(_to_base(2026, 7))
q("C23-B-002", T, "Convert a decimal number to base 7 by repeated division", "Easy",
  "Single-step computation",
  r"The number $2026$ (decimal) is written in base $7$, giving a four-digit numeral. Type that base-$7$ numeral exactly as it appears, digits only.",
  "TITA",
  r"Powers of $7$: $343, 49, 7, 1$. $2026 = 5 \times 343 + 311$, $311 = 6 \times 49 + 17$, $17 = 2 \times 7 + 3$. So $2026 = 5623_7$. Check: $1715 + 294 + 14 + 3 = 2026$.",
  "Writing the remainders of repeated division in the order they are obtained, which reverses the numeral.",
  "C23B-base-positional-conversion", "Three divisions with a basic calculator.",
  tita_answer=5623, check=_c2,
  tita_traps=[(3265, "Repeated division by $7$ gives remainders $3, 2, 6, 5$; typing them in that order reverses the numeral."),
              (5622, "Arithmetic slip in the last step, taking $17 = 2 \\times 7 + 2$.")],
  cognitive="Application")

# 003
def _c3():
    a, b = "2453", "1354"
    da = [int(c) for c in reversed(a)]
    db = [int(c) for c in reversed(b)]
    out, carry = [], 0
    for i in range(4):
        s = da[i] + db[i] + carry
        out.append(s % 6)
        carry = s // 6
    if carry:
        out.append(carry)
    res = "".join(str(d) for d in reversed(out))
    assert _val(res, 6) == _val(a, 6) + _val(b, 6)
    return _val(res, 6)
q("C23-B-003", T, "Column addition with carries in base 6", "Easy",
  "Single-step computation",
  r"Two numbers are written in base $6$ as $2453$ and $1354$. Their sum, written in base $6$, is",
  "MCQ",
  r"Add column by column, carrying $1$ for every $6$. Units: $3 + 4 = 7 = 1 \cdot 6 + 1$, write $1$, carry $1$. Sixes: $5 + 5 + 1 = 11 = 1 \cdot 6 + 5$, write $5$, carry $1$. Thirty-sixes: $4 + 3 + 1 = 8 = 1 \cdot 6 + 2$, write $2$, carry $1$. Last: $2 + 1 + 1 = 4$. The sum is $4251_6$. (Check in decimal: $609 + 358 = 967 = 4 \cdot 216 + 2 \cdot 36 + 5 \cdot 6 + 1$.)",
  "Dropping carries, or reversing the digits when converting back.",
  "C23B-base-column-arithmetic", "One column addition; the only trap is carrying at 6.",
  correct=r"$4251$",
  distractors=[(r"$3141$", "Reduces each column modulo $6$ but never carries: $7 \\to 1$, $10 \\to 4$, $7 \\to 1$, $3$."),
               (r"$1524$", "Adds via decimal ($967$) and writes the base-$6$ remainders $1, 5, 2, 4$ in the order obtained."),
               (r"$4241$", "Carries correctly from every column except the first: $5 + 5 = 10$ gives $4$ with carry, then $4 + 3 + 1 = 8$ gives $2$, then $4$.")],
  check=_c3, values=[_val("4251", 6), _val("3141", 6), _val("1524", 6), _val("4241", 6)],
  cognitive="Application")

# 004
def _c4():
    a, b = [int(c) for c in reversed("4021")], [int(c) for c in reversed("1356")]
    out, borrow = [], 0
    for i in range(4):
        d = a[i] - borrow - b[i]
        if d < 0:
            d += 7
            borrow = 1
        else:
            borrow = 0
        out.append(d)
    res = "".join(str(d) for d in reversed(out))
    assert _val(res, 7) == _val("4021", 7) - _val("1356", 7)
    return _val(res, 7)
q("C23-B-004", T, "Column subtraction with repeated borrowing in base 7", "Medium",
  "Multi-step word problem",
  r"On the planet Septa, all quantities are written in base $7$. A reservoir held $4021$ kilolitres of water, and $1356$ kilolitres were then drawn out, both amounts written in base $7$. How much water is left, written in base $7$, in kilolitres?",
  "MCQ",
  r"Subtract column by column, borrowing $7$ each time. Units: $1 < 6$, borrow: $8 - 6 = 2$. Sevens: $2 - 1 = 1 < 5$, borrow: $8 - 5 = 3$. Forty-nines: $0 - 1 < 3$, borrow: $6 - 3 = 3$. Last: $4 - 1 - 1 = 2$. The answer is $2332_7$. Check: $4021_7 = 1387$, $1356_7 = 531$, and $1387 - 531 = 856 = 2 \cdot 343 + 3 \cdot 49 + 3 \cdot 7 + 2$.",
  "Borrowing $10$ out of decimal habit, or not reducing the next digit after a borrow.",
  "C23B-base-column-arithmetic", "Three consecutive borrows across a zero in a non-decimal base.",
  correct=r"$2332$",
  distractors=[(r"$2665$", "Borrows $10$ instead of $7$ in each column: $11 - 6 = 5$, $11 - 5 = 6$, $9 - 3 = 6$, $4 - 1 - 1 = 2$."),
               (r"$3442$", "Borrows $7$ but never reduces the next digit: $8 - 6 = 2$, $9 - 5 = 4$, $7 - 3 = 4$, $4 - 1 = 3$."),
               (r"$3335$", "Subtracts the smaller digit from the larger in each column: $5, 3, 3, 3$.")],
  check=_c4, values=[_val("2332", 7), _val("2665", 7), _val("3442", 7), _val("3335", 7)],
  cognitive="Application")

# 005
def _c5():
    sols = [b for b in range(6, 200) if _val("23", b) + _val("45", b) == _val("101", b)]
    assert len(sols) == 1
    return sols[0]
q("C23-B-005", T, "Find the base in which a given addition is correct", "Easy",
  "Inverse/parameter",
  r"Kabir writes $23 + 45 = 101$. The statement is correct when all three numerals are read in the same base $b$. What is $b$?",
  "MCQ",
  r"In base $b$: $(2b + 3) + (4b + 5) = b^2 + 1$, so $b^2 - 6b - 7 = 0$, that is $(b - 7)(b + 1) = 0$, giving $b = 7$. Quick check: units $3 + 5 = 8 = 7 + 1$ (write $1$, carry $1$); then $2 + 4 + 1 = 7 = 10_7$, giving $101_7$.",
  "Ignoring the carry from the units column, or stopping at the digit-size condition.",
  "C23B-unknown-base-equation", "One equation in $b$ that factorises at once.",
  correct=r"$7$",
  distractors=[(r"$6$", "Uses only the digit condition: the smallest base allowed by the digit $5$ is $6$."),
               (r"$8$", "Takes the units-column total $3 + 5 = 8$ as the base, overlooking the written units digit $1$."),
               (r"$9$", "Reads the written units digit $1$ as the carry and adds it to the units total: $3 + 5 + 1 = 9$.")],
  check=_c5, values=[7, 6, 8, 9], cognitive="Application")

# 006
def _c6():
    sols = [b for b in range(4, 200) if _val("1331", b) == 2197]
    assert len(sols) == 1
    return sols[0]
q("C23-B-006", T, "Recognise 1331 in base b as (b+1) cubed", "Medium",
  "Conceptual/application",
  r"In a certain base $b$, the numeral $1331$ represents the decimal number $2197$. What is $b$, written in decimal?",
  "TITA",
  r"$1331_b = b^3 + 3b^2 + 3b + 1 = (b + 1)^3$. Since $2197 = 13^3$, $b + 1 = 13$ and $b = 12$.",
  "Reporting $b + 1$ instead of $b$.",
  "C23B-unknown-base-equation", "Needs the binomial pattern in the place values; brute force would be slow.",
  tita_answer=12, check=_c6,
  tita_traps=[(13, "Finds $(b + 1)^3 = 13^3$ and reports $b + 1$."),
              (11, "Uses $1331 = 11^3$ in decimal and assumes the base is $11$.")],
  cognitive="Analysis")

# 007
def _c7():
    b = symbols('b', positive=True, integer=True)
    sol = [s for s in solve(Eq(2*b**2 + 4*b + 3, (b + 2)**2 + 4*(b + 2) + 3), b) if s > 4]
    assert len(sol) == 1
    bb = int(sol[0])
    assert _val("243", bb) == _val("143", bb + 2)
    return _val("243", bb)
q("C23-B-007", T, "Same number written in two related bases", "Medium",
  "Inverse/parameter",
  r"A positive integer $N$ is written as $243$ in base $b$ and as $143$ in base $b + 2$. What is the value of $N$ in decimal?",
  "MCQ",
  r"$2b^2 + 4b + 3 = (b + 2)^2 + 4(b + 2) + 3 = b^2 + 8b + 15$, so $b^2 - 4b - 12 = 0$, that is $(b - 6)(b + 2) = 0$ and $b = 6$. Then $N = 243_6 = 72 + 24 + 3 = 99$; check: $143_8 = 64 + 32 + 3 = 99$.",
  "Evaluating a numeral in the wrong one of the two bases after finding $b$.",
  "C23B-unknown-base-equation", "Set up and solve a quadratic in the base, then convert.",
  correct=r"$99$",
  distractors=[(r"$163$", "Evaluates $243$ in base $8$ (the larger base): $128 + 32 + 3 = 163$."),
               (r"$63$", "Evaluates $143$ in base $6$ (the smaller base): $36 + 24 + 3 = 63$."),
               (r"$143$", "Reads the base-$(b+2)$ numeral $143$ as a decimal number.")],
  check=_c7, values=[99, 163, 63, 143], cognitive="Application")

# 008
def _c8():
    return sum(1 for n in range(1, 1000) if len(_to_base(n, 4)) == 5)
q("C23-B-008", T, "Count integers below a bound having a given number of base-4 digits", "Easy",
  "Conceptual/application",
  r"How many positive integers less than $1000$ have exactly $5$ digits when written in base $4$?",
  "TITA",
  r"A base-$4$ numeral has exactly $5$ digits when the number is from $4^4 = 256$ to $4^5 - 1 = 1023$. Below $1000$ this is $256$ to $999$, which is $999 - 256 + 1 = 744$ numbers.",
  "Ignoring the upper limit of $1000$, or an off-by-one in counting an inclusive range.",
  "C23B-digit-length-in-base", "One range from powers of 4, cut off by the given bound.",
  tita_answer=744, check=_c8,
  tita_traps=[(768, "Counts every five-digit base-$4$ number, $256$ to $1023$, ignoring the bound $1000$."),
              (743, "Computes $999 - 256$ without adding $1$ for the inclusive range.")],
  cognitive="Understanding")

# 009
def _c9():
    return sum(1 for n in range(1, 701) if bin(n).count("1") == 3)
q("C23-B-009", T, "Count numbers up to 700 with exactly three 1s in binary", "Difficult",
  "Casework/optimisation",
  r"The lockers in a gym are numbered $1$ to $700$. Each locker shows its number in binary (base $2$) using a row of lights, where a lit light means the digit $1$. How many lockers show exactly three lit lights?",
  "MCQ",
  r"$700 = 1010111100_2$. Numbers below $512$ use $9$ binary places: $\binom{9}{3} = 84$ have three $1$s. From $512$ to $700$, the leading $1$ is lit and $m = n - 512$ runs from $0$ to $188$ with exactly two $1$s. Since $188 < 256$, split at $128$: below $128$ there are $\binom{7}{2} = 21$; from $128$ to $188$ we need $128 + z$ with $z \le 60$ a power of $2$, giving $z = 1, 2, 4, 8, 16, 32$, so $6$ more. Total $84 + 21 + 6 = 111$.",
  "Ignoring the upper limit, or missing the partial block just below 200.",
  "C23B-binary-digit-counting", "Three nested levels of casework on binary place values, with a zero bit to skip and a partial block at the bottom.",
  correct=r"$111$",
  distractors=[(r"$120$", "Uses $\\binom{10}{3} = 120$, counting all $10$-bit numbers up to $1023$ and ignoring the limit $700$."),
               (r"$84$", "Counts only the numbers below $512$, $\\binom{9}{3} = 84$."),
               (r"$105$", "Handles $512$ to $639$ but misses $641, 642, 644, 648, 656$ and $672$: $84 + 21 = 105$.")],
  check=_c9, values=[111, 120, 84, 105], cognitive="Analysis", exams=HARD)

# 010
def _c10():
    n, count = 0, 0
    while True:
        if "4" not in str(n):
            if n == 2050:
                return count
            count += 1
        n += 1
q("C23-B-010", T, "Meter that skips the digit 4 behaves like base 9", "Medium",
  "Conceptual/application",
  r"A faulty taxi meter never shows the digit $4$. In every position it goes straight from $3$ to $5$, and otherwise it counts normally; for example, after $13$ it shows $15$, and after $39$ it shows $50$. The meter advances one step for every kilometre travelled. It showed $0000$ at the start of a journey and shows $2050$ at the end. How many kilometres, in decimal, did the taxi actually travel?",
  "TITA",
  r"Each position uses only the nine digits $0, 1, 2, 3, 5, 6, 7, 8, 9$, so the meter is really counting in base $9$, with displayed $5$ to $9$ standing for base-$9$ digits $4$ to $8$. The display $2050$ means base-$9$ digits $2, 0, 4, 0$, so the distance is $2 \times 729 + 0 \times 81 + 4 \times 9 + 0 = 1458 + 36 = 1494$ km.",
  "Using the displayed digit 5 as a base-9 digit without shifting it down, or scaling the reading by 9/10.",
  "C23B-skipped-digit-counter", "Needs the insight that a counter missing one digit is a base-9 counter, plus the digit remapping.",
  tita_answer=1494, check=_c10,
  tita_traps=[(1503, "Reads $2050$ directly as a base-$9$ numeral: $2 \\times 729 + 5 \\times 9 = 1503$."),
              (1845, "Assumes one reading in ten is skipped and takes $\\frac{9}{10} \\times 2050 = 1845$.")],
  cognitive="Analysis")

# 011
def _c11():
    n, count = 0, 0
    while True:
        s = str(n)
        if "3" not in s and "7" not in s:
            if count == 1000:
                return n
            count += 1
        n += 1
q("C23-B-011", T, "Odometer missing two digits; find the display for a given distance", "Difficult",
  "Multi-step word problem",
  r"A defective odometer never shows the digits $3$ or $7$. In every position it goes straight from $2$ to $4$ and from $6$ to $8$, and otherwise counts normally, advancing one step for every kilometre. It showed $0000$ at the start of a trip. After the car has actually travelled $1000$ km, what does the odometer show?",
  "MCQ",
  r"Each position has the eight digits $0, 1, 2, 4, 5, 6, 8, 9$, so the odometer counts in base $8$, with displayed $0, 1, 2, 4, 5, 6, 8, 9$ standing for $0$ to $7$. In base $8$: $1000 = 1 \times 512 + 7 \times 64 + 5 \times 8 + 0$, that is $1750_8$. Translate the digits: $1 \to 1$, $7 \to 9$, $5 \to 6$, $0 \to 0$. The display is $1960$.",
  "Off-by-one on the starting reading, or remapping as if only one digit were skipped.",
  "C23B-skipped-digit-counter", "Reverse direction (distance to display), two missing digits, base-8 conversion and digit remapping.",
  correct=r"$1960$",
  distractors=[(r"$1959$", "Counts the starting reading $0000$ as the first kilometre, so takes position $999$: $999 = 1747_8$, remapped to $1959$."),
               (r"$1860$", "Remaps as if only the digit $3$ were missing, shifting every base-$8$ digit from $3$ up by one: $7 \\to 8$, $5 \\to 6$."),
               (r"$1250$", "Assumes $8$ of every $10$ readings are used and scales: $1000 \\times \\frac{10}{8} = 1250$.")],
  check=_c11, values=[1960, 1959, 1860, 1250], cognitive="Analysis", exams=HARD)

# 012
def _c12():
    w = [1, 3, 9, 27, 81]
    reps = {}
    for signs in itertools.product((-1, 0, 1), repeat=5):
        m = sum(s * x for s, x in zip(signs, w))
        if 1 <= m <= 121:
            reps.setdefault(m, []).append(signs)
    assert len(reps) == 121 and all(len(v) == 1 for v in reps.values())
    return sum(1 for m, v in reps.items() if all(s != 0 for s in v[0]))
q("C23-B-012", T, "Balanced ternary weighing: masses needing every weight", "Difficult",
  "Conceptual/application",
  r"A shopkeeper has exactly one weight of each of $1$, $3$, $9$, $27$ and $81$ grams, and a two-pan balance. The object being weighed always goes on the left pan, and each weight may be put on either pan or left out. Every whole number of grams from $1$ to $121$ can be weighed in this way, and in exactly one way. For how many of these $121$ masses must all five weights be used?",
  "TITA",
  r"A mass $m$ is weighed when $m = \sum e_i w_i$ with each $e_i \in \{-1, 0, 1\}$ ($+1$ on the right pan, $-1$ on the object's pan); this is the balanced base-$3$ form of $m$, which is unique. All five weights are used exactly when every $e_i$ is $\pm 1$. The $81$ g weight then decides the sign, since $1 + 3 + 9 + 27 = 40 < 81$, so it must be $+1$; the other four signs are free. That gives $2^4 = 16$ masses.",
  "Counting all sign patterns without requiring a positive mass.",
  "C23B-balanced-ternary-weights", "Needs the balanced base-3 model and a sign argument, not trial weighing.",
  tita_answer=16, check=_c12,
  tita_traps=[(32, "Counts all $2^5$ sign patterns with every weight used, including the negative totals."),
              (1, "Thinks all five weights are needed only for $121$ g, with every weight on the right pan.")],
  cognitive="Analysis", exams=HARD)

# 013
def _c13():
    ks = [k for k in range(9) if _val("73" + str(k) + "52", 9) % 8 == 0]
    assert len(ks) == 1
    return ks[0]
q("C23-B-013", T, "Divisibility by b-1 through the digit sum in base 9", "Medium",
  "Inverse/parameter",
  r"The five-digit base-$9$ numeral $73k52$, where $k$ is a single base-$9$ digit, represents a number divisible by $8$. What is $k$?",
  "TITA",
  r"Since $9 \equiv 1 \pmod 8$, every power of $9$ leaves remainder $1$ on division by $8$, so a base-$9$ number leaves the same remainder as its digit sum. The digit sum is $7 + 3 + k + 5 + 2 = 17 + k$, which lies between $17$ and $25$ for $k = 0, \ldots, 8$. The only multiple of $8$ in that range is $24$, so $k = 7$.",
  "Applying the decimal rule for 9 instead of the base-9 rule for 8.",
  "C23B-digit-sum-divisibility-base", "Needs the b-1 digit-sum rule in base 9.",
  tita_answer=7, check=_c13,
  tita_traps=[(1, "Uses the decimal habit of digit sum divisible by $9$: $17 + 1 = 18$."),
              (6, "Leaves out the leading digit $7$ and makes $10 + k$ a multiple of $8$.")],
  cognitive="Analysis")

# 014
def _c14():
    sols = []
    for N in range(1, 81):
        s7, s9 = _to_base(N, 7), _to_base(N, 9)
        if len(s7) == 2 and len(s9) == 2 and s7 == s9[::-1]:
            sols.append(N)
    assert len(sols) == 1
    return sols[0]
q("C23-B-014", T, "Two-digit number whose digits reverse between base 7 and base 9", "Medium",
  "Inverse/parameter",
  r"A positive integer $N$ is a two-digit numeral both in base $7$ and in base $9$. In base $7$ its digits are $x$ then $y$; in base $9$ its digits are $y$ then $x$. What is $N$ in decimal?",
  "MCQ",
  r"$7x + y = 9y + x$, so $6x = 8y$, that is $3x = 4y$. With $x, y$ nonzero digits below $7$ (both are leading digits somewhere), the only solution is $x = 4$, $y = 3$. Hence $N = 7 \times 4 + 3 = 31$; check: $31 = 3 \times 9 + 4 = 34_9$.",
  "Reading one of the numerals in the wrong base, or as a decimal number.",
  "C23B-digits-across-two-bases", "One linear Diophantine relation plus digit limits, then evaluation.",
  correct=r"$31$",
  distractors=[(r"$43$", "Gives the base-$7$ numeral $43$ as if it were decimal."),
               (r"$39$", "Evaluates the base-$7$ digits $43$ in base $9$: $4 \\times 9 + 3 = 39$."),
               (r"$34$", "Gives the base-$9$ numeral $34$ as if it were decimal.")],
  check=_c14, values=[31, 43, 39, 34], cognitive="Application")

# 015
def _c15():
    return _trailing_zeros_dec(math.factorial(250))
q("C23-B-015", T, "Trailing zeros of 250 factorial", "Easy",
  "Single-step computation",
  r"When $250!$ is written out in full in decimal, how many zeros does it end with?",
  "MCQ",
  r"Each trailing zero needs a factor $10 = 2 \times 5$, and factors of $5$ are scarcer. The exponent of $5$ in $250!$ is $\lfloor \frac{250}{5} \rfloor + \lfloor \frac{250}{25} \rfloor + \lfloor \frac{250}{125} \rfloor = 50 + 10 + 2 = 62$. So $250!$ ends in $62$ zeros.",
  "Stopping the sum of floor terms early.",
  "C23B-trailing-zeros-legendre", "Direct use of the floor-sum for the prime 5.",
  correct=r"$62$",
  distractors=[(r"$60$", "Stops after $50 + 10$, missing the extra factor from $125$ and $250$."),
               (r"$50$", "Counts only the multiples of $5$."),
               (r"$25$", "Counts only the multiples of $10$ up to $250$.")],
  check=_c15, values=[62, 60, 50, 25], cognitive="Recall")

# 016
def _c16():
    return _mult(math.factorial(200), 3)
q("C23-B-016", T, "Highest power of 3 dividing 200 factorial", "Easy",
  "Single-step computation",
  r"What is the largest integer $k$ such that $3^k$ divides $200!$?",
  "TITA",
  r"By the floor-sum rule, the exponent of $3$ in $200!$ is $\lfloor \frac{200}{3} \rfloor + \lfloor \frac{200}{9} \rfloor + \lfloor \frac{200}{27} \rfloor + \lfloor \frac{200}{81} \rfloor = 66 + 22 + 7 + 2 = 97$. ($243 > 200$, so the sum stops.)",
  "Missing a term of the floor sum.",
  "C23B-prime-exponent-in-factorial", "Four floor terms for one prime.",
  tita_answer=97, check=_c16,
  tita_traps=[(66, "Counts only the multiples of $3$."),
              (95, "Stops at $27$ and misses the $2$ from multiples of $81$: $66 + 22 + 7 = 95$.")],
  cognitive="Recall")

# 017
def _c17():
    return _mult(math.factorial(500), 49)
q("C23-B-017", T, "Highest power of 49 dividing 500 factorial", "Medium",
  "Conceptual/application",
  r"What is the largest integer $k$ such that $49^k$ divides $500!$?",
  "MCQ",
  r"Since $49 = 7^2$, first find the exponent of $7$: $\lfloor \frac{500}{7} \rfloor + \lfloor \frac{500}{49} \rfloor + \lfloor \frac{500}{343} \rfloor = 71 + 10 + 1 = 82$. Each $49$ uses two $7$s, so $k = \lfloor \frac{82}{2} \rfloor = 41$.",
  "Treating 49 like a prime and counting its multiples, or forgetting to halve.",
  "C23B-prime-power-divisor", "Needs the step from the prime 7 to its square.",
  correct=r"$41$",
  distractors=[(r"$82$", "Gives the exponent of $7$ without dividing by $2$."),
               (r"$10$", "Counts only the multiples of $49$, $\\lfloor \\frac{500}{49} \\rfloor = 10$, as if $49$ were prime."),
               (r"$35$", "Uses only the first term for $7$ and halves it: $\\lfloor \\frac{71}{2} \\rfloor = 35$.")],
  check=_c17, values=[41, 82, 10, 35], cognitive="Application")

# 018
def _c18():
    return _mult(math.factorial(80), 12)
q("C23-B-018", T, "Highest power of 12 dividing 80 factorial", "Medium",
  "Single-step computation",
  r"What is the largest integer $k$ such that $12^k$ divides $80!$?",
  "MCQ",
  r"$12 = 2^2 \times 3$. Exponent of $2$ in $80!$: $40 + 20 + 10 + 5 + 2 + 1 = 78$, enough for $\lfloor \frac{78}{2} \rfloor = 39$ factors of $4$. Exponent of $3$: $26 + 8 + 2 = 36$. The limit is the smaller, $\min(39, 36) = 36$.",
  "Assuming the larger prime always limits, or picking the wrong prime as the bottleneck.",
  "C23B-composite-divisor-in-factorial", "Two primes, one squared; the bottleneck must be compared, not assumed.",
  correct=r"$36$",
  distractors=[(r"$39$", "Uses only the prime $2$: $\\lfloor \\frac{78}{2} \\rfloor = 39$."),
               (r"$26$", "Uses only the first floor term for $3$, $\\lfloor \\frac{80}{3} \\rfloor = 26$."),
               (r"$6$", "Counts only the multiples of $12$ up to $80$.")],
  check=_c18, values=[36, 39, 26, 6], cognitive="Application")

# 019
def _c19():
    return _mult(math.factorial(50), 72)
q("C23-B-019", T, "Highest power of 72 dividing 50 factorial", "Medium",
  "Single-step computation",
  r"What is the largest integer $k$ such that $72^k$ divides $50!$?",
  "TITA",
  r"$72 = 2^3 \times 3^2$. Exponent of $2$ in $50!$: $25 + 12 + 6 + 3 + 1 = 47$, giving $\lfloor \frac{47}{3} \rfloor = 15$ factors of $8$. Exponent of $3$: $16 + 5 + 1 = 22$, giving $\lfloor \frac{22}{2} \rfloor = 11$ factors of $9$. So $k = \min(15, 11) = 11$.",
  "Not dividing each prime's exponent by its power in 72 before comparing.",
  "C23B-composite-divisor-in-factorial", "Two prime powers, each exponent divided before taking the minimum.",
  tita_answer=11, check=_c19,
  tita_traps=[(15, "Uses only the prime $2$: $\\lfloor \\frac{47}{3} \\rfloor = 15$."),
              (22, "Uses the exponent of $3$ without dividing by $2$.")],
  cognitive="Application")

# 020
def _c20():
    n = math.factorial(90)
    k = 0
    while n % 18 == 0:
        n //= 18
        k += 1
    return k
q("C23-B-020", T, "Trailing zeros of 90 factorial in base 18", "Medium",
  "Conceptual/application",
  r"When $90!$ is written in base $18$, how many zeros does it end with?",
  "MCQ",
  r"The number of trailing zeros in base $18$ is the largest $k$ with $18^k \mid 90!$. Here $18 = 2 \times 3^2$. Exponent of $3$ in $90!$: $30 + 10 + 3 + 1 = 44$, giving $22$ factors of $9$. Exponent of $2$ is $45 + 22 + 11 + 5 + 2 + 1 = 86$, far more than $22$. So $90!$ ends in $22$ zeros in base $18$.",
  "Forgetting that 18 contains 3 squared, or counting multiples of the base.",
  "C23B-composite-divisor-in-factorial", "Translate base-b zeros into a power of b, then handle a squared prime.",
  correct=r"$22$",
  distractors=[(r"$44$", "Uses the exponent of $3$ without dividing by $2$ for the factor $3^2$."),
               (r"$5$", "Counts only the multiples of $18$ up to $90$."),
               (r"$21$", "Stops the floor sum for $3$ before $81$: $30 + 10 + 3 = 43$, then halves to $21$.")],
  check=_c20, values=[22, 44, 5, 21], cognitive="Application")

# 021
def _c21():
    f = math.factorial(25)
    def z(b):
        n, k = f, 0
        while n % b == 0:
            n //= b
            k += 1
        return k
    ten = z(10)
    return sum(1 for b in range(2, 17) if z(b) > ten)
q("C23-B-021", T, "Compare trailing zeros of 25 factorial across bases 2 to 16", "Difficult",
  "Casework/optimisation",
  r"The number $25!$ is written in each of the bases $2, 3, 4, \ldots, 16$. In how many of these fifteen bases does it end in more zeros than it does in base $10$?",
  "MCQ",
  r"Exponents in $25!$: $2$ has $22$, $3$ has $10$, $5$ has $6$, $7$ has $3$, $11$ has $2$, $13$ has $1$. Base $10$ gives $\min(22, 6) = 6$ zeros. Others: base $2$: $22$; $3$: $10$; $4$: $11$; $5$: $6$; $6$: $10$; $7$: $3$; $8$: $\lfloor \frac{22}{3} \rfloor = 7$; $9$: $5$; $11$: $2$; $12$: $\min(11, 10) = 10$; $13$: $1$; $14$: $3$; $15$: $6$; $16$: $5$. More than $6$: bases $2, 3, 4, 6, 8, 12$, so $6$ bases.",
  "Not dividing the prime's exponent for prime-power bases such as 9 and 16.",
  "C23B-trailing-zeros-other-base", "Fifteen cases, each needing the right prime-power bottleneck.",
  correct=r"$6$",
  distractors=[(r"$8$", "Uses the bare prime exponent for prime-power bases, so $9$ gets $10$ and $16$ gets $22$; both are then counted."),
               (r"$9$", "Counts bases with at least as many zeros as base $10$, adding $5$, $10$ and $15$."),
               (r"$7$", "Counts the multiples of $b$ up to $25$, $\\lfloor \\frac{25}{b} \\rfloor$, and compares with $\\lfloor \\frac{25}{10} \\rfloor = 2$, which selects $b = 2$ to $8$.")],
  check=_c21, values=[6, 8, 9, 7], cognitive="Analysis", exams=HARD)

# 022
def _c22():
    n = 1
    while _trailing_zeros_dec(math.factorial(n)) < 100:
        n += 1
    return n
q("C23-B-022", T, "Smallest n whose factorial has at least 100 trailing zeros", "Medium",
  "Inverse/parameter",
  r"What is the smallest positive integer $n$ for which $n!$ ends in at least $100$ zeros?",
  "MCQ",
  r"The count of zeros is about $\frac{n}{4}$, so try near $400$: $400!$ has $80 + 16 + 3 = 99$ zeros. The count only rises at multiples of $5$, so $401!$ to $404!$ still have $99$, and $405!$ has $81 + 16 + 3 = 100$. The answer is $405$.",
  "Assuming the count rises by one at every n.",
  "C23B-trailing-zeros-inverse", "Estimate, test and adjust to the next multiple of 5.",
  correct=r"$405$",
  distractors=[(r"$400$", "Uses the estimate $4 \\times 100$ without checking that $400!$ has only $99$ zeros."),
               (r"$401$", "Finds $99$ zeros at $400$ and adds one to $n$, not noticing the count rises only at multiples of $5$."),
               (r"$500$", "Takes $5 \\times 100$, as if each multiple of $5$ gave exactly one zero.")],
  check=_c22, values=[405, 400, 401, 500], cognitive="Application")

# 023
def _c23():
    return max(n for n in range(1, 200) if _trailing_zeros_dec(math.factorial(n)) == 7)
q("C23-B-023", T, "Largest n whose factorial has exactly 7 trailing zeros", "Easy",
  "Inverse/parameter",
  r"What is the largest positive integer $n$ for which $n!$ ends in exactly $7$ zeros?",
  "MCQ",
  r"$25!$ has $5 + 1 = 6$ zeros and $30!$ has $6 + 1 = 7$. The count stays $7$ until the next multiple of $5$: $35!$ has $7 + 1 = 8$. So $30!$ to $34!$ have exactly $7$ zeros, and the largest such $n$ is $34$.",
  "Forgetting the extra factor of 5 contributed by 25.",
  "C23B-trailing-zeros-inverse", "One floor-sum check around a multiple of 25.",
  correct=r"$34$",
  distractors=[(r"$30$", "Gives the smallest $n$ with exactly $7$ zeros instead of the largest."),
               (r"$35$", "Takes $n = 5 \\times 7$."),
               (r"$39$", "Uses only $\\lfloor \\frac{n}{5} \\rfloor = 7$, ignoring the extra $5$ in $25$, so takes $35$ to $39$.")],
  check=_c23, values=[34, 30, 35, 39], cognitive="Understanding")

# 024
def _c24():
    seen = set()
    for n in range(1, 400):
        seen.add(_trailing_zeros_dec(math.factorial(n)))
    return sum(1 for k in range(1, 51) if k not in seen)
q("C23-B-024", T, "Count zero-counts that no factorial attains", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ with $1 \le k \le 50$ is there no positive integer $n$ such that $n!$ ends in exactly $k$ zeros?",
  "TITA",
  r"The zero count rises only at multiples of $5$: by $1$ normally, by $2$ at a multiple of $25$ (not of $125$), and by $3$ at $125$. Each jump of $2$ skips one value and the jump of $3$ skips two. Counts: $24! \to 25!$ goes $4 \to 6$ (skips $5$); then $50$: $10 \to 12$ (skips $11$); $75$: skips $17$; $100$: skips $23$; $125$: $28 \to 31$ (skips $29, 30$); $150$: skips $36$; $175$: skips $42$; $200$: skips $48$; $225!$ has $55$ zeros, beyond $50$. Skipped values: $5, 11, 17, 23, 29, 30, 36, 42, 48$, which is $9$.",
  "Treating the jump at 125 like the other multiples of 25.",
  "C23B-trailing-zeros-gaps", "Track jumps at multiples of 25 and 125 through eight stages.",
  tita_answer=9, check=_c24,
  tita_traps=[(8, "Treats the jump at $125$ as a jump of $2$, so it skips only one value."),
              (2, "Counts only the two values $29$ and $30$ skipped at $125$.")],
  cognitive="Analysis", exams=HARD)

# 025
def _c25():
    p = 1
    for k in range(1, 31):
        p *= math.factorial(k)
    return _trailing_zeros_dec(p)
q("C23-B-025", T, "Trailing zeros of the product of factorials 1! to 30!", "Difficult",
  "Conceptual/application",
  r"How many zeros does the product $1! \times 2! \times 3! \times \cdots \times 30!$ end with?",
  "MCQ",
  r"Factors of $2$ are plentiful, so count factors of $5$, which is the sum of the zero counts of $k!$. For $k = 1$ to $4$: $0$. $k = 5$ to $9$: $1$ each, total $5$. $k = 10$ to $14$: $2$ each, total $10$. $k = 15$ to $19$: $15$. $k = 20$ to $24$: $20$. $k = 25$ to $29$: $6$ each, total $30$. $k = 30$: $7$. Sum $5 + 10 + 15 + 20 + 30 + 7 = 87$.",
  "Forgetting that 25 contributes two factors of 5 to every later factorial.",
  "C23B-zeros-special-product", "Blockwise summation of zero counts with a jump at 25.",
  correct=r"$87$",
  distractors=[(r"$81$", "Counts only one $5$ from $25$, so $25!$ to $29!$ get $5$ each and $30!$ gets $6$: $87 - 5 - 1 = 81$."),
               (r"$114$", "Treats the product as $(1 + 2 + \\cdots + 30)! = 465!$, giving $93 + 18 + 3 = 114$."),
               (r"$7$", "Counts the zeros of $30!$ only.")],
  check=_c25, values=[87, 81, 114, 7], cognitive="Analysis", exams=HARD)

# 026
def _c26():
    p = 1
    for k in range(5, 501, 5):
        p *= k
    return _trailing_zeros_dec(p)
q("C23-B-026", T, "Trailing zeros of the product of multiples of 5 where 2 is the bottleneck", "Medium",
  "Conceptual/application",
  r"How many zeros are there at the end of the product $5 \times 10 \times 15 \times \cdots \times 500$ of all multiples of $5$ from $5$ to $500$?",
  "MCQ",
  r"The product is $5^{100} \times (1 \times 2 \times \cdots \times 100) = 5^{100} \times 100!$. Factors of $5$: $100 + (20 + 4) = 124$. Factors of $2$ come only from $100!$: $50 + 25 + 12 + 6 + 3 + 1 = 97$. Here $2$ is the scarce prime, so there are $97$ zeros.",
  "Assuming 5 is always the limiting prime for trailing zeros.",
  "C23B-zeros-special-product", "The usual bottleneck reverses; needs both prime counts.",
  correct=r"$97$",
  distractors=[(r"$124$", "Counts the factors of $5$ only, assuming $5$ always limits."),
               (r"$24$", "Counts only the zeros of $100!$, ignoring the extra $5^{100}$."),
               (r"$100$", "Assumes each of the $100$ factors contributes exactly one zero.")],
  check=_c26, values=[97, 124, 24, 100], cognitive="Analysis")

# 027
def _c27():
    p = 1
    for k in range(1, 51):
        p *= k**k
    return _trailing_zeros_dec(p)
q("C23-B-027", T, "Trailing zeros of the superfactorial-type product of k to the power k", "Difficult",
  "Conceptual/application",
  r"How many zeros does the product $1^1 \times 2^2 \times 3^3 \times \cdots \times 50^{50}$ end with?",
  "TITA",
  r"Count factors of $5$: each multiple of $5$, say $k$, gives $k$ copies of its $5$s. Multiples of $5$: $5 + 10 + \cdots + 50 = 275$. The numbers $25$ and $50$ contain a second $5$, adding $25 + 50 = 75$. Total $350$. Factors of $2$ are far more: the even $k$ alone give at least $2 + 4 + \cdots + 50 = 650$. So the product ends in $350$ zeros.",
  "Counting each multiple of 5 once instead of k times, or missing the second 5 in 25 and 50.",
  "C23B-zeros-special-product", "Weighted count of 5s with exponents, plus a check that 2 is not scarcer.",
  tita_answer=350, check=_c27,
  tita_traps=[(275, "Forgets the extra $5$ inside $25$ and $50$."),
              (12, "Counts the zeros of $50!$, ignoring the exponents.")],
  cognitive="Analysis", exams=HARD)

# 028
def _c28():
    return _mult(math.factorial(96), 2)
q("C23-B-028", T, "Highest power of 2 dividing 96 factorial", "Easy",
  "Single-step computation",
  r"What is the largest integer $k$ such that $2^k$ divides $96!$?",
  "MCQ",
  r"$\lfloor \frac{96}{2} \rfloor + \lfloor \frac{96}{4} \rfloor + \lfloor \frac{96}{8} \rfloor + \lfloor \frac{96}{16} \rfloor + \lfloor \frac{96}{32} \rfloor + \lfloor \frac{96}{64} \rfloor = 48 + 24 + 12 + 6 + 3 + 1 = 94$. Shortcut: the exponent of $2$ in $n!$ is $n$ minus the number of $1$s in binary; $96 = 1100000_2$, so $96 - 2 = 94$.",
  "Stopping the floor sum early, or approximating it by n.",
  "C23B-prime-exponent-in-factorial", "Six floor terms or the binary digit-sum shortcut.",
  correct=r"$94$",
  distractors=[(r"$48$", "Counts only the even numbers."),
               (r"$90$", "Stops at $16$: $48 + 24 + 12 + 6 = 90$."),
               (r"$96$", "Uses the infinite sum $\\frac{96}{2} + \\frac{96}{4} + \\cdots = 96$ without floors.")],
  check=_c28, values=[94, 48, 90, 96], cognitive="Understanding")

# 029
def _c29():
    return _mult(math.comb(90, 45), 3)
q("C23-B-029", T, "Highest power of 3 dividing a central binomial coefficient", "Medium",
  "Conceptual/application",
  r"A coach can choose a squad of $45$ players from $90$ players in $N$ ways. What is the largest integer $k$ such that $3^k$ divides $N$?",
  "MCQ",
  r"$N = \frac{90!}{45! \, 45!}$. Exponent of $3$ in $90!$: $30 + 10 + 3 + 1 = 44$. In $45!$: $15 + 5 + 1 = 21$. So $k = 44 - 2 \times 21 = 2$.",
  "Subtracting the exponent for only one of the two 45! factors.",
  "C23B-binomial-prime-exponent", "Floor sums for three factorials combined by subtraction.",
  correct=r"$2$",
  distractors=[(r"$23$", "Subtracts the exponent for only one $45!$: $44 - 21 = 23$."),
               (r"$44$", "Gives the exponent of $3$ in $90!$, ignoring the denominator."),
               (r"$0$", "Uses only the first floor terms: $30 - 2 \\times 15 = 0$.")],
  check=_c29, values=[2, 23, 44, 0], cognitive="Application", exams=HARD)

# 030
def _c30():
    n = 1
    while math.factorial(n) % (12**20) != 0:
        n += 1
    return n
q("C23-B-030", T, "Smallest n for which 12 to the 20 divides n factorial", "Medium",
  "Inverse/parameter",
  r"What is the smallest positive integer $n$ such that $12^{20}$ divides $n!$?",
  "MCQ",
  r"$12^{20} = 2^{40} \times 3^{20}$. For $3$: $44!$ has $14 + 4 + 1 = 19$ threes, $45!$ has $15 + 5 + 1 = 21$, so $n \ge 45$. For $2$: $45!$ has $22 + 11 + 5 + 2 + 1 = 41 \ge 40$. Both conditions first hold at $n = 45$.",
  "Checking only one of the two prime conditions, or counting only multiples.",
  "C23B-composite-power-inverse", "Two short inverse floor-sum checks near $n = 45$; the binding prime must be identified.",
  correct=r"$45$",
  distractors=[(r"$44$", "Checks only $2^{40}$: $44!$ has $22 + 11 + 5 + 2 + 1 = 41$ twos, but only $19$ threes."),
               (r"$60$", "Requires twenty multiples of $3$, $\\lfloor \\frac{n}{3} \\rfloor \\ge 20$, ignoring extra $3$s from $9$ and $27$."),
               (r"$80$", "Requires forty even numbers, $\\lfloor \\frac{n}{2} \\rfloor \\ge 40$, ignoring extra $2$s from higher powers.")],
  check=_c30, values=[45, 44, 60, 80], cognitive="Analysis", exams=HARD)
