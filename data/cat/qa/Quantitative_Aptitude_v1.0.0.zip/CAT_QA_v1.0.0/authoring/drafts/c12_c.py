import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TOP = "Logarithms"
CX = ("CAT", "XAT")
X = Symbol('x', real=True)


def _nval(e):
    """Exact-looking value of a numeric sympy expression (via high-precision evaluation)."""
    return nsimplify(N(e, 60), rational=True, tolerance=1e-40)


def _logs_of(n, L):
    """Express log of a positive rational n as a combination of the logs of its primes given in L."""
    f = factorint(Rational(n))
    return sum(e * L[p] for p, e in f.items())


# ================================================================ EASY (10)

# ---------------------------------------------------------------- 001
def _c001():
    num = log(27) + log(8) - log(125)
    den = log(6) - log(5)
    return _nval(num / den)
q("C12-C-001", TOP, "Combining sums and differences of logarithms into a single ratio", "Easy",
  "Single-step computation",
  r"What is the value of $\dfrac{\log_{10} 27 + \log_{10} 8 - \log_{10} 125}{\log_{10} 6 - \log_{10} 5}$?",
  "TITA",
  r"The numerator is $\log_{10} \frac{27 \times 8}{125} = \log_{10} \frac{216}{125} = \log_{10} \left(\frac{6}{5}\right)^3 = 3\log_{10} \frac{6}{5}$. The denominator is $\log_{10} \frac{6}{5}$. The ratio is $3$.",
  "Reducing $\\frac{216}{125}$ to $\\frac{6}{5}$ by taking cube roots inside the logarithm instead of bringing the exponent $3$ out in front.",
  "C12C-laws-combine", "One application of the product, quotient and power laws; the only step is spotting $216 = 6^3$.",
  tita_answer=3, check=_c001, values=[3],
  tita_traps=[(1, r"Combines the numerator into $\log_{10} \frac{216}{125}$, then replaces $\frac{216}{125}$ by its cube root $\frac{6}{5}$ and drops the exponent $3$, so the ratio becomes $\frac{\log_{10} \frac{6}{5}}{\log_{10} \frac{6}{5}} = 1$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    return _nval(log(243) / log(sqrt(3)))
q("C12-C-002", TOP, "Logarithm to a surd base of a power of that base", "Easy",
  "Single-step computation",
  r"The value of $\log_{\sqrt{3}} 243$ is",
  "MCQ",
  r"Since $243 = 3^5$ and $3 = (\sqrt{3})^2$, we have $243 = (\sqrt{3})^{10}$. Hence $\log_{\sqrt{3}} 243 = 10$.",
  "Multiplying by the exponent of the base instead of dividing by it.",
  "C12C-base-power-rule", "Single rewrite of the base and the argument as powers of $\\sqrt{3}$.",
  correct=r"$10$",
  distractors=[(r"$\frac{5}{2}$", r"Uses $\log_{a^k} b = k \log_a b$ with $k = \frac{1}{2}$: $\frac{1}{2} \times 5$."),
               (r"$5$", r"Ignores the square root in the base and computes $\log_3 243 = 5$."),
               (r"$\frac{1}{10}$", r"Inverts the logarithm, computing $\log_{243} \sqrt{3}$.")],
  check=_c002, values=[10, F(5, 2), 5, F(1, 10)], cognitive="Recall")

# ---------------------------------------------------------------- 003
def _c003():
    x = symbols('x', positive=True)
    sol = solve(Eq(log(x, 2) + log(x, 4) + log(x, 16), 21), x)
    return [s for s in sol if s > 0][0]
q("C12-C-003", TOP, "Equation with logarithms of the same number to bases 2, 4 and 16", "Easy",
  "Inverse/parameter",
  r"If $x > 0$ and $\log_2 x + \log_4 x + \log_{16} x = 21$, what is the value of $x$?",
  "TITA",
  r"Write every term in base $2$: $\log_4 x = \frac{1}{2}\log_2 x$ and $\log_{16} x = \frac{1}{4}\log_2 x$. So $\frac{7}{4}\log_2 x = 21$, giving $\log_2 x = 12$ and $x = 2^{12} = 4096$.",
  "Converting $\\log_4 x$ to $2\\log_2 x$ instead of $\\frac{1}{2}\\log_2 x$.",
  "C12C-change-to-common-base", "One change of base applied to two terms, then an antilog.",
  tita_answer=4096, check=_c003, values=[4096],
  tita_traps=[(12, r"Stops at $\log_2 x = 12$ and enters the logarithm instead of $x$."),
              (8, r"Uses $\log_4 x = 2\log_2 x$ and $\log_{16} x = 4\log_2 x$: $7\log_2 x = 21$, so $x = 2^3$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 004
_a, _b = symbols('a b', positive=True)


def _c004():
    L = {2: _a, 3: _b, 5: 1 - _a}   # log 5 = log 10 - log 2
    return expand(_logs_of(45, L))
q("C12-C-004", TOP, "Expressing a common logarithm in terms of log 2 and log 3", "Easy",
  "Conceptual/application",
  r"If $\log_{10} 2 = a$ and $\log_{10} 3 = b$, then $\log_{10} 45$ equals",
  "MCQ",
  r"Write $45 = 9 \times 5 = 3^2 \times \frac{10}{2}$. Then $\log_{10} 45 = 2\log_{10} 3 + \log_{10} 10 - \log_{10} 2 = 2b + 1 - a$.",
  "Not seeing that $\\log_{10} 5$ must be written as $\\log_{10} 10 - \\log_{10} 2$.",
  "C12C-express-given-logs", "One factorisation plus the observation $5 = \\frac{10}{2}$.",
  correct=r"$1 + 2b - a$",
  distractors=[(r"$1 + 2b + a$", r"Takes $\log_{10} 5 = \log_{10} 10 + \log_{10} 2$, adding $\log_{10} 2$ instead of subtracting it."),
               (r"$1 + b^2 - a$", r"Writes $\log_{10} 9 = (\log_{10} 3)^2$ instead of $2\log_{10} 3$."),
               (r"$a + 3b$", r"Takes $\log_{10} 5 = \log_{10} 2 + \log_{10} 3$, treating the log of a sum as the sum of logs.")],
  check=_c004, values=[1 + 2 * _b - _a, 1 + 2 * _b + _a, 1 + _b**2 - _a, _a + 3 * _b], cognitive="Understanding")

# ---------------------------------------------------------------- 005
def _c005():
    return len(str(6**20))
q("C12-C-005", TOP, "Number of digits of a power using given logarithm values", "Easy",
  "Single-step computation",
  r"A combination lock has $20$ dials, and each dial can be set to any one of $6$ symbols, so there are $6^{20}$ possible settings. Given $\log_{10} 2 = 0.3010$ and $\log_{10} 3 = 0.4771$, how many digits does the number $6^{20}$ have?",
  "TITA",
  r"$\log_{10} 6^{20} = 20(\log_{10} 2 + \log_{10} 3) = 20 \times 0.7781 = 15.562$. A number whose common logarithm has integer part $15$ lies between $10^{15}$ and $10^{16}$, so it has $15 + 1 = 16$ digits.",
  "Taking the integer part of the logarithm as the number of digits.",
  "C12C-digits-count", "Direct use of the rule: digits $= \\lfloor \\log_{10} N \\rfloor + 1$.",
  tita_answer=16, check=_c005, values=[16],
  tita_traps=[(15, r"Uses the integer part $15$ of $\log_{10} 6^{20}$ without adding $1$."),
              (3, r"Takes $\log_{10} 6 = \log_{10} 2 \times \log_{10} 3 = 0.3010 \times 0.4771 \approx 0.1436$, treating the log of a product as the product of the logs, so $20 \times 0.1436 \approx 2.87$ and $2 + 1 = 3$ digits.")],
  cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    x = symbols('x', real=True)
    cands = solve(Eq(x * (x - 3), 10), x)
    good = [c for c in cands if c > 0 and c - 3 > 0 and abs(N(log(c, 10) + log(c - 3, 10) - 1, 40)) < 1e-30]
    return FiniteSet(*good)
q("C12-C-006", TOP, "Logarithmic equation with an extraneous root removed by the domain", "Easy",
  "Inverse/parameter",
  r"The set of all real numbers $x$ satisfying $\log_{10} x + \log_{10}(x - 3) = 1$ is",
  "MCQ",
  r"For both logarithms to be defined we need $x > 3$. Combining, $\log_{10} x(x - 3) = 1$, so $x^2 - 3x - 10 = 0$, that is $(x - 5)(x + 2) = 0$. Only $x = 5$ satisfies $x > 3$, so the solution set is $\{5\}$.",
  "Keeping a root of the quadratic without checking that every logarithm is defined there.",
  "C12C-equation-domain", "One law of logarithms and a factorable quadratic; the trap is the negative root.",
  correct=r"$\{5\}$",
  distractors=[(r"$\{-2, 5\}$", r"Solves $x^2 - 3x - 10 = 0$ and keeps both roots without checking the domain $x > 3$."),
               (r"$\{\frac{13}{2}\}$", r"Writes $\log_{10} x + \log_{10}(x - 3) = \log_{10}(2x - 3)$, so $2x - 3 = 10$."),
               (r"$\{2\}$", r"Factorises $x^2 - 3x - 10$ as $(x - 2)(x + 5)$ and rejects the negative root.")],
  check=_c006, values=[FiniteSet(5), FiniteSet(-2, 5), FiniteSet(F(13, 2)), FiniteSet(2)], cognitive="Application")

# ---------------------------------------------------------------- 007
def _c007():
    vals = [log(5, 2), log(24, 5), log(8, 3), log(15, 4)]
    return max(vals, key=lambda v: N(v, 40))
q("C12-C-007", TOP, "Comparing logarithms by placing each against the integer 2", "Easy",
  "Conceptual/application",
  r"Which of the following is the greatest?",
  "MCQ",
  r"Compare each value with $2$: since $5 > 2^2$, $\log_2 5 > 2$. On the other hand $8 < 3^2$, $15 < 4^2$ and $24 < 5^2$, so $\log_3 8$, $\log_4 15$ and $\log_5 24$ are all less than $2$. Hence $\log_2 5$ is the greatest.",
  "Judging a logarithm by the size of its argument alone, or converting a base $4$ logarithm to base $2$ with the factor $2$ instead of $\\frac{1}{2}$.",
  "C12C-compare-logs", "One benchmark comparison with $2$; only one option lies above it.",
  correct=r"$\log_2 5$",
  distractors=[(r"$\log_5 24$", r"Picks the option with the largest argument, ignoring that the base also grows."),
               (r"$\log_3 8$", r"Swaps base and argument, comparing $\log_5 2$, $\log_8 3$, $\log_{15} 4$ and $\log_{24} 5$; of these $\log_8 3 \approx 0.53$ is the largest."),
               (r"$\log_4 15$", r"Converts $\log_4 15$ to $2\log_2 15 \approx 7.8$ instead of $\frac{1}{2}\log_2 15$, so it appears far larger than the others.")],
  check=_c007, values=[log(5, 2), log(24, 5), log(8, 3), log(15, 4)], cognitive="Analysis")

# ---------------------------------------------------------------- 008
def _c008():
    n, count = 0, 500
    while count <= 10**6:
        count *= 3
        n += 1
    return n
q("C12-C-008", TOP, "Least number of tripling periods for a population to cross a threshold", "Easy",
  "Multi-step word problem",
  r"A laboratory culture starts with $500$ bacteria, and at the end of every hour the number of bacteria becomes exactly three times what it was at the start of that hour. Given $\log_{10} 2 = 0.3010$ and $\log_{10} 3 = 0.4771$, after how many hours does the number of bacteria first exceed $10{,}00{,}000$?",
  "TITA",
  r"We need $500 \times 3^n > 10^6$, that is $3^n > 2000$. Taking logs, $n > \frac{\log_{10} 2000}{\log_{10} 3} = \frac{3.3010}{0.4771} \approx 6.92$. The least whole number of hours is $7$ (check: $3^6 = 729$, $3^7 = 2187$).",
  "Rounding the logarithm ratio down, or ignoring the starting count.",
  "C12C-growth-threshold", "One inequality solved with logarithms; the trap is rounding $6.92$ down.",
  tita_answer=7, check=_c008, values=[7],
  tita_traps=[(6, r"Truncates $6.92$ to $6$; after $6$ hours there are only $3{,}64{,}500$ bacteria."),
              (13, r"Ignores the starting $500$ and solves $3^n > 10^6$: $n > \frac{6}{0.4771} \approx 12.6$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 009
def _c009():
    x = symbols('x', positive=True)
    sol = solve(Eq(x**Rational(-3, 2), Rational(1, 64)), x)
    return [s for s in sol if s > 0 and s != 1][0]
q("C12-C-009", TOP, "Finding the base from a negative fractional logarithm", "Easy",
  "Inverse/parameter",
  r"If $\log_x \frac{1}{64} = -\frac{3}{2}$, where $x > 0$ and $x \neq 1$, then $x$ equals",
  "MCQ",
  r"By definition $x^{-3/2} = \frac{1}{64}$, so $x^{3/2} = 64$. Then $x = 64^{2/3} = (64^{1/3})^2 = 4^2 = 16$.",
  "Raising to the wrong power when inverting a fractional exponent.",
  "C12C-unknown-base", "Converting to exponential form and inverting a fractional power.",
  correct=r"$16$",
  distractors=[(r"$512$", r"Inverts the exponent the wrong way: $x = 64^{3/2}$."),
               (r"$4$", r"Takes only the cube root of $64$ and forgets the square."),
               (r"$\frac{1}{16}$", r"Computes $x = \left(\frac{1}{64}\right)^{2/3}$, dropping the negative sign of the exponent.")],
  check=_c009, values=[16, 512, 4, F(1, 16)], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    # multiply the factors log_k(k+1) one at a time until the product reaches 10
    p, n = 1.0, 1
    while abs(p - 10) > 1e-9:
        n += 1
        p *= math.log(n + 1) / math.log(n)
        if p > 10 + 1e-6:
            return None
    return n                          # last base
q("C12-C-010", TOP, "Finding the last base of a telescoping product of logarithms with a given value", "Easy",
  "Inverse/parameter",
  r"The product $\log_2 3 \times \log_3 4 \times \log_4 5 \times \cdots \times \log_n (n + 1)$, in which each factor is $\log_k (k + 1)$ for $k = 2, 3, \ldots, n$, equals $10$. What is the value of $n$?",
  "MCQ",
  r"Write each factor as $\frac{\log_{10} (k+1)}{\log_{10} k}$. The product telescopes to $\frac{\log_{10} (n+1)}{\log_{10} 2} = \log_2 (n + 1)$. So $\log_2 (n + 1) = 10$, giving $n + 1 = 2^{10} = 1024$ and $n = 1023$.",
  "Mis-telescoping the product to $\\log_2 n$, or converting $\\log_2 (n + 1) = 10$ to exponential form incorrectly.",
  "C12C-telescoping-product", "One telescoping step followed by one conversion to exponential form.",
  correct=r"$1023$",
  distractors=[(r"$1024$", r"Takes the product to telescope to $\log_2 n$, so $n = 2^{10} = 1024$."),
               (r"$19$", r"Converts $\log_2 (n + 1) = 10$ to $n + 1 = 2 \times 10 = 20$, multiplying the base by the value."),
               (r"$99$", r"Swaps the roles of base and value, writing $\log_2 (n + 1) = 10$ as $n + 1 = 10^2 = 100$.")],
  check=_c010, values=[1023, 1024, 19, 99], cognitive="Application")


# ================================================================ MEDIUM (16)

# ---------------------------------------------------------------- 011
def _c011():
    a, b = _a, _b
    L2 = {2: 1, 3: a, 5: a * b}       # logs to base 2
    return simplify(_logs_of(45, L2) / _logs_of(10, L2))
q("C12-C-011", TOP, "Common logarithm in terms of two chained logarithms with different bases", "Medium",
  "Conceptual/application",
  r"If $\log_2 3 = a$ and $\log_3 5 = b$, then $\log_{10} 45$ equals",
  "MCQ",
  r"Work in base $2$: $\log_2 5 = \log_2 3 \times \log_3 5 = ab$. Then $\log_2 45 = 2\log_2 3 + \log_2 5 = 2a + ab$ and $\log_2 10 = 1 + ab$. By change of base, $\log_{10} 45 = \frac{\log_2 45}{\log_2 10} = \frac{2a + ab}{1 + ab}$.",
  "Treating $\\log_3 5$ as if it were $\\log_2 5$, or not changing the final base to $10$.",
  "C12C-express-given-logs", "Needs a chain rule for $\\log_2 5$ and a final change of base; two conversions.",
  correct=r"$\frac{2a + ab}{1 + ab}$",
  distractors=[(r"$\frac{2a + b}{1 + b}$", r"Uses $b$ directly as $\log_2 5$ instead of $ab$."),
               (r"$\frac{2a + ab}{ab}$", r"Divides by $\log_2 5$ instead of by $\log_2 10$ when changing the base."),
               (r"$2a + ab$", r"Finds $\log_2 45$ and does not change the base to $10$.")],
  check=_c011, values=[(2 * _a + _a * _b) / (1 + _a * _b), (2 * _a + _b) / (1 + _b), (2 * _a + _a * _b) / (_a * _b), 2 * _a + _a * _b],
  cognitive="Application")

# ---------------------------------------------------------------- 012
def _c012():
    return len(str(2**100 * 5**70))
q("C12-C-012", TOP, "Digits of a product of powers of 2 and 5 by pairing into powers of 10", "Medium",
  "Conceptual/application",
  r"Given $\log_{10} 2 = 0.3010$, how many digits does the number $2^{100} \times 5^{70}$ have?",
  "TITA",
  r"Pair the factors: $2^{100} \times 5^{70} = 2^{30} \times 10^{70}$. Since $\log_{10} 2^{30} = 9.03$, $2^{30}$ has $10$ digits, and multiplying by $10^{70}$ appends $70$ zeros. The number has $10 + 70 = 80$ digits.",
  "Forgetting the $+1$ in the digit rule, or counting only the zeros.",
  "C12C-digits-count", "Requires pairing $2$s with $5$s before using the digit rule.",
  tita_answer=80, check=_c012, values=[80],
  tita_traps=[(79, r"Finds $\log_{10} N = 79.03$ and uses its integer part without adding $1$."),
              (70, r"Counts only the $70$ trailing zeros from $10^{70}$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    return sum(1 for n in range(1, 300) if len(str(2**n)) == 25)
q("C12-C-013", TOP, "Counting exponents for which a power of 2 has a given number of digits", "Medium",
  "Inverse/parameter",
  r"Given $\log_{10} 2 = 0.3010$, for how many positive integers $n$ does $2^n$ have exactly $25$ digits?",
  "TITA",
  r"$2^n$ has $25$ digits exactly when $24 \le 0.3010\,n < 25$, that is $79.7 \le n < 83.06$. So $n = 80, 81, 82, 83$, giving $4$ values. (Check: $83 \times 0.3010 = 24.98$ and $84 \times 0.3010 = 25.28$.)",
  "Assuming every digit count is shared by the same number of consecutive powers of $2$.",
  "C12C-digits-inverse", "Turning a digit count into a range of exponents and counting integers in it, with a boundary check.",
  tita_answer=4, check=_c013, values=[4],
  tita_traps=[(3, r"Assumes each digit count covers about $3$ powers of $2$ since $2^3 \approx 10$, without checking the range."),
              (83, r"Finds the range but enters the largest exponent instead of the count.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 014
def _c014():
    v = F(2, 3)**60
    k = 0
    while v < F(1, 10**(k + 1)):
        k += 1
    return k
q("C12-C-014", TOP, "Zeros after the decimal point in a small power, from a bouncing ball", "Medium",
  "Multi-step word problem",
  r"A ball is dropped from a height of $1$ m, and after every bounce it rises to exactly $\frac{2}{3}$ of the height from which it last fell. Given $\log_{10} 2 = 0.3010$ and $\log_{10} 3 = 0.4771$, when the height (in metres) reached after the $60$th bounce is written as a decimal, how many zeros are there between the decimal point and the first non-zero digit?",
  "TITA",
  r"The height is $\left(\frac{2}{3}\right)^{60}$ m. Its logarithm is $60(0.3010 - 0.4771) = -10.566 = \overline{11}.434$. So the number is about $2.7 \times 10^{-11}$, that is $0.000000000027\ldots$; there are $11 - 1 = 10$ zeros between the decimal point and the first non-zero digit.",
  "Taking the magnitude of the characteristic as the number of zeros.",
  "C12C-leading-zeros", "Negative logarithm must be converted to a negative characteristic and positive mantissa before counting zeros.",
  tita_answer=10, check=_c014, values=[10],
  tita_traps=[(11, r"Uses the characteristic $\overline{11}$ directly as the number of zeros."),
              (9, r"Takes the integer part $10$ of $10.566$ and subtracts $1$, as for $10^{-10} = 0.0000000001$, which has $9$ zeros.")],
  cognitive="Application")

# ---------------------------------------------------------------- 015
def _c015():
    vals = [log(9, 2), log(30, 3), log(65, 4), log(120, 5)]
    return max(vals, key=lambda v: N(v, 40))
q("C12-C-015", TOP, "Comparing four logarithms that all lie close to 3", "Medium",
  "Conceptual/application",
  r"Which of the following numbers has the largest value?",
  "MCQ",
  r"Compare each with $3$: $9 > 2^3$, $30 > 3^3$ and $65 > 4^3$ give values above $3$, while $120 < 5^3$ gives a value below $3$. Now $\log_2 9 = 3 + \log_2 \frac{9}{8}$, $\log_3 30 = 3 + \log_3 \frac{10}{9}$ and $\log_4 65 = 3 + \log_4 \frac{65}{64}$. The ratios satisfy $\frac{9}{8} > \frac{10}{9} > \frac{65}{64}$, and base $2$ is the smallest base, so $\log_2 \frac{9}{8} > \log_2 \frac{10}{9} > \log_3 \frac{10}{9} > \log_4 \frac{65}{64}$. So $\log_2 9$ is the greatest.",
  "Judging logarithms by the size of the argument, by the absolute excess over a power, or stopping at the first value found above $3$.",
  "C12C-compare-logs", "Needs a benchmark ($3$) and then a comparison of two small excesses with different bases.",
  correct=r"$\log_2 9$",
  distractors=[(r"$\log_5 120$", r"Ranks the four values by the size of the argument."),
               (r"$\log_4 65$", r"Shows that $\log_4 65 > 3$ and stops, without comparing it with $\log_2 9$."),
               (r"$\log_3 30$", r"Compares how far each argument exceeds the cube of its base: $30 - 27 = 3$ beats $9 - 8 = 1$ and $65 - 64 = 1$, so it picks $\log_3 30$.")],
  check=_c015, values=[log(9, 2), log(120, 5), log(65, 4), log(30, 3)], cognitive="Analysis")

# ---------------------------------------------------------------- 016
def _c016():
    x = symbols('x', real=True)
    cands = solve(Eq(x**2 - 4 * x, 2 * x - 8), x)
    good = [c for c in cands if c**2 - 4 * c > 0 and 2 * c - 8 > 0]
    return FiniteSet(*good)
q("C12-C-016", TOP, "Equal logarithms whose candidate roots both fall outside the domain", "Medium",
  "Conceptual/application",
  r"The set of all real numbers $x$ satisfying $\log_2 (x^2 - 4x) = \log_2 (2x - 8)$ is",
  "MCQ",
  r"Equating arguments, $x^2 - 4x = 2x - 8$, so $x^2 - 6x + 8 = 0$ and $x = 2$ or $x = 4$. But the right side needs $2x - 8 > 0$, that is $x > 4$. At $x = 2$ both arguments equal $-4$ and at $x = 4$ both equal $0$, so neither logarithm is defined. The solution set is empty.",
  "Equating the arguments and never checking that they are positive.",
  "C12C-equation-domain", "Both roots of the quadratic are extraneous for different reasons; the candidate must test each root.",
  correct=r"$\emptyset$",
  distractors=[(r"$\{2, 4\}$", r"Equates the arguments and keeps both roots without any domain check."),
               (r"$\{x : x > 4\}$", r"Works out the condition $x > 4$ under which both logarithms are defined and reports that domain as the solution set."),
               (r"$\{4\}$", r"Rejects $x = 2$ because $2x - 8 < 0$ but keeps $x = 4$ without noticing that both arguments are $0$.")],
  check=_c016, values=[S.EmptySet, FiniteSet(2, 4), Interval.open(4, oo), FiniteSet(4)], cognitive="Analysis")

# ---------------------------------------------------------------- 017
def _c017():
    t = symbols('t', real=True)
    ts = solve(Eq(1 / t + t, Rational(10, 3)), t)   # t = log_8 x
    xs = [8**s for s in ts]
    xs = [v for v in xs if v > 0 and v != 1 and abs(N(log(8) / log(v) + log(v) / log(8) - Rational(10, 3), 40)) < 1e-30]
    p = 1
    for v in xs:
        p *= v
    return p
q("C12-C-017", TOP, "Product of the roots of an equation in a logarithm and its reciprocal", "Medium",
  "Inverse/parameter",
  r"What is the product of all positive real numbers $x$, $x \neq 1$, that satisfy $\log_x 8 + \log_8 x = \frac{10}{3}$?",
  "MCQ",
  r"Let $t = \log_8 x$; then $\log_x 8 = \frac{1}{t}$ and $t + \frac{1}{t} = \frac{10}{3}$, so $3t^2 - 10t + 3 = 0$, giving $t = 3$ or $t = \frac{1}{3}$. Thus $x = 8^3 = 512$ or $x = 8^{1/3} = 2$, and the product is $1024$. (Faster: the product is $8^{t_1 + t_2} = 8^{10/3} = 2^{10}$.)",
  "Combining the two values of $t$ by multiplying them instead of adding them in the exponent.",
  "C12C-reciprocal-substitution", "Substitution to a quadratic, then converting both roots back.",
  correct=r"$1024$",
  distractors=[(r"$514$", r"Adds the two solutions $512 + 2$ instead of multiplying them."),
               (r"$512$", r"Keeps only the root from $t = 3$ and misses $t = \frac{1}{3}$."),
               (r"$8$", r"Uses $8^{t_1 t_2} = 8^1$, multiplying the exponents instead of adding them.")],
  check=_c017, values=[1024, 514, 512, 8], cognitive="Application")

# ---------------------------------------------------------------- 018
def _c018():
    x = symbols('x', positive=True)
    sol = solve(Eq(log(x, 2) * log(x, 8), 12), x)
    return max(sol)
q("C12-C-018", TOP, "Product of logarithms of the same number to bases 2 and 8", "Medium",
  "Inverse/parameter",
  r"Positive real numbers $x$ satisfy $\log_2 x \cdot \log_8 x = 12$. What is the largest such value of $x$?",
  "TITA",
  r"Since $\log_8 x = \frac{1}{3}\log_2 x$, the equation is $\frac{(\log_2 x)^2}{3} = 12$, so $(\log_2 x)^2 = 36$ and $\log_2 x = 6$ or $-6$. Hence $x = 64$ or $x = \frac{1}{64}$; the largest is $64$.",
  "Converting $\\log_8 x$ to $3\\log_2 x$ instead of $\\frac{1}{3}\\log_2 x$.",
  "C12C-change-to-common-base", "Change of base produces a square; both signs must be considered before picking the larger root.",
  tita_answer=64, check=_c018, values=[64],
  tita_traps=[(4, r"Uses $\log_8 x = 3\log_2 x$: $3(\log_2 x)^2 = 12$, so $\log_2 x = 2$."),
              (6, r"Enters $\log_2 x = 6$ instead of $x$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    p, r = symbols('p r', positive=True)
    q_ = 12
    sols = solve([Eq(2 * log(q_, 2), log(p, 2) + log(r, 2)), Eq(p + q_ + r, 63)], [p, r], dict=True)
    return max(max(s[p], s[r]) for s in sols)
q("C12-C-019", TOP, "Numbers whose logarithms are in AP: recovering the numbers from sum and middle term", "Medium",
  "Multi-step word problem",
  r"Three positive numbers $p$, $q$ and $r$ are such that $\log_2 p$, $\log_2 q$ and $\log_2 r$, in that order, are in arithmetic progression. If $q = 12$ and $p + q + r = 63$, what is the largest of the three numbers?",
  "MCQ",
  r"Logarithms in AP means $2\log_2 q = \log_2 p + \log_2 r$, that is $q^2 = pr$, so $p$, $q$, $r$ are in GP with $pr = 144$. Also $p + r = 51$. So $p$ and $r$ are the roots of $t^2 - 51t + 144 = 0$, that is $(t - 3)(t - 48) = 0$. The numbers are $3$, $12$, $48$, and the largest is $48$.",
  "Not converting the AP of logarithms into a GP of the numbers.",
  "C12C-log-ap-to-gp", "Translating an AP of logs into a GP, then solving a sum and product pair.",
  correct=r"$48$",
  distractors=[(r"$24$", r"Reads the base $2$ of the logarithms as the common ratio of the GP, taking the numbers as $6, 12, 24$."),
               (r"$51$", r"Finds $p + r = 51$ and reports it as the largest number."),
               (r"$3$", r"Solves $t^2 - 51t + 144 = 0$ correctly but reports the smaller root $3$ instead of the largest number.")],
  check=_c019, values=[48, 24, 51, 3], cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    x, y = symbols('x y', positive=True)
    sols = solve([Eq(log(x, 2) + log(y, 4), 4), Eq(log(x, 4) + log(y, 2), 5)], [x, y], dict=True)
    return simplify(sols[0][x] * sols[0][y])
q("C12-C-020", TOP, "Two log equations in bases 2 and 4: finding xy by adding", "Medium",
  "Conceptual/application",
  r"Positive real numbers $x$ and $y$ satisfy $\log_2 x + \log_4 y = 4$ and $\log_4 x + \log_2 y = 5$. What is the value of $xy$?",
  "MCQ",
  r"Let $u = \log_2 x$ and $v = \log_2 y$. The equations are $u + \frac{v}{2} = 4$ and $\frac{u}{2} + v = 5$. Adding, $\frac{3}{2}(u + v) = 9$, so $u + v = \log_2 (xy) = 6$ and $xy = 64$. (Indeed $u = 2$, $v = 4$, so $x = 4$, $y = 16$.)",
  "Converting base $4$ logarithms with a factor of $2$ instead of $\\frac{1}{2}$.",
  "C12C-log-system", "Change of base followed by the insight that adding the equations gives $\\log_2(xy)$ directly.",
  correct=r"$64$",
  distractors=[(r"$512$", r"Adds the equations and reads the left side as $\log_2 x + \log_2 y = 9$, ignoring the factor $\frac{1}{2}$ on the base $4$ terms."),
               (r"$8$", r"Uses $\log_4 t = 2\log_2 t$: $u + 2v = 4$ and $2u + v = 5$ give $u = 2$, $v = 1$."),
               (r"$16$", r"Solves correctly but reports $y$ instead of $xy$.")],
  check=_c020, values=[64, 512, 8, 16], cognitive="Analysis")

# ---------------------------------------------------------------- 021
def _c021():
    f = X**2 - 5 * X + 6
    dom = solve_univariate_inequality(f > 0, X, relational=False)
    # log base 1/2 is decreasing: log_{1/2} f >= -1 = log_{1/2} 2  <=>  f <= 2
    ok = solve_univariate_inequality(f <= 2, X, relational=False)
    res = Intersection(dom, ok)
    # numerical sanity check of the original inequality at sample points
    for xv in [Rational(1), Rational(3, 2), Rational(7, 2), Rational(4), Rational(5, 2), Rational(9, 2), Rational(1, 2)]:
        fv = f.subs(X, xv)
        inside = fv > 0 and N(log(fv) / log(Rational(1, 2)), 40) >= -1 - 1e-30
        assert bool(inside) == bool(res.contains(xv)), xv
    return res
q("C12-C-021", TOP, "Logarithmic inequality with base less than 1 and a quadratic argument", "Medium",
  "Conceptual/application",
  r"The set of all real numbers $x$ satisfying $\log_{1/2} (x^2 - 5x + 6) \ge -1$ is",
  "MCQ",
  r"The argument must be positive: $(x - 2)(x - 3) > 0$, so $x < 2$ or $x > 3$. Since the base $\frac{1}{2}$ is less than $1$, the logarithm is decreasing, and $-1 = \log_{1/2} 2$; so the inequality becomes $x^2 - 5x + 6 \le 2$, that is $(x - 1)(x - 4) \le 0$, or $1 \le x \le 4$. Combining, $x \in [1, 2) \cup (3, 4]$.",
  "Not reversing the inequality for a base below $1$, or ignoring the domain.",
  "C12C-log-inequality", "Two conditions (domain and reversed inequality) must be intersected.",
  correct=r"$[1, 2) \cup (3, 4]$",
  distractors=[(r"$[1, 4]$", r"Reverses the inequality correctly but ignores the domain condition $x^2 - 5x + 6 > 0$."),
               (r"$(-\infty, 1] \cup [4, \infty)$", r"Does not reverse the inequality for base $\frac{1}{2}$: solves $x^2 - 5x + 6 \ge 2$."),
               (r"$[1, 2] \cup [3, 4]$", r"Includes $x = 2$ and $x = 3$, where the argument is $0$ and the logarithm is undefined.")],
  check=_c021,
  values=[Union(Interval.Ropen(1, 2), Interval.Lopen(3, 4)), Interval(1, 4),
          Union(Interval(-oo, 1), Interval(4, oo)), Union(Interval(1, 2), Interval(3, 4))],
  cognitive="Analysis")

# ---------------------------------------------------------------- 022
def _c022():
    amt, n = F(50000), 0
    while amt <= 100000:
        amt *= F(108, 100)
        n += 1
    return n
q("C12-C-022", TOP, "Years for a compound-interest deposit to first exceed double, via logarithms", "Medium",
  "Multi-step word problem",
  r"Sneha deposits Rs. $50{,}000$ in a scheme that pays $8\%$ per annum compound interest, credited at the end of each year. Given $\log_{10} 2 = 0.3010$ and $\log_{10} 1.08 = 0.0334$, after how many complete years will the amount in the account first exceed Rs. $1{,}00{,}000$?",
  "TITA",
  r"We need $1.08^n > 2$, so $n > \frac{\log_{10} 2}{\log_{10} 1.08} = \frac{0.3010}{0.0334} \approx 9.01$. Since $n$ is a whole number of years, $n = 10$. (Indeed $1.08^9 \approx 1.999$, just short of $2$.)",
  "Using the rule of $72$ or rounding $9.01$ down to $9$.",
  "C12C-growth-threshold", "The log ratio lands just above an integer, so the rounding direction decides the answer.",
  tita_answer=10, check=_c022, values=[10],
  tita_traps=[(9, r"Rounds $9.01$ down, or uses the rule of $72$: $\frac{72}{8} = 9$; after $9$ years the amount is about Rs. $99{,}950$."),
              (13, r"Uses simple interest: $\frac{100}{8} = 12.5$, rounded up to $13$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 023
def _c023():
    a = symbols('a', positive=True)
    b = a**2           # log_a b = 2
    c = b**3           # log_b c = 3
    return simplify(log(b * c) / log(a * b))
q("C12-C-023", TOP, "Logarithm of a product to a product base, from two chained logarithms", "Medium",
  "Conceptual/application",
  r"Numbers $a, b, c > 1$ satisfy $\log_a b = 2$ and $\log_b c = 3$. What is the value of $\log_{ab} (bc)$?",
  "MCQ",
  r"Write everything as a power of $a$: $b = a^2$ and $c = b^3 = a^6$. Then $ab = a^3$ and $bc = a^8$, so $\log_{ab}(bc) = \log_{a^3} a^8 = \frac{8}{3}$.",
  "Adding the given logarithms instead of multiplying them when chaining.",
  "C12C-power-of-common-base", "Requires expressing three quantities as powers of one base and chaining two logarithms.",
  correct=r"$\frac{8}{3}$",
  distractors=[(r"$\frac{7}{3}$", r"Chains by adding: takes $c = a^{2 + 3} = a^5$, so $bc = a^7$."),
               (r"$5$", r"Adds the two given values, $2 + 3$."),
               (r"$6$", r"Finds $\log_a c = 2 \times 3 = 6$ and stops there.")],
  check=_c023, values=[F(8, 3), F(7, 3), 5, 6], cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    k = symbols('k', positive=True)
    sol = solve(Eq(log(8, k) + log(64, k**2), 3), k)
    return [s for s in sol if s > 0 and s != 1][0]
q("C12-C-024", TOP, "Finding a base when a logarithm to that base and to its square are combined", "Medium",
  "Inverse/parameter",
  r"If $\log_k 8 + \log_{k^2} 64 = 3$, where $k > 0$ and $k \neq 1$, then $k$ equals",
  "MCQ",
  r"Let $L = \log_2 k$. Then $\log_k 8 = \frac{3}{L}$ and $\log_{k^2} 64 = \frac{6}{2L} = \frac{3}{L}$. So $\frac{6}{L} = 3$, giving $L = 2$ and $k = 4$.",
  "Treating $\\log_{k^2}$ as $2\\log_k$, or reporting $\\log_2 k$ instead of $k$.",
  "C12C-unknown-base", "Change of base on a squared base, then an antilog.",
  correct=r"$4$",
  distractors=[(r"$32$", r"Uses $\log_{k^2} 64 = 2\log_k 64 = \frac{12}{L}$: $\frac{15}{L} = 3$ gives $L = 5$."),
               (r"$8$", r"Ignores the square in the base and uses $\log_k 64 = \frac{6}{L}$: $\frac{9}{L} = 3$ gives $L = 3$."),
               (r"$2$", r"Solves for $L = \log_2 k = 2$ and reports $L$ instead of $k$.")],
  check=_c024, values=[4, 32, 8, 2], cognitive="Application")

# ---------------------------------------------------------------- 025
_m = symbols('m', positive=True)


def _c025():
    y = symbols('y')
    # 12 = 2^2 * 3  =>  2 log_12 2 + log_12 3 = 1
    l3 = solve(Eq(2 * _m + y, 1), y)[0]
    L = {2: _m, 3: l3}
    return expand(_logs_of(18, L))
q("C12-C-025", TOP, "Logarithm to base 12 in terms of a single given logarithm to base 12", "Medium",
  "Conceptual/application",
  r"If $\log_{12} 2 = m$, then $\log_{12} 18$ equals",
  "MCQ",
  r"Since $12 = 2^2 \times 3$, $1 = 2\log_{12} 2 + \log_{12} 3$, so $\log_{12} 3 = 1 - 2m$. Then $\log_{12} 18 = \log_{12} 2 + 2\log_{12} 3 = m + 2(1 - 2m) = 2 - 3m$.",
  "Factorising $12$ as $2 \\times 3$, or treating $\\log_{12} 9$ as $(\\log_{12} 3)^2$.",
  "C12C-express-given-logs", "Must use $\\log_{12} 12 = 1$ to get $\\log_{12} 3$ before expressing $18$.",
  correct=r"$2 - 3m$",
  distractors=[(r"$2 - m$", r"Takes $\log_{12} 3 = 1 - m$, as if $12 = 2 \times 3$, then $m + 2(1 - m)$."),
               (r"$1 - m$", r"Uses $\log_{12} 3 = 1 - 2m$ but writes $18 = 2 \times 3$: $m + (1 - 2m)$."),
               (r"$4m^2 - 3m + 1$", r"Writes $\log_{12} 9 = (\log_{12} 3)^2$: $m + (1 - 2m)^2$.")],
  check=_c025, values=[2 - 3 * _m, 2 - _m, 1 - _m, 4 * _m**2 - 3 * _m + 1], cognitive="Application")

# ---------------------------------------------------------------- 026
def _c026():
    # level of n machines: 70 + 10 log n >= 85  <=>  n >= 10^1.5  <=>  n^2 >= 1000
    n = 1
    while not (n * n >= 1000):
        n += 1
    return n
q("C12-C-026", TOP, "Decibel scale: number of identical sources needed to reach a target level", "Medium",
  "Multi-step word problem",
  r"The sound level of a source of intensity $I$ is $10 \log_{10} \frac{I}{I_0}$ decibels, where $I_0$ is a fixed reference intensity. One machine running alone produces a sound level of $70$ decibels, and when identical machines run together their intensities add. Using $\sqrt{10} \approx 3.162$, what is the least number of such machines that must run together for the sound level to be at least $85$ decibels?",
  "MCQ",
  r"With $n$ machines the intensity is $n$ times as large, so the level is $70 + 10\log_{10} n$. We need $10 \log_{10} n \ge 15$, that is $n \ge 10^{1.5} = 10\sqrt{10} \approx 31.62$. The least whole number is $32$.",
  "Adding decibel levels as if the scale were linear.",
  "C12C-log-scale-word", "Modelling the level of $n$ sources and solving a log inequality; rounding must go up.",
  correct=r"$32$",
  distractors=[(r"$31$", r"Finds $n \ge 31.62$ and rounds down."),
               (r"$3$", r"Assumes each additional machine adds $10$ decibels: $70 + 10(n - 1) \ge 85$."),
               (r"$2$", r"Adds decibel levels directly: two machines give $140 \ge 85$.")],
  check=_c026, values=[32, 31, 3, 2], cognitive="Application")


# ================================================================ DIFFICULT (9)

# ---------------------------------------------------------------- 027
def _c027():
    return sum(k.bit_length() - 1 for k in range(1, 101))
q("C12-C-027", TOP, "Sum of integer parts of base 2 logarithms of 1 to 100", "Difficult",
  "Casework/optimisation",
  r"For each integer $k$ from $1$ to $100$, let $f(k)$ be the greatest integer that does not exceed $\log_2 k$. What is the value of $f(1) + f(2) + \cdots + f(100)$?",
  "TITA",
  r"$f(k) = j$ exactly when $2^j \le k < 2^{j+1}$, a block of $2^j$ integers. Blocks: $j = 0$ for $k = 1$; $j = 1$ for $2$ numbers; $j = 2$ for $4$; $j = 3$ for $8$; $j = 4$ for $16$; $j = 5$ for $32$; and $j = 6$ for $k = 64$ to $100$, which is $37$ numbers. The sum is $0 + 2 + 8 + 24 + 64 + 160 + 6 \times 37 = 258 + 222 = 480$.",
  "Miscounting the last, incomplete block from $64$ to $100$.",
  "C12C-floor-log-sum", "Grouping by blocks between powers of $2$, with an incomplete last block; easy to miscount.",
  tita_answer=480, check=_c027, values=[480],
  tita_traps=[(474, r"Counts the last block as $64$ to $99$, that is $36$ numbers."),
              (486, r"Counts the last block as $100 - 64 + 2 = 38$ numbers.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 028
def _c028():
    vals = {1: log(6, 5), 2: log(7, 6), 3: log(37, 25)}
    return tuple(sorted(vals, key=lambda k: -N(vals[k], 50)))
q("C12-C-028", TOP, "Ordering three logarithms using consecutive-base monotonicity and a base change", "Difficult",
  "Conceptual/application",
  r"Let $p = \log_5 6$, $q = \log_6 7$ and $r = \log_{25} 37$. Which of the following is true?",
  "MCQ",
  r"First, $r = \log_{25} 37 = \frac{1}{2}\log_5 37 = \log_5 \sqrt{37}$, and $\sqrt{37} > 6$, so $r > p$. Next compare $p$ and $q$: by AM-GM, $\log_6 5 \cdot \log_6 7 < \left(\frac{\log_6 35}{2}\right)^2 < \left(\frac{\log_6 36}{2}\right)^2 = 1$, so $\log_6 7 < \frac{1}{\log_6 5} = \log_5 6$, that is $q < p$. Hence $r > p > q$.",
  "Assuming logarithms grow with the numbers involved, or slipping when rewriting a base $25$ logarithm in base $5$.",
  "C12C-compare-logs", "Two separate comparisons, one needing a base change and one needing an AM-GM argument.",
  correct=r"$r > p > q$",
  distractors=[(r"$p > q > r$", r"Assumes a larger base always gives a smaller logarithm and puts the base $25$ value last."),
               (r"$r > q > p$", r"Assumes $\log_n (n+1)$ increases with $n$, so places $q$ above $p$."),
               (r"$p > r > q$", r"Rewrites $r$ as $\log_5 \sqrt{37}$ but takes $\sqrt{37} < 6$.")],
  check=_c028, values=[(3, 1, 2), (1, 2, 3), (3, 2, 1), (1, 3, 2)], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 029
def _c029():
    cnt = 0
    for x in range(-200, 201):
        b, a = x - 2, 16 - x
        if b <= 0 or b == 1 or a <= 0:
            continue
        # b is a positive integer > 1 here, so 1 < log_b a < 2  <=>  b < a < b^2
        if b > 1 and b < a < b * b:
            cnt += 1
        # sanity: numerical value agrees
        v = N(log(a) / log(b), 30)
        assert (1 < v < 2) == (b < a < b * b)
    return cnt
q("C12-C-029", TOP, "Integers for which a logarithm with variable base and argument lies between 1 and 2", "Difficult",
  "Casework/optimisation",
  r"For how many integers $x$ is $\log_{(x - 2)} (16 - x)$ defined and strictly between $1$ and $2$?",
  "TITA",
  r"For the logarithm to be defined we need $x - 2 > 0$, $x - 2 \ne 1$ and $16 - x > 0$, so $x$ is an integer with $4 \le x \le 15$. Then the base $x - 2 \ge 2 > 1$, so $1 < \log_{x-2}(16 - x) < 2$ means $x - 2 < 16 - x < (x - 2)^2$. The left part gives $x < 9$. The right part fails at $x = 4$ ($12 > 4$) and $x = 5$ ($11 > 9$) and holds at $x = 6, 7, 8$ ($10 < 16$, $9 < 25$, $8 < 36$). So there are $3$ integers.",
  "Applying only one side of the double inequality, or including a base equal to $1$.",
  "C12C-log-inequality", "Domain casework on a variable base plus two separate inequalities checked over a short integer range.",
  tita_answer=3, check=_c029, values=[3],
  tita_traps=[(5, r"Uses only the condition $\log_{x-2}(16 - x) > 1$, getting $x = 4$ to $8$."),
              (4, r"Rejects only $x = 4$ from the upper condition and keeps $x = 5$, misjudging $11 < 9$.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 030
def _c030():
    return len(str(2**150)) + len(str(5**150))
q("C12-C-030", TOP, "Total digits of 2 to the n and 5 to the n written side by side", "Difficult",
  "Conceptual/application",
  r"Meera writes the number $2^{150}$ and, immediately to its right, the number $5^{150}$, forming one long number. How many digits does this long number have?",
  "TITA",
  r"Let $2^{150}$ have $a$ digits and $5^{150}$ have $b$ digits. Then $10^{a-1} < 2^{150} < 10^{a}$ and $10^{b-1} < 5^{150} < 10^{b}$ (neither is a power of $10$). Multiplying, $10^{a+b-2} < 10^{150} < 10^{a+b}$, so $a + b - 1 = 150$ and $a + b = 151$.",
  "Assuming the digit counts add up to the digits of $10^{150}$ minus one, or to $150$ exactly.",
  "C12C-digits-pair", "Needs the bounding insight; no logarithm values are given, so direct computation is not available.",
  tita_answer=151, check=_c030, values=[151],
  tita_traps=[(150, r"Assumes the two digit counts add up to the exponent $150$."),
              (149, r"Uses $150\log_{10} 2 = 45.15$ and $150\log_{10} 5 = 104.85$ but takes $45 + 104$, dropping the $+1$ from each digit count.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 031
def _c031():
    cnt = 0
    for m in range(1, 101):
        for n in range(1, 101):
            if m == 1:
                continue      # log base 1 undefined
            k, v = 0, 1
            while v < n:
                v *= m
                k += 1
            if v == n and k >= 1:
                cnt += 1
    return cnt
q("C12-C-031", TOP, "Counting ordered pairs for which a logarithm is a positive integer", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs $(m, n)$ of integers with $1 \le m \le 100$ and $1 \le n \le 100$ are there for which $\log_m n$ is defined and is a positive integer?",
  "MCQ",
  r"We need $m \ge 2$ and $n = m^k$ with $k \ge 1$ and $n \le 100$. Count by $m$: $m = 2$ gives $2, 4, 8, 16, 32, 64$ ($6$); $m = 3$ gives $3, 9, 27, 81$ ($4$); $m = 4$ gives $4, 16, 64$ ($3$); $m = 5$ gives $5, 25$ ($2$); $m = 6$ to $10$ give $m$ and $m^2$ ($5 \times 2 = 10$); $m = 11$ to $100$ give only $n = m$ ($90$). Total $6 + 4 + 3 + 2 + 10 + 90 = 115$.",
  "Counting $\\log_m 1 = 0$ as positive, or forgetting the pairs with $n = m$.",
  "C12C-integer-log-count", "Casework by base with a changing number of powers; several boundary decisions.",
  correct=r"$115$",
  distractors=[(r"$214$", r"Also counts $n = 1$ for every $m$ from $2$ to $100$, treating $\log_m 1 = 0$ as positive: $115 + 99$."),
               (r"$16$", r"Counts only exponents $k \ge 2$, leaving out the $99$ pairs with $n = m$."),
               (r"$116$", r"Includes the pair $(1, 1)$, although base $1$ is not allowed.")],
  check=_c031, values=[115, 214, 16, 116], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 032
def _c032():
    u, v = symbols('u v', real=True)
    # u = log_2 x, v = log_3 y; log_x 4 = 2/u, log_y 9 = 2/v
    sols = solve([Eq(u + v, 5), Eq(2 / u + 2 / v, Rational(5, 3))], [u, v], dict=True)
    vals = set()
    for s in sols:
        x, y = 2**s[u], 3**s[v]
        assert x > 0 and y > 0 and x != 1 and y != 1
        assert abs(N(log(x, 2) + log(y, 3) - 5, 40)) < 1e-30
        assert abs(N(log(4, x) + log(9, y) - Rational(5, 3), 40)) < 1e-30
        vals.add(x + y)
    return sum(vals)
q("C12-C-032", TOP, "Pair of logarithm equations in different bases with reciprocal logarithms, solved by casework on the roots", "Difficult",
  "Casework/optimisation",
  r"Positive real numbers $x \neq 1$ and $y \neq 1$ satisfy $\log_2 x + \log_3 y = 5$ and $\log_x 4 + \log_y 9 = \frac{5}{3}$. What is the sum of all possible values of $x + y$?",
  "MCQ",
  r"Let $u = \log_2 x$ and $v = \log_3 y$. Then $\log_x 4 = \frac{2}{u}$ and $\log_y 9 = \frac{2}{v}$, so the second equation is $\frac{2(u + v)}{uv} = \frac{5}{3}$; with $u + v = 5$ this gives $uv = 6$. Hence $\{u, v\} = \{2, 3\}$. If $u = 2$, $v = 3$: $x = 4$, $y = 27$, $x + y = 31$. If $u = 3$, $v = 2$: $x = 8$, $y = 9$, $x + y = 17$. The sum of the possible values is $31 + 17 = 48$.",
  "Keeping only one assignment of the roots, or ignoring that the two bases differ.",
  "C12C-log-system", "Reciprocal change of base turns the second equation into a product condition, and then two assignments of the roots give different numbers because the bases differ; both must be found.",
  correct=r"$48$",
  distractors=[(r"$31$", r"Takes only $\log_2 x = 2$, $\log_3 y = 3$."),
               (r"$17$", r"Takes only $\log_2 x = 3$, $\log_3 y = 2$."),
               (r"$24$", r"Finds $\{u, v\} = \{2, 3\}$ correctly but then converts both back with base $2$, taking $y = 2^v$: the pairs $(4, 8)$ and $(8, 4)$ give $12 + 12$.")],
  check=_c032, values=[48, 31, 17, 24], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 033
def _c033():
    s = str(3**50)
    return (len(s), int(s[0]))
q("C12-C-033", TOP, "Number of digits and leading digit of a large power from the mantissa", "Difficult",
  "Multi-step word problem",
  r"In a chain message, each person who receives the message sends it to exactly $3$ new people, so in the $50$th round $3^{50}$ people receive it. Given $\log_{10} 2 = 0.3010$, $\log_{10} 3 = 0.4771$ and $\log_{10} 7 = 0.8451$, which of the following correctly describes the number $3^{50}$?",
  "MCQ",
  r"$\log_{10} 3^{50} = 50 \times 0.4771 = 23.855$. The characteristic $23$ gives $24$ digits. The mantissa $0.855$ lies between $\log_{10} 7 = 0.8451$ and $\log_{10} 8 = 3 \times 0.3010 = 0.9030$, so $3^{50} = 10^{23} \times 10^{0.855}$ with $7 < 10^{0.855} < 8$. The first digit is $7$.",
  "Mishandling the characteristic, or reading the leading digit from the wrong end of the bracket.",
  "C12C-leading-digit", "Needs both the digit count and an antilog bracket built from three given logarithms.",
  correct=r"$24$ digits, first digit $7$",
  distractors=[(r"$23$ digits, first digit $7$", r"Uses the characteristic $23$ as the number of digits."),
               (r"$24$ digits, first digit $8$", r"Finds the mantissa between $\log_{10} 7$ and $\log_{10} 8$ and takes the upper end of the bracket."),
               (r"$25$ digits, first digit $7$", r"Rounds $23.855$ up to $24$ and then adds $1$.")],
  check=_c033, values=[(24, 7), (23, 7), (24, 8), (25, 7)], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 034
def _c034():
    x = symbols('x', real=True)
    cands = solve(Eq(x**2, (2 * x + 9)**2), x)
    good = [c for c in cands
            if c != 0 and 2 * c + 9 > 0
            and abs(N(log(c**2, 10) - 2 * log(2 * c + 9, 10), 40)) < 1e-30]
    # brute-force scan of a grid for any solution missed by the algebra
    for k in range(-400, 401):
        xv = Rational(k, 8)
        if xv != 0 and 2 * xv + 9 > 0 and xv**2 == (2 * xv + 9)**2:
            assert xv in good
    return FiniteSet(*good)
q("C12-C-034", TOP, "Logarithm of a square: the solution comes from the negative branch of the absolute value", "Difficult",
  "Conceptual/application",
  r"The set of all real numbers $x$ satisfying $\log_{10} (x^2) = 2\log_{10} (2x + 9)$ is",
  "MCQ",
  r"The left side is defined for every $x \neq 0$, and $\log_{10}(x^2) = 2\log_{10} |x|$, not $2\log_{10} x$. The right side needs $2x + 9 > 0$, that is $x > -4.5$. The equation becomes $|x| = 2x + 9$. If $x > 0$: $x = 2x + 9$ gives $x = -9$, which is not positive. If $x < 0$: $-x = 2x + 9$ gives $x = -3$, and then $2x + 9 = 3 > 0$. Check: $\log_{10} 9 = 2\log_{10} 3$. The solution set is $\{-3\}$.",
  "Replacing $\\log_{10}(x^2)$ by $2\\log_{10} x$, which silently discards every negative $x$.",
  "C12C-log-of-square", "Strong trap: the power law must be applied as $\\log_{10}(x^2) = 2\\log_{10}|x|$, and the only solution is negative; two cases of the absolute value plus a domain check.",
  correct=r"$\{-3\}$",
  distractors=[(r"$\emptyset$", r"Writes $\log_{10}(x^2) = 2\log_{10} x$, so needs $x > 0$; then $x = 2x + 9$ gives $x = -9$, which is rejected, leaving no solution."),
               (r"$\{-9, -3\}$", r"Solves $x^2 = (2x + 9)^2$ and keeps both roots without checking that $2x + 9 > 0$."),
               (r"$\{-9\}$", r"Takes square roots as $x = 2x + 9$ only, ignoring $x = -(2x + 9)$, and does not check that $2x + 9 > 0$.")],
  check=_c034, values=[FiniteSet(-3), S.EmptySet, FiniteSet(-9, -3), FiniteSet(-9)], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 035
def _c035():
    b = symbols('b', real=True)       # b = log_2 y, a = log_2 x = (12 - b)/2
    f = b * (12 - b) / 2
    lo, hi = 0, 4                     # y > 1 and y <= 16; also a > 0 needs b < 12
    cands = [hi] + [s for s in solve(diff(f, b), b) if lo < s <= hi]
    return max(f.subs(b, c) for c in cands)
q("C12-C-035", TOP, "Maximum of a product of logarithms under a constraint with a boundary cap", "Difficult",
  "Casework/optimisation",
  r"Real numbers $x > 1$ and $y > 1$ satisfy $x^2 y = 2^{12}$ and $y \le 16$. What is the maximum possible value of $\log_2 x \cdot \log_2 y$?",
  "MCQ",
  r"Let $a = \log_2 x > 0$ and $b = \log_2 y$, so $2a + b = 12$ with $0 < b \le 4$. The product is $ab = \frac{b(12 - b)}{2}$, which increases for $b < 6$. With $b \le 4$, the maximum is at $b = 4$, $a = 4$, giving $16$. (The unconstrained maximum $18$ at $b = 6$ needs $y = 64$, which is not allowed.)",
  "Applying AM-GM without checking that the equality case is allowed by the cap on $y$.",
  "C12C-log-optimisation", "Optimum lies on the boundary; the standard AM-GM answer is a trap.",
  correct=r"$16$",
  distractors=[(r"$18$", r"Applies AM-GM to $2a$ and $b$ and ignores the cap $y \le 16$, taking $b = 6$."),
               (r"$36$", r"Treats the constraint as $a + b = 12$ and takes $a = b = 6$."),
               (r"$32$", r"Finds $b = 4$, $a = 4$ but reports $(2a)(b)$ instead of $ab$.")],
  check=_c035, values=[16, 18, 36, 32], cognitive="Analysis", exams=CX)
