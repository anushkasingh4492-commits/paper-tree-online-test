import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Integer solutions and number properties"
HEAVY = ("CAT", "XAT")


def _is_sq(n):
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def _is_cube(n):
    if n < 0:
        return False
    r = round(n ** (1.0 / 3))
    return any((r + e) ** 3 == n for e in (-1, 0, 1) if r + e >= 0)


# ---------------------------------------------------------------- EASY

# 001
def _c001():
    return sum(1 for x in range(1, 102) for y in range(1, 102) if 3 * x + 5 * y == 101)
q("C24-B-001", T, "Count of positive integer solutions of a two-variable linear equation", "Easy",
  "Single-step computation",
  r"How many ordered pairs of positive integers $(x, y)$ satisfy $3x + 5y = 101$?",
  "TITA",
  r"We need $101 - 5y$ to be a positive multiple of $3$. Since $101 \equiv 2$ and $5y \equiv 2y \pmod 3$, we need $2y \equiv 2$, that is $y \equiv 1 \pmod 3$. Also $x \geq 1$ forces $5y \leq 98$, so $y \leq 19$. Thus $y = 1, 4, 7, 10, 13, 16, 19$, giving $7$ pairs.",
  "Counting every admissible $y$ without imposing the divisibility condition, or estimating the count by a quotient instead of listing the progression.",
  "C24B-lin-count", "One congruence condition and one bound, then count a short progression.",
  tita_answer=7, check=_c001,
  tita_traps=[(20, r"Counts every $y$ from $1$ to $20$ without requiring $3 \mid (101 - 5y)$."),
              (6, r"Estimates the count as $\frac{101}{15} \approx 6.7$ and rounds down to $6$.")],
  cognitive="Application")

# 002
def _c002():
    opts = [98, 100, 99, 105]
    ok = [v for v in opts if any(sum(range(a, a + 4)) == v for a in range(1, v))]
    assert len(ok) == 1
    return ok[0]
q("C24-B-002", T, "Which number can be a sum of four consecutive positive integers", "Easy",
  "Conceptual/application",
  r"Which of the following numbers can be written as the sum of four consecutive positive integers?",
  "MCQ",
  r"Four consecutive integers starting at $a$ add up to $a + (a + 1) + (a + 2) + (a + 3) = 4a + 6$, which leaves remainder $2$ on division by $4$. Among the options only $98 = 4 \times 23 + 6$ has this form, and indeed $23 + 24 + 25 + 26 = 98$. The sum of an even number of consecutive integers is not a multiple of that number, because the average lies halfway between two integers.",
  "Assuming that the sum of $k$ consecutive integers is always a multiple of $k$, which holds only for odd $k$.",
  "C24B-consecutive-sum-middle", "One general form $4a + 6$ settles it; the trap is the multiple-of-$k$ rule that works only for odd $k$.",
  correct=r"$98$",
  distractors=[(r"$100$", r"Assumes the sum of four consecutive integers must be a multiple of $4$, as it would be if the average were an integer."),
               (r"$99$", r"Applies the rule for three consecutive integers, whose sum is a multiple of $3$: $99 = 32 + 33 + 34$."),
               (r"$105$", r"Applies the rule for five consecutive integers, whose sum is five times the middle term: $105 = 19 + 20 + 21 + 22 + 23$.")],
  check=_c002, values=[98, 100, 99, 105], cognitive="Understanding")

# 003
def _c003():
    return sum(1 for n in range(200, 2001) if _is_sq(n))
q("C24-B-003", T, "Number of perfect squares in a range", "Easy",
  "Single-step computation",
  r"How many perfect squares lie between $200$ and $2000$?",
  "TITA",
  r"Since $14^2 = 196 < 200 < 225 = 15^2$ and $44^2 = 1936 < 2000 < 2025 = 45^2$, the squares in the range are $15^2, 16^2, \ldots, 44^2$. That is $44 - 15 + 1 = 30$ squares.",
  r"Off-by-one when counting the integers from $15$ to $44$, or rounding $\sqrt{2000}$ up.",
  "C24B-squares-cubes-range", "Two square-root bounds and an inclusive count.",
  tita_answer=30, check=_c003,
  tita_traps=[(29, r"Computes $44 - 15 = 29$ without adding $1$."),
              (31, r"Rounds $\sqrt{2000} \approx 44.7$ up to $45$ and counts $15$ to $45$.")],
  cognitive="Application")

# 004
def _c004():
    k = 1
    while not _is_sq(1176 * k):
        k += 1
    return k
q("C24-B-004", T, "Least multiplier making a number a perfect square", "Easy",
  "Inverse/parameter",
  r"What is the smallest positive integer $k$ for which $1176k$ is a perfect square?",
  "MCQ",
  r"$1176 = 2^3 \times 3 \times 7^2$. A perfect square needs every exponent even, so we must supply one more $2$ and one more $3$. Hence $k = 2 \times 3 = 6$, and $1176 \times 6 = 7056 = 84^2$.",
  "Fixing only one of the odd exponents, or completing to a cube instead of a square.",
  "C24B-square-cube-multiplier", "One prime factorisation and a parity check on exponents.",
  correct=r"$6$",
  distractors=[(r"$2$", r"Fixes only the factor $2^3$ and overlooks the single $3$."),
               (r"$3$", r"Fixes only the single $3$ and overlooks that $2^3$ has an odd exponent."),
               (r"$63$", r"Completes every exponent to a multiple of $3$ (a cube): $3^2 \times 7 = 63$.")],
  check=_c004, values=[6, 2, 3, 63], cognitive="Application")

# 005
def _c005():
    sols = [(p, 85 - p) for p in range(2, 43) if isprime(p) and isprime(85 - p) and p < 85 - p]
    assert len(sols) == 1
    p, qq = sols[0]
    return qq - p
q("C24-B-005", T, "Two primes with an odd sum", "Easy",
  "Conceptual/application",
  r"$p$ and $q$ are prime numbers with $p < q$ and $p + q = 85$. What is the value of $q - p$?",
  "TITA",
  r"The sum of two odd primes is even, but $85$ is odd, so one of the primes must be $2$. Then $p = 2$ and $q = 83$, which is prime. Hence $q - p = 83 - 2 = 81$.",
  r"Searching for two primes near $\frac{85}{2}$ instead of using parity.",
  "C24B-prime-parity", "One parity observation fixes the smaller prime.",
  tita_answer=81, check=_c005,
  tita_traps=[(83, r"Reports $q$ instead of $q - p$."),
              (2, r"Reports $p$ instead of $q - p$.")],
  cognitive="Understanding")

# 006
def _c006():
    exprs = [lambda x, y: x + y, lambda x, y: x * y, lambda x, y: x + 2 * y, lambda x, y: 2 * x + y]
    good = []
    for i, f in enumerate(exprs, 1):
        if all(f(x, y) % 2 == 0 for x in range(-12, 13) for y in range(-12, 13) if (3 * x + 5 * y) % 2 == 0):
            good.append(i)
    assert good == [1]
    return 1
q("C24-B-006", T, "Parity of linear expressions", "Easy",
  "Conceptual/application",
  r"$x$ and $y$ are integers such that $3x + 5y$ is even. Which of the following must be even?",
  "MCQ",
  r"$3x + 5y = (x + y) + 2(x + 2y)$, so $3x + 5y$ and $x + y$ always have the same parity. Hence $x + y$ is even. The others need not be: $x = y = 1$ gives $3x + 5y = 8$ but $xy = 1$, $x + 2y = 3$ and $2x + y = 3$ are all odd.",
  "Assuming that an even value of $3x + 5y$ forces both $x$ and $y$ to be even.",
  "C24B-parity-must-be", "Reduce coefficients modulo $2$; one counterexample rules out the rest.",
  correct=r"$x + y$",
  distractors=[(r"$xy$", r"Assumes $3x + 5y$ even forces $x$ and $y$ both even, missing the case where both are odd."),
               (r"$x + 2y$", r"Assumes $x$ itself must be even, again missing the case where $x$ and $y$ are both odd."),
               (r"$2x + y$", r"Assumes $y$ itself must be even, missing the case where $x$ and $y$ are both odd.")],
  check=_c006, values=[1, 2, 3, 4], cognitive="Understanding")

# 007
def _c007():
    a = symbols('a', integer=True)
    s = solve(Eq(sum(a + 2 * i for i in range(5)), 135), a)
    return s[0] + 8
q("C24-B-007", T, "Consecutive odd integers with a given sum", "Easy",
  "Single-step computation",
  r"The sum of five consecutive odd integers is $135$. What is the largest of these integers?",
  "MCQ",
  r"The middle term of five equally spaced numbers is their average, $\frac{135}{5} = 27$. Consecutive odd integers differ by $2$, so the numbers are $23, 25, 27, 29, 31$, and the largest is $31$.",
  "Stepping by $1$ instead of $2$, or stopping at the average.",
  "C24B-consecutive-sum-middle", "Average gives the middle term in one step.",
  correct=r"$31$",
  distractors=[(r"$27$", r"Reports the average, which is the middle term, not the largest."),
               (r"$29$", r"Steps by $1$ from the middle as for consecutive integers: $27 + 2 = 29$."),
               (r"$35$", r"Adds four gaps of $2$ to the middle term instead of two: $27 + 8 = 35$.")],
  check=_c007, values=[31, 27, 29, 35], cognitive="Application")

# 008
def _c008():
    return sum(1 for n in range(61, 100) if isprime(n))
q("C24-B-008", T, "Counting primes in an interval", "Easy",
  "Single-step computation",
  r"How many prime numbers lie between $60$ and $100$?",
  "TITA",
  r"Test each odd number not divisible by $5$ for divisibility by $3$ and $7$ (enough, since $11^2 > 100$). The primes are $61, 67, 71, 73, 79, 83, 89, 97$. Note $63, 69, 81, 87, 93, 99$ are multiples of $3$, $77$ and $91 = 7 \times 13$ are multiples of $7$. So there are $8$ primes.",
  "Treating $91$ (or another odd composite) as prime.",
  "C24B-primality-test", "Direct check with small primes; one well-known trap at $91$.",
  tita_answer=8, check=_c008,
  tita_traps=[(9, r"Treats $91 = 7 \times 13$ as prime."),
              (10, r"Treats both $91 = 7 \times 13$ and $87 = 3 \times 29$ as prime.")],
  cognitive="Recall")

# 009
def _c009():
    n = symbols('n', positive=True, integer=True)
    s = [v for v in solve(Eq(n * (n + 1) * (n + 2), 2184), n) if v.is_integer and v > 0]
    return 3 * s[0] + 3
q("C24-B-009", T, "Three consecutive integers with a given product", "Easy",
  "Inverse/parameter",
  r"The product of three consecutive positive integers is $2184$. What is their sum?",
  "MCQ",
  r"The middle integer is close to $\sqrt[3]{2184}$, and $13^3 = 2197$, so try $12 \times 13 \times 14 = 156 \times 14 = 2184$. The integers are $12, 13, 14$ and their sum is $39$.",
  "Placing the cube-root estimate at the wrong end of the three integers.",
  "C24B-consecutive-product", "A cube-root estimate followed by one confirming multiplication.",
  correct=r"$39$",
  distractors=[(r"$42$", r"Takes the cube-root estimate $13$ as the smallest integer, uses $13, 14, 15$."),
               (r"$36$", r"Takes the cube-root estimate $13$ as the largest integer, uses $11, 12, 13$."),
               (r"$13$", r"Reports the middle integer instead of the sum.")],
  check=_c009, values=[39, 42, 36, 13], cognitive="Application")

# 010
def _c010():
    cands = [401, 221, 323, 391]
    idx = [i for i, v in enumerate(cands, 1) if isprime(v)]
    assert idx == [1]
    return 1
q("C24-B-010", T, "Identifying a prime among close composites", "Easy",
  "Conceptual/application",
  r"Which of the following numbers is a prime?",
  "MCQ",
  r"To test a number below $441 = 21^2$ it is enough to try primes up to $19$. $221 = 13 \times 17$, $323 = 17 \times 19$ and $391 = 17 \times 23$. For $401$, none of $2, 3, 5, 7, 11, 13, 17, 19$ divides it ($7 \times 57 = 399$, $11 \times 36 = 396$, $13 \times 30 = 390$, $17 \times 23 = 391$, $19 \times 21 = 399$), so $401$ is the prime.",
  "Stopping divisibility tests at $11$ or $13$ and declaring a product of two larger primes to be prime.",
  "C24B-primality-test", "Needs testing up to the square root; composites hide as products of two primes above $11$.",
  correct=r"$401$",
  distractors=[(r"$221$", r"Tests only up to $11$ and misses $221 = 13 \times 17$."),
               (r"$323$", r"Tests only up to $13$ and misses $323 = 17 \times 19$."),
               (r"$391$", r"Tests only up to $13$ and misses $391 = 17 \times 23$.")],
  check=_c010, values=[1, 2, 3, 4], cognitive="Application")

# 011
def _c011():
    return sum(1 for x in range(0, 50) for y in range(0, 29) if 4 * x + 7 * y == 196)
q("C24-B-011", T, "Count of non-negative integer solutions of a linear equation", "Easy",
  "Single-step computation",
  r"How many ordered pairs of non-negative integers $(x, y)$ satisfy $4x + 7y = 196$?",
  "MCQ",
  r"Since $4 \mid 196$, we need $4 \mid 7y$, that is $4 \mid y$. With $0 \leq 7y \leq 196$ we get $y = 0, 4, 8, \ldots, 28$, and each gives a non-negative $x = \frac{196 - 7y}{4}$, from $49$ down to $0$. That is $\frac{28}{4} + 1 = 8$ pairs.",
  "Dropping the solutions with a zero coordinate, or forgetting to add $1$ when counting the terms of the progression.",
  "C24B-lin-count", "One divisibility condition; the trap is the endpoints with a zero coordinate.",
  correct=r"$8$",
  distractors=[(r"$6$", r"Counts only positive solutions, dropping both $(49, 0)$ and $(0, 28)$."),
               (r"$7$", r"Counts the progression $y = 0, 4, \ldots, 28$ as $\frac{28}{4} = 7$, forgetting to add $1$ for the first term."),
               (r"$50$", r"Counts every $x$ from $0$ to $49$ without requiring $196 - 4x$ to be a multiple of $7$.")],
  check=_c011, values=[8, 6, 7, 50], cognitive="Application")

# 012
def _c012():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(x - y, 7), Eq(x * y, 330)], [x, y], dict=True)
    s = [d for d in s if d[x].is_integer and d[y].is_integer]
    return s[0][x] ** 2 + s[0][y] ** 2
q("C24-B-012", T, "Sum of squares from difference and product", "Easy",
  "Single-step computation",
  r"Two positive integers differ by $7$ and their product is $330$. What is the sum of their squares?",
  "MCQ",
  r"$x^2 + y^2 = (x - y)^2 + 2xy = 49 + 660 = 709$. (The numbers are $22$ and $15$, and $484 + 225 = 709$.)",
  "Dropping the factor $2$ in $2xy$, or using the identity with the wrong sign.",
  "C24B-number-puzzle-sym", "One standard identity.",
  correct=r"$709$",
  distractors=[(r"$379$", r"Drops the factor $2$: $49 + 330 = 379$."),
               (r"$611$", r"Uses the wrong sign: $2xy - (x - y)^2 = 660 - 49 = 611$."),
               (r"$1369$", r"Computes $(x + y)^2 = (x - y)^2 + 4xy = 49 + 1320 = 1369$ instead.")],
  check=_c012, values=[709, 379, 611, 1369], cognitive="Application")

# ---------------------------------------------------------------- MEDIUM

# 013
def _c013():
    sols = [(x, y) for y in range(1, 31) for x in range(1, 50) if 5 * x + 8 * y == 247]
    return max(x + y for x, y in sols)
q("C24-B-013", T, "Maximum of x + y on a linear equation", "Medium",
  "Casework/optimisation",
  r"$x$ and $y$ are positive integers with $5x + 8y = 247$. What is the largest possible value of $x + y$?",
  "MCQ",
  r"Since $x + y = \frac{247 - 3y}{5}$, the sum is largest when $y$ is smallest. We need $8y \equiv 247 \pmod 5$, that is $3y \equiv 2$, so $y \equiv 4 \pmod 5$. The smallest $y$ is $4$, giving $x = \frac{247 - 32}{5} = 43$ and $x + y = 47$.",
  "Pushing the variable with the larger coefficient up instead of down, or reporting one variable.",
  "C24B-lin-optimise", "Needs the general solution and the direction in which $x + y$ grows.",
  correct=r"$47$",
  distractors=[(r"$32$", r"Makes $y$ as large as possible, $y = 29$, $x = 3$, which gives the minimum of $x + y$."),
               (r"$43$", r"Reports $x$ at the optimum instead of $x + y$."),
               (r"$38$", r"Assumes the balanced solution $x = y = 19$ gives the largest sum.")],
  check=_c013, values=[47, 32, 43, 38], cognitive="Analysis")

# 014
def _c014():
    sols = [(x, (11 * x - 3) // 7) for x in range(1, 200) if (11 * x - 3) % 7 == 0 and (11 * x - 3) // 7 > 0]
    return min(x + y for x, y in sols)
q("C24-B-014", T, "Minimum of x + y with a difference-type linear equation", "Medium",
  "Casework/optimisation",
  r"$x$ and $y$ are positive integers with $11x - 7y = 3$. What is the smallest possible value of $x + y$?",
  "TITA",
  r"We need $11x \equiv 3 \pmod 7$, that is $4x \equiv 3 \pmod 7$; since $4 \times 6 = 24 \equiv 3$, $x \equiv 6 \pmod 7$. So $x = 6 + 7t$ and $y = 9 + 11t$ with $t \geq 0$, and $x + y = 15 + 18t$ increases with $t$. The minimum is at $x = 6$, $y = 9$: $x + y = 15$.",
  "Reporting only one variable, or not realising both variables grow together.",
  "C24B-lin-optimise", "Solving a linear congruence and recognising that $x$ and $y$ increase together.",
  tita_answer=15, check=_c014,
  tita_traps=[(6, r"Reports $x$ instead of $x + y$."),
              (33, r"Skips $x = 6$ and takes the next solution $x = 13$, $y = 20$.")],
  cognitive="Application")

# 015
def _c015():
    return sum(1 for y in range(1, 400) for x in range(y + 1, 400) if x * x - y * y == 720)
q("C24-B-015", T, "Positive solutions of x^2 - y^2 = N", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of positive integers $(x, y)$ satisfy $x^2 - y^2 = 720$?",
  "MCQ",
  r"Write $(x - y)(x + y) = 720$ with $0 < x - y < x + y$. The two factors have the same parity, and since $720$ is even both must be even: $x - y = 2a$, $x + y = 2b$ with $ab = 180$ and $a < b$. As $180 = 2^2 \times 3^2 \times 5$ has $18$ divisors and is not a square, there are $9$ such pairs, hence $9$ solutions.",
  "Ignoring the same-parity condition on the two factors.",
  "C24B-diff-squares", "Factor-pair counting with a parity filter.",
  correct=r"$9$",
  distractors=[(r"$15$", r"Counts all $15$ factor pairs $a < b$ of $720$ without requiring both factors even."),
               (r"$18$", r"Counts the divisors of $180$ instead of the factor pairs with $a < b$."),
               (r"$30$", r"Counts the $30$ divisors of $720$ as if each gave a solution.")],
  check=_c015, values=[9, 15, 18, 30], cognitive="Analysis")

# 016
def _c016():
    reps = set()
    for x in range(0, 200):
        for y in range(0, x + 1):
            d = x * x - y * y
            if 1 <= d <= 100:
                reps.add(d)
    return len(reps)
q("C24-B-016", T, "Which integers are differences of two squares", "Medium",
  "Conceptual/application",
  r"How many integers from $1$ to $100$ (both inclusive) can be written as $x^2 - y^2$, where $x$ and $y$ are non-negative integers?",
  "TITA",
  r"$x^2 - y^2 = (x - y)(x + y)$ and the two factors have the same parity, so the value is odd or a multiple of $4$; a number $\equiv 2 \pmod 4$ is impossible. Conversely $2k + 1 = (k + 1)^2 - k^2$ and $4k = (k + 1)^2 - (k - 1)^2$, so every other number works. From $1$ to $100$ there are $25$ numbers $\equiv 2 \pmod 4$, leaving $100 - 25 = 75$.",
  "Thinking only odd numbers are differences of squares, or forgetting that multiples of $4$ also work.",
  "C24B-diff-squares", "Requires the parity characterisation and its converse.",
  tita_answer=75, check=_c016,
  tita_traps=[(50, r"Counts only the odd numbers, using $(k+1)^2 - k^2 = 2k + 1$."),
              (25, r"Counts the numbers $\equiv 2 \pmod 4$, which are exactly the impossible ones.")],
  cognitive="Analysis")

# 017
def _c017():
    return sum(1 for x in range(1, 100) for y in range(1, 100) if x * y - 2 * x - 3 * y == 18)
q("C24-B-017", T, "Factoring xy + ax + by = c", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of positive integers $(x, y)$ satisfy $xy - 2x - 3y = 18$?",
  "MCQ",
  r"Add $6$ to both sides: $xy - 2x - 3y + 6 = 24$, that is $(x - 3)(y - 2) = 24$. Since $x - 3 \geq -2$ and $y - 2 \geq -1$, both factors cannot be negative with product $24$, so both are positive divisors. $24$ has $8$ divisors, so there are $8$ ordered pairs.",
  "Forgetting to add the constant that completes the factorisation, or halving for order.",
  "C24B-sfft", "Completing a product and checking the sign cases.",
  correct=r"$8$",
  distractors=[(r"$4$", r"Counts unordered factor pairs of $24$, but $(x, y)$ is ordered."),
               (r"$16$", r"Counts negative factor pairs too, without checking that they make $x$ or $y$ non-positive."),
               (r"$6$", r"Factors as $(x - 3)(y - 2) = 18$, forgetting to add $6$ to the right side, and counts divisors of $18$.")],
  check=_c017, values=[8, 4, 16, 6], cognitive="Application")

# 018
def _c018():
    return sum(1 for x in range(1, 100) for y in range(1, 100) if Fraction(1, x) + Fraction(1, y) == Fraction(1, 6))
q("C24-B-018", T, "Ordered solutions of 1/x + 1/y = 1/n", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of positive integers $(x, y)$ satisfy $\frac{1}{x} + \frac{1}{y} = \frac{1}{6}$?",
  "MCQ",
  r"Clearing denominators, $6x + 6y = xy$, so $(x - 6)(y - 6) = 36$. Both $x, y > 6$ (each reciprocal is less than $\frac{1}{6}$), so both factors are positive divisors of $36$. $36$ has $9$ divisors, giving $9$ ordered pairs.",
  "Counting unordered pairs, or allowing negative factor pairs.",
  "C24B-reciprocal-sum", "Transform to a product equation, then count divisors.",
  correct=r"$9$",
  distractors=[(r"$5$", r"Counts unordered pairs $\{x, y\}$, including $x = y = 12$ once."),
               (r"$18$", r"Counts all $18$ signed divisors of $36$ without checking positivity."),
               (r"$8$", r"Drops the solution $x = y = 12$ as if $x$ and $y$ had to differ.")],
  check=_c018, values=[9, 5, 18, 8], cognitive="Application")

# 019
def _c019():
    return sum(1 for x in range(1, 400) for y in range(x + 1, 400) if Fraction(1, x) + Fraction(1, y) == Fraction(1, 12))
q("C24-B-019", T, "Solutions of 1/x + 1/y = 1/n with x < y", "Medium",
  "Casework/optimisation",
  r"How many pairs of positive integers $(x, y)$ with $x < y$ satisfy $\frac{1}{x} + \frac{1}{y} = \frac{1}{12}$?",
  "TITA",
  r"Clearing denominators gives $(x - 12)(y - 12) = 144$ with both factors positive. $144 = 2^4 \times 3^2$ has $15$ divisors, so $15$ ordered pairs. One of them is $x = y = 24$; the other $14$ split into $7$ with $x < y$. Answer $7$.",
  "Counting ordered pairs, or not removing the case $x = y$ before halving.",
  "C24B-reciprocal-sum", "Divisor count plus removal of the symmetric case.",
  tita_answer=7, check=_c019,
  tita_traps=[(15, r"Counts all ordered pairs without imposing $x < y$."),
              (8, r"Halves $15$ and rounds up, keeping $x = y = 24$.")],
  cognitive="Application")

# 020
def _c020():
    sols = [n for n in range(1, 2000) if _is_sq(n * n + 10 * n + 52)]
    assert len(sols) == 1
    return sols[0]
q("C24-B-020", T, "Quadratic expression equal to a perfect square", "Medium",
  "Inverse/parameter",
  r"$n$ is a positive integer for which $n^2 + 10n + 52$ is a perfect square. What is the value of $n$?",
  "MCQ",
  r"$n^2 + 10n + 52 = (n + 5)^2 + 27 = m^2$, so $(m - n - 5)(m + n + 5) = 27$. The factor pairs are $1 \times 27$ and $3 \times 9$. The first gives $m = 14$, $n + 5 = 13$, so $n = 8$; the second gives $n + 5 = 3$, so $n = -2$, which is not positive. Hence $n = 8$ (check: $64 + 80 + 52 = 196 = 14^2$).",
  "Reporting $n + 5$ or $m$ instead of $n$.",
  "C24B-perfect-square-expr", "Completing the square and a difference-of-squares factorisation.",
  correct=r"$8$",
  distractors=[(r"$13$", r"Reports $n + 5 = 13$ instead of $n$."),
               (r"$14$", r"Reports $m = 14$, the square root, instead of $n$."),
               (r"$6$", r"Uses the pair $3 \times 9$ and reports $m = 6$ as $n$.")],
  check=_c020, values=[8, 13, 14, 6], cognitive="Application")

# 021
def _c021():
    return sum(1 for n in range(-1000, 1001) if _is_sq(n * n - 8 * n + 40))
q("C24-B-021", T, "Integers n making a quadratic a perfect square", "Medium",
  "Casework/optimisation",
  r"For how many integers $n$ (positive, negative or zero) is $n^2 - 8n + 40$ a perfect square?",
  "TITA",
  r"$n^2 - 8n + 40 = (n - 4)^2 + 24 = m^2$ with $m \geq 0$. Let $k = |n - 4|$; then $(m - k)(m + k) = 24$ with both factors of the same parity, so both even: $2 \times 12$ gives $k = 5$ and $4 \times 6$ gives $k = 1$. So $n - 4 = \pm 5$ or $\pm 1$, that is $n = 9, -1, 5, 3$: $4$ integers.",
  "Taking only $n - 4 > 0$ and missing the mirror values.",
  "C24B-perfect-square-expr", "Completing the square, parity filter on factor pairs, and both signs of $n - 4$.",
  tita_answer=4, check=_c021,
  tita_traps=[(2, r"Takes only $n - 4 = 5$ and $n - 4 = 1$, missing the negative values of $n - 4$."),
              (3, r"Considers only non-negative $n$ and finds $n = 9, 5, 3$, missing $n = -1$.")],
  cognitive="Analysis")

# 022
def _c022():
    s = set()
    for k in range(1, 1001):
        if k * k <= 1000:
            s.add(k * k)
        if k ** 3 <= 1000:
            s.add(k ** 3)
    return len(s)
q("C24-B-022", T, "Perfect squares or cubes up to N (inclusion-exclusion)", "Medium",
  "Conceptual/application",
  r"How many integers from $1$ to $1000$ (both inclusive) are perfect squares or perfect cubes (or both)?",
  "MCQ",
  r"Squares: $1^2$ to $31^2 = 961$, that is $31$. Cubes: $1^3$ to $10^3 = 1000$, that is $10$. Numbers that are both are sixth powers: $1, 64, 729$, that is $3$. By inclusion-exclusion the count is $31 + 10 - 3 = 38$.",
  "Not removing the sixth powers, or removing them twice.",
  "C24B-squares-cubes-range", "Two counts and the overlap of sixth powers.",
  correct=r"$38$",
  distractors=[(r"$41$", r"Adds $31 + 10$ without removing the sixth powers counted twice."),
               (r"$35$", r"Subtracts the $3$ sixth powers twice: $31 + 10 - 6$."),
               (r"$31$", r"Counts only the perfect squares.")],
  check=_c022, values=[38, 41, 35, 31], cognitive="Application")

# 023
def _c023():
    n = 1
    while not _is_cube(540 * n):
        n += 1
    return n
q("C24-B-023", T, "Least multiplier making a number a perfect cube", "Medium",
  "Inverse/parameter",
  r"What is the smallest positive integer $n$ for which $540n$ is a perfect cube?",
  "MCQ",
  r"$540 = 2^2 \times 3^3 \times 5$. For a cube every exponent must be a multiple of $3$, so we need one more $2$ and two more $5$s: $n = 2 \times 5^2 = 50$. Check: $540 \times 50 = 27000 = 30^3$.",
  "Supplying one copy of each prime, or completing to a square instead of a cube.",
  "C24B-square-cube-multiplier", "Prime factorisation with exponents completed to multiples of $3$.",
  correct=r"$50$",
  distractors=[(r"$10$", r"Supplies one more copy of each prime that is not already cubed: $2 \times 5$."),
               (r"$15$", r"Completes to a perfect square instead: $3 \times 5 = 15$ makes the exponents even."),
               (r"$20$", r"Supplies the existing exponents rather than the missing ones: $2^2 \times 5 = 20$.")],
  check=_c023, values=[50, 10, 15, 20], cognitive="Application")

# 024
def _c024():
    return sum(1 for p in range(2, 10) for qq in range(2, 69) if isprime(p) and isprime(qq) and 7 * p + qq == 68)
q("C24-B-024", T, "Linear equation in primes with parity", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of primes $(p, q)$ satisfy $7p + q = 68$?",
  "MCQ",
  r"If exactly one of $p, q$ were $2$, then $7p + q$ would be odd, but $68$ is even; $p = q = 2$ gives $16$. So both are odd and $p < \frac{68}{7}$, that is $p \in \{3, 5, 7\}$. $p = 3$ gives $q = 47$ (prime), $p = 5$ gives $q = 33 = 3 \times 11$ (not prime), $p = 7$ gives $q = 19$ (prime). So there are $2$ pairs.",
  "Not checking that $q$ is prime, or not checking that $p$ itself is prime.",
  "C24B-prime-parity", "Parity reduces to a short case check with one composite trap.",
  correct=r"$2$",
  distractors=[(r"$1$", r"Finds $(3, 47)$ and stops without checking larger $p$."),
               (r"$3$", r"Accepts $p = 5$ without noticing that $q = 33$ is composite."),
               (r"$4$", r"Counts every odd $p$ from $3$ to $9$, accepting $q = 33$ and the non-prime $p = 9$.")],
  check=_c024, values=[2, 1, 3, 4], cognitive="Application")

# 025
def _c025():
    sums = {0}
    for k in range(1, 21):
        sums = {s + k for s in sums} | {s - k for s in sums}
    return sum(1 for s in sums if -10 <= s <= 10)
q("C24-B-025", T, "Parity of signed sums", "Difficult",
  "Conceptual/application",
  r"A sign, either $+$ or $-$, is placed in front of each of the integers $1, 2, 3, \ldots, 20$, and the resulting expression is evaluated to give a value $S$. Considering all possible choices of signs, how many different values of $S$ lie between $-10$ and $10$ (both inclusive)?",
  "TITA",
  r"If the numbers given a minus sign add up to $t$, then $S = 210 - 2t$, since $1 + 2 + \cdots + 20 = 210$. So $S$ is always even. As $t$ can be any integer from $0$ to $210$ (subsets of $1, \ldots, 20$ reach every such total), every even value from $-210$ to $210$ occurs. The even values from $-10$ to $10$ are $-10, -8, \ldots, 10$: $11$ values.",
  "Ignoring parity and counting every integer in the range, or forgetting $0$.",
  "C24B-parity-signed-sum", "Needs the substitution $S = 210 - 2t$ to find the parity invariant and a separate argument that every even value in range is attainable.",
  tita_answer=11, check=_c025,
  tita_traps=[(21, r"Ignores parity and counts every integer from $-10$ to $10$."),
              (10, r"Counts the even values but leaves out $S = 0$.")],
  cognitive="Analysis", exams=HEAVY)

# 026
def _c026():
    N = 45
    ways = 0
    for a in range(1, N + 1):
        s = 0
        for b in range(a, N + 1):
            s += b
            if s == N and b > a:
                ways += 1
            if s >= N:
                break
    return ways
q("C24-B-026", T, "Ways to write N as a sum of consecutive positive integers", "Medium",
  "Conceptual/application",
  r"In how many ways can $45$ be written as a sum of two or more consecutive positive integers?",
  "MCQ",
  r"The number of ways to write $N$ as a sum of one or more consecutive positive integers equals the number of odd divisors of $N$. $45 = 3^2 \times 5$ has $6$ odd divisors, so there are $6$ ways including $45$ by itself, hence $5$ ways with two or more terms: $22 + 23$, $14 + 15 + 16$, $7 + \cdots + 11$, $5 + \cdots + 10$ and $1 + \cdots + 9$.",
  "Including the single term $45$, or finding only the runs with an odd number of terms.",
  "C24B-consecutive-runs", "Requires the odd-divisor principle or a careful search by length.",
  correct=r"$5$",
  distractors=[(r"$6$", r"Counts all odd divisors of $45$, including the one-term sum $45$ itself."),
               (r"$3$", r"Finds only runs with an odd number of terms (centred on a divisor): lengths $3$, $5$ and $9$."),
               (r"$2$", r"Finds only runs with an even number of terms: lengths $2$ and $6$.")],
  check=_c026, values=[5, 6, 3, 2], cognitive="Analysis")

# 027
def _c027():
    def is_run(N, k):
        # N = a + (a+1) + ... + (a+k-1), a >= 1
        num = N - k * (k - 1) // 2
        return num >= k and num % k == 0
    N = 1
    while not (is_run(N, 7) and is_run(N, 8)):
        N += 1
    return N
q("C24-B-027", T, "Number that is a sum of k and of k+1 consecutive integers", "Medium",
  "Inverse/parameter",
  r"A positive integer $N$ can be written as the sum of $7$ consecutive positive integers and also as the sum of $8$ consecutive positive integers. What is the smallest possible value of $N$?",
  "TITA",
  r"Seven terms starting at $a \geq 1$: $N = 7a + 21$, so $N$ is a multiple of $7$ and $N \geq 28$. Eight terms starting at $b \geq 1$: $N = 8b + 28$, so $N \equiv 4 \pmod 8$ and $N \geq 36$. Multiples of $7$ that are $\equiv 4 \pmod 8$ are $28, 84, 140, \ldots$; $28$ is below $36$, so $N = 84$ ($9 + \cdots + 15 = 84$ and $7 + \cdots + 14 = 84$).",
  "Accepting a run of $8$ that starts at $0$, which is not positive.",
  "C24B-consecutive-runs", "Two congruence conditions plus a lower bound that removes the first candidate.",
  tita_answer=84, check=_c027,
  tita_traps=[(28, r"Accepts $0 + 1 + \cdots + 7 = 28$, but $0$ is not a positive integer."),
              (56, r"Takes the LCM of $7$ and $8$ as the answer.")],
  cognitive="Analysis")

# 028
def _c028():
    sols = [(x, y, 30 - x - y) for x in range(31) for y in range(31 - x) if 2 * x + 3 * y + 5 * (30 - x - y) == 100]
    return max(s[0] for s in sols)
q("C24-B-028", T, "Two linear equations in three non-negative unknowns", "Medium",
  "Casework/optimisation",
  r"$x$, $y$ and $z$ are non-negative integers with $x + y + z = 30$ and $2x + 3y + 5z = 100$. What is the largest possible value of $x$?",
  "MCQ",
  r"Subtracting twice the first equation from the second gives $y + 3z = 40$. Then $y = 40 - 3z$ and $x = 30 - y - z = 2z - 10$. Non-negativity needs $z \geq 5$ and $3z \leq 40$, so $5 \leq z \leq 13$. $x = 2z - 10$ is largest at $z = 13$: $x = 16$ (with $y = 1$).",
  r"Pushing $z$ the wrong way, or rounding $\frac{40}{3}$ up.",
  "C24B-two-eq-three-unknowns", "Elimination to one free variable and bounds from non-negativity.",
  correct=r"$16$",
  distractors=[(r"$13$", r"Reports the value of $z$ at the optimum instead of $x$."),
               (r"$18$", r"Rounds $\frac{40}{3}$ up to $z = 14$, which makes $y = -2$."),
               (r"$0$", r"Takes the smallest $z = 5$, which actually minimises $x$.")],
  check=_c028, values=[16, 13, 18, 0], cognitive="Application")

# 029
def _c029():
    return sum(1 for x in range(-10, 11) for y in range(-10, 11) if x * x + y * y == 65)
q("C24-B-029", T, "Integer points on a circle x^2 + y^2 = N", "Medium",
  "Casework/optimisation",
  r"How many ordered pairs of integers $(x, y)$ satisfy $x^2 + y^2 = 65$?",
  "MCQ",
  r"Check squares up to $65$: $65 = 1 + 64 = 16 + 49$, and $65 - 0, 65 - 4, 65 - 9, 65 - 25, 65 - 36$ are not squares. So $\{|x|, |y|\} = \{1, 8\}$ or $\{4, 7\}$. Each gives $2$ orders and $4$ sign choices, that is $8$ pairs. Total $16$.",
  "Missing one representation, or ignoring signs or order.",
  "C24B-squares-sum", "Search for representations, then count signs and order.",
  correct=r"$16$",
  distractors=[(r"$8$", r"Finds only $65 = 1 + 64$ and misses $16 + 49$."),
               (r"$4$", r"Counts only positive ordered pairs $(1, 8), (8, 1), (4, 7), (7, 4)$."),
               (r"$32$", r"Multiplies the $4$ positive ordered pairs by $8$, counting the order swap twice.")],
  check=_c029, values=[16, 8, 4, 32], cognitive="Application")

# 030
def _c030():
    return sum(1 for n in range(1, 1000) if isprime(n * n - 10 * n + 21))
q("C24-B-030", T, "Factorable quadratic taking prime values", "Medium",
  "Casework/optimisation",
  r"For how many positive integers $n$ is $n^2 - 10n + 21$ a prime number?",
  "MCQ",
  r"$n^2 - 10n + 21 = (n - 3)(n - 7)$. A product of two integers is a (positive) prime only if one factor is $\pm 1$ and the other has the same sign. $n - 3 = 1$ gives $1 \times (-3) < 0$; $n - 7 = 1$ gives $n = 8$ and $5 \times 1 = 5$, prime; $n - 3 = -1$ gives $n = 2$ and $(-1)(-5) = 5$, prime; $n - 7 = -1$ gives $n = 6$ and $3 \times (-1) < 0$. So $n = 2$ and $n = 8$: $2$ values.",
  "Considering only the factor equal to $+1$, or ignoring the sign of the product.",
  "C24B-prime-factor-expr", "Factorisation plus sign casework on the unit factor.",
  correct=r"$2$",
  distractors=[(r"$1$", r"Considers only a factor equal to $+1$, finding $n = 8$ only."),
               (r"$4$", r"Counts all four $n$ that make a factor $\pm 1$, ignoring that two give a negative product."),
               (r"$0$", r"Assumes a product of two factors can never be prime.")],
  check=_c030, values=[2, 1, 4, 0], cognitive="Analysis")

# ---------------------------------------------------------------- DIFFICULT

# 031
def _c031():
    sols = [(a, b, c) for a in range(12) for b in range(a, 12) for c in range(b, 12) if 2 ** a + 2 ** b + 2 ** c == 1600]
    assert len(sols) == 1
    return sum(sols[0])
q("C24-B-031", T, "Sum of three powers of 2 equal to a given number", "Medium",
  "Inverse/parameter",
  r"$a$, $b$ and $c$ are non-negative integers with $a \leq b \leq c$ and $2^a + 2^b + 2^c = 1600$. What is the value of $a + b + c$?",
  "MCQ",
  r"$1600 = 2^6 \times 25 = 2^6(1 + 8 + 16) = 2^6 + 2^9 + 2^{10}$, so $1600$ has exactly three $1$s in binary. If two of the exponents were equal, say $a = b$, the sum would be $2^{a+1} + 2^c$, which has at most two $1$s in binary; three equal exponents give $3 \times 2^a \neq 1600$. So the exponents are distinct and must be the binary positions: $a = 6$, $b = 9$, $c = 10$, and $a + b + c = 25$.",
  "Forgetting to shift the exponents of the odd part by the common power of $2$.",
  "C24B-power-equation", "Factor out $2^6$ and read the binary form of $25$; a short check rules out equal exponents.",
  correct=r"$25$",
  distractors=[(r"$7$", r"Writes $25 = 2^0 + 2^3 + 2^4$ and forgets to add $6$ to each exponent: $0 + 3 + 4$."),
               (r"$13$", r"Adds the common factor's exponent $6$ only once: $0 + 3 + 4 + 6$."),
               (r"$10$", r"Reports $c$, the largest exponent, instead of $a + b + c$.")],
  check=_c031, values=[25, 7, 13, 10], cognitive="Analysis", exams=HEAVY)


# 032
def _c032():
    return sum(1 for x in range(1, 200) for y in range(1, 200) if x * y + 36 == 6 * x + 8 * y)
q("C24-B-032", T, "Factoring with negative factor cases", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs of positive integers $(x, y)$ satisfy $xy + 36 = 6x + 8y$?",
  "TITA",
  r"Rearrange: $xy - 6x - 8y + 48 = 12$, that is $(x - 8)(y - 6) = 12$. Positive factor pairs give $6$ solutions. Negative pairs also work if $x - 8 \geq -7$ and $y - 6 \geq -5$: $(-3)(-4)$ gives $(5, 2)$, $(-4)(-3)$ gives $(4, 3)$, $(-6)(-2)$ gives $(2, 4)$, while $(-1)(-12)$, $(-2)(-6)$ and $(-12)(-1)$ make $y \leq 0$ or $x \leq 0$. Total $6 + 3 = 9$.",
  "Considering only positive factor pairs.",
  "C24B-sfft", "The negative factor pairs must be checked case by case; most candidates miss them.",
  tita_answer=9, check=_c032,
  tita_traps=[(6, r"Counts only the positive divisor pairs of $12$."),
              (12, r"Counts all $12$ signed factor pairs without checking positivity of $x$ and $y$.")],
  cognitive="Analysis", exams=HEAVY)

# 033
def _c033():
    return sum(1 for x in range(1, 31) for y in range(1, 16) for z in range(1, 11) if x + 2 * y + 3 * z == 30)
q("C24-B-033", T, "Positive solutions of a three-variable weighted linear equation", "Difficult",
  "Casework/optimisation",
  r"How many ordered triples of positive integers $(x, y, z)$ satisfy $x + 2y + 3z = 30$?",
  "TITA",
  r"Fix $z$; then $x + 2y = m$ with $m = 30 - 3z$, and $y$ runs from $1$ to $\lfloor \frac{m - 1}{2} \rfloor$ (so that $x \geq 1$). For $z = 1, \ldots, 9$, $m = 27, 24, 21, 18, 15, 12, 9, 6, 3$, giving $13, 11, 10, 8, 7, 5, 4, 2, 1$ values of $y$. The total is $13 + 11 + 10 + 8 + 7 + 5 + 4 + 2 + 1 = 61$.",
  "Allowing $x = 0$ when $m$ is even, which adds one extra solution for each even $m$.",
  "C24B-lin-three-var-count", "Casework over one variable with a floor count that alternates with parity.",
  tita_answer=61, check=_c033,
  tita_traps=[(65, r"Uses $\lfloor \frac{m}{2} \rfloor$, allowing $x = 0$ for each of the four even values of $m$."),
              (54, r"Stops at $z = 6$, missing the cases $m = 9, 6, 3$.")],
  cognitive="Analysis", exams=HEAVY)

# 034
def _c034():
    cnt = 0
    for x in range(-1100, 1101):
        d = x * x - 2024
        if _is_sq(d):
            cnt += 1 if d == 0 else 2
    return cnt
q("C24-B-034", T, "All integer solutions of x^2 - y^2 = N", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs of integers $(x, y)$, positive, negative or zero, satisfy $x^2 - y^2 = 2024$?",
  "MCQ",
  r"Let $x - y = a$ and $x + y = b$, so $ab = 2024$ and $a, b$ have the same parity; since $2024$ is even, both are even. Write $a = 2a'$, $b = 2b'$ with $a'b' = 506 = 2 \times 11 \times 23$, which has $8$ positive divisors. So there are $8$ ordered pairs $(a, b)$ with both positive and $8$ with both negative, each giving a distinct $(x, y)$. Total $16$.",
  "Counting only positive factor pairs, or skipping the parity condition.",
  "C24B-diff-squares", "Parity filter plus both signs of the factor pair, with every combination of signs of $x$ and $y$.",
  correct=r"$16$",
  distractors=[(r"$4$", r"Counts only solutions with $x, y > 0$, that is pairs $a' < b'$."),
               (r"$8$", r"Uses only positive factor pairs $(a, b)$, which covers $x > 0$ but misses all negative $x$."),
               (r"$32$", r"Ignores parity: counts all $16$ positive divisors of $2024$ and doubles for sign.")],
  check=_c034, values=[16, 4, 8, 32], cognitive="Analysis", exams=HEAVY)

# 035
def _c035():
    return sum(1 for x in range(-20, 21) for y in range(-20, 21) if x * x + y * y == 325)
q("C24-B-035", T, "Integer points on x^2 + y^2 = N with several representations", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs of integers $(x, y)$ satisfy $x^2 + y^2 = 325$?",
  "MCQ",
  r"Try $|x| = 0, 1, \ldots, 12$ (enough by symmetry, since $13^2 > \frac{325}{2}$): $325 - 1 = 324 = 18^2$, $325 - 36 = 289 = 17^2$, $325 - 100 = 225 = 15^2$, and no other value gives a square. So $\{|x|, |y|\} = \{1, 18\}, \{6, 17\}, \{10, 15\}$. Each gives $2$ orders and $4$ sign choices, so $3 \times 8 = 24$.",
  "Stopping after one or two representations, or ignoring signs and order.",
  "C24B-squares-sum", "Three representations must all be found; the count then needs signs and order.",
  correct=r"$24$",
  distractors=[(r"$6$", r"Counts only positive ordered pairs."),
               (r"$12$", r"Counts sign choices but treats $(x, y)$ and $(y, x)$ as the same."),
               (r"$16$", r"Misses one of the three representations, for example $325 = 1 + 324$.")],
  check=_c035, values=[24, 6, 12, 16], cognitive="Analysis", exams=HEAVY)

# 036
def _c036():
    def ok(N):
        for a in range(1, N):
            s = 0
            for b in range(a, N + 1):
                s += b
                if s == N and b > a:
                    return True
                if s >= N:
                    break
        return False
    return sum(1 for N in range(1, 100) if ok(N))
q("C24-B-036", T, "Which integers are sums of consecutive positive integers", "Difficult",
  "Conceptual/application",
  r"How many positive integers less than $100$ can be written as the sum of two or more consecutive positive integers?",
  "TITA",
  r"A sum of $k \geq 2$ consecutive positive integers starting at $a$ is $\frac{k(2a + k - 1)}{2}$; the factors $k$ and $2a + k - 1$ have opposite parity and both exceed $1$, so the sum has an odd divisor greater than $1$. Conversely every $N$ with an odd divisor greater than $1$ can be so written. So exactly the powers of $2$ fail: $1, 2, 4, 8, 16, 32, 64$, which is $7$ numbers. Answer $99 - 7 = 92$.",
  "Forgetting that $1 = 2^0$ is a power of $2$ that also fails.",
  "C24B-consecutive-runs", "Needs the characterisation through odd divisors, not a direct search.",
  tita_answer=92, check=_c036,
  tita_traps=[(93, r"Excludes $2, 4, \ldots, 64$ but forgets that $1$ also cannot be written."),
              (49, r"Counts only the odd numbers from $3$ to $99$, missing even numbers such as $6 = 1 + 2 + 3$.")],
  cognitive="Analysis", exams=HEAVY)

# 037
def _c037():
    best = None
    for x in range(-400, 401):
        if (500 - 9 * x) % 14 == 0:
            y = (500 - 9 * x) // 14
            v = abs(x) + abs(y)
            best = v if best is None else min(best, v)
    return best
q("C24-B-037", T, "Minimising |x| + |y| over all integer solutions", "Difficult",
  "Casework/optimisation",
  r"$x$ and $y$ are integers (positive, negative or zero) with $9x + 14y = 500$. What is the smallest possible value of $|x| + |y|$?",
  "TITA",
  r"$9x \equiv 500 \equiv 10 \pmod{14}$; since $9 \times 11 = 99 \equiv 1$, $x \equiv 110 \equiv 12 \pmod{14}$. So $x = 12 + 14t$, $y = 28 - 9t$. Then $t = 0$ gives $12 + 28 = 40$, $t = -1$ gives $(-2, 37)$ and $2 + 37 = 39$, $t = 1$ gives $26 + 19 = 45$, $t = -2$ gives $16 + 46 = 62$; further $t$ only increase the sum. The minimum is $39$.",
  "Searching only non-negative solutions.",
  "C24B-lin-optimise", "General solution with negative values allowed; the optimum is outside the positive quadrant.",
  tita_answer=39, check=_c037,
  tita_traps=[(40, r"Searches only non-negative solutions and takes $x = 12$, $y = 28$."),
              (45, r"Moves in the wrong direction from $t = 0$ and takes $x = 26$, $y = 19$.")],
  cognitive="Analysis", exams=HEAVY)

# 038
def _c038():
    return sum(1 for n in range(-1000, 1001) if _is_sq(n * n + 3 * n))
q("C24-B-038", T, "Integers n for which n^2 + kn is a perfect square", "Difficult",
  "Casework/optimisation",
  r"For how many integers $n$ (positive, negative or zero) is $n^2 + 3n$ a perfect square? (Here $0$ counts as a perfect square.)",
  "MCQ",
  r"Let $n^2 + 3n = m^2$ with $m \geq 0$. Multiply by $4$: $(2n + 3)^2 - 9 = (2m)^2$, so $(2n + 3 - 2m)(2n + 3 + 2m) = 9$. The factor pairs with the first factor not larger are $(1, 9)$, $(3, 3)$, $(-9, -1)$, $(-3, -3)$, giving $2n + 3 = 5, 3, -5, -3$, that is $n = 1, 0, -4, -3$. Check: $4, 0, 4, 0$. So there are $4$ integers.",
  "Missing the negative factor pairs or the cases where the square is $0$.",
  "C24B-perfect-square-expr", "Multiply-by-$4$ completion and casework over signed factor pairs.",
  correct=r"$4$",
  distractors=[(r"$2$", r"Uses only the positive factor pairs, finding $n = 1$ and $n = 0$."),
               (r"$1$", r"Considers only positive $n$, finding $n = 1$."),
               (r"$6$", r"Counts the six ordered signed factor pairs of $9$, namely $(1, 9)$, $(9, 1)$, $(3, 3)$, $(-1, -9)$, $(-9, -1)$, $(-3, -3)$, as the answer without solving for $n$.")],
  check=_c038, values=[4, 2, 1, 6], cognitive="Analysis", exams=HEAVY)

# 039
def _c039():
    tot = 0
    for p in range(2, 73):
        for qq in range(p + 1, 73):
            r = 73 - p * qq
            if r > qq and isprime(p) and isprime(qq) and isprime(r):
                tot += r
    return tot
q("C24-B-039", T, "Prime triple forced by parity, with casework", "Difficult",
  "Casework/optimisation",
  r"$p$, $q$ and $r$ are primes with $p < q < r$ and $pq + r = 73$. What is the sum of all possible values of $r$?",
  "MCQ",
  r"If all three were odd, $pq + r$ would be even, so one prime is $2$, and as the smallest it is $p$. Then $2q + r = 73$ with $q < r$, so $3q < 73$ and $q \leq 23$. $q = 3, 5, 7, 11, 13, 17, 19, 23$ give $r = 67, 63, 59, 51, 47, 39, 35, 27$, of which only $67, 59, 47$ are prime. The sum is $67 + 59 + 47 = 173$.",
  "Ignoring the order condition, or accepting a composite value of $r$.",
  "C24B-prime-parity", "Parity to fix $p$, a bound from the ordering, then eight primality checks.",
  correct=r"$173$",
  distractors=[(r"$184$", r"Ignores $q < r$ and also accepts $q = 31$, $r = 11$."),
               (r"$126$", r"Stops after $q = 7$ and misses $r = 47$."),
               (r"$236$", r"Accepts $r = 63$ as prime.")],
  check=_c039, values=[173, 184, 126, 236], cognitive="Analysis", exams=HEAVY)

# 040
def _c040():
    vals = set()
    for bits in itertools.product((1, -1), repeat=10):
        vals.add(sum(bits[i] * bits[(i + 1) % 10] for i in range(10)))
    return len(vals)
q("C24-B-040", T, "Parity invariant in a cyclic sum of products", "Difficult",
  "Conceptual/application",
  r"Each of $x_1, x_2, \ldots, x_{10}$ is equal to $1$ or $-1$. Let $S = x_1x_2 + x_2x_3 + \cdots + x_9x_{10} + x_{10}x_1$. Over all choices, how many different values can $S$ take?",
  "MCQ",
  r"Each term is $\pm 1$. Going once round the cycle, a term is $-1$ exactly when the sign changes, and the number $k$ of sign changes round a closed cycle is even. So $S = (10 - k) - k = 10 - 2k$ with $k \in \{0, 2, 4, 6, 8, 10\}$, and each such $k$ is achievable (for $k = 10$ alternate the signs). Hence $S \in \{10, 6, 2, -2, -6, -10\}$: $6$ values.",
  "Missing that the number of $-1$ terms must be even.",
  "C24B-parity-signed-sum", "A non-obvious parity invariant on a cycle; the obvious count is wrong.",
  correct=r"$6$",
  distractors=[(r"$11$", r"Allows any number $k = 0, 1, \ldots, 10$ of negative terms, giving all even values from $-10$ to $10$."),
               (r"$21$", r"Allows every integer from $-10$ to $10$."),
               (r"$5$", r"Uses even $k$ but omits $k = 10$, wrongly believing all ten products cannot be $-1$.")],
  check=_c040, values=[6, 11, 21, 5], cognitive="Analysis", exams=HEAVY)
