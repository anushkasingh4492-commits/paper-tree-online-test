import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
import math as _m

T = "Circle combinations"
CX = ("CAT", "XAT")
P7 = Rational(22, 7)


def _fig(f, alt, req=False):
    return dict(svg=f.svg(alt=alt), alt=alt, required=req)


def _lens(r1, r2, d):
    """Exact area common to two circles of radii r1, r2 with centres d apart (general formula)."""
    r1, r2, d = sympify(r1), sympify(r2), sympify(d)
    a1 = acos((d**2 + r1**2 - r2**2) / (2 * d * r1))
    a2 = acos((d**2 + r2**2 - r1**2) / (2 * d * r2))
    k = sqrt((-d + r1 + r2) * (d + r1 - r2) * (d - r1 + r2) * (d + r1 + r2)) / 2
    return nsimplify(simplify(r1**2 * a1 + r2**2 * a2 - k), [pi, sqrt(3)])


def _seg_int(r, h):
    """Area of the segment cut off by a chord at distance h from the centre, by integration."""
    y = symbols('y', real=True)
    return simplify(integrate(2 * sqrt(r**2 - y**2), (y, h, r)))


def _poly_area(V):
    n = len(V)
    return abs(sum(V[i][0] * V[(i + 1) % n][1] - V[(i + 1) % n][0] * V[i][1] for i in range(n))) / 2


def _vertex_angle(V, i):
    n = len(V)
    a, b, c = V[i - 1], V[i], V[(i + 1) % n]
    u = (a[0] - b[0], a[1] - b[1]); w = (c[0] - b[0], c[1] - b[1])
    return acos(simplify((u[0] * w[0] + u[1] * w[1]) / (sqrt(u[0]**2 + u[1]**2) * sqrt(w[0]**2 + w[1]**2))))


def _tether_numeric(w, h, L, step=0.02):
    """Numerical area reachable by a rope of length L tied at corner (0,0) outside a w x h shed."""
    import numpy as np
    xs = np.arange(-L - 1 + step / 2, w + L + 1, step)
    ys = np.arange(-L - 1 + step / 2, h + L + 1, step)
    X, Y = np.meshgrid(xs, ys)
    inside = (X > 0) & (X < w) & (Y > 0) & (Y < h)
    direct = (X <= 0) | (Y <= 0)
    d = np.full(X.shape, np.inf)
    d[direct] = np.hypot(X, Y)[direct]
    c1 = (~direct) & (X >= w)
    d[c1] = np.minimum(d[c1], (w + np.hypot(X - w, Y))[c1])
    c2 = (~direct) & (Y >= h)
    d[c2] = np.minimum(d[c2], (h + np.hypot(X, Y - h))[c2])
    reach = (d <= L) & (~inside)
    return float(reach.sum()) * step * step


# ---------------------------------------------------------------- 001
def _c001():
    r1, r2, d = 11, 4, 25
    P = symbols('P', real=True)
    # tangent line y = m x + c touching both circles on the same side: |c|/sqrt(1+m^2) = 11, |25m + c|/sqrt(1+m^2) = 4
    m, c = symbols('m c', real=True)
    sols = solve([Eq(c, 11 * sqrt(1 + m**2)), Eq(25 * m + c, 4 * sqrt(1 + m**2))], [m, c], dict=True)
    s = sols[0]
    M, C = s[m], s[c]
    # feet of perpendiculars from centres to the line
    def foot(x0, y0):
        t = (M * x0 - y0 + C) / (M**2 + 1)
        return (x0 - M * t, y0 + t)
    F1, F2 = foot(0, 0), foot(25, 0)
    return simplify(sqrt((F1[0] - F2[0])**2 + (F1[1] - F2[1])**2))
_f = Fig()
_O1 = _f.pt("O", 0, 0); _O2 = _f.pt("O'", 25, 0)
_f.circle(_O1, 11); _f.circle(_O2, 4)
_n = (7 / 25, 24 / 25)
_P = _f.pt("P", 11 * _n[0], 11 * _n[1]); _Q = _f.pt("Q", 25 + 4 * _n[0], 4 * _n[1])
_f.seg(_P, _Q); _f.seg(_O1, _P); _f.seg(_O2, _Q); _f.seg(_O1, _O2, dashed=True)
_f.text((17.5, -1.8), "25 cm")
_alt = "Two separate circles with centres O and O' joined by a dashed segment of 25 cm. A common tangent touches the larger circle at P and the smaller circle at Q, both on the same side of OO'."
q("C16-B-001", T, "Length of a direct common tangent from the radii and the distance between centres", "Easy",
  "Single-step computation",
  r"Two circles with centres $O$ and $O'$ have radii $11$ cm and $4$ cm, and $OO' = 25$ cm. A common tangent touches the circles at $P$ and $Q$ respectively, with both circles lying on the same side of the line $PQ$. What is the length of $PQ$?",
  "MCQ",
  r"For a direct common tangent, drop a perpendicular from $O'$ to $OP$: it forms a right triangle with hypotenuse $OO' = 25$ and one leg $11 - 4 = 7$. So $PQ = \sqrt{25^2 - 7^2} = \sqrt{576} = 24$ cm.",
  "Using the sum of the radii (transverse tangent formula) for a direct tangent, or subtracting lengths instead of their squares.",
  "C16B-direct-tangent-length", "One right triangle with the difference of radii as a leg.",
  correct=r"$24$ cm",
  distractors=[(r"$20$ cm", "Uses the transverse tangent formula $\\sqrt{25^2 - (11+4)^2} = 20$."),
               (r"$18$ cm", "Subtracts the difference of radii linearly: $25 - 7 = 18$."),
               (r"$10$ cm", "Reports the gap between the circles along $OO'$: $25 - 11 - 4 = 10$.")],
  check=_c001, values=[24, 20, 18, 10], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 002
def _c002():
    d = symbols('d', positive=True)
    return solve(Eq(d**2 - (5 + 3)**2, 15**2), d)[0]
q("C16-B-002", T, "Distance between centres from the transverse common tangent", "Easy",
  "Inverse/parameter",
  r"Two circles of radii $5$ cm and $3$ cm lie completely outside each other. A common tangent that crosses the line joining their centres touches the circles at two points that are $15$ cm apart. What is the distance between the centres of the two circles, in cm?",
  "TITA",
  r"For a transverse common tangent, $L^2 = d^2 - (r_1 + r_2)^2$. So $d^2 = 15^2 + 8^2 = 225 + 64 = 289$ and $d = 17$ cm.",
  "Using the difference of the radii, which belongs to the direct tangent, or adding lengths instead of squares.",
  "C16B-transverse-tangent-length", "Single use of the transverse tangent relation, run backwards.",
  tita_answer=17, check=_c002, cognitive="Application",
  tita_traps=[(23, "Adds lengths: $15 + 5 + 3 = 23$.")])

# ---------------------------------------------------------------- 003
def _c003():
    d, r1 = symbols('d r1', positive=True)
    sols = solve([Eq(d**2 - (r1 - 2)**2, 17**2), Eq(d**2 - (r1 + 2)**2, 15**2)], [d, r1], dict=True)
    good = [s[r1] for s in sols if s[r1] > 2 and s[d] > s[r1] + 2]
    assert len(good) == 1
    return good[0]
q("C16-B-003", T, "Second radius from the lengths of both common tangents", "Medium",
  "Inverse/parameter",
  r"Two circles lie completely outside each other. The length of each direct common tangent between its points of contact is $17$ cm, and the length of each transverse common tangent between its points of contact is $15$ cm. If the radius of the smaller circle is $2$ cm, the radius of the larger circle is",
  "MCQ",
  r"With $d$ the distance between centres, $17^2 = d^2 - (r_1 - r_2)^2$ and $15^2 = d^2 - (r_1 + r_2)^2$. Subtracting, $(r_1 + r_2)^2 - (r_1 - r_2)^2 = 4r_1r_2 = 289 - 225 = 64$, so $r_1 r_2 = 16$ and $r_1 = \frac{16}{2} = 8$ cm. (Then $d^2 = 289 + 36 = 325$, and $d > 10$, so the circles are indeed separate.)",
  "Treating the difference of the squared tangent lengths as $r_1 r_2$ or $2r_1r_2$ instead of $4r_1r_2$.",
  "C16B-two-common-tangents-radii", "Needs the identity linking both tangent lengths; d is never found directly.",
  correct=r"$8$ cm",
  distractors=[(r"$32$ cm", "Takes $r_1 r_2 = 289 - 225 = 64$, dropping the factor $4$: $r_1 = \\frac{64}{2}$."),
               (r"$16$ cm", "Takes $2 r_1 r_2 = 64$, so $r_1 r_2 = 32$ and $r_1 = \\frac{32}{2}$."),
               (r"$6$ cm", "Takes $289 - 225 = 64$ as $(r_1 + r_2)^2$, so $r_1 + r_2 = 8$ and $r_1 = 6$.")],
  check=_c003, values=[8, 32, 16, 6], cognitive="Analysis")

# ---------------------------------------------------------------- 004
def _c004():
    x = symbols('x', positive=True)
    return solve(Eq(x**2 + (9 - 4)**2, (9 + 4)**2), x)[0]
_f = Fig()
_f.seg((-11, 0), (18, 0))
_f.circle((0, 9), 9); _f.circle((12, 4), 4)
_f.pt("O", 0, 9); _f.pt("O'", 12, 4)
_f.pt("P", 0, 0, offset=(0, -1)); _f.pt("Q", 12, 0, offset=(0, -1))
_f.seg((0, 9), (0, 0), dashed=True); _f.seg((12, 4), (12, 0), dashed=True)
_f.label_seg((0, 9), (0, 0), "9 cm", side=-1); _f.label_seg((12, 4), (12, 0), "4 cm")
_alt = "A straight line with two circles resting on it and touching each other. The larger circle, centre O, radius 9 cm, touches the line at P; the smaller circle, centre O', radius 4 cm, touches the line at Q."
q("C16-B-004", T, "Distance between the points where two touching circles meet a common line", "Easy",
  "Single-step computation",
  r"Two circles of radii $9$ cm and $4$ cm touch each other externally, and both touch a straight line, at $P$ and $Q$ respectively. What is the distance $PQ$?",
  "MCQ",
  r"The centres are $9 + 4 = 13$ cm apart and their heights above the line differ by $9 - 4 = 5$ cm, so $PQ = \sqrt{13^2 - 5^2} = 12$ cm. Equivalently, $PQ = 2\sqrt{r_1 r_2} = 2\sqrt{36} = 12$ cm.",
  "Taking the distance between the centres or the difference of radii as the distance along the line.",
  "C16B-touching-circles-on-line", "One right triangle, or the direct use of $2\\sqrt{r_1 r_2}$.",
  correct=r"$12$ cm",
  distractors=[(r"$13$ cm", "Reports the distance between the centres, $9 + 4$."),
               (r"$5$ cm", "Reports the difference of the radii."),
               (r"$6$ cm", "Uses $\\sqrt{r_1 r_2}$ without the factor $2$.")],
  check=_c004, values=[12, 13, 5, 6], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 005
def _c005():
    x, r, X = symbols('x r X', positive=True)
    # big circle centre (0,36), second circle centre (X, 9) touching it, both on the line y = 0
    Xv = [s for s in solve(Eq(X**2 + 27**2, 45**2), X) if s > 0][0]
    sols = solve([Eq(x**2 + (36 - r)**2, (36 + r)**2), Eq((Xv - x)**2 + (9 - r)**2, (9 + r)**2)], [x, r], dict=True)
    return [s[r] for s in sols if 0 < s[x] < Xv][0]
_f = Fig()
_f.seg((-36, 0), (47, 0))
_f.circle((0, 36), 36); _f.circle((36, 9), 9); _f.circle((24, 4), 4)
_f.pt("", 0, 36); _f.pt("", 36, 9)
_f.seg((0, 36), (0, 72)); _f.text((-7, 54), "36 cm")
_f.seg((36, 9), (36 + 9 / _m.sqrt(2), 9 + 9 / _m.sqrt(2))); _f.text((47, 21), "9 cm")
_alt = "A straight line with three circles resting on it. A large circle of radius 36 cm and a circle of radius 9 cm touch each other; a small circle sits in the gap below their point of contact, touching both circles and the line."
q("C16-B-005", T, "Radius of a circle squeezed between two touching circles and their common tangent line", "Difficult",
  "Conceptual/application",
  r"Two circles of radii $36$ cm and $9$ cm touch each other externally and both rest on a straight line. A third circle, lying in the region between the two circles and the line, touches both circles externally and also touches the line. What is the radius of the third circle, in cm?",
  "TITA",
  r"Two circles of radii $a$ and $b$ that touch each other and a line have points of contact on the line $2\sqrt{ab}$ apart. Applying this to all three pairs, $2\sqrt{36 \cdot 9} = 2\sqrt{36 r} + 2\sqrt{9 r}$, that is $18 = 6\sqrt{r} + 3\sqrt{r} = 9\sqrt{r}$. So $\sqrt{r} = 2$ and $r = 4$ cm.",
  "Taking a mean of the two radii instead of splitting the tangent length $2\\sqrt{ab}$ between the two smaller pairs.",
  "C16B-circle-between-two-and-line", "Needs the $2\\sqrt{ab}$ contact distance applied three times and an additive split along the line.",
  tita_answer=4, check=_c005, cognitive="Analysis", exams=CX,
  tita_traps=[(18, "Takes the geometric mean $\\sqrt{36 \\times 9}$ as the radius."),
              (9, "Assumes the third circle equals the smaller circle.")],
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 006
def _c006():
    r, x = symbols('r x', positive=True)
    sols = solve([Eq(x**2 + (r - 9)**2, (r + 9)**2), Eq(x, 24)], [r, x], dict=True)
    return sols[0][r]
q("C16-B-006", T, "Radius of a touching circle from the distance between contact points on a line", "Medium",
  "Inverse/parameter",
  r"Two circles touch each other externally and both touch a straight line. The points where they touch the line are $24$ cm apart. If one circle has radius $9$ cm, what is the radius of the other circle?",
  "MCQ",
  r"The contact points of two such circles are $2\sqrt{r_1 r_2}$ apart, because the centres are $r_1 + r_2$ apart and differ in height by $|r_1 - r_2|$. So $2\sqrt{9r} = 24$, giving $9r = 144$ and $r = 16$ cm. Check: $\sqrt{25^2 - 7^2} = 24$.",
  "Treating the distance along the line as a sum of radii, or dropping the factor $2$ in $2\\sqrt{r_1 r_2}$.",
  "C16B-touching-circles-on-line", "One relation run backwards; the trap is the missing factor 2.",
  correct=r"$16$ cm",
  distractors=[(r"$15$ cm", "Takes $24 = 9 + r$, treating the distance along the line as the sum of the radii."),
               (r"$64$ cm", "Uses $\\sqrt{9r} = 24$, dropping the factor $2$."),
               (r"$32$ cm", "Uses $\\sqrt{2 \\cdot 9 r} = 24$, putting the $2$ inside the root.")],
  check=_c006, values=[16, 15, 64, 32], cognitive="Application")

# ---------------------------------------------------------------- 007
def _c007():
    k, s, R = symbols('k s R', positive=True)
    # equal circles of radius 1 centred at (0,0), (2,0), (1, sqrt3); small and large circles centred at (1, k)
    sol_s = solve([Eq(1 + k**2, (1 + s)**2), Eq((sqrt(3) - k)**2, (1 + s)**2)], [k, s], dict=True)
    sv = [d[s] for d in sol_s if d[s] < 1][0]
    sol_R = solve([Eq(1 + k**2, (R - 1)**2), Eq((sqrt(3) - k)**2, (R - 1)**2)], [k, R], dict=True)
    Rv = [d[R] for d in sol_R if d[R] > 1][0]
    return nsimplify(simplify(Rv / sv), [sqrt(3)])
q("C16-B-007", T, "Ratio of the enclosing circle to the gap circle for three equal touching circles", "Difficult",
  "Multi-step word problem",
  r"Three identical circles each touch the other two externally. A small circle lies in the gap between them and touches all three externally. A large circle encloses all three and touches each of them internally. The ratio of the radius of the large circle to the radius of the small circle is",
  "MCQ",
  r"Let each equal circle have radius $r$. The centres form an equilateral triangle of side $2r$, whose centre is at distance $\frac{2r}{\sqrt{3}}$ from each vertex. The small circle has radius $\frac{2r}{\sqrt{3}} - r$ and the large circle has radius $\frac{2r}{\sqrt{3}} + r$. The ratio is $\frac{2 + \sqrt{3}}{2 - \sqrt{3}} = (2 + \sqrt{3})^2 = 7 + 4\sqrt{3}$.",
  "Using the full median instead of two thirds of it, or forgetting to add the radius for the enclosing circle.",
  "C16B-gap-circle-among-equal-circles", "Two related radii, each from the centroid distance, then a surd ratio to rationalise.",
  correct=r"$7 + 4\sqrt{3}$",
  distractors=[(r"$2 + \sqrt{3}$", "Takes the distance from the triangle's centre to a vertex as the full median $\\sqrt{3}r$: ratio $\\frac{\\sqrt{3}+1}{\\sqrt{3}-1} = 2 + \\sqrt{3}$."),
               (r"$4 + 2\sqrt{3}$", "Takes the large radius as $\\frac{2r}{\\sqrt{3}}$, not adding $r$: ratio $\\frac{2}{2 - \\sqrt{3}} = 4 + 2\\sqrt{3}$."),
               (r"$7 - 4\sqrt{3}$", "Inverts the ratio, giving small to large.")],
  check=_c007, values=[7 + 4 * sqrt(3), 2 + sqrt(3), 4 + 2 * sqrt(3), 7 - 4 * sqrt(3)], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 008
def _c008():
    s = symbols('s', positive=True)
    return solve(Eq(sqrt(6**2 + 6**2), 6 + s), s)[0]
_f = Fig()
for _cx, _cy in ((6, 6), (-6, 6), (-6, -6), (6, -6)):
    _f.circle((_cx, _cy), 6); _f.pt("", _cx, _cy)
_f.circle((0, 0), 6 * _m.sqrt(2) - 6)
_f.seg((6, 6), (12, 6)); _f.label_seg((6, 6), (12, 6), "6 cm")
_alt = "Four equal circles of radius 6 cm whose centres form a square, each touching its two neighbours, with a small circle in the central gap touching all four."
q("C16-B-008", T, "Radius of the circle in the gap between four equal touching circles", "Medium",
  "Multi-step word problem",
  r"Four coins, each of radius $6$ cm, lie flat on a table with their centres at the corners of a square, so that each coin touches the two coins next to it. A smaller coin is placed in the central gap so that it touches all four. What is the radius of the smaller coin?",
  "MCQ",
  r"The centres form a square of side $12$ cm, so the centre of the square is $\frac{12\sqrt{2}}{2} = 6\sqrt{2}$ cm from each centre. The small coin's radius is this distance minus one large radius: $6\sqrt{2} - 6$ cm (about $2.49$ cm).",
  "Using the full diagonal, or a diameter where a radius is needed, or the three-coin centroid distance.",
  "C16B-gap-circle-among-equal-circles", "Two steps: half-diagonal of the centre square, then subtract a radius.",
  correct=r"$6\sqrt{2} - 6$ cm",
  distractors=[(r"$12\sqrt{2} - 12$ cm", "Subtracts a diameter from the full diagonal, which gives the small coin's diameter, and reports it as the radius."),
               (r"$12\sqrt{2} - 6$ cm", "Uses the full diagonal $12\\sqrt{2}$ of the centre square instead of half of it."),
               (r"$4\sqrt{3} - 6$ cm", "Applies the three-coin centroid distance $\\frac{2r}{\\sqrt{3}} = 4\\sqrt{3}$ to a square arrangement.")],
  check=_c008, values=[6 * sqrt(2) - 6, 12 * sqrt(2) - 12, 12 * sqrt(2) - 6, 4 * sqrt(3) - 6], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 009
def _c009():
    tri = Triangle(Point(0, 0), Point(20, 0), Point(0, 21))
    return tri.inradius
q("C16-B-009", T, "Inradius of a right triangle", "Easy",
  "Single-step computation",
  r"A triangular garden has sides along two perpendicular fences of lengths $20$ m and $21$ m, with the third side joining their far ends. The largest circular fountain that fits inside the garden touches all three sides. What is the radius of the fountain, in metres?",
  "TITA",
  r"The hypotenuse is $\sqrt{20^2 + 21^2} = 29$ m. For a right triangle the inradius is $\frac{a + b - c}{2} = \frac{20 + 21 - 29}{2} = 6$ m. (Check: area $210$, semi-perimeter $35$, $\frac{210}{35} = 6$.)",
  "Forgetting to halve $a + b - c$, or dividing the area by the full perimeter.",
  "C16B-right-triangle-inradius", "One formula for the inradius of a right triangle after a Pythagorean triple.",
  tita_answer=6, check=_c009, cognitive="Application",
  tita_traps=[(12, "Uses $a + b - c$ without halving."),
              (3, "Divides the area $210$ by the full perimeter $70$.")])

# ---------------------------------------------------------------- 010
def _c010():
    # tangent line y = 0; big circle centre O = (0, 6), small circle centre O' = (X, 2), touching externally
    X = symbols('X', positive=True)
    Xv = solve(Eq(X**2 + (6 - 2)**2, (6 + 2)**2), X)[0]
    O, O2, P_, Q_ = (0, 6), (Xv, 2), (0, 0), (Xv, 0)
    trap = _poly_area([P_, Q_, O2, O])
    ang_O = _vertex_angle([P_, O, O2], 1)          # angle POO'
    ang_O2 = _vertex_angle([O, O2, Q_], 1)         # angle OO'Q
    exact = nsimplify(simplify(trap - ang_O / 2 * 36 - ang_O2 / 2 * 4), [pi, sqrt(3)])
    # independent numerical check: trapezium below the line of centres minus the parts covered by the discs
    import mpmath as mp
    xv = float(Xv)
    def slice_len(x):
        top = 6 - 4 * x / xv
        tot = top
        for (cx, cy, rr) in ((0.0, 6.0, 6.0), (xv, 2.0, 2.0)):
            if abs(x - cx) < rr:
                h = mp.sqrt(rr**2 - (x - cx)**2)
                lo, hi = max(0, cy - h), min(top, cy + h)
                if hi > lo:
                    tot -= hi - lo
        return tot
    num = mp.quad(slice_len, [0, xv - 2, 3 * mp.sqrt(3), xv])
    assert abs(num - float(exact)) < 1e-6, (num, exact)
    return exact
_f = Fig()
_X10 = 4 * _m.sqrt(3)
_f.seg((-3, 0), (_X10 + 3, 0))
_f.circle((0, 6), 6); _f.circle((_X10, 2), 2)
_f.pt("", 0, 6); _f.pt("", _X10, 2)
_f.pt("P", 0, 0, offset=(0, -1)); _f.pt("Q", _X10, 0, offset=(0, -1))
_f.seg((0, 6), (0, 12)); _f.text((-2.2, 9), "6 cm")
_f.seg((_X10, 2), (_X10, 4)); _f.text((_X10 + 2.6, 3.4), "2 cm")
_alt = "Two circles of radii 6 cm and 2 cm touching each other externally and both resting on a straight line, which touches the larger circle at P and the smaller circle at Q. A small curved region lies between the segment PQ and the two circles."
q("C16-B-010", T, "Area between two touching circles and their direct common tangent", "Difficult",
  "Multi-step word problem",
  r"Two circles of radii $6$ cm and $2$ cm touch each other externally. A common tangent that does not pass between the circles touches the larger circle at $P$ and the smaller circle at $Q$. What is the area of the small region enclosed by the segment $PQ$ and the two circles?",
  "MCQ",
  r"With centres $O$ and $O'$, $OO' = 8$ and $OP - O'Q = 4$, so $PQ = \sqrt{8^2 - 4^2} = 4\sqrt{3}$ and trapezium $OPQO'$ has area $\frac{1}{2}(6 + 2) \times 4\sqrt{3} = 16\sqrt{3}$. Since $\cos \angle POO' = \frac{4}{8}$, $\angle POO' = 60^\circ$ and $\angle QO'O = 120^\circ$ (co-interior angles, as $OP \parallel O'Q$). Removing the two sectors, $\frac{60}{360} \times 36\pi = 6\pi$ and $\frac{120}{360} \times 4\pi = \frac{4\pi}{3}$, leaves $16\sqrt{3} - \frac{22\pi}{3}$ cm$^2$.",
  "Assuming both sector angles are equal, or using the angles between the tangent and the line of centres in place of the angles at the centres.",
  "C16B-tangent-touching-circles-region", "Four stages: tangent length, trapezium, the supplementary angles at the two centres, and two different sectors.",
  correct=r"$16\sqrt{3} - \frac{22\pi}{3}$ cm$^2$",
  distractors=[(r"$32\sqrt{3} - \frac{22\pi}{3}$ cm$^2$", "Takes the trapezium's area as $(6 + 2) \\times 4\\sqrt{3}$, without the half."),
               (r"$16\sqrt{3} - \frac{20\pi}{3}$ cm$^2$", "Uses $60^\\circ$ at both centres: $6\\pi + \\frac{2\\pi}{3}$."),
               (r"$16\sqrt{3} - \frac{11\pi}{3}$ cm$^2$", "Uses half of each centre angle, $30^\\circ$ and $60^\\circ$: $3\\pi + \\frac{2\\pi}{3}$.")],
  check=_c010, values=[16 * sqrt(3) - Rational(22, 3) * pi, 32 * sqrt(3) - Rational(22, 3) * pi, 16 * sqrt(3) - Rational(20, 3) * pi, 16 * sqrt(3) - Rational(11, 3) * pi],
  cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 011
def _c011():
    tri = Triangle(Point(0, 0), Point(12, 0), Point(6, 6 * sqrt(3)))
    return simplify(pi * (tri.circumradius**2 - tri.inradius**2))
_f = Fig()
_f.poly((0, 0), (12, 0), (6, 6 * _m.sqrt(3)))
_f.circle((6, 2 * _m.sqrt(3)), 2 * _m.sqrt(3)); _f.circle((6, 2 * _m.sqrt(3)), 4 * _m.sqrt(3))
_f.text((6, -1.6), "12 cm")
_alt = "An equilateral triangle of side 12 cm with its incircle inside it and its circumcircle passing through its three vertices; the two circles are concentric."
q("C16-B-011", T, "Area between the incircle and circumcircle of an equilateral triangle", "Easy",
  "Conceptual/application",
  r"An equilateral triangle has side $12$ cm. What is the area of the ring-shaped region between its circumcircle and its incircle?",
  "MCQ",
  r"The two circles are concentric. A radius of the circumcircle to a vertex, a radius of the incircle to the midpoint of a side, and half a side form a right triangle, so $R^2 - r^2 = 6^2 = 36$. The ring has area $\pi(R^2 - r^2) = 36\pi$ cm$^2$. (Directly: $R = 4\sqrt{3}$, $r = 2\sqrt{3}$, $48 - 12 = 36$.)",
  "Using $\\pi(R - r)^2$ for the ring, or taking the altitude as the circumradius.",
  "C16B-regular-polygon-annulus", "One right triangle (or the two standard radii), then a ring area.",
  correct=r"$36\pi$ cm$^2$",
  distractors=[(r"$48\pi$ cm$^2$", "Gives the area of the circumcircle alone."),
               (r"$12\pi$ cm$^2$", "Computes $\\pi(R - r)^2 = \\pi(2\\sqrt{3})^2$."),
               (r"$96\pi$ cm$^2$", "Takes the altitude $6\\sqrt{3}$ as the circumradius: $\\pi(108 - 12)$.")],
  check=_c011, values=[36 * pi, 48 * pi, 12 * pi, 96 * pi], cognitive="Understanding",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 012
def _c012():
    a, n = 10, 8
    R = a / (2 * sin(pi / n)); r = a / (2 * tan(pi / n))
    return nsimplify(simplify(R**2 - r**2))
q("C16-B-012", T, "Ring between the incircle and circumcircle of a regular octagon", "Medium",
  "Conceptual/application",
  r"A regular octagon has side $10$ cm. The region between its circumcircle and its incircle has area $k\pi$ cm$^2$. What is the value of $k$?",
  "TITA",
  r"For any regular polygon, the circumradius to a vertex, the inradius to the midpoint of an adjacent side, and half the side form a right triangle. So $R^2 - r^2 = \left(\frac{10}{2}\right)^2 = 25$, and the ring has area $25\pi$. Hence $k = 25$, without computing either radius.",
  "Using the whole side instead of half the side in the right triangle.",
  "C16B-regular-polygon-annulus", "Insight that the ring area depends only on the side; brute force with trig ratios of $22.5^\\circ$ is slow.",
  tita_answer=25, check=_c012, cognitive="Analysis",
  tita_traps=[(100, "Uses the full side: $R^2 - r^2 = 10^2$.")])

# ---------------------------------------------------------------- 013
def _c013():
    side = Integer(16)
    areas = []
    for _ in range(3):
        areas.append(side**2)
        r = side / 2               # circle inscribed in the square
        side = r * sqrt(2)         # square inscribed in that circle
    ratio = simplify(areas[1] / areas[0])
    assert simplify(areas[2] / areas[1] - ratio) == 0
    return simplify(areas[0] / (1 - ratio))
q("C16-B-013", T, "Sum of areas of an infinite chain of squares and inscribed circles", "Medium",
  "Multi-step word problem",
  r"A square has side $16$ cm. A circle is inscribed in it, a square is inscribed in that circle, another circle is inscribed in the second square, and the process continues indefinitely. What is the sum of the areas of all the squares, in cm$^2$?",
  "TITA",
  r"A circle inscribed in a square of side $s$ has diameter $s$, and the square inscribed in it has diagonal $s$, so its area is $\frac{s^2}{2}$. The square areas are $256, 128, 64, \ldots$, a geometric series with ratio $\frac{1}{2}$, whose sum is $\frac{256}{1 - 1/2} = 512$ cm$^2$.",
  "Taking the next side as half the previous side (ratio $\\frac{1}{4}$), or leaving out the first square.",
  "C16B-nested-squares-circles", "Spot the constant ratio through the circle, then sum an infinite GP.",
  tita_answer=512, check=_c013, cognitive="Application",
  tita_traps=[(256, "Adds only the inscribed squares, leaving out the first one."),
              (1024, "Uses ratio $\\frac{3}{4}$, thinking each square loses a quarter of the previous area.")])

# ---------------------------------------------------------------- 014
def _c014():
    r = Integer(1)
    outer = (2 * r)**2; circ = pi * r**2; inner = (2 * r)**2 / 2
    return simplify((outer - circ) / (circ - inner))
_f = Fig()
_f.poly((0, 0), (2, 0), (2, 2), (0, 2)); _f.circle((1, 1), 1); _f.poly((1, 0), (2, 1), (1, 2), (0, 1))
_alt = "A square with a circle inscribed in it, and a smaller square inscribed in the circle with its vertices at the points where the circle touches the outer square."
q("C16-B-014", T, "Ratio of the regions between a circle and its inscribed and circumscribed squares", "Easy",
  "Conceptual/application",
  r"A circle is inscribed in a square, and a smaller square is inscribed in the circle. What is the ratio of the area inside the larger square but outside the circle to the area inside the circle but outside the smaller square?",
  "MCQ",
  r"Let the radius be $1$. The larger square has side $2$ and area $4$; the smaller square has diagonal $2$ and area $2$; the circle has area $\pi$. The ratio is $(4 - \pi) : (\pi - 2)$.",
  "Mis-sizing the inner square, or reversing the order of the ratio.",
  "C16B-nested-squares-circles", "Three standard areas with one radius; the inner square via its diagonal is the only trap.",
  correct=r"$(4 - \pi) : (\pi - 2)$",
  distractors=[(r"$(\pi - 2) : (4 - \pi)$", "Writes the ratio in the reverse order."),
               (r"$(4 - \pi) : (\pi - 1)$", "Takes the inner square's side as the radius, so its area is $1$."),
               (r"$(4 - \pi) : \pi$", "Uses the whole circle as the second region, not subtracting the inner square.")],
  check=_c014, values=[(4 - pi) / (pi - 2), (pi - 2) / (4 - pi), (4 - pi) / (pi - 1), (4 - pi) / pi], cognitive="Understanding",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 015
def _c015():
    r = 10; arc = 44 - 2 * r
    theta = Rational(arc, r)
    return theta * r**2 / 2
q("C16-B-015", T, "Area of a sector from its perimeter and radius", "Easy",
  "Multi-step word problem",
  r"A fan-shaped piece of cardboard is a sector of a circle of radius $10$ cm. The total length of its boundary (the arc and the two radii) is $44$ cm. What is its area?",
  "MCQ",
  r"The arc is $44 - 2 \times 10 = 24$ cm. The area of a sector is $\frac{1}{2} \times \text{arc} \times \text{radius} = \frac{1}{2} \times 24 \times 10 = 120$ cm$^2$.",
  "Using the whole perimeter as the arc, or subtracting only one radius.",
  "C16B-sector-perimeter-area", "Two steps: arc from the perimeter, then the half-arc-times-radius rule.",
  correct=r"$120$ cm$^2$",
  distractors=[(r"$220$ cm$^2$", "Takes the whole perimeter $44$ as the arc: $\\frac{1}{2} \\times 44 \\times 10$."),
               (r"$240$ cm$^2$", "Uses arc times radius without the half."),
               (r"$170$ cm$^2$", "Subtracts only one radius, taking the arc as $34$.")],
  check=_c015, values=[120, 220, 240, 170], cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    r = symbols('r', positive=True)
    A = r * (40 - 2 * r) / 2
    rc = solve(diff(A, r), r)[0]
    assert (40 - 2 * rc) / rc <= 2 * pi  # the sector angle is possible
    return A.subs(r, rc)
q("C16-B-016", T, "Largest sector area for a fixed perimeter", "Medium",
  "Casework/optimisation",
  r"A gardener has $40$ m of edging and wants to use all of it to enclose a flower bed shaped like a sector of a circle (the edging runs along both radii and the arc). What is the largest possible area of the bed, in m$^2$?",
  "TITA",
  r"With radius $r$, the arc is $40 - 2r$, so the area is $\frac{1}{2} r (40 - 2r) = r(20 - r)$. This is largest when $r = 10$, giving $10 \times 10 = 100$ m$^2$. The arc is then $20$ m, an angle of $2$ radians, which is a valid sector.",
  "Dropping the half in the sector area, or maximising with the arc taken as the whole perimeter.",
  "C16B-sector-perimeter-area", "An optimisation set up from the sector area rule; the maximum of $r(20 - r)$ by symmetry.",
  tita_answer=100, check=_c016, cognitive="Analysis",
  tita_traps=[(200, "Uses area $= r(40 - 2r)$ without the half."),
              (127, "Assumes the best shape is a full circle of circumference $40$, area $\\frac{400}{\\pi} \\approx 127$.")])

# ---------------------------------------------------------------- 017
def _c017():
    minutes = 20
    angle = Rational(360, 60) * minutes
    return 2 * P7 * 21 * angle / 360
q("C16-B-017", T, "Arc traced by the tip of a minute hand", "Easy",
  "Single-step computation",
  r"The minute hand of a tower clock is $21$ cm long. How far does its tip travel, in cm, between $9{:}00$ am and $9{:}20$ am the same morning? (Take $\pi = \frac{22}{7}$.)",
  "TITA",
  r"In $20$ minutes the minute hand turns $\frac{20}{60} \times 360^\circ = 120^\circ$. The tip moves along an arc of length $\frac{120}{360} \times 2 \times \frac{22}{7} \times 21 = \frac{1}{3} \times 132 = 44$ cm.",
  "Using $\\pi r$ instead of $2\\pi r$ for the circumference, or giving the whole circumference.",
  "C16B-arc-length-rotation", "One fraction of a circumference.",
  tita_answer=44, check=_c017, cognitive="Application",
  tita_traps=[(22, "Uses $\\pi r$ as the circumference."),
              (132, "Gives the full circumference.")])

# ---------------------------------------------------------------- 018
def _c018():
    a = _seg_int(28, 28 * cos(pi / 4))
    return simplify(a.subs(pi, P7))
_f = Fig()
_f.circle((0, 0), 28)
_O = _f.pt("O", 0, 0); _P = _f.pt("P", 28, 0); _Q = _f.pt("Q", 0, 28)
_f.seg(_O, _P); _f.seg(_O, _Q); _f.seg(_P, _Q); _f.right_angle(_P, _O, _Q)
_f.text((14, -3.5), "28 cm")
_alt = "A circle with centre O and radius 28 cm. Radii OP and OQ are perpendicular, and the chord PQ cuts off the smaller segment of the circle."
q("C16-B-018", T, "Area of a minor segment for a right-angle chord", "Easy",
  "Multi-step word problem",
  r"In a circle with centre $O$ and radius $28$ cm, the radii $OP$ and $OQ$ are perpendicular. What is the area of the smaller region bounded by the chord $PQ$ and the arc $PQ$? (Take $\pi = \frac{22}{7}$.)",
  "MCQ",
  r"The quarter sector $OPQ$ has area $\frac{1}{4} \times \frac{22}{7} \times 784 = 616$ cm$^2$, and triangle $OPQ$ has area $\frac{1}{2} \times 28 \times 28 = 392$ cm$^2$. The segment is $616 - 392 = 224$ cm$^2$.",
  "Stopping at the sector or the triangle, or computing the larger segment.",
  "C16B-segment-area", "Sector minus triangle, both standard.",
  correct=r"$224$ cm$^2$",
  distractors=[(r"$616$ cm$^2$", "Gives the area of the sector."),
               (r"$392$ cm$^2$", "Gives the area of the triangle."),
               (r"$2{,}240$ cm$^2$", "Gives the larger segment, $2{,}464 - 224$.")],
  check=_c018, values=[224, 616, 392, 2240], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 019
def _c019():
    return _seg_int(6, 6 * cos(pi / 3))
q("C16-B-019", T, "Area of a minor segment for a 120 degree chord", "Medium",
  "Multi-step word problem",
  r"A circular table top of radius $6$ dm has a straight edge cut off along a chord that subtends an angle of $120^\circ$ at the centre. What is the area of the piece that was cut off?",
  "MCQ",
  r"The sector of $120^\circ$ has area $\frac{1}{3} \times 36\pi = 12\pi$. The triangle formed by the chord and two radii has area $\frac{1}{2} \times 6 \times 6 \times \sin 120^\circ = 9\sqrt{3}$. The cut-off piece is the segment, $12\pi - 9\sqrt{3}$ sq dm.",
  "Forgetting the half in the triangle area, or using the wrong fraction of the circle for the sector.",
  "C16B-segment-area", "Sector minus triangle with a non-right angle; needs the sine area formula or the triangle's height.",
  correct=r"$12\pi - 9\sqrt{3}$ sq dm",
  distractors=[(r"$12\pi - 18\sqrt{3}$ sq dm", "Uses $6 \\times 6 \\times \\sin 120^\\circ$ for the triangle, without the half."),
               (r"$6\pi - 9\sqrt{3}$ sq dm", "Takes the angle as $60^\\circ$ for the sector, so the sector is $6\\pi$."),
               (r"$24\pi - 9\sqrt{3}$ sq dm", "Uses $\\frac{\\theta}{180}$ in place of $\\frac{\\theta}{360}$ for the sector.")],
  check=_c019, values=[12 * pi - 9 * sqrt(3), 12 * pi - 18 * sqrt(3), 6 * pi - 9 * sqrt(3), 24 * pi - 9 * sqrt(3)], cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    return _lens(6, 6, 6)
_f = Fig()
_f.circle((0, 0), 6); _f.circle((6, 0), 6)
_f.pt("O", 0, 0, offset=(-1, 0)); _f.pt("O'", 6, 0, offset=(1, 0))
_f.pt("P", 3, 3 * _m.sqrt(3)); _f.pt("Q", 3, -3 * _m.sqrt(3))
_f.seg((0, 0), (6, 0), dashed=True)
_alt = "Two equal circles with centres O and O', each passing through the other's centre. They cross at P and Q, and the overlap is a lens between P and Q."
q("C16-B-020", T, "Common area of two equal circles through each other's centres", "Medium",
  "Multi-step word problem",
  r"Two circles, each of radius $6$ cm, are drawn so that each passes through the centre of the other. What is the area of the region common to both circles?",
  "MCQ",
  r"With centres $O, O'$ and crossing points $P, Q$, triangles $OPO'$ and $OQO'$ are equilateral, so $\angle POQ = 120^\circ$. The common region is two segments of $120^\circ$, each $12\pi - 9\sqrt{3}$. Total $24\pi - 18\sqrt{3}$ cm$^2$.",
  "Counting only one segment, using $60^\\circ$ sectors, or taking the rhombus area as the full product of its diagonals.",
  "C16B-lens-two-circles", "Find the $120^\\circ$ angle from equilateral triangles, then double a segment.",
  correct=r"$24\pi - 18\sqrt{3}$ cm$^2$",
  distractors=[(r"$12\pi - 9\sqrt{3}$ cm$^2$", "Counts only one of the two segments."),
               (r"$12\pi - 18\sqrt{3}$ cm$^2$", "Uses $60^\\circ$ sectors, $2 \\times (6\\pi - 9\\sqrt{3})$."),
               (r"$24\pi - 36\sqrt{3}$ cm$^2$", "Subtracts the rhombus $OPO'Q$ as $6 \\times 6\\sqrt{3}$, the product of its diagonals without the half.")],
  check=_c020, values=[24 * pi - 18 * sqrt(3), 12 * pi - 9 * sqrt(3), 12 * pi - 18 * sqrt(3), 24 * pi - 36 * sqrt(3)], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 021
def _c021():
    return _lens(6, 6 * sqrt(3), 12)
_f = Fig()
_f.circle((0, 0), 6); _f.circle((12, 0), 6 * _m.sqrt(3))
_f.pt("O", 0, 0, offset=(-1, 0)); _f.pt("O'", 12, 0, offset=(1, 0))
_f.pt("P", 3, 3 * _m.sqrt(3)); _f.pt("Q", 3, -3 * _m.sqrt(3))
_f.seg((0, 0), (12, 0), dashed=True); _f.text((8.6, -1.3), "12 cm")
_alt = "A circle with centre O, radius 6 cm, and a larger circle with centre O', radius 6 root 3 cm, with OO' = 12 cm. The circles cross at P and Q and overlap in a lens."
q("C16-B-021", T, "Common area of two unequal intersecting circles", "Difficult",
  "Multi-step word problem",
  r"Two circles with centres $O$ and $O'$ have radii $6$ cm and $6\sqrt{3}$ cm, and $OO' = 12$ cm. What is the area of the region common to both circles?",
  "MCQ",
  r"Let the circles cross at $P$ and $Q$. Since $6^2 + (6\sqrt{3})^2 = 144 = 12^2$, $\angle OPO' = 90^\circ$, and in this right triangle $\angle POO' = 60^\circ$, $\angle PO'O = 30^\circ$. So the common region subtends $120^\circ$ at $O$ and $60^\circ$ at $O'$. It equals sector at $O$ plus sector at $O'$ minus kite $OPO'Q$: $12\pi + 18\pi - 2 \times \frac{1}{2} \times 6 \times 6\sqrt{3} = 30\pi - 36\sqrt{3}$ cm$^2$.",
  "Swapping the angles at the two centres, using half-angles for the sectors, or counting only half the kite.",
  "C16B-lens-two-circles", "Must spot the right angle at P, then combine two different sectors and a kite.",
  correct=r"$30\pi - 36\sqrt{3}$ cm$^2$",
  distractors=[(r"$42\pi - 36\sqrt{3}$ cm$^2$", "Swaps the angles, taking $60^\\circ$ at $O$ and $120^\\circ$ at $O'$: $6\\pi + 36\\pi$."),
               (r"$30\pi - 18\sqrt{3}$ cm$^2$", "Subtracts only one of the two right triangles that make up the kite."),
               (r"$15\pi - 18\sqrt{3}$ cm$^2$", "Uses the half-angles $60^\\circ$ and $30^\\circ$ for the sectors and one right triangle.")],
  check=_c021, values=[30 * pi - 36 * sqrt(3), 42 * pi - 36 * sqrt(3), 30 * pi - 18 * sqrt(3), 15 * pi - 18 * sqrt(3)], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 022
def _c022():
    lens = _lens(14, 14, 14 * sqrt(2))
    return simplify(lens.subs(pi, P7))
_f = Fig()
_f.poly((0, 0), (14, 0), (14, 14), (0, 14))
_f.pt("P", 0, 0); _f.pt("Q", 14, 0); _f.pt("R", 14, 14); _f.pt("S", 0, 14)
_f.arc((0, 0), 14, 0, 90); _f.arc((14, 14), 14, 180, 270)
_f.text((7, -1.6), "14 cm")
_alt = "Square PQRS of side 14 cm with two quarter-circle arcs: one centred at P from Q to S, and one centred at R from S to Q. The arcs enclose a leaf shape along diagonal QS."
q("C16-B-022", T, "Leaf-shaped overlap of two quarter circles in a square", "Medium",
  "Conceptual/application",
  r"$PQRS$ is a square of side $14$ cm. With centre $P$ and radius $14$ cm an arc is drawn from $Q$ to $S$ inside the square, and with centre $R$ and the same radius an arc is drawn from $S$ to $Q$ inside the square. What is the area of the leaf-shaped region enclosed between the two arcs? (Take $\pi = \frac{22}{7}$.)",
  "MCQ",
  r"The two quarter circles together cover the square once and the leaf twice, so leaf $= 2 \times \frac{1}{4}\pi(14)^2 - 14^2 = 2 \times 154 - 196 = 112$ cm$^2$. (Equivalently, two segments of $90^\circ$, each $154 - 98 = 56$.)",
  "Taking a single segment, or giving the part of the square outside the leaf.",
  "C16B-quarter-circle-leaf", "The overlap-counting insight avoids splitting into segments.",
  correct=r"$112$ cm$^2$",
  distractors=[(r"$56$ cm$^2$", "Gives only one of the two segments that make up the leaf."),
               (r"$84$ cm$^2$", "Gives the part of the square outside the leaf, $196 - 112$."),
               (r"$42$ cm$^2$", "Gives the square minus one quarter circle, $196 - 154$.")],
  check=_c022, values=[112, 56, 84, 42], cognitive="Understanding",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 023
def _c023():
    r = 7
    V = [(0, 0), (14, 0), (7, 7 * sqrt(3))]
    straight = sum(sqrt((V[i][0] - V[i - 1][0])**2 + (V[i][1] - V[i - 1][1])**2) for i in range(3))
    wrap = sum(pi - _vertex_angle(V, i) for i in range(3))   # band turns through pi minus the interior angle
    return simplify((straight + r * wrap).subs(pi, P7))
q("C16-B-023", T, "Length of a band wrapped around three touching pipes", "Medium",
  "Multi-step word problem",
  r"Three identical pipes, each with a circular cross-section of radius $7$ cm, are stacked so that each touches the other two, and a tight band is wrapped once around all three. What is the length of the band, in cm? (Take $\pi = \frac{22}{7}$.)",
  "TITA",
  r"The band has three straight parts, each equal to the distance between two centres, $14$ cm, totalling $42$ cm. On each pipe it wraps through $180^\circ - 60^\circ = 120^\circ$, and the three arcs together make one full circle: $2 \times \frac{22}{7} \times 7 = 44$ cm. Total $42 + 44 = 86$ cm.",
  "Leaving out the curved parts, or taking a full circumference on each pipe.",
  "C16B-belt-around-circles", "Straight parts plus arcs, with the insight that the arcs total one circumference.",
  tita_answer=86, check=_c023, cognitive="Application",
  tita_traps=[(42, "Counts only the straight parts."),
              (174, "Adds a full circumference for every pipe: $42 + 3 \\times 44$.")])

# ---------------------------------------------------------------- 024
def _c024():
    r1, r2, d = 8, 2, 12
    # tangent points by direct computation: normal direction n with n . (O2 - O1) = r1 - r2
    cphi = Rational(r1 - r2, d)
    phi = acos(cphi)
    P1 = (r1 * cos(phi), r1 * sin(phi)); P2 = (d + r2 * cos(phi), r2 * sin(phi))
    L = sqrt((P1[0] - P2[0])**2 + (P1[1] - P2[1])**2)
    big_arc = r1 * (2 * pi - 2 * phi)     # from angle phi round the back to -phi
    small_arc = r2 * (2 * phi)
    return nsimplify(simplify(2 * L + big_arc + small_arc), [pi, sqrt(3)])
_f = Fig()
_f.circle((0, 0), 8, dashed=True); _f.circle((12, 0), 2, dashed=True)
_c, _s = 0.5, _m.sqrt(3) / 2
_f.seg((8 * _c, 8 * _s), (12 + 2 * _c, 2 * _s)); _f.seg((8 * _c, -8 * _s), (12 + 2 * _c, -2 * _s))
_f.arc((0, 0), 8, 60, 300); _f.arc((12, 0), 2, -60, 60)
_f.pt("O", 0, 0, offset=(0, -1)); _f.pt("O'", 12, 0, offset=(0, -1))
_f.seg((0, 0), (12, 0), dashed=True); _f.text((4.5, 1.0), "12 cm")
_alt = "Two pulleys with centres O and O', 12 cm apart, of radii 8 cm and 2 cm, joined by an open belt made of two straight tangent pieces and the arcs of each pulley that the belt wraps around."
q("C16-B-024", T, "Length of an open belt around two unequal pulleys", "Difficult",
  "Multi-step word problem",
  r"Two pulleys of radii $8$ cm and $2$ cm have their centres $12$ cm apart. A taut belt goes around both pulleys without crossing itself (an open belt). What is the length of the belt?",
  "MCQ",
  r"Each straight part is a direct common tangent: $\sqrt{12^2 - (8 - 2)^2} = \sqrt{108} = 6\sqrt{3}$, so the two give $12\sqrt{3}$. The radius difference $6$ is half of $12$, so each straight part makes $30^\circ$ with the line of centres, and the radii to the points of contact make $60^\circ$ with it. The belt wraps $360^\circ - 120^\circ = 240^\circ$ of the large pulley and $120^\circ$ of the small one: $\frac{2}{3} \times 16\pi + \frac{1}{3} \times 4\pi = \frac{32\pi}{3} + \frac{4\pi}{3} = 12\pi$. Total $12\pi + 12\sqrt{3}$ cm.",
  "Treating each pulley as half-wrapped, or swapping which pulley gets the larger arc.",
  "C16B-belt-around-circles", "Combines a direct tangent with the wrap angles found from a 30-60-90 triangle.",
  correct=r"$12\pi + 12\sqrt{3}$ cm",
  distractors=[(r"$10\pi + 12\sqrt{3}$ cm", "Takes a half circumference on each pulley: $8\\pi + 2\\pi$."),
               (r"$8\pi + 12\sqrt{3}$ cm", "Swaps the wrap angles: $120^\\circ$ on the large pulley and $240^\\circ$ on the small one, $\\frac{16\\pi}{3} + \\frac{8\\pi}{3}$."),
               (r"$12\pi + 6\sqrt{3}$ cm", "Counts only one straight part of the belt.")],
  check=_c024, values=[12 * pi + 12 * sqrt(3), 10 * pi + 12 * sqrt(3), 8 * pi + 12 * sqrt(3), 12 * pi + 6 * sqrt(3)], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 025
def _c025():
    R, r = 35, 7
    # spin relative to the line of centres from the contact arc rolled, plus one turn for orbiting the drum once
    spin_from_rolling = (2 * pi * R) / r          # radians
    orbit = 2 * pi
    return simplify((spin_from_rolling + orbit) / (2 * pi))
q("C16-B-025", T, "Turns made by a wheel rolling once around a fixed drum", "Medium",
  "Conceptual/application",
  r"A fixed circular drum has radius $35$ cm. A small wheel of radius $7$ cm rolls without slipping around the outside of the drum, always touching it, and goes once around the drum until it first returns to its starting position. How many complete turns does the wheel make about its own centre?",
  "MCQ",
  r"The wheel's centre moves on a circle of radius $35 + 7 = 42$ cm, a path of length $84\pi$. Rolling without slipping, the wheel makes one turn for every $2\pi \times 7 = 14\pi$ of travel by its centre, so it makes $\frac{84\pi}{14\pi} = 6$ turns. Counting only $\frac{35}{7} = 5$ misses the extra turn that comes from going once around the drum.",
  "Dividing the circumference of the drum by that of the wheel, which ignores the turn from circling the drum.",
  "C16B-rolling-coin-rotations", "Conceptual trap: the count is $\\frac{R + r}{r}$, not $\\frac{R}{r}$.",
  correct=r"$6$",
  distractors=[(r"$5$", "Divides the circumference of the drum by that of the wheel: $\\frac{35}{7}$."),
               (r"$7$", "Uses the path of the wheel's far edge, radius $35 + 14$: $\\frac{49}{7}$."),
               (r"$4$", "Uses $\\frac{R - r}{r} = \\frac{28}{7}$, the count for rolling inside a ring.")],
  check=_c025, values=[6, 5, 7, 4], cognitive="Understanding")

# ---------------------------------------------------------------- 026
def _c026():
    a, rho = 10, 3
    V = [(a * cos(k * pi / 3), a * sin(k * pi / 3)) for k in range(6)]
    tot = 0
    for k in range(6):
        A, B = V[k], V[(k + 1) % 6]
        nang = (2 * k + 1) * pi / 6               # outward normal of edge k
        n = (cos(nang), sin(nang))
        A1 = (A[0] + rho * n[0], A[1] + rho * n[1]); B1 = (B[0] + rho * n[0], B[1] + rho * n[1])
        tot += (A1[0] * B1[1] - B1[0] * A1[1]) / 2   # straight piece, Green's theorem
        C = B; a0 = nang; a1 = nang + pi / 3          # arc around vertex k+1
        tot += (rho * C[0] * (sin(a1) - sin(a0)) - rho * C[1] * (cos(a1) - cos(a0)) + rho**2 * (a1 - a0)) / 2
    return nsimplify(simplify(tot), [pi, sqrt(3)])
q("C16-B-026", T, "Area enclosed by the path of a coin's centre around a regular hexagon", "Difficult",
  "Conceptual/application",
  r"A regular hexagonal plate has side $10$ cm. A coin of radius $3$ cm is rolled once around the outside of the plate, always touching its edge, and returns to its starting point. What is the area of the region enclosed by the path traced by the centre of the coin?",
  "MCQ",
  r"Along each side the centre runs parallel to the side at distance $3$, adding a $10 \times 3$ strip: $6 \times 30 = 180$. At each corner it swings on an arc of radius $3$ through the exterior angle $60^\circ$, and six such sectors make one full circle, $9\pi$. The hexagon itself is $6 \times \frac{\sqrt{3}}{4} \times 100 = 150\sqrt{3}$. Total $150\sqrt{3} + 180 + 9\pi$ cm$^2$.",
  "Using the interior angle at the corners, or mis-sizing the strips or the hexagon.",
  "C16B-rolling-around-polygon", "Needs the decomposition into polygon, strips and corner sectors, with the exterior angles summing to $360^\\circ$.",
  correct=r"$150\sqrt{3} + 180 + 9\pi$ cm$^2$",
  distractors=[(r"$150\sqrt{3} + 180 + 18\pi$ cm$^2$", "Uses the interior angle $120^\\circ$ for each corner sector."),
               (r"$75\sqrt{3} + 180 + 9\pi$ cm$^2$", "Takes the hexagon's area as $\\frac{3\\sqrt{3}}{4}a^2$, half its true value."),
               (r"$150\sqrt{3} + 360 + 9\pi$ cm$^2$", "Uses the coin's diameter $6$ as the width of each strip.")],
  check=_c026, values=[150 * sqrt(3) + 180 + 9 * pi, 150 * sqrt(3) + 180 + 18 * pi, 75 * sqrt(3) + 180 + 9 * pi, 150 * sqrt(3) + 360 + 9 * pi],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 027
def _c027():
    w = h = 7; L = 14
    num = _tether_numeric(w, h, L)
    exact = (Rational(3, 4) * pi * L**2 + Rational(1, 4) * pi * (L - w)**2 + Rational(1, 4) * pi * (L - h)**2).subs(pi, P7)
    assert abs(num - float(exact)) / float(exact) < 0.005, (num, exact)
    return exact
q("C16-B-027", T, "Grazing area for a rope tied at the corner of a square shed", "Medium",
  "Casework/optimisation",
  r"A square shed of side $7$ m stands in an open field. A goat is tied to one outer corner of the shed with a rope $14$ m long, and the shed blocks the rope, so the goat can reach a point only if the rope can go around the shed to it. What is the area of the region the goat can graze, in m$^2$? (Take $\pi = \frac{22}{7}$.)",
  "TITA",
  r"Away from the shed the goat sweeps $\frac{3}{4}$ of a circle of radius $14$: $\frac{3}{4} \times \frac{22}{7} \times 196 = 462$. Going along either side to the next corner leaves $14 - 7 = 7$ m of rope, which sweeps a quarter circle of radius $7$ beside the shed: $2 \times \frac{1}{4} \times \frac{22}{7} \times 49 = 77$. These two quarter circles meet only at the far corner, so the total is $462 + 77 = 539$ m$^2$.",
  "Ignoring the extra area reached when the rope bends around the shed's corners.",
  "C16B-tethered-animal-shed", "Casework on where the rope bends, with a check that the wrap regions do not overlap.",
  tita_answer=539, check=_c027, cognitive="Analysis",
  tita_traps=[(462, "Counts only the three-quarter circle."),
              (616, "Takes a full circle of radius $14$, ignoring the shed.")])

# ---------------------------------------------------------------- 028
def _c028():
    w, h, L = 10, 6, 14
    num = _tether_numeric(w, h, L)
    exact = Rational(3, 4) * pi * L**2 + Rational(1, 4) * pi * (L - w)**2 + Rational(1, 4) * pi * (L - h)**2
    assert abs(num - float(exact)) / float(exact) < 0.005, (num, exact)
    return exact
q("C16-B-028", T, "Grazing area for a rope tied at the corner of a rectangular shed", "Medium",
  "Casework/optimisation",
  r"A rectangular shed measuring $10$ m by $6$ m stands in an open field. A horse is tied to one outer corner of the shed with a rope $14$ m long. The rope cannot pass through the shed but can bend around its corners. What is the area of the region the horse can reach?",
  "MCQ",
  r"Away from the shed the horse covers $\frac{3}{4}\pi(14)^2 = 147\pi$. Along the $10$ m side the rope reaches the next corner with $4$ m left, sweeping a quarter circle $\frac{1}{4}\pi(4)^2 = 4\pi$. Along the $6$ m side it has $8$ m left, sweeping $\frac{1}{4}\pi(8)^2 = 16\pi$. Neither leftover rope reaches the far corner ($4 < 6$ and $8 < 10$), and the two quarter circles lie behind different sides, so they do not overlap. Total $147\pi + 4\pi + 16\pi = 167\pi$ m$^2$.",
  "Missing one of the two bends around the shed, or treating the bend regions as semicircles.",
  "C16B-tethered-animal-shed", "Medium: the standard corner-tether casework, with two different leftover radii and a check that neither reaches the far corner.",
  correct=r"$167\pi$ m$^2$",
  distractors=[(r"$147\pi$ m$^2$", "Counts only the three-quarter circle and ignores bending around the corners."),
               (r"$163\pi$ m$^2$", "Includes the bend along the $6$ m side ($16\\pi$) but not the one along the $10$ m side."),
               (r"$187\pi$ m$^2$", "Takes each bend region as a semicircle: $147\\pi + 8\\pi + 32\\pi$.")],
  check=_c028, values=[167 * pi, 147 * pi, 163 * pi, 187 * pi], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 029
def _c029():
    R = 18; th = pi / 3
    x, r = symbols('x r', positive=True)
    s = solve([Eq(x * sin(th / 2), r), Eq(x + r, R)], [x, r], dict=True)[0]
    return simplify(pi * s[r]**2 / (th / (2 * pi) * pi * R**2))
_f = Fig()
_f.seg((0, 0), (18, 0)); _f.seg((0, 0), (9, 9 * _m.sqrt(3))); _f.arc((0, 0), 18, 0, 60)
_f.circle((12 * _m.cos(_m.pi / 6), 12 * _m.sin(_m.pi / 6)), 6)
_f.pt("O", 0, 0); _f.angle_mark((18, 0), (0, 0), (9, 9 * _m.sqrt(3)), "60^\\circ")
_f.text((5, -1.6), "18 cm")
_alt = "A sector with centre O, radius 18 cm and angle 60 degrees, with a circle inside it touching both bounding radii and the arc."
q("C16-B-029", T, "Ratio of a circle inscribed in a 60 degree sector to the sector", "Medium",
  "Multi-step word problem",
  r"A circle is drawn inside a sector of radius $18$ cm and angle $60^\circ$ so that it touches both bounding radii and the arc. What is the ratio of the area of the circle to the area of the sector?",
  "MCQ",
  r"The circle's centre lies on the bisector, at distance $d$ from the vertex with $d \sin 30^\circ = r$, so $d = 2r$. Touching the arc means $d + r = 18$, so $3r = 18$ and $r = 6$. The circle has area $36\pi$ and the sector $\frac{1}{6} \times 324\pi = 54\pi$. The ratio is $2 : 3$.",
  "Taking $r = d \\sin 30^\\circ$ with $d = 18$, or comparing with the whole circle instead of the sector.",
  "C16B-circle-inscribed-in-sector", "Set up the bisector distance, then compare two areas.",
  correct=r"$2 : 3$",
  distractors=[(r"$1 : 9$", "Compares the circle with the whole circle of radius $18$, not the sector."),
               (r"$1 : 3$", "Gives the ratio of the radii, $6 : 18$."),
               (r"$3 : 2$", "Takes the radius as $18 \\sin 30^\\circ = 9$: $81\\pi : 54\\pi$.")],
  check=_c029, values=[Rational(2, 3), Rational(1, 9), Rational(1, 3), Rational(3, 2)], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 030
def _c030():
    R = 36; half = pi / 6
    x1, r1, x2, r2 = symbols('x1 r1 x2 r2', positive=True)
    s1 = solve([Eq(x1 * sin(half), r1), Eq(x1 + r1, R)], [x1, r1], dict=True)[0]
    s2 = solve([Eq(x2 * sin(half), r2), Eq(x2 + r2, s1[x1] - s1[r1])], [x2, r2], dict=True)[0]
    return s2[r2]
q("C16-B-030", T, "Second circle between the inscribed circle of a sector and its vertex", "Difficult",
  "Multi-step word problem",
  r"A sector has radius $36$ cm and angle $60^\circ$. Circle $\omega_1$ lies inside the sector and touches both bounding radii and the arc. A smaller circle $\omega_2$ lies between $\omega_1$ and the vertex of the sector and touches both bounding radii and $\omega_1$. What is the radius of $\omega_2$, in cm?",
  "TITA",
  r"A circle touching both radii of a $60^\circ$ angle has its centre on the bisector at distance $d = \frac{r}{\sin 30^\circ} = 2r$ from the vertex. For $\omega_1$: $2r_1 + r_1 = 36$, so $r_1 = 12$ and its centre is $24$ from the vertex; its nearest point to the vertex is $24 - 12 = 12$ away. For $\omega_2$: $2r_2 + r_2 = 12$, so $r_2 = 4$ cm.",
  "Assuming the second circle is half the first, or forgetting that its centre is $2r_2$ from the vertex.",
  "C16B-circle-inscribed-in-sector", "Two stages of the same bisector relation, with the second constrained by the first circle.",
  tita_answer=4, check=_c030, cognitive="Analysis", exams=CX,
  tita_traps=[(6, "Assumes the second circle has half the radius of the first."),
              (12, "Reports the gap $24 - 12$ between the vertex and the first circle.")])

# ---------------------------------------------------------------- 031
def _c031():
    PQ, QR = 10, 6
    return pi * (PQ + QR) / 2 + pi * PQ / 2 + pi * QR / 2
q("C16-B-031", T, "Perimeter of the region between three semicircles on one line", "Easy",
  "Conceptual/application",
  r"Points $P$, $Q$ and $R$ lie on a straight line in that order, with $PQ = 10$ cm and $QR = 6$ cm. Semicircles are drawn on $PR$, $PQ$ and $QR$ as diameters, all on the same side of the line. What is the perimeter of the region inside the largest semicircle but outside the two smaller ones?",
  "MCQ",
  r"The boundary is made of the three semicircular arcs: $\frac{\pi \times 16}{2} + \frac{\pi \times 10}{2} + \frac{\pi \times 6}{2} = 8\pi + 5\pi + 3\pi = 16\pi$ cm. Note that the two small arcs together equal the large arc.",
  "Counting only the outer arc, or using diameters as radii.",
  "C16B-arbelos-semicircles", "Three semicircular arcs; the insight is that the small arcs sum to the large one.",
  correct=r"$16\pi$ cm",
  distractors=[(r"$8\pi$ cm", "Counts only the large arc."),
               (r"$32\pi$ cm", "Uses each diameter as a radius in $\\pi r$."),
               (r"$24\pi$ cm", "Uses full circumferences for the two small circles: $8\\pi + 10\\pi + 6\\pi$.")],
  check=_c031, values=[16 * pi, 8 * pi, 32 * pi, 24 * pi], cognitive="Understanding")

# ---------------------------------------------------------------- 032
def _c032():
    q_ = symbols('q', positive=True)
    # P = (0,0), R = (20,0), Q = (q,0); T = (q, 8) lies on the circle on diameter PR
    qs = solve(Eq((q_ - 10)**2 + 8**2, 10**2), q_)
    areas = set()
    for qq in qs:
        PQ, QR = qq, 20 - qq
        areas.add(simplify(pi / 8 * (20**2 - PQ**2 - QR**2)))
    assert len(areas) == 1
    return areas.pop()
_f = Fig()
_f.seg((0, 0), (20, 0))
_f.arc((10, 0), 10, 0, 180); _f.arc((8, 0), 8, 0, 180); _f.arc((18, 0), 2, 0, 180)
_f.pt("P", 0, 0, offset=(0, -1)); _f.pt("Q", 16, 0, offset=(0, -1)); _f.pt("R", 20, 0, offset=(0, -1)); _f.pt("T", 16, 8, offset=(0, 1))
_f.seg((16, 0), (16, 8)); _f.right_angle((20, 0), (16, 0), (16, 8))
_f.text((17.6, 4), "8 cm")
_alt = "Segment PR of length 20 cm with a point Q on it. Semicircles on PR, PQ and QR are drawn on the same side. The perpendicular to PR at Q meets the largest semicircle at T, and QT = 8 cm."
q("C16-B-032", T, "Area between three semicircles found from a perpendicular height", "Difficult",
  "Conceptual/application",
  r"Point $Q$ lies on segment $PR$, where $PR = 20$ cm. Semicircles are drawn on $PR$, $PQ$ and $QR$ as diameters, all on the same side of $PR$. The line through $Q$ perpendicular to $PR$ meets the largest semicircle at $T$, and $QT = 8$ cm. What is the area of the region inside the largest semicircle but outside the two smaller ones?",
  "MCQ",
  r"Let $PQ = a$ and $QR = b$, so $a + b = 20$. The angle in a semicircle gives $\angle PTR = 90^\circ$, so $QT^2 = ab = 64$. The region's area is $\frac{\pi}{8}\left((a+b)^2 - a^2 - b^2\right) = \frac{\pi}{8} \times 2ab = \frac{\pi \times 64}{4} = 16\pi$ cm$^2$, the area of a circle with diameter $QT$.",
  "Using $\\pi r^2$ for a semicircle, or taking the region as a semicircle or full circle on $QT$ with the wrong factor.",
  "C16B-arbelos-semicircles", "Needs $QT^2 = ab$ and the algebra that collapses the area to $\\frac{\\pi}{4}QT^2$ without finding $a$ and $b$.",
  correct=r"$16\pi$ cm$^2$",
  distractors=[(r"$32\pi$ cm$^2$", "Uses $\\pi r^2$ instead of $\\frac{1}{2}\\pi r^2$ for each semicircle."),
               (r"$64\pi$ cm$^2$", "Takes the area as a circle of radius $QT$."),
               (r"$8\pi$ cm$^2$", "Takes the area as a semicircle on diameter $QT$.")],
  check=_c032, values=[16 * pi, 32 * pi, 64 * pi, 8 * pi], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 033
def _c033():
    R, x = symbols('R x', positive=True)
    r2 = 6
    # semicircle centre O = (0, 0) on the line y = 0; omega_1 centre (0, R/2), radius R/2; omega_2 centre (x, r2)
    sols = solve([Eq(x**2 + r2**2, (R - r2)**2), Eq(x**2 + (R / 2 - r2)**2, (R / 2 + r2)**2)], [R, x], dict=True)
    good = [d[R] for d in sols if d[R] > 2 * r2]
    assert len(good) == 1
    return good[0]
_f = Fig()
_f.seg((-24, 0), (24, 0)); _f.arc((0, 0), 24, 0, 180)
_f.circle((0, 12), 12); _f.circle((12 * _m.sqrt(2), 6), 6)
_f.pt("P", -24, 0, offset=(0, -1)); _f.pt("Q", 24, 0, offset=(0, -1)); _f.pt("O", 0, 0, offset=(0, -1))
_f.text((0, 12), "\u03c91"); _f.text((12 * _m.sqrt(2), 6), "\u03c92")
_alt = "A semicircle on diameter PQ with centre O. Circle omega 1 touches PQ at O and touches the arc. A smaller circle omega 2 touches PQ, the arc and omega 1."
q("C16-B-033", T, "Radius of a semicircle from a circle wedged beside its inscribed circle", "Medium",
  "Inverse/parameter",
  r"A semicircle has diameter $PQ$ and centre $O$. Inside it, circle $\omega_1$ touches $PQ$ at $O$ and also touches the arc of the semicircle. A second circle $\omega_2$, of radius $6$ cm, lies inside the semicircle, touches $PQ$, touches the arc of the semicircle, and touches $\omega_1$ externally. What is the radius of the semicircle, in cm?",
  "TITA",
  r"Let the semicircle have radius $R$, so $\omega_1$ has radius $\frac{R}{2}$ and centre $(0, \frac{R}{2})$ with $O$ as origin. Let $\omega_2$ have centre $(x, 6)$. Touching the arc internally: $x^2 + 36 = (R - 6)^2$. Touching $\omega_1$ externally: $x^2 + \left(\frac{R}{2} - 6\right)^2 = \left(\frac{R}{2} + 6\right)^2$, so $x^2 = 12R$. Then $12R + 36 = R^2 - 12R + 36$, giving $R = 24$ cm.",
  "Reporting the radius of the first circle, or slipping in $(a + b)^2 - (a - b)^2 = 4ab$.",
  "C16B-circles-in-semicircle", "Two tangency conditions in coordinates, then eliminating the unknown horizontal position.",
  tita_answer=24, check=_c033, cognitive="Analysis", exams=CX,
  tita_traps=[(12, "Reports the radius of $\\omega_1$, which is half the semicircle's radius."),
              (18, "Expands the second condition as $x^2 = 2 \\times \\frac{R}{2} \\times 6 = 6R$ instead of $12R$, giving $R^2 = 18R$.")],
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 034
def _c034():
    p, q_, r = symbols('p q r', positive=True)
    sol = solve([Eq(p + q_, 10), Eq(q_ + r, 14), Eq(p + r, 16)], [p, q_, r], dict=True)[0]
    return min(sol.values())
q("C16-B-034", T, "Radii of three mutually touching discs from the distances between their centres", "Easy",
  "Multi-step word problem",
  r"Three circular discs with centres $P$, $Q$ and $R$ lie flat on a table without overlapping, and each disc touches the other two externally. The distances between the centres are $PQ = 10$ cm, $QR = 14$ cm and $PR = 16$ cm. What is the radius of the smallest disc?",
  "MCQ",
  r"Touching externally, each pair of centres is one sum of radii apart: $p + q = 10$, $q + r = 14$, $p + r = 16$. Adding, $2(p + q + r) = 40$, so $p + q + r = 20$. Then $q = 20 - 16 = 4$, $p = 20 - 14 = 6$ and $r = 20 - 10 = 10$. The smallest radius is $4$ cm.",
  "Assuming the two closest discs are equal, or subtracting the shortest distance from the total, which gives the largest radius.",
  "C16B-mutually-touching-radii", "One linear system solved by adding all three equations.",
  correct=r"$4$ cm",
  distractors=[(r"$5$ cm", "Assumes the two discs at $P$ and $Q$ are equal and halves $PQ = 10$."),
               (r"$10$ cm", "Subtracts the shortest distance from the total, $20 - 10$, which gives the largest radius."),
               (r"$20$ cm", "Stops at the sum of the three radii, half of $10 + 14 + 16$.")],
  check=_c034, values=[4, 5, 10, 20], cognitive="Application")

# ---------------------------------------------------------------- 035
def _c035():
    vals = set()
    for r in (3, 5, 9):
        R2 = r**2 + 12**2          # outer circle meets the tangent line y = r at x = +-12
        vals.add(R2 - r**2)
    assert len(vals) == 1
    return vals.pop()
q("C16-B-035", T, "Area of a ring from a chord of the outer circle touching the inner circle", "Easy",
  "Conceptual/application",
  r"Two circles have the same centre. A chord of the larger circle touches the smaller circle and has length $24$ cm. The area of the ring between the circles is $k\pi$ cm$^2$. What is $k$?",
  "TITA",
  r"The radius of the small circle to the point of contact is perpendicular to the chord and bisects it. So $R^2 - r^2 = 12^2 = 144$, and the ring has area $\pi(R^2 - r^2) = 144\pi$. Hence $k = 144$, whatever the individual radii.",
  "Using the whole chord instead of half of it.",
  "C16B-concentric-annulus", "One right triangle; the radii themselves are not needed.",
  tita_answer=144, check=_c035, cognitive="Understanding",
  tita_traps=[(576, "Uses the full chord: $24^2$.")])

# ---------------------------------------------------------------- 036
def _c036():
    R, r = symbols('R r', positive=True)
    s = solve([Eq(2 * P7 * (R - r), 44), Eq(P7 * (R**2 - r**2), 2926)], [R, r], dict=True)[0]
    return s[r]
q("C16-B-036", T, "Inner radius of a circular track from its area and the difference of circumferences", "Medium",
  "Inverse/parameter",
  r"A circular running track lies between two concentric circles. The outer boundary is $44$ m longer than the inner boundary, and the area of the track is $2926$ m$^2$. What is the radius of the inner boundary, in metres? (Take $\pi = \frac{22}{7}$.)",
  "TITA",
  r"$2\pi(R - r) = 44$ gives $R - r = 7$. Then $\pi(R - r)(R + r) = 2926$ gives $\frac{22}{7} \times 7 \times (R + r) = 2926$, so $R + r = 133$. Hence $r = \frac{133 - 7}{2} = 63$ m.",
  "Reporting the outer radius, or taking the difference of circumferences as $\\pi(R - r)$.",
  "C16B-concentric-annulus", "Two equations, solved by factoring the ring area.",
  tita_answer=63, check=_c036, cognitive="Application",
  tita_traps=[(70, "Reports the outer radius $R$."),
              (133, "Reports $R + r$.")])

# ---------------------------------------------------------------- 037
def _c037():
    O = Point(0, 0)
    side = Line(Point(20, 0), Point(0, 15))
    r = side.distance(O)
    return pi * r**2
q("C16-B-037", T, "Area of the circle inscribed in a rhombus", "Medium",
  "Multi-step word problem",
  r"A rhombus has diagonals of $30$ cm and $40$ cm. A circle is drawn inside it touching all four sides. What is the area of the circle?",
  "MCQ",
  r"The side is $\sqrt{15^2 + 20^2} = 25$ cm and the area is $\frac{1}{2} \times 30 \times 40 = 600$ cm$^2$. The circle's centre is where the diagonals meet, and the area equals $\frac{1}{2} \times \text{perimeter} \times r = 50r$, so $r = 12$ cm. The circle's area is $144\pi$ cm$^2$.",
  "Using the full perimeter with $r$, the product of diagonals as area, or half a diagonal as the radius.",
  "C16B-incircle-quadrilateral", "Area two ways: from diagonals and from the inradius.",
  correct=r"$144\pi$ cm$^2$",
  distractors=[(r"$36\pi$ cm$^2$", "Uses area $= \\text{perimeter} \\times r$, so $r = 6$."),
               (r"$576\pi$ cm$^2$", "Takes the rhombus area as $30 \\times 40 = 1200$, so $r = 24$."),
               (r"$225\pi$ cm$^2$", "Takes the radius as half the shorter diagonal, $15$.")],
  check=_c037, values=[144 * pi, 36 * pi, 576 * pi, 225 * pi], cognitive="Application")

# ---------------------------------------------------------------- 038
def _c038():
    h = symbols('h', positive=True)
    # isosceles trapezium: bottom from (-9,0) to (9,0), top from (-4,h) to (4,h); circle centre (0, h/2), radius h/2
    leg = Line(Point(9, 0), Point(4, h))
    sol = solve(Eq(leg.distance(Point(0, h / 2))**2, (h / 2)**2), h)
    hv = [s for s in sol if s > 0][0]
    return (8 + 18) * hv / 2
q("C16-B-038", T, "Area of an isosceles trapezium that has an inscribed circle", "Difficult",
  "Multi-step word problem",
  r"An isosceles trapezium has parallel sides of $8$ cm and $18$ cm, and a circle can be drawn inside it touching all four sides. What is the area of the trapezium, in cm$^2$?",
  "TITA",
  r"Tangents from a vertex to a circle are equal, so in a quadrilateral with an incircle the sums of opposite sides are equal: $2l = 8 + 18$, so each slant side is $l = 13$. The horizontal overhang on each side is $\frac{18 - 8}{2} = 5$, so the height is $\sqrt{13^2 - 5^2} = 12$. The area is $\frac{1}{2}(8 + 18) \times 12 = 156$ cm$^2$.",
  "Using the slant side as the height, or not knowing the equal-sums property for a quadrilateral with an incircle.",
  "C16B-incircle-quadrilateral", "Needs the tangent-length property to get the legs before the height can be found.",
  tita_answer=156, check=_c038, cognitive="Analysis", exams=CX,
  tita_traps=[(169, "Uses the slant side $13$ as the height."),
              (312, "Forgets the half: $(8 + 18) \\times 12$.")])

# ---------------------------------------------------------------- 039
def _c039():
    x = symbols('x', positive=True)
    dx = solve(Eq(x**2 + (9 - 4)**2, (9 + 4)**2), x)[0]
    width = 9 + dx + 4
    return 18 * width
_f = Fig()
_f.poly((0, 0), (25, 0), (25, 18), (0, 18))
_f.circle((9, 9), 9); _f.circle((21, 4), 4)
_f.pt("", 29.5, 9, dot=False); _f.text((27.6, 9), "18 cm")
_alt = "A rectangle of height 18 cm. A circle of radius 9 cm touches its top, bottom and left sides; a circle of radius 4 cm touches the bottom side, the right side and the larger circle."
q("C16-B-039", T, "Area of a rectangle holding two touching circles", "Medium",
  "Multi-step word problem",
  r"A rectangle has height $18$ cm. Inside it, a circle of radius $9$ cm touches the top, bottom and left sides, and a circle of radius $4$ cm touches the bottom side, the right side and the larger circle. What is the area of the rectangle?",
  "MCQ",
  r"Both circles touch the bottom side, so their points of contact on it are $2\sqrt{9 \times 4} = 12$ cm apart (centres $13$ apart, heights differing by $5$). The width is $9 + 12 + 4 = 25$ cm, and the area is $18 \times 25 = 450$ cm$^2$.",
  "Placing the centres at the same height, subtracting instead of using Pythagoras, or dropping the factor 2.",
  "C16B-touching-circles-on-line", "Recognising the bottom side as a common tangent line, then adding the radii.",
  correct=r"$450$ cm$^2$",
  distractors=[(r"$468$ cm$^2$", "Takes the horizontal gap between centres as $13$, as if they were level: width $26$."),
               (r"$378$ cm$^2$", "Takes the horizontal gap as $13 - 5 = 8$: width $21$."),
               (r"$342$ cm$^2$", "Uses $\\sqrt{r_1 r_2} = 6$ for the gap, without the factor $2$: width $19$.")],
  check=_c039, values=[450, 468, 378, 342], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 040
def _c040():
    a, rho = 12, 6
    V = [(a * cos(k * pi / 3), a * sin(k * pi / 3)) for k in range(6)]
    hexa = _poly_area(V)
    sect = sum(_vertex_angle(V, i) / 2 * rho**2 for i in range(6))
    return simplify(hexa - sect)
_f = Fig()
_HV = [(12 * _m.cos(k * _m.pi / 3), 12 * _m.sin(k * _m.pi / 3)) for k in range(6)]
_f.poly(*_HV)
for _k, _v in enumerate(_HV):
    _f.arc(_v, 6, 60 * _k + 120, 60 * _k + 240)
_f.text((0, -12.2), "12 cm")
_alt = "A regular hexagon of side 12 cm. Inside it, at each of its six vertices, an arc of radius 6 cm centred at that vertex marks off a sector; neighbouring arcs meet at the midpoints of the sides."
q("C16-B-040", T, "Area of a regular hexagon left after removing circles centred at its vertices", "Medium",
  "Multi-step word problem",
  r"A regular hexagonal tile has side $12$ cm. Around each of its six vertices, the part of the tile within $6$ cm of that vertex is painted. What is the area of the unpainted part of the tile?",
  "MCQ",
  r"The painted part near each vertex is a sector of radius $6$ with the interior angle $120^\circ$, area $\frac{1}{3} \times 36\pi = 12\pi$; neighbouring sectors only touch at the midpoints of the sides. Six sectors give $72\pi$. The hexagon is $6 \times \frac{\sqrt{3}}{4} \times 144 = 216\sqrt{3}$. Unpainted area $216\sqrt{3} - 72\pi$ cm$^2$.",
  "Using the exterior angle for the sectors, or slipping on the hexagon's area.",
  "C16B-polygon-minus-vertex-sectors", "Polygon area minus sectors at the interior angles.",
  correct=r"$216\sqrt{3} - 72\pi$ cm$^2$",
  distractors=[(r"$216\sqrt{3} - 36\pi$ cm$^2$", "Uses the exterior angle $60^\\circ$ for each sector."),
               (r"$216\sqrt{3} - 108\pi$ cm$^2$", "Takes each painted part as a semicircle."),
               (r"$432\sqrt{3} - 72\pi$ cm$^2$", "Uses $\\frac{\\sqrt{3}}{2}a^2$ for each of the six equilateral triangles.")],
  check=_c040, values=[216 * sqrt(3) - 72 * pi, 216 * sqrt(3) - 36 * pi, 216 * sqrt(3) - 108 * pi, 432 * sqrt(3) - 72 * pi], cognitive="Application",
  figure=_fig(_f, _alt))

# ---------------------------------------------------------------- 041
def _c041():
    R, r = 15, 5
    best = 0
    for n in range(2, 100):
        # n equal coins with centres on a circle of radius R + r, evenly spaced (best spacing)
        if n == 2 or 2 * (R + r) * _m.sin(_m.pi / n) >= 2 * r - 1e-12:
            best = n
    # upper bound for any arrangement: each neighbouring pair needs an angle of at least 2 asin(r / (R + r))
    bound = int(2 * _m.pi // (2 * _m.asin(r / (R + r))))
    assert bound == best
    return best
q("C16-B-041", T, "Largest number of coins that can touch a central disc without overlapping", "Difficult",
  "Casework/optimisation",
  r"A circular plate of radius $15$ cm lies on a table. Coins of radius $5$ cm are placed flat on the table around it, each touching the plate. No two coins may overlap, though they may touch. What is the largest number of coins that can be placed?",
  "TITA",
  r"Every coin's centre lies on a circle of radius $20$ cm. Two coins do not overlap when their centres are at least $10$ cm apart. With $n$ coins spaced evenly, adjacent centres are $2 \times 20 \sin\frac{180^\circ}{n}$ apart, so we need $\sin\frac{180^\circ}{n} \ge \frac{1}{4}$. For $n = 12$, $\sin 15^\circ \approx 0.259 \ge 0.25$, which works. Uneven spacing cannot do better: seen from the plate's centre, any two neighbouring coin centres must be at least $2\arcsin\frac{1}{4} \approx 28.96^\circ$ apart, and $13 \times 28.96^\circ > 360^\circ$, so $13$ coins never fit. The answer is $12$.",
  "Dividing a circumference by the coin's diameter instead of checking the chord between centres.",
  "C16B-coins-around-disc", "Requires a chord condition on the circle of centres and testing the boundary case.",
  tita_answer=12, check=_c041, cognitive="Analysis", exams=CX,
  tita_traps=[(9, "Divides the plate's circumference $30\\pi$ by the coin diameter $10$."),
              (13, "Divides the centres' circle $40\\pi \\approx 125.7$ by $10$ and rounds up.")])

# ---------------------------------------------------------------- 042
def _c042():
    b = symbols('b', positive=True)
    other = solve(Eq(16**2 + b**2, 20**2), b)[0]
    return pi * 10**2 - 16 * other
q("C16-B-042", T, "Area of a circle outside an inscribed rectangle", "Medium",
  "Multi-step word problem",
  r"A rectangular photo is fixed inside a circular frame of radius $10$ cm so that all four corners of the photo touch the frame. One side of the photo is $16$ cm. What is the area inside the frame that is not covered by the photo?",
  "MCQ",
  r"The diagonal of the photo is a diameter, $20$ cm, so the other side is $\sqrt{20^2 - 16^2} = 12$ cm. The uncovered area is $100\pi - 16 \times 12 = 100\pi - 192$ cm$^2$.",
  "Using the radius as a side, or the diameter as the radius.",
  "C16B-circumcircle-rectangle", "Diagonal as diameter, then subtraction.",
  correct=r"$100\pi - 192$ cm$^2$",
  distractors=[(r"$100\pi - 160$ cm$^2$", "Takes the other side as the radius, $10$ cm."),
               (r"$100\pi - 96$ cm$^2$", "Takes the rectangle's area as $\\frac{1}{2} \\times 16 \\times 12$."),
               (r"$400\pi - 192$ cm$^2$", "Uses the diameter $20$ as the radius of the frame.")],
  check=_c042, values=[100 * pi - 192, 100 * pi - 160, 100 * pi - 96, 400 * pi - 192], cognitive="Application")

# ---------------------------------------------------------------- 043
def _c043():
    W, H, r = 70, 42, 7
    count = 0
    for i in itertools.count():
        cx = r + 2 * r * i
        if cx + r > W:
            break
        for j in itertools.count():
            cy = r + 2 * r * j
            if cy + r > H:
                break
            count += 1
    return W * H - count * P7 * r**2
q("C16-B-043", T, "Waste left after cutting discs in a grid from a rectangular sheet", "Easy",
  "Multi-step word problem",
  r"Circular discs of radius $7$ cm are cut from a rectangular metal sheet measuring $70$ cm by $42$ cm. The discs are cut in straight rows and columns, each disc touching its neighbours, and as many discs as possible are cut this way. What area of the sheet is left over, in cm$^2$? (Take $\pi = \frac{22}{7}$.)",
  "TITA",
  r"Each disc needs a $14 \times 14$ square, so $\frac{70}{14} \times \frac{42}{14} = 5 \times 3 = 15$ discs fit. They use $15 \times \frac{22}{7} \times 49 = 15 \times 154 = 2310$ cm$^2$ of the $70 \times 42 = 2940$ cm$^2$ sheet, leaving $630$ cm$^2$.",
  "Reporting the area used, or counting discs by dividing areas.",
  "C16B-disc-packing-sheet", "Count by rows and columns, then subtract.",
  tita_answer=630, check=_c043, cognitive="Application",
  tita_traps=[(2310, "Reports the area of the discs.")])

# ---------------------------------------------------------------- 044
def _c044():
    rho = 6
    V = [(0, 0), (12, 0), (6, 6 * sqrt(3))]
    tri = _poly_area(V)
    sect = sum(_vertex_angle(V, i) / 2 * rho**2 for i in range(3))
    return simplify(tri - sect)
q("C16-B-044", T, "Area enclosed between three equal mutually touching circles", "Medium",
  "Multi-step word problem",
  r"Three circular discs, each of radius $6$ cm, lie on a table so that each touches the other two. What is the area of the small region enclosed between the three discs?",
  "MCQ",
  r"The centres form an equilateral triangle of side $12$ cm, area $\frac{\sqrt{3}}{4} \times 144 = 36\sqrt{3}$. Inside the triangle each disc covers a $60^\circ$ sector, and the three sectors together make half a disc, $\frac{1}{2} \times 36\pi = 18\pi$. The enclosed region is $36\sqrt{3} - 18\pi$ cm$^2$.",
  "Slipping on the equilateral triangle's area, or subtracting the wrong total for the sectors.",
  "C16B-polygon-minus-vertex-sectors", "Triangle of centres minus three sectors.",
  correct=r"$36\sqrt{3} - 18\pi$ cm$^2$",
  distractors=[(r"$72\sqrt{3} - 18\pi$ cm$^2$", "Uses $\\frac{\\sqrt{3}}{2}a^2$ for the equilateral triangle."),
               (r"$36\sqrt{3} - 6\pi$ cm$^2$", "Subtracts only one $60^\\circ$ sector."),
               (r"$36\sqrt{3} - 12\pi$ cm$^2$", "Takes the three sectors together as one third of a disc instead of one half.")],
  check=_c044, values=[36 * sqrt(3) - 18 * pi, 72 * sqrt(3) - 18 * pi, 36 * sqrt(3) - 6 * pi, 36 * sqrt(3) - 12 * pi], cognitive="Application")

# ---------------------------------------------------------------- 045
def _c045():
    r = symbols('r', positive=True)
    sols = solve(Eq((10 - r)**2 + (10 - r)**2, (10 + r)**2), r)
    return [s for s in sols if s < 10][0]
_rc = 30 - 20 * _m.sqrt(2)
_f = Fig()
_f.poly((0, 0), (20, 0), (20, 20), (0, 20)); _f.circle((10, 10), 10); _f.circle((_rc, _rc), _rc)
_f.label_seg((0, 20), (20, 20), "20 cm")
_alt = "A square of side 20 cm with a circle inscribed in it, and a small circle in one corner touching the two sides at that corner and the inscribed circle."
q("C16-B-045", T, "Radius of a circle in the corner of a square outside its inscribed circle", "Difficult",
  "Multi-step word problem",
  r"A circle is inscribed in a square of side $20$ cm. A smaller circle is drawn in one corner of the square so that it touches the two sides meeting at that corner and also touches the inscribed circle. What is the radius of the smaller circle?",
  "MCQ",
  r"Both centres lie on the diagonal through the corner. The large centre is $10\sqrt{2}$ from the corner and the small centre (radius $r$) is $r\sqrt{2}$ from it. Since the circles touch, $10\sqrt{2} - r\sqrt{2} = 10 + r$, so $r = \frac{10(\sqrt{2} - 1)}{\sqrt{2} + 1} = 10(\sqrt{2} - 1)^2 = 30 - 20\sqrt{2}$ cm (about $1.72$ cm).",
  "Treating the gap along the diagonal as the small circle's radius or diameter, ignoring that its centre is $r\\sqrt{2}$ from the corner.",
  "C16B-corner-circle-square", "The gap along the diagonal must be split as $r + r\\sqrt{2}$, then rationalised.",
  correct=r"$30 - 20\sqrt{2}$ cm",
  distractors=[(r"$10\sqrt{2} - 10$ cm", "Takes the whole gap between the corner and the inscribed circle as the radius."),
               (r"$5\sqrt{2} - 5$ cm", "Takes the gap along the diagonal as the small circle's diameter."),
               (r"$10 - 5\sqrt{2}$ cm", "Sets the gap equal to $r\\sqrt{2}$, ignoring the small circle's own radius toward the large circle.")],
  check=_c045, values=[30 - 20 * sqrt(2), 10 * sqrt(2) - 10, 5 * sqrt(2) - 5, 10 - 5 * sqrt(2)], cognitive="Analysis", exams=CX,
  figure=_fig(_f, _alt))
