import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TOP = "Instalments and present value"
CX = ("CAT", "XAT")


def _grow(P, r, payments):
    """Outstanding balance after each year: add a year's compound interest, then subtract that year's payment."""
    b = F(P)
    for pay in payments:
        b = b * (1 + F(r)) - pay
    return b


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ---------------------------------------------------------------- EASY (9)

def _c1():
    P = symbols('P', positive=True)
    return solve(Eq(P * Rational(6, 5) ** 3, 17280), P)[0]
q("C03-C-001", TOP, "Present value of a single payment due after three years under compound interest", "Easy",
  "Single-step computation",
  r"Meera is to receive Rs. $17{,}280$ exactly $3$ years from today. If money can be invested at $20\%$ per annum compound interest, compounded annually, what is the present value of this payment?",
  "MCQ",
  r"Present value $= \frac{17280}{(1.2)^3} = \frac{17280}{1.728} = 10000$. So the present value is Rs. $10{,}000$.",
  "Discounting for fewer years than the payment is deferred, or subtracting interest computed on the future amount.",
  "C03C-pv-ci-discount", "One division by a cube of the growth factor; the trap is discounting for the wrong number of years or using simple interest.",
  correct=r"Rs. $10{,}000$",
  distractors=[(r"Rs. $12{,}000$", r"Discounts for only $2$ years: $17280 / 1.44 = 12000$."),
               (r"Rs. $10{,}800$", r"Discounts at simple interest: $17280 / (1 + 3 \times 0.2) = 17280 / 1.6 = 10800$."),
               (r"Rs. $6{,}912$", r"Subtracts $60\%$ of the future amount: $17280 \times 0.4 = 6912$.")],
  check=_c1, values=[10000, 12000, 10800, 6912], cognitive="Application")


def _c2():
    x = symbols('x', positive=True)
    # PV of instalments at end of years 1 and 2 equals the loan
    return solve(Eq(x / F(6, 5) + x / F(6, 5) ** 2, 5500), x)[0]
q("C03-C-002", TOP, "Equal annual instalment for a two-year loan under compound interest", "Easy",
  "Multi-step word problem",
  r"Ravi borrows Rs. $5{,}500$ at $20\%$ per annum compound interest, compounded annually. He repays the loan in two equal instalments paid at the end of the first and the second year, and this clears the loan exactly. What is the amount of each instalment, in rupees?",
  "TITA",
  r"The present values of the instalments add up to the loan: $\frac{x}{1.2} + \frac{x}{1.44} = 5500$. Multiplying by $1.44$, $1.2x + x = 2.2x = 5500 \times 1.44 = 7920$, so $x = 3600$.",
  "Ignoring interest, or adding interest on the whole loan for both years and splitting the total equally.",
  "C03C-ci-equal-instalment", "Standard present-value equation for two instalments; one trap of splitting the final amount equally.",
  tita_answer=3600, check=_c2,
  tita_traps=[(2750, r"Ignores interest: $5500 / 2 = 2750$."),
              (3960, r"Compounds the loan for $2$ years and halves it: $5500 \times 1.44 / 2 = 3960$."),
              (3300, r"Adds one year's interest and halves: $5500 \times 1.2 / 2 = 3300$.")],
  cognitive="Application")


def _c3():
    P = symbols('P', positive=True)
    return solve(Eq(P * (1 + Rational(10, 100) * 2), 7200), P)[0]
q("C03-C-003", TOP, "Present value of a payment due after two years under simple interest", "Easy",
  "Single-step computation",
  r"A payment of Rs. $7{,}200$ is due $2$ years from today. Its present value is the sum which, invested today at $10\%$ per annum simple interest, would amount to Rs. $7{,}200$ in $2$ years. What is the present value?",
  "MCQ",
  r"Under simple interest Rs. $P$ grows to $P(1 + 2 \times 0.1) = 1.2P$ in $2$ years. So $1.2P = 7200$ and $P = 6000$. The present value is Rs. $6{,}000$.",
  "Subtracting interest calculated on the future amount instead of dividing by the growth factor.",
  "C03C-pv-si-discount", "One division by $1.2$; the trap is deducting $20\\%$ of the face value.",
  correct=r"Rs. $6{,}000$",
  distractors=[(r"Rs. $5{,}760$", r"Deducts $2$ years' interest on the face value: $7200 - 0.2 \times 7200 = 5760$."),
               (r"Rs. $5{,}832$", r"Deducts $10\%$ of the face value twice in succession: $7200 \times 0.9 \times 0.9 = 5832$."),
               (r"Rs. $6{,}480$", r"Deducts $10\%$ of the face value only once: $7200 \times 0.9 = 6480$.")],
  check=_c3, values=[6000, 5760, 5832, 6480], cognitive="Application")


def _c4():
    pv_cash = F(26000)
    pv_plan = F(10000) + F(18150) / F(11, 10)
    return abs(pv_plan - pv_cash)
q("C03-C-004", TOP, "Comparing a cash price with a down payment plus one deferred payment", "Easy",
  "Conceptual/application",
  r"A refrigerator can be bought for Rs. $26{,}000$ in cash, or for Rs. $10{,}000$ now plus Rs. $18{,}150$ exactly one year later. The buyer can earn $10\%$ per annum interest on money he holds. Comparing the two ways of paying by their present values, by how many rupees is the cheaper way cheaper?",
  "TITA",
  r"Present value of the second option $= 10000 + \frac{18150}{1.1} = 10000 + 16500 = 26500$. Cash costs $26000$, so cash is cheaper by $26500 - 26000 = 500$ rupees.",
  "Comparing total rupees paid without discounting the deferred payment.",
  "C03C-plan-compare-pv", "One discounting step and one comparison; the trap is the nominal comparison.",
  tita_answer=500, check=_c4,
  tita_traps=[(2150, r"Compares nominal totals: $10000 + 18150 - 26000 = 2150$."),
              (335, r"Deducts $10\%$ of $18150$ instead of dividing by $1.1$: $10000 + 16335 - 26000 = 335$.")],
  cognitive="Application")


def _c5():
    x = symbols('x', positive=True)
    P, r = 7000, Rational(10, 100)
    # first instalment earns SI for 1 year till the end, second for 0 years
    return solve(Eq(x * (1 + r) + x, P * (1 + 2 * r)), x)[0]
q("C03-C-005", TOP, "Equal annual instalment for a two-year loan under simple interest", "Easy",
  "Multi-step word problem",
  r"Sneha borrows Rs. $7{,}000$ at $10\%$ per annum simple interest for $2$ years and repays it in two equal instalments at the end of each year. Each instalment is treated as earning simple interest at the same rate from the day it is paid until the end of the $2$ years, and the loan is cleared when the instalments together with this interest equal the amount of the loan (principal plus simple interest) at the end of $2$ years. What is each instalment?",
  "MCQ",
  r"Amount of the loan after $2$ years $= 7000 \times 1.2 = 8400$. The first instalment earns $1$ year's interest, the second none, so $1.1x + x = 2.1x = 8400$, giving $x = 4000$. Each instalment is Rs. $4{,}000$.",
  "Splitting the final amount equally without crediting interest on the first instalment.",
  "C03C-si-equal-instalment", "Two short steps under a stated convention; the trap is halving the final amount.",
  correct=r"Rs. $4{,}000$",
  distractors=[(r"Rs. $4{,}200$", r"Halves the final amount: $8400 / 2 = 4200$, giving the first instalment no interest."),
               (r"Rs. $3{,}500$", r"Ignores interest altogether: $7000 / 2 = 3500$."),
               (r"Rs. $3{,}850$", r"Adds only one year's interest and halves: $7000 \times 1.1 / 2 = 3850$.")],
  check=_c5, values=[4000, 4200, 3500, 3850], cognitive="Application")


def _c6():
    si = F(8000) * F(12, 100) * 2
    ci = F(5000) * (F(6, 5) ** 2 - 1)
    return si + ci
q("C03-C-006", TOP, "Total interest from one sum in a simple interest scheme and another in a compound interest scheme", "Easy",
  "Single-step computation",
  r"Pooja puts Rs. $8{,}000$ in a scheme paying $12\%$ per annum simple interest and Rs. $5{,}000$ in a scheme paying $20\%$ per annum compound interest, compounded annually. What is the total interest she earns from the two schemes in $2$ years?",
  "MCQ",
  r"Simple interest $= 8000 \times 0.12 \times 2 = 1920$. Compound interest $= 5000 \times (1.2^2 - 1) = 5000 \times 0.44 = 2200$. Total $= 1920 + 2200 = 4120$, that is Rs. $4{,}120$.",
  "Treating the compound interest scheme as simple interest, or adding an amount in place of the interest.",
  "C03C-split-si-ci-interest", "Two direct computations added; the trap is computing both schemes the same way.",
  correct=r"Rs. $4{,}120$",
  distractors=[(r"Rs. $3{,}920$", r"Computes the second scheme as simple interest: $1920 + 5000 \times 0.2 \times 2 = 1920 + 2000 = 3920$."),
               (r"Rs. $9{,}120$", r"Adds the compound amount $5000 \times 1.44 = 7200$ to the simple interest: $1920 + 7200 = 9120$."),
               (r"Rs. $3{,}160$", r"Takes only one year of simple interest: $960 + 2200 = 3160$.")],
  check=_c6, values=[4120, 3920, 9120, 3160], cognitive="Application")


def _c7():
    return _grow(20000, F(1, 10), [12000, 0])
q("C03-C-007", TOP, "Amount needed to clear a compound interest loan after one part payment", "Easy",
  "Multi-step word problem",
  r"Arjun borrows Rs. $20{,}000$ at $10\%$ per annum compound interest, compounded annually. At the end of the first year he pays Rs. $12{,}000$. What amount must he pay at the end of the second year to clear the loan completely?",
  "MCQ",
  r"At the end of year $1$ he owes $20000 \times 1.1 = 22000$; after paying $12000$ he owes $10000$. This grows to $10000 \times 1.1 = 11000$ by the end of year $2$. He must pay Rs. $11{,}000$.",
  "Subtracting the part payment from the two-year amount without allowing for the interest it saves.",
  "C03C-partial-repayment-ci", "Two short year-by-year steps; the trap is subtracting the payment at face value.",
  correct=r"Rs. $11{,}000$",
  distractors=[(r"Rs. $12{,}200$", r"Subtracts the payment at face value from the two-year amount: $24200 - 12000 = 12200$."),
               (r"Rs. $10{,}000$", r"Stops at the balance after the payment and drops the second year's interest."),
               (r"Rs. $10{,}800$", r"Uses simple interest: $20000 \times 1.2 - 12000 \times 1.1 = 24000 - 13200 = 10800$.")],
  check=_c7, values=[11000, 12200, 10000, 10800], cognitive="Application")


def _c8():
    P = symbols('P', positive=True)
    # P grows; after paying 4410 twice, nothing is left
    b1 = P * Rational(21, 20) - 4410
    return solve(Eq(b1 * Rational(21, 20) - 4410, 0), P)[0]
q("C03-C-008", TOP, "Loan amount from two equal compound interest instalments", "Easy",
  "Inverse/parameter",
  r"Fatima took a loan at $5\%$ per annum compound interest, compounded annually, and cleared it exactly with two equal instalments of Rs. $4{,}410$ each, paid at the end of the first and the second year. How much did she borrow, in rupees?",
  "TITA",
  r"The loan equals the present value of the instalments: $\frac{4410}{1.05} + \frac{4410}{1.05^2} = 4200 + 4000 = 8200$.",
  "Adding the instalments, or discounting both instalments by the same number of years.",
  "C03C-ci-equal-instalment", "Two divisions and an addition; the trap is ignoring the different payment dates.",
  tita_answer=8200, check=_c8,
  tita_traps=[(8820, r"Adds the instalments without discounting: $2 \times 4410$."),
              (8400, r"Discounts both instalments by one year: $2 \times 4200$."),
              (8000, r"Discounts both instalments by two years: $2 \times 4000$.")],
  cognitive="Application")


def _c9():
    X = symbols('X', positive=True)
    # paying X at end of year 1 is equivalent if X grows to 12100 by end of year 2
    return solve(Eq(X * Rational(11, 10), 12100), X)[0]
q("C03-C-009", TOP, "Equivalent earlier payment for a debt due in two years", "Easy",
  "Conceptual/application",
  r"Kabir owes Rs. $12{,}100$, due exactly $2$ years from today. His lender agrees that he may instead clear the debt with a single payment exactly $1$ year from today, the two being equivalent when money earns $10\%$ per annum compound interest. How much should that payment be?",
  "MCQ",
  r"A payment made one year earlier must grow for one year to the debt: $X \times 1.1 = 12100$, so $X = 11000$. The payment is Rs. $11{,}000$.",
  "Discounting to today instead of to the payment date, or compounding forward instead of discounting.",
  "C03C-pv-ci-discount", "One discounting step; the trap is choosing the wrong date to value the debt at.",
  correct=r"Rs. $11{,}000$",
  distractors=[(r"Rs. $10{,}000$", r"Discounts the debt for $2$ years, finding its value today rather than one year from now."),
               (r"Rs. $10{,}890$", r"Deducts $10\%$ of the face value: $12100 \times 0.9 = 10890$."),
               (r"Rs. $13{,}310$", r"Compounds the debt forward one year: $12100 \times 1.1 = 13310$.")],
  check=_c9, values=[11000, 10000, 10890, 13310], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM (13)

def _c10():
    x = symbols('x', positive=True)
    inst = solve(Eq(x / F(11, 10) + x / F(11, 10) ** 2, 4200), x)[0]
    bal_after_1 = F(4200) * F(11, 10) - F(inst)
    return bal_after_1 * F(1, 10)
q("C03-C-010", TOP, "Interest part of the second of two equal compound interest instalments", "Medium",
  "Conceptual/application",
  r"Priya borrows Rs. $4{,}200$ at $10\%$ per annum compound interest, compounded annually, and clears the loan with two equal instalments at the end of the first and the second year. How much of the second instalment is interest?",
  "MCQ",
  r"The instalment is $x = \frac{4200 \times 1.21}{2.1} = 2420$. After one year she owes $4620$; paying $2420$ leaves $2200$. Interest for the second year on $2200$ is $220$, so Rs. $220$ of the second instalment is interest (the rest, $2200$, repays principal).",
  "Assuming both instalments carry the same interest, or that the interest is spread equally.",
  "C03C-instalment-amortisation", "Needs the instalment first and then the outstanding balance after the first payment.",
  correct=r"Rs. $220$",
  distractors=[(r"Rs. $420$", r"Reports the interest in the first instalment, $10\%$ of $4200$."),
               (r"Rs. $320$", r"Splits the total interest $4840 - 4200 = 640$ equally between the instalments."),
               (r"Rs. $242$", r"Takes $10\%$ of the instalment $2420$.")],
  check=_c10, values=[220, 420, 320, 242], cognitive="Analysis")


def _c11():
    x = symbols('x', positive=True)
    g = F(11, 10)
    return solve(Eq(x / g + x / g ** 2 + x / g ** 3, 99300), x)[0]
q("C03-C-011", TOP, "Equal annual instalment for a three-year compound interest loan", "Medium",
  "Multi-step word problem",
  r"A shopkeeper borrows Rs. $99{,}300$ at $10\%$ per annum compound interest, compounded annually, and repays it in three equal instalments paid at the end of each of the next three years, clearing the loan exactly. What is each instalment, in rupees?",
  "TITA",
  r"$\frac{x}{1.1} + \frac{x}{1.21} + \frac{x}{1.331} = 99300$. Multiplying by $1.331$: $x(1.21 + 1.1 + 1) = 3.31x = 99300 \times 1.331 = 132168.3$, so $x = 39930$.",
  "Dividing the principal, or the principal with one year's interest, into three equal parts.",
  "C03C-ci-equal-instalment", "Three-term present-value sum; the arithmetic simplifies only if the candidate clears denominators by $1.331$.",
  tita_answer=39930, check=_c11,
  tita_traps=[(33100, r"Ignores interest: $99300 / 3$."),
              (36410, r"Adds one year's interest and divides by $3$: $99300 \times 1.1 / 3$.")],
  cognitive="Application")


def _c12():
    x = symbols('x', positive=True)
    P, r = 6300, Rational(5, 100)
    # instalments at ends of years 1, 2, 3 earn SI for 2, 1, 0 years till year 3
    return solve(Eq(x * (1 + 2 * r) + x * (1 + r) + x, P * (1 + 3 * r)), x)[0]
q("C03-C-012", TOP, "Equal annual instalment for a three-year loan under simple interest", "Medium",
  "Multi-step word problem",
  r"Harpreet borrows Rs. $6{,}300$ at $5\%$ per annum simple interest for $3$ years and repays it in three equal instalments at the end of each year. Each instalment is treated as earning simple interest at the same rate from the day it is paid until the end of the $3$ years, and the loan is cleared when the instalments together with this interest equal the amount of the loan (principal plus simple interest) at the end of $3$ years. What is each instalment, in rupees?",
  "TITA",
  r"Amount of the loan $= 6300 \times 1.15 = 7245$. The instalments earn interest for $2$, $1$ and $0$ years, so $x(1.10 + 1.05 + 1) = 3.15x = 7245$, giving $x = 2300$.",
  "Dividing the final amount by $3$ without crediting interest on the earlier instalments.",
  "C03C-si-equal-instalment", "Three instalments with different interest periods under a stated convention.",
  tita_answer=2300, check=_c12,
  tita_traps=[(2415, r"Divides the final amount by $3$: $7245 / 3$."),
              (2100, r"Ignores interest: $6300 / 3$.")],
  cognitive="Application")


def _c13():
    g = F(11, 10)
    pv = {"P": F(62000), "Q": 30000 + F(36300) / g ** 2, "R": F(36300) / g + F(36300) / g ** 2}
    return max(pv.values()) - min(pv.values())
q("C03-C-013", TOP, "Ranking three payment plans by present value", "Medium",
  "Conceptual/application",
  r"A machine can be bought under any of three plans. Plan P: Rs. $62{,}000$ now. Plan Q: Rs. $30{,}000$ now and Rs. $36{,}300$ at the end of $2$ years. Plan R: Rs. $36{,}300$ at the end of each of the next $2$ years, nothing now. Money is worth $10\%$ per annum compound interest. By how much does the present value of the costliest plan exceed that of the cheapest plan?",
  "MCQ",
  r"Present values: P is $62000$; Q is $30000 + \frac{36300}{1.21} = 30000 + 30000 = 60000$; R is $\frac{36300}{1.1} + \frac{36300}{1.21} = 33000 + 30000 = 63000$. The costliest is R and the cheapest is Q, so the difference is Rs. $3{,}000$.",
  "Comparing nominal totals, or comparing only two of the three plans.",
  "C03C-plan-compare-pv", "Three present values to compute and rank; the plan with the largest nominal total is not the costliest.",
  correct=r"Rs. $3{,}000$",
  distractors=[(r"Rs. $1{,}000$", r"Compares R with P only: $63000 - 62000$."),
               (r"Rs. $2{,}000$", r"Compares P with Q only: $62000 - 60000$."),
               (r"Rs. $10{,}600$", r"Compares nominal totals: R totals $72600$ against P's $62000$.")],
  check=_c13, values=[3000, 1000, 2000, 10600], cognitive="Analysis")


def _c14():
    return _grow(50000, F(1, 10), [15000, 20000, 0])
q("C03-C-014", TOP, "Final payment on a compound interest loan after two part payments", "Medium",
  "Multi-step word problem",
  r"Joseph borrows Rs. $50{,}000$ at $10\%$ per annum compound interest, compounded annually. He pays Rs. $15{,}000$ at the end of the first year and Rs. $20{,}000$ at the end of the second year. How much must he pay at the end of the third year to clear the loan, in rupees?",
  "TITA",
  r"Year $1$: $55000 - 15000 = 40000$. Year $2$: $44000 - 20000 = 24000$. Year $3$: $24000 \times 1.1 = 26400$. He must pay $26400$ rupees.",
  "Subtracting the part payments from the three-year amount at face value.",
  "C03C-partial-repayment-ci", "Three year-by-year steps; the trap is subtracting payments without interest.",
  tita_answer=26400, check=_c14,
  tita_traps=[(31550, r"Subtracts the payments at face value: $50000 \times 1.331 - 35000 = 31550$."),
              (24000, r"Forgets the third year's interest on the balance $24000$.")],
  cognitive="Application")


def _c15():
    a, b = symbols('a b', positive=True)
    s = solve([Eq(a + b, 41000), Eq(a * Rational(20, 100), b * (Rational(11, 10) ** 2 - 1))], [a, b], dict=True)[0]
    return s[a] * Rational(20, 100) + s[b] * (Rational(11, 10) ** 2 - 1)
q("C03-C-015", TOP, "Splitting a sum between simple and compound interest so that interests are equal", "Medium",
  "Multi-step word problem",
  r"Ananya divides Rs. $41{,}000$ into two parts. She invests the first part at $10\%$ per annum simple interest and the second part at $10\%$ per annum compound interest, compounded annually, both for $2$ years. The interest earned on the two parts is equal. What is the total interest she earns?",
  "MCQ",
  r"Simple interest on part $a$ is $0.2a$; compound interest on part $b$ is $0.21b$. Equal interest means $a : b = 21 : 20$, so $a = 21000$ and $b = 20000$. Each part earns $4200$, so the total is Rs. $8{,}400$.",
  "Treating both parts alike, or reporting one part's interest as the total.",
  "C03C-split-si-ci-interest", "Needs the split from an equal-interest condition before the total can be found.",
  correct=r"Rs. $8{,}400$",
  distractors=[(r"Rs. $8{,}200$", r"Takes simple interest on the whole sum: $41000 \times 0.2$."),
               (r"Rs. $8{,}610$", r"Takes compound interest on the whole sum: $41000 \times 0.21$."),
               (r"Rs. $4{,}200$", r"Reports the interest on one part only.")],
  check=_c15, values=[8400, 8200, 8610, 4200], cognitive="Application")


def _c16():
    r = symbols('r', positive=True)
    sol = _pos(solve(Eq(2500 / (1 + r) + 2500 / (1 + r) ** 2, 3600), r))
    return sol[0] * 100
q("C03-C-016", TOP, "Rate of compound interest from the loan and two equal instalments", "Difficult",
  "Inverse/parameter",
  r"A loan of Rs. $3{,}600$ is cleared exactly by two equal instalments of Rs. $2{,}500$ each, paid at the end of the first and the second year. Interest is compounded annually at a fixed rate. What is the rate of interest, in percent per annum?",
  "TITA",
  r"With $u = 1 + \frac{r}{100}$: $\frac{2500}{u} + \frac{2500}{u^2} = 3600$, so $3600u^2 - 2500u - 2500 = 0$, that is $36u^2 - 25u - 25 = 0$. Then $u = \frac{25 + \sqrt{625 + 3600}}{72} = \frac{25 + 65}{72} = 1.25$, so the rate is $25\%$.",
  "Treating the total excess paid as simple interest on the loan.",
  "C03C-instalment-rate-inverse", "Inverse problem with no direct formula: the unknown rate sits in two discount factors, giving a quadratic in the growth factor that must be set up and solved (or the rate found by testing values against the loan).",
  tita_answer=25, check=_c16, exams=CX,
  tita_traps=[(125, r"Solves for the growth factor $u = 1.25$ and enters $100u$ instead of the rate.")],
  cognitive="Analysis")


def _c17():
    pv1 = F(11000) / (1 + F(12, 100) * F(10, 12))
    pv2 = F(12240) / (1 + F(12, 100) * F(20, 12))
    return abs(pv2 - pv1)
q("C03-C-017", TOP, "Comparing two deferred offers by present value under simple interest", "Medium",
  "Conceptual/application",
  r"A seller receives two offers for his land: Rs. $11{,}000$ payable after $10$ months, or Rs. $12{,}240$ payable after $20$ months. Money can be invested at $12\%$ per annum simple interest, and each offer is valued by its present value (the sum that would grow to the offered amount at this rate by the payment date). By how many rupees does the present value of the better offer exceed that of the other?",
  "TITA",
  r"First offer: $\frac{11000}{1 + 0.12 \times \frac{10}{12}} = \frac{11000}{1.1} = 10000$. Second offer: $\frac{12240}{1 + 0.12 \times \frac{20}{12}} = \frac{12240}{1.2} = 10200$. The second is better by $200$ rupees.",
  "Comparing face values, or deducting interest computed on the face values.",
  "C03C-pv-si-discount", "Two present values with month-based simple interest, then a comparison.",
  tita_answer=200, check=_c17,
  tita_traps=[(1240, r"Compares face values: $12240 - 11000$."),
              (108, r"Deducts interest on the face values: $12240 \times 0.8 - 11000 \times 0.9 = 9792 - 9900$, then takes the size of the difference.")],
  cognitive="Application")


def _c18():
    x = symbols('x', positive=True)
    g = F(11, 10)   # 20% per annum compounded half-yearly: 10% per half-year
    return solve(Eq(x / g + x / g ** 2, 23100), x)[0]
q("C03-C-018", TOP, "Equal half-yearly instalments with half-yearly compounding", "Medium",
  "Multi-step word problem",
  r"Sneha borrows Rs. $23{,}100$ at $20\%$ per annum compound interest, compounded half-yearly. She repays it in two equal instalments, the first $6$ months after borrowing and the second $1$ year after borrowing, clearing the loan exactly. What is each instalment?",
  "MCQ",
  r"The rate is $10\%$ per half-year, so $\frac{x}{1.1} + \frac{x}{1.21} = 23100$. Then $2.1x = 23100 \times 1.21 = 27951$, giving $x = 13310$. Each instalment is Rs. $13{,}310$.",
  "Using the annual rate for each half-year period.",
  "C03C-halfyearly-instalment", "Requires converting to a per-period rate before setting up the instalment equation.",
  correct=r"Rs. $13{,}310$",
  distractors=[(r"Rs. $15{,}120$", r"Uses $20\%$ per period: $x = 23100 \times 1.44 / 2.2 = 15120$."),
               (r"Rs. $12{,}705$", r"Adds one period's interest and halves: $23100 \times 1.1 / 2$."),
               (r"Rs. $12{,}100$", r"Clears denominators by $1.1$ instead of $1.21$: $2.1x = 23100 \times 1.1$, giving $12100$.")],
  check=_c18, values=[13310, 15120, 12705, 12100], cognitive="Application")


def _c19():
    # simulate the loan with the given instalments and read the balance after the second
    x = 4320
    b = _grow(9100, F(1, 5), [x, x])
    assert _grow(9100, F(1, 5), [x, x, x]) == 0
    return b
q("C03-C-019", TOP, "Outstanding balance after two of three equal compound interest instalments", "Medium",
  "Conceptual/application",
  r"A loan of Rs. $9{,}100$ at $20\%$ per annum compound interest, compounded annually, is cleared exactly by three equal annual instalments of Rs. $4{,}320$, the first paid at the end of the first year. What is the outstanding balance immediately after the second instalment is paid?",
  "MCQ",
  r"Immediately after the second instalment, the balance is exactly what the third instalment clears, so it equals the present value of the last instalment one year earlier: $\frac{4320}{1.2} = 3600$. (Directly: $9100 \to 10920 - 4320 = 6600 \to 7920 - 4320 = 3600$.) The balance is Rs. $3{,}600$.",
  "Subtracting instalments from the principal at face value, or ignoring that the last instalment includes interest.",
  "C03C-instalment-amortisation", "The fast route uses the idea that the balance equals the present value of the remaining instalments.",
  correct=r"Rs. $3{,}600$",
  distractors=[(r"Rs. $4{,}320$", r"Takes the outstanding balance to be the remaining instalment itself."),
               (r"Rs. $460$", r"Subtracts two instalments from the principal: $9100 - 8640$."),
               (r"Rs. $3{,}000$", r"Discounts the last instalment for two years: $4320 / 1.44$.")],
  check=_c19, values=[3600, 4320, 460, 3000], cognitive="Understanding")


def _c20():
    x = symbols('x', positive=True)
    g = F(6, 5)
    # nothing paid in year 1; instalments at the ends of years 2 and 3, valued today
    return solve(Eq(x / g ** 2 + x / g ** 3, 24750), x)[0]
q("C03-C-020", TOP, "Equal instalments that begin after a one-year deferment", "Medium",
  "Multi-step word problem",
  r"A farmer borrows Rs. $24{,}750$ at $20\%$ per annum compound interest, compounded annually. Nothing is paid in the first year; the loan is cleared exactly by two equal instalments paid at the end of the second year and at the end of the third year. What is each instalment?",
  "MCQ",
  r"After one year the debt is $24750 \times 1.2 = 29700$, and two equal annual instalments from then on clear it: $\frac{x}{1.2} + \frac{x}{1.44} = 29700$. Multiplying by $1.44$: $2.2x = 42768$, so $x = 19440$. Each instalment is Rs. $19{,}440$.",
  "Ignoring the deferment year, or shifting the instalments one year too far.",
  "C03C-deferred-instalment", "The deferment shifts the valuation date; the trap is treating it as an ordinary two-year schedule.",
  correct=r"Rs. $19{,}440$",
  distractors=[(r"Rs. $16{,}200$", r"Ignores the deferment, taking instalments at the ends of years $1$ and $2$: $24750 \times 1.44 / 2.2$."),
               (r"Rs. $23{,}328$", r"Defers by two years, taking instalments at the ends of years $3$ and $4$: $24750 \times 2.0736 / 2.2$."),
               (r"Rs. $14{,}850$", r"Adds one year's interest and halves: $24750 \times 1.2 / 2$.")],
  check=_c20, values=[19440, 16200, 23328, 14850], cognitive="Application")


def _c21():
    a, b = symbols('a b', positive=True)
    s = solve([Eq(a + b, 38000), Eq(a * (1 + Rational(12, 100) * 5), b * Rational(6, 5) ** 2)], [a, b], dict=True)[0]
    return s[a] * (1 + Rational(12, 100) * 5)
q("C03-C-021", TOP, "Splitting a sum between simple and compound interest so that the final amounts are equal", "Medium",
  "Multi-step word problem",
  r"Kabir divides Rs. $38{,}000$ into two parts. The first part is invested at $12\%$ per annum simple interest for $5$ years; the second at $20\%$ per annum compound interest, compounded annually, for $2$ years. At the end of their respective periods the two parts amount to the same sum. What is that sum?",
  "MCQ",
  r"The first part grows by the factor $1 + 0.6 = 1.6$ and the second by $1.2^2 = 1.44$. Equal amounts mean $1.6a = 1.44b$, so $a : b = 9 : 10$, giving $a = 18000$, $b = 20000$. Each amounts to $18000 \times 1.6 = 28800$, that is Rs. $28{,}800$.",
  "Splitting the sum equally, or reporting the combined amount.",
  "C03C-split-si-ci-equal-amount", "Two growth factors, a ratio split and one back-substitution.",
  correct=r"Rs. $28{,}800$",
  distractors=[(r"Rs. $30{,}400$", r"Splits equally and grows the simple interest part: $19000 \times 1.6$."),
               (r"Rs. $27{,}360$", r"Splits equally and grows the compound interest part: $19000 \times 1.44$."),
               (r"Rs. $57{,}600$", r"Reports the combined amount of both parts.")],
  check=_c21, values=[28800, 30400, 27360, 57600], cognitive="Application")


def _c22():
    r = F(12, 100)
    owed = F(40000) * (1 + 2 * r) - 30000     # new principal after 2 years
    return owed * (1 + 2 * r)
q("C03-C-022", TOP, "Simple interest loan partly repaid with the balance treated as fresh principal", "Medium",
  "Multi-step word problem",
  r"Ravi borrows Rs. $40{,}000$ at $12\%$ per annum simple interest. At the end of $2$ years he pays Rs. $30{,}000$. The amount then outstanding (principal plus interest so far, minus the payment) becomes a fresh principal on which simple interest at $12\%$ per annum runs from that date. What must he pay at the end of $4$ years from the start to clear the loan?",
  "MCQ",
  r"After $2$ years he owes $40000 \times 1.24 = 49600$; after paying $30000$ the fresh principal is $19600$. Two more years at $12\%$ simple interest: $19600 \times 1.24 = 24304$. He must pay Rs. $24{,}304$.",
  "Running simple interest on the original principal throughout, or crediting interest on the payment instead of restarting the principal.",
  "C03C-partial-repayment-si", "Two simple interest stages with a change of principal in between.",
  correct=r"Rs. $24{,}304$",
  distractors=[(r"Rs. $29{,}200$", r"Runs interest on $40000$ for all $4$ years and subtracts the payment at face value: $59200 - 30000$."),
               (r"Rs. $22{,}000$", r"Credits $2$ years' simple interest on the payment: $59200 - 30000 \times 1.24 = 22000$."),
               (r"Rs. $19{,}600$", r"Stops at the fresh principal and drops the last $2$ years' interest.")],
  check=_c22, values=[24304, 29200, 22000, 19600], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (8)

def _c23():
    x = symbols('x', positive=True)
    g = F(6, 5)
    xv = solve(Eq(x / g + 2 * x / g ** 2 + 3 * x / g ** 3, 17100), x)[0]
    # simulate the loan; the balance just before the last instalment carries one year's interest
    b = F(17100)
    for pay in (xv, 2 * xv):
        b = b * g - pay
    assert b * g == 3 * xv
    return b * F(1, 5)
q("C03-C-023", TOP, "Interest content of the largest of three compound interest instalments in a given ratio", "Difficult",
  "Multi-step word problem",
  r"A loan of Rs. $17{,}100$ at $20\%$ per annum compound interest, compounded annually, is cleared exactly by three instalments paid at the end of the first, second and third years, in the ratio $1 : 2 : 3$. Each instalment first pays the interest accrued during that year, and the rest of it repays principal. How many rupees of the largest instalment are interest?",
  "TITA",
  r"Let the instalments be $x$, $2x$, $3x$. Then $\frac{x}{1.2} + \frac{2x}{1.44} + \frac{3x}{1.728} = 17100$; multiplying by $1.728$, $6.84x = 29548.8$, so $x = 4320$ and the largest instalment is $12960$. It clears the loan, so the balance just before it was $\frac{12960}{1.2} = 10800$, and the year's interest on that balance is $0.2 \times 10800 = 2160$.",
  "Taking the interest as a percentage of the instalment instead of the outstanding balance, or stopping at the instalment.",
  "C03C-unequal-instalments", "Two stages: an unequal-instalment present-value equation with three discount factors, then the amortisation idea that the last instalment equals the final balance plus one year's interest.",
  tita_answer=2160, check=_c23, exams=CX,
  tita_traps=[(12960, r"Reports the largest instalment itself instead of its interest part."),
              (2592, r"Takes $20\%$ of the instalment: $0.2 \times 12960$."),
              (10800, r"Reports the principal part of the largest instalment, $12960 - 2160$.")],
  cognitive="Analysis")


def _c24():
    x = symbols('x', positive=True)
    bal = _grow(35000, F(1, 10), [7000])
    return solve(Eq(x / F(11, 10) + x / F(11, 10) ** 2, bal), x)[0]
q("C03-C-024", TOP, "Part payment followed by equal instalments on a compound interest loan", "Medium",
  "Multi-step word problem",
  r"Priya borrows Rs. $35{,}000$ at $10\%$ per annum compound interest, compounded annually. She pays Rs. $7{,}000$ at the end of the first year, and then clears the rest of the loan exactly with two equal instalments, paid at the end of the second and the third year. What is each of these two instalments?",
  "MCQ",
  r"At the end of year $1$ she owes $38500 - 7000 = 31500$. Two equal annual instalments from then on must have present value $31500$ at that date: $\frac{x}{1.1} + \frac{x}{1.21} = 31500$, so $2.1x = 38115$ and $x = 18150$. Each is Rs. $18{,}150$.",
  "Valuing the remaining balance at the wrong date, or ignoring the timing of the two instalments.",
  "C03C-repay-then-instalments", "Two stages: a balance after a part payment, then a standard two-instalment equation valued at the right date; about two minutes.",
  correct=r"Rs. $18{,}150$",
  distractors=[(r"Rs. $17{,}325$", r"Adds one year's interest to the balance and halves: $31500 \times 1.1 / 2$."),
               (r"Rs. $19{,}965$", r"Treats $31500$ as owed today and discounts the instalments from today for $2$ and $3$ years: $31500 \times 1.331 / 2.1$."),
               (r"Rs. $15{,}750$", r"Ignores interest after the part payment and halves the balance: $31500 / 2$.")],
  check=_c24, values=[18150, 17325, 19965, 15750], cognitive="Application")


def _c25():
    b, paid, pay = F(30000), F(0), 12000
    while True:
        b = b * F(11, 10)
        if b <= pay:
            paid += b
            return paid - 30000
        b -= pay
        paid += pay
q("C03-C-025", TOP, "Total interest paid when a compound interest loan is repaid by fixed annual payments", "Difficult",
  "Casework/optimisation",
  r"Meera borrows Rs. $30{,}000$ at $10\%$ per annum compound interest, compounded annually. At the end of each year the year's interest is added to the outstanding amount, and she then pays Rs. $12{,}000$, except that at the end of the first year in which the outstanding amount (after adding interest) is Rs. $12{,}000$ or less, she pays exactly that amount and the loan is closed. What is the total interest, in rupees, that she pays over the life of the loan?",
  "TITA",
  r"Year $1$: $33000 - 12000 = 21000$. Year $2$: $23100 - 12000 = 11100$. Year $3$: $12210$, which exceeds $12000$, so she pays $12000$ and $210$ remains. Year $4$: $210 \times 1.1 = 231$, which she pays. She pays $3 \times 12000 + 231 = 36231$ in all, so the interest is $36231 - 30000 = 6231$ rupees (check: $3000 + 2100 + 1110 + 21$).",
  "Closing the loan in year $3$ because the balance is close to $12000$, or treating the schedule as exactly three payments of $12000$.",
  "C03C-fixed-payment-schedule", "Year-by-year casework with a near-miss in year $3$ that sends the loan into a fourth year, then totalling the payments against the principal.",
  tita_answer=6231, check=_c25, exams=CX,
  tita_traps=[(6210, r"Closes the loan in year $3$ by paying the whole $12210$ (or, equally, forgets the fourth year's interest on the leftover $210$): $36210 - 30000$."),
              (6000, r"Assumes three payments of $12000$ clear the loan: $36000 - 30000$.")],
  cognitive="Analysis")


def _c26():
    a, b, r = symbols('a b r', positive=True)
    sols = solve([Eq(a + b, 25000), Eq((a + b) * r, 2500), Eq(2 * a * r + b * ((1 + r) ** 2 - 1), 5120)], [a, b, r], dict=True)
    return [s[b] for s in sols if s[a] > 0 and s[b] > 0][0]
q("C03-C-026", TOP, "Recovering the split between simple and compound interest schemes from yearly interest totals", "Difficult",
  "Inverse/parameter",
  r"Joseph invests a total of Rs. $25{,}000$: one part in a scheme paying $r\%$ per annum simple interest and the rest in a scheme paying the same $r\%$ per annum compound interest, compounded annually. The total interest from both schemes is Rs. $2{,}500$ after $1$ year and Rs. $5{,}120$ after $2$ years. How much, in rupees, did he invest in the compound interest scheme?",
  "TITA",
  r"After $1$ year both schemes earn the same, so $25000 \times \frac{r}{100} = 2500$ and $r = 10$. Over $2$ years the only extra is the interest on interest in the compound scheme: $5120 - 2 \times 2500 = 120 = b \times 0.1^2$, so $b = 12000$.",
  "Dividing the extra interest by the rate once instead of by its square.",
  "C03C-split-si-ci-interest", "Needs the insight that the two schemes differ only by interest on interest in year $2$.",
  tita_answer=12000, check=_c26, exams=CX,
  tita_traps=[(1200, r"Divides the extra $120$ by $0.1$ instead of $0.01$."),
              (13000, r"Reports the simple interest part, $25000 - 12000$.")],
  cognitive="Analysis")


def _c27():
    g = F(6, 5)
    pv_plan = F(57600) / g + F(57600) / g ** 2
    d = symbols('d', nonnegative=True)
    # smallest discount so that cash price after discount is at most the plan's present value
    return solve(Eq(100000 - d, pv_plan), d)[0]
q("C03-C-027", TOP, "Smallest cash discount that makes paying cash at least as good as an instalment plan", "Difficult",
  "Inverse/parameter",
  r"A dealer sells a car for Rs. $1{,}00{,}000$ in cash, or alternatively for two equal instalments of Rs. $57{,}600$ each, paid at the end of the first and the second year with nothing paid now. Harpreet can earn $20\%$ per annum compound interest, compounded annually, on her money, and judges the options by present value. What is the smallest cash discount (in rupees, off the Rs. $1{,}00{,}000$) that would make paying cash at least as attractive to her as the instalment plan?",
  "MCQ",
  r"Present value of the plan $= \frac{57600}{1.2} + \frac{57600}{1.44} = 48000 + 40000 = 88000$. Cash is at least as attractive when the cash price is at most $88000$, so the discount must be at least $100000 - 88000 = 12000$, that is Rs. $12{,}000$.",
  "Comparing values at a future date instead of today, or discounting both instalments by the same period.",
  "C03C-plan-compare-pv", "The nominal total makes cash look cheaper; recognising the plan is worth less today and inverting for the discount is the step most candidates miss.",
  correct=r"Rs. $12{,}000$",
  distractors=[(r"Rs. $20{,}000$", r"Discounts both instalments for $2$ years: $100000 - 115200 / 1.44$."),
               (r"Rs. $4{,}000$", r"Discounts both instalments for $1$ year: $100000 - 115200 / 1.2$."),
               (r"Rs. $17{,}280$", r"Compares values at the end of year $2$: $100000 \times 1.44 - (57600 \times 1.2 + 57600) = 144000 - 126720$.")],
  check=_c27, values=[12000, 20000, 4000, 17280], exams=CX, cognitive="Analysis")


def _c28():
    x = symbols('x', positive=True)
    g = F(11, 10)
    xv = solve(Eq(x / g + x * g / g ** 2 + x * g ** 2 / g ** 3, 33000), x)[0]
    return xv * g ** 2
q("C03-C-028", TOP, "Instalments growing at the interest rate: last instalment", "Difficult",
  "Conceptual/application",
  r"Fatima borrows Rs. $33{,}000$ at $10\%$ per annum compound interest, compounded annually, and repays it with three annual instalments paid at the end of the first, second and third years. Each instalment is $10\%$ larger than the one before it, and the loan is cleared exactly. What is the last instalment?",
  "MCQ",
  r"Since each instalment grows at the interest rate, every instalment has the same present value, $\frac{x}{1.1}$. So $3 \times \frac{x}{1.1} = 33000$, giving $x = 12100$ for the first instalment. The last is $12100 \times 1.21 = 14641$, that is Rs. $14{,}641$.",
  r"Taking the first instalment as one third of the loan, or growing it by a fixed amount instead of by $10\%$.",
  "C03C-growing-instalments", "The insight that each instalment has equal present value makes it quick; brute algebra over three discount factors is slow.",
  correct=r"Rs. $14{,}641$",
  distractors=[(r"Rs. $13{,}310$", r"Takes the first instalment as $33000 / 3 = 11000$ and grows it twice: $11000 \times 1.21$."),
               (r"Rs. $12{,}100$", r"Reports the first instalment."),
               (r"Rs. $14{,}520$", r"Grows the first instalment $12100$ by a fixed $1210$ each year: $12100 + 2 \times 1210$.")],
  check=_c28, values=[14641, 13310, 12100, 14520], exams=CX, cognitive="Analysis")


def _c29():
    A = symbols('A', positive=True)
    return solve(Eq(A / (1 + 3 * Rational(1, 10)) - A / Rational(11, 10) ** 3, 620), A)[0]
q("C03-C-029", TOP, "Sum due from the gap between its simple and compound interest present values", "Difficult",
  "Inverse/parameter",
  r"A payment is due $3$ years from today. Its present value at $10\%$ per annum simple interest exceeds its present value at $10\%$ per annum compound interest, compounded annually, by Rs. $620$. (The present value is the sum which, invested today at the stated rate, grows to the payment in $3$ years.) What is the payment?",
  "MCQ",
  r"Present values are $\frac{S}{1.3}$ and $\frac{S}{1.331}$. Their difference is $S \times \frac{0.031}{1.3 \times 1.331} = \frac{0.031S}{1.7303} = 620$, so $S = 20000 \times 1.7303 = 34606$. The payment is Rs. $34{,}606$.",
  "Treating the gap as the difference between compound and simple interest on a principal.",
  "C03C-pv-si-vs-ci", "Reverses the usual SI and CI difference: the gap is between discounted values, not interest amounts.",
  correct=r"Rs. $34{,}606$",
  distractors=[(r"Rs. $20{,}000$", r"Treats $620$ as the CI minus SI gap on a principal $P$: $0.031P = 620$, so $P = 20000$."),
               (r"Rs. $52{,}620$", r"Adds the two growth factors instead of multiplying them when combining the fractions: $\frac{0.031S}{1.3 + 1.331} = 620$, so $S = 20000 \times 2.631$."),
               (r"Rs. $26{,}620$", r"Uses a common denominator of $1.331$ alone: $\frac{0.031S}{1.331} = 620$, so $S = 20000 \times 1.331$.")],
  check=_c29, values=[34606, 20000, 52620, 26620], exams=CX, cognitive="Analysis")


def _c30():
    R = symbols('R', positive=True)
    # R at end of year 1, 2R at end of year 2, Rs 34,012 at end of year 3 clears 44,000 at 10% CI
    b = (44000 * Rational(11, 10) - R) * Rational(11, 10) - 2 * R
    return solve(Eq(b * Rational(11, 10) - 34012, 0), R)[0]
q("C03-C-030", TOP, "Unknown part payment on a compound interest loan cleared by a known final payment", "Difficult",
  "Inverse/parameter",
  r"Arjun borrows Rs. $44{,}000$ at $10\%$ per annum compound interest, compounded annually. He makes a payment at the end of the first year, a payment twice as large at the end of the second year, and clears the loan with a payment of Rs. $34{,}012$ at the end of the third year. How much did he pay at the end of the first year?",
  "MCQ",
  r"Value everything at the end of year $3$: $44000 \times 1.331 = 58564$ must equal $1.21R + 2R \times 1.1 + 34012 = 3.41R + 34012$. So $3.41R = 24552$ and $R = 7200$. He paid Rs. $7{,}200$.",
  "Subtracting payments at face value, using simple interest, or swapping which payment is larger.",
  "C03C-partial-repayment-ci", "Requires valuing three payments at a common date and solving for an unknown; several plausible slips give clean wrong values.",
  correct=r"Rs. $7{,}200$",
  distractors=[(r"Rs. $8{,}184$", r"Ignores interest on the payments: $3R = 58564 - 34012$."),
               (r"Rs. $6{,}820$", r"Uses simple interest throughout: $44000 \times 1.3 = 1.2R + 2.2R + 34012$, so $3.4R = 23188$."),
               (r"Rs. $6{,}975$", r"Puts the larger payment in year $1$: $2R \times 1.21 + R \times 1.1 = 3.52R = 24552$.")],
  check=_c30, values=[7200, 8184, 6820, 6975], exams=CX, cognitive="Analysis")
