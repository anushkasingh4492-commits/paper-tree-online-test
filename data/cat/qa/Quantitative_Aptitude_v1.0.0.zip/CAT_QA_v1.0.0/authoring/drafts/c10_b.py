import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
ALL = ("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET")
HARD = ("CAT", "XAT")
T = "Quadratic word problems and conditions"
k_, x_, t_ = symbols('k x t', real=True)


def _real_roots(a, b, c):
    """Real roots (floats, with multiplicity collapsed) of a x^2 + b x + c with exact Fraction inputs."""
    a, b, c = F(a), F(b), F(c)
    if a == 0:
        return [] if b == 0 else [float(-c / b)]
    D = b * b - 4 * a * c
    if D < 0:
        return []
    if D == 0:
        return [float(-b / (2 * a))]
    s = math.sqrt(D)
    return sorted([(-float(b) - s) / (2 * float(a)), (-float(b) + s) / (2 * float(a))])


def _distinct_count(a, b, c):
    a, b, c = F(a), F(b), F(c)
    D = b * b - 4 * a * c
    return 0 if D < 0 else (1 if D == 0 else 2)


def _scan(S, pred, lo=-20, hi=20, n=3001, exact=()):
    """Brute-force confirmation: pred(k) must agree with membership of k in sympy set S on a fine grid
    of non-special rationals in [lo, hi] and on the exact boundary points listed."""
    pts = [F(lo) + F(hi - lo) * F(2 * i + 1, 2 * n) + F(1, 1009) for i in range(n)]
    pts += [F(e) for e in exact]
    for kk in pts:
        want = bool(S.contains(Rational(kk.numerator, kk.denominator)))
        if bool(pred(kk)) != want:
            raise AssertionError(f"scan mismatch at k={kk}: pred={pred(kk)} set={want}")
    return S


def _iset(expr_rel):
    return solve_univariate_inequality(expr_rel, k_, relational=False)


# ---------------------------------------------------------------- 001
def _c1():
    sols = [n for n in range(4, 200) if F(36000, n) + 1000 == F(36000, n - 3)]
    return sols[0] if len(sols) == 1 else None
q("C10-B-001", T, "Fixed total shared equally; members drop out and each share rises", "Easy",
  "Multi-step word problem",
  r"A group of friends rented a holiday villa for Rs. $36{,}000$, the amount to be shared equally. Three of them later dropped out, and the remaining friends shared the same Rs. $36{,}000$ equally, each paying Rs. $1{,}000$ more than originally planned. How many friends were in the group originally?",
  "TITA",
  r"Let there be $n$ friends. Then $\frac{36000}{n-3} - \frac{36000}{n} = 1000$, so $36000 \times 3 = 1000\,n(n-3)$, that is $n(n-3) = 108$. Since $12 \times 9 = 108$, $n = 12$ (shares Rs. $3{,}000$ and Rs. $4{,}000$).",
  "Reporting the number of friends who finally paid instead of the original group size.",
  "C10B-fixed-total-sharing-change", "One equation from a fixed total, giving a factorable quadratic.",
  tita_answer=12, check=_c1, values=[12],
  tita_traps=[(9, "Reports the $n - 3 = 9$ friends who finally paid.")],
  cognitive="Application")

# ---------------------------------------------------------------- 002
def _c2():
    n = symbols('n', positive=True)
    sol = [s for s in solve(Eq(9600 / n - 9600 / (n + 4), 80), n) if s > 0]
    return Rational(9600) / (sol[0] + 4)
q("C10-B-002", T, "Fixed charge shared; extra members join and the share falls", "Medium",
  "Multi-step word problem",
  r"A club hired a bus for a trip at a fixed charge of Rs. $9{,}600$, to be shared equally by the members who had signed up. On the day of the trip $4$ more members joined, the charge was shared equally among everyone, and each original member's share fell by Rs. $80$. How much did each person finally pay?",
  "MCQ",
  r"Let $n$ members sign up. Then $\frac{9600}{n} - \frac{9600}{n+4} = 80$, so $9600 \times 4 = 80\,n(n+4)$, giving $n(n+4) = 480 = 20 \times 24$. So $n = 20$ and $24$ people travelled, each paying $\frac{9600}{24} = 400$ rupees.",
  "Stopping at the original share or mishandling the change in group size.",
  "C10B-fixed-total-sharing-change", "Two steps: solve for the group size, then compute the new share.",
  correct=r"Rs. $400$",
  distractors=[(r"Rs. $480$", "Reports the original share $\\frac{9600}{20}$."),
               (r"Rs. $560$", "Adds the Rs. $80$ change to the original share instead of subtracting it."),
               (r"Rs. $600$", "Finds $n = 20$ but divides by $n - 4 = 16$, as if $4$ members had left.")],
  check=_c2, values=[400, 480, 560, 600], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c3():
    n = symbols('n', positive=True)
    N = [s for s in solve(Eq(7200 / (n - 2) - 7200 / n, 120), n) if s > 2][0]
    return Rational(7200) / N - Rational(7200) / (N + 4)
q("C10-B-003", T, "Hypothetical changes in group size and the resulting change in share", "Medium",
  "Multi-step word problem",
  r"The members of a team agreed to share a restaurant bill of Rs. $7{,}200$ equally. Had there been $2$ fewer members, each would have paid Rs. $120$ more. Had there been $4$ more members instead, by how much would each member's share have decreased?",
  "MCQ",
  r"With $n$ members, $\frac{7200}{n-2} - \frac{7200}{n} = 120$ gives $n(n-2) = \frac{7200 \times 2}{120} = 120$, so $n = 12$ and the share is Rs. $600$. With $16$ members the share is $\frac{7200}{16} = 450$, a decrease of Rs. $150$.",
  "Treating the change in share as proportional to the change in the number of members.",
  "C10B-fixed-total-sharing-change", "Needs the group size from a quadratic before a second scenario can be evaluated.",
  correct=r"Rs. $150$",
  distractors=[(r"Rs. $240$", "Assumes the change in share is proportional to the change in members: twice $120$."),
               (r"Rs. $120$", "Assumes adding members changes the share by the same Rs. $120$."),
               (r"Rs. $270$", "Compares the $16$-member share with the $10$-member share: $720 - 450$.")],
  check=_c3, values=[150, 240, 120, 270], cognitive="Application")

# ---------------------------------------------------------------- 004
def _c4():
    sols = [n for n in range(1, 2000) if n * (n + 1) == 1056]
    return sols[0] + sols[0] + 1
q("C10-B-004", T, "Product of two consecutive integers (facing page numbers)", "Easy",
  "Single-step computation",
  r"A book lies open, and the two page numbers visible are consecutive integers whose product is $1{,}056$. What is the sum of these two page numbers?",
  "TITA",
  r"If the pages are $n$ and $n + 1$, then $n(n+1) = 1056$. Since $\sqrt{1056} \approx 32.5$, try $32 \times 33 = 1056$. The sum is $32 + 33 = 65$.",
  "Doubling one page number instead of adding the two consecutive numbers.",
  "C10B-consecutive-integers-quadratic", "One quadratic, solved by estimating the square root.",
  tita_answer=65, check=_c4, values=[65],
  tita_traps=[(64, "Doubles the smaller page number $32$."), (32, "Reports only the smaller page number.")],
  cognitive="Application")

# ---------------------------------------------------------------- 005
def _c5():
    n = symbols('n', positive=True)
    sol = [s for s in solve(Eq((n - 10) * (Rational(400) / n + 5), 400 + 120), n) if s > 10]
    return sol[0]
q("C10-B-005", T, "Profit after breakage with a fixed markup per unit", "Medium",
  "Multi-step word problem",
  r"A shopkeeper bought a batch of identical glasses for Rs. $400$ in all. During transport $10$ glasses broke. He sold each of the remaining glasses at Rs. $5$ more than the cost price of one glass and made an overall profit of Rs. $120$ on the batch. How many glasses did he buy?",
  "MCQ",
  r"With $n$ glasses the cost of one is $\frac{400}{n}$, so the revenue is $(n-10)\left(\frac{400}{n} + 5\right) = 400 + 120 = 520$. This gives $400 + 5n - \frac{4000}{n} - 50 = 520$, so $5n^2 - 170n - 4000 = 0$, that is $n^2 - 34n - 800 = 0 = (n-50)(n+16)$. Hence $n = 50$ (cost Rs. $8$ each, $40$ sold at Rs. $13$).",
  "Ignoring the cost of the broken glasses or reporting the number sold.",
  "C10B-profit-after-breakage", "Revenue condition with an unknown unit cost leads to a quadratic.",
  correct=r"$50$",
  distractors=[(r"$40$", "Reports the number of glasses sold, $n - 10$."),
               (r"$34$", "Takes the profit as Rs. $5$ on each glass sold, $5(n - 10) = 120$, ignoring the cost of the broken ones."),
               (r"$24$", "Ignores the breakage in the revenue: $n\\left(\\frac{400}{n} + 5\\right) = 520$ gives $5n = 120$, so $n = 24$.")],
  check=_c5, values=[50, 40, 34, 24], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c6():
    w = symbols('w', positive=True)
    sol = [s for s in solve(Eq((30 - 2 * w) * (20 - 2 * w), 336), w) if 2 * s < 20]
    return sol[0]
q("C10-B-006", T, "Uniform path inside a rectangular lawn", "Easy",
  "Multi-step word problem",
  r"A rectangular lawn measures $30$ m by $20$ m. A path of uniform width is laid inside the lawn along all four edges, and the grassy area that remains is $336$ m$^2$. What is the width of the path, in metres?",
  "TITA",
  r"The grass is a rectangle $(30 - 2w)$ by $(20 - 2w)$. So $(30-2w)(20-2w) = 336$, that is $4w^2 - 100w + 264 = 0$, or $w^2 - 25w + 66 = 0 = (w-3)(w-22)$. Since $2w < 20$, $w = 3$ m.",
  "Reducing each dimension by $w$ instead of $2w$, or treating $336$ m$^2$ as the path area.",
  "C10B-uniform-border-area", "One area equation; the second root must be rejected.",
  tita_answer=3, check=_c6, values=[3],
  tita_traps=[(6, "Reduces each dimension by $w$ only: $(30-w)(20-w) = 336$ gives $w = 6$."),
              (4, "Treats $336$ m$^2$ as the path area: $(30-2w)(20-2w) = 264$ gives $w = 4$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 007
def _c7():
    w = symbols('w', positive=True)
    W = [s for s in solve(Eq((30 + 2 * w) * (20 + 2 * w) - 600, 600), w) if s > 0][0]
    return 2 * ((30 + 2 * W) + (20 + 2 * W))
q("C10-B-007", T, "Border of uniform width whose area equals the enclosed area", "Easy",
  "Multi-step word problem",
  r"A photograph measuring $30$ cm by $20$ cm is mounted on a card so that a border of uniform width surrounds it on all four sides. The area of the border equals the area of the photograph. What is the perimeter of the card?",
  "MCQ",
  r"With border width $w$, the card is $(30+2w)$ by $(20+2w)$ and its area is twice the photograph's: $(30+2w)(20+2w) = 1200$. This gives $w^2 + 25w - 150 = 0 = (w+30)(w-5)$, so $w = 5$. The card is $40$ cm by $30$ cm, with perimeter $140$ cm.",
  "Adding the border width once to each dimension, or ignoring the corner squares of the border.",
  "C10B-uniform-border-area", "Area condition gives a quadratic; perimeter needs the full outer dimensions.",
  correct=r"$140$ cm",
  distractors=[(r"$100$ cm", "Reports the perimeter of the photograph, $2(30 + 20)$, instead of the card."),
               (r"$148$ cm", "Ignores the corner squares: $2(30+20)w = 600$ gives $w = 6$ and a $42 \\times 32$ card."),
               (r"$120$ cm", "Finds $w = 5$ but adds it only once to each dimension: $2(35 + 25)$.")],
  check=_c7, values=[140, 100, 148, 120], cognitive="Application")

# ---------------------------------------------------------------- 008
def _c8():
    # s steps of Rs. 5 above Rs. 60; sales 400 - 20 s; keep prices hitting the revenue target exactly
    hits = [(60 + 5 * s, 400 - 20 * s) for s in range(0, 20) if (60 + 5 * s) * (400 - 20 * s) == 25200]
    return max(hits, key=lambda h: h[1])[0]
q("C10-B-008", T, "Price giving a stated revenue under linear demand; choose the root by a condition", "Medium",
  "Multi-step word problem",
  r"A cafe sells $400$ cups of coffee a day at Rs. $60$ a cup. Each increase of Rs. $5$ in the price reduces daily sales by $20$ cups, and the price is changed only in steps of Rs. $5$. The owner wants the daily coffee revenue to be exactly Rs. $25{,}200$ and, of the prices that achieve this, chooses the one at which more cups are sold. What price per cup, in rupees, does the owner choose?",
  "TITA",
  r"With $s$ increases of Rs. $5$, revenue is $(60 + 5s)(400 - 20s) = 100(12 + s)(20 - s)$. Setting this equal to $25200$ gives $(12 + s)(20 - s) = 252$, that is $s^2 - 8s + 12 = 0 = (s - 2)(s - 6)$. The price Rs. $70$ sells $360$ cups and Rs. $90$ sells $280$, so the owner chooses Rs. $70$.",
  "Picking the root that gives fewer sales, or confusing the target revenue with the maximum revenue.",
  "C10B-price-demand-target-revenue", "Revenue target gives a quadratic with two valid roots; a stated condition picks one.",
  tita_answer=70, check=_c8, values=[70],
  tita_traps=[(90, "Takes the other root $s = 6$, which sells fewer cups."),
              (80, "Gives the price of greatest revenue, midway between the two roots."),
              (62, "Treats the root $s = 2$ as a rise of Rs. $2$ rather than two steps of Rs. $5$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 009
def _c9():
    x = symbols('x', positive=True)
    sol = [s for s in solve(Eq(1 / x + 1 / (x - 5), Rational(1, 6)), x) if s > 5]
    return sol[0]
q("C10-B-009", T, "Two pipes, one faster by a fixed number of hours", "Medium",
  "Multi-step word problem",
  r"Two pipes P and Q, working together, fill an empty tank in $6$ hours. Working alone, pipe P takes $5$ hours less than pipe Q to fill the tank. How long does pipe Q alone take to fill the tank?",
  "MCQ",
  r"Let Q take $x$ hours, so P takes $x - 5$. Then $\frac{1}{x} + \frac{1}{x-5} = \frac{1}{6}$, so $6(2x - 5) = x(x-5)$, that is $x^2 - 17x + 30 = 0 = (x-15)(x-2)$. Since $x > 5$, $x = 15$ hours (P takes $10$).",
  "Reporting the faster pipe's time, or assuming each pipe alone takes twice the joint time.",
  "C10B-work-rates-quadratic", "Rate equation leads to a quadratic with one root to reject.",
  correct=r"$15$ hours",
  distractors=[(r"$10$ hours", "Reports the time of pipe P, $x - 5$."),
               (r"$12$ hours", "Assumes each pipe alone takes twice the joint time of $6$ hours."),
               (r"$20$ hours", "Treats the root $15$ as P's time and adds $5$ for Q.")],
  check=_c9, values=[15, 10, 12, 20], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c10():
    x = symbols('x', positive=True)
    s = [v for v in solve(Eq(x ** 2 + (x + 12) ** 2, 60 ** 2), x) if v > 0][0]
    return s + (s + 12) - 60
q("C10-B-010", T, "Diagonal of a rectangular field with sides differing by a given amount", "Medium",
  "Multi-step word problem",
  r"The diagonal of a rectangular field is $60$ m, and the longer side of the field exceeds the shorter side by $12$ m. Walking from one corner to the opposite corner along the diagonal, instead of along two adjacent sides, saves how many metres?",
  "TITA",
  r"With shorter side $x$, $x^2 + (x+12)^2 = 3600$, so $x^2 + 12x - 1728 = 0 = (x-36)(x+48)$. The sides are $36$ m and $48$ m, so the path along the sides is $84$ m and the saving is $84 - 60 = 24$ m.",
  "Reporting the length along the two sides instead of the saving.",
  "C10B-pythagoras-sides-quadratic", "Pythagoras gives a quadratic; the answer needs one more step.",
  tita_answer=24, check=_c10, values=[24],
  tita_traps=[(84, "Reports the distance along the two sides instead of the saving."),
              (36, "Reports the shorter side.")],
  cognitive="Application")

# ---------------------------------------------------------------- 011
def _c11():
    h, a = symbols('h a', positive=True)
    sols = solve([Eq(1 / h + 1 / a, Rational(1, 6)), Eq(h / 2 + a / 2, Rational(25, 2))], [h, a], dict=True)
    sols = [s for s in sols if s[h] < s[a]]
    return sols[0][a]
q("C10-B-011", T, "Joint time and half-and-half time determine individual times", "Medium",
  "Multi-step word problem",
  r"Harpreet and Ananya, working together, finish a job in $6$ days. If instead Harpreet did half the job alone and Ananya then did the other half alone, the job would take $12\frac{1}{2}$ days in all. Harpreet works faster than Ananya, and each works at a constant rate. How many days would Ananya alone take to finish the whole job?",
  "MCQ",
  r"Let Harpreet and Ananya alone take $h$ and $a$ days. Then $\frac{h}{2} + \frac{a}{2} = 12.5$, so $h + a = 25$, and $\frac{1}{h} + \frac{1}{a} = \frac{1}{6}$ gives $ha = 6(h+a) = 150$. So $h$ and $a$ are roots of $t^2 - 25t + 150 = 0$, namely $10$ and $15$. Ananya is slower, so she takes $15$ days.",
  "Mixing up the faster and slower worker, or treating the half-job time as the full-job time.",
  "C10B-work-rates-quadratic", "Two conditions combine into a sum and product, then a quadratic.",
  correct=r"$15$ days",
  distractors=[(r"$10$ days", "Reports Harpreet's time, the faster worker."),
               (r"$12$ days", "Assumes each person alone takes twice the joint time of $6$ days."),
               (r"$30$ days", "Treats $15$ as Ananya's time for half the job and doubles it.")],
  check=_c11, values=[15, 10, 12, 30], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 012
def _c12():
    sols = [kk for kk in range(4, 120) if (kk - 3) * (kk + 5 - 3) == 84]
    return sols[0]
q("C10-B-012", T, "Product of two ages some years ago", "Easy",
  "Multi-step word problem",
  r"Sneha is $5$ years older than her brother Kabir. Three years ago, the product of their ages (in years) was $84$. What is Kabir's present age, in years?",
  "TITA",
  r"Let Kabir be $k$ now. Three years ago the ages were $k - 3$ and $k + 2$, so $(k-3)(k+2) = 84$, that is $k^2 - k - 90 = 0 = (k-10)(k+9)$. Hence $k = 10$ (ages $7$ and $12$ three years ago).",
  "Reporting an age at the wrong time or the wrong person's age.",
  "C10B-ages-product", "One product equation, one factorable quadratic.",
  tita_answer=10, check=_c12, values=[10],
  tita_traps=[(7, "Reports Kabir's age three years ago."), (15, "Reports Sneha's present age.")],
  cognitive="Application")

# ---------------------------------------------------------------- 013
def _c13():
    d, t = symbols('d t', positive=True)
    D = [s for s in solve(Eq(d * (9 * (d - 4) + 4), 320), d) if s > 4][0]
    A = 9 * (D - 4) + 4
    return solve(Eq(A + t, 3 * (D + t)), t)[0]
q("C10-B-013", T, "Product of present ages with a past ratio, then a future ratio", "Medium",
  "Multi-step word problem",
  r"The product of the present ages of Arjun and his daughter is $320$. Four years ago, Arjun was $9$ times as old as his daughter. In how many years from now will Arjun be exactly $3$ times as old as his daughter?",
  "MCQ",
  r"Let the daughter be $d$ now. Then Arjun is $9(d-4) + 4 = 9d - 32$, and $d(9d - 32) = 320$ gives $9d^2 - 32d - 320 = 0 = (d - 8)(9d + 40)$. So $d = 8$ and Arjun is $40$. Then $40 + t = 3(8 + t)$ gives $t = 8$ years.",
  "Using the ages from four years ago as present ages, or reporting an age instead of the time.",
  "C10B-ages-product", "Three stages: a quadratic for present ages, then a linear future condition.",
  correct=r"$8$ years",
  distractors=[(r"$12$ years", "Uses the ages four years ago ($36$ and $4$) as present ages: $36 + t = 3(4 + t)$."),
               (r"$16$ years", "Reports the daughter's age at that time, $8 + 8$."),
               (r"$48$ years", "Reports Arjun's age at that time, $40 + 8$.")],
  check=_c13, values=[8, 12, 16, 48], cognitive="Application")

# ---------------------------------------------------------------- 014
def _c14():
    sols = [n for n in range(1, 200, 2) if n * n + (n + 2) ** 2 + (n + 4) ** 2 == 251]
    return sols[0] + 4
q("C10-B-014", T, "Sum of squares of consecutive odd numbers", "Easy",
  "Single-step computation",
  r"The sum of the squares of three consecutive odd natural numbers is $251$. What is the largest of the three numbers?",
  "TITA",
  r"Write the numbers as $m - 2$, $m$, $m + 2$. The sum of squares is $3m^2 + 8 = 251$, so $m^2 = 81$ and $m = 9$. The numbers are $7, 9, 11$ and the largest is $11$.",
  "Reporting the middle number found from the symmetric set-up.",
  "C10B-consecutive-integers-quadratic", "Symmetric choice of unknown makes the quadratic immediate.",
  tita_answer=11, check=_c14, values=[11],
  tita_traps=[(9, "Reports the middle number $m$."), (7, "Reports the smallest number.")],
  cognitive="Application")

# ---------------------------------------------------------------- 015
def _c15():
    m, kk = symbols('m kk', real=True)
    def pred(kv):
        # real roots for every m: the discriminant m^2 - 4(m + k) must never be negative
        disc = m ** 2 - 4 * (m + Rational(kv.numerator, kv.denominator))
        return minimum(disc, m) >= 0
    S = Interval(-oo, -1)
    pts = [F(-6) + F(12) * F(2 * i + 1, 2 * 301) + F(1, 1009) for i in range(301)] + [F(-1), F(-4)]
    for kv in pts:
        assert bool(pred(kv)) == bool(S.contains(Rational(kv.numerator, kv.denominator))), kv
    return S
q("C10-B-015", T, "Parameter for which a quadratic has real roots for every value of a second parameter", "Difficult",
  "Inverse/parameter",
  r"For what values of $k$ does the equation $x^2 + mx + (m + k) = 0$ have real roots for every real value of $m$?",
  "MCQ",
  r"The roots are real exactly when $m^2 - 4(m + k) \ge 0$. This must hold for every real $m$, so the upward parabola $m^2 - 4m - 4k$ in $m$ must never dip below zero, which means its own discriminant is not positive: $16 + 16k \le 0$, that is $k \le -1$. At $k = -1$ the expression is $(m - 2)^2 \ge 0$, so $k = -1$ is allowed.",
  "Applying the discriminant only once, or excluding the boundary where the roots are equal for one value of $m$.",
  "C10B-real-roots-for-all-parameter", "Two layers of discriminant: a condition in $x$ that must hold for all values of a second parameter.",
  correct=r"$k \le -1$",
  distractors=[(r"$k < -1$", "Excludes $k = -1$, although then $m^2 - 4m + 4 = (m-2)^2 \\ge 0$ for every $m$."),
               (r"$k \le -4$", "Expands $4(m + k)$ as $4m + k$, so needs $m^2 - 4m - k \\ge 0$ always: $16 + 4k \\le 0$."),
               (r"$k \ge -1$", "Requires the discriminant of $m^2 - 4m - 4k$ to be non-negative instead of non-positive.")],
  check=_c15,
  values=[Interval(-oo, -1), Interval.open(-oo, -1), Interval(-oo, -4), Interval(-1, oo)],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 016
def _c16():
    def pred(A):
        # sides are the roots of t^2 - 20 t + A = 0 (semi-perimeter 20)
        D = 400 - 4 * A
        if D <= 0:
            return False
        s = math.sqrt(float(D))
        lo, hi = (20 - s) / 2, (20 + s) / 2
        return lo > 0 and hi <= 3 * lo + 1e-12
    S = Interval.Ropen(75, 100)
    return _scan(S, pred, lo=1, hi=120, exact=(75, 100))
q("C10-B-016", T, "Ratio condition on the sides of a rectangle read as a condition on the roots", "Difficult",
  "Conceptual/application",
  r"A rectangular plot is to be enclosed by exactly $40$ m of fencing. Its length must be greater than its breadth but not more than three times its breadth. If the area of the plot is $A$ m$^2$, which of the following is the set of all possible values of $A$?",
  "MCQ",
  r"If the area is $A$, the length and breadth add to $20$, so they are the roots of $t^2 - 20t + A = 0$. Unequal sides need $400 - 4A > 0$, so $A < 100$. Writing the breadth as $b$, the length is $20 - b \le 3b$, so $5 \le b < 10$. On this range $A = b(20 - b)$ rises from $5 \times 15 = 75$ towards $100$. Hence $75 \le A < 100$.",
  "Ignoring one of the two conditions on the sides, or allowing the square.",
  "C10B-rectangle-sides-as-roots", "Turns a ratio bound on two unknown sides into a range for the product, with one endpoint excluded.",
  correct=r"$75 \le A < 100$",
  distractors=[(r"$75 \le A \le 100$", "Allows the square plot $10 \\times 10$, although the length must exceed the breadth."),
               (r"$0 < A < 100$", "Ignores the condition that the length is at most three times the breadth."),
               (r"$0 < A \le 75$", "Treats the extreme plot $15 \\times 5$ as the one of greatest area.")],
  check=_c16,
  values=[Interval.Ropen(75, 100), Interval(75, 100), Interval.open(0, 100), Interval.Lopen(0, 75)],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 017
def _c17():
    r = [v for v in solve(Eq(25 + 20 * t_ - 5 * t_ ** 2, 0), t_) if v > 0]
    return r[0]
q("C10-B-017", T, "Projectile launched from a height: time to reach the ground", "Easy",
  "Conceptual/application",
  r"A stone is thrown upwards from the top of a tower $25$ m high. Its height above the ground $t$ seconds later is $25 + 20t - 5t^2$ metres. After how many seconds does the stone hit the ground?",
  "MCQ",
  r"The stone is on the ground when $25 + 20t - 5t^2 = 0$, that is $t^2 - 4t - 5 = 0 = (t - 5)(t + 1)$. Time cannot be negative, so $t = 5$ seconds.",
  "Solving for the return to the launch height instead of the ground, or mis-factoring.",
  "C10B-projectile-from-height", "One quadratic with a negative root to reject.",
  correct=r"$5$ seconds",
  distractors=[(r"$4$ seconds", "Solves $20t - 5t^2 = 0$, the time to come back to the top of the tower."),
               (r"$2$ seconds", "Gives the time of the greatest height, $t = 2$."),
               (r"$1$ second", "Factorises $t^2 - 4t - 5$ as $(t + 5)(t - 1)$ and takes $t = 1$.")],
  check=_c17, values=[5, 4, 2, 1], cognitive="Understanding")

# ---------------------------------------------------------------- 018
def _c18():
    x = symbols('x', positive=True)
    ok = []
    for s in solve(Eq(x * (140 - 2 * x), 2400), x):
        along = 140 - 2 * s
        if 0 < along <= 70:
            ok.append(along)
    assert len(ok) == 1
    return ok[0]
q("C10-B-018", T, "Pen against a wall with given fencing and area; wall length decides the root", "Medium",
  "Multi-step word problem",
  r"A farmer uses exactly $140$ m of fencing to enclose a rectangular pen of area $2{,}400$ m$^2$ against a straight wall $70$ m long. One full side of the pen lies along the wall, so it needs no fencing, and the other three sides are fenced. What is the length, in metres, of the side of the pen that lies along the wall?",
  "TITA",
  r"Let each side perpendicular to the wall be $x$ m; the side along the wall is $140 - 2x$. Then $x(140 - 2x) = 2400$, that is $x^2 - 70x + 1200 = 0 = (x - 30)(x - 40)$. If $x = 30$ the side along the wall is $80$ m, longer than the wall, so $x = 40$ and the side along the wall is $60$ m.",
  "Keeping the root that needs a side longer than the wall, or reporting the perpendicular side.",
  "C10B-wall-pen-given-area", "Area and fencing give a quadratic with two roots; the wall length rules one out.",
  tita_answer=60, check=_c18, values=[60],
  tita_traps=[(80, "Uses the root $x = 30$, which needs $80$ m of wall."),
              (40, "Reports the side perpendicular to the wall.")],
  cognitive="Application")

# ---------------------------------------------------------------- 019
def _c19():
    k = symbols('k', positive=True)
    ks = set()
    for kv in solve(resultant(x_ ** 2 + k * x_ - 12, x_ ** 2 + 2 * k * x_ - 20, x_), k):
        if kv.is_real and kv > 0:
            e1 = set(solve(x_ ** 2 + kv * x_ - 12, x_))
            e2 = set(solve(x_ ** 2 + 2 * kv * x_ - 20, x_))
            if e1 & e2:
                ks.add(kv)
    assert len(ks) == 1
    return ks.pop()
q("C10-B-019", T, "Common root when the parameter appears in both linear coefficients", "Medium",
  "Inverse/parameter",
  r"The equations $x^2 + kx - 12 = 0$ and $x^2 + 2kx - 20 = 0$, where $k$ is a positive real number, have a common root. What is the value of $k$?",
  "TITA",
  r"Subtracting the first equation from the second gives $kx - 8 = 0$, so the common root is $x = \frac{8}{k}$. Substituting in the first, $\frac{64}{k^2} + 8 - 12 = 0$, so $k^2 = 16$ and, as $k > 0$, $k = 4$. Check: $x^2 + 4x - 12 = (x + 6)(x - 2)$ and $x^2 + 8x - 20 = (x + 10)(x - 2)$ share the root $2$.",
  "Reporting $k^2$ or the common root instead of $k$.",
  "C10B-common-root-parameter", "Elimination gives the common root in terms of $k$, then one substitution.",
  tita_answer=4, check=_c19, values=[4],
  tita_traps=[(16, "Reports $k^2 = 16$ instead of $k$."),
              (2, "Reports the common root $x = 2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 020
def _c20():
    x = symbols('x', positive=True)
    ok = [s for s in solve(Eq(x - x * x / 100, 24), x) if s * s / 100 > 20]
    assert len(ok) == 1
    return ok[0]
q("C10-B-020", T, "Discount rate numerically equal to the marked price", "Easy",
  "Multi-step word problem",
  r"A shopkeeper gives a discount whose percentage rate is numerically equal to the marked price of the article in rupees. An article sold under this offer for Rs. $24$, and the discount on it was more than Rs. $20$. What was the marked price of the article?",
  "MCQ",
  r"Let the marked price be Rs. $x$. The discount is $x\%$ of $x$, that is $\frac{x^2}{100}$, so $x - \frac{x^2}{100} = 24$, or $x^2 - 100x + 2400 = 0 = (x - 40)(x - 60)$. At Rs. $40$ the discount is only Rs. $16$; at Rs. $60$ it is Rs. $36$. So the marked price is Rs. $60$.",
  "Keeping the root that fails the stated condition on the discount.",
  "C10B-percent-equals-cost", "One quadratic with two positive roots; a stated condition selects one.",
  correct=r"Rs. $60$",
  distractors=[(r"Rs. $40$", "Takes the other root, for which the discount is only Rs. $16$."),
               (r"Rs. $20$", "Adds the discount: $x + \\frac{x^2}{100} = 24$ gives $x = 20$."),
               (r"Rs. $36$", "Reports the discount, $60 - 24$, instead of the marked price.")],
  check=_c20, values=[60, 40, 20, 36], cognitive="Application")

# ---------------------------------------------------------------- 021
def _c21():
    S = _iset((k_ ** 2 - 5 * k_ + 4) < 0)
    def pred(kk):
        r = _real_roots(1, kk - 3, kk * kk - 5 * kk + 4)
        return len(r) == 2 and r[0] < 0 < r[1]
    return _scan(S, pred, exact=(1, 4))
q("C10-B-021", T, "Roots of opposite signs, parameter in the constant term", "Easy",
  "Conceptual/application",
  r"For what values of $k$ does the equation $x^2 + (k - 3)x + (k^2 - 5k + 4) = 0$ have one positive root and one negative root?",
  "MCQ",
  r"With leading coefficient $1$, the roots have opposite signs exactly when their product is negative: $k^2 - 5k + 4 = (k-1)(k-4) < 0$, so $1 < k < 4$. A negative product also guarantees real roots, so no other condition is needed.",
  "Adding unnecessary conditions on the sum, or including the values that make a root zero.",
  "C10B-roots-opposite-signs", "Recognising that a negative product alone decides the case.",
  correct=r"$1 < k < 4$",
  distractors=[(r"$1 \le k \le 4$", "Allows the product to be zero, where one root is $0$."),
               (r"$k < 1$ or $k > 4$", "Requires a positive product, which gives roots of the same sign."),
               (r"$1 < k < 3$", "Also demands a positive sum $3 - k > 0$, which is not required.")],
  check=_c21,
  values=[Interval.open(1, 4), Interval(1, 4), Union(Interval.open(-oo, 1), Interval.open(4, oo)), Interval.open(1, 3)],
  cognitive="Understanding")

# ---------------------------------------------------------------- 022
def _c22():
    S = _iset((k_ + 5) / (k_ - 2) < 0)
    def pred(kk):
        if kk == 2:
            return False
        r = _real_roots(kk - 2, 3, kk + 5)
        return len(r) == 2 and r[0] < 0 < r[1]
    return _scan(S, pred, exact=(-5, 2))
q("C10-B-022", T, "Roots of opposite signs with a parameter in the leading coefficient", "Medium",
  "Conceptual/application",
  r"For what values of $k$ ($k \ne 2$) does the equation $(k - 2)x^2 + 3x + (k + 5) = 0$ have one positive root and one negative root?",
  "MCQ",
  r"The roots have opposite signs exactly when their product $\frac{k+5}{k-2}$ is negative, which also guarantees real roots. The quotient is negative when $k + 5$ and $k - 2$ have opposite signs, so $-5 < k < 2$.",
  "Assuming the leading coefficient is positive and testing only the sign of the constant term.",
  "C10B-roots-opposite-signs", "The leading coefficient changes sign with $k$, so the product must be used as a quotient.",
  correct=r"$-5 < k < 2$",
  distractors=[(r"$k < -5$", "Assumes the leading coefficient is positive and requires only $k + 5 < 0$."),
               (r"$k < -5$ or $k > 2$", "Requires the product to be positive, which gives roots of the same sign."),
               (r"$-2 < k < 5$", "Takes the critical values with the wrong signs, $k = 5$ and $k = -2$.")],
  check=_c22,
  values=[Interval.open(-5, 2), Interval.open(-oo, -5), Union(Interval.open(-oo, -5), Interval.open(2, oo)), Interval.open(-2, 5)],
  cognitive="Understanding")

# ---------------------------------------------------------------- 023
def _c23():
    cnt = 0
    for kk in range(-100, 101):
        r = _real_roots(1, -2 * (kk - 1), kk * kk - 7 * kk - 18)
        if len(r) == 2 and r[0] < 0 < r[1] and abs(r[1]) > abs(r[0]) + 1e-12:
            cnt += 1
    return cnt
q("C10-B-023", T, "Opposite-sign roots with the positive root larger in magnitude, integer count", "Medium",
  "Casework/optimisation",
  r"For how many integer values of $k$ does the equation $x^2 - 2(k - 1)x + (k^2 - 7k - 18) = 0$ have one positive and one negative root, with the positive root larger in absolute value than the negative root?",
  "TITA",
  r"Opposite signs need a negative product: $k^2 - 7k - 18 = (k-9)(k+2) < 0$, so $-2 < k < 9$. The positive root is larger in size exactly when the sum $2(k-1)$ is positive, so $k > 1$. Hence $k = 2, 3, \ldots, 8$, which is $7$ values.",
  "Ignoring the magnitude condition, or allowing a zero sum.",
  "C10B-roots-opposite-signs", "Combines the product condition with a sum condition and integer counting.",
  tita_answer=7, check=_c23, values=[7],
  tita_traps=[(10, "Ignores the magnitude condition and counts $k = -1, \\ldots, 8$."),
              (8, "Includes $k = 1$, where the roots are equal in size.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 024
def _c24():
    S = Intersection(_iset(4 * k_ ** 2 - 4 * (k_ + 6) > 0), _iset(2 * k_ > 0), _iset(k_ + 6 > 0))
    def pred(kk):
        r = _real_roots(1, -2 * kk, kk + 6)
        return _distinct_count(1, -2 * kk, kk + 6) == 2 and r[0] > 0
    return _scan(S, pred, exact=(3, -2, 0, -6))
q("C10-B-024", T, "Both roots positive and distinct", "Medium",
  "Inverse/parameter",
  r"For what values of $k$ does the equation $x^2 - 2kx + (k + 6) = 0$ have two distinct positive real roots?",
  "MCQ",
  r"Distinct real roots need $k^2 - (k + 6) > 0$, that is $(k-3)(k+2) > 0$, so $k < -2$ or $k > 3$. Both roots positive needs sum $2k > 0$ and product $k + 6 > 0$. Together these give $k > 3$.",
  "Omitting one of the three conditions (discriminant, sum, product), or allowing equal roots.",
  "C10B-both-roots-positive", "Three simultaneous conditions must all be applied.",
  correct=r"$k > 3$",
  distractors=[(r"$k < -2$ or $k > 3$", "Uses only the condition for distinct real roots."),
               (r"$-6 < k < -2$ or $k > 3$", "Checks the discriminant and the product but not the sum."),
               (r"$k \ge 3$", "Allows equal roots at $k = 3$.")],
  check=_c24,
  values=[Interval.open(3, oo), Union(Interval.open(-oo, -2), Interval.open(3, oo)),
          Union(Interval.open(-6, -2), Interval.open(3, oo)), Interval(3, oo)],
  cognitive="Application")

# ---------------------------------------------------------------- 025
def _c25():
    a = k_
    f2 = 4 - 4 * a + a ** 2 + a - 3
    S = Intersection(_iset(3 - a > 0), _iset(a > 2), _iset(f2 > 0))
    def pred(kk):
        c = kk * kk + kk - 3
        r = _real_roots(1, -2 * kk, c)
        return _distinct_count(1, -2 * kk, c) == 2 and r[0] > 2
    return _scan(S, pred, lo=-5, hi=6, exact=(3, 2))
q("C10-B-025", T, "Both roots greater than a given number", "Difficult",
  "Inverse/parameter",
  r"For what values of $a$ does the equation $x^2 - 2ax + (a^2 + a - 3) = 0$ have two distinct real roots, each greater than $2$?",
  "MCQ",
  r"Let $f(x) = x^2 - 2ax + a^2 + a - 3$. Distinct roots: $\frac{D}{4} = 3 - a > 0$, so $a < 3$. Both roots exceed $2$ when the vertex $a > 2$ and $f(2) > 0$: $f(2) = a^2 - 3a + 1 > 0$ gives $a < \frac{3-\sqrt{5}}{2}$ or $a > \frac{3+\sqrt{5}}{2}$. With $2 < a < 3$ this leaves $\frac{3+\sqrt{5}}{2} < a < 3$.",
  "Using only some of the three conditions (discriminant, vertex position, sign of $f(2)$).",
  "C10B-both-roots-beyond-number", "Three location conditions, one with surd boundaries, must be intersected.",
  correct=r"$\frac{3+\sqrt{5}}{2} < a < 3$",
  distractors=[(r"$2 < a < 3$", "Uses the discriminant and the vertex but not the sign of $f(2)$."),
               (r"$a > \frac{3+\sqrt{5}}{2}$", "Uses the vertex and $f(2) > 0$ but not the discriminant."),
               (r"$2 < a < \frac{3+\sqrt{5}}{2}$", "Requires $f(2) < 0$, the condition for $2$ to lie between the roots.")],
  check=_c25,
  values=[Interval.open((3 + sqrt(5)) / 2, 3), Interval.open(2, 3), Interval.open((3 + sqrt(5)) / 2, oo),
          Interval.open(2, (3 + sqrt(5)) / 2)],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 026
def _c26():
    cnt = 0
    for m in range(-12, 13):
        if _distinct_count(1, -(m + 3), 9) == 2 and min(_real_roots(1, -(m + 3), 9)) > 0:
            cnt += 1
    return cnt
q("C10-B-026", T, "Count of integer parameters giving two distinct positive roots", "Medium",
  "Casework/optimisation",
  r"For how many integers $m$ with $-12 \le m \le 12$ does the equation $x^2 - (m + 3)x + 9 = 0$ have two distinct positive real roots?",
  "TITA",
  r"Distinct real roots need $(m+3)^2 > 36$, so $m + 3 > 6$ or $m + 3 < -6$, that is $m > 3$ or $m < -9$. The product $9$ is positive, so both roots are positive exactly when the sum $m + 3 > 0$. That leaves $m > 3$: $m = 4, \ldots, 12$, which is $9$ values.",
  "Forgetting the sign of the sum, or allowing equal roots.",
  "C10B-both-roots-positive", "Discriminant and sum conditions with integer counting in a range.",
  tita_answer=9, check=_c26, values=[9],
  tita_traps=[(12, "Uses only the discriminant and also counts $m = -12, -11, -10$, where both roots are negative."),
              (10, "Includes $m = 3$, where the roots are equal.")],
  cognitive="Application")

# ---------------------------------------------------------------- 027
def _c27():
    p = k_
    S = _iset(1 + p - 6 < 0)
    def pred(kk):
        r = _real_roots(1, kk, -6)
        return len(r) == 2 and r[0] < 1 < r[1]
    return _scan(S, pred, exact=(5,))
q("C10-B-027", T, "A given number lies between the roots", "Easy",
  "Conceptual/application",
  r"For what values of $p$ does the number $1$ lie strictly between the two roots of $x^2 + px - 6 = 0$?",
  "MCQ",
  r"For an upward parabola $f(x) = x^2 + px - 6$, a number lies strictly between the roots exactly when $f$ is negative there. $f(1) = 1 + p - 6 = p - 5 < 0$ gives $p < 5$.",
  "Using the wrong sign of $f(1)$, or evaluating $f(1)$ carelessly.",
  "C10B-number-between-roots", "Single sign test at the given point.",
  correct=r"$p < 5$",
  distractors=[(r"$p > 5$", "Requires $f(1) > 0$, which puts $1$ outside the roots."),
               (r"$p > -5$", "Evaluates $f(1)$ as $1 - p - 6$ and then requires it to be negative."),
               (r"$p < 6$", "Evaluates $f(1)$ as $p - 6$, dropping the $x^2$ term.")],
  check=_c27, values=[Interval.open(-oo, 5), Interval.open(5, oo), Interval.open(-5, oo), Interval.open(-oo, 6)],
  cognitive="Understanding")

# ---------------------------------------------------------------- 028
def _c28():
    a = k_
    S = _iset((a - 1) * (4 * (a - 1) - 2 * (a + 1) + a + 4) < 0)
    def pred(kk):
        if kk == 1:
            return False
        r = _real_roots(kk - 1, -(kk + 1), kk + 4)
        return len(r) == 2 and r[0] < 2 < r[1]
    return _scan(S, pred, lo=-5, hi=5, exact=(F(2, 3), 1))
q("C10-B-028", T, "A given number lies between the roots; leading coefficient varies", "Medium",
  "Inverse/parameter",
  r"For what values of $a$ ($a \ne 1$) does the number $2$ lie strictly between the roots of $(a - 1)x^2 - (a + 1)x + (a + 4) = 0$?",
  "MCQ",
  r"For $f(x) = (a-1)x^2 - (a+1)x + (a+4)$, the number $2$ lies between the roots exactly when $(a-1) f(2) < 0$. Here $f(2) = 4(a-1) - 2(a+1) + a + 4 = 3a - 2$, so $(a-1)(3a-2) < 0$, giving $\frac{2}{3} < a < 1$.",
  "Testing only $f(2) < 0$, which is valid only when the leading coefficient is positive.",
  "C10B-number-between-roots", "Needs the general test $a f(2) < 0$ because the parabola can open downward.",
  correct=r"$\frac{2}{3} < a < 1$",
  distractors=[(r"$a < \frac{2}{3}$", "Requires only $f(2) < 0$, assuming the parabola opens upward."),
               (r"$a > \frac{2}{3}$", "Requires $f(2) > 0$, assuming the parabola opens downward."),
               (r"$a < \frac{2}{3}$ or $a > 1$", "Requires $(a-1) f(2) > 0$, which places $2$ outside the roots.")],
  check=_c28,
  values=[Interval.open(Rational(2, 3), 1), Interval.open(-oo, Rational(2, 3)), Interval.open(Rational(2, 3), oo),
          Union(Interval.open(-oo, Rational(2, 3)), Interval.open(1, oo))],
  cognitive="Application", exams=HARD)

# ---------------------------------------------------------------- 029
def _c29():
    f = lambda xx: xx ** 2 + 2 * k_ * xx + k_ - 4
    S = Intersection(_iset(f(-1) < 0), _iset(f(2) < 0))
    def pred(kk):
        r = _real_roots(1, 2 * kk, kk - 4)
        return len(r) == 2 and r[0] < -1 and r[1] > 2
    return _scan(S, pred, exact=(-3, 0))
q("C10-B-029", T, "Two given numbers both lie between the roots", "Medium",
  "Inverse/parameter",
  r"For what values of $k$ do both the numbers $-1$ and $2$ lie strictly between the roots of $x^2 + 2kx + (k - 4) = 0$?",
  "MCQ",
  r"For the upward parabola $f(x) = x^2 + 2kx + k - 4$, both numbers lie between the roots exactly when $f(-1) < 0$ and $f(2) < 0$. $f(-1) = 1 - 2k + k - 4 = -k - 3 < 0$ gives $k > -3$; $f(2) = 4 + 4k + k - 4 = 5k < 0$ gives $k < 0$. So $-3 < k < 0$.",
  "Applying only one of the two sign conditions, or reasoning from the vertex alone.",
  "C10B-number-between-roots", "Two sign conditions must hold together.",
  correct=r"$-3 < k < 0$",
  distractors=[(r"$k > -3$", "Uses only $f(-1) < 0$."),
               (r"$k < 0$", "Uses only $f(2) < 0$."),
               (r"$-2 < k < 1$", "Requires only the vertex $-k$ to lie between $-1$ and $2$.")],
  check=_c29, values=[Interval.open(-3, 0), Interval.open(-3, oo), Interval.open(-oo, 0), Interval.open(-2, 1)],
  cognitive="Application")

# ---------------------------------------------------------------- 030
def _c30():
    S = _iset((k_ - 3) * (3 * k_ + 5) < 0)
    def pred(kk):
        r = _real_roots(1, kk, -4)
        return sum(1 for v in r if 1 < v < 3) == 1
    return _scan(S, pred, exact=(3, F(-5, 3)))
q("C10-B-030", T, "Exactly one root in an open interval", "Medium",
  "Inverse/parameter",
  r"For what values of $k$ does the equation $x^2 + kx - 4 = 0$ have exactly one root strictly between $1$ and $3$?",
  "MCQ",
  r"The product of the roots is $-4 < 0$, so the roots have opposite signs and at most one lies in $(1, 3)$. Exactly one lies there when $f(1) f(3) < 0$, with $f(1) = k - 3$ and $f(3) = 3k + 5$. So $(k - 3)(3k + 5) < 0$, giving $-\frac{5}{3} < k < 3$. At the endpoints a root sits at $1$ or $3$, outside the open interval.",
  "Testing only one endpoint, or reversing the sign condition.",
  "C10B-one-root-in-interval", "Sign change across the interval plus a check that both roots cannot lie inside.",
  correct=r"$-\frac{5}{3} < k < 3$",
  distractors=[(r"$k < -\frac{5}{3}$ or $k > 3$", "Requires $f(1) f(3) > 0$, the condition for no sign change."),
               (r"$k < 3$", "Uses only $f(1) < 0$ and ignores the other endpoint."),
               (r"$-3 < k < \frac{5}{3}$", "Takes the critical values with the wrong signs.")],
  check=_c30,
  values=[Interval.open(Rational(-5, 3), 3), Union(Interval.open(-oo, Rational(-5, 3)), Interval.open(3, oo)),
          Interval.open(-oo, 3), Interval.open(-3, Rational(5, 3))],
  cognitive="Application")

# ---------------------------------------------------------------- 031
def _c31():
    cnt = 0
    for m in range(-100, 101):
        r = _real_roots(1, -2 * m, m * m - 1)
        if sum(1 for v in r if -2 < v < 4) == 1:
            cnt += 1
    return cnt
q("C10-B-031", T, "Integer parameters for exactly one root in an interval, with endpoint cases", "Difficult",
  "Casework/optimisation",
  r"For how many integer values of $m$ does the equation $x^2 - 2mx + m^2 - 1 = 0$ have exactly one root strictly between $-2$ and $4$?",
  "TITA",
  r"The equation is $(x - m)^2 = 1$, so the roots are $m - 1$ and $m + 1$. The root $m - 1$ is in $(-2, 4)$ for $-1 < m < 5$; the root $m + 1$ is in $(-2, 4)$ for $-3 < m < 3$. Exactly one is inside when $m$ satisfies one condition but not the other: $-3 < m \le -1$ or $3 \le m < 5$. The integers are $-2, -1, 3, 4$, so $4$ values.",
  "Using only the sign test $f(-2) f(4) < 0$, which misses cases where the other root sits on an endpoint.",
  "C10B-one-root-in-interval", "Endpoint cases make the standard sign test incomplete; needs casework on explicit roots.",
  tita_answer=4, check=_c31, values=[4],
  tita_traps=[(2, "Uses only $f(-2) f(4) < 0$, which misses $m = -1$ and $m = 3$ where one root is exactly on an endpoint."),
              (7, "Counts $m$ with at least one root inside, $m = -2, \\ldots, 4$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 032
def _c32():
    f = lambda xx: xx ** 2 - 2 * k_ * xx + 2 * k_ + 3
    S = Intersection(_iset(k_ ** 2 - (2 * k_ + 3) > 0), _iset(k_ > 0), _iset(k_ < 5), _iset(f(0) > 0), _iset(f(5) > 0))
    def pred(kk):
        r = _real_roots(1, -2 * kk, 2 * kk + 3)
        return _distinct_count(1, -2 * kk, 2 * kk + 3) == 2 and 0 < r[0] and r[1] < 5
    return _scan(S, pred, lo=-5, hi=8, exact=(3, F(7, 2)))
q("C10-B-032", T, "Both roots inside an interval", "Difficult",
  "Inverse/parameter",
  r"For what values of $k$ does the equation $x^2 - 2kx + (2k + 3) = 0$ have two distinct real roots, both strictly between $0$ and $5$?",
  "MCQ",
  r"Let $f(x) = x^2 - 2kx + 2k + 3$. Distinct roots: $k^2 - 2k - 3 = (k-3)(k+1) > 0$, so $k < -1$ or $k > 3$. Vertex inside: $0 < k < 5$. End values positive: $f(0) = 2k + 3 > 0$ and $f(5) = 28 - 8k > 0$, so $-\frac{3}{2} < k < \frac{7}{2}$. All together: $3 < k < \frac{7}{2}$.",
  "Omitting one of the four conditions for both roots to lie in an interval.",
  "C10B-both-roots-in-interval", "Four conditions (discriminant, vertex, two end values) must be intersected.",
  correct=r"$3 < k < \frac{7}{2}$",
  distractors=[(r"$0 < k < \frac{7}{2}$", "Omits the discriminant condition."),
               (r"$3 < k < 5$", "Omits the condition $f(5) > 0$."),
               (r"$-\frac{3}{2} < k < -1$ or $3 < k < \frac{7}{2}$", "Omits the condition that the vertex lies between $0$ and $5$.")],
  check=_c32,
  values=[Interval.open(3, Rational(7, 2)), Interval.open(0, Rational(7, 2)), Interval.open(3, 5),
          Union(Interval.open(Rational(-3, 2), -1), Interval.open(3, Rational(7, 2)))],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 033
def _c33():
    m = symbols('m')
    vals = set()
    for r in solve(x_ ** 2 - 7 * x_ + 12, x_):
        vals |= set(solve(r ** 2 + m * r - 24, m))
    return sum(vals)
q("C10-B-033", T, "Common root with a fully known equation", "Easy",
  "Inverse/parameter",
  r"The equations $x^2 - 7x + 12 = 0$ and $x^2 + mx - 24 = 0$ have a common root. What is the sum of all possible values of $m$?",
  "TITA",
  r"The first equation has roots $3$ and $4$. If $3$ is common, $9 + 3m - 24 = 0$ gives $m = 5$. If $4$ is common, $16 + 4m - 24 = 0$ gives $m = 2$. The sum is $5 + 2 = 7$.",
  "Checking only one root of the first equation as the possible common root.",
  "C10B-common-root-parameter", "Two short cases, one for each root of the known equation.",
  tita_answer=7, check=_c33, values=[7],
  tita_traps=[(5, "Tries only the root $3$."), (2, "Tries only the root $4$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 034
def _c34():
    res = set()
    for kk in range(-50, 51):
        e1 = Poly(x_ ** 2 - 3 * x_ + kk, x_)
        e2 = Poly(x_ ** 2 - kk * x_ + 3, x_)
        r1 = set(r for r in roots(e1, x_) if r.is_real)
        r2 = set(r for r in roots(e2, x_) if r.is_real)
        common = r1 & r2
        if len(common) == 1:
            c = list(common)[0]
            res.add(sum(r1 - {c}) + sum(r2 - {c}))
    assert len(res) == 1
    return res.pop()
q("C10-B-034", T, "Exactly one common root, then the remaining roots", "Medium",
  "Inverse/parameter",
  r"For a real number $k$, the equations $x^2 - 3x + k = 0$ and $x^2 - kx + 3 = 0$ have exactly one common root. What is the sum of the two roots that are not common?",
  "MCQ",
  r"Subtracting the equations gives $(k - 3)x + (k - 3) = 0$. If $k = 3$ the equations are identical (and have no real roots), so $k \ne 3$ and the common root is $x = -1$. Then $1 + 3 + k = 0$ gives $k = -4$. The equations are $(x-4)(x+1) = 0$ and $(x+1)(x+3) = 0$, so the other roots are $4$ and $-3$, with sum $1$.",
  "Stopping at the value of $k$, or mis-solving the second equation once $k$ is known.",
  "C10B-common-root-parameter", "Standard elimination by subtraction, then one further step to the remaining roots.",
  correct=r"$1$",
  distractors=[(r"$-4$", "Stops at $k = -4$ and reports it."),
               (r"$0$", "Adds all three distinct roots, $4 - 1 - 3$."),
               (r"$7$", "Takes the roots of $x^2 + 4x + 3 = 0$ as $1$ and $3$, so the other roots are $4$ and $3$.")],
  check=_c34, values=[1, -4, 0, 7], cognitive="Analysis")

# ---------------------------------------------------------------- 035
def _c35():
    a, b = symbols('a b')
    r = Rational(1, 3)
    sol = solve([Eq(a - 1, r * 12), Eq(-6, r * (b + 1))], [a, b], dict=True)[0]
    # confirm the two equations really have the same real roots
    assert set(solve(x_ ** 2 + (sol[a] - 1) * x_ - 6, x_)) == set(solve(3 * x_ ** 2 + 12 * x_ + sol[b] + 1, x_))
    return sol[a] - sol[b]
q("C10-B-035", T, "Both roots common: coefficients proportional", "Medium",
  "Conceptual/application",
  r"The equations $x^2 + (a - 1)x - 6 = 0$ and $3x^2 + 12x + (b + 1) = 0$ have both their roots in common. What is the value of $a - b$?",
  "MCQ",
  r"Two quadratics with the same two roots differ only by a constant factor, so $\frac{1}{3} = \frac{a-1}{12} = \frac{-6}{b+1}$. Hence $a - 1 = 4$, $a = 5$, and $b + 1 = -18$, $b = -19$. So $a - b = 5 + 19 = 24$.",
  "Inverting the ratio, or equating $a$ and $b$ directly to the scaled coefficients.",
  "C10B-both-roots-common", "Recognising the proportional-coefficient principle.",
  correct=r"$24$",
  distractors=[(r"$22$", "Sets $a = 4$ and $b = -18$, ignoring the $-1$ and $+1$ attached to $a$ and $b$."),
               (r"$40$", "Uses the ratio $3$ instead of $\\frac{1}{3}$: $a - 1 = 36$, $b + 1 = -2$."),
               (r"$23$", "Handles the shift in $a$ but sets $b = -18$.")],
  check=_c35, values=[24, 22, 40, 23], cognitive="Understanding")

# ---------------------------------------------------------------- 036
def _c36():
    k = symbols('k', real=True)
    sols = set()
    for kv in range(-50, 51):
        if _distinct_count(1, kv - 1, 9) == 1:
            sols.add(kv)
    assert sols == set(solve(Eq((k - 1) ** 2 - 36, 0), k))
    return FiniteSet(*sols)
q("C10-B-036", T, "Parameter values giving equal roots", "Easy",
  "Conceptual/application",
  r"For what values of $k$ does the equation $x^2 + (k - 1)x + 9 = 0$ have two equal real roots?",
  "MCQ",
  r"Equal roots need a zero discriminant: $(k - 1)^2 - 36 = 0$, so $k - 1 = 6$ or $k - 1 = -6$, giving $k = 7$ or $k = -5$. Both work: the equations become $(x + 3)^2 = 0$ and $(x - 3)^2 = 0$.",
  "Keeping only the positive square root, or dropping the factor $4$ in the discriminant.",
  "C10B-equal-roots-parameter", "One discriminant condition; both signs of the square root must be kept.",
  correct=r"$k = 7$ or $k = -5$",
  distractors=[(r"$k = 7$ only", "Takes only the positive square root, $k - 1 = 6$."),
               (r"$k = 5$ or $k = -7$", "Writes the discriminant as $(k + 1)^2 - 36$, a sign slip in the middle coefficient."),
               (r"$k = 4$ or $k = -2$", "Drops the factor $4$: $(k - 1)^2 = 9$.")],
  check=_c36,
  values=[FiniteSet(7, -5), FiniteSet(7), FiniteSet(5, -7), FiniteSet(4, -2)],
  cognitive="Understanding")

# ---------------------------------------------------------------- 037
def _c37():
    S = _iset(1 - 2 * k_ > 0) & _iset(k_ > 0)
    def pred(kk):
        if kk == 0:
            return False
        a, b, c = kk, -2 * (kk + 1), kk + 4
        r = _real_roots(a, b, c)
        return _distinct_count(a, b, c) == 2 and r[0] > 1
    return _scan(S, pred, lo=-6, hi=6, exact=(0, F(1, 2), -1))
q("C10-B-037", T, "Both roots greater than a number when the leading coefficient varies", "Difficult",
  "Inverse/parameter",
  r"For what values of $k$ does the equation $kx^2 - 2(k + 1)x + (k + 4) = 0$ have two distinct real roots, both greater than $1$?",
  "MCQ",
  r"Two roots need $k \ne 0$. Distinct roots: $\frac{D}{4} = (k+1)^2 - k(k + 4) = 1 - 2k > 0$, so $k < \frac{1}{2}$. With $f(x) = kx^2 - 2(k+1)x + k + 4$, we have $f(1) = 2$. Both roots exceed $1$ only if $1$ lies outside the roots on the left: $k f(1) = 2k > 0$ and the vertex $\frac{k + 1}{k} > 1$, both giving $k > 0$. If $k < 0$, then $k f(1) < 0$ and $1$ lies between the roots. Hence $0 < k < \frac{1}{2}$.",
  "Checking the sign of $f(1)$ without the sign of the leading coefficient, or omitting the discriminant.",
  "C10B-both-roots-beyond-number", "The leading coefficient can be negative, so the sign test must use $k f(1)$; three conditions combine.",
  correct=r"$0 < k < \frac{1}{2}$",
  distractors=[(r"$k < \frac{1}{2}$, $k \ne 0$", "Checks only the discriminant: treats $f(1) = 2 > 0$ as automatically satisfied without multiplying by $k$, and skips the vertex condition, so keeps $k < \\frac{1}{2}$, $k \\ne 0$."),
               (r"$k > 0$", "Uses the vertex and $k f(1) > 0$ but not the discriminant."),
               (r"$k > \frac{1}{2}$", "Writes the discriminant as $2k - 1$ and requires it positive.")],
  check=_c37,
  values=[Interval.open(0, Rational(1, 2)), Union(Interval.open(-oo, 0), Interval.open(0, Rational(1, 2))),
          Interval.open(0, oo), Interval.open(Rational(1, 2), oo)],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 038
def _c38():
    c = symbols('c')
    mn = minimum(2 * x_ ** 2 - 12 * x_ + c, x_)
    mx = maximum(-x_ ** 2 + 4 * x_ + 1, x_)
    return solve(Eq(mn, mx), c)[0]
q("C10-B-038", T, "Least value of one quadratic equals greatest value of another", "Easy",
  "Inverse/parameter",
  r"The least value of $2x^2 - 12x + c$ over all real $x$ equals the greatest value of $-x^2 + 4x + 1$ over all real $x$. What is the value of $c$?",
  "TITA",
  r"$2x^2 - 12x + c = 2(x - 3)^2 + c - 18$, with least value $c - 18$. $-x^2 + 4x + 1 = 5 - (x - 2)^2$, with greatest value $5$. So $c - 18 = 5$ and $c = 23$.",
  "Completing the square without the leading coefficient $2$.",
  "C10B-extreme-value-parameter", "Two completions of the square and one linear equation.",
  tita_answer=23, check=_c38, values=[23],
  tita_traps=[(14, "Writes the least value as $c - 9$, ignoring the factor $2$."),
              (19, "Takes the greatest value of $-x^2 + 4x + 1$ as $1$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 039
def _c39():
    cnt = 0
    for kk in range(-10, 11):
        r = _real_roots(1, -2 * kk, kk + 2)
        if any(v > 1e-12 for v in r):
            cnt += 1
    return cnt
q("C10-B-039", T, "Count of integer parameters giving at least one positive root", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ with $-10 \le k \le 10$ does the equation $x^2 - 2kx + (k + 2) = 0$ have at least one positive real root?",
  "TITA",
  r"Real roots need $k^2 - k - 2 = (k-2)(k+1) \ge 0$, so $k \le -1$ or $k \ge 2$. If the product $k + 2 < 0$ (that is $k < -2$) the roots have opposite signs, so one is positive: $k = -10, \ldots, -3$, which is $8$ values. At $k = -2$ the roots are $0$ and $-4$; at $k = -1$ the only root is $-1$. For $k \ge 2$ the sum $2k$ and product $k + 2$ are positive, so both roots are positive: $k = 2, \ldots, 10$, which is $9$ values. Total $17$.",
  "Missing the opposite-sign case, or counting the boundary values $k = -2$ and $k = -1$.",
  "C10B-at-least-one-positive-root", "Casework over the sign of the product with boundary values that fail.",
  tita_answer=17, check=_c39, values=[17],
  tita_traps=[(19, "Counts every $k$ with real roots, including $k = -2$ and $k = -1$."),
              (9, "Counts only the case where both roots are positive."),
              (18, "Includes $k = -2$, where the roots are $0$ and $-4$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 040
def _c40():
    w = symbols('w', positive=True)
    sol = [s for s in solve(Eq(3 * (2 * w - 6) * (w - 6), 648), w) if s > 6]
    return sol[0]
q("C10-B-040", T, "Open box folded from a sheet with corners cut out", "Medium",
  "Multi-step word problem",
  r"A rectangular metal sheet is twice as long as it is wide. A square of side $3$ cm is cut from each corner and the sides are folded up to form an open box of volume $648$ cm$^3$. What is the width of the sheet?",
  "MCQ",
  r"With width $w$, the box is $(2w - 6)$ by $(w - 6)$ by $3$. So $3(2w - 6)(w - 6) = 648$, that is $(w - 3)(w - 6) = 108$, or $w^2 - 9w - 90 = 0 = (w - 15)(w + 6)$. Hence $w = 15$ cm.",
  "Reporting a dimension of the box, or the length of the sheet, instead of the sheet's width.",
  "C10B-open-box-volume", "Volume condition reduces to a quadratic after factoring out constants.",
  correct=r"$15$ cm",
  distractors=[(r"$9$ cm", "Reports the width of the box, $w - 6$."),
               (r"$24$ cm", "Reports the length of the box, $2w - 6$."),
               (r"$30$ cm", "Reports the length of the sheet, $2w$.")],
  check=_c40, values=[15, 9, 24, 30], cognitive="Application")

# ---------------------------------------------------------------- 041
def _c41():
    x = symbols('x', positive=True)
    return [s for s in solve(Eq(x + x * x / 100, 144), x) if s > 0][0]
q("C10-B-041", T, "Gain percent numerically equal to the cost price", "Medium",
  "Multi-step word problem",
  r"A trader sells an article for Rs. $144$ and makes a gain. The gain percent on the cost price is numerically equal to the cost price in rupees. What is the cost price?",
  "MCQ",
  r"Let the cost price be Rs. $x$. The gain is $x\%$ of $x$, that is $\frac{x^2}{100}$, so $x + \frac{x^2}{100} = 144$, or $x^2 + 100x - 14400 = 0 = (x - 80)(x + 180)$. Hence $x = 80$ (gain $80\%$, that is Rs. $64$).",
  "Treating the gain as $x$ rupees rather than $x$ percent, or dropping the linear term.",
  "C10B-percent-equals-cost", "Translating the percent condition gives a quadratic in the cost.",
  correct=r"Rs. $80$",
  distractors=[(r"Rs. $120$", "Writes $\\frac{x^2}{100} = 144$, dropping the cost from the selling price."),
               (r"Rs. $64$", "Reports the gain in rupees, $144 - 80$."),
               (r"Rs. $72$", "Treats the gain as Rs. $x$, so $2x = 144$.")],
  check=_c41, values=[80, 120, 64, 72], cognitive="Application")

# ---------------------------------------------------------------- 042
def _c42():
    x = symbols('x')
    cnt = 0
    for kk in range(-10, 11):
        sols = solve(Eq((kk - 2) * x ** 2 - 2 * kk * x + (kk + 3), 0), x)
        pos = {s for s in sols if s.is_real and s > 0}
        if len(pos) == 1:
            cnt += 1
    return cnt
q("C10-B-042", T, "Count of parameters giving exactly one positive solution, leading coefficient varies", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ with $-10 \le k \le 10$ does the equation $(k - 2)x^2 - 2kx + (k + 3) = 0$ have exactly one positive real solution? A repeated root counts as a single solution, and for $k = 2$ the equation is linear.",
  "TITA",
  r"For $k = 2$ the equation is $-4x + 5 = 0$, with the positive solution $\frac{5}{4}$. Otherwise $\frac{D}{4} = k^2 - (k-2)(k+3) = 6 - k$, so real roots need $k \le 6$. At $k = 6$ the equation is $(2x - 3)^2 = 0$, one positive solution. For $k < 6$, $k \ne 2$, the roots are distinct with product $\frac{k+3}{k-2}$ and sum $\frac{2k}{k-2}$. The product is negative for $-3 < k < 2$, giving one positive root: $k = -2, -1, 0, 1$. At $k = -3$ the roots are $0$ and $\frac{6}{5}$, again one positive. For $k < -3$ or $2 < k < 6$ the product and sum are both positive, so both roots are positive. The values are $-3, -2, -1, 0, 1, 2, 6$: in all $7$.",
  "Counting only the opposite-sign case and missing the linear, zero-root and repeated-root cases.",
  "C10B-at-least-one-positive-root", "Casework on the leading coefficient, the sign of the product, a zero root and a repeated root.",
  tita_answer=7, check=_c42, values=[7],
  tita_traps=[(4, "Counts only $k = -2, -1, 0, 1$, where the product of the roots is negative."),
              (6, "Leaves out $k = 2$, where the equation is linear with the positive root $\\frac{5}{4}$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 043
def _c43():
    a = k_
    f = lambda xx: xx ** 2 - 2 * a * xx + 4
    S = Intersection(_iset(a ** 2 - 4 > 0), _iset(a > 1), _iset(a < 4), _iset(f(1) > 0), _iset(f(4) > 0))
    def pred(kk):
        r = _real_roots(1, -2 * kk, 4)
        return _distinct_count(1, -2 * kk, 4) == 2 and r[0] > 1 and r[1] < 4
    return _scan(S, pred, lo=-6, hi=6, exact=(2, F(5, 2)))
q("C10-B-043", T, "Both roots inside an interval, fixed product", "Difficult",
  "Inverse/parameter",
  r"For what values of $a$ does the equation $x^2 - 2ax + 4 = 0$ have two distinct real roots, both strictly between $1$ and $4$?",
  "MCQ",
  r"Let $f(x) = x^2 - 2ax + 4$. Distinct roots: $a^2 > 4$, so $a < -2$ or $a > 2$. Vertex inside: $1 < a < 4$. End values positive: $f(1) = 5 - 2a > 0$ and $f(4) = 20 - 8a > 0$, both giving $a < \frac{5}{2}$. Together: $2 < a < \frac{5}{2}$.",
  "Leaving out the discriminant, the vertex condition, or the end-value conditions.",
  "C10B-both-roots-in-interval", "Four conditions with one redundant pair; the vertex condition removes a spurious branch.",
  correct=r"$2 < a < \frac{5}{2}$",
  distractors=[(r"$2 < a < 4$", "Uses the discriminant and the vertex but not the end values."),
               (r"$1 < a < \frac{5}{2}$", "Uses the vertex and the end values but not the discriminant."),
               (r"$a < -2$ or $2 < a < \frac{5}{2}$", "Uses the discriminant and the end values but not the vertex.")],
  check=_c43,
  values=[Interval.open(2, Rational(5, 2)), Interval.open(2, 4), Interval.open(1, Rational(5, 2)),
          Union(Interval.open(-oo, -2), Interval.open(2, Rational(5, 2)))],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 044
def _c44():
    def nroots(kk):
        xs = set()
        for tt in _real_roots(1, -4, kk):
            if tt > 1e-12:
                xs.add(round(tt, 9)); xs.add(round(-tt, 9))
            elif abs(tt) <= 1e-12:
                xs.add(0.0)
        return len(xs)
    S = Union(Interval.open(-oo, 0), FiniteSet(4))
    return _scan(S, lambda kk: nroots(kk) == 2, exact=(0, 4))
q("C10-B-044", T, "Number of real roots of a quadratic in the absolute value", "Difficult",
  "Casework/optimisation",
  r"For what values of $k$ does the equation $x^2 - 4|x| + k = 0$ have exactly two distinct real roots?",
  "MCQ",
  r"Put $t = |x| \ge 0$, so $t^2 - 4t + k = 0$. Each positive $t$ gives two values of $x$, and $t = 0$ gives one. If $k < 0$, the $t$-roots have opposite signs, so one positive $t$ gives $2$ roots. If $k = 0$, $t = 0, 4$ gives $3$ roots. If $0 < k < 4$, two positive $t$ give $4$ roots. If $k = 4$, $t = 2$ (double) gives $2$ roots. If $k > 4$ there are none. So $k < 0$ or $k = 4$.",
  "Missing the repeated-root case $k = 4$, or treating $k = 0$ as giving two roots.",
  "C10B-modulus-substitution-root-count", "Substitution followed by casework on the sign and multiplicity of the $t$-roots.",
  correct=r"$k < 0$ or $k = 4$",
  distractors=[(r"$k < 0$", "Misses $k = 4$, where the double root $t = 2$ gives $x = \\pm 2$."),
               (r"$k \le 0$ or $k = 4$", "Counts $k = 0$, where $t = 0$ and $t = 4$ give three roots $0, \\pm 4$."),
               (r"$0 < k < 4$", "Gives the range for two distinct $t$-roots, which actually yields four values of $x$.")],
  check=_c44,
  values=[Union(Interval.open(-oo, 0), FiniteSet(4)), Interval.open(-oo, 0),
          Union(Interval(-oo, 0), FiniteSet(4)), Interval.open(0, 4)],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 045
def _c45():
    other = (2 * k_ - 1) / (k_ + 1)
    assert simplify((k_ + 1) - 3 * k_ + (2 * k_ - 1)) == 0      # x = 1 is always a root
    S = Intersection(_iset(other > 1), _iset(other < 2))
    def pred(kk):
        if kk == -1:
            return False
        r = _real_roots(kk + 1, -3 * kk, 2 * kk - 1)
        return sum(1 for v in r if 1 + 1e-9 < v < 2 - 1e-9) >= 1
    return _scan(S, pred, exact=(2, F(1, 2)))
q("C10-B-045", T, "Root in an interval when one endpoint is always a root", "Difficult",
  "Conceptual/application",
  r"For what values of $k$ ($k \ne -1$) does the equation $(k + 1)x^2 - 3kx + (2k - 1) = 0$ have a root strictly between $1$ and $2$?",
  "MCQ",
  r"The coefficients add to $(k + 1) - 3k + (2k - 1) = 0$, so $x = 1$ is always a root and the sign test $f(1) f(2) < 0$ cannot be used. The other root is the product $\frac{2k - 1}{k + 1}$. We need $\frac{2k-1}{k+1} - 1 = \frac{k - 2}{k + 1} > 0$ and $\frac{2k-1}{k+1} - 2 = \frac{-3}{k + 1} < 0$. The second gives $k > -1$, and then the first gives $k > 2$.",
  "Applying only one of the two bounds on the other root.",
  "C10B-one-root-in-interval", "The usual sign test fails because $1$ is always a root; the other root must be located directly.",
  correct=r"$k > 2$",
  distractors=[(r"$k > -1$", "Uses only the condition that the other root is less than $2$."),
               (r"$k < -1$ or $k > 2$", "Uses only the condition that the other root is greater than $1$."),
               (r"$k > \frac{1}{2}$", "Requires only that the other root be positive and less than $2$.")],
  check=_c45,
  values=[Interval.open(2, oo), Interval.open(-1, oo), Union(Interval.open(-oo, -1), Interval.open(2, oo)),
          Interval.open(Rational(1, 2), oo)],
  cognitive="Analysis", exams=HARD)
