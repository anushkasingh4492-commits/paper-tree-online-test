import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

X = symbols('x')
DX = ("CAT", "XAT")
T = "Polynomials"


def _comp(poly):
    """Companion matrix of a polynomial in X (made monic)."""
    p = Poly(poly, X)
    c = [co / p.LC() for co in p.all_coeffs()]
    n = p.degree()
    M = zeros(n, n)
    for i in range(1, n):
        M[i, i - 1] = 1
    for i in range(n):
        M[i, n - 1] = -c[n - i]
    return M


def _powsum(poly, k):
    M = _comp(poly)
    return nsimplify((M ** k).trace())


# 001
def _c1():
    P = 4*X**3 + 2*X**2 - 6*X + 5
    return rem(P, 2*X + 1, X)
q("C10-C-001", T, "Remainder on division by a linear divisor with leading coefficient other than 1", "Easy",
  "Single-step computation",
  r"Kavya divides $P(x) = 4x^3 + 2x^2 - 6x + 5$ by $2x + 1$. What is the remainder?",
  "MCQ",
  r"By the remainder theorem the remainder on division by $2x + 1$ is $P\left(-\frac{1}{2}\right)$. This equals $4\left(-\frac{1}{8}\right) + 2\left(\frac{1}{4}\right) - 6\left(-\frac{1}{2}\right) + 5 = -\frac{1}{2} + \frac{1}{2} + 3 + 5 = 8$.",
  "Substituting the wrong value of $x$ for the divisor $2x + 1$.",
  "C10C-remainder-linear-divisor", r"One substitution, but the divisor's root is $-\frac{1}{2}$, not an integer.",
  correct=r"$8$",
  distractors=[(r"$3$", r"Uses $x = \frac{1}{2}$: $P\left(\frac{1}{2}\right) = \frac{1}{2} + \frac{1}{2} - 3 + 5 = 3$."),
               (r"$9$", r"Treats the divisor as $x + 1$ and computes $P(-1) = -4 + 2 + 6 + 5 = 9$."),
               (r"$-7$", r"Reads the root of $2x + 1$ as $-2$: $P(-2) = -32 + 8 + 12 + 5 = -7$.")],
  check=_c1, values=[8, 3, 9, -7], cognitive="Application")

# 002
def _c2():
    # several polynomials leaving remainder 4 on x - 3; remainder of P(2x+1) on x - 1
    outs = set()
    for Q in [7, X**2 + 1, X**3 - 2*X, -5*X + 3]:
        P = expand((X - 3)*Q + 4)
        assert rem(P, X - 3, X) == 4
        outs.add(rem(expand(P.subs(X, 2*X + 1)), X - 1, X))
    assert len(outs) == 1
    return outs.pop()
q("C10-C-002", T, "Remainder of a composed polynomial P(2x+1) using a known remainder of P(x)", "Easy",
  "Conceptual/application",
  r"When a polynomial $P(x)$ is divided by $x - 3$, the remainder is $4$. What is the remainder when $P(2x + 1)$ is divided by $x - 1$?",
  "TITA",
  r"The remainder when $P(2x + 1)$ is divided by $x - 1$ is the value of $P(2x + 1)$ at $x = 1$, which is $P(3)$. Since $P(x)$ leaves remainder $4$ on division by $x - 3$, $P(3) = 4$. So the remainder is $4$.",
  "Applying the substitution $2x + 1$ to the remainder itself instead of to the input of $P$.",
  "C10C-remainder-linear-divisor", "One idea: evaluate the composed polynomial at the divisor's root.",
  tita_answer=4, check=_c2,
  tita_traps=[(9, r"Applies $2x + 1$ to the remainder: $2(4) + 1 = 9$."),
              (8, r"Thinks the coefficient $2$ in $2x + 1$ scales the remainder: $2 \times 4 = 8$.")],
  cognitive="Understanding")

# 003
def _c3():
    k = symbols('k')
    P = 2*X**3 - k*X**2 + 3*X + 10
    return solve(Eq(rem(P, X - 2, X), 0), k)[0]
q("C10-C-003", T, "Factor theorem: find the parameter that makes x - 2 a factor", "Easy",
  "Inverse/parameter",
  r"For a certain number $k$, $x - 2$ is a factor of $2x^3 - kx^2 + 3x + 10$. What is the value of $k$?",
  "TITA",
  r"By the factor theorem the polynomial vanishes at $x = 2$: $2(8) - 4k + 6 + 10 = 0$, so $32 - 4k = 0$ and $k = 8$.",
  "Substituting $x = -2$ for the factor $x - 2$, or dropping the leading coefficient.",
  "C10C-factor-theorem-parameter", "Single substitution and a linear equation in $k$.",
  tita_answer=8, check=_c3,
  tita_traps=[(-3, r"Substitutes $x = -2$: $-16 - 4k - 6 + 10 = 0$ gives $k = -3$."),
              (6, r"Uses $x^3$ in place of $2x^3$: $8 - 4k + 16 = 0$ gives $k = 6$.")],
  cognitive="Application")

# 004
def _c4():
    a, b = symbols('a b')
    P = X**4 + a*X**3 + b*X**2 - 5*X + 6
    s = solve([P.subs(X, 1), P.subs(X, 2)], [a, b], dict=True)[0]
    Pn = P.subs(s)
    assert rem(Pn, X**2 - 3*X + 2, X) == 0
    return len(set(real_roots(Pn)))
q("C10-C-004", T, "Two unknown coefficients from a quadratic factor, then count real roots", "Medium",
  "Multi-step word problem",
  r"The polynomial $P(x) = x^4 + ax^3 + bx^2 - 5x + 6$ is exactly divisible by $x^2 - 3x + 2$. How many distinct real roots does the equation $P(x) = 0$ have?",
  "TITA",
  r"Since $x^2 - 3x + 2 = (x - 1)(x - 2)$, we need $P(1) = 0$ and $P(2) = 0$. These give $a + b = -2$ and $8a + 4b = -12$, so $a = -1$ and $b = -1$. Then $P(x) = (x^2 - 3x + 2)(x^2 + 2x + 3)$, and $x^2 + 2x + 3$ has discriminant $4 - 12 < 0$. So the only real roots are $1$ and $2$: $2$ distinct real roots.",
  "Assuming a quartic with two known real roots must have four real roots.",
  "C10C-factor-then-count-real-roots", "Two conditions give two linear equations, then a division and a discriminant check.",
  tita_answer=2, check=_c4,
  tita_traps=[(4, r"Assumes the other quadratic factor $x^2 + 2x + 3$ also has two real roots."),
              (3, r"Writes the cofactor as $x^2 + 2x - 3$ (sign slip in its constant term, which must satisfy $2c = 6$); this factors as $(x + 3)(x - 1)$ and gives the distinct roots $1$, $2$, $-3$.")],
  cognitive="Application")

# 005
def _c5():
    a, b, c = symbols('a b c')
    e = expand(a*(X - 1)**2 + b*(X - 1) + c - (2*X**2 - 3*X + 5))
    s = solve(Poly(e, X).all_coeffs(), [a, b, c], dict=True)[0]
    return s[a] + s[b] + s[c]
q("C10-C-005", T, "Polynomial identity: sum of coefficients in a shifted form via a clever substitution", "Easy",
  "Conceptual/application",
  r"Constants $a$, $b$ and $c$ satisfy $2x^2 - 3x + 5 = a(x - 1)^2 + b(x - 1) + c$ for every real $x$. The value of $a + b + c$ is",
  "MCQ",
  r"Choose $x$ so that $x - 1 = 1$, that is $x = 2$. Then the right side becomes $a + b + c$, and the left side is $2(4) - 6 + 5 = 7$. So $a + b + c = 7$. (Indeed $a = 2$, $b = 1$, $c = 4$.)",
  "Substituting $x = 1$, which gives only $c$, or adding the coefficients of the original polynomial.",
  "C10C-identity-coefficient-matching", "One well-chosen substitution in an identity.",
  correct=r"$7$",
  distractors=[(r"$4$", r"Adds the coefficients of the left side, $2 - 3 + 5 = 4$, which equals $c$ (the value at $x = 1$)."),
               (r"$5$", r"Substitutes $x = 0$, getting $a - b + c = 5$, and takes it as $a + b + c$."),
               (r"$10$", r"Substitutes $x = -1$, getting $4a - 2b + c = 10$, and takes it as $a + b + c$.")],
  check=_c5, values=[7, 4, 5, 10], cognitive="Understanding")

# 006
def _c6():
    p, qq, r = symbols('p q r')
    e = expand((X**2 + p*X + 3)*(X**2 + qq*X + 5) - (X**4 + 2*X**3 + r*X**2 + 4*X + 15))
    s = solve(Poly(e, X).all_coeffs(), [p, qq, r], dict=True)
    return s[0][r]
q("C10-C-006", T, "Matching coefficients of a product of two quadratics", "Medium",
  "Inverse/parameter",
  r"For constants $p$, $q$ and $r$, the identity $(x^2 + px + 3)(x^2 + qx + 5) = x^4 + 2x^3 + rx^2 + 4x + 15$ holds for all real $x$. What is the value of $r$?",
  "MCQ",
  r"Comparing the $x^3$ terms: $p + q = 2$. Comparing the $x$ terms: $5p + 3q = 4$. Solving, $2p = 4 - 6 = -2$, so $p = -1$ and $q = 3$. The $x^2$ coefficient is $r = 5 + 3 + pq = 8 - 3 = 5$.",
  "Forgetting the cross term $pq$ in the $x^2$ coefficient, or its sign.",
  "C10C-identity-coefficient-matching", "Needs two coefficient equations solved together before the third is read off.",
  correct=r"$5$",
  distractors=[(r"$8$", r"Takes the $x^2$ coefficient as $3 + 5$, leaving out $pq$."),
               (r"$11$", r"Uses $pq = +3$ (sign slip in $p$), so $r = 8 + 3$."),
               (r"$-3$", r"Reports $pq$ alone as the $x^2$ coefficient.")],
  check=_c6, values=[5, 8, 11, -3], cognitive="Application")

# 007
def _c7():
    P = expand((2*X - 1)**5 * (X + 3)**2)
    return sum(Poly(P, X).all_coeffs())
q("C10-C-007", T, "Sum of coefficients of an expanded product", "Easy",
  "Single-step computation",
  r"When $(2x - 1)^5 (x + 3)^2$ is expanded as a polynomial in $x$, the sum of all its coefficients is",
  "MCQ",
  r"The sum of the coefficients of a polynomial $P(x)$ is $P(1)$. Here $P(1) = (2 - 1)^5 (1 + 3)^2 = 1 \times 16 = 16$.",
  "Confusing the sum of coefficients with the constant term or the leading coefficient.",
  "C10C-coefficient-sums", "Single substitution once the $P(1)$ idea is known.",
  correct=r"$16$",
  distractors=[(r"$3888$", r"Ignores the minus sign in $2x - 1$ and evaluates $(2 + 1)^5 (1 + 3)^2 = 243 \times 16 = 3888$."),
               (r"$-9$", r"Computes the constant term $P(0) = (-1)^5 \times 9 = -9$."),
               (r"$32$", r"Reports the leading coefficient $2^5 = 32$.")],
  check=_c7, values=[16, 3888, -9, 32], cognitive="Recall")

# 008
def _c8():
    P = Poly(expand((X**2 - X + 2)**4), X)
    return sum(c for (m,), c in P.terms() if m % 2 == 0)
q("C10-C-008", T, "Sum of coefficients of even powers using P(1) and P(-1)", "Medium",
  "Multi-step word problem",
  r"Let $P(x) = (x^2 - x + 2)^4$. When $P(x)$ is expanded, the sum of the coefficients of all the even powers of $x$ (including the constant term) is",
  "MCQ",
  r"Let $E$ and $O$ be the sums of the coefficients of even and odd powers. Then $P(1) = E + O = 2^4 = 16$ and $P(-1) = E - O = 4^4 = 256$. So $E = \frac{16 + 256}{2} = 136$.",
  "Mixing up which combination of $P(1)$ and $P(-1)$ isolates the even terms, or forgetting to halve.",
  "C10C-coefficient-sums", "Two evaluations combined; the sign of $-1$ raised to odd and even powers must be tracked.",
  correct=r"$136$",
  distractors=[(r"$-120$", r"Computes $\frac{P(1) - P(-1)}{2} = \frac{16 - 256}{2}$, which is the odd-power sum."),
               (r"$272$", r"Uses $P(1) + P(-1) = 272$ without dividing by $2$."),
               (r"$128$", r"Takes $\frac{P(-1)}{2} = 128$, leaving out $P(1)$.")],
  check=_c8, values=[136, -120, 272, 128], cognitive="Application")

# 009
def _c9():
    return _powsum(2*X**3 - 5*X**2 + 3*X - 7, 2)
q("C10-C-009", T, "Sum of squares of the roots of a non-monic cubic", "Easy",
  "Single-step computation",
  r"If $\alpha$, $\beta$ and $\gamma$ are the roots of $2x^3 - 5x^2 + 3x - 7 = 0$, then $\alpha^2 + \beta^2 + \gamma^2$ equals",
  "MCQ",
  r"By Vieta, $\alpha + \beta + \gamma = \frac{5}{2}$ and $\alpha\beta + \beta\gamma + \gamma\alpha = \frac{3}{2}$. So $\alpha^2 + \beta^2 + \gamma^2 = \frac{25}{4} - 2 \times \frac{3}{2} = \frac{25}{4} - 3 = \frac{13}{4}$.",
  "Forgetting the factor $2$, the sign, or dividing only one Vieta sum by the leading coefficient.",
  "C10C-cubic-vieta-power-sums", "One identity plus Vieta, with a leading coefficient to divide by.",
  correct=r"$\frac{13}{4}$",
  distractors=[(r"$\frac{19}{4}$", r"Uses $(\alpha + \beta + \gamma)^2 - (\alpha\beta + \beta\gamma + \gamma\alpha) = \frac{25}{4} - \frac{3}{2}$, dropping the factor $2$."),
               (r"$\frac{37}{4}$", r"Adds instead of subtracting: $\frac{25}{4} + 2 \times \frac{3}{2}$."),
               (r"$\frac{1}{4}$", r"Divides the sum of roots by $2$ but takes the pairwise sum as $3$: $\frac{25}{4} - 6$.")],
  check=_c9, values=[Rational(13, 4), Rational(19, 4), Rational(37, 4), Rational(1, 4)], cognitive="Application")

# 010
def _c10():
    return _powsum(X**3 - 2*X**2 - 5*X + 3, 3)
q("C10-C-010", T, "Sum of cubes of the roots of a cubic via Vieta", "Medium",
  "Multi-step word problem",
  r"If $p$, $q$ and $r$ are the roots of $x^3 - 2x^2 - 5x + 3 = 0$, then $p^3 + q^3 + r^3$ equals",
  "MCQ",
  r"Here $p + q + r = 2$, $pq + qr + rp = -5$ and $pqr = -3$. Using $p^3 + q^3 + r^3 = (p+q+r)^3 - 3(p+q+r)(pq+qr+rp) + 3pqr$, we get $8 - 3(2)(-5) + 3(-3) = 8 + 30 - 9 = 29$.",
  "Dropping the $3pqr$ term or taking the wrong sign of the product of the roots.",
  "C10C-cubic-vieta-power-sums", "Needs the three-variable cube identity and careful signs from Vieta.",
  correct=r"$29$",
  distractors=[(r"$38$", r"Uses $p^3 + q^3 + r^3 = (p+q+r)^3 - 3(p+q+r)(pq+qr+rp)$, omitting $3pqr$."),
               (r"$47$", r"Takes $pqr = +3$, so the last term becomes $+9$."),
               (r"$-31$", r"Takes $pq + qr + rp = +5$: $8 - 3(2)(5) + 3(-3) = 8 - 30 - 9 = -31$.")],
  check=_c10, values=[29, 38, 47, -31], cognitive="Application")

# 011
def _c11():
    M = _comp(X**3 - 4*X**2 + 6*X - 2)
    return nsimplify(M.inv().trace())
q("C10-C-011", T, "Sum of reciprocals of the roots of a cubic", "Easy",
  "Single-step computation",
  r"If $a$, $b$ and $c$ are the roots of $x^3 - 4x^2 + 6x - 2 = 0$, then $\frac{1}{a} + \frac{1}{b} + \frac{1}{c}$ equals",
  "MCQ",
  r"$\frac{1}{a} + \frac{1}{b} + \frac{1}{c} = \frac{ab + bc + ca}{abc}$. By Vieta, $ab + bc + ca = 6$ and $abc = 2$, so the value is $\frac{6}{2} = 3$.",
  "Using the sum of roots in the numerator, or a sign slip in the product.",
  "C10C-cubic-vieta-power-sums", "One identity and two Vieta values.",
  correct=r"$3$",
  distractors=[(r"$-3$", r"Takes $abc = -2$, reading the constant term's sign directly."),
               (r"$2$", r"Uses $\frac{a + b + c}{abc} = \frac{4}{2}$."),
               (r"$6$", r"Stops at the numerator $ab + bc + ca = 6$.")],
  check=_c11, values=[3, -3, 2, 6], cognitive="Application")

# 012
def _c12():
    # product of (1 + root) over the roots of a monic P = resultant(P, x + 1)
    P = X**3 - 5*X**2 + 7*X - 2
    return resultant(P, X + 1, X)
q("C10-C-012", T, "Product (1+a)(1+b)(1+c) for the roots of a cubic via its value at -1", "Medium",
  "Conceptual/application",
  r"If $a$, $b$ and $c$ are the roots of $x^3 - 5x^2 + 7x - 2 = 0$, the value of $(1 + a)(1 + b)(1 + c)$ is",
  "MCQ",
  r"Write $P(x) = x^3 - 5x^2 + 7x - 2 = (x - a)(x - b)(x - c)$. Then $P(-1) = (-1 - a)(-1 - b)(-1 - c) = -(1 + a)(1 + b)(1 + c)$. Since $P(-1) = -1 - 5 - 7 - 2 = -15$, the product is $15$. (Equivalently, $1 + (a+b+c) + (ab+bc+ca) + abc = 1 + 5 + 7 + 2 = 15$.)",
  "Missing the sign $(-1)^3$, or using $P(1)$, which gives $(1-a)(1-b)(1-c)$.",
  "C10C-product-via-polynomial-value", "Spotting that the product is a value of the polynomial, with a sign to track.",
  correct=r"$15$",
  distractors=[(r"$-15$", r"Takes the product as $P(-1)$ itself, missing the factor $(-1)^3$."),
               (r"$1$", r"Uses $P(1) = 1$, which is $(1 - a)(1 - b)(1 - c)$."),
               (r"$11$", r"Expands $1 + (a+b+c) + (ab+bc+ca) + abc$ but takes $abc = -2$: $1 + 5 + 7 - 2$.")],
  check=_c12, values=[15, -15, 1, 11], cognitive="Understanding")

# 013
def _c13():
    P = X**3 - 2*X**2 + 3*X - 4
    return resultant(P, X**2 + 1, X)
q("C10-C-013", T, "Product of (root squared + 1) over the roots of a cubic", "Difficult",
  "Multi-step word problem",
  r"Let $\alpha$, $\beta$ and $\gamma$ be the roots of $x^3 - 2x^2 + 3x - 4 = 0$. Find the value of $(\alpha^2 + 1)(\beta^2 + 1)(\gamma^2 + 1)$.",
  "TITA",
  r"Expand: the product is $1 + \sum\alpha^2 + \sum\alpha^2\beta^2 + (\alpha\beta\gamma)^2$. With $s = 2$, $p = 3$, $r = 4$: $\sum\alpha^2 = s^2 - 2p = -2$, $\sum\alpha^2\beta^2 = p^2 - 2rs = 9 - 16 = -7$, and $r^2 = 16$. Total $1 - 2 - 7 + 16 = 8$. (Faster: with $P(x) = x^3 - 2x^2 + 3x - 4$ and $\alpha^2 + 1 = (\alpha - i)(\alpha + i)$, the product is $P(i)P(-i) = |{-2} + 2i|^2 = 8$.)",
  "Using $p^2 - 2r$ instead of $p^2 - 2rs$ for the sum of squared pairwise products.",
  "C10C-product-via-polynomial-value", "Several symmetric functions of three roots must be built and combined; negative intermediate values unsettle students.",
  tita_answer=8, check=_c13,
  tita_traps=[(16, r"Takes $\sum\alpha^2\beta^2 = p^2 - 2r = 1$: $1 - 2 + 1 + 16 = 16$."),
              (7, r"Drops the leading $1$ of the expansion: $-2 - 7 + 16 = 7$.")],
  exams=DX, cognitive="Analysis")

# 014
def _c14():
    m, d, k = symbols('m d k')
    roots = [m - d, m, m + d]
    eqs = [Eq(sum(roots), 12), Eq(roots[0]*roots[1]*roots[2], 28)]
    sols = solve(eqs, [m, d], dict=True)
    ks = set()
    for s in sols:
        rs = [r.subs(s) for r in roots]
        if all(rr.is_real for rr in rs):
            ks.add(simplify(rs[0]*rs[1] + rs[1]*rs[2] + rs[0]*rs[2]))
    assert len(ks) == 1
    return ks.pop()
q("C10-C-014", T, "Cubic with roots in arithmetic progression: find the middle coefficient", "Medium",
  "Inverse/parameter",
  r"The roots of $x^3 - 12x^2 + kx - 28 = 0$ are real and in arithmetic progression. What is the value of $k$?",
  "MCQ",
  r"Let the roots be $m - d$, $m$, $m + d$. Their sum $3m = 12$ gives $m = 4$. Their product $4(16 - d^2) = 28$ gives $d^2 = 9$, so the roots are $1$, $4$, $7$. Then $k = 1 \cdot 4 + 4 \cdot 7 + 7 \cdot 1 = 39$.",
  "Taking the product of the roots as $-28$, or reading $k$ off a wrong symmetric sum.",
  "C10C-cubic-roots-relation", "Needs the symmetric AP parametrisation and two Vieta relations.",
  correct=r"$39$",
  distractors=[(r"$25$", r"Uses product $= -28$: $4(16 - d^2) = -28$ gives $d^2 = 23$, and $k = 3(16) - d^2 = 25$."),
               (r"$48$", r"Assumes all three roots equal $4$, giving $k = 3 \times 16$."),
               (r"$66$", r"Adds the squares $1 + 16 + 49$ instead of the pairwise products.")],
  check=_c14, values=[39, 25, 48, 66], cognitive="Application")

# 015
def _c15():
    m, t = symbols('m t', positive=True)
    sols = solve([Eq(m**3, 64), Eq(m/t + m + m*t, 14)], [m, t], dict=True)
    ks = set()
    for s in sols:
        rs = [s[m]/s[t], s[m], s[m]*s[t]]
        ks.add(simplify(rs[0]*rs[1] + rs[1]*rs[2] + rs[0]*rs[2]))
    assert len(ks) == 1
    return ks.pop()
q("C10-C-015", T, "Cubic with roots in geometric progression: find the middle coefficient", "Medium",
  "Inverse/parameter",
  r"The equation $x^3 - 14x^2 + kx - 64 = 0$ has three positive real roots in geometric progression. What is the value of $k$?",
  "MCQ",
  r"Let the roots be $\frac{m}{t}$, $m$, $mt$. Their product is $m^3 = 64$, so $m = 4$. The pairwise sum is $m^2\left(\frac{1}{t} + 1 + t\right) = m \times \left(\frac{m}{t} + m + mt\right) = 4 \times 14 = 56$. So $k = 56$ (the roots are $2$, $4$, $8$).",
  "Assuming equal roots, or summing squares instead of pairwise products.",
  "C10C-cubic-roots-relation", "The GP parametrisation plus the observation that the pairwise sum is the middle root times the sum.",
  correct=r"$56$",
  distractors=[(r"$48$", r"Assumes all three roots equal the middle root $4$: $k = 3 \times 16$."),
               (r"$84$", r"Adds the squares $4 + 16 + 64$ instead of the pairwise products."),
               (r"$112$", r"Counts each pairwise product twice: $2(8 + 32 + 16)$.")],
  check=_c15, values=[56, 48, 84, 112], cognitive="Application")

# 016
def _c16():
    a, b, c = symbols('a b c')
    sols = solve([Eq(a, b + c), Eq(a + b + c, 10), Eq(a*b*c, 30)], [a, b, c], dict=True)
    ks = set(simplify(s[a]*s[b] + s[b]*s[c] + s[c]*s[a]) for s in sols)
    assert len(ks) == 1
    return ks.pop()
q("C10-C-016", T, "Cubic where one root equals the sum of the other two", "Medium",
  "Inverse/parameter",
  r"One root of $x^3 - 10x^2 + kx - 30 = 0$ is equal to the sum of the other two roots. What is the value of $k$?",
  "MCQ",
  r"If $a = b + c$, then $a + b + c = 2a = 10$, so $a = 5$. Then $bc = \frac{30}{5} = 6$ and $b + c = 5$. So $k = a(b + c) + bc = 25 + 6 = 31$.",
  "Leaving out the product $bc$ of the other two roots when forming the pairwise sum.",
  "C10C-cubic-roots-relation", "Combines the given relation with all three Vieta sums.",
  correct=r"$31$",
  distractors=[(r"$25$", r"Uses $k = a(b + c) = 25$, leaving out $bc$."),
               (r"$19$", r"Subtracts $bc$: $25 - 6$."),
               (r"$38$", r"With roots $5$, $2$, $3$ adds the squares $25 + 4 + 9$.")],
  check=_c16, values=[31, 25, 19, 38], cognitive="Application")

# 017
def _c17():
    k = symbols('k')
    for kv in range(-300, 301):
        rr = sorted(real_roots(X**4 - 30*X**2 + kv))
        if len(set(rr)) == 4:
            dif = [rr[i + 1] - rr[i] for i in range(3)]
            if simplify(dif[0] - dif[1]) == 0 and simplify(dif[1] - dif[2]) == 0:
                return kv
q("C10-C-017", T, "Biquadratic with four real roots in arithmetic progression", "Difficult",
  "Inverse/parameter",
  r"The equation $x^4 - 30x^2 + k = 0$ has four distinct real roots that are in arithmetic progression. What is the value of $k$?",
  "MCQ",
  r"The roots come in pairs $\pm u$, $\pm v$ with $0 < u < v$, so in increasing order they are $-v$, $-u$, $u$, $v$. Equal gaps force $v - u = 2u$, so $v = 3u$. As a quadratic in $x^2$, $u^2 + v^2 = 30$, so $10u^2 = 30$ and $u^2 = 3$. Then $k = u^2 v^2 = 3 \times 27 = 81$.",
  r"Taking the roots as $\pm u$, $\pm 2u$, which are not equally spaced.",
  "C10C-quartic-vieta", "Must convert the AP condition into $v = 3u$ through the symmetry of a biquadratic.",
  correct=r"$81$",
  distractors=[(r"$144$", r"Takes the roots as $\pm u$, $\pm 2u$: $5u^2 = 30$, $k = 6 \times 24$."),
               (r"$225$", r"Takes the two values of $x^2$ as equal, $15$ each, so $k = 225$."),
               (r"$-81$", r"Takes the product of the four roots as $-k$.")],
  check=_c17, values=[81, 144, 225, -81], exams=DX, cognitive="Analysis")

# 018
def _c18():
    a, b, c, k = symbols('a b c k')
    lhs = expand((X**2 - a*X + 6)*(X**2 - b*X + c))
    rhs = X**4 - 7*X**3 + k*X**2 - 2*X - 12
    sols = solve(Poly(lhs - rhs, X).all_coeffs(), [a, b, c, k], dict=True)
    ks = set(s[k] for s in sols)
    assert len(ks) == 1
    kv = ks.pop()
    # confirm two roots really have product 6
    rr = Poly(rhs.subs(k, kv), X).all_roots()
    assert any(simplify(rr[i]*rr[j] - 6) == 0 for i in range(4) for j in range(i + 1, 4))
    return kv
q("C10-C-018", T, "Quartic where the product of two roots is given: find a missing coefficient", "Difficult",
  "Inverse/parameter",
  r"Two of the four roots of $x^4 - 7x^3 + kx^2 - 2x - 12 = 0$ have product $6$. What is the value of $k$?",
  "MCQ",
  r"Pair the roots: $x^4 - 7x^3 + kx^2 - 2x - 12 = (x^2 - ax + 6)(x^2 - bx + c)$. The constant term gives $6c = -12$, so $c = -2$. The $x^3$ term gives $a + b = 7$, and the $x$ term gives $-ac - 6b = 2a - 6b = -2$. Solving, $a = 5$ and $b = 2$. The $x^2$ coefficient is $k = c + 6 + ab = -2 + 6 + 10 = 14$.",
  "Missing one of the three contributions to the $x^2$ coefficient of a product of two quadratics.",
  "C10C-quartic-vieta", "Requires setting up a factorisation into two quadratics and solving for three unknowns.",
  correct=r"$14$",
  distractors=[(r"$10$", r"Takes $k = ab$ only, leaving out $6 + c$."),
               (r"$4$", r"Takes $k = 6 + c$, leaving out the cross term $ab$."),
               (r"$18$", r"Finds $a = 5$, $b = 2$ and $c = -2$ correctly, but in the final sum writes the contribution of $c$ as $+2$: $2 + 6 + 10$.")],
  check=_c18, values=[14, 10, 4, 18], exams=DX, cognitive="Analysis")

# 019
def _c19():
    r = Integer(16) ** Rational(1, 4)
    assert 4 * r == 8  # AM equals GM, so all four roots are equal
    P = Poly(expand((X - r)**4), X)
    assert P.all_coeffs()[1] == -8 and P.all_coeffs()[4] == 16
    return P.all_coeffs()[2]
q("C10-C-019", T, "Quartic with all roots positive: AM equals GM forces equal roots", "Difficult",
  "Conceptual/application",
  r"The equation $x^4 - 8x^3 + ax^2 + bx + 16 = 0$ has four positive real roots (not necessarily distinct). What is the value of $a$?",
  "MCQ",
  r"The four roots have sum $8$ and product $16$. Their arithmetic mean is $2$ and their geometric mean is $16^{1/4} = 2$. Equality of the two means forces all four roots to equal $2$, so the polynomial is $(x - 2)^4 = x^4 - 8x^3 + 24x^2 - 32x + 16$. Hence $a = 24$.",
  "Not recognising that AM equal to GM pins every root, or expanding $(x-2)^4$ carelessly.",
  "C10C-quartic-vieta", "The key step is the AM-GM equality case, which is not a routine Vieta computation.",
  correct=r"$24$",
  distractors=[(r"$6$", r"Uses the binomial coefficient $\binom{4}{2} = 6$ without the factor $2^2$."),
               (r"$32$", r"Reads off the size of the coefficient of $x$ in $(x - 2)^4$."),
               (r"$-24$", r"Expands $(x - 2)^4$ with a sign slip, writing the $x^2$ term as $-24x^2$.")],
  check=_c19, values=[24, 6, 32, -24], exams=DX, cognitive="Analysis")

# 020
def _c20():
    a, b, c = symbols('a b c')
    P = X**3 + a*X**2 + b*X + c
    s = solve([P.subs(X, 1) - 3, P.subs(X, 2) - 5, P.subs(X, 3) - 7], [a, b, c], dict=True)[0]
    return P.subs(s).subs(X, 5)
q("C10-C-020", T, "Value of a monic cubic from three given values", "Medium",
  "Conceptual/application",
  r"$P(x)$ is a cubic polynomial with leading coefficient $1$ such that $P(1) = 3$, $P(2) = 5$ and $P(3) = 7$. What is the value of $P(5)$?",
  "TITA",
  r"The polynomial $P(x) - (2x + 1)$ is a monic cubic that vanishes at $x = 1, 2, 3$, so $P(x) = (x - 1)(x - 2)(x - 3) + 2x + 1$. Then $P(5) = 4 \times 3 \times 2 + 11 = 35$.",
  "Continuing the linear pattern $3, 5, 7$ and ignoring the cubic part.",
  "C10C-value-from-given-values", "Requires seeing the auxiliary polynomial $P(x) - (2x+1)$ with known roots.",
  tita_answer=35, check=_c20,
  tita_traps=[(11, r"Continues the pattern $3, 5, 7, 9, 11$ as if $P$ were linear."),
              (24, r"Uses only $(5 - 1)(5 - 2)(5 - 3)$ and forgets to add $2x + 1$.")],
  cognitive="Application")

# 021
def _c21():
    pts = [(k, Rational(1, k)) for k in range(1, 5)]
    P = interpolate(pts, X)
    assert Poly(P, X).degree() == 3
    return P.subs(X, 0)
q("C10-C-021", T, "Cubic taking reciprocal values at four points: value at zero", "Difficult",
  "Conceptual/application",
  r"$P(x)$ is a polynomial of degree $3$ such that $P(k) = \frac{1}{k}$ for $k = 1, 2, 3, 4$. What is the value of $P(0)$?",
  "MCQ",
  r"Let $Q(x) = xP(x) - 1$, a polynomial of degree $4$ with roots $1, 2, 3, 4$. So $Q(x) = c(x - 1)(x - 2)(x - 3)(x - 4)$, and $Q(0) = -1$ gives $24c = -1$, $c = -\frac{1}{24}$. Now $P(0)$ is the coefficient of $x$ in $Q(x)$, which is $c \times (-50) = \frac{50}{24} = \frac{25}{12}$ (since the $x$ coefficient of $(x-1)(x-2)(x-3)(x-4)$ is $-50$).",
  r"Trying to extend the pattern $\frac{1}{k}$ to $k = 0$, or picking the wrong coefficient of $Q(x)$.",
  "C10C-value-from-given-values", "Requires constructing $xP(x) - 1$ and reading a non-leading coefficient of a product of four factors.",
  correct=r"$\frac{25}{12}$",
  distractors=[(r"$-\frac{25}{12}$", r"Takes $c = +\frac{1}{24}$, a sign slip in $Q(0) = -1$."),
               (r"$-\frac{35}{24}$", r"Uses the $x^2$ coefficient $35$ of the product instead of the $x$ coefficient $-50$: $35 \times \left(-\frac{1}{24}\right)$."),
               (r"$\frac{25}{48}$", r"Gets the correct $1 + \frac{1}{2} + \frac{1}{3} + \frac{1}{4}$ but then divides by $4$, treating it as an average.")],
  check=_c21, values=[Rational(25, 12), Rational(-25, 12), Rational(-35, 24), Rational(25, 48)], exams=DX, cognitive="Analysis")

# 022
def _c22():
    return len(set(real_roots(X**4 - 5*X**2 - 36)))
q("C10-C-022", T, "Number of real roots of a biquadratic", "Easy",
  "Single-step computation",
  r"How many real roots does the equation $x^4 - 5x^2 - 36 = 0$ have?",
  "TITA",
  r"Put $t = x^2$: $t^2 - 5t - 36 = 0$ gives $(t - 9)(t + 4) = 0$, so $t = 9$ or $t = -4$. Only $t = 9$ is possible for real $x$, giving $x = \pm 3$. So there are $2$ real roots.",
  "Converting each value of $x^2$ into two real roots without checking its sign.",
  "C10C-biquadratic-real-roots", "One substitution and a sign check.",
  tita_answer=2, check=_c22,
  tita_traps=[(4, r"Takes both $t = 9$ and $t = -4$ as giving two real roots each."),
              (1, r"Keeps only $x = 3$ from $x^2 = 9$.")],
  cognitive="Understanding")

# 023
def _c23():
    return sum(set(real_roots(X**6 - 9*X**3 + 8)))
q("C10-C-023", T, "Sum of real roots of an equation quadratic in x cubed", "Easy",
  "Single-step computation",
  r"The sum of all the real roots of $x^6 - 9x^3 + 8 = 0$ is",
  "MCQ",
  r"With $t = x^3$: $t^2 - 9t + 8 = 0$ gives $t = 1$ or $t = 8$. Each value of $x^3$ has exactly one real cube root, so the real roots are $1$ and $2$, with sum $3$.",
  "Applying Vieta to the degree-6 equation, which sums complex roots too.",
  "C10C-biquadratic-real-roots", "One substitution; the trap is mixing real and complex roots.",
  correct=r"$3$",
  distractors=[(r"$9$", r"Adds the values of $t = x^3$ instead of the values of $x$."),
               (r"$0$", r"Uses Vieta on the degree-6 equation (no $x^5$ term), which includes the four non-real roots."),
               (r"$-3$", r"Solves $t^2 + 9t + 8 = 0$ by a sign slip, getting $x^3 = -1, -8$ and $x = -1, -2$.")],
  check=_c23, values=[3, 9, 0, -3], cognitive="Application")

# 024
def _c24():
    cnt = []
    for k in range(-60, 61):
        if len(set(real_roots(X**4 - k*X**3 - 6*X**2 - k*X + 1))) == 4:
            cnt.append(k)
    assert min(cnt) > -60 and max(cnt) < 60
    return len(cnt)
q("C10-C-024", T, "Reciprocal quartic: integer parameters giving four distinct real roots", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ does the equation $x^4 - kx^3 - 6x^2 - kx + 1 = 0$ have four distinct real roots?",
  "TITA",
  r"$x = 0$ is not a root, so divide by $x^2$ and put $t = x + \frac{1}{x}$: $x^2 + \frac{1}{x^2} - k\left(x + \frac{1}{x}\right) - 6 = 0$ becomes $t^2 - kt - 8 = 0$. A real $t$ gives two distinct real $x$ only when $|t| > 2$ (and a single $x = \pm 1$ when $|t| = 2$). The roots of $t^2 - kt - 8 = 0$ have product $-8$, so one is positive, $t_1$, and the other is $-\frac{8}{t_1}$. Both exceed $2$ in size exactly when $2 < t_1 < 4$. Since $t_1$ increases with $k$, and $t_1 = 2$ at $k = -2$ while $t_1 = 4$ at $k = 2$, we need $-2 < k < 2$: the integers $-1$, $0$, $1$, so $3$ values.",
  r"Forgetting that $x + \frac{1}{x}$ cannot lie strictly between $-2$ and $2$, or counting the boundary cases $k = \pm 2$, where a double root $x = \pm 1$ appears.",
  "C10C-reciprocal-quartic-real-roots", r"Needs the reciprocal substitution, the range condition $|t| > 2$ for both roots of the reduced quadratic and the boundary analysis.",
  tita_answer=3, check=_c24,
  tita_traps=[(5, r"Includes $k = -2$ and $k = 2$, where one value of $t$ is $\pm 2$ and gives the double root $x = \pm 1$, so only $3$ distinct real roots."),
              (1, r"Writes $x^2 + \frac{1}{x^2} = t^2$ instead of $t^2 - 2$, getting $t^2 - kt - 6 = 0$; then $2 < t_1 < 3$ gives $-1 < k < 1$, so only $k = 0$.")],
  exams=DX, cognitive="Analysis")

# 025
def _c25():
    u = X**2 + 2*X
    return len(set(real_roots(expand(u**2 - 2*u - 3))))
q("C10-C-025", T, "Distinct real roots of a quartic reducible by substitution, with a repeated root", "Medium",
  "Multi-step word problem",
  r"How many distinct real values of $x$ satisfy $(x^2 + 2x)^2 - 2(x^2 + 2x) - 3 = 0$?",
  "TITA",
  r"Put $u = x^2 + 2x$: $u^2 - 2u - 3 = 0$ gives $u = 3$ or $u = -1$. From $x^2 + 2x = 3$: $x = 1$ or $x = -3$. From $x^2 + 2x = -1$: $(x + 1)^2 = 0$, so $x = -1$ only. Distinct real values: $1$, $-3$, $-1$, which is $3$.",
  "Counting the repeated root $x = -1$ twice.",
  "C10C-substitution-real-roots", "Substitution then two quadratics, one of which has a repeated root.",
  tita_answer=3, check=_c25,
  tita_traps=[(4, r"Counts $x = -1$ twice from $(x + 1)^2 = 0$."),
              (2, r"Discards $u = -1$ because it is negative, as if $u$ were a square.")],
  cognitive="Application")

# 026
def _c26():
    e = expand((X + 1)*(X + 2)*(X + 3)*(X + 4) - 360)
    return sum(r**2 for r in set(real_roots(e)))
q("C10-C-026", T, "Product of four consecutive linear factors set equal to a constant", "Difficult",
  "Multi-step word problem",
  r"Find the sum of the squares of all the real solutions of $(x + 1)(x + 2)(x + 3)(x + 4) = 360$.",
  "TITA",
  r"Pair the outer and inner factors: $(x^2 + 5x + 4)(x^2 + 5x + 6) = 360$. With $t = x^2 + 5x + 5$ this is $(t - 1)(t + 1) = 360$, so $t^2 = 361$ and $t = \pm 19$. For $t = 19$: $x^2 + 5x - 14 = 0$, so $x = 2$ or $x = -7$. For $t = -19$: $x^2 + 5x + 24 = 0$ has negative discriminant. The real solutions are $2$ and $-7$, and $4 + 49 = 53$.",
  "Using Vieta on the whole quartic, which includes the non-real pair.",
  "C10C-substitution-real-roots", "Needs the pairing trick, a symmetric substitution and rejection of the non-real branch.",
  tita_answer=53, check=_c26,
  tita_traps=[(30, r"Uses Vieta on the whole quartic $x^4 + 10x^3 + 35x^2 + 50x - 336$: $(-10)^2 - 2(35) = 30$, which includes the non-real pair."),
              (-5, r"Reports the sum of the real solutions $2 + (-7)$.")],
  exams=DX, cognitive="Analysis")

# 027
def _c27():
    a, b = symbols('a b')
    P = X**3 + a*X**2 + b*X - 4
    s = solve([Eq(P.subs(X, 1), 3), Eq(P.subs(X, -2), -6)], [a, b], dict=True)[0]
    return rem(P.subs(s), X - 2, X)
q("C10-C-027", T, "Two remainders fix two coefficients; then a third remainder", "Medium",
  "Multi-step word problem",
  r"The polynomial $P(x) = x^3 + ax^2 + bx - 4$ leaves remainder $3$ when divided by $x - 1$ and remainder $-6$ when divided by $x + 2$. What is the remainder when $P(x)$ is divided by $x - 2$?",
  "TITA",
  r"$P(1) = 1 + a + b - 4 = 3$ gives $a + b = 6$. $P(-2) = -8 + 4a - 2b - 4 = -6$ gives $2a - b = 3$. So $a = 3$, $b = 3$, and $P(2) = 8 + 12 + 6 - 4 = 22$.",
  "Arithmetic or sign slips when substituting a negative value, or dropping the constant term.",
  "C10C-remainders-two-unknowns", r"Two remainder conditions, a $2 \times 2$ linear system, then one more evaluation.",
  tita_answer=22, check=_c27,
  tita_traps=[(26, r"Drops the constant term $-4$ when evaluating $P(2)$."),
              (6, r"Stops at $a + b = 6$.")],
  cognitive="Application")

# 028
def _c28():
    a, b = symbols('a b')
    P = X**3 + a*X**2 + b*X - 6
    s = solve([Eq(P.subs(X, 2), 0), Eq(rem(P, X + 1, X), -12)], [a, b], dict=True)[0]
    return (s[a], s[b])
q("C10-C-028", T, "Factor condition and remainder condition together determine two coefficients", "Easy",
  "Inverse/parameter",
  r"The polynomial $x^3 + ax^2 + bx - 6$ has $x - 2$ as a factor and leaves remainder $-12$ when divided by $x + 1$. The values of $a$ and $b$ are",
  "MCQ",
  r"$x = 2$ is a root: $8 + 4a + 2b - 6 = 0$, so $2a + b = -1$. The remainder at $x = -1$: $-1 + a - b - 6 = -12$, so $a - b = -5$. Adding, $3a = -6$, so $a = -2$ and $b = 3$.",
  "Substituting $x = -2$ and $x = 1$, the negatives of the correct roots.",
  "C10C-remainders-two-unknowns", "Two linear conditions in two unknowns.",
  correct=r"$a = -2,\ b = 3$",
  distractors=[(r"$a = 3,\ b = -2$", r"Solves correctly but swaps the values of $a$ and $b$."),
               (r"$a = 0,\ b = -7$", r"Uses $x = -2$ for the factor and $x = 1$ for the remainder: $2a - b = 7$, $a + b = -7$."),
               (r"$a = -6,\ b = 11$", r"Writes $P(-1) = -1 - a - b - 6$, getting $a + b = 5$ with $2a + b = -1$.")],
  check=_c28, values=[(-2, 3), (3, -2), (0, -7), (-6, 11)], cognitive="Application")

# 029
def _c29():
    # build a concrete P with the two given remainders and divide by the quadratic
    u, v = symbols('u v')
    P = X**3 + u*X + v
    s = solve([Eq(P.subs(X, 1), 5), Eq(P.subs(X, -3), -3)], [u, v], dict=True)[0]
    return rem(P.subs(s), (X - 1)*(X + 3), X)
q("C10-C-029", T, "Remainder on division by a quadratic from remainders on its linear factors", "Medium",
  "Multi-step word problem",
  r"A polynomial $P(x)$ leaves remainder $5$ when divided by $x - 1$ and remainder $-3$ when divided by $x + 3$. What is the remainder when $P(x)$ is divided by $x^2 + 2x - 3$?",
  "MCQ",
  r"Write $P(x) = (x - 1)(x + 3)Q(x) + mx + c$. Then $P(1) = m + c = 5$ and $P(-3) = -3m + c = -3$. Subtracting, $4m = 8$, so $m = 2$ and $c = 3$. The remainder is $2x + 3$.",
  "Using the wrong signs for the roots of the factors, or swapping the slope and intercept.",
  "C10C-remainder-quadratic-divisor", "Needs the general linear remainder and two conditions.",
  correct=r"$2x + 3$",
  distractors=[(r"$3x + 2$", r"Finds $m = 2$, $c = 3$ but writes them in the wrong places."),
               (r"$-2x + 3$", r"Uses $x = -1$ and $x = 3$: $-m + c = 5$, $3m + c = -3$."),
               (r"$-4x + 9$", r"Takes the second factor as $x - 3$: $m + c = 5$, $3m + c = -3$.")],
  check=_c29, values=[2*X + 3, 3*X + 2, -2*X + 3, -4*X + 9], cognitive="Application")

# 030
def _c30():
    # any polynomial with the given remainder on x^2 - 5x + 6
    P = expand((X**2 - 5*X + 6)*(X**2 + 7) + 3*X - 1)
    assert rem(P, X**2 - 5*X + 6, X) == 3*X - 1
    return rem(P, X - 3, X)
q("C10-C-030", T, "Remainder on a linear factor from the remainder on a quadratic divisor", "Easy",
  "Conceptual/application",
  r"When a polynomial $P(x)$ is divided by $x^2 - 5x + 6$, the remainder is $3x - 1$. What is the remainder when $P(x)$ is divided by $x - 3$?",
  "TITA",
  r"$P(x) = (x - 2)(x - 3)Q(x) + 3x - 1$. At $x = 3$ the first term vanishes, so $P(3) = 9 - 1 = 8$, which is the required remainder.",
  "Using the other root $x = 2$, or a wrong sign for the root of $x - 3$.",
  "C10C-remainder-quadratic-divisor", "One substitution once the division identity is written.",
  tita_answer=8, check=_c30,
  tita_traps=[(5, r"Substitutes $x = 2$, the root of the other factor: $6 - 1 = 5$."),
              (-10, r"Substitutes $x = -3$: $-9 - 1 = -10$.")],
  cognitive="Understanding")

# 031
def _c31():
    return rem(X**51 + 2*X**30 + 3, X**2 - 1, X)
q("C10-C-031", T, "Remainder of a high-degree polynomial on division by x squared minus 1", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $x^{51} + 2x^{30} + 3$ is divided by $x^2 - 1$?",
  "MCQ",
  r"The remainder is $mx + c$. At $x = 1$: $m + c = 1 + 2 + 3 = 6$. At $x = -1$: $-m + c = -1 + 2 + 3 = 4$. So $m = 1$ and $c = 5$, giving $x + 5$.",
  r"Mishandling $(-1)^{\text{even}}$ or swapping the two coefficients.",
  "C10C-remainder-high-power", r"Two evaluations at $\pm 1$ with parity of exponents.",
  correct=r"$x + 5$",
  distractors=[(r"$-x + 5$", r"Swaps the two equations, taking $m + c = 4$ and $-m + c = 6$."),
               (r"$5x + 1$", r"Finds $m = 1$, $c = 5$ but writes them in the wrong places."),
               (r"$3x + 3$", r"Takes $(-1)^{30} = -1$, so $-m + c = 0$ and $m = c = 3$.")],
  check=_c31, values=[X + 5, -X + 5, 5*X + 1, 3*X + 3], cognitive="Application")

# 032
def _c32():
    return rem(X**100 + X**50 + X**25, X**2 + X + 1, X)
q("C10-C-032", T, "Remainder on division by x squared plus x plus 1 using x cubed = 1", "Difficult",
  "Conceptual/application",
  r"What is the remainder when $x^{100} + x^{50} + x^{25}$ is divided by $x^2 + x + 1$?",
  "MCQ",
  r"Since $x^3 - 1 = (x - 1)(x^2 + x + 1)$, we may replace $x^3$ by $1$ modulo $x^2 + x + 1$. As $100 = 3 \cdot 33 + 1$, $50 = 3 \cdot 16 + 2$ and $25 = 3 \cdot 8 + 1$, the sum reduces to $x + x^2 + x$. Using $x^2 \equiv -x - 1$, this is $2x - x - 1 = x - 1$.",
  r"Reducing with $x^3 \equiv -1$ or with $x^2 \equiv x + 1$ or $x^2 \equiv -1$.",
  "C10C-remainder-high-power", "Needs the cube-root-of-unity reduction and a second reduction of $x^2$.",
  correct=r"$x - 1$",
  distractors=[(r"$3x + 1$", r"Reduces $x^2$ as $x + 1$: $x + (x + 1) + x$."),
               (r"$-x - 1$", r"Uses $x^3 \equiv -1$: $-x + x^2 + x$, then $x^2 \equiv -x - 1$."),
               (r"$x$", r"Uses $x^2 \equiv -1$ as for $x^2 + 1$: $1 - 1 + x$.")],
  check=_c32, values=[X - 1, 3*X + 1, -X - 1, X], exams=DX, cognitive="Analysis")

# 033
def _c33():
    # P(x) = 5x - 5 + (x - 2)(x - 9) Q(x) with Q integer-coefficient; P(6) = 25 - 12 Q(6)
    ok = set()
    for qv in range(-50, 51):
        ok.add(25 - 12 * qv)
    # brute force a few explicit integer polynomials too
    for c0 in range(-3, 4):
        for c1 in range(-3, 4):
            P = expand(5*X - 5 + (X - 2)*(X - 9)*(c1*X + c0))
            assert P.subs(X, 2) == 5 and P.subs(X, 9) == 40
            assert P.subs(X, 6) in ok
    opts = [49, 45, 43, 47]
    good = [v for v in opts if v in ok and (v - 5) % 4 == 0 and (v - 40) % 3 == 0]
    assert len(good) == 1
    return good[0]
q("C10-C-033", T, "Integer-coefficient polynomial: a - b divides P(a) - P(b)", "Difficult",
  "Conceptual/application",
  r"$P(x)$ is a polynomial with integer coefficients such that $P(2) = 5$ and $P(9) = 40$. Which of the following could be the value of $P(6)$?",
  "MCQ",
  r"For integer coefficients, $a - b$ divides $P(a) - P(b)$ for all integers $a$, $b$. So $4$ divides $P(6) - 5$ and $3$ divides $P(6) - 40$, that is, $P(6)$ leaves remainder $1$ on division by both $4$ and $3$. Among the values, only $49$ works, and it is attained: $P(x) = 5x - 5 - 2(x - 2)(x - 9)$ gives $P(6) = 25 + 24 = 49$.",
  "Checking only one of the two divisibility conditions, or using $9 - 2$ as the divisor.",
  "C10C-integer-coefficient-divisibility", "Requires the divisibility property of integer polynomials applied with two different base points.",
  correct=r"$49$",
  distractors=[(r"$45$", r"Checks only that $6 - 2 = 4$ divides $P(6) - 5$; but $45 - 40 = 5$ is not divisible by $3$."),
               (r"$43$", r"Checks only that $9 - 6 = 3$ divides $P(6) - 40$; but $43 - 5 = 38$ is not divisible by $4$."),
               (r"$47$", r"Checks that $9 - 2 = 7$ divides $P(6) - 5 = 42$, a condition that does not involve $x = 6$.")],
  check=_c33, values=[49, 45, 43, 47], exams=DX, cognitive="Analysis")

# 034
def _c34():
    P = X**3 - 10*X**2 + 30*X - 26
    rr = real_roots(P)
    assert len(rr) == 3 and all(r > 0 for r in rr)
    return nsimplify(_powsum(P, 1)**2 - _powsum(P, 2))  # 2(lb+bh+hl) = (sum)^2 - sum of squares
q("C10-C-034", T, "Surface area of a cuboid whose edges are the roots of a cubic", "Easy",
  "Conceptual/application",
  r"The length, breadth and height, in cm, of a closed rectangular box are the three roots of $x^3 - 10x^2 + 30x - 26 = 0$. What is the total surface area of the box?",
  "MCQ",
  r"If the edges are $l$, $b$, $h$, the surface area is $2(lb + bh + hl)$. By Vieta, $lb + bh + hl = 30$, so the surface area is $60$ cm$^2$. The roots themselves need not be found.",
  "Forgetting the factor $2$, or using the product (volume) of the roots.",
  "C10C-vieta-cuboid-context", "One Vieta sum in a geometric setting; the trap is trying to find the roots.",
  correct=r"$60$ cm$^2$",
  distractors=[(r"$30$ cm$^2$", r"Takes $lb + bh + hl$ without the factor $2$."),
               (r"$26$ cm$^2$", r"Uses the product of the roots, which is the volume in cm$^3$."),
               (r"$40$ cm$^2$", r"Computes $l^2 + b^2 + h^2 = 100 - 60$, the square of the space diagonal.")],
  check=_c34, values=[60, 30, 26, 40], cognitive="Understanding")

# 035
def _c35():
    P = X**3 - 9*X**2 + 24*X - 19
    rr = real_roots(P)
    assert len(rr) == 3 and all(r > 0 for r in rr)
    assert all(P.subs(X, d) != 0 for d in (1, -1, 19, -19))  # no rational root
    l, b, h = [CRootOf(P, i) for i in range(3)]
    val = N((l + b)*(b + h)*(h + l), 50)
    v = int(round(val))
    assert abs(val - v) < Float(10)**-30
    return v
q("C10-C-035", T, "Product of the edge sums of the three faces of a cuboid whose edges are the roots of a cubic", "Medium",
  "Conceptual/application",
  r"The length, breadth and height, in cm, of a closed rectangular box are the three roots of $x^3 - 9x^2 + 24x - 19 = 0$. For each of the three distinct faces of the box, Joseph adds the two edge lengths of that face. What is the product of the three sums he obtains?",
  "MCQ",
  r"Let the edges be $l$, $b$, $h$ with $s = l + b + h = 9$, $lb + bh + hl = 24$ and $lbh = 19$. The required product is $(l + b)(b + h)(h + l) = (s - h)(s - l)(s - b)$, which is the cubic evaluated at $x = s$: $9^3 - 9 \cdot 9^2 + 24 \cdot 9 - 19 = 216 - 19 = 197$. Equivalently, $(l + b)(b + h)(h + l) = s(lb + bh + hl) - lbh = 216 - 19 = 197$.",
  r"Stopping at $s(lb + bh + hl)$, or expanding the product and losing the $2lbh$ term.",
  "C10C-vieta-cuboid-context", r"Needs to rewrite each face sum as $s$ minus the third edge and recognise the product as a value of the cubic, or recall $s \cdot p - r$.",
  correct=r"$197$",
  distractors=[(r"$216$", r"Takes $(l + b)(b + h)(h + l) = (l + b + h)(lb + bh + hl) = 9 \times 24$, leaving out $-lbh$."),
               (r"$235$", r"Uses $s(lb + bh + hl) + lbh = 216 + 19$, a sign slip on the product term."),
               (r"$159$", r"Expands the product as the six terms $l^2 b + \ldots$, uses their sum $s \cdot p - 3lbh = 216 - 57$, and forgets the remaining $2lbh$.")],
  check=_c35, values=[197, 216, 235, 159], cognitive="Understanding")

# 036
def _c36():
    a, b, c = symbols('a b c')
    P = a*X**2 + b*X + c
    e = expand(P.subs(X, X + 1) - P - (6*X + 4))
    s = solve(Poly(e, X).all_coeffs() + [c - 3], [a, b, c], dict=True)[0]
    # also step-simulate P(0) -> P(5)
    v = 3
    for n in range(5):
        v += 6*n + 4
    assert v == P.subs(s).subs(X, 5)
    return v
q("C10-C-036", T, "Polynomial determined by its forward difference and one value", "Medium",
  "Conceptual/application",
  r"A polynomial $P(x)$ satisfies $P(x + 1) - P(x) = 6x + 4$ for all real $x$, and $P(0) = 3$. What is the value of $P(5)$?",
  "TITA",
  r"Telescoping, $P(5) = P(0) + \sum_{n=0}^{4} (6n + 4) = 3 + 6(0 + 1 + 2 + 3 + 4) + 4 \times 5 = 3 + 60 + 20 = 83$. (Indeed $P(x) = 3x^2 + x + 3$.)",
  "Summing the differences over $n = 1$ to $5$ instead of $n = 0$ to $4$.",
  "C10C-difference-telescoping", "Needs the telescoping idea and careful index range.",
  tita_answer=83, check=_c36,
  tita_traps=[(113, r"Sums $6n + 4$ for $n = 1$ to $5$: $3 + 90 + 20$."),
              (55, r"Stops one step early and reports $P(4) = 3 + 36 + 16$.")],
  cognitive="Application")

# 037
def _c37():
    t = symbols('t')
    # find P with P(x^2 + 1) = x^4 + 4x^2 + 5 by matching a general quadratic
    a, b, c = symbols('a b c')
    e = expand(a*(X**2 + 1)**2 + b*(X**2 + 1) + c - (X**4 + 4*X**2 + 5))
    s = solve(Poly(e, X).all_coeffs(), [a, b, c], dict=True)[0]
    P = (a*t**2 + b*t + c).subs(s)
    return expand(P.subs(t, X**2 - 1))
q("C10-C-037", T, "Recovering a polynomial from its composition and evaluating a new composition", "Medium",
  "Multi-step word problem",
  r"A polynomial $P$ satisfies $P(x^2 + 1) = x^4 + 4x^2 + 5$ for every real $x$. Then $P(x^2 - 1)$ equals",
  "MCQ",
  r"Let $t = x^2 + 1$, so $x^2 = t - 1$. Then $x^4 + 4x^2 + 5 = (t - 1)^2 + 4(t - 1) + 5 = t^2 + 2t + 2$, so $P(t) = t^2 + 2t + 2$. Hence $P(x^2 - 1) = (x^2 - 1)^2 + 2(x^2 - 1) + 2 = x^4 + 1$.",
  "Renaming $x^2$ as $t$ without shifting, or treating $P(x^2 - 1)$ as $P(x^2 + 1) - 2$.",
  "C10C-composition-substitution", "Requires a change of variable to recover $P$, then a second substitution.",
  correct=r"$x^4 + 1$",
  distractors=[(r"$x^4 + 2x^2 + 2$", r"Finds $P(t) = t^2 + 2t + 2$ but then substitutes $t = x^2$ instead of $t = x^2 - 1$."),
               (r"$x^4 - 4x^2 + 5$", r"Flips the sign of the middle term because $+1$ became $-1$ inside $P$."),
               (r"$x^4 + 4x^2 + 3$", r"Treats $P(x^2 - 1)$ as $P(x^2 + 1) - 2$.")],
  check=_c37, values=[X**4 + 1, X**4 + 2*X**2 + 2, X**4 - 4*X**2 + 5, X**4 + 4*X**2 + 3], cognitive="Application")

# 038
def _c38():
    e = expand((X - 1)*(X - 2)*(X - 3) - 6*(X - 2))
    return sum(set(real_roots(e)))
q("C10-C-038", T, "Sum of real roots when a common factor must not be cancelled", "Medium",
  "Conceptual/application",
  r"The sum of all the real roots of $(x - 1)(x - 2)(x - 3) = 6(x - 2)$ is",
  "MCQ",
  r"Move everything to one side: $(x - 2)\left[(x - 1)(x - 3) - 6\right] = 0$, that is $(x - 2)(x^2 - 4x - 3) = 0$. So $x = 2$ or $x = 2 \pm \sqrt{7}$, all real. Their sum is $2 + 4 = 6$.",
  "Cancelling $x - 2$ from both sides and losing the root $x = 2$.",
  "C10C-real-roots-common-factor", "The trap is division by an expression that can be zero.",
  correct=r"$6$",
  distractors=[(r"$4$", r"Cancels $x - 2$ and sums only the roots of $x^2 - 4x - 3 = 0$."),
               (r"$-2$", r"Keeps $x = 2$ but takes the root sum of $x^2 - 4x - 3 = 0$ as $-4$ (sign slip in Vieta): $2 + (-4)$."),
               (r"$8$", r"Adds $x = 2$ again to the cubic's Vieta sum $6$, counting it twice.")],
  check=_c38, values=[6, 4, -2, 8], cognitive="Understanding")

# 039
def _c39():
    x0 = 2 + sqrt(3)
    return nsimplify(expand(x0**4 - 4*x0**3 + 2*x0**2 - 4*x0 + 7))
q("C10-C-039", T, "Value of a polynomial at a surd using its minimal quadratic", "Medium",
  "Conceptual/application",
  r"If $x = 2 + \sqrt{3}$, what is the value of $x^4 - 4x^3 + 2x^2 - 4x + 7$?",
  "TITA",
  r"Here $x + \frac{1}{x} = (2 + \sqrt{3}) + (2 - \sqrt{3}) = 4$, so $x^2 - 4x + 1 = 0$. Divide: $x^4 - 4x^3 + 2x^2 - 4x + 7 = (x^2 - 4x + 1)(x^2 + 1) + 6$. The first part is $0$, so the value is $6$.",
  "Expanding powers of the surd directly and making arithmetic slips, or taking the constant term as the answer.",
  "C10C-value-at-surd", "Needs the quadratic satisfied by the surd and a polynomial division.",
  tita_answer=6, check=_c39,
  tita_traps=[(7, r"Assumes the non-constant part vanishes entirely and reports the constant $7$."),
              (8, r"Divides by $x^2 - 4x + 1$ correctly but subtracts the constant $1$ of $(x^2 - 4x + 1)(x^2 + 1)$ with a sign slip: $7 + 1 = 8$.")],
  cognitive="Application")

# 040
def _c40():
    ks = set()
    for k in range(-2000, 2001):
        if any(r**3 + k*r + 6 == 0 for r in range(-60, 61)):
            ks.add(k)
    return len(ks)
q("C10-C-040", T, "Counting integer parameters for which a cubic has an integer root", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ does the equation $x^3 + kx + 6 = 0$ have at least one integer root?",
  "TITA",
  r"An integer root $r$ must divide $6$, so $r \in \{\pm 1, \pm 2, \pm 3, \pm 6\}$, and then $k = -r^2 - \frac{6}{r}$. This gives $k = -7, 5, -7, -1, -11, -7, -37, -35$ for $r = 1, -1, 2, -2, 3, -3, 6, -6$. The value $-7$ repeats (roots $1$, $2$, $-3$ all occur for $k = -7$), so the distinct values are $-7, 5, -1, -11, -37, -35$: $6$ integers.",
  "Counting candidate roots instead of distinct values of $k$.",
  "C10C-integer-root-casework", "Casework over divisors, then spotting that several roots give the same $k$.",
  tita_answer=6, check=_c40,
  tita_traps=[(8, r"Counts the eight candidate roots instead of distinct $k$."),
              (4, r"Tries only the positive divisors $r = 1, 2, 3, 6$ and counts one $k$ for each.")],
  exams=DX, cognitive="Analysis")
