import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig

T = "Solid mensuration"
CX = ("CAT", "XAT")


# ---------------------------------------------------------------- figure helpers
def _box(f, w, h, d, k=0.55, ang=35):
    """Oblique sketch of a cuboid: front face w x h, depth d drawn at angle ang, scaled by k.
    Returns dict of the 8 corners. Hidden edges (from back-bottom-left) are dashed."""
    dx, dy = d * k * math.cos(math.radians(ang)), d * k * math.sin(math.radians(ang))
    c = {
        "f00": (0, 0), "f10": (w, 0), "f11": (w, h), "f01": (0, h),
        "b00": (dx, dy), "b10": (w + dx, dy), "b11": (w + dx, h + dy), "b01": (dx, h + dy),
    }
    f.poly(c["f00"], c["f10"], c["f11"], c["f01"])
    f.seg(c["f01"], c["b01"]); f.seg(c["b01"], c["b11"]); f.seg(c["f11"], c["b11"])
    f.seg(c["f10"], c["b10"]); f.seg(c["b10"], c["b11"])
    f.seg(c["b00"], c["f00"], dashed=True); f.seg(c["b00"], c["b10"], dashed=True); f.seg(c["b00"], c["b01"], dashed=True)
    return c


def _ellipse(f, cx, cy, rx, ry, dashed_back=False, n=48):
    """Ellipse (oblique circle) as segments; back half optionally dashed."""
    pts = [(cx + rx * math.cos(2 * math.pi * i / n), cy + ry * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]
    for i in range(n):
        back = pts[i][1] > cy + 1e-9 or pts[i + 1][1] > cy + 1e-9
        f.seg(pts[i], pts[i + 1], dashed=(dashed_back and back))


# ================================================================ 001
def _c001():
    l, b, h = 12, 9, 8
    return sqrt(l**2 + b**2 + h**2)
f = Fig()
_c = _box(f, 12, 8, 9)
f.label_seg(_c["f00"], _c["f10"], "12 m"); f.label_seg(_c["f10"], _c["b10"], "9 m"); f.label_seg(_c["f00"], _c["f01"], "8 m")
_alt = "Oblique sketch of a rectangular room drawn as a cuboid with length 12 m, breadth 9 m and height 8 m; hidden edges are dashed."
q("C18-B-001", T, "Longest rod that fits in a cuboidal room (space diagonal)", "Easy",
  "Single-step computation",
  r"A storeroom is in the shape of a cuboid $12$ m long, $9$ m wide and $8$ m high. What is the length, in metres, of the longest thin straight rod that can be placed entirely inside the storeroom?",
  "TITA",
  r"The longest rod lies along a space diagonal, joining a floor corner to the opposite ceiling corner. Its length is $\sqrt{12^2 + 9^2 + 8^2} = \sqrt{144 + 81 + 64} = \sqrt{289} = 17$ m.",
  r"Using the floor diagonal $\sqrt{12^2 + 9^2}$ instead of the space diagonal.",
  "C18B-cuboid-space-diagonal", "One formula, one step; the only trap is stopping at the floor diagonal.",
  tita_answer=17, check=_c001, values=[17],
  tita_traps=[(15, r"Uses the floor diagonal $\sqrt{144 + 81} = 15$."),
              (29, r"Adds the three dimensions $12 + 9 + 8$.")],
  cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 002
def _c002():
    a, b, c = symbols('a b c', positive=True)
    s = Rational(76, 4)
    # (a+b+c)^2 = d^2 + 2(ab+bc+ca)
    d2 = s**2 - 240
    # confirm a real box exists: 6, 6, 7
    assert 6 + 6 + 7 == s and 2 * (36 + 42 + 42) == 240
    return sqrt(d2)
q("C18-B-002", T, "Space diagonal from the total edge length and total surface area", "Medium",
  "Conceptual/application",
  r"A closed rectangular box is made so that the total length of its $12$ edges is $76$ cm and its total outer surface area is $240$ cm$^2$. What is the length, in cm, of a diagonal of the box joining two opposite corners through its interior?",
  "TITA",
  r"Let the edges be $a, b, c$. Then $4(a + b + c) = 76$, so $a + b + c = 19$, and $2(ab + bc + ca) = 240$. Since $(a + b + c)^2 = a^2 + b^2 + c^2 + 2(ab + bc + ca)$, we get $a^2 + b^2 + c^2 = 361 - 240 = 121$. The diagonal is $\sqrt{121} = 11$ cm. (For instance, $6 \times 6 \times 7$ is such a box.)",
  "Subtracting only $ab + bc + ca$ instead of the full surface area, or reporting $a + b + c$.",
  "C18B-cuboid-space-diagonal", "Needs the identity linking the sum of edges, surface area and diagonal; the edges themselves are never needed.",
  tita_answer=11, check=_c002, values=[11],
  tita_traps=[(19, r"Reports $a + b + c = 19$ as the diagonal."),
              (121, r"Stops at $a^2 + b^2 + c^2 = 121$ and forgets the square root.")],
  cognitive="Analysis")


# ================================================================ 003
def _c003():
    a, b, c = 6, 4, 3
    # unfold two adjacent faces: path length sqrt((x+y)^2 + z^2) for each choice of the edge crossed
    cands = [sqrt((a + b)**2 + c**2), sqrt((a + c)**2 + b**2), sqrt((b + c)**2 + a**2)]
    # numeric confirmation by minimising over the crossing point on each edge
    best = 1e9
    for (p, qq, r_) in [(a, b, c), (a, c, b), (b, c, a)]:
        for i in range(0, 2001):
            t = r_ * i / 2000
            best = min(best, math.hypot(p, t) + math.hypot(qq, r_ - t))
    m = min(cands, key=lambda e: float(e))
    assert abs(float(m) - best) < 1e-6
    return m
f = Fig()
_c = _box(f, 6, 3, 4)
f.pt("P", *_c["f00"], offset=(-0.7, -0.7)); f.pt("Q", *_c["b11"], offset=(0.7, 0.7))
f.label_seg(_c["f00"], _c["f10"], "6 cm"); f.label_seg(_c["f10"], _c["b10"], "4 cm"); f.label_seg(_c["f00"], _c["f01"], "3 cm")
_alt = "Oblique sketch of a closed box 6 cm long, 4 cm wide and 3 cm high. P is the front bottom left corner and Q is the diagonally opposite back top right corner."
q("C18-B-003", T, "Shortest path on the surface of a cuboid between opposite corners", "Difficult",
  "Casework/optimisation",
  r"A closed box is $6$ cm long, $4$ cm wide and $3$ cm high. An ant at corner P wants to reach corner Q, the corner diagonally opposite to P (P and Q are the ends of a diagonal through the interior). The ant can walk only on the outer surface of the box. What is the length of the shortest path available to the ant?",
  "MCQ",
  r"Unfold the two faces the ant crosses into one rectangle; the path is then a straight line. Crossing the edge of length $c$ gives $\sqrt{(a + b)^2 + c^2}$, where $a, b$ are the other two edges. The three choices give $\sqrt{(6+4)^2 + 3^2} = \sqrt{109}$, $\sqrt{(6+3)^2 + 4^2} = \sqrt{97}$ and $\sqrt{(4+3)^2 + 6^2} = \sqrt{85}$. The shortest is $\sqrt{85}$ cm, obtained by keeping the longest edge alone.",
  "Taking the interior diagonal, or unfolding along the wrong edge.",
  "C18B-cuboid-surface-path", "Requires the unfolding (net) idea and comparing three cases to pick the minimum.",
  correct=r"$\sqrt{85}$ cm",
  distractors=[(r"$\sqrt{97}$ cm", r"Unfolds so that the $6$ cm and $3$ cm edges combine: $\sqrt{9^2 + 4^2}$."),
               (r"$\sqrt{109}$ cm", r"Unfolds so that the $6$ cm and $4$ cm edges combine: $\sqrt{10^2 + 3^2}$."),
               (r"$\sqrt{61}$ cm", r"Gives the interior space diagonal $\sqrt{36 + 16 + 9}$, which the ant cannot walk.")],
  check=_c003, values=[sqrt(85), sqrt(97), sqrt(109), sqrt(61)], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 004
def _c004():
    l, b, h = symbols('l b h', positive=True)
    sol = solve([l * b - 48, l * h - 32, b * h - 24], [l, b, h], dict=True)
    s = sol[0]
    return s[l] * s[b] * s[h]
q("C18-B-004", T, "Volume of a cuboid from the areas of three adjacent faces", "Easy",
  "Multi-step word problem",
  r"A closed rectangular gift box has a base of area $48$ cm$^2$, a front face of area $32$ cm$^2$ and a side face of area $24$ cm$^2$. What is the volume of the box, in cm$^3$?",
  "TITA",
  r"With length $l$, breadth $b$ and height $h$: $lb = 48$, $lh = 32$, $bh = 24$. Multiplying, $(lbh)^2 = 48 \times 32 \times 24 = 36864$, so $lbh = 192$. (The edges are $8$, $6$ and $4$ cm.) The volume is $192$ cm$^3$.",
  "Adding the face areas or doubling them as if finding the surface area.",
  "C18B-cuboid-from-face-areas", "One product-of-areas step; the trap is confusing it with surface area.",
  tita_answer=192, check=_c004, values=[192],
  tita_traps=[(104, r"Adds the three face areas $48 + 32 + 24$."),
              (208, r"Computes the total surface area $2(48 + 32 + 24)$.")],
  cognitive="Application")


# ================================================================ 005
def _c005():
    best = 0
    for x in range(1, 8):
        best = max(best, x * (24 - 2 * x) * (15 - 2 * x))
    return best
f = Fig()
_s = 2.2
f.poly((0, 0), (24, 0), (24, 15), (0, 15))
for (cx_, cy_) in [(0, 0), (24 - _s, 0), (24 - _s, 15 - _s), (0, 15 - _s)]:
    f.shade([(cx_, cy_), (cx_ + _s, cy_), (cx_ + _s, cy_ + _s), (cx_, cy_ + _s)])
    f.poly((cx_, cy_), (cx_ + _s, cy_), (cx_ + _s, cy_ + _s), (cx_, cy_ + _s))
f.seg((_s, _s), (24 - _s, _s), dashed=True); f.seg((_s, 15 - _s), (24 - _s, 15 - _s), dashed=True)
f.seg((_s, _s), (_s, 15 - _s), dashed=True); f.seg((24 - _s, _s), (24 - _s, 15 - _s), dashed=True)
f.label_seg((0, 0), (24, 0), "24 cm"); f.label_seg((0, 0), (0, 15), "15 cm"); f.pt("", -4, 7, dot=False)
f.text((_s / 2, 15 - _s - 1.0), "x"); f.text((_s + 0.9, 15 - _s / 2), "x")
_alt = "A rectangular sheet 24 cm by 15 cm with an equal square of side x cut from each corner; dashed lines show where the flaps are folded up."
q("C18-B-005", T, "Open box from a sheet with corner squares removed, integer cut", "Medium",
  "Casework/optimisation",
  r"A rectangular sheet of tin measures $24$ cm by $15$ cm. An equal square of side $x$ cm, where $x$ is a whole number, is cut from each of the four corners, and the flaps are folded up to form an open box (no lid). What is the largest possible volume of the box, in cm$^3$?",
  "TITA",
  r"The box has base $(24 - 2x)$ by $(15 - 2x)$ and height $x$, with $1 \le x \le 7$. Volume $V = x(24 - 2x)(15 - 2x)$: $x = 2$ gives $2 \times 20 \times 11 = 440$, $x = 3$ gives $3 \times 18 \times 9 = 486$, $x = 4$ gives $4 \times 16 \times 7 = 448$, and larger $x$ give less ($x = 5$: $350$). The maximum is $486$ cm$^3$.",
  "Reducing each side by $x$ instead of $2x$, or not checking the neighbouring values.",
  "C18B-open-box-from-sheet", "Needs the model of the folded box and a short table of cases to find the maximum.",
  tita_answer=486, check=_c005, values=[486],
  tita_traps=[(972, r"Takes the base as $(24 - x)(15 - x)$; the maximum of $x(24 - x)(15 - x)$ is $972$ at $x = 6$."),
              (448, r"Tries $x = 4$ only (or guesses a quarter of the shorter side, $3.75$, rounded to $4$) without tabulating the neighbouring values.")],
  cognitive="Analysis",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 006
def _c006():
    r = symbols('r', positive=True)
    V = 256 * pi
    h = V / (pi * r**2)
    cost = 2 * (2 * pi * r**2) + 1 * (2 * pi * r * h)     # ends at price 2, side at price 1
    crit = [s for s in solve(diff(cost, r), r) if s.is_real and s > 0]
    rbest = min(crit, key=lambda s: float(cost.subs(r, s)))
    # numeric confirmation on a fine grid of radii
    grid = min(float(cost.subs(r, Rational(i, 100))) for i in range(100, 1200, 7))
    assert grid >= float(cost.subs(r, rbest)) - 1e-6
    return simplify(h.subs(r, rbest))
q("C18-B-006", T, "Cheapest closed cylindrical tin of fixed volume when the ends cost twice the side", "Difficult",
  "Casework/optimisation",
  r"A company makes closed cylindrical tins, each with a volume of exactly $256\pi$ cm$^3$. The sheet metal for the top and the bottom costs twice as much per cm$^2$ as the sheet metal for the curved side; ignore the thickness of the metal and any wastage. The radius can be any positive value. What is the height, in cm, of the tin that costs the least to make?",
  "TITA",
  r"With radius $r$, the height is $h = \frac{256}{r^2}$. Taking the side price as $1$ per cm$^2$, the cost is $2 \times 2\pi r^2 + 2\pi r h = 4\pi\left(r^2 + \frac{128}{r}\right) = 4\pi\left(r^2 + \frac{64}{r} + \frac{64}{r}\right)$. By AM-GM the bracket is at least $3\sqrt[3]{4096} = 48$, with equality when $r^2 = \frac{64}{r}$, that is $r = 4$. Then $h = \frac{256}{16} = 16$ cm (the cheapest tin has $h = 4r$).",
  r"Using the shape of the least-area can ($h = 2r$), which ignores the higher price of the ends.",
  "C18B-cylinder-cost-optimisation", "Needs a cost model with unequal prices, reduction to one variable and an AM-GM split (or a derivative) to find the minimum.",
  tita_answer=16, check=_c006, values=[16],
  tita_traps=[(4, "Reports the radius of the cheapest tin instead of its height."),
              (8, "Reports the diameter of the cheapest tin instead of its height."),
              (10, r"Ignores the price difference and uses $h = 2r$: $2\pi r^3 = 256\pi$ gives $r = \sqrt[3]{128} \approx 5.04$ and $h \approx 10.1$, which the student rounds to the nearest whole number.")],
  cognitive="Analysis", exams=CX)


# ================================================================ 007
def _c007():
    best = 0
    n = 48
    for i in range(1, n):
        for j in range(1, n - i):
            l, b = Fraction(i, 4), Fraction(j, 4)
            h = 12 - l - b
            if h > 0 and (best == 0 or l * b * h > best[0]):
                best = (l * b * h, 2 * (l * b + b * h + h * l))
    return best[1]
q("C18-B-007", T, "Paper to cover the largest-volume cuboid frame made from a fixed length of wire", "Easy",
  "Conceptual/application",
  r"A wire of length $48$ cm is cut into $12$ pieces that form all the edges of a cuboid frame, using the whole wire. The dimensions are chosen so that the frame encloses the largest possible volume. The frame is then covered on all six faces with paper, without overlap, to make a closed box. How much paper is needed?",
  "MCQ",
  r"The $12$ edges are four lengths, four breadths and four heights, so $l + b + h = 12$. For a fixed sum the product $lbh$ is largest when the three are equal, so the box is a cube of edge $4$ cm. Its six faces need $6 \times 4^2 = 96$ cm$^2$ of paper.",
  "Dividing the wire among the wrong number of edges, or leaving out the factor $2$ in the surface area.",
  "C18B-cuboid-amgm-extremes", "Two quick ideas: a cuboid has 12 edges, and equal factors maximise a product with fixed sum; then one surface-area step.",
  correct=r"$96$ cm$^2$",
  distractors=[(r"$48$ cm$^2$", r"Uses $lb + bh + hl = 48$ for the surface area, leaving out the factor $2$."),
               (r"$384$ cm$^2$", r"Divides $48$ by $6$, taking a cube to have $6$ edges, so edge $8$ and area $6 \times 64$."),
               (r"$216$ cm$^2$", r"Divides $48$ by $8$, counting $8$ edges, so edge $6$ and area $6 \times 36$.")],
  check=_c007, values=[96, 48, 384, 216], cognitive="Understanding")


# ================================================================ 008
def _c008():
    a = Rational(1)
    return (6 * (a * Rational(6, 5))**2 - 6 * a**2) / (6 * a**2) * 100
q("C18-B-008", T, "Percentage change in surface area of a cube when its edge grows", "Easy",
  "Single-step computation",
  r"A manufacturer increases each edge of a cubical storage box by $20\%$. By what percentage does the total surface area of the box increase?",
  "MCQ",
  r"Surface area varies as the square of the edge. The new area is $(1.2)^2 = 1.44$ times the old, an increase of $44\%$.",
  "Treating area as changing in the same proportion as the edge, or using the cube of the factor.",
  "C18B-percent-change-dimensions", "One scaling step; the trap is using the linear or the cubic factor.",
  correct=r"$44\%$",
  distractors=[(r"$20\%$", "Assumes area grows in the same proportion as the edge."),
               (r"$40\%$", r"Doubles the $20\%$ for two dimensions, ignoring the $4\%$ cross term."),
               (r"$72.8\%$", r"Uses $(1.2)^3 = 1.728$, the volume factor.")],
  check=_c008, values=[44, 20, 40, Rational(728, 10)], cognitive="Understanding")


# ================================================================ 009
def _c009():
    r, h = symbols('r h', positive=True)
    V0 = pi * r**2 * h
    V1 = pi * (Rational(11, 10) * r)**2 * (Rational(4, 5) * h)
    return simplify((V1 - V0) / V0 * 100)
q("C18-B-009", T, "Volume change of a cylinder when radius and height change by percentages", "Medium",
  "Multi-step word problem",
  r"A company redesigns its cylindrical juice can. The radius of the can is increased by $10\%$ and its height is decreased by $20\%$. What happens to the volume of the can?",
  "MCQ",
  r"Volume varies as $r^2 h$. The new volume is $(1.1)^2 \times 0.8 = 1.21 \times 0.8 = 0.968$ times the old, so the volume falls by $3.2\%$.",
  "Ignoring that the radius enters squared, or adding percentages instead of multiplying factors.",
  "C18B-percent-change-dimensions", "Two factors combined multiplicatively, with a squared term.",
  correct=r"a decrease of $3.2\%$",
  distractors=[(r"a decrease of $12\%$", r"Treats volume as proportional to $r h$: $1.1 \times 0.8 = 0.88$."),
               (r"a decrease of $10\%$", r"Adds the changes directly: $+10\% - 20\% = -10\%$."),
               (r"an increase of $1\%$", r"Correctly gets $+21\%$ for $r^2$ but then adds $-20\%$ for $h$ instead of multiplying.")],
  check=_c009, values=[Rational(-16, 5), -12, -10, 1], cognitive="Application")


# ================================================================ 010
def _c010():
    k = sqrt(Rational(169, 100))          # radius factor from area factor 1.69
    return (k**3 - 1) * 100
q("C18-B-010", T, "Volume change of a sphere from a given change in its surface area", "Medium",
  "Inverse/parameter",
  r"A spherical balloon is inflated so that its surface area increases by $69\%$. Assuming it stays a sphere, by what percentage does its volume increase?",
  "MCQ",
  r"Surface area varies as $r^2$, so the radius factor is $\sqrt{1.69} = 1.3$. Volume varies as $r^3$: $1.3^3 = 2.197$. The volume increases by $119.7\%$.",
  r"Scaling the area percentage by $\frac{3}{2}$ or reporting the radius change.",
  "C18B-percent-change-dimensions", "Needs going back from area to radius and then forward to volume.",
  correct=r"$119.7\%$",
  distractors=[(r"$103.5\%$", r"Multiplies $69\%$ by $\frac{3}{2}$, treating the percentages as proportional."),
               (r"$69\%$", "Assumes volume changes by the same percentage as surface area."),
               (r"$30\%$", r"Stops at the radius increase $\sqrt{1.69} - 1 = 0.3$.")],
  check=_c010, values=[Rational(1197, 10), Rational(1035, 10), 69, 30], cognitive="Application")


# ================================================================ 011
def _c011():
    r, h = symbols('r h', positive=True)
    s = solve([2 * pi * r * h - 120 * pi, pi * r**2 * h - 360 * pi], [r, h], dict=True)
    return s[0][h]
q("C18-B-011", T, "Height of a cylinder from its curved surface area and volume", "Easy",
  "Inverse/parameter",
  r"A closed cylindrical water tank has a curved surface area of $120\pi$ m$^2$ and a volume of $360\pi$ m$^3$. What is the height of the tank?",
  "MCQ",
  r"Dividing, $\frac{\pi r^2 h}{2\pi r h} = \frac{r}{2} = \frac{360\pi}{120\pi} = 3$, so $r = 6$ m. Then $2\pi \times 6 \times h = 120\pi$ gives $h = 10$ m.",
  "Dropping the factor $2$ in the ratio, or reporting the radius.",
  "C18B-cylinder-csa-volume", "Ratio of the two formulas gives the radius at once; one more step gives the height.",
  correct=r"$10$ m",
  distractors=[(r"$6$ m", "Reports the radius."),
               (r"$12$ m", "Reports the diameter."),
               (r"$40$ m", r"Takes $r = \frac{V}{\text{CSA}} = 3$, forgetting the factor $2$, then $h = \frac{360}{9} = 40$.")],
  check=_c011, values=[10, 6, 12, 40], cognitive="Application")


# ================================================================ 012
def _c012():
    def vol(circ, ht):
        r = circ / (2 * pi)
        return pi * r**2 * ht
    return simplify(vol(44, 18) / vol(18, 44))
q("C18-B-012", T, "Comparing volumes when a sheet is rolled into a cylinder in two ways", "Medium",
  "Conceptual/application",
  r"A rectangular sheet of paper measures $44$ cm by $18$ cm. Cylinder X is formed by rolling the sheet, without overlap, so that the $44$ cm side becomes the circumference of the base. Cylinder Y is formed by rolling an identical sheet so that the $18$ cm side becomes the circumference. Both cylinders are open at the ends. What is the ratio of the volume of X to the volume of Y?",
  "MCQ",
  r"If the circumference is $c$ and the height $h$, then $r = \frac{c}{2\pi}$ and $V = \pi r^2 h = \frac{c^2 h}{4\pi}$. So $V_X : V_Y = 44^2 \times 18 : 18^2 \times 44 = 44 : 18 = 22 : 9$.",
  "Assuming equal sheet area means equal volume, or squaring the ratio without the height factor.",
  "C18B-cylinder-rolled-sheet", "Needs expressing volume in terms of circumference; the insight is that the ratio equals the ratio of the circumferences.",
  correct=r"$22 : 9$",
  distractors=[(r"$9 : 22$", "Inverts the ratio, giving Y to X."),
               (r"$1 : 1$", "Assumes the same sheet (same curved area) gives the same volume."),
               (r"$484 : 81$", r"Uses only $r^2$, that is $44^2 : 18^2$, ignoring the different heights.")],
  check=_c012, values=[Rational(22, 9), Rational(9, 22), 1, Rational(484, 81)], cognitive="Understanding")


# ================================================================ 013
def _c013():
    c = symbols('c', positive=True)
    V = c**2 * (18 - c) / (4 * pi)
    crit = [s for s in solve(diff(V, c), c) if 0 < s < 18]
    return max(V.subs(c, s) for s in crit)
q("C18-B-013", T, "Maximum volume of a cylinder rolled from a rectangle of fixed perimeter", "Difficult",
  "Casework/optimisation",
  r"A rectangular sheet of paper has a perimeter of $36$ cm; its sides may be any lengths. The sheet is rolled, without overlap, so that one side becomes the circumference of the base of an open cylinder and the other side becomes its height. What is the largest possible volume of such a cylinder?",
  "MCQ",
  r"Let the side that becomes the circumference be $c$; the height is $18 - c$. Then $r = \frac{c}{2\pi}$ and $V = \frac{c^2(18 - c)}{4\pi}$. Writing $c^2(18 - c) = 4 \cdot \frac{c}{2} \cdot \frac{c}{2} \cdot (18 - c)$, AM-GM on the three terms (sum $18$) gives the maximum at $\frac{c}{2} = 18 - c$, so $c = 12$, height $6$. Then $V = \frac{144 \times 6}{4\pi} = \frac{216}{\pi}$ cm$^3$.",
  r"Assuming a square sheet is best, or using $r = \frac{c}{\pi}$.",
  "C18B-cylinder-rolled-sheet", "Needs a volume function of one variable and an optimisation by weighted AM-GM.",
  correct=r"$\frac{216}{\pi}$ cm$^3$",
  distractors=[(r"$\frac{729}{4\pi}$ cm$^3$", r"Assumes a square $9 \times 9$ sheet is best: $\frac{81 \times 9}{4\pi}$."),
               (r"$\frac{108}{\pi}$ cm$^3$", r"Rolls the optimal $12 \times 6$ sheet the other way, with $6$ as circumference: $\frac{36 \times 12}{4\pi}$."),
               (r"$\frac{864}{\pi}$ cm$^3$", r"Takes $r = \frac{c}{\pi}$ (circumference as $\pi r$), so $V = \frac{c^2 h}{\pi} = \frac{144 \times 6}{\pi}$.")],
  check=_c013, values=[216 / pi, Rational(729, 4) / pi, 108 / pi, 864 / pi], cognitive="Analysis", exams=CX)


# ================================================================ 014
def _c014():
    r, l = 9, 15
    h = sqrt(l**2 - r**2)
    return Rational(1, 3) * r**2 * h        # coefficient of pi
f = Fig()
f.poly((-9, 0), (9, 0), (0, 12))
_ellipse(f, 0, 0, 9, 2.2, dashed_back=True)
f.seg((0, 0), (9, 0)); f.label_seg((0, 0), (9, 0), "9 m", side=-1)
f.label_seg((0, 12), (-9, 0), "15 m")
f.pt("", 0, 0)
_alt = "Front view of a cone with base radius 9 m drawn from the centre of the base to its edge, and slant height 15 m marked along one side."
q("C18-B-014", T, "Volume of a cone from its radius and slant height", "Easy",
  "Multi-step word problem",
  r"A conical heap of grain has a base radius of $9$ m and a slant height of $15$ m. Its volume is $k\pi$ m$^3$. What is the value of $k$?",
  "TITA",
  r"The height is $\sqrt{15^2 - 9^2} = \sqrt{144} = 12$ m. Volume $= \frac{1}{3}\pi \times 81 \times 12 = 324\pi$ m$^3$, so $k = 324$.",
  "Using the slant height as the vertical height.",
  "C18B-cone-slant-height", "Two steps: Pythagoras for the height, then the volume formula.",
  tita_answer=324, check=_c014, values=[324],
  tita_traps=[(405, r"Uses the slant height $15$ as the height: $\frac{1}{3} \times 81 \times 15$."),
              (972, r"Forgets the $\frac{1}{3}$: $81 \times 12$.")],
  cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 015
def _c015():
    r, l = symbols('r l', positive=True)
    lsol = solve(Eq(pi * r * l, 2 * pi * r**2), l)[0]
    h = sqrt(lsol**2 - r**2)
    return simplify(h / r)
q("C18-B-015", T, "Shape of a cone whose curved area is twice its base area", "Medium",
  "Conceptual/application",
  r"The curved surface area of a right circular cone is exactly twice the area of its base. What is the ratio of the height of the cone to the radius of its base?",
  "MCQ",
  r"$\pi r l = 2\pi r^2$ gives $l = 2r$. Then $h = \sqrt{l^2 - r^2} = \sqrt{4r^2 - r^2} = \sqrt{3}\,r$, so $h : r = \sqrt{3} : 1$.",
  "Stopping at the slant-to-radius ratio or adding squares instead of subtracting.",
  "C18B-cone-slant-height", "A ratio set-up with no numbers; requires linking curved area, slant height and height.",
  correct=r"$\sqrt{3} : 1$",
  distractors=[(r"$2 : 1$", r"Reports $l : r$ instead of $h : r$."),
               (r"$\sqrt{5} : 1$", r"Computes $h = \sqrt{l^2 + r^2} = \sqrt{5}\,r$."),
               (r"$1 : \sqrt{3}$", r"Reports $r : h$.")],
  check=_c015, values=[sqrt(3), 2, sqrt(5), 1 / sqrt(3)], cognitive="Understanding")


# ================================================================ 016
def _c016():
    r = symbols('r', positive=True)
    hemi_tsa = 2 * pi * r**2 + pi * r**2
    return simplify(2 * hemi_tsa / (4 * pi * r**2))
q("C18-B-016", T, "Surface area gained when a sphere is cut into two hemispheres", "Easy",
  "Conceptual/application",
  r"A solid wooden ball is sawn into two equal hemispheres. What is the ratio of the total surface area of the two hemispheres together to the surface area of the original ball?",
  "MCQ",
  r"Each hemisphere has curved area $2\pi r^2$ and a flat face $\pi r^2$, total $3\pi r^2$. Two hemispheres give $6\pi r^2$, against $4\pi r^2$ for the ball. The ratio is $6 : 4 = 3 : 2$.",
  "Forgetting the new flat faces, or counting only one of them.",
  "C18B-hemisphere-surface", "One idea: cutting creates two new circular faces.",
  correct=r"$3 : 2$",
  distractors=[(r"$1 : 1$", "Ignores the two new flat faces."),
               (r"$3 : 4$", r"Uses one hemisphere ($3\pi r^2$) against the ball ($4\pi r^2$)."),
               (r"$5 : 4$", r"Adds only one new flat face: $4\pi r^2 + \pi r^2$.")],
  check=_c016, values=[Rational(3, 2), 1, Rational(3, 4), Rational(5, 4)], cognitive="Understanding")


# ================================================================ 017
def _c017():
    rod = pi * 3**2 * 32
    ball = Rational(4, 3) * pi * 2**3
    return rod / ball
q("C18-B-017", T, "Number of balls recast from a cylindrical rod", "Easy",
  "Single-step computation",
  r"A solid metal rod in the shape of a cylinder has radius $3$ cm and length $32$ cm. It is melted and recast, with no loss of metal, into solid spherical balls each of radius $2$ cm. How many balls are made?",
  "MCQ",
  r"Rod volume $= \pi \times 9 \times 32 = 288\pi$ cm$^3$. Each ball has volume $\frac{4}{3}\pi \times 8 = \frac{32\pi}{3}$ cm$^3$. Number of balls $= 288 \times \frac{3}{32} = 27$.",
  "Using a wrong formula for the volume of a sphere.",
  "C18B-recast-count", "Volume conservation with one division.",
  correct=r"$27$",
  distractors=[(r"$18$", r"Uses the surface area $4\pi r^2 = 16\pi$ for each ball: $\frac{288}{16}$."),
               (r"$36$", r"Uses $\pi r^3 = 8\pi$, dropping the $\frac{4}{3}$: $\frac{288}{8}$."),
               (r"$54$", r"Uses $\frac{4}{3}\pi r^2 = \frac{16\pi}{3}$, squaring instead of cubing the radius.")],
  check=_c017, values=[27, 18, 36, 54], cognitive="Application")


# ================================================================ 018
def _c018():
    metal = Rational(9, 10) * Rational(4, 3) * pi * 9**3
    cone = Rational(1, 3) * pi * 3**2 * 4
    n = 0
    while (n + 1) * cone <= metal:
        n += 1
    return n
q("C18-B-018", T, "Complete cones recast from a sphere with metal lost in melting", "Medium",
  "Multi-step word problem",
  r"A solid metal sphere of radius $9$ cm is melted, and $10\%$ of the metal is lost in the process. The remaining metal is used to cast solid cones, each of base radius $3$ cm and height $4$ cm. What is the largest number of complete cones that can be cast?",
  "MCQ",
  r"Sphere volume $= \frac{4}{3}\pi \times 729 = 972\pi$; after the loss, $0.9 \times 972\pi = 874.8\pi$. Each cone has volume $\frac{1}{3}\pi \times 9 \times 4 = 12\pi$. Then $\frac{874.8}{12} = 72.9$, so $72$ complete cones can be cast.",
  r"Ignoring the loss, rounding up, or forgetting the $\frac{1}{3}$ in the cone volume.",
  "C18B-recast-count", "Three steps: loss, cone volume, and taking the whole-number part correctly.",
  correct=r"$72$",
  distractors=[(r"$81$", r"Ignores the $10\%$ loss: $\frac{972}{12}$."),
               (r"$73$", r"Rounds $72.9$ up, although the last cone would be incomplete."),
               (r"$24$", r"Uses $\pi r^2 h = 36\pi$ for the cone: $\frac{874.8}{36} = 24.3$.")],
  check=_c018, values=[72, 81, 73, 24], cognitive="Application")


# ================================================================ 019
def _c019():
    tub = pi * 6**2 * 15
    serve = Rational(1, 3) * pi * 3**2 * 12 + Rational(2, 3) * pi * 3**3
    return tub / serve
q("C18-B-019", T, "Number of cone-and-hemisphere servings from a cylindrical tub", "Medium",
  "Multi-step word problem",
  r"A cylindrical tub of internal radius $6$ cm and height $15$ cm is full of ice cream. The ice cream is served in cones of internal radius $3$ cm and height $12$ cm; each cone is filled completely and topped with a hemisphere of ice cream of radius $3$ cm. How many such cones can be served from the tub, using all the ice cream?",
  "TITA",
  r"Tub: $\pi \times 36 \times 15 = 540\pi$ cm$^3$. One serving: cone $\frac{1}{3}\pi \times 9 \times 12 = 36\pi$ plus hemisphere $\frac{2}{3}\pi \times 27 = 18\pi$, total $54\pi$. Number of cones $= \frac{540}{54} = 10$.",
  "Forgetting the hemispherical top, or using the full-sphere volume for it.",
  "C18B-recast-count", "A composite serving volume combined with a volume ratio.",
  tita_answer=10, check=_c019, values=[10],
  tita_traps=[(15, r"Ignores the hemispherical top: $\frac{540}{36}$."),
              (7, r"Uses a full sphere $36\pi$ for the top: $\frac{540}{72} = 7.5$, so $7$.")],
  cognitive="Application")


# ================================================================ 020
def _c020():
    dims = (24, 18, 15)
    best = None
    for e in range(1, 16):
        if all(d_ % e == 0 for d_ in dims):
            best = e
    return (24 // best) * (18 // best) * (15 // best)
q("C18-B-020", T, "Fewest identical cubes cut from a cuboid without waste", "Easy",
  "Single-step computation",
  r"A wooden block measuring $24$ cm by $18$ cm by $15$ cm is cut into identical cubes with no wood wasted. The edge of each cube is a whole number of centimetres and is as large as possible. How many cubes are obtained?",
  "MCQ",
  r"The largest edge dividing $24$, $18$ and $15$ is their HCF, $3$ cm. The number of cubes is $\frac{24}{3} \times \frac{18}{3} \times \frac{15}{3} = 8 \times 6 \times 5 = 240$.",
  "Dividing the volume by the area of a face of a cube, or adding the counts along each edge.",
  "C18B-cuboid-into-largest-cubes", "HCF of the edges, then one product.",
  correct=r"$240$",
  distractors=[(r"$720$", r"Divides the volume $6480$ by $3^2 = 9$ instead of $3^3$."),
               (r"$6480$", r"Uses $1$ cm cubes, the smallest instead of the largest edge."),
               (r"$19$", r"Adds $8 + 6 + 5$ instead of multiplying.")],
  check=_c020, values=[240, 720, 6480, 19], cognitive="Application")


# ================================================================ 021
def _c021():
    h = symbols('h', positive=True)
    shell = Rational(4, 3) * pi * (6**3 - 3**3)
    return solve(Eq(Rational(1, 3) * pi * 6**2 * h, shell), h)[0]
q("C18-B-021", T, "Height of a cone recast from a hollow sphere", "Medium",
  "Inverse/parameter",
  r"A hollow metal sphere has an external radius of $6$ cm and an internal radius of $3$ cm. It is melted and recast, with no loss, into a solid cone of base radius $6$ cm. What is the height of the cone, in cm?",
  "TITA",
  r"Metal volume $= \frac{4}{3}\pi(6^3 - 3^3) = \frac{4}{3}\pi \times 189 = 252\pi$ cm$^3$. The cone: $\frac{1}{3}\pi \times 36 \times h = 12\pi h = 252\pi$, so $h = 21$ cm.",
  "Using the solid sphere of radius $6$, ignoring the hollow interior.",
  "C18B-recast-dimension", "Shell volume by subtraction, then solve a linear equation for the height.",
  tita_answer=21, check=_c021, values=[21],
  tita_traps=[(24, r"Ignores the cavity: $\frac{288\pi}{12\pi}$."),
              (27, r"Adds the cavity volume instead of subtracting: $\frac{288 + 36}{12}$."),
              (7, r"Forgets the $\frac{1}{3}$ in the cone: $36\pi h = 252\pi$.")],
  cognitive="Application")


# ================================================================ 022
def _c022():
    L = symbols('L', positive=True)
    sphere = Rational(4, 3) * pi * 6**3           # cm^3
    r_w = Rational(2, 10) / 1                       # 4 mm diameter -> 0.2 cm radius
    Lcm = solve(Eq(pi * r_w**2 * L, sphere), L)[0]
    return Lcm / 100                                # metres
q("C18-B-022", T, "Length of wire drawn from a solid sphere", "Medium",
  "Multi-step word problem",
  r"A solid copper sphere of radius $6$ cm is melted and drawn into a uniform cylindrical wire of diameter $4$ mm, with no loss of copper. What is the length of the wire?",
  "MCQ",
  r"Sphere volume $= \frac{4}{3}\pi \times 216 = 288\pi$ cm$^3$. The wire radius is $2$ mm $= 0.2$ cm, so its cross-section is $0.04\pi$ cm$^2$. Length $= \frac{288\pi}{0.04\pi} = 7200$ cm $= 72$ m.",
  "Using the diameter as the radius or slipping in the sphere volume formula.",
  "C18B-recast-dimension", "Volume conservation with a mm to cm conversion.",
  correct=r"$72$ m",
  distractors=[(r"$18$ m", r"Takes the radius of the wire as $4$ mm: $\frac{288\pi}{0.16\pi} = 1800$ cm."),
               (r"$54$ m", r"Uses $\pi r^3 = 216\pi$ for the sphere: $\frac{216}{0.04} = 5400$ cm."),
               (r"$36$ m", r"Uses $4\pi r^2 = 144\pi$ (surface area) for the sphere: $3600$ cm.")],
  check=_c022, values=[72, 18, 54, 36], cognitive="Application")


# ================================================================ 023
def _c023():
    r = symbols('r', positive=True)
    hemi = Rational(2, 3) * pi * 6**3
    rin = solve(Eq(pi * (5**2 - r**2) * 16, hemi), r)[0]
    return 2 * rin
q("C18-B-023", T, "Internal diameter of a pipe recast from a hemisphere", "Medium",
  "Inverse/parameter",
  r"A solid metal hemisphere of radius $6$ cm is melted and recast, with no loss, into a hollow cylindrical pipe of length $16$ cm and external radius $5$ cm. What is the internal diameter of the pipe, in cm?",
  "TITA",
  r"Hemisphere volume $= \frac{2}{3}\pi \times 216 = 144\pi$ cm$^3$. Pipe volume $= \pi(5^2 - r^2) \times 16 = 144\pi$, so $25 - r^2 = 9$ and $r = 4$ cm. The internal diameter is $8$ cm.",
  "Reporting the internal radius or the thickness.",
  "C18B-recast-dimension", "Hollow-cylinder volume set equal to a hemisphere, then convert radius to diameter.",
  tita_answer=8, check=_c023, values=[8],
  tita_traps=[(4, "Reports the internal radius instead of the diameter."),
              (1, r"Reports the thickness $5 - 4$ of the pipe wall.")],
  cognitive="Application")


# ================================================================ 024
def _c024():
    R = symbols('R', positive=True)
    rs = solve(Eq(27 * Rational(4, 3) * pi * symbols('s', positive=True)**3, Rational(4, 3) * pi * R**3), symbols('s', positive=True))[0]
    new = 27 * 4 * pi * rs**2
    return simplify((new - 4 * pi * R**2) / (4 * pi * R**2) * 100)
q("C18-B-024", T, "Change in total surface area when a sphere is recast into many equal spheres", "Medium",
  "Conceptual/application",
  r"A solid sphere is melted and recast, with no loss, into $27$ identical smaller solid spheres. By what percentage does the total surface area increase?",
  "MCQ",
  r"Each small sphere has $\frac{1}{27}$ of the volume, so its radius is $\frac{r}{3}$ and its area is $\frac{1}{9}$ of the original. The total area is $27 \times \frac{1}{9} = 3$ times the original, an increase of $200\%$.",
  r"Confusing a ratio of $3$ with an increase of $300\%$, or using the wrong power of $27$.",
  "C18B-recast-surface-area-change", "Needs the volume to radius to area chain and careful percentage language.",
  correct=r"$200\%$",
  distractors=[(r"$300\%$", r"Takes the area ratio $3$ itself as the percentage increase."),
               (r"$800\%$", r"Uses $27^{2/3} = 9$ as the total area ratio, an increase of $800\%$."),
               (r"$2600\%$", r"Assumes each small sphere keeps the original surface area, so $27$ times.")],
  check=_c024, values=[200, 300, 800, 2600], cognitive="Understanding")


# ================================================================ 025
def _c025():
    h = symbols('h', positive=True)
    return solve(Eq(pi * 18**2 * h, Rational(4, 3) * pi * 9**3), h)[0]
f = Fig()
f.seg((-18, 0), (18, 0)); f.seg((-18, 0), (-18, 30)); f.seg((18, 0), (18, 30))
f.seg((-18, 20), (18, 20), dashed=True)
f.circle((0, 9), 9)
f.seg((0, 9), (9, 9)); f.label_seg((0, 9), (9, 9), "9 cm", side=-1)
f.seg((0, 26), (18, 26)); f.label_seg((0, 26), (18, 26), "18 cm")
f.pt("", 0, 9)
_alt = "Front view of a cylindrical vessel of radius 18 cm containing water, shown by a dashed water line, with a solid sphere of radius 9 cm resting at the bottom, fully under water."
q("C18-B-025", T, "Rise in water level when a sphere is submerged in a cylinder", "Easy",
  "Multi-step word problem",
  r"A cylindrical vessel with internal radius $18$ cm contains water. A solid metal sphere of radius $9$ cm is lowered into it and is completely submerged; no water overflows. By how many cm does the water level rise?",
  "TITA",
  r"The rise $h$ satisfies $\pi \times 18^2 \times h = \frac{4}{3}\pi \times 9^3$, that is $324h = 972$, so $h = 3$ cm.",
  "Using the surface area of the sphere or the wrong radius for the vessel.",
  "C18B-water-level-immersion", "One volume equation; the traps are formula slips.",
  tita_answer=3, check=_c025, values=[3],
  tita_traps=[(1, r"Uses the sphere's surface area $4\pi r^2 = 324\pi$ as its volume."),
              (12, r"Takes the vessel radius as $9$ cm: $\frac{972}{81}$.")],
  cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 026
def _c026():
    base, cube, d0 = 40 * 25, 20, 15
    water = base * d0
    # simulate: raise the level in small steps until the water volume is used up
    level, step, used = Fraction(0), Fraction(1, 100), Fraction(0)
    while True:
        layer = (base - (cube * cube if level < cube else 0)) * step
        if used + layer > water:
            break
        used += layer; level += step
    h = level + (water - used) / (base - (cube * cube if level < cube else 0))
    assert h > cube                               # the cube ends up fully covered
    assert h == Fraction(water + cube**3, base)
    return h
f = Fig()
f.seg((0, 0), (40, 0)); f.seg((0, 0), (0, 30)); f.seg((40, 0), (40, 30))
f.seg((0, 15), (40, 15), dashed=True)
f.poly((10, 36), (30, 36), (30, 56), (10, 56))
f.label_seg((0, 0), (40, 0), "40 cm"); f.label_seg((10, 56), (30, 56), "20 cm")
f.text((-4.5, 15), "15 cm"); f.pt("", -9, 15, dot=False)
_alt = "Front view of a rectangular tank 40 cm wide (and 25 cm from front to back) with a dashed line marking the water depth of 15 cm before the cube is placed; a cube of edge 20 cm is shown above the tank, about to be lowered in. Figure not to scale."
q("C18-B-026", T, "Water depth after placing a cube in a tank: deciding between partial and full submersion", "Difficult",
  "Conceptual/application",
  r"A rectangular glass tank has a base measuring $40$ cm by $25$ cm and contains water to a depth of $15$ cm. A solid metal cube of edge $20$ cm is placed on the floor of the tank and stays there. The tank is tall enough that no water overflows. What is the new depth of the water?",
  "MCQ",
  r"The base area is $1000$ cm$^2$, the water is $15000$ cm$^3$ and the cube is $8000$ cm$^3$. If the cube stuck out of the water, the water would fill the base minus the cube's footprint: $(1000 - 400)h = 15000$ gives $h = 25$ cm, which is more than $20$ cm, a contradiction. So the cube is fully covered, and $1000h = 15000 + 8000$ gives $h = 23$ cm, which is indeed above the cube.",
  "Applying the partly-submerged formula without checking that the resulting level stays below the top of the cube.",
  "C18B-water-level-partial-immersion", "Two possible cases; the partly-submerged formula gives an impossible $25$ cm, so the candidate must test it and switch to the fully submerged case.",
  correct=r"$23$ cm",
  distractors=[(r"$25$ cm", r"Uses the partly-submerged formula $(1000 - 400)h = 15000$ without checking that $25$ exceeds the cube's height."),
               (r"$20$ cm", "Assumes the water rises exactly to the top of the cube."),
               (r"$8$ cm", r"Reports the rise $23 - 15$ instead of the new depth.")],
  check=_c026, values=[23, 25, 20, 8], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 027
def _c027():
    t = symbols('t', positive=True)
    flow = pi * 2**2 * 50                    # cm^3 per second (0.5 m/s = 50 cm/s)
    need = pi * 50**2 * 48
    sec = solve(Eq(flow * t, need), t)[0]
    return sec / 60
q("C18-B-027", T, "Time to raise the water level in a tank through a pipe", "Medium",
  "Multi-step word problem",
  r"Water flows at a constant speed of $0.5$ m/s through a pipe of internal radius $2$ cm into a cylindrical tank of internal radius $50$ cm. How many minutes does it take for the water level in the tank to rise by $48$ cm?",
  "TITA",
  r"In cm: speed $50$ cm/s, so flow $= \pi \times 2^2 \times 50 = 200\pi$ cm$^3$ per second. Water needed $= \pi \times 50^2 \times 48 = 120000\pi$ cm$^3$. Time $= \frac{120000}{200} = 600$ s $= 10$ minutes.",
  "Unit slips between m/s and cm/s, or giving the time in seconds.",
  "C18B-flow-through-pipe", "Flow rate as cross-section times speed, with unit conversion.",
  tita_answer=10, check=_c027, values=[10],
  tita_traps=[(600, "Gives the time in seconds."),
              (100, r"Converts $0.5$ m/s to $5$ cm/s, getting $6000$ s.")],
  cognitive="Application")


# ================================================================ 028
def _c028():
    n = 6
    cnt = 0
    for i, j, k in itertools.product(range(n), repeat=3):
        faces = sum(1 for c in (i, j, k) if c in (0, n - 1))
        cnt += (faces == 2)
    return cnt
q("C18-B-028", T, "Small cubes with exactly two painted faces", "Easy",
  "Single-step computation",
  r"A wooden cube of edge $6$ cm is painted blue on all six faces and then cut into $1$ cm cubes. How many of the small cubes have exactly two blue faces?",
  "TITA",
  r"Cubes with exactly two painted faces lie along the $12$ edges, excluding the corner cubes. Each edge has $6 - 2 = 4$ of them, so the count is $12 \times 4 = 48$.",
  "Including the corners on each edge, or confusing the face and edge counts.",
  "C18B-painted-cube-count", "Direct use of the edge rule with one trap about corners.",
  tita_answer=48, check=_c028, values=[48],
  tita_traps=[(72, r"Counts all $6$ cubes on each edge: $12 \times 6$."),
              (96, r"Gives the one-face count $6 \times 4^2$.")],
  cognitive="Application")


# ================================================================ 029
def _c029():
    L, B, H = 4, 5, 6
    cnt = 0
    for i, j, k in itertools.product(range(L), range(B), range(H)):
        faces = (i in (0, L - 1)) + (j in (0, B - 1)) + (k in (0, H - 1))
        cnt += (faces == 1)
    return cnt
q("C18-B-029", T, "Unit cubes with exactly one painted face from a painted cuboid", "Medium",
  "Multi-step word problem",
  r"A cuboid measuring $4$ cm by $5$ cm by $6$ cm is painted on all its faces and then cut into $1$ cm cubes. How many of the small cubes have exactly one painted face?",
  "MCQ",
  r"On each face, the one-face cubes form the inner rectangle with $2$ removed from each dimension. The $4 \times 5$ faces give $2 \times 3 = 6$ each, the $5 \times 6$ faces give $3 \times 4 = 12$ each, and the $4 \times 6$ faces give $2 \times 4 = 8$ each. With two faces of each kind, the total is $2(6 + 12 + 8) = 52$.",
  "Removing only one row from each dimension, or counting only three faces.",
  "C18B-painted-cuboid", "Three different face sizes; each pair must be handled separately.",
  correct=r"$52$",
  distractors=[(r"$26$", r"Counts only one face of each pair: $6 + 12 + 8$."),
               (r"$94$", r"Removes $1$ instead of $2$ from each dimension: $2(3 \times 4 + 4 \times 5 + 3 \times 5)$."),
               (r"$24$", r"Gives the number with no painted face, $2 \times 3 \times 4$.")],
  check=_c029, values=[52, 26, 94, 24], cognitive="Application")


# ================================================================ 030
def _c030():
    for n in range(3, 30):
        c = {0: 0, 1: 0, 2: 0, 3: 0}
        for i, j, k in itertools.product(range(n), repeat=3):
            c[(i in (0, n - 1)) + (j in (0, n - 1)) + (k in (0, n - 1))] += 1
        if c[1] == c[0]:
            return c[2]
q("C18-B-030", T, "Painted cube with as many one-face cubes as unpainted cubes", "Difficult",
  "Inverse/parameter",
  r"A large cube is painted on all six faces and then cut into identical small cubes, with $n$ small cubes along each edge, where $n > 2$. The number of small cubes with exactly one painted face is equal to the number of small cubes with no painted face. How many small cubes have exactly two painted faces?",
  "TITA",
  r"One painted face: $6(n - 2)^2$. No painted face: $(n - 2)^3$. Setting them equal, $n - 2 = 6$, so $n = 8$. Cubes with exactly two painted faces lie on the $12$ edges, $n - 2 = 6$ per edge: $12 \times 6 = 72$.",
  "Using $n$ instead of $n - 2$ in the counting formulas.",
  "C18B-painted-cube-count", "Requires setting up two counting formulas, solving for $n$, then applying a third formula.",
  tita_answer=72, check=_c030, values=[72],
  tita_traps=[(96, r"Uses $12n = 96$, forgetting to remove the two corner cubes on each edge."),
              (8, r"Reports $n = 8$ itself."),
              (512, r"Reports the total number of small cubes $8^3$.")],
  cognitive="Analysis", exams=CX)


# ================================================================ 031
def _c031():
    # frustum as difference of two similar cones: full cone radius 20, cut cone radius 10
    R, r_, h = 20, 10, 15
    H = h * R / (R - r_)                 # height of full cone
    return pi * (Rational(1, 3) * R**2 * H - Rational(1, 3) * r_**2 * (H - h))
f = Fig()
f.poly((-10, 0), (10, 0), (20, 15), (-20, 15))
_ellipse(f, 0, 15, 20, 3.2)
_ellipse(f, 0, 0, 10, 1.6, dashed_back=True)
f.seg((0, 0), (10, 0)); f.text((5, -3.4), "10 cm")
f.seg((0, 15), (20, 15)); f.text((10, 19.8), "20 cm")
f.seg((0, 0), (0, 15), dashed=True); f.text((-2.6, 7.5), "15 cm")
_alt = "Front view of a bucket shaped as a frustum of a cone, with bottom radius 10 cm, top radius 20 cm and vertical depth 15 cm shown by a dashed axis."
q("C18-B-031", T, "Capacity of a frustum-shaped bucket", "Medium",
  "Multi-step word problem",
  r"A bucket is in the shape of a frustum of a right circular cone. Its internal radii are $10$ cm at the bottom and $20$ cm at the top, and its internal depth is $15$ cm. What is the capacity of the bucket?",
  "MCQ",
  r"For a frustum, $V = \frac{\pi h}{3}(R^2 + Rr + r^2) = \frac{15\pi}{3}(400 + 200 + 100) = 5\pi \times 700 = 3500\pi$ cm$^3$.",
  "Treating the bucket as a cylinder of mean radius, or dropping the $Rr$ term.",
  "C18B-frustum-volume", "Direct frustum formula with a few multiplications; the traps are tempting shortcuts.",
  correct=r"$3500\pi$ cm$^3$",
  distractors=[(r"$3375\pi$ cm$^3$", r"Treats the bucket as a cylinder of mean radius $15$: $\pi \times 225 \times 15$."),
               (r"$2500\pi$ cm$^3$", r"Drops the $Rr$ term: $5\pi(400 + 100)$."),
               (r"$10500\pi$ cm$^3$", r"Forgets the $\frac{1}{3}$: $15\pi \times 700$.")],
  check=_c031, values=[3500 * pi, 3375 * pi, 2500 * pi, 10500 * pi], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 032
def _c032():
    R, r_, h = 15, 6, 12
    l = sqrt(h**2 + (R - r_)**2)
    # curved area as difference of two cone lateral areas (similar cones)
    Lbig = l * R / (R - r_)
    return pi * (R * Lbig - r_ * (Lbig - l))
q("C18-B-032", T, "Curved surface area of a frustum-shaped lampshade", "Medium",
  "Multi-step word problem",
  r"A lampshade is made of fabric in the shape of the curved surface of a frustum of a cone, open at both ends. The radii of its two circular ends are $6$ cm and $15$ cm, and its vertical height is $12$ cm. What area of fabric is needed for the curved surface?",
  "MCQ",
  r"Slant height $l = \sqrt{12^2 + (15 - 6)^2} = \sqrt{144 + 81} = 15$ cm. Curved area $= \pi(R + r)l = \pi \times 21 \times 15 = 315\pi$ cm$^2$.",
  "Using the vertical height in place of the slant height, or adding the end circles.",
  "C18B-frustum-surface", "Two steps: slant height from the radii difference, then the curved-area formula.",
  correct=r"$315\pi$ cm$^2$",
  distractors=[(r"$252\pi$ cm$^2$", r"Uses the vertical height $12$ in place of the slant height: $21 \times 12$."),
               (r"$576\pi$ cm$^2$", r"Adds both end circles: $315 + 36 + 225$, although the shade is open."),
               (r"$630\pi$ cm$^2$", r"Uses $2\pi(R + r)l$, doubling the curved area.")],
  check=_c032, values=[315 * pi, 252 * pi, 576 * pi, 630 * pi], cognitive="Application")


# ================================================================ 033
def _c033():
    k = symbols('k', positive=True)          # small cone height as a fraction of full height
    ks = solve(Eq(k**3, Rational(1, 2)), k)[0]
    return simplify(ks / (1 - ks))
_k = 0.5 ** (1 / 3)
f = Fig()
f.poly((-9, 0), (9, 0), (0, 15))
_ellipse(f, 0, 0, 9, 1.8, dashed_back=True)
_kd = 0.6                                # drawn at 3/5 of the height from V (ratio 3 : 2, not an option)
_y = 15 * (1 - _kd); _rx = 9 * _kd
f.seg((-_rx, _y), (_rx, _y), dashed=True)
f.pt("V", 0, 15, offset=(0, 1))
_alt = "Front view of a solid cone with apex V; a dashed horizontal line parallel to the base cuts it into a small cone at the top and a frustum at the bottom. Figure not to scale."
q("C18-B-033", T, "Height ratio when a cone is cut into two parts of equal volume", "Difficult",
  "Inverse/parameter",
  r"A solid right circular cone with apex $V$ is cut by a plane parallel to its base into two parts of equal volume: a small cone containing $V$ and a frustum. What is the ratio of the height of the small cone to the height of the frustum?",
  "MCQ",
  r"The small cone is similar to the whole cone. If its height is $k$ times the full height, its volume is $k^3$ times the full volume. Equal parts means $k^3 = \frac{1}{2}$, so $k = \frac{1}{\sqrt[3]{2}}$. The frustum's height is $(1 - k)$ of the whole, so the ratio is $k : (1 - k) = 1 : (\sqrt[3]{2} - 1)$.",
  "Using the square root (area scaling) or assuming equal volumes need equal heights.",
  "C18B-cone-similar-sections", "Needs similarity with cubic volume scaling and a careful ratio of the remaining height.",
  correct=r"$1 : (\sqrt[3]{2} - 1)$",
  distractors=[(r"$(\sqrt[3]{2} - 1) : 1$", "Inverts the ratio, giving frustum to small cone."),
               (r"$1 : (\sqrt{2} - 1)$", r"Uses area scaling $k^2 = \frac{1}{2}$ instead of volume scaling."),
               (r"$1 : 1$", "Assumes equal volumes come from cutting at half the height.")],
  check=_c033, values=[1 / (2**Rational(1, 3) - 1), 2**Rational(1, 3) - 1, 1 / (sqrt(2) - 1), 1],
  cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 034
def _c034():
    V = Fraction(1)
    first = V * Fraction(1, 27)          # depth one third of height: (1/3)^3 of volume
    rate = first / 3                     # per minute
    return (V - first) / (2 * rate)
f = Fig()
f.poly((-9, 18), (9, 18), (0, 0))
_ellipse(f, 0, 18, 9, 1.8)
f.seg((-3, 6), (3, 6), dashed=True)
f.seg((11, 0), (11, 18)); f.text((13, 9), "H")
f.seg((-5, 0), (-5, 6)); f.text((-8, 3), "H/3")
_alt = "An inverted cone with its vertex at the bottom and height H; a dashed line marks the water surface at depth H/3 above the vertex."
q("C18-B-034", T, "Filling time of an inverted cone after the pouring rate changes", "Difficult",
  "Multi-step word problem",
  r"An empty vessel in the shape of an inverted right circular cone (vertex at the bottom, axis vertical) is being filled with water at a constant rate. After $3$ minutes the depth of the water is one-third of the height of the vessel. At that moment the rate of pouring is doubled and kept constant. How many more minutes will it take to fill the vessel completely?",
  "TITA",
  r"The water forms a cone similar to the vessel, so at one-third of the depth it holds $\left(\frac{1}{3}\right)^3 = \frac{1}{27}$ of the capacity $V$. The first rate is $\frac{V}{27 \times 3} = \frac{V}{81}$ per minute, and the new rate is $\frac{2V}{81}$. The remaining $\frac{26V}{27}$ needs $\frac{26}{27} \times \frac{81}{2} = 39$ minutes.",
  "Assuming volume is proportional to depth, or ignoring the doubled rate.",
  "C18B-cone-similar-sections", "Cubic scaling against the intuition of linear filling, plus a change of rate.",
  tita_answer=39, check=_c034, values=[39],
  tita_traps=[(3, r"Assumes volume is proportional to depth: the remaining two-thirds at double rate takes $3$ minutes."),
              (78, r"Ignores the doubled rate: $26 \times 3$ minutes.")],
  cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 035
def _c035():
    L, ang = 10, 216
    arc = 2 * pi * L * Rational(ang, 360)
    r = arc / (2 * pi)
    h = sqrt(L**2 - r**2)
    return Rational(1, 3) * pi * r**2 * h
f = Fig()
_a0, _a1 = 90 - 108, 90 + 108
f.arc((0, 0), 10, _a0, _a1)
f.seg((0, 0), (10 * math.cos(math.radians(_a0)), 10 * math.sin(math.radians(_a0))))
f.seg((0, 0), (10 * math.cos(math.radians(_a1)), 10 * math.sin(math.radians(_a1))))
f.arc((0, 0), 1.6, _a0, _a1)
f.text((0, 2.8), "216^\\circ")
f.label_seg((0, 0), (10 * math.cos(math.radians(_a0)), 10 * math.sin(math.radians(_a0))), "10 cm", side=-1)
f.pt("O", 0, 0, offset=(0, -1.1))
_alt = "A sector of a circle with centre O, radius 10 cm and central angle 216 degrees, to be rolled into a cone."
q("C18-B-035", T, "Volume of the cone formed by rolling a sector", "Medium",
  "Multi-step word problem",
  r"A sector of a circle of radius $10$ cm with central angle $216^\circ$ is cut from a sheet of paper and rolled so that its two straight edges just meet, forming the curved surface of a cone. What is the volume of the cone?",
  "MCQ",
  r"The radius of the sector becomes the slant height, $l = 10$ cm. The arc length $2\pi \times 10 \times \frac{216}{360} = 12\pi$ becomes the base circumference, so $r = 6$ cm. Then $h = \sqrt{100 - 36} = 8$ cm and $V = \frac{1}{3}\pi \times 36 \times 8 = 96\pi$ cm$^3$.",
  "Using the slant height as the height, or swapping radius and height.",
  "C18B-cone-from-sector", "Three linked steps: arc to base radius, Pythagoras, volume.",
  correct=r"$96\pi$ cm$^3$",
  distractors=[(r"$128\pi$ cm$^3$", r"Swaps radius and height: $\frac{1}{3}\pi \times 64 \times 6$."),
               (r"$288\pi$ cm$^3$", r"Forgets the $\frac{1}{3}$: $\pi \times 36 \times 8$."),
               (r"$120\pi$ cm$^3$", r"Uses the slant height $10$ as the height: $\frac{1}{3}\pi \times 36 \times 10$.")],
  check=_c035, values=[96 * pi, 128 * pi, 288 * pi, 120 * pi], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 036
def _c036():
    L, ang = 25, 288
    r = L * Rational(ang, 360)
    return sqrt(L**2 - r**2)
q("C18-B-036", T, "Height of the cone formed from a large sector", "Easy",
  "Multi-step word problem",
  r"A party hat is made by rolling a sector of a circle of radius $25$ cm and central angle $288^\circ$ so that its straight edges just meet, forming a cone with no overlap. What is the height of the hat?",
  "MCQ",
  r"The slant height is $25$ cm. Matching arc length to base circumference, $2\pi r = 2\pi \times 25 \times \frac{288}{360}$, so $r = 20$ cm. Height $= \sqrt{25^2 - 20^2} = \sqrt{225} = 15$ cm.",
  "Reporting the base radius or the slant height, or subtracting lengths instead of squares.",
  "C18B-cone-from-sector", "Arc length to radius, then one Pythagoras step.",
  correct=r"$15$ cm",
  distractors=[(r"$20$ cm", "Reports the base radius of the hat."),
               (r"$25$ cm", "Reports the slant height."),
               (r"$5$ cm", r"Subtracts lengths: $25 - 20$.")],
  check=_c036, values=[15, 20, 25, 5], cognitive="Application")


# ================================================================ 037
def _c037():
    r, total = 3, 20
    cyl_len = total - 2 * r
    return pi * r**2 * cyl_len + Rational(4, 3) * pi * r**3
f = Fig()
f.seg((-7, 3), (7, 3)); f.seg((-7, -3), (7, -3))
f.arc((7, 0), 3, -90, 90); f.arc((-7, 0), 3, 90, 270)
f.seg((-7, 3), (-7, -3), dashed=True); f.seg((7, 3), (7, -3), dashed=True)
f.seg((-10, -5.2), (10, -5.2)); f.text((0, -6.6), "20 mm")
f.seg((12, -3), (12, 3)); f.text((14.3, 0), "6 mm"); f.pt("", 16.5, 0, dot=False)
_alt = "A capsule made of a cylinder with a hemisphere at each end; total length 20 mm and diameter 6 mm; dashed lines show where the hemispheres join the cylinder."
q("C18-B-037", T, "Volume of a capsule: cylinder with hemispherical ends", "Medium",
  "Multi-step word problem",
  r"A medicine capsule is shaped like a cylinder with a hemisphere attached at each end. The total length of the capsule, end to end, is $20$ mm and its diameter is $6$ mm. What is the volume of the capsule?",
  "MCQ",
  r"The radius is $3$ mm, so the two hemispheres take up $3 + 3 = 6$ mm of the length and the cylinder is $14$ mm long. Volume $= \pi \times 9 \times 14 + \frac{4}{3}\pi \times 27 = 126\pi + 36\pi = 162\pi$ cubic mm.",
  "Taking the full $20$ mm as the cylinder length, or counting only one hemisphere.",
  "C18B-composite-volume", "Composite solid: the overall length includes the hemispheres, which must be subtracted first.",
  correct=r"$162\pi$ cubic mm",
  distractors=[(r"$216\pi$ cubic mm", r"Uses a $20$ mm cylinder and adds two hemispheres: $180\pi + 36\pi$."),
               (r"$180\pi$ cubic mm", r"Treats the whole capsule as a cylinder of length $20$ mm."),
               (r"$144\pi$ cubic mm", r"Adds only one hemisphere: $126\pi + 18\pi$.")],
  check=_c037, values=[162 * pi, 216 * pi, 180 * pi, 144 * pi], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 038
def _c038():
    r, total = 6, 14
    hc = total - r
    l = sqrt(hc**2 + r**2)
    return 2 * r**2 + r * l                      # coefficient of pi
f = Fig()
f.arc((0, 0), 6, 180, 360)
f.poly((-6, 0), (6, 0), (0, 8))
f.seg((0, -6), (0, 8), dashed=True)
f.seg((9, -6), (9, 8)); f.text((11.3, 1), "14 cm")
f.label_seg((0, 0), (6, 0), "6 cm", side=-1)
_alt = "A toy made of a cone standing on a hemisphere of the same radius 6 cm; the total height from the bottom of the hemisphere to the tip of the cone is 14 cm."
q("C18-B-038", T, "Surface area of a toy: cone mounted on a hemisphere", "Medium",
  "Multi-step word problem",
  r"A solid toy is made of a cone mounted on a hemisphere, both of radius $6$ cm, with the flat face of the hemisphere exactly covered by the base of the cone. The total height of the toy is $14$ cm. The total outer surface area of the toy is $k\pi$ cm$^2$. What is the value of $k$?",
  "TITA",
  r"The cone's height is $14 - 6 = 8$ cm, so its slant height is $\sqrt{64 + 36} = 10$ cm. Outer surface $=$ hemisphere's curved area $+$ cone's curved area $= 2\pi \times 36 + \pi \times 6 \times 10 = 72\pi + 60\pi = 132\pi$ cm$^2$, so $k = 132$.",
  "Adding the hidden circular face, or using the height instead of the slant height.",
  "C18B-composite-surface", "Composite surface: identify which faces are exposed and find the slant height.",
  tita_answer=132, check=_c038, values=[132],
  tita_traps=[(168, r"Adds the hidden circular face $36\pi$."),
              (120, r"Uses the cone's height $8$ instead of its slant height: $72 + 48$.")],
  cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 039
def _c039():
    r, H, d = 6, 20, 8
    l = sqrt(r**2 + d**2)
    assert d + r < H                                  # the two cavities do not meet
    outer = 2 * pi * r * H                            # curved side of the cylinder
    cone_wall = pi * r * l                            # replaces the top face
    bowl = 2 * pi * r**2                              # hemispherical wall, replaces the bottom face
    return outer + cone_wall + bowl
f = Fig()
f.poly((-6, 0), (6, 0), (6, 20), (-6, 20))
f.seg((-6, 20), (0, 12), dashed=True); f.seg((6, 20), (0, 12), dashed=True)
f.arc((0, 0), 6, 0, 180, dashed=True)
f.label_seg((-6, 20), (0, 20), "6 cm")
f.seg((9, 0), (9, 20)); f.text((11.6, 10), "20 cm")
f.seg((0, 12), (0, 20)); f.text((1.7, 16.5), "8 cm")
f.pt("", 15, 10, dot=False)
_alt = "Front view of a solid cylinder of radius 6 cm and height 20 cm; dashed lines show a conical hollow 8 cm deep whose base is the whole top face, and a hemispherical hollow whose rim is the whole bottom face. Figure not to scale."
q("C18-B-039", T, "Total surface area of a cylinder with a conical cavity at one end and a hemispherical cavity at the other", "Difficult",
  "Multi-step word problem",
  r"A solid cylinder of radius $6$ cm and height $20$ cm is hollowed out at both ends. At the top, a conical cavity $8$ cm deep is cut whose base is the whole top face. At the bottom, a hemispherical cavity is cut whose rim is the whole bottom face. The two cavities do not meet. What is the total surface area (outside and inside) of the remaining solid?",
  "MCQ",
  r"Both flat faces are gone: the top is replaced by the cone's curved wall and the bottom by the hemisphere's curved wall. The cone's slant height is $\sqrt{6^2 + 8^2} = 10$ cm. Surface $=$ cylinder's curved area $+$ cone's curved area $+$ hemisphere's curved area $= 2\pi \times 6 \times 20 + \pi \times 6 \times 10 + 2\pi \times 36 = 240\pi + 60\pi + 72\pi = 372\pi$ cm$^2$.",
  r"Keeping removed flat faces, using the depth for the slant height, or taking the hemisphere's area as $3\pi r^2$.",
  "C18B-composite-surface", "Two different cavities replace both end faces; the candidate must track five surfaces, find a slant height and see that neither flat face survives.",
  correct=r"$372\pi$ cm$^2$",
  distractors=[(r"$444\pi$ cm$^2$", r"Also counts the two removed flat faces: $372\pi + 36\pi + 36\pi$."),
               (r"$360\pi$ cm$^2$", r"Uses the depth $8$ as the cone's slant height: $240\pi + 48\pi + 72\pi$."),
               (r"$408\pi$ cm$^2$", r"Takes the hemispherical cavity as $3\pi r^2$ (the solid hemisphere's total area), adding a flat face: $240\pi + 60\pi + 108\pi$.")],
  check=_c039, values=[372 * pi, 444 * pi, 360 * pi, 408 * pi], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 040
def _c040():
    r = Rational(12, 2)
    return Rational(4, 3) * pi * r**3
q("C18-B-040", T, "Largest sphere carved from a cube", "Easy",
  "Single-step computation",
  r"The largest possible solid sphere is carved out of a solid wooden cube of edge $12$ cm. What is the volume of the sphere?",
  "MCQ",
  r"The largest sphere touches all six faces, so its diameter equals the edge: $r = 6$ cm. Volume $= \frac{4}{3}\pi \times 216 = 288\pi$ cm$^3$.",
  "Taking the edge as the radius, or misusing the sphere formula.",
  "C18B-sphere-cube-inscribed", "One idea (diameter equals edge) and one formula.",
  correct=r"$288\pi$ cm$^3$",
  distractors=[(r"$2304\pi$ cm$^3$", r"Takes the edge $12$ as the radius: $\frac{4}{3}\pi \times 1728$."),
               (r"$216\pi$ cm$^3$", r"Drops the $\frac{4}{3}$: $\pi \times 6^3$."),
               (r"$144\pi$ cm$^3$", r"Computes the surface area $4\pi \times 36$ instead of the volume.")],
  check=_c040, values=[288 * pi, 2304 * pi, 216 * pi, 144 * pi], cognitive="Application")


# ================================================================ 041
def _c041():
    R, a = symbols('R a', positive=True)
    asol = solve(Eq(sqrt(3) * a, 2 * R), a)[0]
    return simplify(asol**3 / (Rational(4, 3) * pi * R**3))
q("C18-B-041", T, "Ratio of volumes of a cube inscribed in a sphere", "Medium",
  "Conceptual/application",
  r"A cube is placed inside a hollow sphere so that all eight vertices of the cube touch the sphere. What is the ratio of the volume of the cube to the volume of the sphere?",
  "MCQ",
  r"The space diagonal of the cube is a diameter: $a\sqrt{3} = 2R$, so $a = \frac{2R}{\sqrt{3}}$ and $a^3 = \frac{8R^3}{3\sqrt{3}}$. The ratio is $\frac{8R^3}{3\sqrt{3}} : \frac{4}{3}\pi R^3 = \frac{2}{\sqrt{3}} : \pi = 2\sqrt{3} : 3\pi$.",
  "Using the face diagonal or the edge as the diameter.",
  "C18B-sphere-cube-inscribed", "Needs the space-diagonal insight and a clean ratio with surds.",
  correct=r"$2\sqrt{3} : 3\pi$",
  distractors=[(r"$3\sqrt{2} : 2\pi$", r"Takes the face diagonal as the diameter: $a\sqrt{2} = 2R$."),
               (r"$3 : 4\pi$", r"Takes the edge equal to the radius: $a = R$."),
               (r"$\sqrt{3} : 12\pi$", r"Takes the space diagonal equal to the radius: $a\sqrt{3} = R$, so $a^3 = \frac{R^3}{3\sqrt{3}}$.")],
  check=_c041, values=[2 * sqrt(3) / (3 * pi), 3 * sqrt(2) / (2 * pi), 3 / (4 * pi), sqrt(3) / (12 * pi)], cognitive="Analysis")


# ================================================================ 042
def _c042():
    r = symbols('r', positive=True)
    can = pi * r**2 * (6 * r)
    balls = 3 * Rational(4, 3) * pi * r**3
    return simplify((can - balls) / can)
f = Fig()
f.poly((-1, 0), (1, 0), (1, 6), (-1, 6))
for _cy in (1, 3, 5):
    f.circle((0, _cy), 1)
_alt = "Front view of a cylindrical can holding three identical balls stacked vertically; each ball touches the side of the can, the balls touch each other, and the end balls touch the lid and the base."
q("C18-B-042", T, "Empty fraction of a can holding three snug balls", "Medium",
  "Conceptual/application",
  r"Three identical tennis balls fit exactly in a closed cylindrical can: each ball touches the curved side, adjacent balls touch each other, and the top and bottom balls touch the lid and the base. What fraction of the volume of the can is not occupied by the balls?",
  "MCQ",
  r"With ball radius $r$, the can has radius $r$ and height $6r$, so its volume is $6\pi r^3$. The balls occupy $3 \times \frac{4}{3}\pi r^3 = 4\pi r^3$. The empty fraction is $\frac{6 - 4}{6} = \frac{1}{3}$.",
  "Reporting the occupied fraction or misusing the sphere formula.",
  "C18B-spheres-in-cylinder", "Insight: the can's dimensions are fixed by the balls; the answer is independent of size.",
  correct=r"$\frac{1}{3}$",
  distractors=[(r"$\frac{2}{3}$", "Reports the occupied fraction."),
               (r"$\frac{1}{2}$", r"Uses $\pi r^3$ for each ball, dropping the $\frac{4}{3}$: $\frac{6 - 3}{6}$."),
               (r"$\frac{7}{9}$", r"Uses the volume of only one ball: $1 - \frac{4/3}{6}$.")],
  check=_c042, values=[Rational(1, 3), Rational(2, 3), Rational(1, 2), Rational(7, 9)], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 043
def _c043():
    rr = symbols('rr', positive=True)
    R, H = 60, 80
    # centre (0, rr) on the axis; distance to the slant line x/R + y/H = 1 equals rr
    line_dist = Abs(H * 0 + R * rr - R * H) / sqrt(H**2 + R**2)
    sol = solve(Eq(line_dist, rr), rr)
    return [s for s in sol if s < H / 2 + 1][0]
f = Fig()
f.poly((-60, 0), (60, 0), (0, 80))
f.seg((0, 0), (0, 80), dashed=True)
f.label_seg((0, 0), (60, 0), "60 cm")
f.seg((-70, 0), (-70, 80)); f.text((-80, 40), "80 cm"); f.pt("", -96, 40, dot=False)
_alt = "Vertical cross-section through the axis of a cone with base radius 60 cm and height 80 cm, shown as an isosceles triangle with the axis dashed. Figure not to scale."
q("C18-B-043", T, "Radius of the largest ball inside a cone (inscribed sphere)", "Difficult",
  "Conceptual/application",
  r"A closed conical container has base radius $60$ cm and height $80$ cm. What is the radius of the largest ball that can be placed inside it?",
  "MCQ",
  r"The largest ball touches the base and the curved surface, so in the vertical cross-section through the axis its circle is the incircle of an isosceles triangle with base $120$ cm, height $80$ cm and equal sides $\sqrt{60^2 + 80^2} = 100$ cm. Area $= \frac{1}{2} \times 120 \times 80 = 4800$; semi-perimeter $= \frac{100 + 100 + 120}{2} = 160$. Inradius $= \frac{4800}{160} = 30$ cm.",
  "Centring the ball at the base, or using the full perimeter in the inradius formula.",
  "C18B-inscribed-in-cone", "Needs reducing the 3D problem to the incircle of the axial cross-section.",
  correct=r"$30$ cm",
  distractors=[(r"$48$ cm", r"Centres the ball at the centre of the base and uses the distance to the slant side: $\frac{60 \times 80}{100}$."),
               (r"$40$ cm", "Assumes the ball's diameter equals the height of the cone."),
               (r"$15$ cm", r"Divides the area by the full perimeter $320$ instead of the semi-perimeter.")],
  check=_c043, values=[30, 48, 40, 15], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 044
def _c044():
    h = symbols('h', positive=True)
    R, H = 6, 12
    V = pi * (R * (H - h) / H)**2 * h
    crit = [s for s in solve(diff(V, h), h) if 0 < s < H]
    return max(V.subs(h, s) for s in crit)
f = Fig()
f.poly((-6, 0), (6, 0), (0, 12))
_hh = 3.0; _rr = 6 * (12 - _hh) / 12
f.poly((-_rr, 0), (_rr, 0), (_rr, _hh), (-_rr, _hh))
f.seg((0, 0), (0, 12), dashed=True)
f.label_seg((0, 0), (6, 0), "6 cm")
f.text((-1.6, 9), "12 cm")
_alt = "Vertical cross-section of a cone with base radius 6 cm and height 12 cm, with a rectangle standing on the base inside it representing a cylinder whose top rim touches the slant sides."
q("C18-B-044", T, "Largest cylinder that fits inside a cone", "Difficult",
  "Casework/optimisation",
  r"A right circular cone has base radius $6$ cm and height $12$ cm. A solid cylinder is placed inside it with its base on the base of the cone, its axis along the axis of the cone, and the rim of its top face touching the curved surface. What is the largest possible volume of such a cylinder?",
  "MCQ",
  r"If the cylinder has height $h$, similar triangles give radius $r = 6 \times \frac{12 - h}{12} = \frac{12 - h}{2}$. So $V = \pi \frac{(12 - h)^2}{4} h$. Writing $(12 - h)^2 h = 4 \cdot \frac{12 - h}{2} \cdot \frac{12 - h}{2} \cdot h$, AM-GM on the three terms (sum $12$) gives the maximum when $\frac{12 - h}{2} = h$, so $h = 4$, $r = 4$. Then $V = \pi \times 16 \times 4 = 64\pi$ cm$^3$.",
  "Guessing half the height, or taking a fixed fraction of the cone's volume.",
  "C18B-inscribed-in-cone", "Similar triangles to get one variable, then an optimisation via AM-GM.",
  correct=r"$64\pi$ cm$^3$",
  distractors=[(r"$54\pi$ cm$^3$", r"Takes the cylinder at half the cone's height: $h = 6$, $r = 3$, $\pi \times 9 \times 6$."),
               (r"$72\pi$ cm$^3$", r"Takes half the cone's volume $\frac{144\pi}{2}$."),
               (r"$48\pi$ cm$^3$", r"Takes one-third of the cone's volume $\frac{144\pi}{3}$.")],
  check=_c044, values=[64 * pi, 54 * pi, 72 * pi, 48 * pi], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ================================================================ 045
def _c045():
    seen = set()
    for a in range(1, 73):
        for b in range(1, 73):
            for c in range(1, 73):
                if a * b * c == 72 and 2 * (a * b + b * c + c * a) <= 150:
                    seen.add(tuple(sorted((a, b, c))))
    return len(seen)
q("C18-B-045", T, "Counting integer-edged boxes of fixed volume under a surface-area cap", "Difficult",
  "Casework/optimisation",
  r"A toy maker wants solid rectangular blocks of volume $72$ cm$^3$ whose length, breadth and height are all whole numbers of centimetres. Two blocks are counted as the same if one can be turned to match the other. How many different blocks have a total surface area of at most $150$ cm$^2$?",
  "TITA",
  r"List $a \le b \le c$ with $abc = 72$ and surface area $2(ab + bc + ca)$: $(1,1,72)$: $290$; $(1,2,36)$: $220$; $(1,3,24)$: $198$; $(1,4,18)$: $188$; $(1,6,12)$: $180$; $(1,8,9)$: $178$; $(2,2,18)$: $152$; $(2,3,12)$: $132$; $(2,4,9)$: $124$; $(2,6,6)$: $120$; $(3,3,8)$: $114$; $(3,4,6)$: $108$. Those with area at most $150$ are $(2,3,12)$, $(2,4,9)$, $(2,6,6)$, $(3,3,8)$, $(3,4,6)$: $5$ blocks.",
  "Counting orientations separately, or missing a factor triple.",
  "C18B-integer-cuboid-casework", "Systematic listing of twelve factor triples with a surface-area test for each; a near-miss case ($152$) must be excluded.",
  tita_answer=5, check=_c045, values=[5],
  tita_traps=[(24, "Counts ordered triples (orientations) instead of distinct blocks."),
              (6, r"Includes $(2,2,18)$ with area $152$, just above the limit."),
              (12, "Counts all factor triples without applying the area condition.")],
  cognitive="Analysis", exams=CX)
