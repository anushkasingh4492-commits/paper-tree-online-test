import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Surds"
CX = ("CAT", "XAT")
s2, s3, s5, s6 = sqrt(2), sqrt(3), sqrt(5), sqrt(6)


def _rat_irr(expr, rad):
    """Return (rational part, coefficient of sqrt(rad)) of a simplified a + b*sqrt(rad)."""
    e = expand(radsimp(expr))
    b = e.coeff(sqrt(rad))
    a = simplify(e - b * sqrt(rad))
    return a, b


# ---------------------------------------------------------------- 001
def _c001():
    return radsimp(6 / (s5 - s2))
q("C12-B-001", T, "Rationalising a binomial surd denominator", "Easy",
  "Single-step computation",
  r"When the denominator of $\frac{6}{\sqrt{5}-\sqrt{2}}$ is rationalised, the expression equals",
  "MCQ",
  r"Multiply numerator and denominator by the conjugate $\sqrt{5}+\sqrt{2}$. The denominator becomes $(\sqrt{5})^2-(\sqrt{2})^2 = 5-2 = 3$. So the expression is $\frac{6(\sqrt{5}+\sqrt{2})}{3} = 2(\sqrt{5}+\sqrt{2})$.",
  r"Treating $(\sqrt5-\sqrt2)(\sqrt5+\sqrt2)$ as $5+2$ or as $\sqrt{5-2}$.",
  "C12B-rationalise-binomial", "One conjugate multiplication with a single trap in the denominator.",
  correct=r"$2(\sqrt{5}+\sqrt{2})$",
  distractors=[(r"$2(\sqrt{5}-\sqrt{2})$", r"Multiplies by the conjugate but keeps the original sign in the numerator, writing $6(\sqrt5-\sqrt2)$ over $3$."),
               (r"$\frac{6}{7}(\sqrt{5}+\sqrt{2})$", r"Computes the new denominator as $5+2 = 7$."),
               (r"$2\sqrt{3}(\sqrt{5}+\sqrt{2})$", r"Takes the new denominator as $\sqrt{5-2} = \sqrt3$, giving $\frac{6}{\sqrt3}(\sqrt5+\sqrt2) = 2\sqrt3(\sqrt5+\sqrt2)$.")],
  check=_c001, values=[2 * (s5 + s2), 2 * (s5 - s2), Rational(6, 7) * (s5 + s2), 2 * s3 * (s5 + s2)],
  cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    u = cbrt(2)
    x = 3 / (cbrt(4) + u + 1)
    # rationalise with (u - 1): (u - 1)(u^2 + u + 1) = u^3 - 1 = 1
    xr = expand(3 * (u - 1) / (u**3 - 1))
    assert abs(N(x - xr, 50)) < Float("1e-40")
    val = expand((xr + 3)**3)
    assert abs(N((x + 3)**3 - val, 50)) < Float("1e-40")
    return nsimplify(val)
q("C12-B-002", T, "Rationalising a denominator of cube roots with the difference of cubes", "Easy",
  "Single-step computation",
  r"If $x = \frac{3}{\sqrt[3]{4}+\sqrt[3]{2}+1}$, what is the value of $(x+3)^3$?",
  "TITA",
  r"With $u = \sqrt[3]{2}$ the denominator is $u^2+u+1$, and $(u-1)(u^2+u+1) = u^3-1 = 2-1 = 1$. So multiplying numerator and denominator by $u-1$ gives $x = 3(\sqrt[3]{2}-1) = 3\sqrt[3]{2}-3$. Then $x+3 = 3\sqrt[3]{2}$ and $(x+3)^3 = 27 \times 2 = 54$.",
  r"Cubing $3\sqrt[3]{2}$ as $3 \times 2$, or rationalising with a square-root style conjugate.",
  "C12B-rationalise-cube-root", "One difference-of-cubes rationalisation and a cube.",
  tita_answer=54, check=_c002,
  tita_traps=[(6, r"Finds $x+3 = 3\sqrt[3]{2}$ but cubes only the cube root, writing $3 \times 2$."),
              (27, r"Finds $x + 3 = 3\sqrt[3]{2}$ and cubes only the coefficient $3$, losing the factor $(\sqrt[3]{2})^3 = 2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    e = 1 / (s3 + s2) - 2 / (s5 + s3) + 3 / (s5 + s2)
    return simplify(radsimp(e))
q("C12-B-003", T, "Simplifying a combination of three rationalised terms", "Medium",
  "Conceptual/application",
  r"The value of $\frac{1}{\sqrt{3}+\sqrt{2}} - \frac{2}{\sqrt{5}+\sqrt{3}} + \frac{3}{\sqrt{5}+\sqrt{2}}$ is",
  "MCQ",
  r"Rationalise each term: $\frac{1}{\sqrt3+\sqrt2} = \sqrt3-\sqrt2$, $\frac{2}{\sqrt5+\sqrt3} = \frac{2(\sqrt5-\sqrt3)}{2} = \sqrt5-\sqrt3$ and $\frac{3}{\sqrt5+\sqrt2} = \frac{3(\sqrt5-\sqrt2)}{3} = \sqrt5-\sqrt2$. The expression is $(\sqrt3-\sqrt2)-(\sqrt5-\sqrt3)+(\sqrt5-\sqrt2) = 2\sqrt3-2\sqrt2$.",
  "Mishandling the subtraction of a bracketed surd or the numerators $2$ and $3$.",
  "C12B-rationalise-binomial", "Three rationalisations whose numerators cancel the new denominators, then careful signs.",
  correct=r"$2\sqrt{3}-2\sqrt{2}$",
  distractors=[(r"$2\sqrt{5}-2\sqrt{2}$", r"Adds the middle term: $(\sqrt3-\sqrt2)+(\sqrt5-\sqrt3)+(\sqrt5-\sqrt2)$."),
               (r"$2\sqrt{2}-2\sqrt{3}$", r"Rationalises each term in reverse order, e.g. $\frac{1}{\sqrt3+\sqrt2} = \sqrt2-\sqrt3$, which flips the sign of the result."),
               (r"$3\sqrt{3}-\sqrt{5}-2\sqrt{2}$", r"Does not divide the middle term by its new denominator $2$, using $2(\sqrt5-\sqrt3)$.")],
  check=_c003, values=[2 * s3 - 2 * s2, 2 * s5 - 2 * s2, 2 * s2 - 2 * s3, 3 * s3 - s5 - 2 * s2],
  cognitive="Application")

# ---------------------------------------------------------------- 004
def _c004():
    return radsimp(1 / (1 + s2 + s3))
q("C12-B-004", T, "Rationalising a three-term surd denominator", "Medium",
  "Conceptual/application",
  r"When the denominator of $\frac{1}{1+\sqrt{2}+\sqrt{3}}$ is fully rationalised, the expression equals",
  "MCQ",
  r"Group as $(1+\sqrt2)+\sqrt3$ and multiply by $(1+\sqrt2)-\sqrt3$. The denominator becomes $(1+\sqrt2)^2-3 = 3+2\sqrt2-3 = 2\sqrt2$, so the expression is $\frac{1+\sqrt2-\sqrt3}{2\sqrt2}$. Multiplying numerator and denominator by $\sqrt2$ gives $\frac{\sqrt2+2-\sqrt6}{4} = \frac{2+\sqrt{2}-\sqrt{6}}{4}$.",
  r"Dropping the factor $2$ in the cross term of $(1+\sqrt2)^2$, or rationalising $2\sqrt2$ inconsistently.",
  "C12B-rationalise-three-term", "Two successive rationalisations with a grouping choice.",
  correct=r"$\frac{2+\sqrt{2}-\sqrt{6}}{4}$",
  distractors=[(r"$\frac{2+\sqrt{2}+\sqrt{6}}{4}$", r"Sign slip on the $\sqrt3 \cdot \sqrt2$ term when multiplying the numerator by $\sqrt2$."),
               (r"$\frac{2+\sqrt{2}-\sqrt{6}}{2}$", r"Expands $(1+\sqrt2)^2$ as $3+\sqrt2$, so the denominator becomes $\sqrt2$ and the result is $\frac{1+\sqrt2-\sqrt3}{\sqrt2}$."),
               (r"$\frac{2+\sqrt{2}-\sqrt{6}}{8}$", r"Multiplies the numerator by $\sqrt2$ but the denominator $2\sqrt2$ by $2\sqrt2$, getting $8$ below.")],
  check=_c004, values=[(2 + s2 - s6) / 4, (2 + s2 + s6) / 4, (2 + s2 - s6) / 2, (2 + s2 - s6) / 8],
  cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    e = 1 / (s2 + s3 + s5) + 1 / (s2 + s3 - s5)
    return simplify(radsimp(together(e)))
q("C12-B-005", T, "Sum of two reciprocals of three-term surds", "Medium",
  "Conceptual/application",
  r"The value of $\frac{1}{\sqrt{2}+\sqrt{3}+\sqrt{5}} + \frac{1}{\sqrt{2}+\sqrt{3}-\sqrt{5}}$ is",
  "MCQ",
  r"Treat $\sqrt2+\sqrt3$ as one block. The common denominator is $(\sqrt2+\sqrt3)^2-5 = 5+2\sqrt6-5 = 2\sqrt6$ and the numerator is $(\sqrt2+\sqrt3-\sqrt5)+(\sqrt2+\sqrt3+\sqrt5) = 2(\sqrt2+\sqrt3)$. So the sum is $\frac{\sqrt2+\sqrt3}{\sqrt6} = \frac{\sqrt{12}+\sqrt{18}}{6} = \frac{3\sqrt{2}+2\sqrt{3}}{6}$.",
  r"Mishandling the block product $(\sqrt2+\sqrt3)^2-5$ or adding fractions by adding numerators and denominators.",
  "C12B-rationalise-three-term", "Needs the block-conjugate idea and then a second rationalisation.",
  correct=r"$\frac{3\sqrt{2}+2\sqrt{3}}{6}$",
  distractors=[(r"$\frac{3\sqrt{2}+2\sqrt{3}}{3}$", r"Expands $(\sqrt2+\sqrt3)^2$ as $5+\sqrt6$, so the denominator is $\sqrt6$ and the sum is $\frac{2(\sqrt2+\sqrt3)}{\sqrt6}$."),
               (r"$\frac{3\sqrt{2}+2\sqrt{3}}{12}$", r"Adds the numerators as $\sqrt2+\sqrt3$ (losing the factor $2$), giving $\frac{\sqrt2+\sqrt3}{2\sqrt6}$."),
               (r"$\sqrt{3}-\sqrt{2}$", r"Adds the fractions by adding numerators and denominators: $\frac{2}{2\sqrt2+2\sqrt3} = \frac{1}{\sqrt2+\sqrt3} = \sqrt3-\sqrt2$.")],
  check=_c005, values=[(3 * s2 + 2 * s3) / 6, (3 * s2 + 2 * s3) / 3, (3 * s2 + 2 * s3) / 12, s3 - s2],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 006
def _c006():
    target_irr = 2 * sqrt(360)
    good = set()
    for k in range(1, 51):
        rhs = k + target_irr
        for m in range(1, k):
            n = k - m
            # (sqrt m + sqrt n)^2 must equal k + 2 sqrt 360 exactly
            if simplify(expand((sqrt(m) + sqrt(n))**2) - rhs) == 0:
                good.add(k)
                break
    return len(good)
q("C12-B-006", T, "Counting parameter values for which a nested radical denests into integer surds", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ with $1 \le k \le 50$ can $\sqrt{k+2\sqrt{360}}$ be written as $\sqrt{m}+\sqrt{n}$ for some positive integers $m$ and $n$?",
  "TITA",
  r"Squaring, $m+n+2\sqrt{mn} = k+2\sqrt{360}$. Since $\sqrt{360} = 6\sqrt{10}$ is irrational, this forces $mn = 360$ and $m+n = k$. The divisor pairs of $360$ with $m \le n$ and $m+n \le 50$ are $(18, 20), (15, 24), (12, 30), (10, 36), (9, 40)$, giving $k = 38, 39, 42, 46, 49$; the next pair $(8, 45)$ already gives $53$. So there are $5$ values of $k$.",
  r"Counting every divisor pair of $360$ without the bound on $k$, or counting ordered pairs $(m, n)$ instead of values of $k$.",
  "C12B-denest-integer-parameter", "Needs the rational-irrational matching argument, a divisor-pair listing and the bound on $k$; three distinct traps.",
  tita_answer=5, check=_c006,
  tita_traps=[(12, r"Counts all $12$ divisor pairs of $360$, ignoring the condition $k \le 50$."),
              (10, r"Counts ordered pairs $(m, n)$, so each valid $k$ is counted twice.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 007
def _c007():
    e = 1 / (s6 + sqrt(14) + sqrt(15) + sqrt(35))
    # factorisation of the denominator into two binomial surds
    assert simplify(expand((s2 + s5) * (s3 + sqrt(7))) - (s6 + sqrt(14) + sqrt(15) + sqrt(35))) == 0
    opts = [(s5 - s2) * (sqrt(7) - s3) / 12, (s5 - s2) * (sqrt(7) - s3) / 7,
            (s5 - s2) * (sqrt(7) - s3) / 70, (s3 - s2) * (sqrt(7) - s5) / 2]
    hit = [o for o in opts if abs(N(o - e, 60)) < Float("1e-45")]
    assert len(hit) == 1
    return hit[0]
q("C12-B-007", T, "Rationalising a four-term surd denominator by factorising it", "Difficult",
  "Conceptual/application",
  r"When the denominator of $\frac{1}{\sqrt{6}+\sqrt{14}+\sqrt{15}+\sqrt{35}}$ is rationalised, the expression equals",
  "MCQ",
  r"The denominator factorises: $\sqrt6+\sqrt{14}+\sqrt{15}+\sqrt{35} = \sqrt2(\sqrt3+\sqrt7)+\sqrt5(\sqrt3+\sqrt7) = (\sqrt2+\sqrt5)(\sqrt3+\sqrt7)$. Rationalise each factor: $\frac{1}{\sqrt5+\sqrt2} = \frac{\sqrt5-\sqrt2}{3}$ and $\frac{1}{\sqrt7+\sqrt3} = \frac{\sqrt7-\sqrt3}{4}$. The product is $\frac{(\sqrt{5}-\sqrt{2})(\sqrt{7}-\sqrt{3})}{12}$.",
  "Pairing the four surds into the wrong product, or combining the two new denominators incorrectly.",
  "C12B-factorise-surd-sum", "The four-term denominator must be recognised as a product of two binomial surds before rationalising; the wrong pairing gives a numerically close option.",
  correct=r"$\frac{(\sqrt{5}-\sqrt{2})(\sqrt{7}-\sqrt{3})}{12}$",
  distractors=[(r"$\frac{(\sqrt{5}-\sqrt{2})(\sqrt{7}-\sqrt{3})}{7}$", r"Factorises and rationalises correctly but adds the two new denominators, $3 + 4 = 7$, instead of multiplying them."),
               (r"$\frac{(\sqrt{5}-\sqrt{2})(\sqrt{7}-\sqrt{3})}{70}$", r"Takes each new denominator as a sum of squares, $(5+2)(7+3) = 70$, instead of $(5-2)(7-3)$."),
               (r"$\frac{(\sqrt{3}-\sqrt{2})(\sqrt{7}-\sqrt{5})}{2}$", r"Pairs the surds as $(\sqrt2+\sqrt3)(\sqrt5+\sqrt7)$ without checking that this product is $\sqrt{10}+\sqrt{14}+\sqrt{15}+\sqrt{21}$, then rationalises with denominators $1$ and $2$.")],
  check=_c007, values=[(s5 - s2) * (sqrt(7) - s3) / 12, (s5 - s2) * (sqrt(7) - s3) / 7,
                       (s5 - s2) * (sqrt(7) - s3) / 70, (s3 - s2) * (sqrt(7) - s5) / 2],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 008
def _c008():
    x = symbols('x')
    xv = s2 + s3
    # build the minimal relation from the givens: x^2 = 5 + 2 sqrt6, (x^2 - 5)^2 = 24
    rel = expand((x**2 - 5)**2 - 24)
    assert simplify(rel.subs(x, xv)) == 0
    P = x**6 - 10 * x**4 + 2 * x**2 + 3
    rem = Poly(P, x).rem(Poly(rel, x)).as_expr()
    val = expand(rem.subs(x, xv))
    assert simplify(expand(P.subs(x, xv)) - val) == 0
    return val
q("C12-B-008", T, "Evaluating a polynomial at a sum of two surds using the quartic it satisfies", "Difficult",
  "Conceptual/application",
  r"If $x = \sqrt{2}+\sqrt{3}$, then $x^6 - 10x^4 + 2x^2 + 3$ equals",
  "MCQ",
  r"Square: $x^2 = 5+2\sqrt6$, so $(x^2-5)^2 = 24$, i.e. $x^4 - 10x^2 + 1 = 0$. Write the expression as $x^2(x^4 - 10x^2 + 1) + x^2 + 3$. The bracket is $0$, so the value is $x^2 + 3 = 5 + 2\sqrt6 + 3 = 8 + 2\sqrt{6}$.",
  r"Building the quartic with a sign error, or squaring $\sqrt2+\sqrt3$ without the factor $2$ in the cross term.",
  "C12B-surd-minimal-polynomial", r"Needs the quartic satisfied by $\sqrt2+\sqrt3$ and a reduction of a sixth-degree expression; direct expansion of $x^6$ is long and error-prone.",
  correct=r"$8+2\sqrt{6}$",
  distractors=[(r"$18+6\sqrt{6}$", r"Writes the relation as $x^4 - 10x^2 - 1 = 0$, so $x^6 = 10x^4 + x^2$ and the expression becomes $3x^2 + 3 = 18 + 6\sqrt6$."),
               (r"$8+\sqrt{6}$", r"Squares $\sqrt2+\sqrt3$ as $5+\sqrt6$, dropping the factor $2$ in the cross term, then evaluates $x^2 + 3$."),
               (r"$8-2\sqrt{6}$", r"Uses $x^2 = 5 - 2\sqrt6$, the square of $\sqrt3-\sqrt2$, another root of the same quartic.")],
  check=_c008, values=[8 + 2 * s6, 18 + 6 * s6, 8 + s6, 8 - 2 * s6],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 009
def _c009():
    x, y = symbols('x y', positive=True)
    # sqrt(19 - 6 sqrt2) = sqrt(x) - sqrt(y), x > y, x + y = 19, xy = 18
    sols = solve([x + y - 19, x * y - 18], [x, y], dict=True)
    sol = [s for s in sols if s[x] > s[y]][0]
    val = sqrt(sol[x]) - sqrt(sol[y])
    assert simplify(val**2 - (19 - 6 * s2)) == 0 and val > 0
    return val
q("C12-B-009", T, "Square root of a binomial surd with a minus sign", "Easy",
  "Single-step computation",
  r"$\sqrt{19-6\sqrt{2}}$ equals",
  "MCQ",
  r"Look for $(\sqrt{x}-\sqrt{y})^2 = x+y-2\sqrt{xy}$ with $x+y = 19$ and $2\sqrt{xy} = 6\sqrt2$, so $xy = 18$. Then $x = 18$, $y = 1$ and $19-6\sqrt2 = (\sqrt{18}-1)^2 = (3\sqrt2-1)^2$. Since $3\sqrt2 > 1$, the positive square root is $3\sqrt{2}-1$.",
  "Picking a factor pair of $18$ without checking that the pair sums to $19$, or losing the minus sign.",
  "C12B-denest-square-root", "One denesting with a sign trap.",
  correct=r"$3\sqrt{2}-1$",
  distractors=[(r"$\sqrt{6}-\sqrt{3}$", r"Uses $xy = 18$ but picks the factor pair $6 \times 3$ without checking the sum: $(\sqrt6-\sqrt3)^2 = 9-6\sqrt2$, not $19-6\sqrt2$."),
               (r"$3\sqrt{2}+1$", r"Loses the minus sign; $(3\sqrt2+1)^2 = 19+6\sqrt2$."),
               (r"$3-\sqrt{2}$", r"Uses $xy = 18$ with the factor pair $9 \times 2$, taking $3-\sqrt2$ without checking that $9+2 = 11$, not $19$.")],
  check=_c009, values=[3 * s2 - 1, s6 - s3, 3 * s2 + 1, 3 - s2],
  cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    S = sqrt(37 + 20 * s3) + sqrt(37 - 20 * s3)
    v = nsimplify(sqrtdenest(S))
    assert abs(float(S) - 10) < 1e-12
    return v
q("C12-B-010", T, "Sum of square roots of conjugate binomial surds", "Medium",
  "Conceptual/application",
  r"What is the value of $\sqrt{37+20\sqrt{3}} + \sqrt{37-20\sqrt{3}}$?",
  "TITA",
  r"Let $S$ be the sum. Then $S^2 = 74 + 2\sqrt{(37+20\sqrt3)(37-20\sqrt3)} = 74 + 2\sqrt{1369-1200} = 74 + 2\sqrt{169} = 100$, so $S = 10$. Equivalently, $37 \pm 20\sqrt3 = (5 \pm 2\sqrt3)^2$, and both $5 \pm 2\sqrt3$ are positive, so $S = (5+2\sqrt3)+(5-2\sqrt3) = 10$.",
  "Reporting $S^2$, or denesting one root and keeping only its rational part.",
  "C12B-denest-square-root", "Squaring the sum (or denesting) turns the conjugate product into a perfect square.",
  tita_answer=10, check=_c010,
  tita_traps=[(100, r"Reports $S^2 = 100$ rather than $S$."),
              (5, r"Denests $\sqrt{37+20\sqrt3} = 5+2\sqrt3$ and reports its rational part $5$.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 011
def _c011():
    a, b = symbols('a b', positive=True)
    # inner: 28 - 10 sqrt3 = (sqrt a - sqrt b)^2 with a + b = 28, ab = 75, a > b
    si = [s for s in solve([a + b - 28, a * b - 75], [a, b], dict=True) if s[a] > s[b]][0]
    inner = sqrt(si[a]) - sqrt(si[b])
    assert simplify(expand(inner**2) - (28 - 10 * s3)) == 0 and inner > 0
    rad = expand(14 + 22 * inner)                 # 124 - 22 sqrt3
    # outer: (p - q sqrt3)^2 = p^2 + 3q^2 - 2pq sqrt3, with p q = 11
    hits = []
    for p in range(1, 125):
        for qv in range(1, 125):
            if p * qv == 11 and p * p + 3 * qv * qv == rad.subs(s3, 0) and p > qv * s3:
                hits.append(p - qv * s3)
    assert len(hits) == 1
    outer = hits[0]
    assert abs(N(outer - sqrt(14 + 22 * sqrt(28 - 10 * s3)), 60)) < Float("1e-45")
    return outer
q("C12-B-011", T, "Doubly nested radical whose inner denesting introduces a minus sign", "Difficult",
  "Conceptual/application",
  r"$\sqrt{14+22\sqrt{28-10\sqrt{3}}}$ equals",
  "MCQ",
  r"Work from the inside. $28-10\sqrt3 = x+y-2\sqrt{xy}$ with $x+y = 28$ and $xy = 75$, so $x = 25$, $y = 3$ and $\sqrt{28-10\sqrt3} = 5-\sqrt3$ (positive). The outer radicand becomes $14+22(5-\sqrt3) = 124-22\sqrt3$. Now $124-22\sqrt3 = (p-q\sqrt3)^2 = p^2+3q^2-2pq\sqrt3$ needs $pq = 11$ and $p^2+3q^2 = 124$, so $p = 11$, $q = 1$. Since $11 > \sqrt3$, the expression equals $11-\sqrt{3}$.",
  "Losing the minus sign that the inner denesting creates, or matching only the surd term at the outer stage.",
  "C12B-denest-square-root", "Two denestings in sequence; the plus signs in the stem hide a minus sign that appears only after the inner stage, and the outer radicand has large parts to match.",
  correct=r"$11-\sqrt{3}$",
  distractors=[(r"$11+\sqrt{3}$", r"Denests the inner root as $5+\sqrt3$, so the outer radicand is $124+22\sqrt3 = (11+\sqrt3)^2$."),
               (r"$5-\sqrt{3}$", r"Denests only the inner root $\sqrt{28-10\sqrt3}$ and reports it."),
               (r"$11\sqrt{3}-1$", r"Matches $22\sqrt3 = 2 \cdot 1 \cdot 11\sqrt3$ and takes $11\sqrt3-1$ without checking that $363+1 = 364$, not $124$.")],
  check=_c011, values=[11 - s3, 11 + s3, 5 - s3, 11 * s3 - 1],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 012
def _c012():
    opts = [root(6, 4), root(4, 3), s3, root(15, 6)]
    twelfth = [nsimplify(o**12) for o in opts]   # 216, 256, 729, 225
    i = twelfth.index(min(twelfth))
    assert twelfth.count(min(twelfth)) == 1
    return opts[i]
q("C12-B-012", T, "Comparing surds of different orders", "Medium",
  "Conceptual/application",
  r"Which of the following is the smallest?",
  "MCQ",
  r"Raise each number to the power $12$, the LCM of the indices $2, 3, 4, 6$. This gives $(\sqrt3)^{12} = 3^6 = 729$, $(\sqrt[3]{4})^{12} = 4^4 = 256$, $(\sqrt[4]{6})^{12} = 6^3 = 216$ and $(\sqrt[6]{15})^{12} = 15^2 = 225$. The smallest twelfth power is $216$, so $\sqrt[4]{6}$ is the smallest.",
  "Judging size by the radicand or by the index alone.",
  "C12B-compare-surd-order", "Needs the LCM of four indices, and $216$ versus $225$ is close.",
  correct=r"$\sqrt[4]{6}$",
  distractors=[(r"$\sqrt{3}$", r"Picks the smallest radicand."),
               (r"$\sqrt[6]{15}$", r"Assumes the root with the highest index must be the smallest; $15^2 = 225 > 216$."),
               (r"$\sqrt[3]{4}$", r"Ranks by radicand divided by index ($\frac32, \frac43, \frac64, \frac{15}{6}$), where $\frac43$ is least.")],
  check=_c012, values=[root(6, 4), s3, root(15, 6), root(4, 3)],
  cognitive="Analysis")

# ---------------------------------------------------------------- 013
def _c013():
    pairs = [(11, 5), (3, 2), (30, 21), (50, 47)]
    vals = [sqrt(a) - sqrt(b) for a, b in pairs]
    best = max(vals, key=lambda v: N(v, 50))
    return best
q("C12-B-013", T, "Comparing differences of square roots", "Medium",
  "Conceptual/application",
  r"Which of the following has the greatest value?",
  "MCQ",
  r"Write $\sqrt a - \sqrt b = \frac{a-b}{\sqrt a + \sqrt b}$. The four values are $\frac{6}{\sqrt{11}+\sqrt5} \approx \frac{6}{5.55} \approx 1.08$, $\frac{1}{\sqrt3+\sqrt2} \approx 0.32$, $\frac{9}{\sqrt{30}+\sqrt{21}} \approx \frac{9}{10.06} \approx 0.89$ and $\frac{3}{\sqrt{50}+\sqrt{47}} \approx 0.22$. The greatest is $\sqrt{11}-\sqrt{5}$.",
  "Comparing by the gap between radicands alone, or by the size of the radicands alone.",
  "C12B-compare-surd-order", "Needs the conjugate form and a judgement of gap against size of the radicands.",
  correct=r"$\sqrt{11}-\sqrt{5}$",
  distractors=[(r"$\sqrt{30}-\sqrt{21}$", r"Picks the largest gap between radicands ($9$), ignoring that larger roots compress differences."),
               (r"$\sqrt{3}-\sqrt{2}$", r"Picks the smallest radicands, assuming small roots are spread furthest apart."),
               (r"$\sqrt{50}-\sqrt{47}$", r"Picks the largest radicands, as if larger numbers gave larger differences of roots.")],
  check=_c013, values=[sqrt(11) - s5, sqrt(30) - sqrt(21), s3 - s2, sqrt(50) - sqrt(47)],
  cognitive="Analysis")

# ---------------------------------------------------------------- 014
def _c014():
    lo, hi = 3 * s2, 2 * sqrt(7)
    return sum(1 for n in range(1, 200) if N(lo, 40) < N(sqrt(n), 40) < N(hi, 40))
q("C12-B-014", T, "Counting integers whose square roots lie between two mixed surds", "Easy",
  "Casework/optimisation",
  r"How many positive integers $n$ satisfy $3\sqrt{2} < \sqrt{n} < 2\sqrt{7}$?",
  "TITA",
  r"Move each coefficient inside the root: $3\sqrt2 = \sqrt{9 \times 2} = \sqrt{18}$ and $2\sqrt7 = \sqrt{4 \times 7} = \sqrt{28}$. So the condition is $18 < n < 28$, which gives $n = 19, 20, \ldots, 27$, that is $9$ integers.",
  r"Moving a coefficient inside the root without squaring it, or including the end points.",
  "C12B-compare-surd-order", "One idea: write each mixed surd as a pure surd, then count.",
  tita_answer=9, check=_c014,
  tita_traps=[(7, r"Moves the coefficients inside without squaring them: $\sqrt6 < \sqrt n < \sqrt{14}$, giving $n = 7, \ldots, 13$."),
              (11, r"Includes the end points $n = 18$ and $n = 28$, although the inequalities are strict.")],
  cognitive="Application")

# ---------------------------------------------------------------- 015
def _c015():
    return expand((s3 + s2)**4 + (s3 - s2)**4)
q("C12-B-015", T, "Sum of even powers of conjugate surds", "Medium",
  "Conceptual/application",
  r"What is the value of $(\sqrt{3}+\sqrt{2})^4 + (\sqrt{3}-\sqrt{2})^4$?",
  "TITA",
  r"First square: $(\sqrt3 \pm \sqrt2)^2 = 5 \pm 2\sqrt6$. Then $(5+2\sqrt6)^2 + (5-2\sqrt6)^2 = 2(25 + 24) = 98$, because the cross terms $\pm 20\sqrt6$ cancel.",
  r"Halving the symmetric sum, or squaring $2\sqrt6$ as $12$.",
  "C12B-conjugate-power-sum", "Two squaring steps in which the irrational parts cancel.",
  tita_answer=98, check=_c015,
  tita_traps=[(49, r"Computes only $25+24$ and forgets that both conjugates contribute it."),
              (74, r"Squares $2\sqrt6$ as $12$, getting $2(25+12)$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    return int(floor((2 + s3)**5))
q("C12-B-016", T, "Integer part of a power of a surd using its conjugate", "Difficult",
  "Conceptual/application",
  r"What is the greatest integer less than or equal to $(2+\sqrt{3})^5$?",
  "TITA",
  r"Let $S_n = (2+\sqrt3)^n + (2-\sqrt3)^n$. These are integers with $S_0 = 2$, $S_1 = 4$ and $S_n = 4S_{n-1} - S_{n-2}$ (since $2 \pm \sqrt3$ are roots of $t^2 - 4t + 1 = 0$). So $S_2 = 14$, $S_3 = 52$, $S_4 = 194$, $S_5 = 724$. As $0 < (2-\sqrt3)^5 < 1$, $(2+\sqrt3)^5 = 724 - (2-\sqrt3)^5$ lies strictly between $723$ and $724$, so the answer is $723$.",
  "Reporting the conjugate sum itself without removing the small conjugate power.",
  "C12B-conjugate-power-sum", "Needs the conjugate-sum integer idea, a recurrence and a careful floor.",
  tita_answer=723, check=_c016,
  tita_traps=[(724, r"Reports $S_5 = 724$, forgetting that the small positive conjugate power must be subtracted."),
              (193, r"Stops the recurrence one step early and floors the fourth power: $194 - (2-\sqrt3)^4$ lies between $193$ and $194$.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 017
def _c017():
    return int(floor((s5 + 2)**3))
q("C12-B-017", T, "Integer part of an odd power using the difference with the conjugate", "Medium",
  "Conceptual/application",
  r"The greatest integer less than or equal to $(\sqrt{5}+2)^3$ is",
  "MCQ",
  r"Since $(\sqrt5+2)(\sqrt5-2) = 1$, the conjugate $\sqrt5-2$ lies between $0$ and $1$. For an odd power, $(\sqrt5+2)^3 - (\sqrt5-2)^3 = 2(3 \cdot 5 \cdot 2 + 2^3) = 76$ is an integer. Hence $(\sqrt5+2)^3 = 76 + (\sqrt5-2)^3$, which is just above $76$, so the answer is $76$. (Directly: $(\sqrt5+2)^3 = 38+17\sqrt5 \approx 76.01$.)",
  "Applying the 'subtract one' rule meant for conjugate sums, or expanding the difference of the cubes incompletely.",
  "C12B-conjugate-power-sum", "Requires noticing that for odd powers the difference, not the sum, is the integer.",
  correct=r"$76$",
  distractors=[(r"$75$", r"Applies the rule for conjugate sums (integer minus a small part) to this case, subtracting $1$ from $76$."),
               (r"$68$", r"Expands the difference as $2(3a^2b) + b^3$ with $a = \sqrt5$, $b = 2$, doubling only the first term: $60 + 8 = 68$."),
               (r"$77$", r"Rounds $38 + 17\sqrt5$ up to the next integer.")],
  check=_c017, values=[76, 75, 68, 77],
  cognitive="Analysis")

# ---------------------------------------------------------------- 018
def _c018():
    x = 3 + 2 * s2
    return simplify(radsimp(x**2 + 1 / x**2))
q("C12-B-018", T, "Value of x squared plus its reciprocal squared for a surd x", "Easy",
  "Single-step computation",
  r"If $x = 3+2\sqrt{2}$, what is the value of $x^2 + \frac{1}{x^2}$?",
  "TITA",
  r"Rationalising, $\frac1x = \frac{1}{3+2\sqrt2} = \frac{3-2\sqrt2}{9-8} = 3-2\sqrt2$. So $x + \frac1x = 6$ and $x^2 + \frac{1}{x^2} = \left(x+\frac1x\right)^2 - 2 = 36 - 2 = 34$.",
  r"Squaring $x + \frac1x$ and not subtracting $2$.",
  "C12B-reciprocal-conjugate-powers", "One reciprocal and one standard identity.",
  tita_answer=34, check=_c018,
  tita_traps=[(36, r"Reports $\left(x+\frac1x\right)^2$ without subtracting $2$."),
              (38, r"Adds $2$ instead: uses $\left(x+\frac1x\right)^2 + 2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    x = radsimp((s5 + s3) / (s5 - s3))
    y = radsimp((s5 - s3) / (s5 + s3))
    return simplify(expand(x**2 + x * y + y**2))
q("C12-B-019", T, "Symmetric expression in two reciprocal surds", "Medium",
  "Conceptual/application",
  r"If $x = \frac{\sqrt{5}+\sqrt{3}}{\sqrt{5}-\sqrt{3}}$ and $y = \frac{\sqrt{5}-\sqrt{3}}{\sqrt{5}+\sqrt{3}}$, then $x^2 + xy + y^2$ equals",
  "MCQ",
  r"Rationalising, $x = \frac{(\sqrt5+\sqrt3)^2}{2} = \frac{8+2\sqrt{15}}{2} = 4+\sqrt{15}$ and similarly $y = 4-\sqrt{15}$. So $x+y = 8$ and $xy = 1$. Then $x^2+xy+y^2 = (x+y)^2 - xy = 64 - 1 = 63$.",
  "Mixing up $x^2+y^2$, $(x+y)^2$ and $x^2+xy+y^2$.",
  "C12B-reciprocal-conjugate-powers", "Rationalise, spot $xy = 1$, then a symmetric-function identity.",
  correct=r"$63$",
  distractors=[(r"$62$", r"Computes $x^2+y^2 = 64 - 2 = 62$ and omits the $xy$ term."),
               (r"$64$", r"Uses $(x+y)^2 = 64$ as if it equalled $x^2+xy+y^2$."),
               (r"$65$", r"Writes $x^2+xy+y^2 = (x+y)^2 + xy$.")],
  check=_c019, values=[63, 62, 64, 65],
  cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    a = radsimp(1 / (5 - 2 * s6))
    b = radsimp(1 / (5 + 2 * s6))
    return simplify(expand(a**3 + b**3))
q("C12-B-020", T, "Sum of cubes of two reciprocal surds", "Medium",
  "Conceptual/application",
  r"If $a = \frac{1}{5-2\sqrt{6}}$ and $b = \frac{1}{5+2\sqrt{6}}$, then $a^3 + b^3$ equals",
  "MCQ",
  r"Since $(5-2\sqrt6)(5+2\sqrt6) = 25-24 = 1$, $a = 5+2\sqrt6$ and $b = 5-2\sqrt6$. So $a+b = 10$ and $ab = 1$. Then $a^3+b^3 = (a+b)^3 - 3ab(a+b) = 1000 - 30 = 970$.",
  "Misapplying the identity for $a^3+b^3$.",
  "C12B-reciprocal-conjugate-powers", "Rationalise to find $ab = 1$, then the cube identity.",
  correct=r"$970$",
  distractors=[(r"$1000$", r"Uses $a^3+b^3 = (a+b)^3$, dropping the $3ab(a+b)$ term."),
               (r"$1030$", r"Adds $3ab(a+b)$ rather than subtracting it."),
               (r"$990$", r"Writes the correction term as $ab(a+b) = 10$, losing the factor $3$.")],
  check=_c020, values=[970, 1000, 1030, 990],
  cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    p, qq = symbols('p q', rational=True)
    e = expand(p * (2 + s3) + qq * (2 - s3) - (16 + 2 * s3))
    sol = solve([e.coeff(s3), e.subs(s3, 0)], [p, qq], dict=True)[0]
    return sol[p]
q("C12-B-021", T, "Equating rational and irrational parts to find unknown rationals", "Easy",
  "Inverse/parameter",
  r"Rational numbers $p$ and $q$ satisfy $p(2+\sqrt{3}) + q(2-\sqrt{3}) = 16 + 2\sqrt{3}$. The value of $p$ is",
  "MCQ",
  r"Expanding, $(2p+2q) + (p-q)\sqrt3 = 16 + 2\sqrt3$. Since $p, q$ are rational and $\sqrt3$ is irrational, $2p+2q = 16$ and $p-q = 2$. So $p+q = 8$, $p-q = 2$, giving $p = 5$ (and $q = 3$).",
  "Equating parts carelessly, for example $p+q = 16$, or reporting $q$.",
  "C12B-rational-irrational-parts", "Single idea: compare rational and irrational parts, then a 2 by 2 system.",
  correct=r"$5$",
  distractors=[(r"$3$", r"Solves correctly but reports $q$."),
               (r"$9$", r"Equates $p+q$ (not $2p+2q$) to $16$, then $p-q = 2$ gives $p = 9$."),
               (r"$8$", r"Sets $2p = 16$, ignoring the $q$ term in the rational part.")],
  check=_c021, values=[5, 3, 9, 8],
  cognitive="Application")

# ---------------------------------------------------------------- 022
def _c022():
    k = symbols('k', rational=True)
    e = expand(radsimp(1 / (2 + s3)) + k * radsimp(1 / (s3 - 1)))
    sol = solve(e.coeff(s3), k)
    assert len(sol) == 1
    kv = sol[0]
    val = simplify(radsimp(1 / (2 + s3) + kv / (s3 - 1)))
    assert val.is_rational
    return kv
q("C12-B-022", T, "Choosing a rational multiplier that makes a surd sum rational", "Medium",
  "Inverse/parameter",
  r"For a rational number $k$, the number $\frac{1}{2+\sqrt{3}} + \frac{k}{\sqrt{3}-1}$ is rational. The value of $k$ is",
  "MCQ",
  r"Rationalise both terms: $\frac{1}{2+\sqrt3} = 2-\sqrt3$ and $\frac{k}{\sqrt3-1} = \frac{k(\sqrt3+1)}{2}$. The sum is $\left(2+\frac k2\right) + \left(\frac k2 - 1\right)\sqrt3$. It is rational only if $\frac k2 - 1 = 0$, so $k = 2$ (and the sum is then $3$).",
  "Using the wrong denominator or the wrong conjugate while rationalising.",
  "C12B-rational-irrational-parts", "Two rationalisations and then setting the irrational coefficient to zero.",
  correct=r"$2$",
  distractors=[(r"$4$", r"Takes the denominator of $\frac{k}{\sqrt3-1}$ as $3+1 = 4$, so $\frac k4 = 1$."),
               (r"$1$", r"Does not divide by $(\sqrt3)^2 - 1 = 2$, writing $k(\sqrt3+1)$, so $k = 1$."),
               (r"$-2$", r"Writes $\frac{1}{2+\sqrt3}$ as $\sqrt3-2$, so the irrational coefficient is $1+\frac k2$.")],
  check=_c022, values=[2, 4, 1, -2],
  cognitive="Application")

# ---------------------------------------------------------------- 023
def _c023():
    cnt = 0
    for a in range(1, 469):
        # b = (sqrt468 - sqrt a)^2 = 468 + a - 2 sqrt(468 a); need integer b >= a
        r = 468 * a
        s = math.isqrt(r)
        if s * s != r:
            continue
        b = 468 + a - 2 * s
        if b >= a and b >= 1:
            assert simplify(sqrt(a) + sqrt(b) - sqrt(468)) == 0
            cnt += 1
    return cnt
q("C12-B-023", T, "Counting integer pairs whose square roots add to a given surd", "Medium",
  "Casework/optimisation",
  r"How many pairs of positive integers $(a, b)$ with $a \le b$ satisfy $\sqrt{a} + \sqrt{b} = \sqrt{468}$?",
  "TITA",
  r"Here $\sqrt{468} = 6\sqrt{13}$. Squaring $\sqrt b = 6\sqrt{13} - \sqrt a$ gives $b = 468 + a - 12\sqrt{13a}$, so $13a$ must be a perfect square, i.e. $a = 13m^2$ and similarly $b = 13n^2$, with $m + n = 6$. With $1 \le m \le n$ the possibilities are $(m, n) = (1, 5), (2, 4), (3, 3)$, so there are $3$ pairs.",
  "Counting ordered pairs, or excluding the case $a = b$.",
  r"C12B-sum-of-surds-integer-pairs", r"Needs the like-surd argument and careful casework on the condition $a \le b$.",
  tita_answer=3, check=_c023,
  tita_traps=[(5, r"Counts ordered pairs $(m, n)$ with $m + n = 6$, ignoring $a \le b$."),
              (2, r"Excludes the case $a = b = 117$.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 024
def _c024():
    x, y = symbols('x y', positive=True)
    xv = [s for s in solve(x**2 - 56 - x, x) if s > 0][0]
    yv = [s for s in solve(y**2 - 56 + y, y) if s > 0][0]
    # confirm by iterating the finite truncations
    a = b = 0.0
    for _ in range(60):
        a = math.sqrt(56 + a)
        b = math.sqrt(56 - b)
    assert abs(a - float(xv)) < 1e-9 and abs(b - float(yv)) < 1e-9
    return xv + yv
q("C12-B-024", T, "Sum of two infinite nested radicals with opposite signs", "Easy",
  "Conceptual/application",
  r"Each of the infinite expressions $\sqrt{56+\sqrt{56+\sqrt{56+\cdots}}}$ and $\sqrt{56-\sqrt{56-\sqrt{56-\cdots}}}$ represents a positive real number. Their sum is",
  "MCQ",
  r"Let $x = \sqrt{56+\sqrt{56+\cdots}}$. Then $x = \sqrt{56+x}$, so $x^2 - x - 56 = 0 = (x-8)(x+7)$ and $x = 8$. Let $y = \sqrt{56-\sqrt{56-\cdots}}$. Then $y^2 = 56 - y$, so $y^2 + y - 56 = 0 = (y+8)(y-7)$ and $y = 7$. The sum is $8 + 7 = 15$.",
  "Treating both expressions as having the same value.",
  "C12B-infinite-nested-radical", "One self-similar substitution for each expression; the trap is the sign.",
  correct=r"$15$",
  distractors=[(r"$16$", r"Solves $x^2 = 56 + x$ for both expressions, ignoring the minus signs in the second."),
               (r"$14$", r"Solves $y^2 = 56 - y$ for both expressions."),
               (r"$1$", r"Finds $8$ and $7$ correctly but subtracts them.")],
  check=_c024, values=[15, 16, 14, 1],
  cognitive="Application")

# ---------------------------------------------------------------- 025
def _c025():
    # build the alternating nest from the inside out; outermost sign is +
    val = 0.0
    for i in range(400, 0, -1):
        val = math.sqrt(6 + val) if i % 2 == 1 else math.sqrt(6 - val)
    x = symbols('x', positive=True)
    exact = [s for s in solve(x**2 - x - 5, x) if s > 0][0]
    assert abs(float(exact) - val) < 1e-12
    return exact
q("C12-B-025", T, "Infinite nested radical with alternating signs", "Difficult",
  "Conceptual/application",
  r"The infinite expression $\sqrt{6+\sqrt{6-\sqrt{6+\sqrt{6-\cdots}}}}$, in which the signs alternate $+, -, +, -, \ldots$, represents a positive real number. That number is",
  "MCQ",
  r"Let $x$ be the value and $y = \sqrt{6-\sqrt{6+\cdots}}$, so $x = \sqrt{6+y}$ and $y = \sqrt{6-x}$. Then $x^2 = 6+y$ and $y^2 = 6-x$; subtracting, $x^2 - y^2 = x + y$, so $x - y = 1$ as $x + y > 0$. Substituting $y = x - 1$ into $x^2 = 6 + y$ gives $x^2 - x - 5 = 0$, so $x = \frac{1+\sqrt{21}}{2}$ (the positive root).",
  "Reporting the inner value $y$, or slipping a sign when relating $x$ and $y$.",
  "C12B-infinite-nested-radical", "Period-two nesting needs two variables and the subtraction trick; several traps.",
  correct=r"$\frac{1+\sqrt{21}}{2}$",
  distractors=[(r"$\frac{\sqrt{21}-1}{2}$", r"Solves correctly but reports $y = x - 1$, the value of the inner expression starting with a minus sign."),
               (r"$\frac{1+\sqrt{29}}{2}$", r"Gets $x - y = -1$ from the subtraction, then $x^2 = 6 + x + 1$, i.e. $x^2 - x - 7 = 0$."),
               (r"$\frac{1+\sqrt{6}}{2}$", r"Solves $x^2 - x - 5 = 0$ with discriminant $1 + 5$, dropping the factor $4$ in $b^2 - 4ac$.")],
  check=_c025, values=[(1 + sqrt(21)) / 2, (sqrt(21) - 1) / 2, (1 + sqrt(29)) / 2, (1 + s6) / 2],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 026
def _c026():
    x = symbols('x', real=True)
    v = cbrt(9 + 4 * s5) + real_root(9 - 4 * s5, 3)
    # 9 - 4 sqrt5 > 0, so both cube roots are real and positive
    assert 9 - 4 * s5 > 0
    roots = [r for r in solve(x**3 - 3 * x - 18, x) if r.is_real]
    assert len(roots) == 1 and abs(float(v) - float(roots[0])) < 1e-12
    return roots[0]
q("C12-B-026", T, "Sum of conjugate cube roots via a cubic", "Difficult",
  "Conceptual/application",
  r"What is the value of $\sqrt[3]{9+4\sqrt{5}} + \sqrt[3]{9-4\sqrt{5}}$?",
  "TITA",
  r"Let $x$ be the sum, with $u = \sqrt[3]{9+4\sqrt5}$, $v = \sqrt[3]{9-4\sqrt5}$. Then $uv = \sqrt[3]{81-80} = 1$ and $x^3 = u^3 + v^3 + 3uv(u+v) = 18 + 3x$. So $x^3 - 3x - 18 = 0 = (x-3)(x^2+3x+6)$; the quadratic factor has no real root, so $x = 3$. (Indeed $\sqrt[3]{9 \pm 4\sqrt5} = \frac{3 \pm \sqrt5}{2}$.)",
  r"Missing the $3uv(u+v)$ term, or taking the cube roots as $3 \pm \sqrt5$.",
  "C12B-cube-root-conjugate-sum", "Requires cubing the unknown sum and solving a cubic; the cube roots are not obvious.",
  tita_answer=3, check=_c026,
  tita_traps=[(6, r"Guesses $\sqrt[3]{9 \pm 4\sqrt5} = 3 \pm \sqrt5$, missing the factor $\frac12$ (in fact $(3+\sqrt5)^3 = 8(9+4\sqrt5)$).")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 027
def _c027():
    x = symbols('x', real=True)
    sols = solve(Eq(sqrt(x + 20) - sqrt(x - 4), 2), x)
    good = [s for s in sols if simplify(sqrt(s + 20) - sqrt(s - 4) - 2) == 0]
    assert len(good) == 1
    return good[0]
q("C12-B-027", T, "Solving a difference of square roots equation by the conjugate", "Medium",
  "Inverse/parameter",
  r"The real number $x$ satisfies $\sqrt{x+20} - \sqrt{x-4} = 2$. What is the value of $x$?",
  "TITA",
  r"Let $u = \sqrt{x+20}$ and $v = \sqrt{x-4}$. Then $u^2 - v^2 = 24$ and $u - v = 2$, so $u + v = 12$. Hence $u = 7$, $v = 5$ and $x = 49 - 20 = 29$. Check: $\sqrt{49} - \sqrt{25} = 2$.",
  "Reporting $u$ or $u^2$ rather than $x$.",
  "C12B-surd-equation-squaring", "Conjugate trick turns the equation into a linear system.",
  tita_answer=29, check=_c027,
  tita_traps=[(7, r"Reports $u = \sqrt{x+20} = 7$."),
              (49, r"Reports $u^2 = x + 20 = 49$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 028
def _c028():
    cnt = 0
    for x in range(3, 2000):
        t = sqrt(x - 3)
        lhs = sqrt(x - 2 - 2 * t) + sqrt(x + 6 - 6 * t)
        if abs(N(lhs - 2, 60)) < Float("1e-40"):
            cnt += 1
    return cnt
q("C12-B-028", T, "Nested radical equation that reduces to absolute values", "Difficult",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $\sqrt{x-2-2\sqrt{x-3}} + \sqrt{x+6-6\sqrt{x-3}} = 2$?",
  "TITA",
  r"Put $t = \sqrt{x-3} \ge 0$, so $x = t^2 + 3$. Then $x - 2 - 2t = (t-1)^2$ and $x + 6 - 6t = (t-3)^2$, so the equation is $|t-1| + |t-3| = 2$. The sum of distances from $t$ to $1$ and $3$ equals $2$ exactly when $1 \le t \le 3$, i.e. $1 \le x - 3 \le 9$, so $4 \le x \le 12$. That gives $9$ integers.",
  r"Taking $\sqrt{(t-1)^2} = t-1$ without absolute values, which yields only isolated solutions.",
  "C12B-nested-radical-abs-casework", "Hidden perfect squares inside the radicals and an absolute value casework giving an interval.",
  tita_answer=9, check=_c028,
  tita_traps=[(3, r"Counts only the integer values $t = 1, 2, 3$, i.e. $x = 4, 7, 12$."),
              (7, r"Uses strict inequalities $1 < t < 3$ and drops the end points $x = 4$ and $x = 12$.")],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 029
def _c029():
    return sqrt(75) + sqrt(48) - sqrt(27)
q("C12-B-029", T, "Combining like surds after simplifying", "Easy",
  "Single-step computation",
  r"$\sqrt{75} + \sqrt{48} - \sqrt{27}$ equals",
  "MCQ",
  r"Take out the square factors: $\sqrt{75} = 5\sqrt3$, $\sqrt{48} = 4\sqrt3$, $\sqrt{27} = 3\sqrt3$. These are like surds, so the expression is $(5 + 4 - 3)\sqrt3 = 6\sqrt{3}$.",
  "Combining radicands under a single root, or not taking the square root of the square factor.",
  "C12B-like-surds-simplification", "Single idea: reduce each surd and combine like terms.",
  correct=r"$6\sqrt{3}$",
  distractors=[(r"$4\sqrt{6}$", r"Combines the radicands: $\sqrt{75+48-27} = \sqrt{96} = 4\sqrt6$."),
               (r"$12\sqrt{3}$", r"Adds all three surds, ignoring the minus sign: $5+4+3 = 12$."),
               (r"$32\sqrt{3}$", r"Takes the square factor out without its square root: $25\sqrt3 + 16\sqrt3 - 9\sqrt3$.")],
  check=_c029, values=[6 * s3, 4 * s6, 12 * s3, 32 * s3],
  cognitive="Recall")

# ---------------------------------------------------------------- 030
def _c030():
    for k in range(1, 10000):
        r = 7350 * k
        if math.isqrt(r) ** 2 == r:
            return k
q("C12-B-030", T, "Smallest multiplier that makes a surd an integer", "Easy",
  "Inverse/parameter",
  r"Priya wants a square plot whose area is $7350k$ m$^2$, where $k$ is a positive integer, and whose side is a whole number of metres. The smallest possible value of $k$ is",
  "MCQ",
  r"The side is $\sqrt{7350k}$, which must be an integer. Factorise: $7350 = 2 \times 3 \times 5^2 \times 7^2$. The factors $5^2$ and $7^2$ are already squares, so $k$ must supply one more $2$ and one more $3$: $k = 6$, giving side $\sqrt{44100} = 210$ m.",
  "Missing one of the square factors, or multiplying by every prime.",
  "C12B-surd-simplest-form", "One prime factorisation and pairing the unpaired primes.",
  correct=r"$6$",
  distractors=[(r"$294$", r"Removes the square $25$ but misses $49$, then treats $294 = 2 \times 3 \times 49$ as entirely unpaired."),
               (r"$150$", r"Removes the square $49$ but misses $25$, treating $150 = 2 \times 3 \times 25$ as entirely unpaired."),
               (r"$210$", r"Multiplies by every distinct prime factor: $2 \times 3 \times 5 \times 7$.")],
  check=_c030, values=[6, 294, 150, 210],
  cognitive="Application")

# ---------------------------------------------------------------- 031
def _c031():
    return expand((1 + s2 + s3) * (1 + s2 - s3) * (1 - s2 + s3) * (-1 + s2 + s3))
q("C12-B-031", T, "Product of four surd factors by pairing conjugates", "Medium",
  "Conceptual/application",
  r"What is the value of $(1+\sqrt{2}+\sqrt{3})(1+\sqrt{2}-\sqrt{3})(1-\sqrt{2}+\sqrt{3})(-1+\sqrt{2}+\sqrt{3})$?",
  "TITA",
  r"Pair the factors. $(1+\sqrt2+\sqrt3)(1+\sqrt2-\sqrt3) = (1+\sqrt2)^2 - 3 = 2\sqrt2$. Also $(\sqrt3 + (1-\sqrt2))(\sqrt3 - (1-\sqrt2)) = 3 - (1-\sqrt2)^2 = 3 - (3 - 2\sqrt2) = 2\sqrt2$. The product is $2\sqrt2 \times 2\sqrt2 = 8$.",
  r"Pairing the factors so that no difference of squares appears, or arithmetic slips with $2\sqrt2 \times 2\sqrt2$.",
  "C12B-rationalise-three-term", "Needs a smart pairing so each pair is a difference of squares.",
  tita_answer=8, check=_c031,
  tita_traps=[(16, r"Evaluates $2\sqrt2 \times 2\sqrt2$ as $4 \times 4$ rather than $4 \times 2$."),
              (4, r"Drops the $\sqrt2$ in each pair product, using $2 \times 2$.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 032
def _c032():
    opts = [(sqrt(50) + sqrt(18)) / sqrt(8),
            (s5 + s3)**2 - (s5 - s3)**2,
            sqrt(12) + sqrt(27) - s3,
            (2 + s3)**2]
    vals = [simplify(expand(o)) for o in opts]
    rat = [v for v in vals if v.is_rational]
    assert len(rat) == 1
    return rat[0]
q("C12-B-032", T, "Identifying which surd expression is rational", "Easy",
  "Conceptual/application",
  r"Which of the following numbers is rational?",
  "MCQ",
  r"$\frac{\sqrt{50}+\sqrt{18}}{\sqrt8} = \frac{5\sqrt2 + 3\sqrt2}{2\sqrt2} = \frac{8\sqrt2}{2\sqrt2} = 4$, which is rational. The others are $(\sqrt5+\sqrt3)^2 - (\sqrt5-\sqrt3)^2 = 4\sqrt{15}$, $\sqrt{12}+\sqrt{27}-\sqrt3 = 4\sqrt3$ and $(2+\sqrt3)^2 = 7+4\sqrt3$, all irrational.",
  "Believing cross terms cancel in a difference of squares, or that radicands can be combined.",
  "C12B-rationality-test", "Each option needs one simplification; traps rely on familiar slips.",
  correct=r"$\frac{\sqrt{50}+\sqrt{18}}{\sqrt{8}}$",
  distractors=[(r"$(\sqrt{5}+\sqrt{3})^2 - (\sqrt{5}-\sqrt{3})^2$", r"Thinks the cross terms cancel, giving $0$; in fact they add to $4\sqrt{15}$."),
               (r"$\sqrt{12}+\sqrt{27}-\sqrt{3}$", r"Combines radicands as $\sqrt{12+27-3} = \sqrt{36} = 6$; the true value is $4\sqrt3$."),
               (r"$(2+\sqrt{3})^2$", r"Squares term by term as $4 + 3 = 7$, missing the $4\sqrt3$ cross term.")],
  check=_c032, values=[4, 4 * sqrt(15), 4 * s3, 7 + 4 * s3],
  cognitive="Understanding")

# ---------------------------------------------------------------- 033
def _c033():
    k, a = symbols('k a', rational=True)
    e = expand(radsimp((k + 3 * s5) / (3 - s5)) - (a + 4 * s5))
    sol = solve([e.coeff(s5), e.subs(s5, 0)], [k, a], dict=True)
    assert len(sol) == 1
    kv, av = sol[0][k], sol[0][a]
    assert simplify((kv + 3 * s5) / (3 - s5) - (av + 4 * s5)) == 0
    return av
q("C12-B-033", T, "Finding an unknown numerator so that a rationalised surd has a given irrational part", "Medium",
  "Inverse/parameter",
  r"For rational numbers $k$ and $a$, $\frac{k+3\sqrt{5}}{3-\sqrt{5}} = a + 4\sqrt{5}$. The value of $a$ is",
  "MCQ",
  r"Multiply by the conjugate $3+\sqrt5$; the denominator becomes $9-5 = 4$ and the numerator $(k+3\sqrt5)(3+\sqrt5) = (3k+15) + (k+9)\sqrt5$. So the expression is $\frac{3k+15}{4} + \frac{k+9}{4}\sqrt5$. Matching the irrational part, $\frac{k+9}{4} = 4$, so $k = 7$, and then $a = \frac{21+15}{4} = 9$.",
  "Dividing only one part by the new denominator, or reporting $k$ instead of $a$.",
  "C12B-rational-irrational-parts", "Rationalise with an unknown in the numerator, match the irrational part, then back-substitute.",
  correct=r"$9$",
  distractors=[(r"$7$", r"Solves correctly for $k = 7$ and reports $k$."),
               (r"$36$", r"Divides only the irrational part by $4$: $k + 9 = 16$ gives $k = 7$, then takes $a = 3k + 15 = 36$."),
               (r"$0$", r"Forgets to divide by the new denominator $4$: $k + 9 = 4$ gives $k = -5$ and $a = 3k + 15 = 0$.")],
  check=_c033, values=[9, 7, 36, 0],
  cognitive="Application")

# ---------------------------------------------------------------- 034
def _c034():
    x = symbols('x', positive=True)
    f = sqrt(x + sqrt(x + 11)) + sqrt(x - sqrt(x + 11)) - 4
    # after squaring: sqrt(x^2 - x - 11) = 8 - x
    cand = solve(Eq(x**2 - x - 11, (8 - x)**2), x)
    good = [c for c in cand if simplify(f.subs(x, c)) == 0]
    # brute check over a fine rational grid that no other solution exists in the domain
    xs = [3.86 + i * 0.001 for i in range(0, 200000)]
    sgn = None
    changes = 0
    for t in xs:
        v = math.sqrt(t + math.sqrt(t + 11)) + math.sqrt(max(0.0, t - math.sqrt(t + 11))) - 4
        s = v > 0
        if sgn is not None and s != sgn:
            changes += 1
        sgn = s
    assert len(good) == 1 and changes == 1
    return good[0]
q("C12-B-034", T, "Equation with a nested radical solved by squaring the sum", "Medium",
  "Inverse/parameter",
  r"The real number $x$ satisfies $\sqrt{x+\sqrt{x+11}} + \sqrt{x-\sqrt{x+11}} = 4$. The value of $x$ is",
  "MCQ",
  r"Square both sides: $2x + 2\sqrt{x^2 - (x+11)} = 16$, so $\sqrt{x^2 - x - 11} = 8 - x$ (which needs $x \le 8$). Squaring again, $x^2 - x - 11 = 64 - 16x + x^2$, so $15x = 75$ and $x = 5$. Check: $\sqrt{x+11} = 4$, and $\sqrt{9} + \sqrt{1} = 3 + 1 = 4$.",
  "Dropping the cross term when squaring a sum of roots, or reporting an intermediate quantity.",
  "C12B-surd-equation-squaring", "Two squarings with a product of conjugate radicands in the middle (heavy Medium); easy to lose the cross term.",
  correct=r"$5$",
  distractors=[(r"$8$", r"Squares as $(x + \sqrt{x+11}) + (x - \sqrt{x+11}) = 16$, dropping the cross term, so $x = 8$."),
               (r"$9$", r"Reports the radicand $x + \sqrt{x+11} = 9$ of the first root."),
               (r"$4$", r"Reports $\sqrt{x+11} = 4$ rather than $x$.")],
  check=_c034, values=[5, 8, 9, 4],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 035
def _c035():
    def ok(n):
        # sqrt(n+1) - sqrt(n-1) < 1/10, decided exactly with high precision
        return N(sqrt(n + 1) - sqrt(n - 1) - Rational(1, 10), 60) < 0
    for n in range(1, 2000):
        if ok(n):
            assert not ok(n - 1)
            return n
q("C12-B-035", T, "Smallest integer for which a difference of square roots falls below a bound", "Difficult",
  "Inverse/parameter",
  r"The smallest positive integer $n$ for which $\sqrt{n+1} - \sqrt{n-1} < \frac{1}{10}$ is",
  "MCQ",
  r"Rationalise: $\sqrt{n+1} - \sqrt{n-1} = \frac{2}{\sqrt{n+1}+\sqrt{n-1}}$, so the condition is $\sqrt{n+1}+\sqrt{n-1} > 20$. For $n = 100$, $(\sqrt{101}+\sqrt{99})^2 = 200 + 2\sqrt{9999} < 200 + 200 = 400$, so the sum is below $20$ and $n = 100$ fails. For $n = 101$, $\sqrt{102} + \sqrt{100} > 10 + 10 = 20$, so the smallest $n$ is $101$.",
  r"Approximating $\sqrt{n+1}+\sqrt{n-1}$ by $2\sqrt n$ and accepting the boundary value.",
  "C12B-surd-difference-threshold", "Boundary case needs an exact comparison; the natural approximation gives the wrong integer.",
  correct=r"$101$",
  distractors=[(r"$100$", r"Assumes $\sqrt{101}+\sqrt{99} > 2\sqrt{100} = 20$; in fact $\sqrt{101}$ exceeds $10$ by less than $\sqrt{99}$ falls short of it."),
               (r"$102$", r"Bounds the sum below by $2\sqrt{n-1}$ and demands $2\sqrt{n-1} > 20$, i.e. $n - 1 > 100$."),
               (r"$26$", r"Drops the numerator $2$ after rationalising, needing only $\sqrt{n+1}+\sqrt{n-1} > 10$, first true at $n = 26$.")],
  check=_c035, values=[101, 100, 102, 26],
  cognitive="Analysis", exams=CX)
