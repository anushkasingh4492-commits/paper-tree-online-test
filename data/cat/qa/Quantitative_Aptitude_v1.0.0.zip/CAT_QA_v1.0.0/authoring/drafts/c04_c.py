import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Partnership"
CX = ("CAT", "XAT")


def rs(n):
    """Indian digit grouping in LaTeX, e.g. 145000 -> Rs. $1{,}45{,}000$."""
    s = str(int(n))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = "{,}".join(parts + [tail])
    return r"Rs. $" + s + r"$"


def _tl(segments, n=12):
    """Capital x months, simulated month by month.
    segments: list of (from_month, capital) meaning the capital from that month onward
    (months are numbered 0..n-1; 'joins after t months' means from month t)."""
    tot = 0
    for mth in range(n):
        cap = 0
        for start, c in segments:
            if mth >= start:
                cap = c
        tot += cap
    return tot


def _shares(P, weights):
    s = sum(weights)
    return [F(P) * w / s for w in weights]


def _pos(sol):
    return [x for x in sol if x.is_real and x > 0]


# ================================================================ EASY (11)

def _c1():
    r, m = _tl([(4, 50000)]), _tl([(0, 40000)])  # Ravi 8 months, Meera 12 months
    return _shares(99000, [r, m])[0]
q("C04-C-001", T, "Two partners with different capitals and different periods; share of one", "Easy",
  "Single-step computation",
  r"In a joint venture that lasts one year, Ravi invests Rs. $50{,}000$ for the last $8$ months only, while Meera invests Rs. $40{,}000$ for the whole $12$ months. The year's profit of Rs. $99{,}000$ is shared in the ratio of capital multiplied by time. What is Ravi's share?",
  "MCQ",
  r"Capital multiplied by time: Ravi $50{,}000 \times 8 = 4{,}00{,}000$ and Meera $40{,}000 \times 12 = 4{,}80{,}000$, a ratio of $5 : 6$. Ravi gets $\frac{5}{11} \times 99{,}000 = 45{,}000$ rupees.",
  "Sharing profit in the ratio of capitals alone and ignoring the different periods.",
  "C04C-capital-time-basic-share", "One product per partner and one proportional split; the trap is ignoring time.",
  correct=rs(45000),
  distractors=[(rs(55000), r"Uses capitals only, $5 : 4$, giving Ravi $\frac{5}{9} \times 99{,}000 = 55{,}000$."),
               (rs(54000), r"Reports Meera's share, $\frac{6}{11} \times 99{,}000$."),
               (rs(39600), r"Uses the periods only, $8 : 12 = 2 : 3$, giving Ravi $\frac{2}{5} \times 99{,}000 = 39{,}600$.")],
  check=_c1, values=[45000, 55000, 54000, 39600], cognitive="Application")


def _c2():
    a, f = _tl([(0, 72000)]), _tl([(5, 108000)])
    return _shares(135000, [a, f])[1]
q("C04-C-002", T, "Second partner joins after some months; share of the late joiner", "Easy",
  "Multi-step word problem",
  r"Arjun starts a business with Rs. $72{,}000$. Five months later Fatima joins him with Rs. $1{,}08{,}000$. Neither changes the capital afterwards. At the end of the year (counted from the start of the business) the profit is Rs. $1{,}35{,}000$, shared in the ratio of capital multiplied by time. What is Fatima's share, in rupees?",
  "TITA",
  r"Arjun's capital is in for $12$ months and Fatima's for $12 - 5 = 7$ months. The ratio is $72{,}000 \times 12 : 1{,}08{,}000 \times 7 = 8{,}64{,}000 : 7{,}56{,}000 = 8 : 7$. Fatima gets $\frac{7}{15} \times 1{,}35{,}000 = 63{,}000$ rupees.",
  "Splitting the profit in the ratio of capitals only, ignoring that Fatima's money worked for fewer months.",
  "C04C-late-joiner-share", "Two products and a split; the trap is the late joining.",
  tita_answer=63000, check=_c2,
  tita_traps=[(81000, r"Uses capitals only, $2 : 3$, so Fatima gets $\frac{3}{5} \times 1{,}35{,}000$."),
              (72000, r"Reports Arjun's share, $\frac{8}{15} \times 1{,}35{,}000$.")],
  cognitive="Application")


def _c3():
    k, s = _tl([(0, 60000)]), _tl([(0, 80000), (6, 60000)])
    return _shares(91000, [k, s])[1]
q("C04-C-003", T, "Partial withdrawal of capital midway through the year", "Easy",
  "Multi-step word problem",
  r"Kabir and Sneha start a business with Rs. $60{,}000$ and Rs. $80{,}000$ respectively. After $6$ months Sneha withdraws Rs. $20{,}000$ of her capital; there are no other changes. The profit of Rs. $91{,}000$ at the end of the year is shared in the ratio of capital multiplied by time. What is Sneha's share?",
  "MCQ",
  r"Kabir: $60{,}000 \times 12 = 7{,}20{,}000$. Sneha: $80{,}000 \times 6 + 60{,}000 \times 6 = 8{,}40{,}000$. The ratio is $720 : 840 = 6 : 7$, so Sneha gets $\frac{7}{13} \times 91{,}000 = 49{,}000$ rupees.",
  "Using Sneha's starting capital for the whole year, or her reduced capital for the whole year.",
  "C04C-withdrawal-midway-share", "Two time segments for one partner; the trap is ignoring the withdrawal.",
  correct=rs(49000),
  distractors=[(rs(52000), r"Ignores the withdrawal and uses $60{,}000 : 80{,}000 = 3 : 4$, giving $\frac{4}{7} \times 91{,}000$."),
               (rs(45500), r"Uses Sneha's reduced capital $60{,}000$ for the whole year, so the split is $1 : 1$."),
               (rs(42000), r"Reports Kabir's share, $\frac{6}{13} \times 91{,}000$.")],
  check=_c3, values=[49000, 52000, 45500, 42000], cognitive="Application")


def _c4():
    P, sal = 114000, 2000 * 12
    j, p = _tl([(0, 90000)]), _tl([(0, 60000)])
    return sal + _shares(P - sal, [j, p])[1]
q("C04-C-004", T, "Working partner's monthly salary paid out of profit before division", "Easy",
  "Multi-step word problem",
  r"Joseph and Priya invest Rs. $90{,}000$ and Rs. $60{,}000$ in a business for a full year. Priya runs the business and is paid a salary of Rs. $2{,}000$ per month out of the profit; what remains is shared in the ratio of their capitals. The year's profit is Rs. $1{,}14{,}000$. How much does Priya receive in all, in rupees?",
  "TITA",
  r"Priya's salary is $2{,}000 \times 12 = 24{,}000$. The remaining $1{,}14{,}000 - 24{,}000 = 90{,}000$ is shared $90 : 60 = 3 : 2$, so Priya's share is $36{,}000$. In all she receives $24{,}000 + 36{,}000 = 60{,}000$ rupees.",
  "Splitting the whole profit before taking out the salary, or forgetting to add the salary to her share.",
  "C04C-salary-before-division", "Deduct, split, add back; the trap is the order of the salary step.",
  tita_answer=60000, check=_c4,
  tita_traps=[(36000, r"Reports only her capital share and leaves out the salary."),
              (69600, r"Splits the whole $1{,}14{,}000$ in the ratio $3 : 2$ and then adds the salary: $45{,}600 + 24{,}000$.")],
  cognitive="Application")


def _c5():
    P = 80000
    com = F(10, 100) * P
    return com + _shares(P - com, [50000, 75000])[0]
q("C04-C-005", T, "Managing partner's commission as a percentage of total profit, rest by capital", "Easy",
  "Multi-step word problem",
  r"Harpreet and Ananya invest Rs. $50{,}000$ and Rs. $75{,}000$ in a business for a full year. Harpreet manages it and first receives a commission of $10\%$ of the total profit; the rest of the profit is shared in the ratio of their capitals. If the year's profit is Rs. $80{,}000$, how much does Harpreet receive in all?",
  "MCQ",
  r"Commission $= 10\%$ of $80{,}000 = 8{,}000$. The remaining $72{,}000$ is shared $2 : 3$, so Harpreet's capital share is $\frac{2}{5} \times 72{,}000 = 28{,}800$. Her total is $8{,}000 + 28{,}800 = 36{,}800$ rupees.",
  "Dividing the full profit by capital after paying the commission, so that the commission is counted twice.",
  "C04C-commission-before-division", "Commission first, then a two-way split of the remainder.",
  correct=rs(36800),
  distractors=[(rs(32000), r"Leaves out the commission and gives Harpreet $\frac{2}{5}$ of the whole $80{,}000$."),
               (rs(40000), r"Adds the $8{,}000$ commission to $\frac{2}{5}$ of the whole $80{,}000$, not of the remaining $72{,}000$."),
               (rs(43200), r"Reports Ananya's share, $\frac{3}{5} \times 72{,}000$.")],
  check=_c5, values=[36800, 32000, 40000, 43200], cognitive="Application")


def _c6():
    P = symbols('P', positive=True)
    r, a = _tl([(0, 40000)]), _tl([(6, 60000)])
    sh = _shares(1, [r, a])
    return _pos(solve(Eq(P * sh[0] - P * sh[1], 9000), P))[0]
q("C04-C-006", T, "Total profit from the difference of two partners' shares", "Easy",
  "Inverse/parameter",
  r"Ravi starts a business with Rs. $40{,}000$. Six months later Arjun joins with Rs. $60{,}000$, and both stay till the end of the year. The year's profit is shared in the ratio of capital multiplied by time, and Ravi's share exceeds Arjun's by Rs. $9{,}000$. What is the total profit?",
  "MCQ",
  r"Ravi : Arjun $= 40{,}000 \times 12 : 60{,}000 \times 6 = 4{,}80{,}000 : 3{,}60{,}000 = 4 : 3$. The difference is one part, so one part is $9{,}000$ and the total of $7$ parts is $63{,}000$ rupees.",
  "Using the capital ratio, or reporting a single share instead of the total.",
  "C04C-share-difference-total", "One ratio and the unitary method; the trap is the period.",
  correct=rs(63000),
  distractors=[(rs(45000), r"Uses capitals only, $2 : 3$, takes the one part difference as $9{,}000$ and reports $5$ parts."),
               (rs(36000), r"Reports Ravi's share, $4$ parts."),
               (rs(27000), r"Uses the periods only, $12 : 6 = 2 : 1$, so one part is $9{,}000$ and the total is $3$ parts.")],
  check=_c6, values=[63000, 45000, 36000, 27000], cognitive="Application")


def _c7():
    x = symbols('x', positive=True)
    s, k = _tl([(0, 36000)]), 9 * x
    P, ks = 66000, 30000
    return _pos(solve(Eq(k * (P - ks), s * ks), x))[0]
q("C04-C-007", T, "Unknown capital of a late joiner from his share of profit", "Easy",
  "Inverse/parameter",
  r"Sneha starts a business with Rs. $36{,}000$ and keeps it in for the whole year. Kabir joins after $3$ months with some capital and also stays till the end of the year. Out of the year's profit of Rs. $66{,}000$, shared in the ratio of capital multiplied by time, Kabir receives Rs. $30{,}000$. How much capital did Kabir bring, in rupees?",
  "TITA",
  r"Sneha receives $66{,}000 - 30{,}000 = 36{,}000$, so the profit ratio Sneha : Kabir is $6 : 5$. Hence $36{,}000 \times 12 : 9x = 6 : 5$, giving $9x = \frac{5}{6} \times 4{,}32{,}000 = 3{,}60{,}000$ and $x = 40{,}000$ rupees.",
  "Equating the capital ratio to the profit ratio without the factor of time.",
  "C04C-inverse-unknown-capital", "One proportion with time factors; the trap is Kabir's $9$ months.",
  tita_answer=40000, check=_c7,
  tita_traps=[(30000, r"Ignores time and sets $36{,}000 : x = 6 : 5$."),
              (120000, r"Uses $3$ months for Kabir instead of $9$: $3x = 3{,}60{,}000$.")],
  cognitive="Application")


def _c8():
    c1, c2 = symbols('c1 c2', positive=True)
    # profit ratio 5:3, time ratio 2:3
    sol = solve(Eq(c1 * 2 * 3, c2 * 3 * 5), c1)
    return sol[0] / c2
q("C04-C-008", T, "Ratio of capitals from the ratio of profits and the ratio of periods", "Easy",
  "Conceptual/application",
  r"Priya and Joseph invested in a business for different periods. The ratio of their profits is $5 : 3$ and the ratio of the periods for which their money was invested is $2 : 3$. What is the ratio of Priya's capital to Joseph's capital?",
  "MCQ",
  r"Profit is proportional to capital times time, so capital is proportional to $\frac{\text{profit}}{\text{time}}$. Priya : Joseph $= \frac{5}{2} : \frac{3}{3} = \frac{5}{2} : 1 = 5 : 2$.",
  "Multiplying the profit ratio by the time ratio instead of dividing by it.",
  r"C04C-profit-capital-time-relation", r"Single relation profit $\propto$ capital $\times$ time, rearranged once.",
  correct=r"$5 : 2$",
  distractors=[(r"$10 : 9$", r"Multiplies the profit ratio by the time ratio: $5 \times 2 : 3 \times 3$."),
               (r"$2 : 5$", r"Divides time by profit, $\frac{2}{5} : \frac{3}{3}$, which inverts the answer."),
               (r"$5 : 3$", r"Takes the profit ratio as the capital ratio and ignores the periods.")],
  check=_c8, values=[F(5, 2), F(10, 9), F(2, 5), F(5, 3)], cognitive="Understanding")


def _c9():
    f, a = _tl([(0, 120000)]), _tl([(3, 80000)])
    return _shares(33000, [f, a])[0]
q("C04-C-009", T, "Sharing a loss in the ratio of capital multiplied by time", "Easy",
  "Single-step computation",
  r"Fatima starts a shop with Rs. $1{,}20{,}000$. Three months later Ananya joins with Rs. $80{,}000$, and both remain till the end of the year. The shop makes a loss of Rs. $33{,}000$ for the year, which they bear in the ratio of capital multiplied by time. How much of the loss does Fatima bear?",
  "MCQ",
  r"Fatima: $1{,}20{,}000 \times 12 = 14{,}40{,}000$; Ananya: $80{,}000 \times 9 = 7{,}20{,}000$. The ratio is $2 : 1$, so Fatima bears $\frac{2}{3} \times 33{,}000 = 22{,}000$ rupees.",
  "Sharing the loss by capitals alone, or thinking a loss is shared equally.",
  "C04C-loss-sharing", "Same rule as profit, applied to a loss; one ratio and one split.",
  correct=rs(22000),
  distractors=[(rs(19800), r"Uses capitals only, $3 : 2$, so Fatima bears $\frac{3}{5} \times 33{,}000$."),
               (rs(11000), r"Reports Ananya's portion of the loss."),
               (rs(16500), r"Splits the loss equally between the two partners.")],
  check=_c9, values=[22000, 19800, 11000, 16500], cognitive="Application")


def _c10():
    d = symbols('d', positive=True)
    a = _tl([(0, 60000)])
    months_in = _pos(solve(Eq(a, 80000 * d), d))[0]
    return 12 - months_in
q("C04-C-010", T, "Joining time of a partner when the year's profit is shared equally", "Easy",
  "Inverse/parameter",
  r"Arjun starts a business with Rs. $60{,}000$. Some whole number of months later Priya joins with Rs. $80{,}000$, and neither changes the capital afterwards. At the end of the year (counted from the start of the business) the profit is shared in the ratio of capital multiplied by time, and the two receive equal shares. After how many months from the start did Priya join?",
  "TITA",
  r"Equal shares need equal capital-months: $60{,}000 \times 12 = 80{,}000 \times d$, where $d$ is the number of months Priya's money was in. So $d = 9$, and she joined $12 - 9 = 3$ months after the start.",
  "Reporting the number of months Priya's capital was in the business instead of when she joined.",
  "C04C-inverse-joining-time", "One equation in the period, then one subtraction; the trap is reporting $9$.",
  tita_answer=3, check=_c10,
  tita_traps=[(9, r"Reports the months Priya was in the business, not the month she joined after.")],
  cognitive="Application")


def _c11():
    w = [_tl([(0, 30000)]), _tl([(2, 45000)]), _tl([(6, 60000)])]
    return _shares(117000, w)[2]
q("C04-C-011", T, "Three partners with different capitals and periods; share of one", "Easy",
  "Single-step computation",
  r"Sneha starts a business with Rs. $30{,}000$. Two months later Kabir joins with Rs. $45{,}000$, and six months after the start Ananya joins with Rs. $60{,}000$. All three stay till the end of the year, and the profit of Rs. $1{,}17{,}000$ is shared in the ratio of capital multiplied by time. What is Ananya's share?",
  "MCQ",
  r"Capital-months: Sneha $30{,}000 \times 12 = 3{,}60{,}000$, Kabir $45{,}000 \times 10 = 4{,}50{,}000$, Ananya $60{,}000 \times 6 = 3{,}60{,}000$. The ratio is $4 : 5 : 4$, so Ananya gets $\frac{4}{13} \times 1{,}17{,}000 = 36{,}000$ rupees.",
  "Splitting by capital alone, which favours the partner with the most money but the least time.",
  "C04C-capital-time-basic-share", "Three products and a split; the trap is the largest capital for the shortest period.",
  correct=rs(36000),
  distractors=[(rs(52000), r"Uses capitals only, $2 : 3 : 4$, so Ananya gets $\frac{4}{9} \times 1{,}17{,}000$."),
               (rs(45000), r"Reports Kabir's share, $\frac{5}{13} \times 1{,}17{,}000$."),
               (rs(39000), r"Splits the profit equally among the three partners.")],
  check=_c11, values=[36000, 52000, 45000, 39000], cognitive="Application")


# ================================================================ MEDIUM (15)

def _c12():
    w = [_tl([(0, 40000), (4, 30000)]), _tl([(0, 50000)]), _tl([(0, 60000), (8, 0)])]
    return _shares(74000, w)[2]
q("C04-C-012", T, "Three partners; one partly withdraws and another leaves before the year ends", "Medium",
  "Multi-step word problem",
  r"Joseph, Harpreet and Ananya start a business with Rs. $40{,}000$, Rs. $50{,}000$ and Rs. $60{,}000$ respectively. After $4$ months Joseph withdraws Rs. $10{,}000$ of his capital. After $8$ months (from the start) Ananya withdraws her entire capital and leaves. The profit of Rs. $74{,}000$ at the end of the year is shared in the ratio of capital multiplied by time. What is Ananya's share, in rupees?",
  "TITA",
  r"Capital-months in thousands: Joseph $40 \times 4 + 30 \times 8 = 400$, Harpreet $50 \times 12 = 600$, Ananya $60 \times 8 = 480$. The total is $1480$, so each unit is worth $\frac{74{,}000}{1480} = 50$ rupees and Ananya gets $480 \times 50 = 24{,}000$ rupees.",
  "Ignoring the mid-year changes and splitting by the starting capitals.",
  "C04C-withdrawal-midway-share", "Two separate mid-year changes for two partners before a three-way split.",
  tita_answer=24000, check=_c12,
  tita_traps=[(29600, r"Ignores both changes and splits by starting capitals $4 : 5 : 6$."),
              (30000, r"Reports Harpreet's share, $600 \times 50$.")],
  cognitive="Application")


def _c13():
    P, sal = 200000, 3000 * 12
    m, k = _tl([(0, 80000)]), _tl([(4, 120000)])
    return sal + _shares(P - sal, [m, k])[0]
q("C04-C-013", T, "Working partner's salary combined with a late-joining partner", "Medium",
  "Multi-step word problem",
  r"Meera starts a business with Rs. $80{,}000$. Four months later Kabir joins with Rs. $1{,}20{,}000$. Meera manages the business and is paid Rs. $3{,}000$ per month for all $12$ months out of the profit; the rest of the profit is shared in the ratio of capital multiplied by time. If the year's profit is Rs. $2{,}00{,}000$, how much does Meera receive in all?",
  "MCQ",
  r"Salary $= 3{,}000 \times 12 = 36{,}000$, leaving $1{,}64{,}000$. Capital-months: Meera $80{,}000 \times 12 = 9{,}60{,}000$ and Kabir $1{,}20{,}000 \times 8 = 9{,}60{,}000$, so the remainder is split equally, $82{,}000$ each. Meera receives $36{,}000 + 82{,}000 = 1{,}18{,}000$ rupees.",
  "Splitting by capitals alone after the salary, or splitting the profit before taking out the salary.",
  "C04C-salary-before-division", "Salary deduction plus a capital-time split with a late joiner.",
  correct=rs(118000),
  distractors=[(rs(101600), r"Splits the $1{,}64{,}000$ by capitals only, $2 : 3$: $65{,}600 + 36{,}000$."),
               (rs(136000), r"Splits the whole $2{,}00{,}000$ equally before paying the salary, then adds it: $1{,}00{,}000 + 36{,}000$."),
               (rs(82000), r"Gives only Meera's share of the remainder and leaves out her salary.")],
  check=_c13, values=[118000, 101600, 136000, 82000], cognitive="Application")


def _c14():
    P = 108000
    c = symbols('c', positive=True)
    com = solve(Eq(c, F(20, 100) * (P - c)), c)[0]
    return com + _shares(P - com, [50000, 75000])[0]
q("C04-C-014", T, "Commission defined as a percentage of the profit left after the commission", "Medium",
  "Conceptual/application",
  r"Ravi and Sneha invest Rs. $50{,}000$ and Rs. $75{,}000$ in a business for a full year. Ravi manages it and receives a commission equal to $20\%$ of the profit that remains after his commission has been paid; that remaining profit is then shared in the ratio of their capitals. The year's profit is Rs. $1{,}08{,}000$. How much does Ravi receive in all, in rupees?",
  "TITA",
  r"If the remaining profit is $R$, the commission is $0.2R$, so $1.2R = 1{,}08{,}000$, $R = 90{,}000$ and the commission is $18{,}000$. Ravi's capital share is $\frac{2}{5} \times 90{,}000 = 36{,}000$, so he receives $18{,}000 + 36{,}000 = 54{,}000$ rupees.",
  r"Taking the commission as $20\%$ of the total profit instead of $20\%$ of what is left after it.",
  "C04C-commission-before-division", "The commission base is the post-commission profit, which needs a small equation.",
  tita_answer=54000, check=_c14,
  tita_traps=[(56160, r"Takes $20\%$ of the total, $21{,}600$, then adds $\frac{2}{5} \times 86{,}400$."),
              (36000, r"Gives only Ravi's capital share and leaves out the commission.")],
  cognitive="Analysis")


def _c15():
    x = symbols('x', positive=True)
    f = 6 * x + 6 * (x + 30000)
    a = _tl([(0, 90000)])
    return _pos(solve(Eq(f * 60000, a * 50000), x))[0]
q("C04-C-015", T, "Unknown starting capital of a partner who adds money midway", "Medium",
  "Inverse/parameter",
  r"Fatima and Arjun start a business together; Arjun puts in Rs. $90{,}000$. After $6$ months Fatima adds Rs. $30{,}000$ to her capital, and there are no other changes. Of the year's profit of Rs. $1{,}10{,}000$, shared in the ratio of capital multiplied by time, Fatima receives Rs. $50{,}000$. With how much capital did Fatima start?",
  "MCQ",
  r"Let Fatima start with $x$. Her capital-months are $6x + 6(x + 30{,}000) = 12x + 1{,}80{,}000$, and Arjun's are $90{,}000 \times 12 = 10{,}80{,}000$. Since Fatima : Arjun $= 50{,}000 : 60{,}000 = 5 : 6$, $12x + 1{,}80{,}000 = 9{,}00{,}000$, so $x = 60{,}000$ rupees.",
  "Treating the starting capital, or the final capital, as if it stayed for the whole year.",
  "C04C-inverse-unknown-capital", "Sets up a linear equation with a mid-year change; several tempting shortcuts.",
  correct=rs(60000),
  distractors=[(rs(75000), r"Ignores the addition: $12x = 9{,}00{,}000$."),
               (rs(45000), r"Uses $x + 30{,}000$ for all $12$ months: $12(x + 30{,}000) = 9{,}00{,}000$."),
               (rs(90000), r"Reports Fatima's capital after the addition, $60{,}000 + 30{,}000$.")],
  check=_c15, values=[60000, 75000, 45000, 90000], cognitive="Application")


def _c16():
    t = symbols('t', positive=True)
    ravi = _tl([(0, 40000)])
    sol = _pos(solve(Eq(ravi, 80000 * (12 - 2 * t)), t))[0]
    return 2 * sol
q("C04-C-016", T, "Joining time of a third partner when two shares are equal", "Medium",
  "Inverse/parameter",
  r"Ravi starts a business with Rs. $40{,}000$. Some months later Meera joins with Rs. $60{,}000$, and exactly the same number of months after Meera joins, Kabir joins with Rs. $80{,}000$. Nobody withdraws, and the profit at the end of the year (from the start of the business) is shared in the ratio of capital multiplied by time. If Ravi's and Kabir's shares are equal, how many months after the start of the business did Kabir join?",
  "TITA",
  r"Let Meera join after $t$ months; Kabir then joins after $2t$ months and his money is in for $12 - 2t$ months. Equal shares give $40{,}000 \times 12 = 80{,}000(12 - 2t)$, so $12 - 2t = 6$ and $t = 3$. Kabir joined $2t = 6$ months after the start. Meera's capital does not affect the comparison.",
  "Reporting Meera's joining time $t$ instead of Kabir's $2t$.",
  "C04C-inverse-joining-time", "Two joining times linked by one parameter, plus a redundant given to ignore.",
  tita_answer=6, check=_c16,
  tita_traps=[(3, r"Reports $t$, the month Meera joined, instead of Kabir's $2t$.")],
  cognitive="Analysis")


def _c17():
    c = [3, 4, 6]
    p = [1, 2, 3]
    t = [F(pi, ci) for pi, ci in zip(p, c)]
    return tuple(x / t[0] for x in t)  # normalised so the first term is 1
q("C04-C-017", T, "Ratio of periods from the ratio of capitals and the ratio of profits", "Medium",
  "Conceptual/application",
  r"Joseph, Priya and Harpreet invested capitals in the ratio $3 : 4 : 6$ in a business, each for a different period. At the end, the profit was shared in the ratio of capital multiplied by time, and their profits were in the ratio $1 : 2 : 3$. What is the ratio of the periods for which Joseph, Priya and Harpreet kept their money in the business?",
  "MCQ",
  r"Time is proportional to $\frac{\text{profit}}{\text{capital}}$: $\frac{1}{3} : \frac{2}{4} : \frac{3}{6} = \frac{1}{3} : \frac{1}{2} : \frac{1}{2}$. Multiplying by $6$ gives $2 : 3 : 3$. Check: $3 \times 2 : 4 \times 3 : 6 \times 3 = 6 : 12 : 18 = 1 : 2 : 3$.",
  "Multiplying the two ratios, or dividing them the wrong way round.",
  "C04C-profit-capital-time-relation", "Three-term rearrangement with fractions; easy to invert or multiply by mistake.",
  correct=r"$2 : 3 : 3$",
  distractors=[(r"$3 : 2 : 2$", r"Divides capital by profit, $\frac{3}{1} : \frac{4}{2} : \frac{6}{3}$, which inverts each term."),
               (r"$3 : 8 : 18$", r"Multiplies the capital ratio by the profit ratio term by term."),
               (r"$1 : 2 : 3$", r"Takes the profit ratio itself as the ratio of periods.")],
  check=_c17,
  values=[(1, F(3, 2), F(3, 2)), (1, F(2, 3), F(2, 3)), (1, F(8, 3), 6), (1, 2, 3)], cognitive="Understanding")


def _c18():
    a = _tl([(0, 100000), (3, 80000), (6, 60000), (9, 40000)])
    k = _tl([(0, 50000), (3, 75000), (6, 100000), (9, 125000)])
    return _shares(198000, [a, k])[1]
q("C04-C-018", T, "Capitals changing every quarter; one partner withdrawing and one adding", "Medium",
  "Multi-step word problem",
  r"Ananya and Kabir start a business with Rs. $1{,}00{,}000$ and Rs. $50{,}000$ respectively. At the end of the $3$rd, $6$th and $9$th months, Ananya withdraws Rs. $20{,}000$ each time and Kabir adds Rs. $25{,}000$ each time. The profit of Rs. $1{,}98{,}000$ at the end of the year is shared in the ratio of capital multiplied by time. What is Kabir's share?",
  "MCQ",
  r"Each capital stays for $3$ months at a time. Ananya: $3(100 + 80 + 60 + 40) = 840$ thousand rupee-months; Kabir: $3(50 + 75 + 100 + 125) = 1050$. The ratio is $4 : 5$, so Kabir gets $\frac{5}{9} \times 1{,}98{,}000 = 1{,}10{,}000$ rupees.",
  "Using only the opening capitals or only the closing capitals.",
  "C04C-multi-stage-timeline", "Four quarterly segments for each partner before the split.",
  correct=rs(110000),
  distractors=[(rs(66000), r"Uses the opening capitals $2 : 1$, so Kabir gets $\frac{1}{3} \times 1{,}98{,}000$."),
               (rs(150000), r"Uses the closing capitals $40{,}000 : 1{,}25{,}000 = 8 : 25$, so Kabir gets $\frac{25}{33} \times 1{,}98{,}000$."),
               (rs(88000), r"Reports Ananya's share, $\frac{4}{9} \times 1{,}98{,}000$.")],
  check=_c18, values=[110000, 66000, 150000, 88000], cognitive="Application", exams=CX)


def _c19():
    P = 160000
    rate = F(12, 100)
    h_seg, a_seg = [(0, 200000)], [(4, 180000)]
    # simple interest month by month on the capital actually in the business
    ih = rate * _tl(h_seg) / 12
    ia = rate * _tl(a_seg) / 12
    rest = P - ih - ia
    w = [_tl(h_seg), _tl(a_seg)]
    return ia + rest * F(w[1], sum(w))
q("C04-C-019", T, "Interest on capital for the period invested, then the rest shared by capital multiplied by time", "Medium",
  "Conceptual/application",
  r"Harpreet starts a business with Rs. $2{,}00{,}000$, and Ananya joins $4$ months later with Rs. $1{,}80{,}000$; both stay till the end of the year. Out of the year's profit of Rs. $1{,}60{,}000$, each partner is first paid simple interest at $12\%$ per annum on capital for the period the capital was in the business. The remaining profit is shared in the ratio of capital multiplied by time. How much does Ananya receive in all?",
  "MCQ",
  r"Interest for the period invested is proportional to capital multiplied by time, so the interest is paid in the same ratio as the remainder: Harpreet $200 \times 12 = 2400$, Ananya $180 \times 8 = 1440$ (thousand rupee-months), that is $5 : 3$. Hence the whole profit effectively goes $5 : 3$, and Ananya receives $\frac{3}{8} \times 1{,}60{,}000 = 60{,}000$ rupees. Directly: interest $24{,}000$ and $14{,}400$, remainder $1{,}21{,}600$, Ananya's part $45{,}600$, total $14{,}400 + 45{,}600 = 60{,}000$.",
  "Sharing the remainder by capitals alone, or charging the late joiner a full year's interest.",
  "C04C-interest-on-capital", "Two layers (time-based interest, then a capital-time split); the fast route needs the insight that the interest does not change the overall ratio.",
  correct=rs(60000),
  distractors=[(rs(72000), r"Shares the remaining $1{,}21{,}600$ by capitals only, $10 : 9$: $14{,}400 + 57{,}600$."),
               (rs(64500), r"Gives Ananya a full year's interest, $21{,}600$, leaving $1{,}14{,}400$ to split $5 : 3$: $21{,}600 + 42{,}900$."),
               (rs(45600), r"Reports only Ananya's part of the remainder and leaves out her interest.")],
  check=_c19, values=[60000, 72000, 64500, 45600], cognitive="Understanding")


def _c20():
    P = symbols('P', positive=True)
    s, a = _tl([(0, 50000)]), _tl([(3, 80000), (10, 0)])
    sh = _shares(1, [s, a])
    return _pos(solve(Eq(P * (sh[0] - sh[1]), 4000), P))[0]
q("C04-C-020", T, "Total profit from a share difference when a partner joins late and leaves early", "Medium",
  "Inverse/parameter",
  r"Sneha starts a business with Rs. $50{,}000$ and keeps it in for the whole year. Arjun joins $3$ months after the start with Rs. $80{,}000$ and withdraws his entire capital $2$ months before the end of the year. The year's profit is shared in the ratio of capital multiplied by time, and Sneha's share exceeds Arjun's by Rs. $4{,}000$. What is the total profit, in rupees?",
  "TITA",
  r"Arjun's money is in for $12 - 3 - 2 = 7$ months. Sneha : Arjun $= 50{,}000 \times 12 : 80{,}000 \times 7 = 6{,}00{,}000 : 5{,}60{,}000 = 15 : 14$. One part is $4{,}000$, so the total of $29$ parts is $1{,}16{,}000$ rupees.",
  "Miscounting Arjun's months, or reporting Sneha's share instead of the total.",
  "C04C-share-difference-total", "Period with both late entry and early exit, then the unitary method.",
  tita_answer=116000, check=_c20,
  tita_traps=[(60000, r"Reports Sneha's share, $15$ parts."),
              (56000, r"Reports Arjun's share, $14$ parts.")],
  cognitive="Application")


def _c21():
    s = symbols('s', positive=True)
    P = 180000
    m, r = _tl([(0, 60000)]), _tl([(0, 120000)])
    rest = P - 12 * s
    sh = [rest * F(m, m + r), rest * F(r, m + r)]
    return _pos(solve(Eq(12 * s + sh[0], sh[1]), s))[0]
q("C04-C-021", T, "Monthly salary of a working partner that makes both partners' totals equal", "Medium",
  "Inverse/parameter",
  r"Meera and Ravi invest Rs. $60{,}000$ and Rs. $1{,}20{,}000$ in a business for a full year. Meera manages the business and is paid a fixed salary every month for $12$ months out of the profit; the rest of the profit is shared in the ratio of their capitals. The year's profit is Rs. $1{,}80{,}000$, and Meera and Ravi end up receiving equal amounts in all. What is Meera's monthly salary?",
  "MCQ",
  r"Each receives $90{,}000$. If the annual salary is $S$, the remainder $1{,}80{,}000 - S$ is shared $1 : 2$, and Ravi's $\frac{2}{3}(1{,}80{,}000 - S) = 90{,}000$ gives $1{,}80{,}000 - S = 1{,}35{,}000$, so $S = 45{,}000$. The monthly salary is $\frac{45{,}000}{12} = 3{,}750$ rupees.",
  "Forgetting that the salary reduces the profit being shared, or forgetting Meera's own capital share.",
  "C04C-working-partner-inverse", "Equation in the salary where the salary also shrinks the divisible profit.",
  correct=rs(3750),
  distractors=[(rs(5000), r"Does not deduct the salary before division: $12s + 60{,}000 = 1{,}20{,}000$."),
               (rs(6000), r"Sets Meera's salary equal to Ravi's share of the remainder: $12s = \frac{2}{3}(1{,}80{,}000 - 12s)$."),
               (rs(7500), r"Sets the salary alone equal to half the profit: $12s = 90{,}000$.")],
  check=_c21, values=[3750, 5000, 6000, 7500], cognitive="Analysis", exams=CX)


def _c22():
    w = [F(1, 3) * F(3, 4), F(1, 2) * 1, (1 - F(1, 3) - F(1, 2)) * F(1, 2)]
    return w[0] / sum(w)
q("C04-C-022", T, "Fractions of total capital invested for fractions of the year; one partner's fraction of profit", "Medium",
  "Conceptual/application",
  r"Kabir, Sneha and Priya together finance a one-year venture. Kabir provides $\frac{1}{3}$ of the total capital and keeps it in for $\frac{3}{4}$ of the year; Sneha provides $\frac{1}{2}$ of the capital for the whole year; Priya provides the rest of the capital for half the year. Profit is shared in the ratio of capital multiplied by time. What fraction of the profit does Kabir receive?",
  "MCQ",
  r"Priya's fraction of the capital is $1 - \frac{1}{3} - \frac{1}{2} = \frac{1}{6}$. Capital times time: Kabir $\frac{1}{3} \times \frac{3}{4} = \frac{1}{4}$, Sneha $\frac{1}{2}$, Priya $\frac{1}{6} \times \frac{1}{2} = \frac{1}{12}$. The ratio is $3 : 6 : 1$, so Kabir receives $\frac{3}{10}$ of the profit.",
  "Reporting Kabir's capital-time product as his fraction without dividing by the total of all three products.",
  "C04C-fractional-capital-time", "Works entirely with fractions and needs the normalising step.",
  correct=r"$\frac{3}{10}$",
  distractors=[(r"$\frac{1}{3}$", r"Uses capital fractions only and ignores the periods."),
               (r"$\frac{8}{23}$", r"Divides capital by time, $\frac{4}{9} : \frac{1}{2} : \frac{1}{3} = 8 : 9 : 6$."),
               (r"$\frac{1}{4}$", r"Reports Kabir's product $\frac{1}{3} \times \frac{3}{4}$ without dividing by the total $\frac{5}{6}$.")],
  check=_c22, values=[F(3, 10), F(1, 3), F(8, 23), F(1, 4)], cognitive="Understanding")


def _c23():
    best = None
    r, m = _tl([(0, 60000)]), _tl([(0, 90000)])
    for wait in range(0, 12):
        k = _tl([(wait, 120000)])
        if F(k, r + m + k) >= F(1, 4):
            best = wait
    return best
q("C04-C-023", T, "Latest joining time that still secures a minimum fraction of the profit", "Medium",
  "Casework/optimisation",
  r"Ravi and Meera start a business with Rs. $60{,}000$ and Rs. $90{,}000$, which stay in for the whole year. Kabir plans to join at the end of some whole number of months with Rs. $1{,}20{,}000$ and stay till the end of the year. Profit at the end of the year is shared in the ratio of capital multiplied by time. Kabir wants his share to be at least one-fourth of the total profit. What is the maximum number of months after the start that he can wait before joining?",
  "TITA",
  r"Ravi and Meera have $60 \times 12 + 90 \times 12 = 1800$ thousand rupee-months. If Kabir is in for $d$ months he has $120d$, and he needs $120d \geq \frac{1}{3} \times 1800 = 600$ (one-fourth of the total means one-third of the others). So $d \geq 5$, and he can wait at most $12 - 5 = 7$ months; at $7$ he gets exactly one-fourth.",
  "Reporting the minimum months in the business, $5$, instead of the waiting time.",
  "C04C-threshold-share-optimisation", "Converts a share threshold into an inequality and then into a waiting time.",
  tita_answer=7, check=_c23,
  tita_traps=[(5, r"Reports the minimum number of months Kabir must be in the business."),
              (8, r"Off-by-one: counts months inclusively, $12 - 5 + 1 = 8$.")],
  cognitive="Analysis")


def _c24():
    w = [_tl([(0, 50000), (4, 30000)]), _tl([(0, 50000)]), _tl([(4, 90000)])]
    return _shares(132000, w)[2]
q("C04-C-024", T, "New partner joins while an existing partner withdraws part of his capital", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera start a business with Rs. $50{,}000$ each. After $4$ months Kabir joins with Rs. $90{,}000$, and at the same moment Ravi withdraws Rs. $20{,}000$ of his capital. There are no other changes. The profit of Rs. $1{,}32{,}000$ at the end of the year is shared in the ratio of capital multiplied by time. What is Kabir's share?",
  "MCQ",
  r"In thousand rupee-months: Ravi $50 \times 4 + 30 \times 8 = 440$, Meera $50 \times 12 = 600$, Kabir $90 \times 8 = 720$. The total is $1760$, so Kabir gets $\frac{720}{1760} \times 1{,}32{,}000 = 54{,}000$ rupees.",
  "Missing the simultaneous withdrawal by Ravi.",
  "C04C-late-joiner-share", "A joining and a withdrawal at the same moment across three partners.",
  correct=rs(54000),
  distractors=[(rs(49500), r"Ignores Ravi's withdrawal: $600 : 600 : 720$, so Kabir gets $\frac{6}{16} \times 1{,}32{,}000$."),
               (rs(45000), r"Reports Meera's share, $\frac{600}{1760} \times 1{,}32{,}000$."),
               (rs(44000), r"Splits the profit equally among the three partners.")],
  check=_c24, values=[54000, 49500, 45000, 44000], cognitive="Application")


def _c25():
    h = _tl([(0, 80000), (12, 40000)], n=18)
    j = _tl([(6, 120000)], n=18)
    return _shares(132000, [h, j])[1]
q("C04-C-025", T, "Profit shared at the end of an 18-month period with a joining and a withdrawal", "Medium",
  "Multi-step word problem",
  r"Harpreet starts a business with Rs. $80{,}000$. Six months later Joseph joins with Rs. $1{,}20{,}000$. Six months after Joseph joins, Harpreet withdraws half of his capital. The accounts are closed $18$ months after the start of the business, and the profit of Rs. $1{,}32{,}000$ for the whole $18$ months is shared in the ratio of capital multiplied by time. What is Joseph's share?",
  "MCQ",
  r"Harpreet: $80{,}000 \times 12 + 40{,}000 \times 6 = 12{,}00{,}000$. Joseph is in for $18 - 6 = 12$ months: $1{,}20{,}000 \times 12 = 14{,}40{,}000$. The ratio is $5 : 6$, so Joseph gets $\frac{6}{11} \times 1{,}32{,}000 = 72{,}000$ rupees.",
  "Misreading the periods in an 18-month account: ignoring the withdrawal or giving Joseph only $6$ months.",
  "C04C-multi-stage-timeline", "An account period longer than a year with two events to place on the timeline.",
  correct=rs(72000),
  distractors=[(rs(66000), r"Ignores Harpreet's withdrawal: $80{,}000 \times 18 = 14{,}40{,}000$, so the split is $1 : 1$."),
               (rs(60000), r"Reports Harpreet's share, $\frac{5}{11} \times 1{,}32{,}000$."),
               (rs(49500), r"Gives Joseph only $6$ months: $12{,}00{,}000 : 7{,}20{,}000 = 5 : 3$, so Joseph gets $\frac{3}{8} \times 1{,}32{,}000$.")],
  check=_c25, values=[72000, 66000, 60000, 49500], cognitive="Application", exams=CX)


def _c26():
    x = symbols('x', positive=True)
    s, p = _tl([(0, 120000)]), _tl([(3, 80000)])
    f = 6 * x
    return _pos(solve(Eq(f * (150000 - 30000), (s + p) * 30000), x))[0]
q("C04-C-026", T, "Unknown capital of the third partner from that partner's share of profit", "Medium",
  "Inverse/parameter",
  r"Sneha starts a business with Rs. $1{,}20{,}000$. Priya joins after $3$ months with Rs. $80{,}000$, and Fatima joins after $6$ months (from the start) with some capital. All three stay till the end of the year. Out of the year's profit of Rs. $1{,}50{,}000$, shared in the ratio of capital multiplied by time, Fatima receives Rs. $30{,}000$. How much capital did Fatima bring?",
  "MCQ",
  r"Fatima's share is $\frac{30{,}000}{1{,}50{,}000} = \frac{1}{5}$, so her capital-months are one-fourth of the other two together. Sneha and Priya have $120 \times 12 + 80 \times 9 = 2160$ thousand rupee-months, so Fatima has $540$, and her capital is $\frac{540}{6} = 90$ thousand, that is, Rs. $90{,}000$.",
  "Leaving out time for one or more partners when equating the share.",
  "C04C-inverse-unknown-capital", "Three partners with staggered entry; the unknown is found from a share fraction.",
  correct=rs(90000),
  distractors=[(rs(50000), r"Ignores time for everyone: $\frac{1}{4}(1{,}20{,}000 + 80{,}000)$."),
               (rs(100000), r"Gives Priya $12$ months: $\frac{1}{4}(1440 + 960) = 600$, then $\frac{600}{6}$."),
               (rs(70000), r"Uses $3$ months for Priya: $\frac{1}{4}(1440 + 240) = 420$, then $\frac{420}{6}$.")],
  check=_c26, values=[90000, 50000, 100000, 70000], cognitive="Application")


# ================================================================ DIFFICULT (9)

def _c27():
    ravi = _tl([(0, 60000), (6, 40000)])
    found = set()
    for m in range(1, 12):
        for cap in range(5000, 200001, 5000):
            if _tl([(m, cap)]) == ravi:
                found.add(cap)
    return len(found)
q("C04-C-027", T, "Counting the possible capitals of a late joiner under equal sharing and divisibility limits", "Difficult",
  "Casework/optimisation",
  r"Ravi starts a business with Rs. $60{,}000$ and withdraws Rs. $20{,}000$ of it at the end of the $6$th month. Meera joins at the end of some whole number of months, between $1$ and $11$ inclusive, with a capital that is a multiple of Rs. $5{,}000$ and is at most Rs. $2{,}00{,}000$. Neither makes any other change. The profit at the end of the year is shared in the ratio of capital multiplied by time, and Ravi and Meera receive equal shares. How many different amounts could Meera's capital have been?",
  "TITA",
  r"Ravi has $60 \times 6 + 40 \times 6 = 600$ thousand rupee-months. If Meera's money is in for $d$ months ($1 \leq d \leq 11$), her capital is $\frac{600}{d}$ thousand, which must be a multiple of $5$ thousand and at most $200$ thousand. So $\frac{120}{d}$ is a whole number and $d \geq 3$: $d = 3, 4, 5, 6, 8, 10$, giving capitals of $200, 150, 120, 100, 75, 60$ thousand. That is $6$ amounts.",
  "Ignoring the upper limit on capital, or ignoring Ravi's withdrawal.",
  "C04C-joining-month-casework", "Divisor casework with two constraints after building Ravi's capital-months.",
  tita_answer=6, check=_c27,
  tita_traps=[(8, r"Ignores the Rs. $2{,}00{,}000$ limit and also counts $d = 1$ and $d = 2$."),
              (4, r"Ignores Ravi's withdrawal and uses $720$ thousand rupee-months."),
              (5, r"Treats the limit as strict and drops the Rs. $2{,}00{,}000$ case.")],
  cognitive="Analysis", exams=CX)


def _c28():
    P = symbols('P', positive=True)
    sal = 2000 * 12
    pr, jo = _tl([(0, 100000)]), _tl([(4, 150000)])
    rest = P - sal
    com = F(10, 100) * rest
    total = sal + com + (rest - com) * F(pr, pr + jo)
    return _pos(solve(Eq(total, 90000), P))[0]
q("C04-C-028", T, "Total profit from a working partner's total receipt with salary, commission and capital share", "Difficult",
  "Inverse/parameter",
  r"Priya starts a business with Rs. $1{,}00{,}000$, and Joseph joins $4$ months later with Rs. $1{,}50{,}000$. Priya runs the business. Out of the year's profit she is first paid a salary of Rs. $2{,}000$ per month for $12$ months; next she is paid a commission of $10\%$ of the profit left after the salary; the rest is shared in the ratio of capital multiplied by time. Priya receives Rs. $90{,}000$ in all. What is the year's total profit, in rupees?",
  "TITA",
  r"Salary $= 24{,}000$. Let $X$ be the profit after salary. Capital-months are $100 \times 12 = 1200$ and $150 \times 8 = 1200$ (thousands), so the final remainder $0.9X$ is split equally. Priya gets $24{,}000 + 0.1X + 0.45X = 24{,}000 + 0.55X = 90{,}000$, so $X = 1{,}20{,}000$ and the total profit is $1{,}44{,}000$ rupees.",
  "Reporting the profit after salary, or forgetting the commission layer.",
  "C04C-working-partner-inverse", "Three layers of payout reversed from one total; needs a clean variable choice.",
  tita_answer=144000, check=_c28,
  tita_traps=[(120000, r"Reports $X$, the profit after salary, and does not add the salary back."),
              (156000, r"Leaves out the commission: $24{,}000 + 0.5X = 90{,}000$ gives $X = 1{,}32{,}000$.")],
  cognitive="Analysis", exams=CX)


def _c29():
    K = symbols('K', positive=True)
    fa = _tl([(0, 80000), (5, 20000)])
    jo = _tl([(0, 130000)])
    an = _tl([(5, 1)]) * K
    return _pos(solve(Eq(an * 5, 2 * (fa + jo + an)), K))[0]
q("C04-C-029", T, "Minimum capital a new partner must bring to secure a target share when another partner withdraws", "Difficult",
  "Casework/optimisation",
  r"Fatima and Joseph start a business with Rs. $80{,}000$ and Rs. $1{,}30{,}000$. After $5$ months Ananya joins with some capital, and at that same moment Fatima withdraws Rs. $60{,}000$ of her capital. There are no other changes, and the profit at the end of the year is shared in the ratio of capital multiplied by time. What is the minimum capital Ananya must bring so that her share is at least $40\%$ of the year's profit?",
  "MCQ",
  r"Fatima: $80 \times 5 + 20 \times 7 = 540$; Joseph: $130 \times 12 = 1560$ (thousand rupee-months), a total of $2100$. Ananya, in for $7$ months with $K$ thousand, needs $\frac{7K}{2100 + 7K} \geq \frac{2}{5}$, that is $7K \geq \frac{2}{3} \times 2100 = 1400$. So $K \geq 200$, a minimum of Rs. $2{,}00{,}000$.",
  r"Taking $40\%$ of the others' capital-months instead of $40\%$ of the total that includes Ananya.",
  "C04C-threshold-share-optimisation", "Inequality on a share that includes the unknown, combined with a simultaneous withdrawal.",
  correct=rs(200000),
  distractors=[(rs(240000), r"Ignores Fatima's withdrawal: $7K \geq \frac{2}{3}(960 + 1560) = 1680$."),
               (rs(280000), r"Uses $5$ months for Ananya instead of $7$: $5K \geq 1400$."),
               (rs(120000), r"Takes $40\%$ of the others' total: $7K \geq 0.4 \times 2100 = 840$.")],
  check=_c29, values=[200000, 240000, 280000, 120000], cognitive="Analysis", exams=CX)


def _c30():
    y1 = _shares(75000, [_tl([(0, 60000)]), _tl([(0, 90000)])])
    a_cap2 = 60000 + y1[0]
    a2 = _tl([(0, a_cap2)])
    h2 = _tl([(0, 90000), (6, 60000)])
    y2 = _shares(99000, [a2, h2])
    return y1[0] + y2[0]
q("C04-C-030", T, "Two-year partnership where one partner reinvests the first year's profit", "Difficult",
  "Multi-step word problem",
  r"Ananya and Harpreet start a business with Rs. $60{,}000$ and Rs. $90{,}000$. The first year's profit of Rs. $75{,}000$ is shared in the ratio of capital multiplied by time. At the start of the second year Ananya adds her entire first-year share to her capital, while Harpreet takes his share out and leaves his capital unchanged. Six months into the second year Harpreet withdraws Rs. $30{,}000$ of his capital. The second year's profit of Rs. $99{,}000$ is also shared in the ratio of capital multiplied by time. What is Ananya's total profit over the two years?",
  "MCQ",
  r"Year $1$: the ratio is $2 : 3$, so Ananya gets $30{,}000$ and her capital becomes $90{,}000$. Year $2$: Ananya $90 \times 12 = 1080$; Harpreet $90 \times 6 + 60 \times 6 = 900$ (thousand rupee-months), a ratio of $6 : 5$. Ananya gets $\frac{6}{11} \times 99{,}000 = 54{,}000$. Her total is $30{,}000 + 54{,}000 = 84{,}000$ rupees.",
  "Missing the reinvestment or the second-year withdrawal, or reporting only one year's profit.",
  "C04C-reinvested-profit-two-years", "Two accounting periods where the first year's result changes the second year's capital.",
  correct=rs(84000),
  distractors=[(rs(74000), r"Ignores the reinvestment: year $2$ ratio $720 : 900 = 4 : 5$ gives $44{,}000$, plus $30{,}000$."),
               (rs(79500), r"Ignores Harpreet's withdrawal: year $2$ ratio $1 : 1$ gives $49{,}500$, plus $30{,}000$."),
               (rs(54000), r"Reports only Ananya's second-year share.")],
  check=_c30, values=[84000, 74000, 79500, 54000], cognitive="Analysis", exams=CX)


def _c31():
    t = symbols('t', positive=True)
    arjun = 3 * 6 + F(3, 2) * 6
    ts = _pos(solve(Eq(arjun * 4, 3 * 4 * t), t))
    tt = int(ts[0])
    p = _tl([(0, 2), (tt, 4)])
    a = _tl([(0, F(3)), (6, F(3, 2))])
    f = _tl([(0, 4), (tt, 0)])
    return F(p, p + a + f)
q("C04-C-031", T, "Unknown exit time found from a share ratio, then a third partner's fraction of profit", "Difficult",
  "Multi-step word problem",
  r"Priya, Arjun and Fatima start a business with capitals in the ratio $2 : 3 : 4$. After $6$ months Arjun withdraws half of his capital. Some months after the start, Fatima withdraws her entire capital and leaves, and at that same moment Priya doubles her capital. There are no other changes, and the profit at the end of the year is shared in the ratio of capital multiplied by time. If Arjun's and Fatima's shares are in the ratio $3 : 4$, what fraction of the profit does Priya receive?",
  "MCQ",
  r"Take capitals $2, 3, 4$ units. Arjun: $3 \times 6 + 1.5 \times 6 = 27$. Fatima, in for $t$ months, has $4t$, and $27 : 4t = 3 : 4$ gives $t = 9$. Priya: $2 \times 9 + 4 \times 3 = 30$. The total is $30 + 27 + 36 = 93$, so Priya receives $\frac{30}{93} = \frac{10}{31}$.",
  "Overlooking one of the linked changes: Arjun's mid-year withdrawal or Priya's doubling when Fatima leaves.",
  "C04C-inverse-period-then-share", "Solve for an unknown exit time first, then use it to build a third partner's timeline.",
  correct=r"$\frac{10}{31}$",
  distractors=[(r"$\frac{8}{29}$", r"Ignores Priya's doubling: Priya $24$, total $24 + 27 + 36 = 87$."),
               (r"$\frac{2}{9}$", r"Ignores Arjun's withdrawal: Arjun $36$, so $t = 12$, Priya never doubles and gets $\frac{24}{108}$."),
               (r"$\frac{12}{31}$", r"Reports Fatima's fraction, $\frac{36}{93}$.")],
  check=_c31, values=[F(10, 31), F(8, 29), F(2, 9), F(12, 31)], cognitive="Analysis", exams=CX)


def _c32():
    P = 120000
    a, s = _tl([(0, 100000)]), _tl([(4, 150000)])
    ia = F(12, 100) * 100000 * F(a, 100000) / 12
    i_s = F(12, 100) * 150000 * F(s, 150000) / 12
    sal = 1500 * 12
    rest = P - ia - i_s - sal
    return ia + sal + rest * F(a, a + s)
q("C04-C-032", T, "Interest on capital for the period invested, a salary, and a capital-time split together", "Difficult",
  "Multi-step word problem",
  r"Arjun starts a business with Rs. $1{,}00{,}000$, and Sneha joins $4$ months later with Rs. $1{,}50{,}000$. Out of the year's profit, each partner is first paid simple interest at $12\%$ per annum on capital for the period the capital was in the business; Arjun, who runs the business, is also paid a salary of Rs. $1{,}500$ per month for $12$ months. The remaining profit is shared in the ratio of capital multiplied by time. If the year's profit is Rs. $1{,}20{,}000$, how much does Arjun receive in all?",
  "MCQ",
  r"Interest: Arjun $12\%$ of $1{,}00{,}000 = 12{,}000$; Sneha $12\%$ of $1{,}50{,}000$ for $\frac{8}{12}$ year $= 12{,}000$. Salary $= 18{,}000$. Remaining: $1{,}20{,}000 - 42{,}000 = 78{,}000$. Capital-months are $1200$ and $1200$ thousand, so the split is equal, $39{,}000$ each. Arjun receives $12{,}000 + 18{,}000 + 39{,}000 = 69{,}000$ rupees.",
  "Charging interest for a full year on capital that was in for only part of it.",
  "C04C-interest-on-capital", "Three payout layers, one of them time-weighted, before a capital-time split.",
  correct=rs(69000),
  distractors=[(rs(66000), r"Gives Sneha a full year's interest, $18{,}000$, leaving $72{,}000$ to split: $12{,}000 + 18{,}000 + 36{,}000$."),
               (rs(61200), r"Splits the $78{,}000$ by capitals only, $2 : 3$: $12{,}000 + 18{,}000 + 31{,}200$."),
               (rs(51000), r"Leaves out the salary from Arjun's total: $12{,}000 + 39{,}000$.")],
  check=_c32, values=[69000, 66000, 61200, 51000], cognitive="Analysis", exams=CX)


def _c33():
    # brute force over whole-rupee profits in steps of 1000
    pr, jo = 50000, 100000
    best = None
    for P in range(1000, 1000001, 1000):
        opt1 = 4000 * 12 + F(P - 48000) * F(pr, pr + jo)
        c = F(30, 100) * P
        opt2 = c + (P - c) * F(pr, pr + jo)
        if opt2 >= opt1:
            best = P
            break
    return best
q("C04-C-033", T, "Break-even profit between a fixed salary and a percentage commission for the working partner", "Difficult",
  "Conceptual/application",
  r"Priya and Joseph invest Rs. $50{,}000$ and Rs. $1{,}00{,}000$ in a business for a full year, and Priya runs it. She may choose either (i) a salary of Rs. $4{,}000$ per month for $12$ months, or (ii) a commission of $30\%$ of the total profit. Whichever she chooses is paid first out of the profit, and the rest of the profit is shared in the ratio of their capitals. What is the smallest annual profit, in rupees, for which choice (ii) gives Priya at least as much in all as choice (i)?",
  "TITA",
  r"Priya's capital share is $\frac{1}{3}$. Under (i) she gets $48{,}000 + \frac{1}{3}(P - 48{,}000)$; under (ii) she gets $0.3P + \frac{1}{3}(P - 0.3P)$. The difference (ii) minus (i) is $\frac{2}{3}(0.3P - 48{,}000)$, so (ii) is at least as good exactly when $0.3P \geq 48{,}000$, that is $P \geq 1{,}60{,}000$ rupees. Whatever she takes out first, she gets back one-third of it through her capital share, so only the two payments need comparing.",
  "Comparing the commission with her whole receipt under the salary, or not deducting the salary before division.",
  "C04C-salary-vs-commission-threshold", "Needs the insight that the capital share scales both options equally; the algebra otherwise invites slips.",
  tita_answer=160000, check=_c33,
  tita_traps=[(90000, r"Compares her whole receipt under (ii), $\frac{8}{15}P$, with the salary $48{,}000$ alone."),
              (240000, r"Does not deduct the salary before division in (i): $48{,}000 + \frac{P}{3} \leq \frac{8P}{15}$.")],
  cognitive="Analysis", exams=CX)


def _c34():
    r = _tl([(0, 90000)])
    m = _tl([(0, 40000), (6, 30000)])
    cnt = 0
    for wait in range(1, 12):
        k = _tl([(wait, 120000)])
        if m < k < r:
            cnt += 1
    return cnt
q("C04-C-034", T, "Counting joining months for which a new partner's share lies strictly between two others", "Difficult",
  "Casework/optimisation",
  r"Ravi invests Rs. $90{,}000$ in a business for the whole year. Meera invests Rs. $40{,}000$ at the start and withdraws Rs. $10{,}000$ of it after $6$ months. Kabir joins at the end of the $m$th month, where $m$ is a whole number from $1$ to $11$, with Rs. $1{,}20{,}000$ and stays till the end of the year. Profit at the end of the year is shared in the ratio of capital multiplied by time. For how many values of $m$ is Kabir's share more than Meera's but less than Ravi's?",
  "MCQ",
  r"In thousand rupee-months: Ravi $90 \times 12 = 1080$; Meera $40 \times 6 + 30 \times 6 = 420$; Kabir $120d$ with $d = 12 - m$. We need $420 < 120d < 1080$, that is $3.5 < d < 9$, so $d = 4, 5, 6, 7, 8$. That gives $5$ values of $m$ (from $4$ to $8$).",
  "Missing the withdrawal or treating the strict inequalities as inclusive.",
  "C04C-joining-month-casework", "Double inequality on an integer period with a mid-year change for one partner.",
  correct=r"$5$",
  distractors=[(r"$4$", r"Ignores Meera's withdrawal: $480 < 120d < 1080$ gives $d = 5, 6, 7, 8$."),
               (r"$6$", r"Allows equality with Ravi: $3.5 < d \leq 9$ gives $d = 4$ to $9$."),
               (r"$8$", r"Applies only the lower bound: $d = 4$ to $11$.")],
  check=_c34, values=[5, 4, 6, 8], cognitive="Analysis", exams=CX)


def _c35():
    P = symbols('P', positive=True)
    jo, pr = _tl([(0, 80000)]), _tl([(2, 120000)])
    com = F(20, 100) * P
    rest = P - com
    jtot = com + rest * F(jo, jo + pr)
    ptot = rest * F(pr, jo + pr)
    return _pos(solve(Eq(jtot - ptot, 8000), P))[0]
q("C04-C-035", T, "Total profit from the gap between a commissioned partner and a larger investor", "Difficult",
  "Inverse/parameter",
  r"Joseph starts a business with Rs. $80{,}000$, and Priya joins $2$ months later with Rs. $1{,}20{,}000$. Joseph manages the business and first receives a commission of $20\%$ of the total profit; the rest is shared in the ratio of capital multiplied by time. At the end of the year Joseph's total receipt exceeds Priya's by Rs. $8{,}000$. What is the year's total profit?",
  "MCQ",
  r"Capital-months: Joseph $80 \times 12 = 960$, Priya $120 \times 10 = 1200$, a ratio of $4 : 5$. With profit $P$, Joseph gets $0.2P + \frac{4}{9}(0.8P)$ and Priya gets $\frac{5}{9}(0.8P)$. The gap is $0.2P - \frac{1}{9}(0.8P) = \frac{1.8P - 0.8P}{9} = \frac{P}{9} = 8{,}000$, so $P = 72{,}000$ rupees.",
  "Taking the capital-share gap as a fraction of the whole profit instead of the profit left after commission.",
  "C04C-working-partner-inverse", "Gap between two receipts with opposing effects; the remainder base is easy to mistake.",
  correct=rs(72000),
  distractors=[(rs(90000), r"Takes the capital-share gap on the whole profit: $0.2P - \frac{P}{9} = 8{,}000$."),
               (rs(40000), r"Sets the commission alone equal to the gap: $0.2P = 8{,}000$."),
               (rs(200000), r"Uses capitals only, $2 : 3$: $0.2P + 0.32P - 0.48P = 0.04P = 8{,}000$.")],
  check=_c35, values=[72000, 90000, 40000, 200000], cognitive="Analysis", exams=CX)
