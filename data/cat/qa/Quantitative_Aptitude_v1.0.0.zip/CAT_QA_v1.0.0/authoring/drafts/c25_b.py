import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

from itertools import combinations, product
from math import comb

T = "Selections and distributions"
CX = ("CAT", "XAT")


def _comps(total, parts, lo=0, hi=None):
    """All ordered tuples of `parts` non-negative integers summing to total, each in [lo, hi]."""
    hi = total if hi is None else hi
    out = []
    for t in product(range(lo, hi + 1), repeat=parts):
        if sum(t) == total:
            out.append(t)
    return out


def _set_partitions(items):
    items = list(items)
    if not items:
        yield []
        return
    first, rest = items[0], items[1:]
    for p in _set_partitions(rest):
        for i in range(len(p)):
            yield p[:i] + [[first] + p[i]] + p[i + 1:]
        yield [[first]] + p


# ---------------------------------------------------------------- EASY

def _e1():
    members = list(range(10)); ravi, meera = 0, 1
    return sum(1 for c in combinations(members, 4) if ravi in c and meera not in c)
q("C25-B-001", T, "Committee that must include one named person and exclude another", "Easy",
  "Single-step computation",
  r"A residents' association has $10$ members, among them Ravi and Meera. A $4$-member committee is to be formed that includes Ravi but does not include Meera. In how many ways can the committee be formed?",
  "MCQ",
  r"Put Ravi in and remove Meera from consideration. The remaining $3$ seats are filled from the other $8$ members, so the count is $\binom{8}{3} = 56$.",
  "Handling only one of the two conditions, or removing both named people from the pool.",
  "C25B-committee-named-members", "One restriction of each kind (must include, must exclude) applied to a single combination.",
  correct=r"$56$",
  distractors=[(r"$84$", r"Includes Ravi but leaves Meera in the pool: $\binom{9}{3} = 84$."),
               (r"$126$", r"Excludes Meera but does not force Ravi in: $\binom{9}{4} = 126$."),
               (r"$70$", r"Removes both Ravi and Meera from the pool and chooses all $4$ from the other $8$: $\binom{8}{4} = 70$.")],
  check=_e1, values=[56, 84, 126, 70], cognitive="Application")


def _e2():
    return sum(1 for r in range(0, 7) for c in combinations(range(6), r) if 1 <= len(c) <= 3)
q("C25-B-002", T, "Subsets of toppings with a lower and an upper limit on size", "Easy",
  "Single-step computation",
  r"A pizza outlet offers $6$ different toppings. A customer must choose at least $1$ and at most $3$ different toppings for a pizza; the order in which toppings are chosen does not matter. How many different topping combinations are possible? Type the number of combinations.",
  "TITA",
  r"Add the selections of each permitted size: $\binom{6}{1} + \binom{6}{2} + \binom{6}{3} = 6 + 15 + 20 = 41$.",
  "Using $2^6 - 1$ for every non-empty selection and ignoring the upper limit.",
  "C25B-subsets-size-limits", "Sum of three binomial coefficients; the only trap is the size limit.",
  tita_answer=41, check=_e2,
  tita_traps=[(63, r"Uses $2^6 - 1 = 63$, ignoring the limit of at most $3$ toppings."),
              (42, r"Counts the plain pizza with no topping as well: $1 + 41 = 42$.")],
  cognitive="Application")


def _e3():
    n = 0
    for a in range(5):
        for o in range(4):
            for m in range(3):
                if a + o + m >= 1:
                    n += 1
    return n
q("C25-B-003", T, "Selections from identical items of several kinds, at least one item", "Easy",
  "Conceptual/application",
  r"A fruit basket contains $4$ apples, $3$ oranges and $2$ mangoes. Fruits of the same kind are identical. In how many ways can Kabir take at least one fruit from the basket?",
  "MCQ",
  r"Kabir decides how many apples ($0$ to $4$, so $5$ choices), how many oranges ($4$ choices) and how many mangoes ($3$ choices). That gives $5 \times 4 \times 3 = 60$ selections, one of which is taking nothing, so the answer is $60 - 1 = 59$.",
  "Treating identical fruits as distinct, or not removing the empty selection.",
  "C25B-identical-items-selection", "Needs the insight that only the number of each kind matters.",
  correct=r"$59$",
  distractors=[(r"$60$", r"Counts the selection in which no fruit is taken."),
               (r"$511$", r"Treats all $9$ fruits as distinct: $2^9 - 1 = 511$."),
               (r"$24$", r"Allows only $1$ to $4$ apples, $1$ to $3$ oranges and $1$ to $2$ mangoes, giving $4 \times 3 \times 2 = 24$.")],
  check=_e3, values=[59, 60, 511, 24], cognitive="Understanding")


def _e4():
    return len(_comps(10, 3, lo=2))
q("C25-B-004", T, "Identical objects to distinct people with a minimum for each", "Easy",
  "Single-step computation",
  r"Ten identical chocolates are to be distributed among three children, Arjun, Fatima and Sneha, so that each child gets at least $2$ chocolates and all ten are given out. In how many ways can this be done? Type the number of ways.",
  "TITA",
  r"First give $2$ chocolates to each child. The remaining $4$ identical chocolates go to $3$ children with no restriction, which can be done in $\binom{4+2}{2} = \binom{6}{2} = 15$ ways.",
  "Applying the minimum of $1$ per child, or no minimum at all.",
  "C25B-identical-distinct-min", "One reduction step followed by the standard identical-objects formula.",
  tita_answer=15, check=_e4,
  tita_traps=[(66, r"Ignores the minimum: $\binom{12}{2} = 66$."),
              (36, r"Uses a minimum of $1$ each: $\binom{9}{2} = 36$.")],
  cognitive="Application")


def _e5():
    return sum(1 for _ in product(range(3), repeat=5))
q("C25-B-005", T, "Distinct objects into distinct boxes, no restriction", "Easy",
  "Conceptual/application",
  r"Five different job applications are to be forwarded to three departments of a company, Finance, Sales and Operations. Each application goes to exactly one department, and a department may receive any number of applications, including none. In how many ways can the applications be forwarded?",
  "MCQ",
  r"Each application independently has $3$ choices of department, so the count is $3^5 = 243$.",
  "Raising the wrong number to the wrong power, or treating the applications as identical.",
  "C25B-distinct-into-distinct-free", "Single multiplication-principle idea; the trap is which number is the base.",
  correct=r"$243$",
  distractors=[(r"$125$", r"Lets each department pick one of $5$ applications: $5^3 = 125$."),
               (r"$21$", r"Treats the applications as identical: $\binom{5+2}{2} = 21$."),
               (r"$60$", r"Sends exactly one application to each department: $5 \times 4 \times 3 = 60$.")],
  check=_e5, values=[243, 125, 21, 60], cognitive="Understanding")


def _e6():
    people = ["M"] * 5 + ["W"] * 4
    return sum(1 for c in combinations(range(9), 3) if any(people[i] == "W" for i in c))
q("C25-B-006", T, "Committee with at least one woman, complement count", "Easy",
  "Multi-step word problem",
  r"A committee of $3$ is to be chosen from $5$ men and $4$ women. In how many ways can it be chosen if it must contain at least one woman?",
  "MCQ",
  r"All committees: $\binom{9}{3} = 84$. Committees with no woman: $\binom{5}{3} = 10$. So the answer is $84 - 10 = 74$.",
  "Fixing one woman first and then choosing the rest freely, which counts some committees more than once.",
  "C25B-committee-gender-mix", "Complement of a single case; the trap is double counting.",
  correct=r"$74$",
  distractors=[(r"$112$", r"Picks one woman and then any $2$ of the remaining $8$: $4 \times \binom{8}{2} = 112$, which counts committees with two or more women more than once."),
               (r"$40$", r"Counts only committees with exactly one woman: $4 \times \binom{5}{2} = 40$."),
               (r"$84$", r"Ignores the condition and counts every committee of $3$.")],
  check=_e6, values=[74, 112, 40, 84], cognitive="Application")


def _e7():
    shirts = ["R"] * 4 + ["B"] * 3 + ["G"] * 5
    return sum(1 for i, j in combinations(range(12), 2) if shirts[i] != shirts[j])
q("C25-B-007", T, "Choosing two items that must come from different groups", "Easy",
  "Multi-step word problem",
  r"Harpreet's wardrobe has $4$ different red shirts, $3$ different blue shirts and $5$ different green shirts. She packs exactly $2$ shirts for a trip, and the two shirts must be of different colours. In how many ways can she choose the $2$ shirts? Type the number of ways.",
  "TITA",
  r"Add the three colour pairings: red with blue $4 \times 3 = 12$, red with green $4 \times 5 = 20$, blue with green $3 \times 5 = 15$, total $47$. Equivalently, all pairs $\binom{12}{2} = 66$ minus same-colour pairs $\binom{4}{2} + \binom{3}{2} + \binom{5}{2} = 6 + 3 + 10 = 19$ gives $47$.",
  "Multiplying all three group sizes together, or forgetting to remove same-colour pairs.",
  "C25B-pair-different-groups", "One idea: sum over colour pairings, or a single complement.",
  tita_answer=47, check=_e7,
  tita_traps=[(66, r"Ignores the colour condition: $\binom{12}{2} = 66$."),
              (60, r"Multiplies all three counts, $4 \times 3 \times 5 = 60$, which picks one shirt of each colour (three shirts)."),
              (19, r"Reports the number of same-colour pairs.")],
  cognitive="Application")


def _e8():
    people = ["M"] * 6 + ["W"] * 4
    return sum(1 for c in combinations(range(10), 5) if sum(people[i] == "W" for i in c) == 2)
q("C25-B-008", T, "Committee with an exact number of women", "Easy",
  "Single-step computation",
  r"A committee of $5$ is to be selected from $6$ men and $4$ women. In how many ways can this be done if the committee must have exactly $2$ women?",
  "MCQ",
  r"Choose the $2$ women in $\binom{4}{2} = 6$ ways and the $3$ men in $\binom{6}{3} = 20$ ways. Total $6 \times 20 = 120$.",
  "Adding the two choices, ignoring the composition, or reading 'exactly' as 'at least'.",
  "C25B-committee-gender-mix", "Product of two binomial coefficients with one trap.",
  correct=r"$120$",
  distractors=[(r"$26$", r"Adds the two counts: $6 + 20 = 26$."),
               (r"$252$", r"Ignores the composition: $\binom{10}{5} = 252$."),
               (r"$186$", r"Reads exactly $2$ women as at least $2$: $120 + 4 \times 15 + 1 \times 6 = 186$.")],
  check=_e8, values=[120, 26, 252, 186], cognitive="Application")


def _e9():
    return sum(1 for c in combinations(range(6), 3))
q("C25-B-009", T, "Dividing distinct objects equally between two named people", "Easy",
  "Conceptual/application",
  r"Six different books are to be divided between Arjun and Fatima so that each of them gets exactly $3$ books. In how many ways can this be done?",
  "MCQ",
  r"Choose Arjun's $3$ books in $\binom{6}{3} = 20$ ways; Fatima gets the rest. Since the two people are distinguishable, there is no further division, and the answer is $20$.",
  "Dividing by $2$ as if the two piles were unlabelled, or using arrangements.",
  "C25B-distinct-groups-sizes", "One choice; the trap is whether to divide by $2!$.",
  correct=r"$20$",
  distractors=[(r"$10$", r"Divides by $2!$ as if the two piles were not assigned to particular people."),
               (r"$40$", r"Multiplies by $2$ for who gets which pile, although choosing Arjun's books already decides that."),
               (r"$120$", r"Uses ordered choices for Arjun: $6 \times 5 \times 4 = 120$.")],
  check=_e9, values=[20, 10, 40, 120], cognitive="Understanding")


def _e10():
    n = 0
    for team in combinations(range(7), 4):
        for cap in team:
            n += 1
    return n
q("C25-B-010", T, "Selecting a team and then a captain from within it", "Easy",
  "Multi-step word problem",
  r"From $7$ volunteers, a team of $4$ is to be selected, and then one member of the team is to be named captain. In how many ways can this be done?",
  "MCQ",
  r"Choose the team in $\binom{7}{4} = 35$ ways and the captain from its $4$ members in $4$ ways: $35 \times 4 = 140$. Equivalently, choose the captain in $7$ ways and the other three in $\binom{6}{3} = 20$ ways: $140$.",
  "Ignoring the captain, picking the captain from all volunteers, or ordering all four members.",
  "C25B-selection-with-roles", "Two-stage selection; trap is the pool for the captain.",
  correct=r"$140$",
  distractors=[(r"$35$", r"Counts only the team and ignores the choice of captain."),
               (r"$245$", r"Picks the team and then the captain from all $7$ volunteers: $35 \times 7 = 245$."),
               (r"$840$", r"Arranges all four members in order: $7 \times 6 \times 5 \times 4 = 840$.")],
  check=_e10, values=[140, 35, 245, 840], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM

def _m1():
    J, P = 0, 1
    return sum(1 for c in combinations(range(12), 5) if not (J in c and P in c))
q("C25-B-011", T, "Committee in which two named people refuse to serve together", "Medium",
  "Multi-step word problem",
  r"A committee of $5$ is to be formed from $12$ teachers, among them Joseph and Priya. Joseph and Priya refuse to serve together on the committee, though either may serve without the other. In how many ways can the committee be formed?",
  "MCQ",
  r"All committees: $\binom{12}{5} = 792$. Committees containing both Joseph and Priya: fill the other $3$ seats from $10$, $\binom{10}{3} = 120$. Answer $792 - 120 = 672$. As a check: neither $\binom{10}{5} = 252$, exactly one $2 \times \binom{10}{4} = 420$, total $672$.",
  "Missing one of the cases, or reporting the committees that are forbidden.",
  "C25B-committee-named-members", "Complement or three-case split; easy to drop a case.",
  correct=r"$672$",
  distractors=[(r"$462$", r"Counts committees with neither ($252$) and with Joseph only ($210$), but not those with Priya only."),
               (r"$252$", r"Keeps only committees containing neither of them: $\binom{10}{5} = 252$."),
               (r"$120$", r"Reports the number of committees containing both of them.")],
  check=_m1, values=[672, 462, 252, 120], cognitive="Application")


def _m2():
    people = ["M"] * 6 + ["W"] * 5
    n = 0
    for c in combinations(range(11), 5):
        w = sum(people[i] == "W" for i in c)
        if w >= 2 and 5 - w >= 2:
            n += 1
    return n
q("C25-B-012", T, "Committee with at least two of each gender, casework", "Medium",
  "Casework/optimisation",
  r"A panel of $5$ is to be chosen from $6$ men and $5$ women so that it has at least $2$ men and at least $2$ women. In how many ways can the panel be chosen? Type the number of ways.",
  "TITA",
  r"The only possible splits are $3$ men with $2$ women, or $2$ men with $3$ women. That gives $\binom{6}{3}\binom{5}{2} + \binom{6}{2}\binom{5}{3} = 20 \times 10 + 15 \times 10 = 350$.",
  "Fixing two men and two women and then choosing the fifth member from the rest, which double counts.",
  "C25B-committee-gender-mix", "Two cases must be identified and added; tempting overcount route.",
  tita_answer=350, check=_m2,
  tita_traps=[(1050, r"Picks $2$ men and $2$ women, then any $1$ of the remaining $7$: $15 \times 10 \times 7 = 1050$, counting each panel more than once."),
              (462, r"Ignores the condition: $\binom{11}{5} = 462$."),
              (200, r"Counts only the split of $3$ men and $2$ women.")],
  cognitive="Analysis")


def _m3():
    books = ["M"] * 4 + ["P"] * 3 + ["C"] * 2
    return sum(1 for c in combinations(range(9), 4) if {books[i] for i in c} == {"M", "P", "C"})
q("C25-B-013", T, "Selection with at least one item from each of three groups", "Medium",
  "Casework/optimisation",
  r"A shelf holds $4$ different mathematics books, $3$ different physics books and $2$ different chemistry books. Ananya wants to pick $4$ books that include at least one book of each subject. In how many ways can she pick them?",
  "MCQ",
  r"One subject must supply $2$ books and the other two supply $1$ each. Mathematics doubled: $\binom{4}{2} \times 3 \times 2 = 36$. Physics doubled: $4 \times \binom{3}{2} \times 2 = 24$. Chemistry doubled: $4 \times 3 \times \binom{2}{2} = 12$. Total $36 + 24 + 12 = 72$.",
  "Picking one book of each subject first and then any fourth book, which double counts.",
  "C25B-each-group-represented", "Requires splitting into three cases by which subject repeats.",
  correct=r"$72$",
  distractors=[(r"$144$", r"Picks one of each subject ($24$ ways) and then any of the remaining $6$ books: $24 \times 6 = 144$, counting every selection twice."),
               (r"$126$", r"Ignores the condition: $\binom{9}{4} = 126$."),
               (r"$60$", r"Considers only the cases in which mathematics or physics supplies two books: $36 + 24 = 60$.")],
  check=_m3, values=[72, 144, 126, 60], cognitive="Application")


def _m4():
    return sum(1 for t in _comps(10, 4) if sum(1 for x in t if x == 0) == 1)
q("C25-B-014", T, "Identical objects into distinct boxes with exactly one box empty", "Medium",
  "Conceptual/application",
  r"Ten identical gift hampers are to be delivered to four branch offices of a company, at Thane, Vashi, Kalyan and Panvel. All ten hampers are delivered, and exactly one of the four offices receives no hamper (each of the other three receives at least one). In how many ways can the hampers be distributed? Type the number of ways.",
  "TITA",
  r"Choose the office that gets nothing in $4$ ways. The $10$ hampers then go to the other $3$ offices with at least one each: $\binom{10-1}{3-1} = \binom{9}{2} = 36$ ways. Total $4 \times 36 = 144$.",
  "Forgetting to choose which office is empty, or counting distributions in which one or more offices are empty.",
  "C25B-identical-exact-empty", "Two-stage count: pick the empty box, then a positive distribution; the 'at least one empty' complement is a tempting wrong route.",
  tita_answer=144, check=_m4,
  tita_traps=[(36, r"Fixes the empty office and does not multiply by the $4$ choices of which office it is."),
              (202, r"Counts distributions with at least one office empty: $\binom{13}{3} - \binom{9}{3} = 286 - 84 = 202$."),
              (264, r"Picks the empty office but lets the other three also receive none: $4 \times \binom{12}{2} = 264$.")],
  cognitive="Application")


def _m5():
    return sum(1 for f in product(range(3), repeat=5) if len(set(f)) == 3)
q("C25-B-015", T, "Distinct objects to distinct people, nobody left out", "Medium",
  "Multi-step word problem",
  r"Five different tasks are to be assigned to three employees, Arjun, Sneha and Joseph. Each task goes to exactly one employee, and each employee must get at least one task. In how many ways can the tasks be assigned?",
  "MCQ",
  r"Without restriction there are $3^5 = 243$ assignments. Those missing a given employee: $2^5 = 32$, for each of $3$ employees; those missing two given employees: $1$, for each of $3$ pairs. By inclusion-exclusion, $243 - 3 \times 32 + 3 \times 1 = 150$.",
  "Pre-assigning one task to each employee and then assigning the rest freely, or stopping inclusion-exclusion early.",
  "C25B-distinct-onto", "Inclusion-exclusion over three people, with a common overcount route.",
  correct=r"$150$",
  distractors=[(r"$540$", r"Gives each employee one task first ($\binom{5}{3} \times 3! = 60$), then assigns the other two freely ($3^2 = 9$): $540$, which overcounts."),
               (r"$147$", r"Subtracts $3 \times 32$ but does not add back the $3$ assignments that give all tasks to one employee."),
               (r"$25$", r"Counts ways to split the tasks into three unnamed non-empty groups, ignoring which employee gets which group.")],
  check=_m5, values=[150, 540, 147, 25], cognitive="Application")


def _m6():
    n = 0
    def rec(rem):
        nonlocal n
        if not rem:
            n += 1
            return
        first, rest = rem[0], rem[1:]
        for others in combinations(rest, 2):
            rec([x for x in rest if x not in others])
    rec(list(range(12)))
    return n
q("C25-B-016", T, "Dividing distinct people into equal unlabelled groups", "Medium",
  "Conceptual/application",
  r"Twelve students are to be split into four study groups of $3$ students each. The groups have no names or roles; two splits are the same if every student has the same two group-mates in both. In how many ways can the students be split? Type the number of ways.",
  "TITA",
  r"If the groups were labelled, the count would be $\frac{12!}{(3!)^4} = 369600$. The four groups are interchangeable, so divide by $4! = 24$: $\frac{369600}{24} = 15400$. (Fast route: the student with the smallest roll number picks $2$ partners in $\binom{11}{2} = 55$ ways, the next unplaced student in $\binom{8}{2} = 28$, then $\binom{5}{2} = 10$, then $1$: $55 \times 28 \times 10 = 15400$.)",
  "Not dividing by the number of orders of the equal groups.",
  "C25B-distinct-groups-sizes", "Needs the idea of dividing by $4!$ for interchangeable equal groups.",
  tita_answer=15400, check=_m6,
  tita_traps=[(369600, r"Treats the groups as labelled: $\frac{12!}{(3!)^4} = 369600$."),
              (61600, r"Divides by $3!$ in place of $4!$: $\frac{369600}{6} = 61600$.")],
  cognitive="Understanding")


def _m7():
    return sum(1 for c in combinations(range(10), 3) if all(c[i + 1] - c[i] >= 2 for i in range(2)))
q("C25-B-017", T, "Choosing items from a row with no two adjacent", "Medium",
  "Conceptual/application",
  r"Ten flower pots stand in a straight row. A gardener wants to plant saplings in exactly $3$ of the pots so that no two chosen pots are next to each other. In how many ways can she choose the $3$ pots?",
  "MCQ",
  r"Place the $7$ unchosen pots in a row; they create $8$ gaps (including the two ends). Putting each chosen pot in a different gap guarantees no two are adjacent, so the count is $\binom{8}{3} = 56$.",
  "Ignoring the condition, or subtracting adjacent pairs without correcting for three in a row.",
  "C25B-no-two-adjacent", "Gap method insight; inclusion-exclusion route has a trap.",
  correct=r"$56$",
  distractors=[(r"$120$", r"Ignores the condition: $\binom{10}{3} = 120$."),
               (r"$48$", r"Subtracts $9 \times 8 = 72$ selections containing an adjacent pair from $120$, but the $8$ runs of three pots were subtracted twice and are not added back."),
               (r"$35$", r"Uses $\binom{7}{3}$, choosing the saplings' pots from the unchosen pots instead of from the gaps.")],
  check=_m7, values=[56, 120, 48, 35], cognitive="Analysis")


def _m8():
    return len([t for t in _comps(6, 3) if t[0] <= 5 and t[1] <= 4 and t[2] <= 3])
q("C25-B-018", T, "Selecting from limited stocks of identical items", "Medium",
  "Casework/optimisation",
  r"A box contains $5$ red, $4$ blue and $3$ green marbles; marbles of the same colour are identical. Priya takes exactly $6$ marbles from the box. How many different selections (by the number of marbles of each colour) can she make? Type the number of selections.",
  "TITA",
  r"With unlimited stock, the number of colour counts adding to $6$ is $\binom{8}{2} = 28$. Remove those that exceed the stock: $6$ red is $1$ case; $5$ or more blue leaves $1$ or fewer for the others, $\binom{3}{2} = 3$ cases; $4$ or more green leaves $2$ or fewer, $\binom{4}{2} = 6$ cases. No two excesses can happen together. Answer $28 - 1 - 3 - 6 = 18$.",
  "Ignoring the stock limits, or treating marbles as distinct.",
  "C25B-identical-bounded", "Three different caps, each needing its own correction.",
  tita_answer=18, check=_m8,
  tita_traps=[(28, r"Ignores the limited stock: $\binom{8}{2} = 28$."),
              (924, r"Treats the $12$ marbles as distinct: $\binom{12}{6} = 924$."),
              (22, r"Removes only the cases with too many green marbles: $28 - 6 = 22$.")],
  cognitive="Application")


def _m9():
    n = 0
    for p in _set_partitions(range(5)):
        if len(p) == 2:
            n += 1
    return n
q("C25-B-019", T, "Distinct objects into identical containers, none empty", "Medium",
  "Conceptual/application",
  r"Fatima has $5$ different gifts to pack into $2$ identical carry bags. Every gift goes into a bag and neither bag may be empty; the bags themselves cannot be told apart. In how many ways can she pack the gifts?",
  "MCQ",
  r"If the bags were distinguishable, each gift would have $2$ choices, $2^5 = 32$, minus the $2$ cases with an empty bag, giving $30$. Since the bags are identical, each split is counted twice, so the answer is $\frac{30}{2} = 15$.",
  "Treating identical bags as distinct, or not removing the empty-bag cases before halving.",
  "C25B-distinct-into-identical", "Requires both removing empty cases and halving for identical bags.",
  correct=r"$15$",
  distractors=[(r"$30$", r"Treats the bags as distinguishable: $2^5 - 2 = 30$."),
               (r"$32$", r"Lets each gift choose a bag, with no further adjustment: $2^5 = 32$."),
               (r"$16$", r"Halves $2^5$ without first removing the cases with an empty bag.")],
  check=_m9, values=[15, 30, 32, 16], cognitive="Understanding")


def _m10():
    parts = set()
    for t in _comps(8, 3, lo=1):
        parts.add(tuple(sorted(t)))
    return len(parts)
q("C25-B-020", T, "Identical objects into identical boxes, none empty", "Medium",
  "Casework/optimisation",
  r"Eight identical sweets are to be packed into $3$ identical boxes so that no box is empty and all sweets are used. Only the numbers of sweets in the boxes matter, since the boxes cannot be told apart. In how many ways can this be done?",
  "MCQ",
  r"List the ways of writing $8$ as a sum of $3$ positive parts in non-increasing order: $6+1+1$, $5+2+1$, $4+3+1$, $4+2+2$, $3+3+2$. There are $5$ ways.",
  "Using the formula for distinct boxes, or allowing empty boxes.",
  "C25B-identical-into-identical", "No formula; systematic listing of partitions is needed.",
  correct=r"$5$",
  distractors=[(r"$21$", r"Treats the boxes as distinct: $\binom{7}{2} = 21$."),
               (r"$10$", r"Allows empty boxes, adding $8$, $7+1$, $6+2$, $5+3$ and $4+4$ to the list."),
               (r"$45$", r"Treats the boxes as distinct and allows empty boxes: $\binom{10}{2} = 45$.")],
  check=_m10, values=[5, 21, 10, 45], cognitive="Analysis")


def _m11():
    n = 0
    for c in combinations(range(9), 5):
        for p, s in product(c, c):
            if p != s:
                n += 1
    return n
q("C25-B-021", T, "Committee followed by two different office-bearers from within it", "Medium",
  "Multi-step word problem",
  r"A society of $9$ members elects a committee of $5$. From the committee, a president and a secretary (two different people) are then chosen. In how many ways can the committee and its two office-bearers be chosen?",
  "MCQ",
  r"Choose the committee in $\binom{9}{5} = 126$ ways, then the president in $5$ ways and the secretary in $4$ ways: $126 \times 20 = 2520$. Equivalently, president and secretary from the society in $9 \times 8 = 72$ ways and the other $3$ members in $\binom{7}{3} = 35$ ways: $72 \times 35 = 2520$.",
  "Treating the two posts as interchangeable, or ignoring them.",
  "C25B-selection-with-roles", "Selection combined with two distinct posts; two routes must agree.",
  correct=r"$2520$",
  distractors=[(r"$1260$", r"Picks the two office-bearers as an unordered pair: $126 \times \binom{5}{2} = 1260$."),
               (r"$126$", r"Counts only the committee."),
               (r"$15120$", r"Arranges all $5$ committee members in order: $9 \times 8 \times 7 \times 6 \times 5 = 15120$.")],
  check=_m11, values=[2520, 1260, 126, 15120], cognitive="Application")


def _m12():
    men = 7
    for n in range(2, 40):
        cnt = sum(1 for _ in combinations(range(n), 2)) * sum(1 for _ in combinations(range(men), 2))
        if cnt == 315:
            return n
q("C25-B-022", T, "Finding the size of a group from a committee count", "Medium",
  "Inverse/parameter",
  r"A housing society's cultural team has $7$ men and some women. The number of ways to form a $4$-member committee with exactly $2$ men and $2$ women is $315$. How many women are in the team? Type the number of women.",
  "TITA",
  r"The men can be chosen in $\binom{7}{2} = 21$ ways, so $\binom{w}{2} = \frac{315}{21} = 15$. Then $\frac{w(w-1)}{2} = 15$, so $w(w-1) = 30$ and $w = 6$.",
  r"Stopping at $\binom{w}{2} = 15$ and reporting $15$.",
  "C25B-inverse-committee-count", "Reverse of a committee count; needs solving a small quadratic.",
  tita_answer=6, check=_m12,
  tita_traps=[(15, r"Reports $\binom{w}{2} = 15$ instead of solving for $w$."),
              (30, r"Reports $w(w-1) = 30$ instead of $w$.")],
  cognitive="Application")


def _m13():
    kinds = ["N"] * 5 + ["B"] * 4 + ["C"] * 3
    n = 0
    for r in range(1, 13):
        for c in combinations(range(12), r):
            ks = [kinds[i] for i in c]
            if "N" in ks and "B" in ks:
                n += 1
    return n
q("C25-B-023", T, "Selections of any size with at least one item from each of two groups, a third group optional", "Medium",
  "Conceptual/application",
  r"A library display has $5$ different novels, $4$ different biographies and $3$ different comics. Kabir may borrow any number of these books, but he must borrow at least one novel and at least one biography; borrowing comics is optional. In how many ways can he choose the books to borrow?",
  "MCQ",
  r"Each group is decided independently. Novels: any non-empty subset, $2^5 - 1 = 31$ ways. Biographies: $2^4 - 1 = 15$ ways. Comics: any subset including none, $2^3 = 8$ ways. Total $31 \times 15 \times 8 = 3720$.",
  "Treating the optional group as compulsory or as absent, or ignoring the conditions altogether.",
  "C25B-free-size-each-group", "Two ideas: independent subset choices per group and different handling of compulsory and optional groups.",
  correct=r"$3720$",
  distractors=[(r"$4095$", r"Ignores both conditions and counts every non-empty selection of the $12$ books: $2^{12} - 1 = 4095$."),
               (r"$465$", r"Leaves the comics out of the count altogether: $31 \times 15 = 465$."),
               (r"$3255$", r"Requires at least one comic as well: $31 \times 15 \times 7 = 3255$.")],
  check=_m13, values=[3720, 4095, 465, 3255], cognitive="Application")


def _m14():
    seen = set()
    for r in range(4):
        for b in range(3):
            for k in range(4):
                for sub in combinations(["green", "black", "pink"], k):
                    if r + b + k == 4:
                        seen.add((r, b, sub))
    return len(seen)
q("C25-B-024", T, "Selection from a mix of identical and distinct items", "Difficult",
  "Casework/optimisation",
  r"Meera's pen stand holds $3$ identical red pens, $2$ identical blue pens, and one each of green, black and pink pens. In how many ways can she pick exactly $4$ pens from the stand?",
  "MCQ",
  r"Split by the number $k$ of single-colour pens (green, black, pink) taken. $k = 0$: red and blue add to $4$, so $(3,1)$ or $(2,2)$: $2$ ways. $k = 1$: $3$ choices of pen, red and blue add to $3$: $(3,0), (2,1), (1,2)$, giving $3 \times 3 = 9$. $k = 2$: $3$ choices, red and blue add to $2$: $(2,0), (1,1), (0,2)$, giving $9$. $k = 3$: $1$ choice, one red or one blue: $2$. Total $2 + 9 + 9 + 2 = 22$.",
  "Treating all pens as distinct, ignoring the limited number of red and blue pens, or missing a case.",
  "C25B-identical-items-selection", "Four-way casework on the distinct pens, each case needing its own count of identical red and blue pens under two stock limits; easy to drop or overcount a case, about 3 minutes.",
  correct=r"$22$",
  distractors=[(r"$70$", r"Treats all $8$ pens as distinct: $\binom{8}{4} = 70$."),
               (r"$28$", r"Allows unlimited red and blue pens, so the cases give $5 + 12 + 9 + 2 = 28$."),
               (r"$20$", r"Leaves out the case in which all three single pens are taken.")],
  check=_m14, values=[22, 70, 28, 20], cognitive="Analysis", exams=CX)


def _m15():
    return len([t for t in _comps(15, 3, lo=1) if all(x % 2 == 1 for x in t)])
q("C25-B-025", T, "Identical objects to distinct people, each getting an odd number", "Medium",
  "Conceptual/application",
  r"Fifteen identical one-rupee coins are shared among three children, Ravi, Sneha and Harpreet, so that every coin is given out and each child receives an odd number of coins. In how many ways can the coins be shared?",
  "MCQ",
  r"Write each share as $2y_i + 1$ with $y_i \ge 0$. Then $2(y_1 + y_2 + y_3) + 3 = 15$, so $y_1 + y_2 + y_3 = 6$. The number of ways is $\binom{6+2}{2} = 28$.",
  "Ignoring the odd condition, using only 'at least one', or using the wrong binomial coefficient.",
  "C25B-identical-distinct-min", "Needs a substitution to turn a parity condition into a plain distribution.",
  correct=r"$28$",
  distractors=[(r"$136$", r"Ignores the odd condition: $\binom{17}{2} = 136$."),
               (r"$91$", r"Applies only 'at least one coin each': $\binom{14}{2} = 91$."),
               (r"$56$", r"Reaches $y_1 + y_2 + y_3 = 6$ but uses $\binom{8}{3} = 56$ in place of $\binom{8}{2}$.")],
  check=_m15, values=[28, 136, 91, 56], cognitive="Application")


def _m16():
    return len(_comps(8, 4, lo=1))
q("C25-B-026", T, "Buying items of several unlimited varieties, at least one of each", "Medium",
  "Multi-step word problem",
  r"A sweet shop sells $4$ varieties of laddoo, with plenty of each variety, and laddoos of the same variety are identical. Joseph buys $8$ laddoos and wants at least one of each variety. How many different purchases can he make?",
  "MCQ",
  r"Take one laddoo of each variety first. The other $4$ laddoos are spread over $4$ varieties with no restriction: $\binom{4+3}{3} = \binom{7}{3} = 35$.",
  "Ignoring the 'at least one' condition, or misusing the formula.",
  "C25B-identical-distinct-min", "Recognising a purchase as a distribution of identical items into varieties.",
  correct=r"$35$",
  distractors=[(r"$165$", r"Ignores the 'at least one of each' condition: $\binom{11}{3} = 165$."),
               (r"$56$", r"Uses $\binom{8}{3}$, that is $\binom{n}{k-1}$ in place of $\binom{n-1}{k-1}$."),
               (r"$256$", r"After one of each, chooses a variety for each of the other $4$ laddoos in order: $4^4 = 256$.")],
  check=_m16, values=[35, 165, 56, 256], cognitive="Application", flags="")


# ---------------------------------------------------------------- DIFFICULT

def _d1():
    return len(_comps(20, 4, lo=2, hi=7))
q("C25-B-027", T, "Identical objects with both a lower and an upper limit per person", "Difficult",
  "Casework/optimisation",
  r"Twenty identical chocolates are to be shared among four children so that every chocolate is given out and each child gets at least $2$ and at most $7$ chocolates. In how many ways can this be done? Type the number of ways.",
  "TITA",
  r"Give $2$ to each child first; then each child receives an extra $e_i$ with $0 \le e_i \le 5$ and $e_1 + e_2 + e_3 + e_4 = 12$. Without the cap: $\binom{15}{3} = 455$. If one child has $e_i \ge 6$: $\binom{9}{3} = 84$, for each of $4$ children. If two children exceed: $\binom{3}{3} = 1$, for each of $\binom{4}{2} = 6$ pairs. Three cannot exceed. So $455 - 336 + 6 = 125$.",
  "Ignoring the cap or omitting the add-back for two children exceeding it.",
  "C25B-identical-bounded", "Two-sided bound with four people; full inclusion-exclusion needed.",
  tita_answer=125, check=_d1,
  tita_traps=[(455, r"Applies the minimum but ignores the maximum: $\binom{15}{3} = 455$."),
              (119, r"Subtracts $4 \times 84$ but does not add back the $6$ cases with two children over the cap.")],
  cognitive="Analysis", exams=CX)


def _d2():
    n = 0
    for f in product(range(3), repeat=6):
        cnt = [f.count(i) for i in range(3)]
        if min(cnt) >= 1 and max(cnt) <= 3:
            n += 1
    return n
q("C25-B-028", T, "Distinct objects to distinct teams with lower and upper limits", "Difficult",
  "Casework/optimisation",
  r"Six different projects are to be allotted to three teams, Red, Green and Blue. Each project goes to exactly one team, every team gets at least one project, and no team gets more than $3$ projects. In how many ways can the projects be allotted?",
  "MCQ",
  r"The possible team sizes are $3, 2, 1$ in some order or $2, 2, 2$. Sizes $3, 2, 1$: $\frac{6!}{3!\,2!\,1!} = 60$ for a fixed order of sizes, times $3! = 6$ orders of sizes, giving $360$. Sizes $2, 2, 2$: $\frac{6!}{2!\,2!\,2!} = 90$. Total $360 + 90 = 450$.",
  "Missing a size pattern, ignoring the upper limit, or treating the teams as unnamed.",
  "C25B-distinct-onto", "Casework on size patterns plus multinomial counting with labelled teams.",
  correct=r"$450$",
  distractors=[(r"$540$", r"Ignores the upper limit and counts all allotments with every team non-empty, including sizes $4, 1, 1$."),
               (r"$360$", r"Counts only the size pattern $3, 2, 1$ and misses $2, 2, 2$."),
               (r"$75$", r"Treats the teams as unnamed groups: $60$ splits of sizes $3, 2, 1$ plus $15$ splits into three pairs, $75$.")],
  check=_d2, values=[450, 540, 360, 75], cognitive="Analysis", exams=CX)


def _d3():
    people = [(c, s) for c in range(6) for s in range(2)]
    n = 0
    for com in combinations(people, 5):
        couples = sum(1 for c in range(6) if (c, 0) in com and (c, 1) in com)
        if couples <= 1:
            n += 1
    return n
q("C25-B-029", T, "Committee from married couples with at most one couple", "Difficult",
  "Casework/optimisation",
  r"A club has $6$ married couples as members, $12$ people in all. A committee of $5$ is to be chosen from them so that it includes at most one married couple. In how many ways can the committee be chosen?",
  "MCQ",
  r"No couple: choose $5$ of the $6$ couples and one spouse from each, $\binom{6}{5} \times 2^5 = 192$. Exactly one couple: choose that couple in $6$ ways, then $3$ of the other $5$ couples and one spouse from each, $6 \times \binom{5}{3} \times 2^3 = 480$. Total $192 + 480 = 672$. (Check: $\binom{12}{5} = 792$, minus committees with two couples, $\binom{6}{2} \times 8 = 120$, gives $672$.)",
  "Fixing a couple and then choosing any three others, which lets a second couple in and double counts.",
  "C25B-committee-couples", "Two cases, each needing a pair-then-member selection; overcount route is natural.",
  correct=r"$672$",
  distractors=[(r"$480$", r"Counts only committees with exactly one couple."),
               (r"$720$", r"Fixes one couple and then any $3$ of the remaining $10$ people: $6 \times \binom{10}{3} = 720$."),
               (r"$792$", r"Ignores the condition: $\binom{12}{5} = 792$.")],
  check=_d3, values=[672, 480, 720, 792], cognitive="Analysis", exams=CX)


def _d4():
    return sum(1 for c in combinations(range(1, 21), 4) if all(c[i + 1] - c[i] >= 3 for i in range(3)))
q("C25-B-030", T, "Choosing days with at least two free days between any two chosen", "Medium",
  "Conceptual/application",
  r"A trainer must choose $4$ of the $20$ days of a training camp (days numbered $1$ to $20$) for fitness tests. Between any two test days there must be at least $2$ days without a test. In how many ways can she choose the test days? Type the number of ways.",
  "TITA",
  r"Each of the $3$ gaps between consecutive test days must contain at least $2$ rest days, so reserve $3 \times 2 = 6$ rest days. Removing them leaves $14$ days in which any $4$ can be test days, and every such choice maps back to exactly one valid choice. The count is $\binom{20 - 6}{4} = \binom{14}{4} = 1001$.",
  "Reserving only one day per gap, or none.",
  "C25B-no-two-adjacent", "One reservation step (two rest days per gap) followed by a single binomial coefficient; the spacing of two is the trap.",
  tita_answer=1001, check=_d4,
  tita_traps=[(2380, r"Reserves only one rest day per gap: $\binom{17}{4} = 2380$."),
              (4845, r"Ignores the spacing condition: $\binom{20}{4} = 4845$.")],
  cognitive="Analysis", exams=CX)


def _d5():
    from math import factorial as F
    # brute force over a smaller analogue would not test the given numbers; count via canonical construction
    # Count unordered partitions of 10 labelled people into blocks of sizes {2,2,3,3} by enumeration of
    # set partitions restricted to block sizes.
    n = 0
    def rec(remaining, sizes_left):
        nonlocal n
        if not remaining:
            if not sizes_left:
                n += 1
            return
        first = remaining[0]
        rest = remaining[1:]
        for s in set(sizes_left):
            for others in combinations(rest, s - 1):
                left = [x for x in rest if x not in others]
                sl = list(sizes_left); sl.remove(s)
                rec(left, sl)
    rec(list(range(10)), [2, 2, 3, 3])
    return n
q("C25-B-031", T, "Dividing distinct people into unlabelled groups of mixed sizes", "Difficult",
  "Conceptual/application",
  r"Ten trainees are to be divided into four discussion groups: two groups of $2$ and two groups of $3$. The groups have no names; two divisions are the same if every trainee has the same group-mates in both. In how many ways can the division be made?",
  "MCQ",
  r"With the four groups labelled, the count is $\frac{10!}{2!\,2!\,3!\,3!} = 25200$. The two groups of $2$ can be swapped and so can the two groups of $3$, so divide by $2! \times 2! = 4$: $\frac{25200}{4} = 6300$.",
  "Not dividing for interchangeable equal-size groups, dividing for only one pair, or dividing by $4!$ for all four groups.",
  "C25B-distinct-groups-sizes", "Must divide only for groups of equal size, which is a strong trap.",
  correct=r"$6300$",
  distractors=[(r"$25200$", r"Treats all four groups as labelled and does not divide at all."),
               (r"$12600$", r"Divides by $2!$ for only one pair of equal-size groups."),
               (r"$1050$", r"Divides by $4!$ as though all four groups were interchangeable.")],
  check=_d5, values=[6300, 25200, 12600, 1050], cognitive="Analysis", exams=CX)


def _d6():
    return len([t for t in _comps(12, 3) if t[0] > t[1]])
q("C25-B-032", T, "Identical objects with one person getting more than another, symmetry", "Difficult",
  "Conceptual/application",
  r"Twelve identical sweets are to be shared among Ravi, Meera and Kabir. Every sweet is given out, and a child may get none. In how many ways can the sweets be shared if Ravi gets more sweets than Meera? Type the number of ways.",
  "TITA",
  r"Without condition there are $\binom{14}{2} = 91$ ways. Ravi and Meera get the same number $k$ when $2k \le 12$, that is $k = 0, 1, \ldots, 6$, with Kabir taking the rest: $7$ ways. In the other $84$ ways the roles of Ravi and Meera are symmetric, so exactly half, $42$, have Ravi ahead.",
  "Not removing the equal cases before halving, or ignoring the condition.",
  "C25B-identical-symmetry", "Needs the symmetry argument with a correction for ties.",
  tita_answer=42, check=_d6,
  tita_traps=[(49, r"Includes the ties on Ravi's side: $\frac{91 + 7}{2} = 49$."),
              (91, r"Ignores the condition."),
              (45, r"Halves $91$ directly and rounds down, without separating the $7$ ties.")],
  cognitive="Analysis", exams=CX)


def _d7():
    n = 0
    for r in _comps(5, 3):
        for b in _comps(5, 3):
            if all(r[i] + b[i] >= 1 for i in range(3)):
                n += 1
    return n
q("C25-B-033", T, "Two kinds of identical objects into distinct boxes, no box empty", "Difficult",
  "Casework/optimisation",
  r"Five identical red balls and five identical blue balls are to be placed in three boxes labelled P, Q and R. All ten balls are used, and no box may be left empty (a box with at least one ball of either colour is not empty). In how many ways can the balls be placed?",
  "MCQ",
  r"Red balls alone can be placed in $\binom{7}{2} = 21$ ways and blue balls likewise, so $21^2 = 441$ placements with no restriction. If a given box is empty, both colours go into the other two boxes: $6^2 = 36$ ways, for each of $3$ boxes. If two given boxes are empty, everything goes into the third: $1$ way, for each of $3$ pairs. By inclusion-exclusion, $441 - 108 + 3 = 336$.",
  "Ignoring the empty-box condition, dropping the add-back, or demanding each box get both colours.",
  "C25B-two-kinds-nonempty-boxes", "Combines distribution of two identical types with inclusion-exclusion on boxes.",
  correct=r"$336$",
  distractors=[(r"$441$", r"Ignores the condition that no box is empty."),
               (r"$333$", r"Subtracts $3 \times 36$ but does not add back the $3$ placements that put everything in one box."),
               (r"$36$", r"Requires every box to get at least one red and at least one blue: $\binom{4}{2}^2 = 36$.")],
  check=_d7, values=[336, 441, 333, 36], cognitive="Analysis", exams=CX)


def _d8():
    men = ["Arjun"] + ["m%d" % i for i in range(6)]
    women = ["Sneha"] + ["w%d" % i for i in range(5)]
    pool = [(p, "M") for p in men] + [(p, "W") for p in women]
    n = 0
    for c in combinations(pool, 5):
        names = {p for p, _ in c}
        w = sum(1 for _, g in c if g == "W")
        if w >= 2 and not ("Arjun" in names and "Sneha" in names):
            n += 1
    return n
q("C25-B-034", T, "Committee with a gender minimum and two people who cannot serve together", "Difficult",
  "Casework/optimisation",
  r"A committee of $5$ is to be formed from $7$ men and $6$ women. It must contain at least $2$ women. Further, Arjun (one of the men) and Sneha (one of the women) are not allowed to be on the committee together. In how many ways can the committee be formed? Type the number of ways.",
  "TITA",
  r"Committees with at least $2$ women: $\binom{13}{5} - \binom{7}{5} - \binom{7}{4}\binom{6}{1} = 1287 - 21 - 210 = 1056$. Among these, those containing both Arjun and Sneha: the other $3$ members come from $6$ men and $5$ women with at least $1$ more woman, $\binom{11}{3} - \binom{6}{3} = 165 - 20 = 145$. Answer $1056 - 145 = 911$.",
  "Forgetting that Sneha already counts towards the two women when removing the Arjun and Sneha committees.",
  "C25B-committee-named-members", "Two conditions interact: the forbidden pair changes the gender count.",
  tita_answer=911, check=_d8,
  tita_traps=[(1056, r"Applies the gender condition but not the restriction on Arjun and Sneha."),
              (891, r"Subtracts all $\binom{11}{3} = 165$ committees containing both Arjun and Sneha, although $20$ of them have no other woman and were never among the $1056$."),
              (986, r"When removing committees with both Arjun and Sneha, demands $2$ further women, not counting Sneha: $1056 - (60 + 10) = 986$.")],
  cognitive="Analysis", exams=CX)


def _d9():
    return sum(1 for c in combinations(range(1, 21), 3) if sum(c) % 3 == 0)
q("C25-B-035", T, "Selecting numbers by residue classes so the sum is divisible by 3", "Difficult",
  "Conceptual/application",
  r"In a quiz game, a player marks $3$ different numbers from $1$ to $20$. In how many ways can the player mark them so that the sum of the three numbers is divisible by $3$?",
  "MCQ",
  r"Group the numbers by remainder on division by $3$: remainder $0$ has $6$ numbers ($3, 6, \ldots, 18$), remainder $1$ has $7$ ($1, 4, \ldots, 19$), remainder $2$ has $7$ ($2, 5, \ldots, 20$). The sum is divisible by $3$ when all three share a remainder or all three remainders differ. Count: $\binom{6}{3} + \binom{7}{3} + \binom{7}{3} + 6 \times 7 \times 7 = 20 + 35 + 35 + 294 = 384$.",
  "Assuming one third of all selections works, or missing one of the two patterns.",
  "C25B-residue-class-selection", "Needs grouping by residues and two patterns; the one-third shortcut fails because group sizes differ.",
  correct=r"$384$",
  distractors=[(r"$380$", r"Takes one third of all selections: $\frac{1140}{3} = 380$."),
               (r"$294$", r"Counts only selections with one number from each remainder class."),
               (r"$90$", r"Counts only selections with all three numbers in the same remainder class.")],
  check=_d9, values=[384, 380, 294, 90], cognitive="Analysis", exams=CX)
