import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Compound interest"
CX = ("CAT", "XAT")


def amt(P, rate_pct, periods):
    """Step-by-step compounding: P grows by rate_pct percent per period."""
    a = F(P)
    for _ in range(periods):
        a = a + a * F(rate_pct) / 100
    return a


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ---------------------------------------------------------------- EASY (11)

def _c1():
    return amt(12500, 8, 2) - 12500
q("C03-B-001", T, "Compound interest on a sum for 2 years at an annual rate", "Easy",
  "Single-step computation",
  r"Ravi deposits Rs. $12{,}500$ in a bank that pays $8\%$ per annum compound interest, compounded annually. How much interest does he earn in $2$ years?",
  "MCQ",
  r"Amount $= 12500 \times 1.08^2 = 12500 \times 1.1664 = 14580$. Interest $= 14580 - 12500 =$ Rs. $2{,}080$. Quick check: first-year interest is $1000$, second-year interest is $1000 + 8\%$ of $1000 = 1080$, total $2080$.",
  "Using simple interest, or reporting the amount instead of the interest.",
  "C03B-ci-basic-amount", "Direct application of the CI formula for two years; traps are SI and amount versus interest.",
  correct=r"Rs. $2{,}080$",
  distractors=[(r"Rs. $2{,}000$", r"Simple interest: $12500 \times 0.08 \times 2 = 2000$."),
               (r"Rs. $14{,}580$", r"Reports the amount $12500 \times 1.08^2$ instead of the interest."),
               (r"Rs. $2{,}160$", r"Finds the second-year interest $1080$ and doubles it for two years.")],
  check=_c1, values=[2080, 2000, 14580, 2160], cognitive="Application")


def _c2():
    return amt(20000, 10, 3) - amt(20000, 10, 2)
q("C03-B-002", T, "Interest earned during one particular year under annual compounding", "Easy",
  "Single-step computation",
  r"Meera invests Rs. $20{,}000$ at $10\%$ per annum compound interest, compounded annually. How much interest, in rupees, does she earn during the third year alone?",
  "TITA",
  r"At the start of the third year the amount is $20000 \times 1.1^2 = 24200$. Interest during the third year $= 10\%$ of $24200 = 2420$ rupees.",
  "Using the original principal for every year, or giving the total interest over three years.",
  "C03B-ci-specific-year", "One growth step to the start of year three, then one percentage; trap is total versus one year.",
  tita_answer=2420, check=_c2,
  tita_traps=[(2000, r"Takes $10\%$ of the original principal, as in simple interest."),
              (6620, r"Gives the total interest for three years, $20000(1.331 - 1)$."),
              (2200, r"Gives the second-year interest, $10\%$ of $22000$.")],
  cognitive="Application")


def _c3():
    return amt(16000, 5, 3) - 16000
q("C03-B-003", T, "Half-yearly compounding over one and a half years", "Easy",
  "Single-step computation",
  r"Kabir borrows Rs. $16{,}000$ at $10\%$ per annum, compounded half-yearly. What is the interest due at the end of $1\frac{1}{2}$ years?",
  "MCQ",
  r"Half-yearly compounding at $10\%$ per annum means $5\%$ per half-year, for $3$ half-years. Amount $= 16000 \times 1.05^3 = 16000 \times 1.157625 = 18522$. Interest $=$ Rs. $2{,}522$.",
  "Using the annual rate per half-year, or compounding annually and adding simple interest for the last half-year.",
  "C03B-half-yearly", "Convert rate and periods for half-yearly compounding; one cube.",
  correct=r"Rs. $2{,}522$",
  distractors=[(r"Rs. $2{,}400$", r"Simple interest: $16000 \times 0.10 \times 1.5 = 2400$."),
               (r"Rs. $2{,}480$", r"Compounds annually for one year, then adds $5\%$ for the half-year: $16000 \times 1.1 \times 1.05 = 18480$."),
               (r"Rs. $5{,}296$", r"Applies the full $10\%$ every half-year: $16000 \times 1.1^3 = 21296$.")],
  check=_c3, values=[2522, 2400, 2480, 5296], cognitive="Application")


def _c4():
    P = symbols('P', positive=True)
    r = F(6, 100)
    ci = P * (1 + r) ** 2 - P
    si = P * r * 2
    return solve(Eq(ci - si, 54), P)[0]
q("C03-B-004", T, "Principal from the CI minus SI difference over 2 years", "Easy",
  "Inverse/parameter",
  r"On a certain sum invested for $2$ years at $6\%$ per annum, the compound interest (compounded annually) exceeds the simple interest by Rs. $54$. What is the sum, in rupees?",
  "TITA",
  r"For $2$ years, $\text{CI} - \text{SI} = P\left(\frac{r}{100}\right)^2$, the interest earned in the second year on the first year's interest. So $P \times 0.0036 = 54$, giving $P = 15000$ rupees.",
  "Using a wrong multiplier on $P r^2$ for the two-year difference.",
  "C03B-ci-si-diff-2yr", "One standard relation, one division.",
  tita_answer=15000, check=_c4,
  tita_traps=[(7500, r"Uses $\text{CI} - \text{SI} = 2P r^2$."),
              (30000, r"Uses $\text{CI} - \text{SI} = \frac{P r^2}{2}$.")],
  cognitive="Application")


def _c5():
    # (1+r)^5 = 3; find n with (1+r)^n = 27 -> n = 5 * log3(27)
    n = symbols('n', positive=True)
    k = symbols('k', positive=True)  # k = (1+r), k^5 = 3
    kval = Integer(3) ** Rational(1, 5)
    return nsimplify(solve(Eq(n * log(kval), log(27)), n)[0])
q("C03-B-005", T, "Time for a sum to become 27 times when it triples in a known time", "Easy",
  "Conceptual/application",
  r"A sum of money invested at compound interest (compounded annually) becomes $3$ times itself in $5$ years. In how many years will it become $27$ times itself at the same rate?",
  "MCQ",
  r"Every $5$ years the sum is multiplied by $3$. Since $27 = 3^3$, it needs three such periods: $3 \times 5 = 15$ years.",
  "Treating compound growth as linear (proportional or simple-interest style).",
  "C03B-multiply-time", "One insight: multiplying factors means adding time periods.",
  correct=r"$15$ years",
  distractors=[(r"$65$ years", r"Simple-interest reasoning: interest $2P$ in $5$ years, so interest $26P$ needs $65$ years."),
               (r"$45$ years", r"Scales time in proportion to the multiple: $\frac{27}{3} \times 5 = 45$."),
               (r"$10$ years", r"Takes two tripling periods, which gives only $3^2 = 9$ times.")],
  check=_c5, values=[15, 65, 45, 10], cognitive="Understanding")


def _c6():
    return ((1 + F(10, 100)) ** 2 - 1) * 100
q("C03-B-006", T, "Effective annual rate for half-yearly compounding", "Easy",
  "Conceptual/application",
  r"A finance company advertises $20\%$ per annum, compounded half-yearly. What is the effective annual rate of interest, in percent?",
  "TITA",
  r"The rate is $10\%$ per half-year. One year gives a factor $1.1^2 = 1.21$, so the effective annual rate is $21\%$. Type $21$.",
  "Equating the nominal and effective rates.",
  "C03B-effective-rate", "One squaring; the trap is nominal versus effective rate.",
  tita_answer=21, check=_c6,
  tita_traps=[(20, r"Reports the nominal rate as the effective rate."),
              (10, r"Reports the half-yearly rate.")],
  cognitive="Understanding")


def _c7():
    a = F(25000)
    for r in (8, 10, 12):
        a = a * (1 + F(r, 100))
    return a
q("C03-B-007", T, "Amount under different rates in successive years", "Easy",
  "Multi-step word problem",
  r"Sneha invests Rs. $25{,}000$ in a scheme that pays compound interest at $8\%$ for the first year, $10\%$ for the second year and $12\%$ for the third year. What is the amount at the end of $3$ years?",
  "MCQ",
  r"Each year's rate applies to the amount at the start of that year: $25000 \times 1.08 = 27000$, then $27000 \times 1.10 = 29700$, then $29700 \times 1.12 = 33264$. Amount $=$ Rs. $33{,}264$.",
  "Replacing the three rates by their average, or applying the later rates to the original principal.",
  "C03B-successive-rates", "Three successive multiplications; the average-rate shortcut is the trap.",
  correct=r"Rs. $33{,}264$",
  distractors=[(r"Rs. $33{,}275$", r"Uses the average rate $10\%$ for all three years: $25000 \times 1.331$."),
               (r"Rs. $32{,}500$", r"Simple interest at a total of $30\%$: $25000 \times 1.30$."),
               (r"Rs. $32{,}700$", r"Compounds for two years to $29700$ but takes the third-year $12\%$ on the principal: $29700 + 3000$.")],
  check=_c7, values=[33264, 33275, 32500, 32700], cognitive="Application")


def _c8():
    r = symbols('r', positive=True)
    return _pos(solve(Eq(15625 * (1 + r / 100) ** 3, 17576), r))[0]
q("C03-B-008", T, "Rate from principal and amount over 3 years", "Easy",
  "Inverse/parameter",
  r"Rs. $15{,}625$ invested at compound interest, compounded annually, amounts to Rs. $17{,}576$ in $3$ years. What is the rate of interest, in percent per annum?",
  "TITA",
  r"$(1 + r)^3 = \frac{17576}{15625} = \left(\frac{26}{25}\right)^3$, since $26^3 = 17576$ and $25^3 = 15625$. So $1 + r = 1.04$ and the rate is $4\%$. Type $4$.",
  "Reading the total growth as the annual rate, or stopping at the cube-root ratio.",
  "C03B-ci-find-rate", "Recognising a perfect cube ratio; one step.",
  tita_answer=4, check=_c8,
  tita_traps=[(12, r"Finds $4\%$ and then multiplies by the $3$ years; the total growth $\frac{1951}{15625}$ is about $12.49\%$, which a student truncating or rounding would also type as $12$."),
              (26, r"Finds the cube-root ratio $\frac{26}{25}$ and types the numerator.")],
  cognitive="Application")


def _c9():
    return amt(25000, 6, 2) - amt(25000, 12, 1)
q("C03-B-009", T, "Half-yearly versus annual compounding on the same sum", "Easy",
  "Multi-step word problem",
  r"Arjun and Fatima each invest Rs. $25{,}000$ for $1$ year at $12\%$ per annum. Arjun's interest is compounded half-yearly and Fatima's is compounded annually. By how much does Arjun's interest exceed Fatima's?",
  "MCQ",
  r"Arjun: $6\%$ per half-year for $2$ half-years, $25000 \times 1.06^2 = 25000 \times 1.1236 = 28090$, interest $3090$. Fatima: $25000 \times 0.12 = 3000$. Difference $=$ Rs. $90$, which is the second half-year's interest on the first half-year's interest: $6\%$ of $1500$.",
  "Taking interest on the whole year's interest, or using the annual rate in the interest-on-interest term.",
  "C03B-half-yearly-vs-annual", "Two direct computations, or one interest-on-interest step.",
  correct=r"Rs. $90$",
  distractors=[(r"Rs. $360$", r"Uses the annual rate in the interest-on-interest term: $25000 \times 0.12^2$."),
               (r"Rs. $180$", r"Takes $6\%$ of the whole year's interest $3000$ instead of the first half-year's interest $1500$."),
               (r"Rs. $3{,}090$", r"Reports Arjun's interest instead of the difference.")],
  check=_c9, values=[90, 360, 180, 3090], cognitive="Application")


def _c10():
    return amt(40000, 3, 2) - 40000
q("C03-B-010", T, "Quarterly compounding over six months", "Easy",
  "Single-step computation",
  r"Joseph deposits Rs. $40{,}000$ at $12\%$ per annum, compounded quarterly. What interest does he earn in $6$ months?",
  "MCQ",
  r"Quarterly rate $= 3\%$; $6$ months is $2$ quarters. Amount $= 40000 \times 1.03^2 = 40000 \times 1.0609 = 42436$. Interest $=$ Rs. $2{,}436$.",
  "Using the half-yearly rate per quarter, or counting the six months as one period.",
  "C03B-quarterly", "Rate and period conversion for quarterly compounding, then one square.",
  correct=r"Rs. $2{,}436$",
  distractors=[(r"Rs. $2{,}400$", r"Simple interest for half a year: $40000 \times 0.12 \times 0.5$."),
               (r"Rs. $4{,}944$", r"Takes $6\%$ per quarter for two quarters: $40000(1.06^2 - 1)$."),
               (r"Rs. $1{,}200$", r"Treats the six months as a single quarter at $3\%$.")],
  check=_c10, values=[2436, 2400, 4944, 1200], cognitive="Application")


def _c11():
    P, r = symbols('P r', positive=True)
    si = P * r / 100 * 3
    ci = P * (1 + r / 100) ** 3 - P
    sol = solve(Eq(ci - si, Rational(33, 100) * si), r)
    return [s for s in sol if s.is_real and s > 0][0]
q("C03-B-011", T, "Rate from the 3-year CI excess over SI given as a percentage of the SI", "Difficult",
  "Inverse/parameter",
  r"A sum is lent for $3$ years at $r\%$ per annum. The compound interest on it (compounded annually) exceeds the simple interest on it at the same rate by an amount equal to $33\%$ of the simple interest. What is $r$?",
  "MCQ",
  r"With $r$ as a decimal, $\text{SI} = 3Pr$ and $\text{CI} - \text{SI} = P\left[(1 + r)^3 - 1 - 3r\right] = Pr^2(3 + r)$. So $\frac{Pr^2(3 + r)}{3Pr} = \frac{r(3 + r)}{3} = 0.33$, that is $r^2 + 3r - 0.99 = 0 = (r - 0.3)(r + 3.3)$. Hence $r = 0.3$ and the rate is $30\%$.",
  r"Using the two-year relation (excess $= \frac{r}{2}$ of the SI) or ignoring the squared term.",
  "C03B-ci-si-diff-3yr", r"Needs the three-year excess as a fraction of the SI, $\frac{r(3 + r)}{3}$, and a quadratic in the rate; the two-year shortcut is a strong trap.",
  correct=r"$30$",
  distractors=[(r"$66$", r"Uses the two-year relation, excess $= \frac{r}{2} \times \text{SI}$, so $\frac{r}{2} = 0.33$."),
               (r"$33$", r"Drops the $r^2$ inside $\frac{r(3 + r)}{3}$, leaving $r = 0.33$."),
               (r"$11$", r"Treats the $33\%$ as the total compound excess over $3$ years and divides by $3$ to get an annual rate: $\frac{33}{3} = 11$.")],
  check=_c11, values=[30, 66, 33, 11], exams=CX, cognitive="Analysis")


# ---------------------------------------------------------------- MEDIUM (15)

def _c12():
    P = symbols('P', positive=True)
    r = F(10, 100)
    return solve(Eq(P * (1 + r) ** 3 - P - P * r * 3, 930), P)[0]
q("C03-B-012", T, "Principal from the CI minus SI difference over 3 years", "Medium",
  "Inverse/parameter",
  r"For a certain sum invested for $3$ years at $10\%$ per annum, the compound interest (compounded annually) exceeds the simple interest by Rs. $930$. What is the sum, in rupees?",
  "TITA",
  r"For $3$ years, $\text{CI} - \text{SI} = P\left[(1.1)^3 - 1 - 0.3\right] = P(1.331 - 1.3) = 0.031P$. So $0.031P = 930$ and $P = 30000$ rupees.",
  "Using the two-year difference formula, or dropping the $r^3$ term in the three-year one.",
  "C03B-ci-si-diff-3yr", "Needs the three-year difference $P r^2 (3 + r)$, not the two-year one.",
  tita_answer=30000, check=_c12,
  tita_traps=[(31000, r"Drops the $r^3$ term: $0.03P = 930$."),
              (93000, r"Uses the two-year formula $P r^2 = 930$.")],
  cognitive="Application")


def _c13():
    P, r = symbols('P r', positive=True)
    sol = solve([Eq(P * (1 + r) ** 2 - P, 2544), Eq(2 * P * r, 2400)], [P, r], dict=True)
    return [s[P] for s in sol if s[r] > 0][0]
q("C03-B-013", T, "Principal from CI and SI for 2 years at the same unknown rate", "Medium",
  "Inverse/parameter",
  r"On the same sum and at the same rate per annum, the compound interest (compounded annually) for $2$ years is Rs. $2{,}544$ and the simple interest for $2$ years is Rs. $2{,}400$. What is the sum?",
  "MCQ",
  r"The extra Rs. $144$ is interest on the first year's interest of $1200$, so the rate is $\frac{144}{1200} = 12\%$. Then $P \times 0.12 \times 2 = 2400$ gives $P =$ Rs. $10{,}000$.",
  "Dividing the difference by the whole two-year SI to get the rate.",
  "C03B-ci-si-diff-2yr", "Two linked steps: rate from the difference, then principal.",
  correct=r"Rs. $10{,}000$",
  distractors=[(r"Rs. $20{,}000$", r"Takes the rate as $\frac{144}{2400} = 6\%$ and then $P = \frac{2400}{2 \times 0.06}$."),
               (r"Rs. $40{,}000$", r"Takes the rate as $6\%$ and uses $P = \frac{144}{0.06^2}$."),
               (r"Rs. $12{,}544$", r"Reports the amount $10000 + 2544$ instead of the sum.")],
  check=_c13, values=[10000, 20000, 40000, 12544], cognitive="Application")


def _c14():
    P, r = symbols('P r', positive=True)
    sol = solve([Eq(P * (1 + r) ** 2, 17640), Eq(P * (1 + r) ** 3, 18522)], [P, r], dict=True)
    return sol[0][P]
q("C03-B-014", T, "Principal from the amounts at the end of two consecutive years", "Medium",
  "Multi-step word problem",
  r"A sum invested at compound interest (compounded annually) amounts to Rs. $17{,}640$ at the end of $2$ years and to Rs. $18{,}522$ at the end of $3$ years. What is the sum?",
  "MCQ",
  r"Interest in the third year is $18522 - 17640 = 882$, which is $\frac{882}{17640} = 5\%$ of the amount at the end of year $2$. So the rate is $5\%$ and $P = \frac{17640}{1.05^2} = \frac{17640}{1.1025} =$ Rs. $16{,}000$.",
  "Going back by subtracting equal yearly interest instead of dividing by the growth factor.",
  "C03B-consecutive-amounts", "Rate from consecutive amounts, then discount back two years.",
  correct=r"Rs. $16{,}000$",
  distractors=[(r"Rs. $15{,}876$", r"Subtracts the third-year interest twice: $17640 - 2 \times 882$."),
               (r"Rs. $16{,}800$", r"Divides by $1.05$ only once, going back one year instead of two."),
               (r"Rs. $16{,}758$", r"Treats $882$ as the total interest for the first two years: $17640 - 882$.")],
  check=_c14, values=[16000, 15876, 16800, 16758], cognitive="Application")


def _c15():
    P, r = symbols('P r', positive=True)
    sol = solve([Eq(P * (1 + r) * r, 1320), Eq(P * (1 + r) ** 2 * r, 1452)], [P, r], dict=True)
    return sol[0][P]
q("C03-B-015", T, "Principal from the interest earned in two consecutive later years", "Medium",
  "Multi-step word problem",
  r"Under compound interest (compounded annually), the interest earned by a sum during the second year is Rs. $1{,}320$ and during the third year is Rs. $1{,}452$. What is the sum, in rupees?",
  "TITA",
  r"Third-year interest is the second-year interest grown by one year: $\frac{1452}{1320} = 1.1$, so the rate is $10\%$. First-year interest $= \frac{1320}{1.1} = 1200$, which is $10\%$ of the sum. Sum $= 12000$ rupees.",
  "Treating the second-year interest as interest on the original sum.",
  "C03B-consecutive-amounts", "Rate from the ratio of consecutive interests, then step back one year.",
  tita_answer=12000, check=_c15,
  tita_traps=[(13200, r"Treats $1320$ as $10\%$ of the original sum."),
              (14520, r"Treats $1452$ as $10\%$ of the original sum.")],
  cognitive="Application")


def _c16():
    P, k = symbols('P k', positive=True)   # k = (1+r)^2
    sol = solve([Eq(P * k ** 2, 48000), Eq(P * k ** 5, 384000)], [P, k], dict=True)
    return sol[0][P]
q("C03-B-016", T, "Original sum from amounts after 4 and 10 years", "Medium",
  "Conceptual/application",
  r"Priya's investment grows at compound interest, compounded annually at a fixed rate. Its value is Rs. $48{,}000$ at the end of $4$ years and Rs. $3{,}84{,}000$ at the end of $10$ years. How much, in rupees, did she invest?",
  "TITA",
  r"In the $6$ years from year $4$ to year $10$ the value is multiplied by $\frac{384000}{48000} = 8 = 2^3$, so it doubles every $2$ years. In the first $4$ years it doubled twice, so the investment was $\frac{48000}{4} = 12000$ rupees.",
  "Mis-scaling the doubling period back to the start.",
  "C03B-multiply-time", "Needs the growth factor per fixed period and then a backward step.",
  tita_answer=12000, check=_c16,
  tita_traps=[(6000, r"Divides by $8$, assuming the factor $8$ also applies to the first $4$ years."),
              (24000, r"Assumes the sum doubles every $4$ years.")],
  cognitive="Analysis")


def _c17():
    r = symbols('r', positive=True)
    return _pos(solve(Eq((1 + r / 100) * (1 + (r + 10) / 100), Rational(132, 100)), r))[0]
q("C03-B-017", T, "Unknown rate when the second-year rate is 10 points higher", "Medium",
  "Inverse/parameter",
  r"Harpreet invests a sum at compound interest: $r\%$ for the first year and $(r + 10)\%$ for the second year, the second year's interest being calculated on the amount at the end of the first year. Over the two years the sum grows by exactly $32\%$. What is $r$?",
  "MCQ",
  r"$(1 + \frac{r}{100})(1.1 + \frac{r}{100}) = 1.32$. Trying $r = 10$: $1.1 \times 1.2 = 1.32$. Indeed $x = \frac{r}{100}$ satisfies $x^2 + 2.1x - 0.22 = 0 = (x - 0.1)(x + 2.2)$, so $r = 10$.",
  "Adding the two rates as in simple interest.",
  "C03B-successive-rates", "A quadratic from two different successive rates; checking candidate values is the fast route.",
  correct=r"$10$",
  distractors=[(r"$11$", r"Adds rates as simple interest: $r + (r + 10) = 32$."),
               (r"$16$", r"Splits the $32\%$ equally between the two years."),
               (r"$20$", r"Reports the second-year rate $r + 10$.")],
  check=_c17, values=[10, 11, 16, 20], cognitive="Application")


def _c18():
    r = symbols('r', positive=True)
    return _pos(solve(Eq((1 + r / 200) ** 2, Rational(144, 100)), r))[0]
q("C03-B-018", T, "Nominal rate for half-yearly compounding from a given annual growth", "Medium",
  "Inverse/parameter",
  r"A deposit scheme compounds interest half-yearly, and a sum kept in it for exactly $1$ year grows by $44\%$. What is the nominal annual rate of interest of the scheme, in percent per annum?",
  "TITA",
  r"If the nominal rate is $R\%$, the half-yearly rate is $\frac{R}{2}\%$ and $(1 + \frac{R}{200})^2 = 1.44$. So $1 + \frac{R}{200} = 1.2$, the half-yearly rate is $20\%$ and $R = 40$.",
  "Halving the annual growth instead of taking the square root, or stopping at the half-yearly rate.",
  "C03B-effective-rate", "Reverse of the effective-rate idea; needs a square root and a doubling.",
  tita_answer=40, check=_c18,
  tita_traps=[(22, r"Halves the $44\%$ annual growth to get the half-yearly rate and reports it."),
              (20, r"Reports the half-yearly rate $20\%$ as the annual rate."),
              (44, r"Reports the effective growth as the nominal rate.")],
  cognitive="Application")


def _c19():
    P = symbols('P', positive=True)
    return solve(Eq(P * F(11, 10) ** 4 - P * F(12, 10) ** 2, 482), P)[0]
q("C03-B-019", T, "Principal from the gap between half-yearly and annual compounding", "Medium",
  "Inverse/parameter",
  r"A sum is invested for $2$ years at $20\%$ per annum. The compound interest when compounded half-yearly is Rs. $482$ more than when compounded annually. What is the sum?",
  "MCQ",
  r"Per rupee, half-yearly gives $1.1^4 = 1.4641$ and annual gives $1.2^2 = 1.44$, a gap of $0.0241$. So $0.0241P = 482$ and $P =$ Rs. $20{,}000$.",
  "Using the one-year gap, or the CI minus SI gap, as the multiplier.",
  "C03B-half-yearly-vs-annual", "Needs both growth factors and their exact difference.",
  correct=r"Rs. $20{,}000$",
  distractors=[(r"Rs. $48{,}200$", r"Uses the one-year gap $1.21 - 1.20 = 0.01$."),
               (r"Rs. $24{,}100$", r"Doubles the one-year gap to $0.02$ for two years."),
               (r"Rs. $12{,}050$", r"Uses the annual CI minus SI gap $1.44 - 1.40 = 0.04$.")],
  check=_c19, values=[20000, 48200, 24100, 12050], cognitive="Application")


def _c20():
    x = symbols('x', positive=True)    # part for 3 years
    sol = solve(Eq(x * F(11, 10) ** 3, (22100 - x) * F(11, 10) ** 5), x)[0]
    return max(sol, 22100 - sol)
q("C03-B-020", T, "Splitting a sum so that two parts reach equal amounts at different times", "Medium",
  "Inverse/parameter",
  r"Rs. $22{,}100$ is divided into two parts. The first part is invested for $3$ years and the second for $5$ years, both at $10\%$ per annum compound interest, compounded annually. The two amounts at the end of their periods are equal. What is the larger part, in rupees?",
  "TITA",
  r"First part $\times 1.1^3 =$ second part $\times 1.1^5$, so first part $= 1.21 \times$ second part. Then $2.21 \times$ second part $= 22100$, second part $= 10000$, first part $= 12100$. The larger part is $12100$ rupees.",
  "Splitting equally or reporting the smaller part.",
  "C03B-split-sum", "Ratio from equal amounts, then a split of the total.",
  tita_answer=12100, check=_c20,
  tita_traps=[(10000, r"Reports the smaller part (the one invested for $5$ years)."),
              (11050, r"Splits the total equally.")],
  cognitive="Application")


def _c21():
    P = symbols('P', positive=True)
    y1 = P * F(20, 100)
    y3 = P * F(12, 10) ** 2 * F(20, 100)
    return solve(Eq(y3 - y1, 1320), P)[0]
q("C03-B-021", T, "Principal from the gap between third-year and first-year interest", "Medium",
  "Multi-step word problem",
  r"A sum is invested at $20\%$ per annum compound interest, compounded annually. The interest earned during the third year exceeds the interest earned during the first year by Rs. $1{,}320$. What is the sum?",
  "MCQ",
  r"First-year interest $= 0.2P$; third-year interest $= 0.2 \times 1.44P = 0.288P$. The gap is $0.088P = 1320$, so $P =$ Rs. $15{,}000$.",
  "Comparing the wrong years, or growing the base linearly.",
  "C03B-ci-specific-year", "Interest of a specific year as a fraction of $P$ for two different years.",
  correct=r"Rs. $15{,}000$",
  distractors=[(r"Rs. $16{,}500$", r"Grows the base by simple interest: third-year interest $0.2 \times 1.4P$, gap $0.08P$."),
               (r"Rs. $33{,}000$", r"Uses the gap between second-year and first-year interest, $0.04P$."),
               (r"Rs. $3{,}000$", r"Uses $P(1.2^2 - 1) = 0.44P$, leaving out the factor $0.2$.")],
  check=_c21, values=[15000, 16500, 33000, 3000], cognitive="Application")


def _c22():
    n, a = 0, F(10000)
    while not a > 30000:
        a = a * F(12, 10)
        n += 1
    return n
q("C03-B-022", T, "Least whole number of years for a sum to exceed three times itself", "Medium",
  "Casework/optimisation",
  r"Ananya invests Rs. $10{,}000$ at $20\%$ per annum compound interest, compounded annually. After how many complete years does her amount first exceed Rs. $30{,}000$?",
  "MCQ",
  r"Track the factor: $1.2^2 = 1.44$, $1.2^3 = 1.728$, $1.2^4 = 2.0736$, $1.2^5 = 2.48832$, $1.2^6 = 2.985984$, $1.2^7 = 3.5831808$. After $6$ years the amount is $29{,}859.84$, still below $30{,}000$; after $7$ years it is above. Answer: $7$ years.",
  "Rounding $1.2^6$ up to $3$, or using simple interest.",
  "C03B-time-threshold", "Repeated multiplication with a near-miss at $6$ years.",
  correct=r"$7$ years",
  distractors=[(r"$6$ years", r"Rounds $1.2^6 \approx 2.99$ to $3$ and accepts it."),
               (r"$11$ years", r"Simple interest: needs more than $10$ years of Rs. $2000$ each."),
               (r"$10$ years", r"Simple interest reaching exactly Rs. $30{,}000$.")],
  check=_c22, values=[7, 6, 11, 10], cognitive="Application")


def _c23():
    return amt(62500, 4, 3) - 62500
q("C03-B-023", T, "Quarterly compounding over nine months", "Easy",
  "Single-step computation",
  r"Fatima deposits Rs. $62{,}500$ at $16\%$ per annum, compounded quarterly. What interest does she earn in $9$ months?",
  "MCQ",
  r"Quarterly rate $= 4\%$ and $9$ months $= 3$ quarters. Amount $= 62500 \times 1.04^3 = 62500 \times 1.124864 = 70304$. Interest $=$ Rs. $7{,}804$.",
  "Mismatching the quarterly rate or the number of quarters.",
  "C03B-quarterly", "One idea: convert to a quarterly rate and a count of quarters, then one cube.",
  correct=r"Rs. $7{,}804$",
  distractors=[(r"Rs. $7{,}500$", r"Simple interest: $62500 \times 0.16 \times 0.75$."),
               (r"Rs. $5{,}100$", r"Counts only $2$ quarters: $62500(1.04^2 - 1)$."),
               (r"Rs. $16{,}232$", r"Takes $8\%$ per quarter (the half-yearly rate): $62500(1.08^3 - 1)$.")],
  check=_c23, values=[7804, 7500, 5100, 16232], cognitive="Application")


def _c24():
    X, Y = symbols('X Y', positive=True)
    ratio = solve(Eq(X * F(10, 100) * 3, Y * (F(11, 10) ** 3 - 1)), X)[0] / Y
    return nsimplify(ratio)
q("C03-B-024", T, "Ratio of two sums earning equal SI and CI over 3 years", "Medium",
  "Conceptual/application",
  r"Ravi lends a sum at $10\%$ per annum simple interest and Sneha lends another sum at $10\%$ per annum compound interest, compounded annually, both for $3$ years. They earn exactly the same interest. What is the ratio of Ravi's sum to Sneha's sum?",
  "MCQ",
  r"Ravi's interest $= 0.3X$; Sneha's interest $= Y(1.1^3 - 1) = 0.331Y$. Equal interests give $\frac{X}{Y} = \frac{0.331}{0.3} = \frac{331}{300}$. Ravi needs the larger sum, as expected, since SI earns less per rupee.",
  "Equating amounts instead of interests, or inverting the ratio.",
  "C03B-ci-vs-si-compare", "Needs the per-rupee interest under each scheme and the correct direction of the ratio.",
  correct=r"$331 : 300$",
  distractors=[(r"$300 : 331$", r"Inverts the ratio."),
               (r"$1331 : 1300$", r"Equates the amounts $1.3X = 1.331Y$ instead of the interests."),
               (r"$21 : 20$", r"Uses $2$ years: $\frac{0.21}{0.2}$.")],
  check=_c24, values=[F(331, 300), F(300, 331), F(1331, 1300), F(21, 20)], cognitive="Understanding")


def _c25():
    P = 40000
    a = F(P) * F(12, 10) * F(11, 10)
    b = F(P) * F(115, 100) ** 2
    return b - a
q("C03-B-025", T, "Uniform rate versus unequal rates with the same average", "Medium",
  "Conceptual/application",
  r"Kabir and Joseph each invest Rs. $40{,}000$ at compound interest for $2$ years. Kabir earns $20\%$ in the first year and $10\%$ in the second year; Joseph earns $15\%$ in each year. By how much does Joseph's amount exceed Kabir's?",
  "MCQ",
  r"Joseph: $40000 \times 1.15^2 = 52900$. Kabir: $40000 \times 1.2 \times 1.1 = 52800$. Difference $=$ Rs. $100$. In general $(1 + a)^2 - (1 + a + d)(1 + a - d) = d^2$, here $0.05^2 \times 40000 = 100$.",
  "Assuming equal average rates give equal amounts.",
  "C03B-successive-rates", "Needs the insight that equal rates beat unequal rates with the same average by $P d^2$.",
  correct=r"Rs. $100$",
  distractors=[(r"Rs. $0$", r"Assumes equal average rates give equal amounts."),
               (r"Rs. $400$", r"Uses the full gap between rates: $0.1^2 \times 40000$."),
               (r"Rs. $800$", r"Compares Kabir's amount $52800$ with $15\%$ simple interest, $52000$.")],
  check=_c25, values=[100, 0, 400, 800], cognitive="Understanding")


def _c26():
    P, r = symbols('P r', positive=True)
    sol = solve([Eq(P * (1 + r) ** 2 - P, 2520), Eq(2 * P * r, 2400)], [P, r], dict=True)
    s = [s for s in sol if s[r] > 0][0]
    return s[P] * ((1 + s[r]) ** 3 - 1)
q("C03-B-026", T, "Three-year CI from two-year CI and SI on the same sum", "Medium",
  "Multi-step word problem",
  r"On a certain sum, at the same rate per annum, the compound interest (compounded annually) for $2$ years is Rs. $2{,}520$ and the simple interest for $2$ years is Rs. $2{,}400$. What is the compound interest on the same sum for $3$ years at that rate?",
  "MCQ",
  r"First-year interest is $1200$; the extra $120$ is interest on it, so the rate is $10\%$ and the sum is $12000$. Yearly interests are $1200$, $1320$, $1452$, so the three-year CI is $1200 + 1320 + 1452 =$ Rs. $3{,}972$.",
  "Using a constant interest for the third year, or scaling the two-year CI.",
  "C03B-ci-si-diff-2yr", "Rate and sum from the difference, then extend to a third year.",
  correct=r"Rs. $3{,}972$",
  distractors=[(r"Rs. $3{,}600$", r"Gives the three-year simple interest."),
               (r"Rs. $3{,}780$", r"Scales the two-year CI by $\frac{3}{2}$."),
               (r"Rs. $3{,}840$", r"Takes the third-year interest equal to the second-year interest, $1320$.")],
  check=_c26, values=[3972, 3600, 3780, 3840], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (9)

def _c27():
    P, r = symbols('P r', positive=True)
    d2 = P * (1 + r) ** 2 - P - 2 * P * r
    d3 = P * (1 + r) ** 3 - P - 3 * P * r
    sol = solve([Eq(d2, 160), Eq(d3, 488)], [P, r], dict=True)
    return [s[P] for s in sol if s[r] > 0][0]
q("C03-B-027", T, "Sum from the CI minus SI gaps for 2 and 3 years", "Difficult",
  "Inverse/parameter",
  r"On a certain sum at a certain rate per annum, the compound interest (compounded annually) exceeds the simple interest by Rs. $160$ over $2$ years and by Rs. $488$ over $3$ years. What is the sum, in rupees?",
  "TITA",
  r"With $r$ as a decimal, the gaps are $P r^2$ and $P r^2 (3 + r)$. Dividing, $3 + r = \frac{488}{160} = 3.05$, so $r = 0.05$. Then $P = \frac{160}{0.0025} = 64000$ rupees.",
  "Assuming the three-year gap is a fixed multiple of the two-year gap, or reporting the rate.",
  "C03B-ci-si-diff-3yr", "Two difference formulas combined; dividing them isolates the rate.",
  tita_answer=64000, check=_c27,
  tita_traps=[(5, r"Stops after finding the rate $5\%$."),
              (32000, r"Uses $2P r^2$ for the two-year gap.")],
  exams=CX, cognitive="Analysis")


def _c28():
    r = 1
    while not F(10000) * (1 + F(r, 100)) ** 5 > 20000:
        r += 1
    return r
q("C03-B-028", T, "Least whole-number rate for a sum to more than double in 5 years", "Difficult",
  "Casework/optimisation",
  r"Rs. $10{,}000$ is to be invested for $5$ years at compound interest, compounded annually, at a whole-number rate per annum. What is the smallest such rate, in percent, for which the amount at the end of $5$ years exceeds Rs. $20{,}000$?",
  "TITA",
  r"Rule of $72$ suggests about $14\%$, so test near there. $1.14^2 = 1.2996$, $1.14^4 \approx 1.6890$, $1.14^5 \approx 1.9254 < 2$. $1.15^2 = 1.3225$, $1.15^4 \approx 1.7490$, $1.15^5 \approx 2.0114 > 2$. The smallest rate is $15\%$.",
  "Trusting the rule-of-72 estimate, or using simple interest.",
  "C03B-time-threshold", "Needs testing of fifth powers on either side of an estimate.",
  tita_answer=15, check=_c28,
  tita_traps=[(14, r"Uses the rule of $72$: $\frac{72}{5} = 14.4$, rounded down."),
              (21, r"Simple interest: $5r > 100$ gives $r = 21$.")],
  exams=CX, cognitive="Analysis")


def _c29():
    a = symbols('a', positive=True)    # common amount
    parts = [a / F(12, 10) ** k for k in (1, 2, 3)]
    A = solve(Eq(sum(parts), 36400), a)[0]
    return A / F(12, 10) ** 2
q("C03-B-029", T, "Three parts reaching equal amounts after 1, 2 and 3 years", "Difficult",
  "Inverse/parameter",
  r"Rs. $36{,}400$ is divided into three parts, invested at $20\%$ per annum compound interest, compounded annually, for $1$ year, $2$ years and $3$ years respectively. All three amounts at the end of their periods are equal. How much, in rupees, is the part invested for $2$ years?",
  "TITA",
  r"Let the common amount be $M$. The parts are $\frac{M}{1.2}$, $\frac{M}{1.44}$, $\frac{M}{1.728}$, in ratio $1.44 : 1.2 : 1 = 36 : 30 : 25$. The total ratio is $91$, so one unit is $\frac{36400}{91} = 400$. The two-year part is $30 \times 400 = 12000$ rupees.",
  "Reporting the wrong part or the common amount.",
  "C03B-split-sum", "Three-way split with ratio derived from discount factors.",
  tita_answer=12000, check=_c29,
  tita_traps=[(14400, r"Reports the part invested for $1$ year."),
              (10000, r"Reports the part invested for $3$ years."),
              (17280, r"Reports the common final amount.")],
  exams=CX, cognitive="Analysis")


def _c30():
    P, r = symbols('P r', positive=True)
    sol = solve([Eq(2 * P * r, 3200), Eq(P * (1 + r) ** 3 - P, 5824)], [P, r], dict=True)
    return [s[P] for s in sol if s[r] > 0][0]
q("C03-B-030", T, "Sum from 2-year SI and 3-year CI at the same rate", "Difficult",
  "Inverse/parameter",
  r"On the same sum and at the same rate per annum, the simple interest for $2$ years is Rs. $3{,}200$ and the compound interest (compounded annually) for $3$ years is Rs. $5{,}824$. What is the sum?",
  "MCQ",
  r"With $r$ as a decimal, one year's simple interest is $Pr = 1600$. Three-year CI $= P\left[(1 + r)^3 - 1\right] = Pr(3 + 3r + r^2)$, so $3 + 3r + r^2 = \frac{5824}{1600} = 3.64$, that is $r^2 + 3r - 0.64 = 0 = (r - 0.2)(r + 3.2)$. So $r = 20\%$ and $P = \frac{1600}{0.2} =$ Rs. $8{,}000$. Check: $8000 \times 1.728 - 8000 = 5824$.",
  "Applying the two-year interest-on-interest shortcut to a three-year excess, or dropping the cubic term.",
  "C03B-si-ci-mixed-periods", "The interests cover different periods, so the first-year-interest shortcut fails; needs the three-year CI as $Pr(3 + 3r + r^2)$ and a quadratic.",
  correct=r"Rs. $8{,}000$",
  distractors=[(r"Rs. $7{,}500$", r"Drops the $r^3$ term: excess over the $3$-year SI $4800$ is $1024 = 3Pr^2$, so $r = \frac{1024}{4800}$ and $P = \frac{1600}{r} = 7500$."),
               (r"Rs. $16{,}000$", r"Finds $20\%$ but divides the two-year SI by it without halving: $\frac{3200}{0.2}$."),
               (r"Rs. $2{,}500$", r"Treats the excess $5824 - 4800 = 1024$ as interest on one year's interest $1600$, so $r = 64\%$ and $P = \frac{1600}{0.64}$.")],
  check=_c30, values=[8000, 7500, 16000, 2500], exams=CX, cognitive="Analysis")


def _c31():
    P = F(160000)
    owed = amt(P, 5, 4)                 # 10% p.a. half-yearly for 2 years
    y1 = P * F(11, 100)                 # Priya's interest, end of year 1
    y2 = P * F(11, 100)                 # Priya's interest, end of year 2
    deposit = amt(y1, 5, 2)             # year-1 interest at 10% p.a. half-yearly for 1 year
    return deposit + y2 + P - owed
q("C03-B-031", T, "Gain from borrowing at half-yearly CI, lending at SI and reinvesting the interest", "Difficult",
  "Multi-step word problem",
  r"Arjun borrows Rs. $1{,}60{,}000$ for exactly $2$ years at $10\%$ per annum, compounded half-yearly, to be repaid in full at the end. He immediately lends the whole amount to Priya for $2$ years at $11\%$ per annum simple interest; Priya pays the interest for each year at the end of that year and returns the principal at the end of $2$ years. Arjun deposits the interest received at the end of the first year in a bank at $10\%$ per annum, compounded half-yearly, for the remaining year. After settling his loan at the end of $2$ years, what is Arjun's net gain?",
  "MCQ",
  r"He owes $160000 \times 1.05^4 = 160000 \times 1.21550625 = 194481$. Priya pays $17600$ at the end of each year. The first payment grows to $17600 \times 1.05^2 = 17600 \times 1.1025 = 19404$. At the end he holds $19404 + 17600 + 160000 = 197004$. Net gain $= 197004 - 194481 =$ Rs. $2{,}523$.",
  "Ignoring the growth of the reinvested interest, or compounding the borrowing annually.",
  "C03B-borrow-lend", "Three stages under three rules: half-yearly compounding on the loan, simple interest received yearly, and reinvestment of the first year's interest.",
  correct=r"Rs. $2{,}523$",
  distractors=[(r"Rs. $719$", r"Ignores the reinvestment and compares $35200$ of interest with $34481$."),
               (r"Rs. $2{,}479$", r"Grows the reinvested $17600$ at $10\%$ simple interest to $19360$: $196960 - 194481$."),
               (r"Rs. $3{,}404$", r"Compounds the borrowing annually, owing $193600$: $197004 - 193600$.")],
  check=_c31, values=[2523, 719, 2479, 3404], exams=CX, cognitive="Analysis")


def _c32():
    P = 200000
    plans = [amt(P, 10, 4) - P,             # 20% p.a. half-yearly
             amt(P, F(43, 2), 2) - P,       # 21.5% p.a. annually
             F(P) * F(23, 100) * 2]         # 23% simple
    return max(plans) - min(plans)
q("C03-B-032", T, "Comparing three deposit plans with different compounding", "Difficult",
  "Casework/optimisation",
  r"Ananya has Rs. $2{,}00{,}000$ to deposit for exactly $2$ years. Plan Kosh pays $20\%$ per annum compounded half-yearly, Plan Nidhi pays $21.5\%$ per annum compounded annually, and Plan Sarvam pays $23\%$ per annum simple interest. By how much does the interest from the best plan exceed the interest from the worst plan?",
  "MCQ",
  r"Kosh: $200000(1.1^4 - 1) = 200000 \times 0.4641 = 92820$. Nidhi: $200000(1.215^2 - 1) = 200000 \times 0.476225 = 95245$. Sarvam: $200000 \times 0.23 \times 2 = 92000$. Best is Nidhi and worst is Sarvam, despite its highest nominal rate; difference $=$ Rs. $3{,}245$.",
  "Ranking plans by nominal rate, or mishandling one compounding rule.",
  "C03B-plan-comparison", "Three computations under three different rules, then a ranking with close values where the highest nominal rate is worst.",
  correct=r"Rs. $3{,}245$",
  distractors=[(r"Rs. $2{,}425$", r"Ranks Sarvam above Kosh on its higher nominal rate and takes Kosh as worst: $95245 - 92820$."),
               (r"Rs. $7{,}245$", r"Treats Kosh as $20\%$ compounded annually ($88000$), making it worst: $95245 - 88000$."),
               (r"Rs. $6{,}820$", r"Computes Nidhi as simple interest ($86000$), so Kosh is best and Nidhi worst: $92820 - 86000$.")],
  check=_c32, values=[3245, 2425, 7245, 6820], exams=CX, cognitive="Analysis")


def _c33():
    P = 100000
    arjun = amt(P, 20, 2) * (1 + F(10, 100))      # final half-year: half the annual rate, simple
    fatima = amt(P, 10, 5)
    return fatima - arjun
q("C03-B-033", T, "Half-yearly compounding versus annual compounding over 2.5 years", "Medium",
  "Multi-step word problem",
  r"Arjun and Fatima each borrow Rs. $1{,}00{,}000$ at $20\%$ per annum for $2\frac{1}{2}$ years. Arjun's loan is compounded annually, and for the final half-year he is charged simple interest at $20\%$ per annum, that is $10\%$ of the amount due at the end of $2$ years. Fatima's loan is compounded half-yearly throughout. By how much do Fatima's final dues exceed Arjun's?",
  "MCQ",
  r"Arjun: $100000 \times 1.2^2 \times 1.1 = 144000 \times 1.1 = 158400$. Fatima: $100000 \times 1.1^5 = 161051$. Difference $=$ Rs. $2{,}651$.",
  "Comparing over the wrong period or with simple interest.",
  "C03B-fractional-year", "Two direct products under two conventions, one with a part-year simple-interest rule; about two minutes.",
  correct=r"Rs. $2{,}651$",
  distractors=[(r"Rs. $2{,}410$", r"Compares only the first $2$ years: $146410 - 144000$."),
               (r"Rs. $11{,}051$", r"Compares Fatima's dues with simple interest, $150000$."),
               (r"Rs. $11{,}749$", r"Compounds Arjun's loan for $3$ full years ($172800$) and reports the size of the gap to Fatima's $161051$, ignoring which is larger: $172800 - 161051$.")],
  check=_c33, values=[2651, 2410, 11051, 11749], exams=CX, cognitive="Analysis")


def _c34():
    n = 0
    ravi, meera = F(10000), F(15000)
    while not ravi > meera:
        n += 1
        ravi = ravi * F(12, 10)                      # 20% p.a. annually
        meera = meera * F(105, 100) * F(105, 100)    # 10% p.a. half-yearly
    return n
q("C03-B-034", T, "Years until a smaller sum at a higher rate overtakes a larger sum compounded half-yearly", "Difficult",
  "Casework/optimisation",
  r"On the same day, Ravi invests Rs. $10{,}000$ at $20\%$ per annum compounded annually and Meera invests Rs. $15{,}000$ at $10\%$ per annum compounded half-yearly. Neither withdraws anything. At the end of how many complete years is Ravi's amount greater than Meera's for the first time?",
  "MCQ",
  r"Each year Ravi's amount is multiplied by $1.2$ and Meera's by $1.05^2 = 1.1025$, so Ravi gains by the factor $\frac{1.2}{1.1025} \approx 1.0884$ a year and must make up the factor $1.5$. Directly: after $4$ years Ravi has $10000 \times 2.0736 = 20736$ and Meera has $15000 \times 1.05^8 \approx 22162$; after $5$ years Ravi has $24883.2$ and Meera has $15000 \times 1.05^{10} \approx 24433$. The answer is $5$ years.",
  "Ignoring the growth of the larger sum, reading the half-yearly rate as an annual rate, or using simple interest.",
  "C03B-overtaking-sums", "Two sums under different rates and compounding conventions; a ratio of growth factors must be tracked across years with a near-miss at $4$.",
  correct=r"$5$ years",
  distractors=[(r"$4$ years", r"Takes Meera's half-yearly rate $5\%$ as her annual rate: $\left(\frac{1.2}{1.05}\right)^4 \approx 1.71 > 1.5$ while the cube is below $1.5$."),
               (r"$3$ years", r"Ignores the growth of Meera's sum and waits for Ravi to pass Rs. $15{,}000$: $1.2^3 = 1.728$."),
               (r"$11$ years", r"Uses simple interest: $10000 + 2000n > 15000 + 1500n$ first holds at $n = 11$.")],
  check=_c34, values=[5, 4, 3, 11], exams=CX, cognitive="Analysis")


def _c35():
    P, k = symbols('P k', positive=True)   # k = (1+r)^2
    s = solve([Eq(P * k, 14400), Eq(P * k ** 2, 20736)], [P, k], dict=True)[0]
    r = sqrt(s[k]) - 1
    return s[P] * r * 4
q("C03-B-035", T, "Simple interest on a sum identified from CI amounts after 2 and 4 years", "Difficult",
  "Multi-step word problem",
  r"A sum invested at compound interest, compounded annually at a fixed rate, amounts to Rs. $14{,}400$ after $2$ years and Rs. $20{,}736$ after $4$ years. What would the simple interest on the same sum at the same rate be for $4$ years?",
  "MCQ",
  r"Over two years the amount is multiplied by $\frac{20736}{14400} = 1.44 = 1.2^2$, so $r = 20\%$. The sum is $\frac{14400}{1.44} = 10000$. Simple interest for $4$ years $= 10000 \times 0.2 \times 4 =$ Rs. $8{,}000$.",
  "Treating the growth between the two amounts as simple interest, or using the wrong base.",
  "C03B-consecutive-amounts", "Square root of a two-year factor, back-discounting, then a switch to SI.",
  correct=r"Rs. $8{,}000$",
  distractors=[(r"Rs. $12{,}672$", r"Treats the growth $20736 - 14400 = 6336$ as two years of simple interest and doubles it."),
               (r"Rs. $10{,}736$", r"Gives the compound interest for $4$ years, $20736 - 10000$."),
               (r"Rs. $11{,}520$", r"Takes simple interest on $14400$: $14400 \times 0.2 \times 4$.")],
  check=_c35, values=[8000, 12672, 10736, 11520], exams=CX, cognitive="Analysis")
