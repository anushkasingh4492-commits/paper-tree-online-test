import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T_INT = "Integrated journeys"
T_SND = "Sound and signals"
ALL = EXAMS
HARD = ("CAT", "XAT")


def _pos(sols):
    return [s for s in sols if s.is_positive]


# ---------------------------------------------------------------- 001
def _c001():
    d, c = 160, 320
    delay = Fraction(d, c)
    recorded = Fraction(213, 10)
    return recorded + delay
q("C08-F-001", T_SND, "Timekeeper starts the watch on hearing the gun instead of seeing the smoke", "Easy",
  "Conceptual/application",
  r"In a $160$ m race on a straight track, the timekeeper stands at the finish line. The starter's gun is fired at the start line, and the timekeeper starts his stopwatch when he hears the shot instead of when he sees the smoke. The speed of sound is $320$ m/s and light reaches him instantly. He records the winner's time as $21.3$ s. What is the winner's actual time?",
  "MCQ",
  r"The sound takes $\frac{160}{320} = 0.5$ s to reach the finish line, so the watch was started $0.5$ s after the runners actually set off. The recorded time is therefore $0.5$ s too short, and the actual time is $21.3 + 0.5 = 21.8$ s.",
  "Subtracting the sound delay, as if the watch had started early.",
  "C08F-sound-delay-timing", "One idea: the watch starts late by the sound travel time; the trap is the direction of the correction.",
  correct=r"$21.8$ s",
  distractors=[(r"$20.8$ s", "Subtracts the $0.5$ s delay: $21.3 - 0.5$."),
               (r"$21.3$ s", "Ignores the time sound takes to travel $160$ m."),
               (r"$22.3$ s", "Adds the delay twice, $21.3 + 2 \\times 0.5$, as if the sound made a round trip.")],
  check=_c001, values=[Fraction(218, 10), Fraction(208, 10), Fraction(213, 10), Fraction(223, 10)],
  cognitive="Understanding", assumptions=["Light travel time negligible"], exams=ALL)

# ---------------------------------------------------------------- 002
def _c002():
    d = symbols('d', positive=True)
    return _pos(solve(Eq(2 * d, 330 * 3), d))[0]
q("C08-F-002", T_SND, "Echo from a cliff, stationary listener", "Easy",
  "Single-step computation",
  r"Joseph stands facing a vertical cliff and claps once. He hears the echo of the clap $3$ s later. If the speed of sound is $330$ m/s, how far is Joseph from the cliff, in metres?",
  "TITA",
  r"In $3$ s the sound travels $330 \times 3 = 990$ m. This is the trip to the cliff and back, so the distance to the cliff is $\frac{990}{2} = 495$ m.",
  "Forgetting that the echo covers the distance twice.",
  "C08F-echo-stationary", "Single step; the only trap is the round trip.",
  tita_answer=495, check=_c002,
  tita_traps=[(990, "Does not halve the round-trip distance."), (110, "Divides $330$ by $3$ instead of multiplying.")],
  cognitive="Understanding", exams=ALL)

# ---------------------------------------------------------------- 003
def _c003():
    D = symbols('D', positive=True)
    u, c, t = 20, 340, 4
    # sound out and back: D + (D - u t) = c t
    return _pos(solve(Eq(D + (D - u * t), c * t), D))[0]
q("C08-F-003", T_SND, "Car approaching a cliff sounds its horn and hears the echo", "Medium",
  "Multi-step word problem",
  r"A car moves at a constant $20$ m/s straight towards a vertical cliff. The driver sounds the horn once and hears its echo $4$ s later. The speed of sound is $340$ m/s. How far from the cliff was the car when the horn was sounded?",
  "MCQ",
  r"Let the distance be $D$ m. In $4$ s the sound goes to the cliff and comes back to the car, which has moved $20 \times 4 = 80$ m closer. So the sound covers $D + (D - 80) = 340 \times 4 = 1360$ m, giving $2D = 1440$ and $D = 720$ m. Quick route: sound and car together cover $2D$, so $2D = (340 + 20) \times 4$.",
  "Treating the car as stationary, or reporting the distance at the moment the echo is heard.",
  "C08F-echo-moving-source", "Two ideas: the round trip and the listener moving during it.",
  correct=r"$720$ m",
  distractors=[(r"$680$ m", "Treats the car as stationary: $\\frac{340 \\times 4}{2}$."),
               (r"$640$ m", "Gives the distance from the cliff when the echo is heard, $720 - 80$."),
               (r"$1440$ m", "Does not halve: $(340 + 20) \\times 4$.")],
  check=_c003, values=[720, 680, 640, 1440], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 004
def _c004():
    c = 340
    d1 = Fraction(c * 2, 2)
    d2 = Fraction(c * 5, 2)
    return d1 + d2
q("C08-F-004", T_SND, "Listener between two parallel cliffs hears two echoes", "Medium",
  "Multi-step word problem",
  r"Harpreet stands between two parallel vertical cliffs, on the straight line perpendicular to both, and bursts a cracker. She hears the first echo $2$ s after the burst and the second echo $5$ s after the burst. The speed of sound is $340$ m/s. What is the distance between the two cliffs, in metres?",
  "TITA",
  r"The nearer cliff is $\frac{340 \times 2}{2} = 340$ m away and the farther cliff is $\frac{340 \times 5}{2} = 850$ m away, on the opposite side. The cliffs are $340 + 850 = 1190$ m apart. In one line: $\frac{340 \times (2 + 5)}{2} = 1190$.",
  "Measuring the second echo time from the first echo, or not halving.",
  "C08F-echo-two-cliffs", "Two echoes, each a round trip; the times must be read from the burst.",
  tita_answer=1190, check=_c004,
  tita_traps=[(2380, "Does not halve the round trips: $340 \\times 7$."),
              (850, "Gives only the distance to the farther cliff, $\\frac{340 \\times 5}{2}$ (the same value also comes from using $5 - 2 = 3$ s for the second echo: $340 + 510$)."),
              (340, "Gives only the distance to the nearer cliff, $\\frac{340 \\times 2}{2}$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 005
def _c005():
    c, u, T = 330, 30, Fraction(11, 2)
    D = 2000  # any initial distance large enough
    start_heard = Fraction(D, c)
    end_heard = T + Fraction(D - u * T, c)
    return end_heard - start_heard
q("C08-F-005", T_SND, "Duration of a whistle heard from an approaching train", "Medium",
  "Conceptual/application",
  r"A train approaches a station at a constant $30$ m/s and blows its whistle continuously for $5.5$ s. The stationmaster stands on the platform ahead of the train, and the train is still approaching him when the whistle stops. The speed of sound is $330$ m/s. For how long does the stationmaster hear the whistle?",
  "MCQ",
  r"During the $5.5$ s the train moves $30 \times 5.5 = 165$ m closer, so the sound emitted last has $165$ m less to travel, which saves $\frac{165}{330} = 0.5$ s. The whistle is heard for $5.5 - 0.5 = 5$ s.",
  "Ignoring the motion of the source, or applying the receding case.",
  "C08F-moving-source-duration", "Needs the idea that the end of the sound is emitted closer to the listener.",
  correct=r"$5$ s",
  distractors=[(r"$6$ s", "Adds the $0.5$ s, the case of a train moving away."),
               (r"$5.5$ s", "Ignores the motion of the train."),
               (r"$6.05$ s", "Scales by $\\frac{330}{300}$, inverting the ratio: $5.5 \\times \\frac{330}{300}$.")],
  check=_c005, values=[5, 6, Fraction(11, 2), Fraction(605, 100)], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 006
def _c006():
    v, D = symbols('v D', positive=True)
    c, gap = 330, 680  # seconds between shots
    t1 = D / (c + v)
    t2 = gap + (D - v * gap) / (c + v)
    sol = _pos(solve(Eq(simplify(t2 - t1), 660), v))
    return sol[0] * Rational(18, 5)
q("C08-F-006", T_SND, "Two shots heard closer together by a listener moving towards the gun", "Medium",
  "Inverse/parameter",
  r"Two guns are fired from a fort $11$ minutes $20$ seconds apart. Kabir is driving straight towards the fort at a constant speed and hears the two shots $11$ minutes apart. He is still short of the fort when he hears the second shot. The speed of sound is $330$ m/s. What is the speed of the car, in km/h?",
  "TITA",
  r"The second shot is heard $20$ s earlier than it would be by a stationary listener. In the $660$ s between hearing the shots, the car covers the distance that sound would have needed $20$ s to cover: $660v = 330 \times 20$, so $v = 10$ m/s $= 10 \times \frac{18}{5} = 36$ km/h.",
  "Forgetting to convert m/s to km/h, or using the firing interval instead of the hearing interval.",
  "C08F-shots-moving-observer", "Requires the insight that the car's travel in the hearing interval equals the sound's travel in the time saved.",
  tita_answer=36, check=_c006,
  tita_traps=[(10, "Gives the speed in m/s.")],
  cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 007
def _c007():
    u = symbols('u', positive=True)
    c = 330
    D1 = Rational(6, 2) * (c + u)       # 2*D1 = (c+u)*6
    D2 = D1 - 6 * u                      # where the second horn is sounded
    sol = _pos(solve(Eq(2 * D2, (c + u) * 5), u))
    return sol[0] * Rational(18, 5)
q("C08-F-007", T_SND, "Two successive echoes heard by a driver approaching a hill", "Difficult",
  "Inverse/parameter",
  r"A car moves at a constant speed straight towards a vertical hill face. The driver sounds the horn and hears the echo $6$ s later. At the instant he hears it, he sounds the horn again, and hears this second echo $5$ s after sounding it. The speed of sound is $330$ m/s. What is the speed of the car, in km/h?",
  "TITA",
  r"Let the car's speed be $u$ m/s. For an approaching car, sound and car together cover twice the distance: first distance $= 3(330 + u)$. After $6$ s the car is $3(330 + u) - 6u = 990 - 3u$ away, and the second echo gives $2(990 - 3u) = 5(330 + u)$. So $1980 - 6u = 1650 + 5u$, $u = 30$ m/s $= 108$ km/h.",
  "Treating the car as stationary for each echo and only then comparing the two distances.",
  "C08F-echo-moving-source", "Two linked echo equations with the car's own motion in each; then a unit conversion.",
  tita_answer=108, check=_c007,
  tita_traps=[(30, "Gives the speed in m/s."),
              (99, "Ignores the car's motion in each echo: distances $990$ m and $825$ m, so $165$ m in $6$ s $= 27.5$ m/s.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 008
def _c008():
    c = 330
    d1, d2 = c * 15, c * 5
    v = Fraction(d1 - d2, 11 * 60)
    return v * Fraction(18, 5)
q("C08-F-008", T_SND, "Speed of an approaching storm from the thunder delay", "Easy",
  "Multi-step word problem",
  r"Sneha sees a lightning flash and hears the thunder $15$ s later. The next flash, $11$ minutes after the first, is followed by thunder $5$ s after it. The storm moves straight towards her at a constant speed. The speed of sound is $330$ m/s and light reaches her instantly. What is the speed of the storm?",
  "MCQ",
  r"The storm was $330 \times 15 = 4950$ m away and then $330 \times 5 = 1650$ m away, so it moved $3300$ m in $660$ s. That is $5$ m/s $= 5 \times \frac{18}{5} = 18$ km/h.",
  "Using one distance instead of the change in distance, or leaving the speed in m/s.",
  "C08F-thunder-gap-storm-speed", "Two direct distance computations and a unit conversion.",
  correct=r"$18$ km/h",
  distractors=[(r"$5$ km/h", "Reports the speed in m/s with a km/h label."),
               (r"$9$ km/h", "Uses only the second distance: $\\frac{1650}{660} = 2.5$ m/s."),
               (r"$27$ km/h", "Uses only the first distance: $\\frac{4950}{660} = 7.5$ m/s.")],
  check=_c008, values=[18, 5, 9, 27], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 009
def _c009():
    c = 340
    r, m = c * 3, c * 4
    return sqrt(r ** 2 + m ** 2)
q("C08-F-009", T_SND, "Two listeners on perpendicular lines hear the same burst", "Easy",
  "Conceptual/application",
  r"A firecracker bursts at a point O. Ravi stands due north of O and hears the burst $3$ s after it happens; Meera stands due east of O and hears it $4$ s after it happens. The speed of sound is $340$ m/s. What is the straight-line distance between Ravi and Meera, in metres?",
  "TITA",
  r"Ravi is $340 \times 3 = 1020$ m from O and Meera is $340 \times 4 = 1360$ m from O, at right angles. The distance is $\sqrt{1020^2 + 1360^2} = 340 \times 5 = 1700$ m.",
  "Adding the two distances instead of using Pythagoras.",
  "C08F-sound-two-listeners", "Two short steps, with a 3-4-5 triangle hidden in the times.",
  tita_answer=1700, check=_c009,
  tita_traps=[(2380, "Adds the distances: $1020 + 1360$."), (340, "Subtracts the distances.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 010
def _c010():
    d = symbols('d', positive=True)
    return _pos(solve(Eq(d / 340 - d / 5100, Rational(14, 10)), d))[0]
q("C08-F-010", T_SND, "Hammer blow heard twice, through a steel rail and through air", "Medium",
  "Inverse/parameter",
  r"A worker strikes a long steel rail once with a hammer. Fatima, standing beside the same rail some distance away, hears the blow twice: first through the rail and then through the air, $1.4$ s apart. Sound travels at $5100$ m/s in steel and $340$ m/s in air. How far is Fatima from the point where the rail was struck, in metres?",
  "TITA",
  r"Let the distance be $d$ m. Then $\frac{d}{340} - \frac{d}{5100} = 1.4$. Since $5100 = 15 \times 340$, this is $\frac{14d}{5100} = 1.4$, so $d = 510$ m.",
  "Multiplying the time gap by one speed or by the difference of the speeds.",
  "C08F-sound-two-media", "One equation in one unknown, with a ratio shortcut.",
  tita_answer=510, check=_c010,
  tita_traps=[(476, "Uses only the air speed: $340 \\times 1.4$."),
              (6664, "Multiplies the gap by the speed difference: $(5100 - 340) \\times 1.4$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 011
def _c011():
    x = symbols('x', positive=True)
    D, w, b = 24, 4, 12
    xs = solve(Eq(x / b + (D - x) / w, x / w + (D - x) / b), x)[0]
    return xs / b + (D - xs) / w
q("C08-F-011", T_INT, "Two people share one bicycle to arrive together, equal speeds", "Easy",
  "Conceptual/application",
  r"Arjun and Meera must go from P to Q, $24$ km apart, and have one bicycle that can carry only one person. Each walks at $4$ km/h and cycles at $12$ km/h. They start together; Arjun cycles part of the way, leaves the bicycle by the road and walks on, while Meera walks to the bicycle and cycles the rest. They plan this so that both reach Q at the same time. How long does the journey take?",
  "MCQ",
  r"Their speeds are identical, so to arrive together each must cycle the same distance, $12$ km, and walk the other $12$ km. Time $= \frac{12}{12} + \frac{12}{4} = 1 + 3 = 4$ hours.",
  "Averaging the two speeds as if each mode were used for half the time.",
  "C08F-shared-bicycle", "One symmetry idea and a two-term time sum.",
  correct=r"$4$ hours",
  distractors=[(r"$3$ hours", "Uses the average speed $\\frac{4 + 12}{2} = 8$ km/h for $24$ km."),
               (r"$6$ hours", "Takes the walking time for the whole distance."),
               (r"$2$ hours", "Takes the cycling time for the whole distance.")],
  check=_c011, values=[4, 3, 6, 2], cognitive="Understanding", exams=ALL)

# ---------------------------------------------------------------- 012
def _c012():
    x = symbols('x', positive=True)
    D, b = 30, 15
    sol = solve(Eq(x / b + (D - x) / 5, x / 3 + (D - x) / b), x)
    xs = sol[0]
    assert xs / 15 <= xs / 3  # bicycle is waiting when Priya arrives
    return xs
q("C08-F-012", T_INT, "Shared bicycle with unequal walking speeds: where to leave it", "Medium",
  "Inverse/parameter",
  r"Ravi and Priya must travel $30$ km from P to Q with one bicycle that carries one person. Both cycle at $15$ km/h; Ravi walks at $5$ km/h and Priya at $3$ km/h. They start together from P. Ravi cycles to some point, leaves the bicycle there and walks on to Q; Priya walks to that point and cycles the rest of the way. If both reach Q at the same time, how many km from P does Ravi leave the bicycle?",
  "TITA",
  r"Let the point be $x$ km from P. Ravi's time is $\frac{x}{15} + \frac{30 - x}{5}$ and Priya's is $\frac{x}{3} + \frac{30 - x}{15}$. Multiplying by $15$: $x + 90 - 3x = 5x + 30 - x$, so $6x = 60$ and $x = 10$. Each then takes $4\frac{2}{3}$ hours, and the bicycle is waiting when Priya reaches it.",
  "Splitting the distance equally although the walking speeds differ.",
  "C08F-shared-bicycle", "Unequal speeds break the symmetry; one linear equation must be set up.",
  tita_answer=10, check=_c012,
  tita_traps=[(15, "Assumes each cycles half the distance."), (20, "Gives the distance Priya cycles.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 013
def _c013():
    D, w, b = 30, 5, 15
    seg = Fraction(D, 3)
    # rider 1: rides 0..10 then walks; rider 2 walks to 10, rides to 20, walks; rider 3 walks to 20 and rides
    t1 = seg / b + (D - seg) / w
    t2 = seg / w + seg / b + seg / w
    t3 = 2 * seg / w + seg / b
    # bicycle available in time at each hand-over
    assert seg / b <= seg / w and seg / w + seg / b <= 2 * seg / w
    assert t1 == t2 == t3
    return t1 * 60
q("C08-F-013", T_INT, "Three people relay one bicycle forward to arrive together", "Medium",
  "Conceptual/application",
  r"Three friends must travel $30$ km from P to Q with a single bicycle that carries one person. Each walks at $5$ km/h and cycles at $15$ km/h. They start together from P. The bicycle only ever moves towards Q: whoever is riding it leaves it at the roadside for the next friend and walks on. They plan the hand-overs so that all three reach Q at the same time. How long does the journey take?",
  "MCQ",
  r"The bicycle covers the $30$ km once, ridden forward, so the riding distances add up to $30$ km. Equal speeds and equal arrival times force equal riding distances of $10$ km each. Time $= \frac{10}{15} + \frac{20}{5} = \frac{2}{3} + 4$ hours $= 4$ hours $40$ minutes. The bicycle is always waiting at each hand-over point, since cycling is faster than walking.",
  "Reusing the two-person split, in which each rides half the distance.",
  "C08F-shared-bicycle", "Extends the two-person idea to a relay; must see that riding distances total the route length.",
  correct=r"$4$ hours $40$ minutes",
  distractors=[(r"$4$ hours", "Uses the two-person split, $\\frac{15}{15} + \\frac{15}{5}$."),
               (r"$6$ hours", "Takes the walking time for the whole distance."),
               (r"$3$ hours", "Uses the average speed $\\frac{5 + 15}{2} = 10$ km/h.")],
  check=_c013, values=[280, 240, 360, 180], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 014
def _c014():
    x, t = symbols('x t', positive=True)
    D, v, w = 60, 50, 10
    # van drops group 1 at x, returns, meets group 2 (walking since start) at time t
    t_drop = x / v
    meet_pos = w * t
    eq1 = Eq(x - v * (t - t_drop), meet_pos)
    tm = solve(eq1, t)[0]
    total2 = tm + (D - w * tm) / v
    total1 = t_drop + (D - x) / w
    xs = _pos(solve(Eq(total1, total2), x))[0]
    return total1.subs(x, xs) * 60
q("C08-F-014", T_INT, "Van ferries two halves of a group so that all arrive together", "Difficult",
  "Multi-step word problem",
  r"A group of students must travel $60$ km from P to Q. Their van can carry only half of them at a time. The van takes the first half part of the way, drops them to walk on to Q, drives back and picks up the second half, who have been walking towards Q since the start, and carries them to Q. The van runs at $50$ km/h and everyone walks at $10$ km/h; ignore time spent boarding and turning. The drop-off point is chosen so that both halves reach Q at the same time. How long does the journey take?",
  "MCQ",
  r"Both halves arrive together, so each rides the same distance $x$ and walks $60 - x$. When the van drops the first half at $x$, the walkers are at $\frac{x}{5}$; the gap $\frac{4x}{5}$ closes at $60$ km/h, and they meet at $\frac{x}{5} + 10 \times \frac{4x}{300} = \frac{x}{3}$. The second half walks this $\frac{x}{3}$ km and rides $x$ km, so $\frac{x}{3} + x = 60$, $x = 45$. Time $= \frac{45}{50} + \frac{15}{10} = 2.4$ hours $= 2$ hours $24$ minutes.",
  "Fixing the drop-off point by guesswork instead of from the equal-arrival condition.",
  "C08F-van-ferry-groups", "Needs the symmetric model, the return-meeting point and an equation; about four stages.",
  correct=r"$2$ hours $24$ minutes",
  distractors=[(r"$3$ hours $36$ minutes", "Drops the first half at the midpoint and computes their time, $\\frac{30}{50} + \\frac{30}{10}$."),
               (r"$2$ hours $48$ minutes", "Lets the van take the first half all the way to Q, return to meet the walkers at $20$ km and then carry them $40$ km."),
               (r"$2$ hours", "Uses the average speed $\\frac{50 + 10}{2} = 30$ km/h for $60$ km.")],
  check=_c014, values=[144, 216, 168, 120], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 015
def _c015():
    x, t = symbols('x t', positive=True)
    D, v, w = 36, 36, 4
    t_drop = x / v
    tm = solve(Eq(x - v * (t - t_drop), w * t), t)[0]
    total2 = tm + (D - w * tm) / v
    total1 = t_drop + (D - x) / w
    xs = _pos(solve(Eq(total1, total2), x))[0]
    return w * tm.subs(x, xs)
q("C08-F-015", T_INT, "Jeep shuttle: where the second group is picked up", "Difficult",
  "Inverse/parameter",
  r"Eight trekkers must reach a base camp $36$ km away along a road. A jeep that can carry only four of them takes the first four part of the way, leaves them to walk the rest, and immediately drives back to collect the other four, who have been walking towards the camp since the start; it then carries them to the camp. The jeep runs at $36$ km/h and all trekkers walk at $4$ km/h; ignore stopping and turning time. Both groups reach the camp at the same time. How many km from the start are the second four picked up?",
  "TITA",
  r"Equal arrival means each group rides the same $x$ km. At the drop-off the walkers are at $\frac{x}{9}$; the gap $\frac{8x}{9}$ closes at $40$ km/h in $\frac{x}{45}$ h, during which they walk $\frac{4x}{45}$ more, so the pick-up is at $\frac{x}{9} + \frac{4x}{45} = \frac{x}{5}$. Then $\frac{x}{5} + x = 36$ gives $x = 30$ and the pick-up point is $6$ km from the start.",
  "Confusing the drop-off point with the pick-up point.",
  "C08F-van-ferry-groups", "Return-trip meeting combined with the equal-arrival condition.",
  tita_answer=6, check=_c015,
  tita_traps=[(30, "Gives the drop-off point of the first group.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 016
def _c016():
    x = symbols('x', positive=True)
    D = 180
    kabir = Rational(D, 45)
    return _pos(solve(Eq(x / 40 + (D - x) / 60, kabir), x))[0]
q("C08-F-016", T_INT, "Point at which a driver speeds up so as to arrive together with a steady driver", "Easy",
  "Inverse/parameter",
  r"Meera and Kabir leave P together for Q, $180$ km away, along the same road. Kabir drives at a steady $45$ km/h. Meera drives at $40$ km/h up to a certain point and at $60$ km/h for the rest of the way, and the two reach Q at the same time. How far from P does Meera increase her speed?",
  "MCQ",
  r"Kabir takes $\frac{180}{45} = 4$ hours, so Meera's average speed must be $45$ km/h over $4$ hours. By alligation her times at $40$ km/h and $60$ km/h are in the ratio $(60 - 45) : (45 - 40) = 3 : 1$, that is $3$ hours and $1$ hour. She covers $40 \times 3 = 120$ km before speeding up. Check: $\frac{120}{40} + \frac{60}{60} = 4$ hours.",
  "Applying the alligation ratio to distances instead of times.",
  "C08F-speed-change-point", "One equation (or one alligation), with a distance-versus-time trap.",
  correct=r"$120$ km",
  distractors=[(r"$60$ km", "Gives the length of the stretch driven at $60$ km/h (the same value comes from swapping the two speeds)."),
               (r"$135$ km", "Applies the $3 : 1$ alligation ratio to the distances: $\\frac{3}{4} \\times 180$."),
               (r"$40$ km", "Inverts the time ratio to $1 : 3$, so she drives only $1$ hour at $40$ km/h.")],
  check=_c016, values=[120, 60, 135, 40], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 017
def _c017():
    d, T = symbols('d T', positive=True)
    sol = solve([Eq(d / 40, T + Rational(1, 6)), Eq(1 + (d - 40) / 60, T - Rational(1, 6))], [d, T], dict=True)
    return sol[0][d]
q("C08-F-017", T_INT, "Late at one speed, early after speeding up after the first hour: find the distance", "Medium",
  "Inverse/parameter",
  r"Kabir must reach a meeting at a fixed time. If he drives at $40$ km/h all the way, he is $10$ minutes late. Instead he drives at $40$ km/h for the first hour and at $60$ km/h for the rest of the way, and arrives $10$ minutes early. How long is the journey?",
  "MCQ",
  r"Let the distance be $d$ km. The two plans differ by $20$ minutes: $\frac{d}{40} - \left(1 + \frac{d - 40}{60}\right) = \frac{1}{3}$. Multiplying by $120$: $3d - 120 - 2d + 80 = 40$, so $d = 80$ km. Check: $2$ hours versus $1$ hour $40$ minutes.",
  "Ignoring that the first hour is driven at $40$ km/h in both plans.",
  "C08F-speed-change-point", "Two scenarios to compare; the common first hour must be handled.",
  correct=r"$80$ km",
  distractors=[(r"$64$ km", "Takes the $20$ minute difference as $0.2$ h."),
               (r"$100$ km", "Double counts the lateness, taking the gap between the plans as $10 + 20 = 30$ minutes: $\\frac{d}{40} - 1 - \\frac{d - 40}{60} = \\frac{1}{2}$ gives $d - 40 = 60$."),
               (r"$60$ km", "Uses a $10$ minute difference between the two plans.")],
  check=_c017, values=[80, 64, 100, 60], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 018
def _c018():
    v, R = symbols('v R', positive=True)
    s = solve([Eq(R / (Rational(3, 4) * v) - R / v, Rational(35, 60)),
               Eq((R - 24) / (Rational(3, 4) * v) - (R - 24) / v, Rational(25, 60))], [v, R], dict=True)
    return 50 + s[0][R]
q("C08-F-018", T_INT, "Bus slows after a fault; a later fault would cause less delay", "Medium",
  "Multi-step word problem",
  r"A bus travels from P to Q at a constant speed. After covering $50$ km it develops an engine fault and completes the journey at $\frac{3}{4}$ of its usual speed, reaching Q $35$ minutes later than it would have at its usual speed throughout. Had the fault occurred $24$ km farther on, the bus would have reached Q only $25$ minutes later than it would have at its usual speed throughout. What is the distance from P to Q?",
  "MCQ",
  r"The $24$ km driven at full speed instead of at $\frac{3}{4}$ speed saves $10$ minutes: $\frac{24}{v} \times \frac{1}{3} = \frac{1}{6}$, so $v = 48$ km/h and the reduced speed is $36$ km/h. For the remaining $R$ km after the fault, $\frac{R}{36} - \frac{R}{48} = \frac{35}{60}$, so $\frac{R}{144} = \frac{7}{12}$ and $R = 84$. Hence $PQ = 50 + 84 = 134$ km.",
  "Forgetting to add the $50$ km before the fault.",
  "C08F-breakdown-reduced-speed", "Differencing two scenarios, then a second equation for the remaining distance.",
  correct=r"$134$ km",
  distractors=[(r"$84$ km", "Gives only the distance after the fault."),
               (r"$110$ km", "Uses the second scenario's remaining $60$ km and adds $50$, forgetting the extra $24$ km."),
               (r"$158$ km", "Finds $84$ km correctly but treats it as the distance remaining after the later fault point ($50 + 24 = 74$ km), giving $74 + 84 = 158$.")],
  check=_c018, values=[134, 84, 110, 158], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 019
def _c019():
    # event simulation with unknown riding distances x1 (group 1) and x2 (group 2)
    x1, x2 = symbols('x1 x2', positive=True)
    D, v, w = 50, 50, 10
    t1 = x1 / v                                  # group 1 dropped at x1
    T1 = t1 + (D - x1) / w
    tm2 = t1 + (x1 - w * t1) / (v + w)           # van meets group 2
    p2 = w * tm2
    d2 = p2 + x2
    td2 = tm2 + x2 / v                           # group 2 dropped at d2
    T2 = td2 + (D - d2) / w
    tm3 = td2 + (d2 - w * td2) / (v + w)         # van meets group 3
    p3 = w * tm3
    T3 = tm3 + (D - p3) / v                      # group 3 ridden to the campsite
    s = solve([Eq(T1, T2), Eq(T2, T3)], [x1, x2], dict=True)[0]
    assert 0 < s[x1] < D and 0 < s[x2] and (p3.subs(s)) < D
    return T1.subs(s) * 60
q("C08-F-019", T_INT, "Van shuttles three groups forward so that all arrive together", "Difficult",
  "Conceptual/application",
  r"Thirty students must travel $50$ km from their school to a campsite, and their van can carry only ten of them at a time, so they form three groups of ten. The van carries the first group part of the way and drops them to walk on to the campsite, drives back to pick up the second group, carries them forward and drops them to walk on, then drives back to pick up the third group and carries them all the way to the campsite. Every group not in the van walks towards the campsite from the start. The van runs at $50$ km/h and all students walk at $10$ km/h; ignore loading and turning time. The drop-off points are chosen so that all three groups reach the campsite at the same time. How long does the whole journey take?",
  "MCQ",
  r"Equal speeds and equal arrival times mean every group rides the same distance $x$ and walks $50 - x$. While the van carries a group $x$ km, the walkers behind cover $\frac{x}{5}$ km; the gap of $\frac{4x}{5}$ km closes at $60$ km/h in $\frac{x}{75}$ h, during which they walk $\frac{2x}{15}$ km more. So each pick-up is $\frac{x}{5} + \frac{2x}{15} = \frac{x}{3}$ km beyond the previous one: at $0$, $\frac{x}{3}$ and $\frac{2x}{3}$. The third group rides $x$ from $\frac{2x}{3}$ to the campsite, so $\frac{5x}{3} = 50$ and $x = 30$. Time $= \frac{30}{50} + \frac{20}{10} = 2.6$ hours $= 2$ hours $36$ minutes.",
  "Reusing the two-group split, or giving each group an equal third of the route as in a bicycle relay.",
  "C08F-van-ferry-groups", "Three-stage shuttle: must find the constant advance of the pick-up point and chain it twice before using equal arrival.",
  correct=r"$2$ hours $36$ minutes",
  distractors=[(r"$2$ hours", "Uses the two-group shuttle: $\\frac{x}{3} + x = 50$ gives $x = 37.5$ and $\\frac{37.5}{50} + \\frac{12.5}{10} = 2$ hours."),
               (r"$3$ hours $40$ minutes", "Lets each group ride one third of the route: $\\frac{50/3}{50} + \\frac{100/3}{10} = \\frac{11}{3}$ hours."),
               (r"$1$ hour $40$ minutes", "Uses the average speed $\\frac{50 + 10}{2} = 30$ km/h for $50$ km.")],
  check=_c019, values=[156, 120, 220, 100], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 020
def _c020():
    s, a = symbols('s a', positive=True)
    c = 340
    ds = solve(Eq(s / c, 3), s)[0]
    da = solve(Eq(a / c, 7), a)[0]
    return da - ds          # both on the same side of the factory, Arjun farther
q("C08-F-020", T_SND, "Two listeners on the same side of a whistle along one line: gap from hearing times", "Easy",
  "Single-step computation",
  r"A factory whistle is blown once. Sneha hears it $3$ s after it is blown. Arjun stands on the same straight line from the factory as Sneha, on the same side but farther away, and hears it $7$ s after it is blown. The speed of sound is $340$ m/s. How far apart are Sneha and Arjun, in metres?",
  "TITA",
  r"Both are on the same side of the factory along one line, so the gap between them is the extra distance the sound travels in the extra $7 - 3 = 4$ s: $340 \times 4 = 1360$ m. (Separately: $340 \times 7 - 340 \times 3 = 2380 - 1020$.)",
  "Adding the two distances from the factory as if the listeners were on opposite sides.",
  "C08F-sound-two-listeners", "One subtraction of hearing times; the trap is adding the distances.",
  tita_answer=1360, check=_c020,
  tita_traps=[(3400, "Adds the two distances, $1020 + 2380$, as if they were on opposite sides of the factory."),
              (2380, "Gives Arjun's distance from the factory.")],
  cognitive="Understanding", exams=ALL)

# ---------------------------------------------------------------- 021
def _c021():
    tr, v = symbols('tr v', positive=True)
    d = v * tr                                   # Ravi's speed v, Meera's 4v/3, same distance
    tm_ride = d / (Rational(4, 3) * v)
    # Meera leaves 25 min later, stops 5 min, arrives with Ravi
    return solve(Eq(tr, 25 + tm_ride + 5), tr)[0]
q("C08-F-021", T_INT, "Speed ratio, a late start and a stop: time from the parts of a time ratio", "Medium",
  "Conceptual/application",
  r"Ravi and Meera walk from the same hostel gate to the same market along the same road. Ravi's walking speed is $\frac{3}{4}$ of Meera's. Ravi sets off first; Meera sets off $25$ minutes after him, stops for $5$ minutes at a shop on the way, and the two reach the market at the same moment. How long does Ravi take to walk to the market?",
  "MCQ",
  r"For the same distance the walking times are inversely proportional to the speeds, so Ravi's time : Meera's walking time $= 4 : 3$. Meera's $25$ minute late start and her $5$ minute stop both come out of the time Ravi spends walking, so her walking time is shorter than his by $25 + 5 = 30$ minutes. So one part $= 30$ minutes and Ravi takes $4 \times 30 = 120$ minutes (Meera walks $90$ minutes).",
  "Ignoring the stop, or subtracting it from the late start as if it gave Meera extra time.",
  "C08F-ratio-speed-time-gap", "Two ideas combined: the inverse time ratio and the net head start after the stop.",
  correct=r"$120$ minutes",
  distractors=[(r"$90$ minutes", "Gives Meera's walking time, $3 \\times 30$."),
               (r"$100$ minutes", "Ignores the stop, so one part $= 25$ minutes."),
               (r"$80$ minutes", "Subtracts the stop from the late start, so one part $= 25 - 5 = 20$ minutes.")],
  check=_c021, values=[120, 90, 100, 80], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 022
def _c022():
    w, d = symbols('w d', positive=True)
    c = Rational(5, 2) * w
    dd = solve(Eq((d / w + d / c).subs(w, 2), 70), d)[0]
    return ((d / w - d / c).subs(w, 2)).subs(d, dd)
q("C08-F-022", T_INT, "Walk one way, cycle back; split of the total time from a speed ratio", "Easy",
  "Multi-step word problem",
  r"Priya's walking and cycling speeds are in the ratio $2 : 5$. She walks from home to her tuition class and, after the class, cycles back home along the same road. Her walking and cycling together take $70$ minutes. By how many minutes does the walk take longer than the ride back?",
  "MCQ",
  r"For the same distance, times are inversely proportional to speeds, so walking time : cycling time $= 5 : 2$. Then $7$ parts $= 70$ minutes and one part $= 10$ minutes: the walk takes $50$ minutes and the ride $20$ minutes. The walk is longer by $3$ parts $= 30$ minutes.",
  "Using the speed ratio directly as the time ratio, or reporting one leg instead of the difference.",
  "C08F-ratio-mixed-mode-roundtrip", "One ratio inversion and a parts computation.",
  correct=r"$30$ minutes",
  distractors=[(r"$20$ minutes", "Gives the time of the ride back."),
               (r"$50$ minutes", "Gives the time of the walk."),
               (r"$10$ minutes", "Gives one part of the $7$ part split.")],
  check=_c022, values=[30, 20, 50, 10], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 023
def _c023():
    t = Rational(3, 2)
    return sqrt((12 * t) ** 2 + (16 * t) ** 2)
q("C08-F-023", T_INT, "Two people leave a crossing along perpendicular roads", "Easy",
  "Single-step computation",
  r"Ravi and Meera start at the same time from a crossing of two straight roads that meet at right angles. Ravi walks north at $12$ km/h and Meera cycles east at $16$ km/h. How far apart are they, in km, after $1$ hour $30$ minutes?",
  "TITA",
  r"Their separation grows like the hypotenuse of a triangle with legs $12t$ and $16t$, that is at $\sqrt{12^2 + 16^2} = 20$ km/h. After $1.5$ hours they are $20 \times 1.5 = 30$ km apart.",
  "Adding the two distances as if they moved in opposite directions.",
  "C08F-perpendicular-separation", "One Pythagoras step on a 3-4-5 triangle.",
  tita_answer=30, check=_c023,
  tita_traps=[(42, "Adds the distances $18 + 24$."), (6, "Subtracts the distances $24 - 18$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 024
def _c024():
    t = symbols('t', positive=True)
    sols = [s for s in solve(Eq((6 * t) ** 2 + (16 * (t - 1)) ** 2, 400), t) if s >= 1]
    return (sols[0] - 1) * 60
q("C08-F-024", T_INT, "Perpendicular roads with a head start: when the separation reaches a value", "Medium",
  "Inverse/parameter",
  r"Ravi leaves a road crossing at $9{:}00$ am and walks due north at $6$ km/h. Meera leaves the same crossing at $10{:}00$ am and cycles due east at $16$ km/h. The roads are straight and at right angles. How many minutes after Meera starts are the two of them exactly $20$ km apart?",
  "TITA",
  r"Let $s$ be the hours after $10{:}00$ am. Ravi is $6(s + 1)$ km north and Meera $16s$ km east, so $36(s + 1)^2 + 256s^2 = 400$. Trying $s = 1$: legs $12$ and $16$ give $20$ exactly, and the separation keeps increasing, so this is the only time. So the answer is $60$ minutes.",
  "Measuring the time from Ravi's start.",
  "C08F-perpendicular-separation", "A quadratic set-up; the 3-4-5 triangle shortcut must be spotted.",
  tita_answer=60, check=_c024,
  tita_traps=[(120, "Measures the time from $9{:}00$ am.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 025
def _c025():
    return Fraction(120 + 50, 1) / sqrt(120 ** 2 + 50 ** 2)
q("C08-F-025", T_INT, "Diagonal versus two edges of a rectangular field: speed ratio", "Easy",
  "Single-step computation",
  r"A rectangular field measures $120$ m by $50$ m. Fatima and Kabir start together from one corner and both reach the opposite corner at the same time: Fatima walks straight along the diagonal, and Kabir walks along the two edges. What is the ratio of Kabir's speed to Fatima's speed?",
  "MCQ",
  r"The diagonal is $\sqrt{120^2 + 50^2} = 130$ m and the edge route is $120 + 50 = 170$ m. Equal times mean speeds are proportional to distances, so the ratio is $170 : 130 = 17 : 13$.",
  "Inverting the ratio, or using one side instead of the edge route.",
  "C08F-diagonal-vs-edges", "One Pythagoras step and a direct proportion.",
  correct=r"$17 : 13$",
  distractors=[(r"$13 : 17$", "Gives Fatima's speed to Kabir's."),
               (r"$12 : 13$", "Uses only the longer side for Kabir's route."),
               (r"$17 : 12$", "Compares the edge route with the longer side instead of the diagonal.")],
  check=_c025, values=[Rational(17, 13), Rational(13, 17), Rational(12, 13), Rational(17, 12)],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 026
def _c026():
    t = symbols('t', real=True)
    d2 = (3 * t) ** 2 + (10 - 4 * t) ** 2
    tm = solve(diff(d2, t), t)[0]
    return sqrt(d2.subs(t, tm))
q("C08-F-026", T_INT, "Closest approach on perpendicular roads, one moving towards the crossing", "Difficult",
  "Casework/optimisation",
  r"Two straight roads cross at right angles at O. At noon, Ravi is at O and walks due east at $3$ km/h, while Sneha is $10$ km due north of O and walks due south along the other road, through O, at $4$ km/h. What is the least distance between them?",
  "MCQ",
  r"After $t$ hours the distance squared is $(3t)^2 + (10 - 4t)^2 = 25t^2 - 80t + 100 = 25(t - 1.6)^2 + 36$. The minimum is at $t = 1.6$ h, before Sneha reaches O, and the least distance is $\sqrt{36} = 6$ km. (Relative motion gives the same: Sneha moves relative to Ravi along a direction with slope $4 : 3$, so the least distance is $10 \times \frac{3}{5}$.)",
  "Assuming the closest moment is when one person reaches the crossing.",
  "C08F-closest-approach", "Needs minimising a quadratic or a relative-velocity picture; a natural but wrong guess exists.",
  correct=r"$6$ km",
  distractors=[(r"$8$ km", "Uses $10 \\times \\frac{4}{5}$, the wrong component of the relative motion."),
               (r"$7.5$ km", "Takes the moment Sneha reaches O, when Ravi is $7.5$ km away."),
               (r"$4.8$ km", "Multiplies $10$ by both $\\frac{3}{5}$ and $\\frac{4}{5}$.")],
  check=_c026, values=[6, 8, Fraction(15, 2), Fraction(24, 5)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 027
def _c027():
    t = symbols('t', real=True)
    jx = -15 + 9 * t
    py = -10 + 12 * t
    d2 = jx ** 2 + py ** 2
    tm = solve(diff(d2, t), t)[0]
    return tm * 60
q("C08-F-027", T_INT, "Time of closest approach of two cyclists heading for a junction", "Difficult",
  "Casework/optimisation",
  r"Two straight roads meet at right angles at a junction J. At $8{:}00$ am Joseph is $15$ km west of J cycling east at $9$ km/h, and Priya is $10$ km south of J cycling north at $12$ km/h. Both ride through J and keep going at the same speeds. How many minutes after $8{:}00$ am are they closest to each other?",
  "TITA",
  r"Take J as origin. After $t$ hours Joseph is at $(-15 + 9t, 0)$ and Priya at $(0, -10 + 12t)$, so the distance squared is $(9t - 15)^2 + (12t - 10)^2 = 225t^2 - 510t + 325$. This is least at $t = \frac{510}{450} = \frac{17}{15}$ h $= 68$ minutes (when they are $6$ km apart).",
  "Assuming they are closest when one of them reaches the junction.",
  "C08F-closest-approach", "Quadratic minimisation with neither person starting at the junction; tempting wrong guesses.",
  tita_answer=68, check=_c027,
  tita_traps=[(50, "Takes the moment Priya reaches J."), (100, "Takes the moment Joseph reaches J.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 028
def _c028():
    # Ravi: 40 km at 20 km/h with 6-minute stops at 10, 20, 30 km marks
    ravi = Fraction(40, 20) * 60 + 6 * len([m for m in (10, 20, 30, 40) if 0 < m < 40])
    meera = Fraction(40, 15) * 60
    return meera - ravi
q("C08-F-028", T_INT, "Cyclist with regular stops against a slower non-stop cyclist", "Easy",
  "Multi-step word problem",
  r"Ravi and Meera set off together to cycle $40$ km from P to Q. Ravi rides at $20$ km/h but stops for $6$ minutes at each $10$ km mark between P and Q. Meera rides at $15$ km/h without stopping. By how many minutes does Ravi reach Q before Meera?",
  "MCQ",
  r"Ravi rides for $2$ hours and stops at the $10$, $20$ and $30$ km marks only, since the $40$ km mark is Q itself: $120 + 18 = 138$ minutes. Meera takes $\frac{40}{15}$ h $= 160$ minutes. Ravi arrives $160 - 138 = 22$ minutes before her.",
  "Counting a stop at the destination.",
  "C08F-rests-who-ahead", "Short computation with an off-by-one trap in the number of stops.",
  correct=r"$22$ minutes",
  distractors=[(r"$16$ minutes", "Counts four stops, including one at Q."),
               (r"$40$ minutes", "Ignores the stops."),
               (r"$28$ minutes", "Counts only two stops.")],
  check=_c028, values=[22, 16, 40, 28], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 029
def _c029():
    # simulate minute by minute with Fractions from 8:00 to 12:00
    pos_s, ride, rest = Fraction(0), 0, 0
    riding = True
    for minute in range(240):
        if riding:
            pos_s += Fraction(16, 60)
            ride += 1
            if ride == 60:
                riding, ride = False, 0
        else:
            rest += 1
            if rest == 15:
                riding, rest = True, 0
    pos_f = Fraction(12 * 240, 60)
    return abs(pos_s - pos_f)
q("C08-F-029", T_INT, "Cyclist with hourly rests against a steady cyclist: gap at a given time", "Medium",
  "Multi-step word problem",
  r"Sneha and Fatima leave the same point at $8{:}00$ am and cycle along the same road in the same direction. Sneha rides at $16$ km/h but, after every $60$ minutes of riding, rests for $15$ minutes before riding on. Fatima rides at a steady $12$ km/h without stopping. How far apart are they, in km, at $12{:}00$ noon?",
  "TITA",
  r"Sneha rides $8{:}00$ am to $9{:}00$ am, $9{:}15$ am to $10{:}15$ am and $10{:}30$ am to $11{:}30$ am, then rests until $11{:}45$ am and rides the last $15$ minutes: $3 \times 16 + 4 = 52$ km. Fatima covers $12 \times 4 = 48$ km. They are $4$ km apart, with Sneha ahead.",
  "Ignoring the rests, or treating the last quarter hour as rest.",
  "C08F-rests-who-ahead", "Requires a careful timeline across several ride and rest cycles.",
  tita_answer=4, check=_c029,
  tita_traps=[(16, "Ignores Sneha's rests: $64 - 48$."), (0, "Treats Sneha as resting from $11{:}30$ am until noon.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 030
def _c030():
    leave = 7 * 60 + 5
    best = None
    # bus: stop 0.5 km away, buses every 20 min from 7:00, 45 km at 36 km/h
    at_stop = leave + Fraction(1, 2) / 4 * 60
    dep = next(t for t in range(7 * 60, 10 * 60, 20) if t >= at_stop)
    bus = dep + Fraction(45, 36) * 60
    # train: station 1 km away, trains every 30 min from 7:10, 50 km at 60 km/h
    at_stn = leave + Fraction(1, 4) * 60
    dep2 = next(t for t in range(7 * 60 + 10, 10 * 60, 30) if t >= at_stn)
    train = dep2 + Fraction(50, 60) * 60
    return min(bus, train) - leave
q("C08-F-030", T_INT, "Earliest arrival choosing between a bus and a train with fixed timetables", "Medium",
  "Casework/optimisation",
  r"Fatima leaves home at $7{:}05$ am for her office. She walks at $4$ km/h. The bus stop is $500$ m from her home; buses leave it at $7{:}00$ am and every $20$ minutes after that, and cover the $45$ km to her office at $36$ km/h. The railway station is $1$ km from her home; trains leave it at $7{:}10$ am and every $30$ minutes after that, and cover the $50$ km to her office at $60$ km/h. Both the bus and the train stop right beside her office. What is the least number of minutes after $7{:}05$ am in which she can reach her office?",
  "TITA",
  r"Bus: she reaches the stop at $7{:}12{:}30$ am, catches the $7{:}20$ am bus and rides $75$ minutes, arriving at $8{:}35$ am. Train: she reaches the station at $7{:}20$ am, has just missed the $7{:}10$ am train, catches the $7{:}40$ am and rides $50$ minutes, arriving at $8{:}30$ am. The earlier arrival is $8{:}30$ am, which is $85$ minutes after $7{:}05$ am.",
  "Ignoring the waiting time for the next departure.",
  "C08F-earliest-arrival-timetable", "Two cases, each with a walk, a wait and a ride.",
  tita_answer=85, check=_c030,
  tita_traps=[(90, "Takes the bus option."), (65, "Ignores the wait for the train: $15 + 50$.")],
  cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 031
def _c031():
    v, d = symbols('v d', positive=True)
    s = solve([Eq(d / (v + 3), Rational(4, 5) * d / v),
               Eq((d / 2) / (v - 3) + (d / 2) / (v + 3) - d / v, Rational(1, 3))], [v, d], dict=True)
    s = [x for x in s if x[v] > 3][0]
    return s[d]
q("C08-F-031", T_INT, "Speed from a fractional time saving, then a slower-half and faster-half plan fixes the distance", "Medium",
  "Multi-step word problem",
  r"Ravi cycles from P to Q at a constant speed. Had he ridden $3$ km/h faster throughout, he would have taken $\frac{1}{5}$ less time. Had he instead ridden the first half of the distance $3$ km/h slower than usual and the second half $3$ km/h faster than usual, he would have taken $20$ minutes more than usual. What is the distance from P to Q?",
  "MCQ",
  r"Taking $\frac{4}{5}$ of the time means riding at $\frac{5}{4}$ of the speed, so $3$ km/h is $\frac{1}{4}$ of his speed and $v = 12$ km/h. With $PQ = d$, the second plan takes $\frac{d}{2} \left(\frac{1}{9} + \frac{1}{15}\right) = \frac{4d}{45}$ against the usual $\frac{d}{12}$, a difference of $\frac{16d - 15d}{180} = \frac{d}{180}$ hours. Setting $\frac{d}{180} = \frac{1}{3}$ gives $d = 60$ km.",
  "Assuming that riding $3$ km/h slower and $3$ km/h faster over equal distances cancels out.",
  "C08F-ratio-then-split-journey", "Two stages: a ratio step for the speed, then an unequal-effect half-and-half comparison.",
  correct=r"$60$ km",
  distractors=[(r"$36$ km", "Takes $20$ minutes as $0.2$ h: $\\frac{d}{180} = 0.2$."),
               (r"$24$ km", "Ignores the time saved on the faster half: $\\frac{d}{2}\\left(\\frac{1}{9} - \\frac{1}{12}\\right) = \\frac{d}{72} = \\frac{1}{3}$."),
               (r"$30$ km", "Forgets to halve the distance: $d\\left(\\frac{1}{9} - \\frac{1}{12}\\right) - d\\left(\\frac{1}{12} - \\frac{1}{15}\\right) = \\frac{d}{90} = \\frac{1}{3}$.")],
  check=_c031, values=[60, 36, 24, 30], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 032
def _c032():
    h = Fraction(36)
    # time proportional to distance / speed; Joseph: 2x distance, 4/3 speed
    return h * 2 / Fraction(4, 3)
q("C08-F-032", T_INT, "Time from ratios of speeds and distances", "Easy",
  "Single-step computation",
  r"Harpreet and Joseph walk to the same market, and their walking speeds are in the ratio $3 : 4$. Harpreet takes $36$ minutes to walk from her home to the market. Joseph's home is twice as far from the market as Harpreet's. How long does Joseph take to walk from his home to the market?",
  "MCQ",
  r"Time is proportional to distance and inversely proportional to speed. Joseph's time $= 36 \times 2 \times \frac{3}{4} = 54$ minutes.",
  "Using the speed ratio the wrong way round.",
  "C08F-ratio-distance-speed-time", "One proportional computation with an inversion trap.",
  correct=r"$54$ minutes",
  distractors=[(r"$96$ minutes", "Multiplies by $\\frac{4}{3}$: $36 \\times 2 \\times \\frac{4}{3}$."),
               (r"$27$ minutes", "Ignores the doubled distance: $36 \\times \\frac{3}{4}$."),
               (r"$72$ minutes", "Ignores the speed ratio: $36 \\times 2$.")],
  check=_c032, values=[54, 96, 27, 72], cognitive="Understanding", exams=ALL)

# ---------------------------------------------------------------- 033
def _c033():
    t = symbols('t', positive=True)
    ravi = 20 + 12 * (t - 1)
    ts = [s for s in solve(Eq(15 * t, ravi), t) if s > 1][0]
    return 15 * ts
q("C08-F-033", T_INT, "A cyclist who slows after the first hour is drawn level with", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera start together from P and cycle along the same road in the same direction. Ravi rides at $20$ km/h for the first hour and then at $12$ km/h. Meera rides at a steady $15$ km/h. How far from P is Meera when she draws level with Ravi?",
  "MCQ",
  r"After one hour Ravi is $20$ km out and Meera $15$ km, so Ravi leads by $5$ km. Meera then gains $15 - 12 = 3$ km/h, closing the gap in $\frac{5}{3}$ h. She draws level $\frac{8}{3}$ h after the start, at $15 \times \frac{8}{3} = 40$ km from P.",
  "Using Ravi's first-hour speed for the closing rate, or timing from the start.",
  "C08F-speed-drop-drawing-level", "Two phases: build the lead, then close it at the correct relative speed.",
  correct=r"$40$ km",
  distractors=[(r"$30$ km", "Uses $20 - 15 = 5$ km/h as the closing rate, so they are level after $2$ h."),
               (r"$25$ km", "Measures the $\\frac{5}{3}$ h from the start: $15 \\times \\frac{5}{3}$."),
               (r"$32$ km", "Uses $12$ km/h for Ravi over the whole $\\frac{8}{3}$ h.")],
  check=_c033, values=[40, 30, 25, 32], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 034
def _c034():
    w, t = symbols('w t', positive=True)
    D, vc = 15, 30  # station at 0, home at D km; times in hours, 5 PM = 17
    car_leave = 17 - Rational(D, vc)
    meet = Eq(w * (t - 16), D - vc * (t - car_leave))
    home = t + (D - w * (t - 16)) / vc
    sol = solve([meet, Eq(home, 17 + Rational(D, vc) - Rational(1, 3))], [w, t], dict=True)[0]
    return (sol[t] - 16) * 60
q("C08-F-034", T_INT, "Early arrival walking to meet the car that comes to fetch him", "Medium",
  "Conceptual/application",
  r"Every day a car leaves Arjun's home at a fixed time, reaches the station at exactly $5{:}00$ pm, picks him up and drives straight back. One day Arjun arrives at the station at $4{:}00$ pm and starts walking home along the car's route. The car, leaving home at its usual time, meets him on the way, turns back at once and brings him home $20$ minutes earlier than usual. The car's speed is the same throughout. For how many minutes did Arjun walk?",
  "MCQ",
  r"The car saved $20$ minutes by not driving from the meeting point to the station and back, so that one-way stretch takes $10$ minutes. The car therefore met Arjun $10$ minutes before it would have reached the station, at $4{:}50$ pm. He walked from $4{:}00$ pm to $4{:}50$ pm, that is $50$ minutes.",
  "Taking the whole time saved as a one-way saving.",
  "C08F-walk-to-meet-car", "A classic insight: the saving is a round trip of the car.",
  correct=r"$50$ minutes",
  distractors=[(r"$40$ minutes", "Treats the $20$ minutes as saved on one leg, so the meeting is at $4{:}40$ pm."),
               (r"$10$ minutes", "Gives the one-way saving of the car."),
               (r"$20$ minutes", "Takes the time saved as the walking time.")],
  check=_c034, values=[50, 40, 10, 20], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 035
def _c035():
    a, t = symbols('a t', positive=True)
    vw, vc, D = 6, 54, 30  # station at 0, home at D; father's car reaches station at 17
    car_leave = 17 - Rational(D, vc)
    start = 17 - a / 60
    meet = Eq(vw * (t - start), D - vc * (t - car_leave))
    home = t + (D - vw * (t - start)) / vc
    sol = solve([meet, Eq(home, 17 + Rational(D, vc) - Rational(24, 60))], [a, t], dict=True)[0]
    return sol[a]
q("C08-F-035", T_INT, "How early the traveller arrived, given walking and car speeds", "Difficult",
  "Inverse/parameter",
  r"Priya's father always leaves home at a fixed time and drives to the station at $54$ km/h, reaching it at exactly $5{:}00$ pm to pick her up, and then drives home at the same speed. One day Priya arrives at the station early and immediately starts walking home along the same road at $6$ km/h. Her father leaves home at the usual time, meets her on the way, turns back at once, and they reach home $24$ minutes earlier than usual. How long before $5{:}00$ pm did Priya arrive at the station?",
  "MCQ",
  r"The car saves a round trip from the meeting point to the station, so each way takes $12$ minutes and they met at $4{:}48$ pm, $54 \times \frac{12}{60} = 10.8$ km from the station. Priya walked $10.8$ km at $6$ km/h, taking $1.8$ h $= 108$ minutes, so she started at $3{:}00$ pm. She arrived $2$ hours before $5{:}00$ pm.",
  "Reporting the walking time instead of how early she arrived.",
  "C08F-walk-to-meet-car", "The round-trip saving insight plus a speed-ratio step back to the start time.",
  correct=r"$2$ hours",
  distractors=[(r"$1$ hour $48$ minutes", "Gives the walking time only."),
               (r"$4$ hours", "Takes the $24$ minutes as a one-way saving: meeting at $4{:}36$ pm, $21.6$ km out, $3$ h $36$ min of walking."),
               (r"$2$ hours $12$ minutes", "Adds the whole $24$ minutes to the $108$ minutes of walking.")],
  check=_c035, values=[120, 108, 240, 132], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    T, f = symbols('T f', positive=True)
    s = solve([Eq(T * f * Rational(1, 3), 10), Eq(T * (1 - f) * Rational(1, 3), 20)], [T, f], dict=True)[0]
    return s[T]
q("C08-F-036", T_INT, "Delay proportional to the distance covered at reduced speed", "Difficult",
  "Conceptual/application",
  r"Ananya's usual journey to work is at a constant speed. One day she covers the first part of the route at $\frac{3}{4}$ of her usual speed and the rest at her usual speed, and arrives $10$ minutes late. Had she covered the first part at her usual speed and the rest at $\frac{3}{4}$ of it, she would have been $20$ minutes late. How long does her usual journey take?",
  "MCQ",
  r"At $\frac{3}{4}$ speed each stretch takes $\frac{4}{3}$ times as long, so the delay on a stretch is $\frac{1}{3}$ of its usual time. The two delays add to the delay for covering the whole route at $\frac{3}{4}$ speed: $10 + 20 = 30$ minutes $= \frac{1}{3}$ of the usual time. The usual time is $90$ minutes.",
  "Taking the extra time at $\\frac{3}{4}$ speed as $\\frac{1}{4}$ instead of $\\frac{1}{3}$ of the usual time.",
  "C08F-proportional-saving", "The split point and the usual time are both unknown and the stem gives no distances; the non-obvious step is that the two delays add to the delay for the whole route at reduced speed, and the direct route needs two equations in a fraction and a time.",
  correct=r"$90$ minutes",
  distractors=[(r"$120$ minutes", "Uses an extra $\\frac{1}{4}$ of the usual time: $\\frac{T}{4} = 30$."),
               (r"$60$ minutes", "Assumes the first part is half the route: $\\frac{1}{3} \\times \\frac{T}{2} = 10$."),
               (r"$45$ minutes", "Takes the first part as $\\frac{2}{3}$ of the route: $\\frac{1}{3} \\times \\frac{2T}{3} = 10$.")],
  check=_c036, values=[90, 120, 60, 45], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 037
def _c037():
    x = symbols('x', positive=True)
    d, w, c, rest = 12, 4, 12, Rational(1, 3)
    return _pos(solve(Eq(x / w, Rational(d, c) + rest + (d - x) / c), x))[0]
q("C08-F-037", T_INT, "Cyclist reaches the end, rests and rides back to meet a walker", "Medium",
  "Multi-step word problem",
  r"Kabir and Fatima leave P together for Q, $12$ km away. Kabir walks at $4$ km/h. Fatima cycles at $12$ km/h, rests at Q for $20$ minutes and then cycles back towards P at the same speed. How far from P are they when they meet?",
  "MCQ",
  r"Fatima reaches Q after $1$ h and leaves again at $1$ h $20$ min, when Kabir has walked $\frac{16}{3}$ km. The gap of $\frac{20}{3}$ km closes at $16$ km/h in $\frac{5}{12}$ h, in which Kabir walks $\frac{5}{3}$ km more. They meet $\frac{16}{3} + \frac{5}{3} = 7$ km from P.",
  "Ignoring the rest, or reporting the distance from Q.",
  "C08F-there-and-back-rest", "Three phases (ride, rest, return) to track before the meeting.",
  correct=r"$7$ km",
  distractors=[(r"$6$ km", "Ignores the $20$ minute rest."),
               (r"$7\frac{1}{3}$ km", "Adds the $\\frac{4}{3}$ km Kabir walks during the rest to the no-rest answer of $6$ km."),
               (r"$5$ km", "Gives the distance from Q.")],
  check=_c037, values=[7, 6, Fraction(22, 3), 5], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 038
def _c038():
    L, u, v = Fraction(12, 10), 4, 20
    t = L / (v - u) + L / (v + u)
    return v * t
q("C08-F-038", T_INT, "Messenger rides from the rear of a marching column to the front and back", "Medium",
  "Multi-step word problem",
  r"A column of cadets $1.2$ km long marches along a straight road at $4$ km/h. A messenger on a motorcycle rides at $20$ km/h from the rear of the column to the front, delivers a message instantly and rides straight back to the rear. What distance does the messenger cover on the road?",
  "MCQ",
  r"Going forward the messenger gains on the front at $16$ km/h, taking $\frac{1.2}{16} = 0.075$ h. Coming back the rear approaches at $24$ km/h, taking $\frac{1.2}{24} = 0.05$ h. Total time $0.125$ h, so the distance on the road is $20 \times 0.125 = 2.5$ km.",
  "Using one relative speed for both legs, or ignoring the march.",
  "C08F-column-messenger", "Two legs with different relative speeds, then back to ground distance.",
  correct=r"$2.5$ km",
  distractors=[(r"$2.4$ km", "Ignores the column's motion: twice $1.2$ km."),
               (r"$3$ km", "Uses $16$ km/h for both legs: $20 \\times \\frac{2.4}{16}$."),
               (r"$2$ km", "Uses $24$ km/h for both legs: $20 \\times \\frac{2.4}{24}$.")],
  check=_c038, values=[Fraction(5, 2), Fraction(12, 5), 3, 2], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 039
def _c039():
    r = symbols('r', positive=True)
    L = 400
    # u = 1, v = r: time forward L/(r-1), back L/(r+1), column advances L in that time
    rs = [s for s in solve(Eq(L / (r - 1) + L / (r + 1), L), r) if s > 1][0]
    return L * rs
q("C08-F-039", T_INT, "Messenger's distance when the column advances its own length", "Difficult",
  "Conceptual/application",
  r"A column of soldiers $400$ m long marches along a straight road at a constant speed. A dispatch rider starts at the rear, rides to the front and immediately rides back to the rear, at a constant speed. During this time the column advances exactly $400$ m. What distance does the rider cover on the road?",
  "MCQ",
  r"Let the column's speed be $1$ and the rider's $r$. The trip takes $\frac{400}{r - 1} + \frac{400}{r + 1}$, which equals the time for the column to move $400$ m, namely $400$. So $\frac{2r}{r^2 - 1} = 1$, $r^2 - 2r - 1 = 0$ and $r = 1 + \sqrt{2}$. The rider covers $r$ times the column's $400$ m, that is $400(1 + \sqrt{2})$ m.",
  "Ignoring the column's motion, or dropping a term of the quadratic.",
  "C08F-column-messenger", "Speeds are unknown; the condition gives a quadratic for their ratio with an irrational root.",
  correct=r"$400(1 + \sqrt{2})$ m",
  distractors=[(r"$800$ m", "Ignores the column's motion, or drops the constant term so that $r = 2$."),
               (r"$1200$ m", "Adds the column's $400$ m advance to a relative round trip of $800$ m."),
               (r"$400(2 + \sqrt{2})$ m", "Adds the column's $400$ m advance to the correct distance.")],
  check=_c039, values=[400 * (1 + sqrt(2)), 800, 1200, 400 * (2 + sqrt(2))], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 040
def _c040():
    T, D = symbols('T D', positive=True)
    Ts = solve(Eq(T - T * Rational(4, 5), 1), T)[0]
    Ds = solve(Eq((D - 120) / D * (Ts / 5), Rational(1, 3)), D)[0]
    return Ds / Ts
q("C08-F-040", T_INT, "Saving proportional to the distance driven faster: find the usual speed", "Medium",
  "Inverse/parameter",
  r"Meera usually drives from P to Q at a constant speed. Had she driven $25\%$ faster all the way, she would have arrived $1$ hour earlier. Had she driven the first $120$ km at her usual speed and the rest $25\%$ faster, she would have arrived $20$ minutes earlier. What is her usual speed?",
  "MCQ",
  r"At $\frac{5}{4}$ of the speed the time is $\frac{4}{5}$ of usual, so the saving is $\frac{1}{5}$ of the usual time: usual time $= 5$ hours. The saving is proportional to the distance driven faster, so $20$ minutes out of $60$ means the last $\frac{1}{3}$ of the route was driven faster and the first $120$ km is $\frac{2}{3}$ of it. Hence $PQ = 180$ km and the usual speed is $\frac{180}{5} = 36$ km/h.",
  "Treating the $120$ km as the stretch driven faster.",
  "C08F-proportional-saving", "Heavy Medium: two standard proportional steps chained (the time-saving fraction, then the distance fraction), each quick once seen.",
  correct=r"$36$ km/h",
  distractors=[(r"$72$ km/h", "Treats the $120$ km as the faster third, so $PQ = 360$ km."),
               (r"$45$ km/h", "Assumes $25\\%$ faster saves $25\\%$ of the time, so the usual time is $4$ hours."),
               (r"$32$ km/h", "Takes $PQ = 120 + \\frac{120}{3} = 160$ km.")],
  check=_c040, values=[36, 72, 45, 32], cognitive="Analysis", exams=HARD)
