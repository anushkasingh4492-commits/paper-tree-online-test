import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Graphs"
CX = ("CAT", "XAT")
X = symbols('x', real=True)
R = Rational


# ---------------------------------------------------------------- helpers

def _poly_area(cons):
    """Area of the bounded convex region {a x + b y <= c for every (a, b, c)}.
    Vertices are pairwise intersections of boundary lines satisfying every constraint."""
    xs, ys = symbols('xs ys', real=True)
    verts = set()
    for (a1, b1, c1), (a2, b2, c2) in itertools.combinations(cons, 2):
        det = a1 * b2 - a2 * b1
        if det == 0:
            continue
        s = solve([a1 * xs + b1 * ys - c1, a2 * xs + b2 * ys - c2], [xs, ys], dict=True)[0]
        px, py = nsimplify(s[xs]), nsimplify(s[ys])
        if all(a * px + b * py <= c for a, b, c in cons):
            verts.add((px, py))
    verts = list(verts)
    cx = sum(v[0] for v in verts) / len(verts)
    cy = sum(v[1] for v in verts) / len(verts)
    verts.sort(key=lambda v: float(atan2(v[1] - cy, v[0] - cx)))
    s = 0
    for i in range(len(verts)):
        x1, y1 = verts[i]
        x2, y2 = verts[(i + 1) % len(verts)]
        s += x1 * y2 - x2 * y1
    return Abs(s) / 2


def _pl_hits(pts, k):
    """Distinct x where the piecewise-linear graph through pts (sorted by x) equals k."""
    sol = set()
    for (x1, y1), (x2, y2) in zip(pts[:-1], pts[1:]):
        x1, y1, x2, y2 = map(Fraction, (x1, y1, x2, y2))
        if y1 == y2:
            if y1 == k:
                raise ValueError("flat piece at level k")
            continue
        t = (Fraction(k) - y1) / (y2 - y1)
        if 0 <= t <= 1:
            sol.add(x1 + t * (x2 - x1))
    return sol


def _line_vs_branches(slope, icpt, branches):
    """Number of points where y = slope*x + icpt meets a piecewise-linear graph given as
    branches (s, c, lo, hi): y = s*x + c for lo <= x <= hi (lo/hi may be None). oo if overlap."""
    pts = set()
    for s, c, lo, hi in branches:
        if s == slope:
            if c == icpt:
                return oo
            continue
        x0 = nsimplify((sympify(icpt) - c) / (s - sympify(slope)))
        if (lo is None or x0 >= lo) and (hi is None or x0 <= hi):
            pts.add(x0)
    return len(pts)


def _assemble(crit, count_fn, target, lo=None):
    """Set of parameter values p (p > lo if lo given) with count_fn(p) == target, assuming the
    count is constant between consecutive critical values in crit."""
    crit = sorted(set(sympify(c) for c in crit if lo is None or sympify(c) > lo), key=lambda v: float(v))
    pieces = []
    edges = ([sympify(lo)] if lo is not None else [-oo]) + crit + [oo]
    for a, b in zip(edges[:-1], edges[1:]):
        if a == -oo and b == oo:
            m = 0
        elif a == -oo:
            m = b - 1
        elif b == oo:
            m = a + 1
        else:
            m = (a + b) / 2
        if count_fn(m) == target:
            pieces.append(Interval.open(a, b))
    for c in crit:
        if count_fn(c) == target:
            pieces.append(FiniteSet(c))
    return Union(*pieces) if pieces else S.EmptySet


def _pt_set(*vals):
    return FiniteSet(*[nsimplify(v) for v in vals])


# ================================================================ C14B-graph-shift-equation

def _c1():
    f = X**2 - 6*X + 5
    return expand(f.subs(X, X + 4) + 3)
q("C14-B-001", T, "Equation of a parabola after a horizontal and a vertical shift", "Easy",
  "Single-step computation",
  r"The graph of $y = x^2 - 6x + 5$ is shifted $4$ units to the left and then $3$ units upward. The equation of the new graph is",
  "MCQ",
  r"Shifting left by $4$ replaces $x$ by $x + 4$, and shifting up by $3$ adds $3$: $y = (x+4)^2 - 6(x+4) + 5 + 3 = x^2 + 8x + 16 - 6x - 24 + 8 = x^2 + 2x$. As a check, the vertex moves from $(3, -4)$ to $(-1, -1)$, and $y = (x+1)^2 - 1 = x^2 + 2x$.",
  "Replacing $x$ by $x - 4$ for a shift to the left, or subtracting the vertical shift.",
  "C14B-graph-shift-equation", "Direct substitution for two shifts; the only trap is the direction of the horizontal shift.",
  correct=r"$y = x^2 + 2x$",
  distractors=[(r"$y = x^2 - 14x + 48$", "Replaces $x$ by $x - 4$ (a shift to the right) and adds $3$: $(x-4)^2 - 6(x-4) + 8 = x^2 - 14x + 48$."),
               (r"$y = x^2 + 2x - 6$", "Shifts left correctly, $(x+4)^2 - 6(x+4) + 5 = x^2 + 2x - 3$, but subtracts $3$ for the upward shift: $x^2 + 2x - 6$."),
               (r"$y = x^2 - 14x + 42$", "Reverses both directions: replaces $x$ by $x - 4$ and subtracts $3$, giving $x^2 - 14x + 45 - 3$.")],
  check=_c1, values=[X**2 + 2*X, X**2 - 14*X + 48, X**2 + 2*X - 6, X**2 - 14*X + 42],
  cognitive="Application")


def _c2():
    b, c = symbols('b c')
    f = X**2 + b*X + c
    shifted = expand(f.subs(X, X - 3) - 2)
    sol = solve(Poly(shifted - (X**2 - 10*X + 27), X).all_coeffs(), [b, c], dict=True)[0]
    return f.subs(sol).subs(X, 5)
q("C14-B-002", T, "Recovering the original quadratic from its shifted graph", "Easy",
  "Inverse/parameter",
  r"Let $f(x) = x^2 + bx + c$. When the graph of $y = f(x)$ is shifted $3$ units to the right and then $2$ units downward, the resulting graph is $y = x^2 - 10x + 27$. Find the value of $f(5)$.",
  "TITA",
  r"The new graph is $y = (x - 5)^2 + 2$, with vertex $(5, 2)$. Undoing the shifts (move $3$ units left and $2$ units up), the original vertex is $(2, 4)$, so $f(x) = (x - 2)^2 + 4 = x^2 - 4x + 8$. Hence $f(5) = 9 + 4 = 13$.",
  "Undoing the shifts in the wrong direction, or evaluating the shifted graph instead of $f$.",
  "C14B-graph-shift-equation", "One reverse transformation of a vertex; slightly harder than a forward shift.",
  tita_answer=13, check=_c2,
  tita_traps=[(9, "Applies the shifts again instead of undoing them: vertex $(8, 0)$, $f(x) = (x-8)^2$, $f(5) = 9$."),
              (2, "Evaluates the new graph at $x = 5$: $25 - 50 + 27 = 2$.")],
  cognitive="Application")


def _c3():
    h = symbols('h', positive=True)
    # y = 2x - 5 shifted h units left: y = 2(x + h) - 5; tangent to y = x^2
    eq = X**2 - (2*(X + h) - 5)
    a, bb, cc = Poly(eq, X).all_coeffs()
    return solve(Eq(bb**2 - 4*a*cc, 0), h)[0]
q("C14-B-003", T, "Horizontal shift of a line that makes it touch a parabola", "Medium",
  "Inverse/parameter",
  r"The line $y = 2x - 5$ is shifted $h$ units to the left, where $h > 0$. After the shift, the line touches the parabola $y = x^2$ at exactly one point. The value of $h$ is",
  "MCQ",
  r"Shifting left by $h$ gives $y = 2(x + h) - 5 = 2x + 2h - 5$. For exactly one common point, $x^2 - 2x + (5 - 2h) = 0$ must have a repeated root: $4 - 4(5 - 2h) = 0$, so $5 - 2h = 1$ and $h = 2$. Quick route: a line of slope $2$ touches $y = x^2$ at $(1, 1)$, and the original line reaches $y = 1$ at $x = 3$, so it must move $2$ units left.",
  "Changing the intercept by $h$ rather than by $2h$, or a sign slip in the discriminant.",
  "C14B-graph-shift-equation", "Combines a horizontal shift of a line with the tangency (discriminant) condition.",
  correct=r"$2$",
  distractors=[(r"$4$", "Treats a left shift by $h$ as adding $h$ to the intercept: $5 - h = 1$ gives $h = 4$."),
               (r"$3$", "Sign slip in the discriminant: $4 + 4(5 - 2h) = 0$ gives $5 - 2h = -1$, $h = 3$."),
               (r"$1$", "Reports the $x$-coordinate of the point of contact, $x = 1$, as $h$.")],
  check=_c3, values=[2, 4, 3, 1], cognitive="Application")


# ================================================================ C14B-roots-under-substitution

def _c4():
    roots = [-2, 1, 5]
    return FiniteSet(*[s for r in roots for s in solve(Eq(2*X - 4, r), X)])
q("C14-B-004", T, "x-intercepts of y = f(2x - 4) from those of y = f(x)", "Medium",
  "Conceptual/application",
  r"The graph of $y = f(x)$ meets the $x$-axis at exactly three points, where $x = -2$, $x = 1$ and $x = 5$. The graph of $y = f(2x - 4)$ meets the $x$-axis exactly where $x$ equals",
  "MCQ",
  r"$f(2x - 4) = 0$ exactly when $2x - 4$ is one of $-2, 1, 5$. So $x = \frac{-2 + 4}{2}, \frac{1 + 4}{2}, \frac{5 + 4}{2}$, that is $x = 1, \frac{5}{2}, \frac{9}{2}$.",
  r"Applying the map $r \to 2r - 4$ to the old roots instead of solving $2x - 4 = r$.",
  "C14B-roots-under-substitution", "Needs the inverse of the inner map; the forward map is the natural trap.",
  correct=r"$1, \frac{5}{2}, \frac{9}{2}$",
  distractors=[(r"$-8, -2, 6$", r"Applies $r \to 2r - 4$ to each old root, the forward map."),
               (r"$-3, -\frac{3}{2}, \frac{1}{2}$", r"Halves each root and then subtracts $2$: $\frac{r}{2} - 2$."),
               (r"$3, \frac{9}{2}, \frac{13}{2}$", r"Halves each root and then adds $4$: $\frac{r}{2} + 4$, undoing the steps in the wrong order.")],
  check=_c4, values=[_pt_set(1, R(5, 2), R(9, 2)), _pt_set(-8, -2, 6), _pt_set(-3, R(-3, 2), R(1, 2)), _pt_set(3, R(9, 2), R(13, 2))],
  cognitive="Understanding")


def _c5():
    r = symbols('r1:5')
    # roots of f(6 - x) = 0 are x = 6 - r_i ; sum r_i = 10
    s = sum(6 - ri for ri in r)
    return s.subs(r[3], 10 - r[0] - r[1] - r[2])
q("C14-B-005", T, "Sum of the roots after reflecting the graph about a vertical line", "Easy",
  "Conceptual/application",
  r"The equation $f(x) = 0$ has exactly four distinct real roots, and their sum is $10$. Find the sum of all the real roots of the equation $f(6 - x) = 0$.",
  "TITA",
  r"If $r$ is a root of $f$, then $x = 6 - r$ is a root of $f(6 - x) = 0$, and every root arises this way; geometrically the graph is reflected about the line $x = 3$. The sum is $4 \times 6 - 10 = 14$.",
  "Thinking the reflected graph has the same roots, or subtracting the sum from $6$ only once.",
  "C14B-roots-under-substitution", "One substitution idea applied to four roots.",
  tita_answer=14, check=_c5,
  tita_traps=[(10, "Assumes the roots of $f(6 - x) = 0$ are the same as those of $f(x) = 0$."),
              (-4, "Computes $6 - 10$, applying the $6$ once instead of once per root.")],
  cognitive="Understanding")


def _c6():
    def f_pos(u):
        return (-4 < u < -1) or (2 < u < 5)
    return sum(1 for x in range(-300, 301) if f_pos(3 - Fraction(x, 2)))
q("C14-B-006", T, "Integers where f(3 - x/2) is positive when f is positive on two separate intervals", "Medium",
  "Conceptual/application",
  r"A function $f$ satisfies $f(x) > 0$ exactly when $-4 < x < -1$ or $2 < x < 5$, and $f(x) \le 0$ for every other real $x$. For how many integers $x$ is $f\left(3 - \frac{x}{2}\right) > 0$?",
  "TITA",
  r"Put $u = 3 - \frac{x}{2}$, so $x = 6 - 2u$; the map reverses order and doubles lengths. For $-4 < u < -1$ we get $8 < x < 14$, and for $2 < u < 5$ we get $-4 < x < 2$. The integers are $9, 10, \ldots, 13$ ($5$ of them) and $-3, -2, \ldots, 1$ ($5$ of them), so there are $10$ integers.",
  r"Pushing the interval endpoints forward through $u \to 3 - \frac{u}{2}$ instead of solving for $x$, or keeping the endpoints where $f$ is $0$.",
  "C14B-roots-under-substitution", "Inverting a reflection with a stretch on two separate intervals, then counting integers in open intervals.",
  tita_answer=10, check=_c6,
  tita_traps=[(2, "Maps the endpoints forward: $(-4, -1)$ goes to $(3.5, 5)$ and $(2, 5)$ to $(0.5, 2)$, containing only the integers $4$ and $1$."),
              (14, "Includes the endpoints $-4$, $2$, $8$ and $14$, where $f$ is not positive."),
              (12, "Reports the total length $6 + 6$ of the two intervals instead of counting integers.")],
  cognitive="Application")


# ================================================================ C14B-point-image-transform

def _c7():
    a, b = 3, -2
    return (a + 1, 2*b + 3)
q("C14-B-007", T, "Image of a known point under a shift and a vertical stretch", "Easy",
  "Single-step computation",
  r"The point $(3, -2)$ lies on the graph of $y = f(x)$. Which point must lie on the graph of $y = 2f(x - 1) + 3$?",
  "MCQ",
  r"For the new graph at $x = 4$, $y = 2f(3) + 3 = 2(-2) + 3 = -1$. In general $(a, b)$ moves to $(a + 1, 2b + 3)$, so $(3, -2)$ moves to $(4, -1)$.",
  "Shifting left for $x - 1$, or adding $3$ before doubling.",
  "C14B-point-image-transform", "One point pushed through two simple transformations.",
  correct=r"$(4, -1)$",
  distractors=[(r"$(2, -1)$", "Moves the point $1$ unit left for $x - 1$."),
               (r"$(4, 2)$", "Adds $3$ before doubling: $2(-2 + 3) = 2$."),
               (r"$(2, 2)$", "Makes both slips: shifts left and adds $3$ before doubling.")],
  check=_c7, values=[(4, -1), (2, -1), (4, 2), (2, 2)], cognitive="Application")


def _c8():
    a = symbols('a')
    # (a, f(a)) -> shift right 2 -> (a + 2, f(a)) -> horizontal stretch 3 -> (3(a + 2), f(a))
    xn = 3 * (a + 2)
    g = solve(Eq(xn, X), a)[0]       # final graph is y = f(g(x))
    return expand(g)
q("C14-B-008", T, "Order of a horizontal shift and a horizontal stretch", "Medium",
  "Conceptual/application",
  r"The graph of $y = f(x)$ is first shifted $2$ units to the right. The resulting graph is then stretched horizontally by a factor of $3$, so that each of its points $(p, q)$ moves to $(3p, q)$. The equation of the final graph is",
  "MCQ",
  r"A point $(a, f(a))$ goes to $(a + 2, f(a))$ and then to $(3a + 6, f(a))$. On the final graph $x = 3a + 6$, so $a = \frac{x}{3} - 2$ and the equation is $y = f\left(\frac{x}{3} - 2\right)$. Equivalently, the shift gives $y = f(x - 2)$, and the stretch then replaces $x$ by $\frac{x}{3}$.",
  "Doing the substitutions in the order the operations were listed, or compressing instead of stretching.",
  "C14B-point-image-transform", "Two horizontal transformations whose order changes the answer.",
  correct=r"$y = f\left(\frac{x}{3} - 2\right)$",
  distractors=[(r"$y = f\left(\frac{x - 2}{3}\right)$", r"Divides the whole argument of $f(x - 2)$ by $3$, which corresponds to stretching first and shifting afterwards."),
               (r"$y = f(3x - 2)$", "Writes $3x$ for a stretch by $3$, which actually compresses the graph."),
               (r"$y = f(3x - 6)$", "Writes $3x$ for the stretch and applies it to $f(x - 2)$: $f(3(x - 2))$.")],
  check=_c8, values=[X/3 - 2, (X - 2)/3, 3*X - 2, 3*X - 6], cognitive="Understanding")


def _c9():
    f = X**2 - 6*X + 8
    g = f.subs(X, -X)              # reflect in the y-axis
    g = g.subs(X, X - 4)           # shift right 4
    g = -g                         # reflect in the x-axis
    return FiniteSet(*solve(g, X))
q("C14-B-009", T, "x-intercepts after a reflection, a shift and a second reflection", "Medium",
  "Conceptual/application",
  r"The graph of $y = x^2 - 6x + 8$ is reflected in the $y$-axis. The resulting graph is shifted $4$ units to the right, and that graph is then reflected in the $x$-axis. The final graph meets the $x$-axis exactly where $x$ equals",
  "MCQ",
  r"The original $x$-intercepts are $x = 2$ and $x = 4$. A point $(r, 0)$ goes to $(-r, 0)$, then to $(4 - r, 0)$; the reflection in the $x$-axis leaves points on the $x$-axis fixed. So the intercepts are $4 - 2 = 2$ and $4 - 4 = 0$. (The final equation is $y = -x^2 + 2x$.)",
  "Shifting before reflecting, or thinking the reflection in the $x$-axis moves the $x$-intercepts.",
  "C14B-point-image-transform", "Three successive transformations whose order matters, with one that has no effect on the intercepts.",
  correct=r"$0$ and $2$",
  distractors=[(r"$-6$ and $-8$", r"Shifts before reflecting in the $y$-axis: $r \to r + 4 \to -(r + 4)$."),
               (r"$6$ and $8$", r"Skips the reflection in the $y$-axis and only shifts: $r \to r + 4$."),
               (r"$-2$ and $0$", r"Treats the reflection in the $x$-axis as also negating $x$: $4 - r \to r - 4$.")],
  check=_c9, values=[_pt_set(0, 2), _pt_set(-6, -8), _pt_set(6, 8), _pt_set(-2, 0)],
  cognitive="Application")


# ================================================================ C14B-graph-symmetry

def _c10():
    d = symbols('d1:4', positive=True)
    roots = [3] + [3 + di for di in d] + [3 - di for di in d]
    assert len(roots) == 7
    return simplify(sum(roots))
q("C14-B-010", T, "Sum of an odd number of roots of a graph symmetric about x = 3", "Medium",
  "Conceptual/application",
  r"The graph of $y = f(x)$ is symmetric about the line $x = 3$, that is, $f(3 + t) = f(3 - t)$ for every real $t$. The equation $f(x) = 0$ has exactly $7$ distinct real roots. Find the sum of these roots.",
  "TITA",
  r"If $3 + t$ is a root with $t \ne 0$, so is $3 - t$, so roots other than $3$ come in pairs with sum $6$. Seven is odd, so $x = 3$ must itself be a root, and the other six form $3$ pairs. The sum is $3 \times 6 + 3 = 21$.",
  "Forgetting that an odd count forces the axis value $x = 3$ to be a root.",
  "C14B-graph-symmetry", "Needs the pairing argument and the parity observation.",
  tita_answer=21, check=_c10,
  tita_traps=[(18, "Counts only the three symmetric pairs and misses the root at $x = 3$."),
              (0, "Assumes symmetry makes the roots cancel, as for symmetry about the $y$-axis.")],
  cognitive="Analysis")


def _c11():
    def f(x):
        x = Fraction(x)
        while not (1 <= x <= 4):
            x = 8 - x if x > 4 else 2 - x
        return x - 1
    # f is piecewise linear with kinks only at 1 + 3k; solve f = 2 on each piece
    sols = set()
    k = -2
    while 1 + 3*k <= 31:
        a, b = Fraction(1 + 3*k), Fraction(4 + 3*k)
        fa, fb = f(a), f(b)
        if fa != fb:
            t = (2 - fa) / (fb - fa)
            if 0 <= t <= 1:
                x = a + t * (b - a)
                if 0 <= x <= 30:
                    sols.add(x)
        k += 1
    return len(sols)
q("C14-B-011", T, "Counting solutions for a graph symmetric about two vertical lines", "Difficult",
  "Casework/optimisation",
  r"A function $f$, defined for all real $x$, satisfies $f(1 + t) = f(1 - t)$ and $f(4 + t) = f(4 - t)$ for every real $t$, so its graph is symmetric about both lines $x = 1$ and $x = 4$. For $1 \le x \le 4$, $f(x) = x - 1$. How many solutions does the equation $f(x) = 2$ have with $0 \le x \le 30$?",
  "TITA",
  r"Reflecting in $x = 4$ and then in $x = 1$ is a translation by $6$, so $f(x + 6) = f(x)$. On $[1, 4]$ the graph rises from $0$ to $3$, and by symmetry about $x = 4$ it falls from $3$ to $0$ on $[4, 7]$: a triangular wave of period $6$. In each period $f = 2$ at $x = 3 + 6j$ and $x = 5 + 6j$. In $[0, 30]$ these are $3, 5, 9, 11, 15, 17, 21, 23, 27, 29$ (and $f(0) = f(2) = 1$), giving $10$ solutions.",
  "Missing the period $6$ created by the two symmetries, or counting only the rising parts.",
  "C14B-graph-symmetry", "Must discover the period $6$ from two symmetries, build the triangular wave and count carefully at the ends.",
  tita_answer=10, check=_c11,
  tita_traps=[(5, "Counts only the rising pieces, one solution per period."),
              (2, "Uses each symmetry only once without discovering the period $6$, finding just $x = 3$ and $x = 5$.")],
  cognitive="Analysis", exams=CX)


def _c12():
    f0, f1 = symbols('f0 f1')
    f2 = solve(Eq(2*symbols('u'), 6), symbols('u'))[0]   # t = 0: f(2) + f(2) = 6
    f3 = 6 - f1
    f4 = 6 - f0
    return simplify(f0 + f1 + f2 + f3 + f4)
q("C14-B-012", T, "Sum of values for a graph symmetric about a point", "Medium",
  "Conceptual/application",
  r"The graph of $y = f(x)$ is symmetric about the point $(2, 3)$, that is, $f(2 + t) + f(2 - t) = 6$ for every real $t$. The value of $f(0) + f(1) + f(2) + f(3) + f(4)$ is",
  "MCQ",
  r"Putting $t = 0$ gives $2f(2) = 6$, so $f(2) = 3$. Also $t = 2$ gives $f(4) + f(0) = 6$ and $t = 1$ gives $f(3) + f(1) = 6$. The sum is $6 + 6 + 3 = 15$.",
  "Mishandling the self-paired middle term $f(2)$.",
  "C14B-graph-symmetry", "Point symmetry pairs values; the centre term needs separate thought.",
  correct=r"$15$",
  distractors=[(r"$18$", "Treats $f(2)$ as a full pair and counts it as $6$."),
               (r"$12$", "Pairs the outer terms and drops $f(2)$."),
               (r"$30$", "Assumes each of the five values contributes $6$.")],
  check=_c12, values=[15, 18, 12, 30], cognitive="Understanding")


# ================================================================ C14B-area-under-stretch

def _c13():
    res = set()
    for f in (R(3, 2)*X, R(9, 16)*X**2, 3 + 0*X):
        A = integrate(f, (X, 0, 4))
        f = f * 12 / A                          # scale so that the given area is 12
        g = 3 * f.subs(X, 2*X)
        res.add(integrate(g, (X, 0, 2)))
    assert len(res) == 1
    return res.pop()
q("C14-B-013", T, "Area under y = 3f(2x) from the area under y = f(x)", "Easy",
  "Conceptual/application",
  r"A function $f$ is positive for $0 \le x \le 4$, and the region bounded by $y = f(x)$, the $x$-axis and the lines $x = 0$ and $x = 4$ has area $12$ square units. What is the area, in square units, of the region bounded by $y = 3f(2x)$, the $x$-axis and the lines $x = 0$ and $x = 2$?",
  "MCQ",
  r"Replacing $x$ by $2x$ compresses the graph horizontally by a factor of $2$, so the strip $0 \le x \le 4$ becomes $0 \le x \le 2$ and the area halves to $6$. Multiplying by $3$ stretches it vertically, tripling the area to $18$.",
  "Treating the horizontal compression as a stretch, or ignoring one of the two factors.",
  "C14B-area-under-stretch", "Two scale factors applied to a known area.",
  correct=r"$18$",
  distractors=[(r"$72$", r"Multiplies by $2$ for the inner factor as well as by $3$: $12 \times 3 \times 2$."),
               (r"$36$", r"Applies only the vertical factor: $12 \times 3$."),
               (r"$6$", r"Applies only the horizontal compression: $12 \div 2$.")],
  check=_c13, values=[18, 72, 36, 6], cognitive="Understanding")


def _c14():
    A0 = integrate((X - 1)*(5 - X), (X, 1, 5))
    f = (X - 1)*(5 - X) * 15 / A0
    g = -2 * f.subs(X, 4 - X/3)
    xs = solve(g, X)
    lo, hi = min(xs), max(xs)
    return Abs(integrate(g, (X, lo, hi)))
q("C14-B-014", T, "Area after a reflection, a horizontal stretch and a vertical stretch", "Medium",
  "Conceptual/application",
  r"For a function $f$, $f(1) = f(5) = 0$ and $f(x) > 0$ for $1 < x < 5$. The part of the graph of $y = f(x)$ with $1 \le x \le 5$ and the $x$-axis enclose a region of area $15$ square units. What is the area, in square units, of the region enclosed by the $x$-axis and the corresponding part of the graph of $y = -2f\left(4 - \frac{x}{3}\right)$, namely the part with $-3 \le x \le 9$?",
  "MCQ",
  r"Write $u = 4 - \frac{x}{3}$; as $x$ runs over $[-3, 9]$, $u$ runs over $[1, 5]$ in reverse. The map $x \to 4 - \frac{x}{3}$ is a reflection with a horizontal stretch by $3$, which multiplies area by $3$; the factor $-2$ reflects in the $x$-axis and stretches vertically by $2$, multiplying area by $2$. Reflections do not change area, so the area is $15 \times 3 \times 2 = 90$.",
  "Reading $\\frac{x}{3}$ inside $f$ as a compression, or dropping one of the factors.",
  "C14B-area-under-stretch", "Must separate the reflections (no effect on area) from the two stretches.",
  correct=r"$90$",
  distractors=[(r"$10$", "Treats $\\frac{x}{3}$ as a compression by $3$: $15 \\times 2 \\div 3$."),
               (r"$30$", "Ignores the horizontal stretch: $15 \\times 2$."),
               (r"$45$", "Ignores the vertical factor $2$: $15 \\times 3$.")],
  check=_c14, values=[90, 10, 30, 45], cognitive="Application")


# ================================================================ C14B-area-lines-polygon

def _c15():
    # region: y >= 0, y <= x + 2, y <= 18 - 3x  (triangle with the x-axis)
    return _poly_area([(0, -1, 0), (-1, 1, 2), (3, 1, 18)])
q("C14-B-015", T, "Triangle cut off by two lines and the x-axis", "Easy",
  "Single-step computation",
  r"The lines $y = x + 2$ and $3x + y = 18$ together with the $x$-axis enclose a triangle. What is its area in square units?",
  "MCQ",
  r"The lines meet where $x + 2 = 18 - 3x$, that is at $(4, 6)$. They cut the $x$-axis at $x = -2$ and $x = 6$, so the base is $8$ and the height is $6$. Area $= \frac{1}{2} \times 8 \times 6 = 24$.",
  "Dropping the factor $\\frac{1}{2}$, or measuring the base from the origin.",
  "C14B-area-lines-polygon", "Two intercepts and one intersection point, then the triangle formula.",
  correct=r"$24$",
  distractors=[(r"$48$", "Uses base times height without the factor $\\frac{1}{2}$."),
               (r"$18$", "Measures the base from the origin to $x = 6$: $\\frac{1}{2} \\times 6 \\times 6$."),
               (r"$32$", "Uses the $y$-axis as the third side: base from $y = 2$ to $y = 18$, height $4$, area $\\frac{1}{2} \\times 16 \\times 4$.")],
  check=_c15, values=[24, 48, 18, 32], cognitive="Application")


def _c16():
    return _poly_area([(-1, 0, 0), (0, -1, 0), (1, 2, 16), (3, 1, 18)])
q("C14-B-016", T, "Area of the first-quadrant region under two lines", "Easy",
  "Single-step computation",
  r"Find the area, in square units, of the region of all points $(x, y)$ with $x \ge 0$, $y \ge 0$, $x + 2y \le 16$ and $3x + y \le 18$.",
  "MCQ",
  r"The lines $x + 2y = 16$ and $3x + y = 18$ meet at $(4, 6)$. The region is the quadrilateral with vertices $(0, 0)$, $(6, 0)$, $(4, 6)$ and $(0, 8)$. Splitting along the diagonal from $(0, 0)$ to $(4, 6)$: $\frac{1}{2} \times 6 \times 6 + \frac{1}{2} \times 8 \times 4 = 18 + 16 = 34$.",
  "Using the rectangle formed by the smaller intercepts, or the triangle under only one line.",
  "C14B-area-lines-polygon", "Find one intersection and split a quadrilateral into two triangles.",
  correct=r"$34$",
  distractors=[(r"$48$", "Takes the rectangle with sides equal to the smaller intercepts, $6 \\times 8$."),
               (r"$54$", "Uses only the triangle under $3x + y \\le 18$: $\\frac{1}{2} \\times 6 \\times 18$."),
               (r"$68$", "Applies the shoelace sum without halving it.")],
  check=_c16, values=[34, 48, 54, 68], cognitive="Application")


def _c17():
    # x + y >= 4, x - y <= 2, y <= 8, x >= 0
    return _poly_area([(-1, -1, -4), (1, -1, 2), (0, 1, 8), (-1, 0, 0)])
q("C14-B-017", T, "Area of a region defined by four linear inequalities", "Medium",
  "Conceptual/application",
  r"Find the area, in square units, of the region of all points $(x, y)$ satisfying $x + y \ge 4$, $x - y \le 2$, $y \le 8$ and $x \ge 0$.",
  "MCQ",
  r"Without $x + y \ge 4$, the lines $x = 0$, $y = 8$ and $x - y = 2$ bound the triangle with vertices $(0, -2)$, $(10, 8)$ and $(0, 8)$, of area $\frac{1}{2} \times 10 \times 10 = 50$. The condition $x + y \ge 4$ removes the corner triangle with vertices $(0, -2)$, $(0, 4)$ and $(3, 1)$, of area $\frac{1}{2} \times 6 \times 3 = 9$. The area is $50 - 9 = 41$.",
  "Ignoring one constraint, or adding the cut corner rather than removing it.",
  "C14B-area-lines-polygon", "Four constraints; the region is a quadrilateral best found as a triangle minus a corner.",
  correct=r"$41$",
  distractors=[(r"$50$", "Ignores the constraint $x + y \\ge 4$ and keeps the whole triangle."),
               (r"$59$", "Adds the corner triangle of area $9$ instead of removing it."),
               (r"$82$", "Applies the shoelace sum to the vertices $(0, 4)$, $(3, 1)$, $(10, 8)$, $(0, 8)$ without halving.")],
  check=_c17, values=[41, 50, 59, 82], cognitive="Application")


# ================================================================ C14B-area-v-and-line

def _c18():
    xs = [s for s in solve(Eq(3*Abs(X - 1), 6), X)]
    return integrate(6 - 3*Abs(X - 1), (X, min(xs), max(xs)))
q("C14-B-018", T, "Area between a steep V-shaped graph and a horizontal line", "Easy",
  "Single-step computation",
  r"Find the area, in square units, of the region enclosed by the graph of $y = 3|x - 1|$ and the line $y = 6$.",
  "MCQ",
  r"The graph is a V with vertex $(1, 0)$. It meets $y = 6$ where $|x - 1| = 2$, at $x = -1$ and $x = 3$. The region is a triangle with base $4$ and height $6$, so its area is $\frac{1}{2} \times 4 \times 6 = 12$.",
  "Ignoring the factor $3$ when finding where the arms reach $y = 6$.",
  "C14B-area-v-and-line", "One triangle once the two intersection points are found.",
  correct=r"$12$",
  distractors=[(r"$36$", "Ignores the factor $3$: solves $|x - 1| = 6$, base $12$, area $\\frac{1}{2} \\times 12 \\times 6$."),
               (r"$24$", "Uses base times height without the factor $\\frac{1}{2}$."),
               (r"$6$", "Uses only one arm, the triangle from $x = 1$ to $x = 3$.")],
  check=_c18, values=[12, 36, 24, 6], cognitive="Application")


def _c19():
    line = (X + 7) / 3
    xs = []
    for e in (X - 1, 1 - X):
        for s in solve(Eq(e, line), X):
            if simplify(Abs(s - 1) - e.subs(X, s)) == 0:
                xs.append(s)
    return integrate(line - Abs(X - 1), (X, min(xs), max(xs)))
q("C14-B-019", T, "Area between y = |x - 1| and a slanted line", "Medium",
  "Conceptual/application",
  r"The graph of $y = |x - 1|$ and the line $x - 3y + 7 = 0$ enclose a region. Find its area in square units.",
  "TITA",
  r"The line is $y = \frac{x + 7}{3}$. It meets the right arm $y = x - 1$ where $3x - 3 = x + 7$, at $(5, 4)$, and the left arm $y = 1 - x$ where $3 - 3x = x + 7$, at $(-1, 2)$. The region is the triangle with vertices $(1, 0)$, $(5, 4)$ and $(-1, 2)$. The arms are perpendicular, with legs $\sqrt{32} = 4\sqrt{2}$ and $\sqrt{8} = 2\sqrt{2}$, so the area is $\frac{1}{2} \times 4\sqrt{2} \times 2\sqrt{2} = 8$.",
  "Taking the area under the line alone, or dropping the half.",
  "C14B-area-v-and-line", "Two intersections on different arms, then a triangle with a right angle at the vertex.",
  tita_answer=8, check=_c19,
  tita_traps=[(18, "Computes only the area under the line from $x = -1$ to $x = 5$, a trapezium $\\frac{1}{2}(2 + 4) \\times 6$."),
              (16, "Uses the product of the legs without the factor $\\frac{1}{2}$.")],
  cognitive="Application")


def _c20():
    g = Abs(X - 1) + Abs(X - 5)
    line = X/2 + 6
    xs = set()
    for s1 in (1, -1):
        for s2 in (1, -1):
            e = s1*(X - 1) + s2*(X - 5)
            for s in solve(Eq(e, line), X):
                if s1*(s - 1) >= 0 and s2*(s - 5) >= 0:
                    xs.add(s)
    return integrate(line - g, (X, min(xs), max(xs)))
q("C14-B-020", T, "Area between y = |x - 1| + |x - 5| and a slanted line", "Difficult",
  "Casework/optimisation",
  r"Find the area, in square units, of the region enclosed by the graph of $y = |x - 1| + |x - 5|$ and the line $y = \frac{x}{2} + 6$.",
  "TITA",
  r"The graph is $y = 6 - 2x$ for $x \le 1$, the flat segment $y = 4$ for $1 \le x \le 5$, and $y = 2x - 6$ for $x \ge 5$. The line meets the left piece at $(0, 6)$ and the right piece at $(8, 10)$; it never meets the flat part (that would need $x = -4$). The region is the quadrilateral $(0, 6)$, $(1, 4)$, $(5, 4)$, $(8, 10)$. Area under the line from $0$ to $8$ is $\frac{1}{2}(6 + 10) \times 8 = 64$; area under the graph is $5 + 16 + 21 = 42$; the region has area $64 - 42 = 22$.",
  "Treating the graph as a V with a single vertex, or not subtracting the area under the graph.",
  "C14B-area-v-and-line", "Needs the flat-bottomed shape of a sum of two moduli, two intersections with a sloping line, and a four-sided region.",
  tita_answer=22, check=_c20,
  tita_traps=[(64, "Computes only the area under the line between the two intersection points."),
              (44, "Applies the shoelace sum to the four vertices without halving it.")],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-area-two-strips

def _c21():
    return _poly_area([(1, -1, 2), (-1, 1, 2), (1, 1, 5), (-1, -1, 5)])
q("C14-B-021", T, "Area of the rectangle |x - y| <= 2, |x + y| <= 5", "Medium",
  "Conceptual/application",
  r"Find the area, in square units, of the region of all points $(x, y)$ with $|x - y| \le 2$ and $|x + y| \le 5$.",
  "MCQ",
  r"The region lies between the parallel lines $x - y = \pm 2$ and between $x + y = \pm 5$; the two families are perpendicular, so it is a rectangle. The gaps between the pairs are $\frac{4}{\sqrt{2}} = 2\sqrt{2}$ and $\frac{10}{\sqrt{2}} = 5\sqrt{2}$, so the area is $2\sqrt{2} \times 5\sqrt{2} = 20$. (Equivalently, the diagonals of the rectangle give the same result.)",
  "Taking $4$ and $10$ as the side lengths, ignoring the $\\sqrt{2}$ in the distance between parallel lines.",
  "C14B-area-two-strips", "Recognising a tilted rectangle and computing the distance between parallel lines.",
  correct=r"$20$",
  distractors=[(r"$40$", "Takes the side lengths as $4$ and $10$, the differences of the constants."),
               (r"$10$", "Multiplies the two half-widths $2$ and $5$."),
               (r"$80$", "Multiplies by $\\sqrt{2}$ instead of dividing: sides $4\\sqrt{2}$ and $10\\sqrt{2}$.")],
  check=_c21, values=[20, 40, 10, 80], cognitive="Understanding")


def _c22():
    return _poly_area([(1, -1, 3), (-1, 1, 3), (1, 2, 6), (-1, -2, 6), (1, 0, 2), (-1, 0, 2)])
q("C14-B-022", T, "Area of the parallelogram |x - y| <= 3, |x + 2y| <= 6 cut by the strip |x| <= 2", "Difficult",
  "Casework/optimisation",
  r"Find the area, in square units, of the region of all points $(x, y)$ with $|x - y| \le 3$, $|x + 2y| \le 6$ and $|x| \le 2$.",
  "MCQ",
  r"The first two conditions give a parallelogram with vertices $(4, 1)$, $(0, 3)$, $(-4, -1)$ and $(0, -3)$; its diagonal along the $y$-axis has length $6$ and the other two vertices are $4$ units on either side, so its area is $2 \times \frac{1}{2} \times 6 \times 4 = 24$. The condition $x \le 2$ cuts off the corner at $(4, 1)$: the line $x = 2$ meets $x - y = 3$ at $(2, -1)$ and $x + 2y = 6$ at $(2, 2)$, leaving a triangle with base $3$ and height $2$, of area $3$. By symmetry $x \ge -2$ cuts off another $3$ at $(-4, -1)$. The area is $24 - 3 - 3 = 18$.",
  "Ignoring the third condition, cutting only one corner, or dropping the half in the corner triangles.",
  "C14B-area-two-strips", "Non-perpendicular strips give a slanted parallelogram whose vertices must be found, and a third strip then cuts two corners that must be located and subtracted.",
  correct=r"$18$",
  distractors=[(r"$24$", "Ignores the condition $|x| \\le 2$ and gives the area of the whole parallelogram."),
               (r"$21$", "Uses only $x \\le 2$ and cuts off just the corner at $(4, 1)$: $24 - 3$."),
               (r"$12$", "Takes each corner triangle as base times height, $3 \\times 2 = 6$, without halving: $24 - 6 - 6$.")],
  check=_c22, values=[18, 24, 21, 12], cognitive="Analysis", exams=CX)


# ================================================================ C14B-pivot-line-v

def _pivot_set(px, py, branches, kinks, target):
    def cnt(m):
        return _line_vs_branches(m, py - m*px, branches)
    crit = [b[0] for b in branches] + [Rational(ky - py, kx - px) for kx, ky in kinks if kx != px]
    return _assemble(crit, cnt, target)


def _c23():
    br = [(1, -1, 1, None), (-1, 1, None, 1)]          # y = |x - 1|
    return _pivot_set(-2, 0, br, [(1, 0)], 2)
q("C14-B-023", T, "Slopes of lines through (-2, 0) meeting y = |x - 1| twice", "Medium",
  "Inverse/parameter",
  r"For a real number $m$, consider the line $y = m(x + 2)$. For which values of $m$ does this line meet the graph of $y = |x - 1|$ at exactly two points?",
  "MCQ",
  r"The line passes through $(-2, 0)$; the V has vertex $(1, 0)$ and arms of slopes $-1$ and $1$. For $0 < m < 1$ the line is below the left arm at $x = -2$ and above the vertex at $x = 1$, so it crosses the left arm once; since its slope is less than $1$, the right arm overtakes it once. For $m = 0$ it touches only the vertex, and for $m \ge 1$ the right arm never catches up, leaving one point. For $m < 0$ the line is negative for $x > -2$, so it can meet only the left arm, at most once. Hence $0 < m < 1$.",
  "Including the boundary slope $1$, or assuming negative slopes behave symmetrically.",
  "C14B-pivot-line-v", "A rotating line against a V: casework on the slope relative to the arms and the vertex.",
  correct=r"$0 < m < 1$",
  distractors=[(r"$-1 < m < 1$", "Assumes negative slopes mirror positive ones, though the pivot is not below the vertex."),
               (r"$0 < m \le 1$", "Includes $m = 1$, where the line is parallel to the right arm and meets the graph only once."),
               (r"$m > 1$", "Thinks the line must be steeper than the right arm to cut it.")],
  check=_c23, values=[Interval.open(0, 1), Interval.open(-1, 1), Interval.Lopen(0, 1), Interval.open(1, oo)],
  cognitive="Analysis")


def _c24():
    br = [(1, -1, 2, None), (-1, 3, None, 2)]          # y = |x - 2| + 1
    return _pivot_set(0, 0, br, [(2, 1)], 0)
q("C14-B-024", T, "Slopes of lines through the origin missing y = |x - 2| + 1", "Difficult",
  "Inverse/parameter",
  r"For a real number $m$, the line $y = mx$ does not meet the graph of $y = |x - 2| + 1$ at any point exactly when",
  "MCQ",
  r"The graph is a V with vertex $(2, 1)$ and arms $y = 3 - x$ (for $x \le 2$) and $y = x - 1$ (for $x \ge 2$). The line through the origin hits the vertex when $m = \frac{1}{2}$; for $\frac{1}{2} < m < 1$ it meets both arms, and for $m \ge 1$ it meets the left arm. For $m < -1$ it is steeper than the left arm and meets it once for some $x < 0$. For $m = -1$ the line $y = -x$ is parallel to the left arm $y = 3 - x$ and $3$ units below it, and it is also below the right arm, so there is no meeting; for $-1 < m < \frac{1}{2}$ it stays below the graph. Hence the condition is $-1 \le m < \frac{1}{2}$.",
  "Mishandling the boundary cases: the parallel slope $-1$ (no meeting) and the vertex slope $\\frac{1}{2}$ (one meeting).",
  "C14B-pivot-line-v", "Casework over all slopes including negative ones, with two different boundary behaviours.",
  correct=r"$-1 \le m < \frac{1}{2}$",
  distractors=[(r"$-1 < m < \frac{1}{2}$", "Thinks the line of slope $-1$ meets the left arm, though it is parallel to it."),
               (r"$0 \le m < \frac{1}{2}$", "Ignores negative slopes, assuming they always meet the graph."),
               (r"$-1 \le m \le \frac{1}{2}$", "Includes $m = \\frac{1}{2}$, where the line passes through the vertex $(2, 1)$.")],
  check=_c24, values=[Interval.Ropen(-1, R(1, 2)), Interval.open(-1, R(1, 2)), Interval.Ropen(0, R(1, 2)), Interval(-1, R(1, 2))],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-curve-diamond-count

def _diamond_hits(a, curve_eqs):
    """Points on |x| + |y| = a that satisfy every equation in curve_eqs (in xs, ys)."""
    xs, ys = symbols('xs ys', real=True)
    pts = set()
    for sx in (1, -1):
        for sy in (1, -1):
            eqs = [Eq(sx*xs + sy*ys, a)] + [e(xs, ys) for e in curve_eqs]
            for s in solve(eqs, [xs, ys], dict=True):
                px, py = s[xs], s[ys]
                if px.is_real and py.is_real and sx*px >= 0 and sy*py >= 0:
                    pts.add((nsimplify(px), nsimplify(py)))
    return pts


def _c25():
    return len(_diamond_hits(6, [lambda x, y: Eq(x**2 + y**2, 20)]))
q("C14-B-025", T, "Intersection points of a circle and the square |x| + |y| = 6", "Easy",
  "Conceptual/application",
  r"At how many points does the circle $x^2 + y^2 = 20$ meet the graph of $|x| + |y| = 6$?",
  "TITA",
  r"By symmetry, look at the first quadrant, where the graph is the segment $x + y = 6$. Then $x^2 + (6 - x)^2 = 20$ gives $x^2 - 6x + 8 = 0$, so $x = 2$ or $x = 4$: the points $(2, 4)$ and $(4, 2)$, neither on an axis. Each quadrant gives $2$ points, so there are $8$ in all.",
  "Assuming one point per quadrant.",
  "C14B-curve-diamond-count", "One quadratic, then symmetry over four quadrants.",
  tita_answer=8, check=_c25,
  tita_traps=[(4, "Assumes the circle meets each side of the square once."),
              (2, "Counts only the two first-quadrant points.")],
  cognitive="Application")


def _c26():
    def cnt(r):
        return len(_diamond_hits(4, [lambda x, y: Eq(x**2 + y**2, r**2)]))
    return _assemble([2*sqrt(2), 4], cnt, 4, lo=0)
q("C14-B-026", T, "Radii for which a circle meets |x| + |y| = 4 at exactly four points", "Medium",
  "Inverse/parameter",
  r"For $r > 0$, the circle $x^2 + y^2 = r^2$ meets the graph of $|x| + |y| = 4$ at exactly four points if and only if",
  "MCQ",
  r"The graph is a square with vertices $(\pm 4, 0)$ and $(0, \pm 4)$. The distance from the origin to a side ranges from $2\sqrt{2}$ (at the midpoint, such as $(2, 2)$) to $4$ (at the vertices). For $r = 2\sqrt{2}$ the circle touches each side once: $4$ points. For $2\sqrt{2} < r < 4$ it cuts each side twice: $8$ points. For $r = 4$ it passes through the four vertices: $4$ points. Otherwise it misses the square.",
  "Forgetting that the circle through the four vertices also gives exactly four points, or taking the inradius as $2$.",
  "C14B-curve-diamond-count", "Needs both tangency and the vertex case of a circle against a tilted square.",
  correct=r"$r = 2\sqrt{2}$ or $r = 4$",
  distractors=[(r"$2\sqrt{2} < r < 4$", "Gives the range where the circle cuts each side twice, which yields $8$ points."),
               (r"$r = 4$", "Keeps only the circle through the vertices and misses the inscribed circle."),
               (r"$r = 2$ or $r = 4$", "Takes the distance from the origin to a side as half of $4$.")],
  check=_c26, values=[FiniteSet(2*sqrt(2), 4), Interval.open(2*sqrt(2), 4), FiniteSet(4), FiniteSet(2, 4)],
  cognitive="Analysis")


def _c27():
    return len(_diamond_hits(4, [lambda x, y: Eq(y, x**2 - 4)]))
q("C14-B-027", T, "Intersection points of the parabola y = x^2 - 4 and |x| + |y| = 4", "Difficult",
  "Casework/optimisation",
  r"At how many points does the parabola $y = x^2 - 4$ meet the graph of $|x| + |y| = 4$?",
  "TITA",
  r"For $y \ge 0$ the graph is $y = 4 - |x|$: $x^2 - 4 = 4 - |x|$ gives $|x|^2 + |x| - 8 = 0$, so $|x| = \frac{-1 + \sqrt{33}}{2} \approx 2.37$, with $y \approx 1.63 \ge 0$: $2$ points. For $y \le 0$ the graph is $y = |x| - 4$: $x^2 - 4 = |x| - 4$ gives $|x| = 0$ or $|x| = 1$, that is $(0, -4)$, $(1, -3)$ and $(-1, -3)$: $3$ points. In all there are $5$ points.",
  "Doubling the solution $|x| = 0$, or missing the vertex $(0, -4)$ shared by two sides.",
  "C14B-curve-diamond-count", "Casework on the upper and lower halves, with a common point at a vertex of the square.",
  tita_answer=5, check=_c27,
  tita_traps=[(6, "Counts $|x| = 0$ as giving two points $x = \\pm 0$."),
              (4, "Misses the vertex $(0, -4)$ of the square, where the parabola has its lowest point.")],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-floor-graph-meet

def _c28():
    cnt = 0
    for n in range(-500, 500):
        x = Fraction(5 * (n - 1), 4)                 # [x] = n = (4x + 5)/5
        if math.floor(x) == n:
            cnt += 1
    return cnt
q("C14-B-028", T, "Meeting points of the step graph y = [x] and a line of slope 4/5", "Difficult",
  "Casework/optimisation",
  r"Here $[x]$ denotes the greatest integer less than or equal to $x$. At how many points does the graph of $y = [x]$ meet the line $5y = 4x + 5$?",
  "TITA",
  r"At a meeting point $y = [x] = n$ is an integer, so $x = \frac{5(n - 1)}{4}$, and we need $n \le x < n + 1$. This gives $4n \le 5n - 5 < 4n + 4$, that is $5 \le n < 9$. So $n = 5, 6, 7, 8$, with $x = 5, \frac{25}{4}, \frac{15}{2}, \frac{35}{4}$, which is $4$ points.",
  "Using $n \\le x \\le n + 1$, which wrongly admits the jump point $x = 10$.",
  "C14B-floor-graph-meet", "Converts a graph meeting into an integer inequality with a half-open interval; boundary handling decides the count.",
  tita_answer=4, check=_c28,
  tita_traps=[(5, "Uses $n \\le x \\le n + 1$, accepting $n = 9$ with $x = 10$, where $[x] = 10$."),
              (3, "Uses $n < x < n + 1$, rejecting $x = 5$ although $[5] = 5$.")],
  cognitive="Analysis", exams=CX)


def _c29():
    sols = set()
    for n in range(-5, 20):
        if n + 2 < 0:
            continue
        for x in (sqrt(n + 2), -sqrt(n + 2)):
            if floor(x) == n:
                sols.add(x)
    return FiniteSet(*sols)
q("C14-B-029", T, "Meeting points of y = [x] and the parabola y = x^2 - 2", "Difficult",
  "Casework/optimisation",
  r"Here $[x]$ denotes the greatest integer less than or equal to $x$. The graphs of $y = [x]$ and $y = x^2 - 2$ meet exactly at the points whose $x$-coordinates are",
  "MCQ",
  r"At a meeting point $[x] = n$ is an integer with $x^2 = n + 2$ and $n \le x < n + 1$. For $x \ge 0$: $n = 1$ gives $x = \sqrt{3}$ with $[\sqrt{3}] = 1$, and $n = 2$ gives $x = 2$; $n = 0$ gives $\sqrt{2}$ with $[\sqrt{2}] = 1 \ne 0$, and $n \ge 3$ fails since $\sqrt{n + 2} < n$. For $x < 0$: $n = -1$ gives $x = -1$ with $[-1] = -1$; $n = 0$ gives $-\sqrt{2}$ with $[-\sqrt{2}] = -2$, and larger $n$ fail similarly. So $x = -1, \sqrt{3}, 2$.",
  "Assuming the solutions must be integers, or that they are symmetric about the $y$-axis.",
  "C14B-floor-graph-meet", "Casework on the integer value of $[x]$ on both sides of the origin, with irrational solutions.",
  correct=r"$-1, \sqrt{3}, 2$",
  distractors=[(r"$\sqrt{3}, 2$", "Checks only $x \\ge 0$."),
               (r"$-1, 2$", "Assumes $x$ must be an integer because $x^2 - 2 = [x]$ is an integer."),
               (r"$-2, -\sqrt{3}, \sqrt{3}, 2$", "Assumes the meeting points are symmetric about the $y$-axis because $x^2 - 2$ is even.")],
  check=_c29, values=[FiniteSet(-1, sqrt(3), 2), FiniteSet(sqrt(3), 2), FiniteSet(-1, 2), FiniteSet(-2, -sqrt(3), sqrt(3), 2)],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-f-of-abs-x

def _c30():
    f = (X + 3)*(X - 1)*(X - 4)
    sols = set(s for s in solve(f, X) if s >= 0) | set(s for s in solve(f.subs(X, -X), X) if s < 0)
    return len(sols)
q("C14-B-030", T, "Number of x-intercepts of y = f(|x|) for a cubic f", "Easy",
  "Conceptual/application",
  r"Let $f(x) = (x + 3)(x - 1)(x - 4)$. How many real solutions does the equation $f(|x|) = 0$ have?",
  "MCQ",
  r"The graph of $y = f(|x|)$ keeps the part of $y = f(x)$ for $x \ge 0$ and mirrors it in the $y$-axis. We need $|x|$ to be a root of $f$; $|x| = -3$ is impossible, while $|x| = 1$ and $|x| = 4$ give $x = \pm 1, \pm 4$. That is $4$ solutions.",
  "Mirroring the negative root as well, or not mirroring at all.",
  "C14B-f-of-abs-x", "One idea: only the non-negative roots survive, each doubled.",
  correct=r"$4$",
  distractors=[(r"$6$", "Mirrors all three roots, including $-3$, as if $|x| = -3$ had solutions."),
               (r"$3$", "Assumes $f(|x|) = 0$ has the same roots as $f(x) = 0$."),
               (r"$2$", "Keeps only the positive roots $1$ and $4$ without mirroring them.")],
  check=_c30, values=[4, 6, 3, 2], cognitive="Understanding")


def _c31():
    pts = [(0, 2), (3, -1), (6, 5)]
    pos = _pl_hits(pts, 2)
    return len(pos | set(-x for x in pos))
q("C14-B-031", T, "Solutions of f(|x|) = 2 for a piecewise-linear f, including x = 0", "Medium",
  "Conceptual/application",
  r"A function $f$ is defined for $0 \le x \le 6$; its graph consists of the line segment from $(0, 2)$ to $(3, -1)$ followed by the line segment from $(3, -1)$ to $(6, 5)$. Let $g(x) = f(|x|)$ for $-6 \le x \le 6$. How many solutions does the equation $g(x) = 2$ have?",
  "TITA",
  r"On $[0, 6]$, $f(x) = 2$ at $x = 0$ (the starting point) and on the second segment, where $-1 + 2(x - 3) = 2$, at $x = 4.5$. The graph of $g$ mirrors this in the $y$-axis: $x = 4.5$ gives $x = \pm 4.5$, but $x = 0$ is its own mirror image. So $g(x) = 2$ at $x = -4.5, 0, 4.5$: $3$ solutions.",
  "Doubling every solution, including $x = 0$.",
  "C14B-f-of-abs-x", "Reading a piecewise graph and noticing that a solution on the axis of symmetry is not doubled.",
  tita_answer=3, check=_c31,
  tita_traps=[(4, "Doubles both solutions, counting $x = 0$ twice."),
              (2, "Counts the solutions of $f(x) = 2$ on $[0, 6]$ and does not mirror.")],
  cognitive="Analysis")


def _c32():
    def cnt(k):
        s = set(r for r in solve(X**2 - 8*X + 12 - k, X) if r.is_real and r >= 0)
        s |= set(r for r in solve(X**2 + 8*X + 12 - k, X) if r.is_real and r < 0)
        return len(s)
    return sum(1 for k in range(-30, 40) if cnt(k) == 4)
q("C14-B-032", T, "Integer heights of horizontal lines meeting y = x^2 - 8|x| + 12 four times", "Difficult",
  "Inverse/parameter",
  r"For how many integer values of $k$ does the line $y = k$ meet the graph of $y = x^2 - 8|x| + 12$ at exactly four points?",
  "MCQ",
  r"The graph is $y = f(|x|)$ with $f(x) = x^2 - 8x + 12 = (x - 4)^2 - 4$: for $x \ge 0$ it falls from $12$ at $x = 0$ to $-4$ at $x = 4$ and then rises, and the left half is the mirror image, a W shape. A line $y = k$ meets each half twice exactly when $-4 < k < 12$; at $k = 12$ it meets at $x = 0, \pm 8$ (three points) and at $k = -4$ only at $x = \pm 4$. So $k = -3, -2, \ldots, 11$: $15$ values.",
  "Including an endpoint where two of the meeting points merge.",
  "C14B-f-of-abs-x", "Must build the W shape of $f(|x|)$ and treat both ends of the range, where the count drops for different reasons.",
  correct=r"$15$",
  distractors=[(r"$16$", "Includes $k = 12$, where the middle peak gives only one point, $x = 0$, so there are three points in all."),
               (r"$17$", "Includes both $k = 12$ and $k = -4$."),
               (r"$12$", "Takes only $0 \\le k \\le 11$, assuming a line below the $x$-axis cannot meet the graph four times.")],
  check=_c32, values=[15, 16, 17, 12], cognitive="Analysis", exams=CX)


# ================================================================ C14B-abs-of-f-count

def _c33():
    pts = [(0, -3), (2, 3), (5, -3), (8, 3)]
    return len(_pl_hits(pts, 2) | _pl_hits(pts, -2))
q("C14-B-033", T, "Solutions of |f(x)| = 2 for a zigzag graph", "Easy",
  "Conceptual/application",
  r"A function $f$ is defined for $0 \le x \le 8$; its graph is made of the line segments joining $(0, -3)$ to $(2, 3)$, $(2, 3)$ to $(5, -3)$, and $(5, -3)$ to $(8, 3)$. How many solutions does the equation $|f(x)| = 2$ have?",
  "TITA",
  r"$|f(x)| = 2$ means $f(x) = 2$ or $f(x) = -2$. Each of the three segments runs between $-3$ and $3$, so it crosses both levels $2$ and $-2$ once, at points that are not shared by two segments. That gives $3 \times 2 = 6$ solutions.",
  "Solving only $f(x) = 2$.",
  "C14B-abs-of-f-count", "One idea: $|f| = 2$ splits into two levels; each segment crosses each level once.",
  tita_answer=6, check=_c33,
  tita_traps=[(3, "Solves only $f(x) = 2$."),
              (12, "Draws the graph of $|f|$, whose six monotone pieces each rise or fall between $0$ and $3$, and then counts each piece twice, once for the level $2$ and once for the level $-2$.")],
  cognitive="Understanding")


def _c34():
    pts = [(0, 4), (2, -2), (4, 1), (6, -3)]
    def cnt(k):
        k = Fraction(str(k)) if not isinstance(k, Fraction) else k
        return len(_pl_hits(pts, k) | _pl_hits(pts, -k))
    def cnt_s(k):
        return cnt(Fraction(int(Rational(k).p), int(Rational(k).q)))
    crit = [1, 2, 3, 4]
    return _assemble(crit, cnt_s, 4, lo=0)
q("C14-B-034", T, "Values of k for which |f(x)| = k has exactly four solutions", "Difficult",
  "Inverse/parameter",
  r"A function $f$ is defined for $0 \le x \le 6$; its graph is made of the line segments joining $(0, 4)$ to $(2, -2)$, $(2, -2)$ to $(4, 1)$, and $(4, 1)$ to $(6, -3)$. For $k > 0$, the equation $|f(x)| = k$ has exactly four solutions if and only if",
  "MCQ",
  r"Reflecting the negative parts upward, $y = |f(x)|$ falls from $4$ to $0$ (at $x = \frac{4}{3}$), rises to $2$ at $x = 2$, falls to $0$ (at $x = \frac{10}{3}$), rises to a small peak $1$ at $x = 4$, falls to $0$ (at $x = \frac{9}{2}$) and rises to $3$ at $x = 6$. For $0 < k < 1$ the line $y = k$ meets all six monotone pieces ($6$ solutions); $k = 1$ gives $5$; for $1 < k < 2$ it misses the small peak and meets each of the other four pieces once: $4$ solutions; $k = 2$ gives $3$; for $k > 2$ there are at most $2$. Hence $1 < k < 2$.",
  "Missing the small peak created by reflection, or counting a peak point twice.",
  "C14B-abs-of-f-count", "Build the graph of $|f|$ with three peaks of different heights and count carefully at each level.",
  correct=r"$1 < k < 2$",
  distractors=[(r"$0 < k < 2$", "Overlooks the small peak of height $1$ near $x = 4$, so believes the count is $4$ for $0 < k < 1$ as well."),
               (r"$1 < k \le 2$", "At $k = 2$ counts the peak point $x = 2$ twice, once for each segment meeting there."),
               (r"$1 \le k < 2$", "At $k = 1$ ignores the point $x = 4$ where the line only touches the small peak.")],
  check=_c34, values=[Interval.open(1, 2), Interval.open(0, 2), Interval.Lopen(1, 2), Interval.Ropen(1, 2)],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-abs-graph-reading

def _c35():
    return solve_univariate_inequality(Abs(X - 3) - 2 < 0, X, relational=False)
q("C14-B-035", T, "Where the graph of y = |x - 3| - 2 lies strictly below the x-axis", "Easy",
  "Conceptual/application",
  r"The graph of $y = |x - 3| - 2$ lies strictly below the $x$-axis exactly when",
  "MCQ",
  r"The graph is a V with vertex $(3, -2)$ and arms of slopes $\pm 1$, so it meets the $x$-axis where $|x - 3| = 2$, at $x = 1$ and $x = 5$, and lies below the axis between them. Hence $|x - 3| < 2$, that is $1 < x < 5$.",
  "Dropping the modulus, or including the $x$-intercepts where $y = 0$.",
  "C14B-abs-graph-reading", "One idea: the part of a V below a level lies between its two crossing points.",
  correct=r"$1 < x < 5$",
  distractors=[(r"$x < 5$", "Drops the modulus and solves $x - 3 - 2 < 0$, ignoring the left arm of the V."),
               (r"$x < 1$ or $x > 5$", "Reverses the inequality, giving where the graph is above the $x$-axis."),
               (r"$1 \le x \le 5$", "Includes the $x$-intercepts $x = 1$ and $x = 5$, where $y = 0$.")],
  check=_c35, values=[Interval.open(1, 5), Interval.open(-oo, 5), Union(Interval.open(-oo, 1), Interval.open(5, oo)), Interval(1, 5)],
  cognitive="Understanding")


def _c36():
    f = lambda t: t**2 - 4*t
    cands = [(5, 5), (-1, 5), (-1, -3), (2, 4)]
    both = [p for p in cands if abs(f(p[0])) == p[1] and f(abs(p[0])) == p[1]]
    assert len(both) == 1
    return both[0]
q("C14-B-036", T, "A point common to y = |f(x)| and y = f(|x|)", "Medium",
  "Conceptual/application",
  r"Let $f(x) = x^2 - 4x$. Which of these points lies on both the graph of $y = |f(x)|$ and the graph of $y = f(|x|)$?",
  "MCQ",
  r"At $(5, 5)$: $|f(5)| = |25 - 20| = 5$ and $f(|5|) = 5$, so it lies on both. At $x = -1$: $|f(-1)| = 5$ but $f(|-1|) = f(1) = -3$, so $(-1, 5)$ is only on the first graph and $(-1, -3)$ only on the second. At $x = 2$: $|f(2)| = 4$ but $f(2) = -4$, so $(2, 4)$ is only on the first graph.",
  "Treating $|f(x)|$ and $f(|x|)$ as the same function.",
  "C14B-abs-graph-reading", "Needs both transformations evaluated correctly and compared at several points.",
  correct=r"$(5, 5)$",
  distractors=[(r"$(-1, 5)$", "Lies on $y = |f(x)|$ only; taking $f(|x|) = |f(x)|$ puts it on both."),
               (r"$(-1, -3)$", "Lies on $y = f(|x|)$ only; taking $|f(x)| = f(|x|)$ puts it on both."),
               (r"$(2, 4)$", "Lies on $y = |f(x)|$ only; reflects $f(2) = -4$ for both graphs.")],
  check=_c36, values=[(5, 5), (-1, 5), (-1, -3), (2, 4)], cognitive="Understanding")


def _c37():
    tests = [X - 1, X**2 - 4*X, X**3 - 2, 2**X - 3, -X**2 + X + 1]
    pts = [R(k, 2) for k in range(-9, 10)]
    stm = {
        1: lambda f: all(f.subs(X, Abs(t)) == f.subs(X, Abs(-t)) for t in pts),
        2: lambda f: all(Abs(f.subs(X, t)) == Abs(f.subs(X, -t)) for t in pts),
        3: lambda f: all(Abs(f.subs(X, t)) == f.subs(X, Abs(t)) for t in pts if t >= 0),
        4: lambda f: all(f.subs(X, Abs(t)) >= 0 for t in pts),
    }
    ok = [k for k, s in stm.items() if all(s(f) for f in tests)]
    assert len(ok) == 1
    return ok[0]
q("C14-B-037", T, "Which property holds for y = |f(x)| or y = f(|x|) for every f", "Medium",
  "Conceptual/application",
  r"Let $f$ be any function defined for all real numbers. Which statement is true for every such $f$?",
  "MCQ",
  r"Since $|-x| = |x|$, $f(|-x|) = f(|x|)$ for every $x$, so the graph of $y = f(|x|)$ is always symmetric about the $y$-axis. The others fail for $f(x) = x - 1$: $|f(2)| = 1$ but $|f(-2)| = 3$, so $y = |f(x)|$ is not symmetric; at $x = 0$, $|f(0)| = 1$ while $f(|0|) = -1$, so the two graphs differ for $x \ge 0$; and $f(|0|) = -1 < 0$.",
  "Confusing the reflection of the negative $y$ part in $|f(x)|$ with the mirroring of the right half in $f(|x|)$.",
  "C14B-abs-graph-reading", "Needs a clear picture of how each transformation acts and a quick counterexample for the rest.",
  correct=r"The graph of $y = f(|x|)$ is symmetric about the $y$-axis.",
  distractors=[(r"The graph of $y = |f(x)|$ is symmetric about the $y$-axis.", "Attributes the mirror symmetry of $f(|x|)$ to $|f(x)|$; fails for $f(x) = x - 1$."),
               (r"The graphs of $y = |f(x)|$ and $y = f(|x|)$ coincide for $x \ge 0$.", r"Thinks both transformations leave the part with $x \ge 0$ unchanged; but $|f|$ also flips negative values there."),
               (r"The graph of $y = f(|x|)$ never goes below the $x$-axis.", "Attributes the non-negativity of $|f(x)|$ to $f(|x|)$.")],
  check=_c37, values=[1, 2, 3, 4], cognitive="Understanding")


# ================================================================ C14B-hyperbola-v-meet

def _hyp_v(c, k):
    """Number of x with c/x = |x - k|."""
    sols = set()
    for e in (X - k, k - X):
        for r in solve(Eq(e * X, c), X):
            if r.is_real and r != 0 and simplify(e.subs(X, r) - Abs(r - k)) == 0 and c / r >= 0:
                sols.add(nsimplify(r))
    return len(sols)


def _c38():
    return _hyp_v(2, 3)
q("C14-B-038", T, "Meeting points of y = 2/x and y = |x - 3|", "Medium",
  "Casework/optimisation",
  r"At how many points does the graph of $y = \frac{2}{x}$ meet the graph of $y = |x - 3|$?",
  "TITA",
  r"Since $|x - 3| \ge 0$, any meeting point has $x > 0$. For $0 < x < 3$: $3 - x = \frac{2}{x}$ gives $x^2 - 3x + 2 = 0$, so $x = 1$ or $x = 2$. For $x \ge 3$: $x - 3 = \frac{2}{x}$ gives $x^2 - 3x - 2 = 0$, so $x = \frac{3 + \sqrt{17}}{2} \approx 3.56$. That is $3$ points.",
  "Missing one arm of the V, or keeping only integer solutions.",
  "C14B-hyperbola-v-meet", "Casework on the two arms with a quadratic on each and range checks.",
  tita_answer=3, check=_c38,
  tita_traps=[(2, "Keeps only the left-arm solutions $x = 1$ and $x = 2$."),
              (1, "Solves only on the right arm $x \\ge 3$.")],
  cognitive="Application")


def _c39():
    return _assemble([-2, 0, 2], lambda k: _hyp_v(1, k), 2)
q("C14-B-039", T, "Values of k for which y = 1/x and y = |x - k| meet at exactly two points", "Difficult",
  "Inverse/parameter",
  r"For a real number $k$, the graphs of $y = \frac{1}{x}$ and $y = |x - k|$ meet at exactly two points if and only if",
  "MCQ",
  r"Meeting points need $x > 0$. On the right arm ($x \ge k$), $x^2 - kx - 1 = 0$ always has exactly one root with $x > 0$ and $x \ge k$, namely $\frac{k + \sqrt{k^2 + 4}}{2}$. On the left arm ($0 < x < k$), $x^2 - kx + 1 = 0$ has roots with product $1$ and sum $k$; they are real and positive only when $k \ge 2$, and then both are less than $k$. So there are $3$ points for $k > 2$, $2$ points for $k = 2$ (the left arm touches at $(1, 1)$) and $1$ point for $k < 2$. Hence $k = 2$.",
  "Assuming symmetry in $k$, or confusing the two-point case with the three-point range.",
  "C14B-hyperbola-v-meet", "Casework on both arms with a discriminant and sign conditions; the right arm contributes a point for every $k$.",
  correct=r"$k = 2$",
  distractors=[(r"$k = -2$ or $k = 2$", "Takes both roots of $k^2 = 4$, but for $k = -2$ the left arm lies where $x < 0$, so only one point."),
               (r"$k > 2$", "Counts only the left-arm meetings, which number two when $k > 2$, forgetting the right-arm point."),
               (r"$k \ge 2$", "Uses the condition $k^2 - 4 \\ge 0$ for real roots on the left arm without counting points.")],
  check=_c39, values=[FiniteSet(2), FiniteSet(-2, 2), Interval.open(2, oo), Interval(2, oo)],
  cognitive="Analysis", exams=CX)


# ================================================================ C14B-exponential-line-meet

def _c40():
    h = lambda t: 2**t - 4*t + 4
    roots = set()
    N = 4000
    grid = [Fraction(-200 + i, 10) for i in range(N)]          # -20 to 380 / 10 = 20
    for a, b in zip(grid[:-1], grid[1:]):
        ha, hb = h(Rational(a.numerator, a.denominator)), h(Rational(b.numerator, b.denominator))
        if ha == 0:
            roots.add(Rational(a.numerator, a.denominator))
        elif ha * hb < 0:
            roots.add(nsolve(2**X - 4*X + 4, X, float(a + b) / 2))
    return sum(roots)
q("C14-B-040", T, "Meeting points of y = 2^x and a line, using convexity", "Medium",
  "Conceptual/application",
  r"The graphs of $y = 2^x$ and $y = 4x - 4$ meet at one or more points. Find the sum of the $x$-coordinates of all the meeting points.",
  "TITA",
  r"Trying small integers, $x = 2$ gives $4 = 4$ and $x = 3$ gives $8 = 8$, so both are meeting points. The graph of $y = 2^x$ bends upward (it is convex), so a straight line can meet it at most twice. Hence the meeting points are exactly $x = 2$ and $x = 3$, and the sum is $5$.",
  "Stopping after finding one meeting point.",
  "C14B-exponential-line-meet", "Spotting integer solutions and using the shape of the exponential to rule out more.",
  tita_answer=5, check=_c40,
  tita_traps=[(2, "Finds only $x = 2$."),
              (3, "Finds only $x = 3$.")],
  cognitive="Understanding")
