import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
import math as _m

TOPIC = "Triangle properties and centres"
HARD = ("CAT", "XAT")


def _tri(pq, qr, pr):
    """Exact triangle with Q=(0,0), R=(qr,0), P above QR, from the three side lengths."""
    pq, qr, pr = nsimplify(pq), nsimplify(qr), nsimplify(pr)
    x = (pq**2 - pr**2 + qr**2) / (2 * qr)
    y = sqrt(pq**2 - x**2)
    return Point(x, y), Point(0, 0), Point(qr, 0)


def _ftri(pq, qr, pr):
    """Float coordinates for figures: Q=(0,0), R=(qr,0), P above."""
    x = (pq**2 - pr**2 + qr**2) / (2.0 * qr)
    return (x, _m.sqrt(pq**2 - x**2)), (0.0, 0.0), (float(qr), 0.0)


def _angle_deg(a, v, b):
    """Angle at v (degrees, float) between rays v->a and v->b."""
    ax, ay = float(a[0] - v[0]), float(a[1] - v[1])
    bx, by = float(b[0] - v[0]), float(b[1] - v[1])
    return _m.degrees(_m.acos((ax * bx + ay * by) / (_m.hypot(ax, ay) * _m.hypot(bx, by))))


def _incentre_f(P, Q, R):
    a = _m.dist(Q, R); b = _m.dist(P, R); c = _m.dist(P, Q)
    s = a + b + c
    return ((a * P[0] + b * Q[0] + c * R[0]) / s, (a * P[1] + b * Q[1] + c * R[1]) / s)


def _circumcentre_f(P, Q, R):
    ax, ay = P; bx, by = Q; cx, cy = R
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    ux = ((ax**2 + ay**2) * (by - cy) + (bx**2 + by**2) * (cy - ay) + (cx**2 + cy**2) * (ay - by)) / d
    uy = ((ax**2 + ay**2) * (cx - bx) + (bx**2 + by**2) * (ax - cx) + (cx**2 + cy**2) * (bx - ax)) / d
    return (ux, uy)


def _foot_f(X, A, B):
    ax, ay = A; bx, by = B
    dx, dy = bx - ax, by - ay
    t = ((X[0] - ax) * dx + (X[1] - ay) * dy) / (dx * dx + dy * dy)
    return (ax + t * dx, ay + t * dy)


# ---------------------------------------------------------------- 001
def _c001():
    legs = [(0, 11), (6, 0), (0, -4), (18, 0)]   # (east, north) in km
    e = sum(Fraction(a) for a, b in legs); n = sum(Fraction(b) for a, b in legs)
    return sqrt(e**2 + n**2)
q("C15-C-001", TOPIC, "Straight-line distance after a walk along perpendicular legs", "Easy",
  "Multi-step word problem",
  r"Kabir leaves his house and walks $11$ km due north, then $6$ km due east, then $4$ km due south and finally $18$ km due east, all along straight roads. What is the straight-line distance between Kabir and his house at the end of the walk, in km?",
  "TITA",
  r"Net movement north is $11 - 4 = 7$ km and net movement east is $6 + 18 = 24$ km. These are perpendicular, so the distance is $\sqrt{7^2 + 24^2} = \sqrt{625} = 25$ km.",
  "Adding path lengths or adding the net components instead of combining them with Pythagoras.",
  "C15C-pythagoras-word", "Net displacement in two directions, then one Pythagorean triple (7, 24, 25).",
  tita_answer=25, check=_c001, values=[25],
  tita_traps=[(39, "Adds all four legs: $11 + 6 + 4 + 18$, the path length."),
              (31, "Adds the net components $7 + 24$ instead of using Pythagoras.")],
  cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    L, h0, drop = Rational(13, 2), 6, Rational(4, 5)
    x0 = sqrt(L**2 - h0**2)
    x1 = sqrt(L**2 - (h0 - drop)**2)
    return x1 - x0
_f = Fig()
_W0 = _f.pt("", 0, 0, dot=False); _W1 = _f.pt("", 0, 7.0, dot=False)
_f.seg(_W0, _W1); _f.seg((0, 0), (4.6, 0))
_T = _f.pt("T", 0, 6); _F = _f.pt("F", 2.5, 0)
_f.seg(_T, _F); _f.right_angle(_W1, _W0, _F)
_f.label_seg(_T, _F, "6.5 m"); _f.label_seg(_W0, _T, "6 m")
_alt = "A vertical wall and level ground. A ladder of length 6.5 m leans from the foot F on the ground to the point T on the wall, 6 m above the ground."
q("C15-C-002", TOPIC, "Sliding ladder: movement of the foot when the top slips down", "Easy",
  "Multi-step word problem",
  r"A ladder $6.5$ m long leans against a vertical wall on level ground, with its top $6$ m above the ground. The top of the ladder slips $0.8$ m down the wall, and the foot slides straight away from the wall, the ladder staying in contact with both. How far does the foot of the ladder slide?",
  "MCQ",
  r"Initially the foot is $\sqrt{6.5^2 - 6^2} = \sqrt{6.25} = 2.5$ m from the wall. After the slip the top is at $5.2$ m, so the foot is $\sqrt{6.5^2 - 5.2^2} = \sqrt{15.21} = 3.9$ m from the wall (a $3 : 4 : 5$ triangle scaled by $1.3$). The foot slides $3.9 - 2.5 = 1.4$ m.",
  "Assuming the foot moves by the same amount as the top.",
  "C15C-pythagoras-word", "Two Pythagoras computations with decimals; the trap is equal movement.",
  correct=r"$1.4$ m",
  distractors=[(r"$0.8$ m", "Assumes the foot slides out by the same distance that the top slips down."),
               (r"$3.9$ m", "Reports the new distance of the foot from the wall, not the change."),
               (r"$2.5$ m", "Reports the original distance of the foot from the wall.")],
  check=_c002, values=[Rational(7, 5), Rational(4, 5), Rational(39, 10), Rational(5, 2)],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    t = symbols('t', positive=True)             # t = QR, the side opposite the 30 degree angle at P
    # right angle at Q (axes); angle P = 30 deg means tan(P) = QR / PQ = 1/sqrt(3), so PQ = t*tan(60 deg)
    Q, R, P = Point(0, 0), Point(t, 0), Point(0, t * tan(pi / 3))
    QH = Line(P, R).distance(Q)                  # perpendicular from Q to PR
    tv = solve(Eq(QH, 3 * sqrt(3)), t)[0]
    return simplify(P.distance(R).subs(t, tv))
_Qc, _Rc, _Pc = (0.0, 0.0), (6.0, 0.0), (0.0, 6 * _m.sqrt(3))
_Hc = _foot_f(_Qc, _Pc, _Rc)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _H = _f.pt("H", *_Hc, offset=(0.7, 0.7))
_f.poly(_P, _Q, _R); _f.right_angle(_R, _Q, _P); _f.seg(_Q, _H, dashed=True); _f.right_angle(_R, _H, _Q)
_f.angle_mark(_Q, _P, _R, "30^\\circ")
_alt = "Right triangle PQR with the right angle at Q and the angle at P marked 30 degrees. QH is the dashed perpendicular from Q to the hypotenuse PR."
q("C15-C-003", TOPIC, "Hypotenuse of a 30-60-90 triangle from the altitude to the hypotenuse", "Easy",
  "Conceptual/application",
  r"In triangle $PQR$, $\angle Q = 90^\circ$ and $\angle P = 30^\circ$. The perpendicular from $Q$ to $PR$ meets it at $H$, and $QH = 3\sqrt{3}$ cm. What is the length of $PR$?",
  "MCQ",
  r"$\angle R = 60^\circ$, so triangle $QHR$ is $30$-$60$-$90$ with $QH$ opposite the $60^\circ$ angle at $R$. Hence $QR = \frac{2}{\sqrt{3}} \times 3\sqrt{3} = 6$ cm. In triangle $PQR$, $QR$ is opposite the $30^\circ$ angle, so $PR = 2 \times QR = 12$ cm.",
  "Placing the altitude opposite the wrong angle in the small 30-60-90 triangle, or stopping at a leg.",
  "C15C-306090-sides", "Two uses of the side ratio $1 : \\sqrt{3} : 2$, in the small and the large triangle.",
  correct=r"$12$ cm",
  distractors=[(r"$12\sqrt{3}$ cm", r"Treats $QH$ as opposite the $30^\circ$ angle in triangle $QHR$, so $QR = 2 \times 3\sqrt{3} = 6\sqrt{3}$, then doubles it."),
               (r"$6\sqrt{3}$ cm", r"Finds $QR = 6$ but reports $PQ = \sqrt{3} \times 6$, the other leg."),
               (r"$6$ cm", r"Stops at $QR = 6$ cm, the shortest side.")],
  check=_c003, values=[12, 12 * sqrt(3), 6 * sqrt(3), 6],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Application")

# ---------------------------------------------------------------- 004
def _c004():
    hyp = 18 * sqrt(2)
    leg = symbols('leg', positive=True)
    l = solve(Eq(2 * leg**2, hyp**2), leg)[0]
    return simplify(l * l / 2)
q("C15-C-004", TOPIC, "Area of an isosceles right triangle from its hypotenuse", "Easy",
  "Single-step computation",
  r"A triangular flower bed has angles $45^\circ$, $45^\circ$ and $90^\circ$. Its longest side measures $18\sqrt{2}$ m. What is the area of the flower bed, in m$^2$?",
  "TITA",
  r"In a $45$-$45$-$90$ triangle the hypotenuse is $\sqrt{2}$ times each leg, so each leg is $18$ m. The area is $\frac{1}{2} \times 18 \times 18 = 162$ m$^2$.",
  "Forgetting the factor one half, or halving the hypotenuse to get a leg.",
  "C15C-454590-sides", "One ratio and one area formula.",
  tita_answer=162, check=_c004, values=[162],
  tita_traps=[(324, r"Forgets the $\frac{1}{2}$: $18 \times 18$."),
              (81, r"Takes each leg as $9\sqrt{2}$ (half the hypotenuse), giving $\frac{1}{2}(9\sqrt{2})^2$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    P, Q, R = _tri(20, 34, 42)
    return abs(Triangle(P, Q, R).area)
q("C15-C-005", TOPIC, "Heron's formula for a scalene plot", "Easy",
  "Single-step computation",
  r"A triangular plot of land has sides $20$ m, $34$ m and $42$ m. What is its area?",
  "MCQ",
  r"The semi-perimeter is $s = \frac{20 + 34 + 42}{2} = 48$. By Heron's formula the area is $\sqrt{48 \times 28 \times 14 \times 6} = \sqrt{112896} = 336$ m$^2$. (Factorising helps: $48 \times 28 \times 14 \times 6 = 2^8 \times 3^2 \times 7^2$.)",
  "Assuming a right angle between two of the sides.",
  "C15C-heron-area", "Single application of Heron's formula; the trap is a false right angle.",
  correct=r"$336$ m$^2$",
  distractors=[(r"$340$ m$^2$", r"Assumes a right angle between the $20$ m and $34$ m sides: $\frac{1}{2} \times 20 \times 34$."),
               (r"$420$ m$^2$", r"Assumes a right angle between the $20$ m and $42$ m sides: $\frac{1}{2} \times 20 \times 42$."),
               (r"$714$ m$^2$", r"Assumes a right angle between the $34$ m and $42$ m sides: $\frac{1}{2} \times 34 \times 42$.")],
  check=_c005, values=[336, 340, 420, 714], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    # generic triangle: verify the centroid ratios, then apply to the givens
    P, Q, R = Point(1, 7), Point(0, 0), Point(9, 0)
    M = Point((Q.x + R.x) / 2, 0); N = Point((P.x + R.x) / 2, (P.y + R.y) / 2)
    G = Triangle(P, Q, R).centroid
    k_PG = P.distance(G) / P.distance(M)       # fraction of median from vertex
    k_GN = G.distance(N) / Q.distance(N)
    PM, GN = 18, 4
    return simplify(k_PG * PM + GN / k_GN)
_Pc, _Qc, _Rc = (4.0, _m.sqrt(320)), (0.0, 0.0), (12.0, 0.0)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
_Mc = (6.0, 0.0); _Nc = ((_Pc[0] + _Rc[0]) / 2, _Pc[1] / 2)
_Gc = ((_Pc[0] + _Qc[0] + _Rc[0]) / 3, _Pc[1] / 3)
_f.poly(_P, _Q, _R)
_M = _f.pt("M", *_Mc, offset=(0, -1)); _N = _f.pt("N", *_Nc, offset=(1, 0.3)); _G = _f.pt("G", *_Gc, offset=(1, 0.6))
_f.seg(_P, _M); _f.seg(_Q, _N)
_alt = "Triangle PQR with M the midpoint of QR and N the midpoint of PR. Medians PM and QN meet at G."
q("C15-C-006", TOPIC, "Centroid divides each median in the ratio 2 : 1", "Easy",
  "Conceptual/application",
  r"In triangle $PQR$, $M$ is the midpoint of $QR$ and $N$ is the midpoint of $PR$. The medians $PM$ and $QN$ meet at $G$. If $PM = 18$ cm and $GN = 4$ cm, what is $PG + QN$?",
  "MCQ",
  r"The centroid $G$ divides each median in the ratio $2 : 1$ from the vertex. So $PG = \frac{2}{3} \times 18 = 12$ cm, and $GN$ is one third of $QN$, so $QN = 3 \times 4 = 12$ cm. Hence $PG + QN = 24$ cm.",
  "Using the wrong ratio (1 : 1 or 1 : 2) for the centroid's division of a median.",
  "C15C-centroid-median-ratio", "One property applied twice, in opposite directions.",
  correct=r"$24$ cm",
  distractors=[(r"$17$ cm", r"Assumes $G$ bisects each median: $PG = 9$ and $QN = 2 \times 4 = 8$."),
               (r"$20$ cm", r"Gets $PG = 12$ but takes $QN = 2 \times GN = 8$."),
               (r"$12$ cm", r"Reverses the ratio: $PG = \frac{1}{3} \times 18 = 6$ and $QN = \frac{3}{2} \times 4 = 6$.")],
  check=_c006, values=[24, 17, 20, 12],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Understanding")

# ---------------------------------------------------------------- 007
def _c007():
    a = 18 * sqrt(3)
    P, Q, R = Point(a / 2, a * sqrt(3) / 2), Point(0, 0), Point(a, 0)
    X = Triangle(P, Q, R).circumcenter      # equidistant from the three vertices
    return simplify(Line(Q, R).distance(X))
q("C15-C-007", TOPIC, "Distance from the centre of an equilateral triangle to a side", "Easy",
  "Conceptual/application",
  r"A park is in the shape of an equilateral triangle of side $18\sqrt{3}$ m. A lamp post stands at the point inside the park that is equidistant from the three corners. What is the perpendicular distance from the lamp post to any side of the park, in metres?",
  "TITA",
  r"In an equilateral triangle the circumcentre, centroid and incentre coincide, so the lamp is at the centroid. The height is $\frac{\sqrt{3}}{2} \times 18\sqrt{3} = 27$ m, and the centroid lies one third of the height above each side, so the distance is $9$ m.",
  "Reporting the circumradius (distance to a corner) instead of the inradius (distance to a side).",
  "C15C-equilateral-centres", "Needs the coincidence of centres and the 1 : 2 split of the height.",
  tita_answer=9, check=_c007, values=[9],
  tita_traps=[(18, "Gives the distance to a corner, two thirds of the height."),
              (27, "Gives the full height of the triangle.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 008
def _c008():
    # build an acute triangle with angle P = 64 deg and find angle QOR at the circumcentre
    Pa, Qa = 64, 60
    Ra = 180 - Pa - Qa
    QR = 10.0
    PQ = QR * _m.sin(_m.radians(Ra)) / _m.sin(_m.radians(Pa))
    Q = (0.0, 0.0); R = (QR, 0.0); P = (PQ * _m.cos(_m.radians(Qa)), PQ * _m.sin(_m.radians(Qa)))
    O = _circumcentre_f(P, Q, R)
    return round(_angle_deg(Q, O, R), 9)
_Pc, _Qc, _Rc = None, (0.0, 0.0), (10.0, 0.0)
_PQl = 10.0 * _m.sin(_m.radians(56)) / _m.sin(_m.radians(64))
_Pc = (_PQl * _m.cos(_m.radians(60)), _PQl * _m.sin(_m.radians(60)))
_Oc = _circumcentre_f(_Pc, _Qc, _Rc)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _O = _f.pt("O", *_Oc, offset=(0, 1))
_f.poly(_P, _Q, _R); _f.seg(_O, _Q); _f.seg(_O, _R)
_f.angle_mark(_Q, _P, _R, "64^\\circ")
_alt = "Acute-angled triangle PQR with circumcentre O inside it, joined to Q and R. The angle at P is marked 64 degrees."
q("C15-C-008", TOPIC, "Angle subtended at the circumcentre by a side", "Easy",
  "Conceptual/application",
  r"$O$ is the circumcentre of an acute-angled triangle $PQR$ in which $\angle QPR = 64^\circ$. What is the measure of $\angle QOR$?",
  "MCQ",
  r"$O$ is the centre of the circle through $P$, $Q$ and $R$, so $\angle QOR$ is the angle at the centre on arc $QR$, and $\angle QPR$ is the angle at the circumference on the same arc. Since the triangle is acute, $O$ lies inside it and $\angle QOR = 2 \times 64^\circ = 128^\circ$.",
  "Using the incentre formula $90^\\circ + \\frac{P}{2}$ for the circumcentre.",
  "C15C-centre-angles", "One property of the circumcentre; the trap is the incentre formula.",
  correct=r"$128^\circ$",
  distractors=[(r"$122^\circ$", r"Uses the incentre result $90^\circ + \frac{64^\circ}{2}$."),
               (r"$116^\circ$", r"Takes the supplement $180^\circ - 64^\circ$."),
               (r"$64^\circ$", r"Assumes the angle at $O$ equals the angle at $P$.")],
  check=_c008, values=[128, 122, 116, 64],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Understanding")

# ---------------------------------------------------------------- 009
def _c009():
    # search the apex angle P for which angle QIR = 125 deg (any split of Q and R)
    hits = set()
    for p in range(1, 179):
        for qa in (Fraction(180 - p, 2), Fraction(180 - p, 3)):
            ra = 180 - p - qa
            QR = 10.0
            PQ = QR * _m.sin(_m.radians(float(ra))) / _m.sin(_m.radians(p))
            Q = (0.0, 0.0); R = (QR, 0.0)
            P = (PQ * _m.cos(_m.radians(float(qa))), PQ * _m.sin(_m.radians(float(qa))))
            I = _incentre_f(P, Q, R)
            if abs(_angle_deg(Q, I, R) - 125) < 1e-7:
                hits.add(p)
    assert len(hits) == 1
    return hits.pop()
_Qc, _Rc = (0.0, 0.0), (10.0, 0.0)
_PQl = 10.0 * _m.sin(_m.radians(50)) / _m.sin(_m.radians(70))
_Pc = (_PQl * _m.cos(_m.radians(60)), _PQl * _m.sin(_m.radians(60)))
_Ic = _incentre_f(_Pc, _Qc, _Rc)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _I = _f.pt("I", *_Ic, offset=(0, 1))
_f.poly(_P, _Q, _R); _f.seg(_I, _Q); _f.seg(_I, _R)
_f.angle_mark(_Q, _I, _R, "125^\\circ")
_alt = "Triangle PQR with incentre I joined to Q and R. The angle QIR at I is marked 125 degrees."
q("C15-C-009", TOPIC, "Recover a vertex angle from the angle at the incentre", "Easy",
  "Inverse/parameter",
  r"$I$ is the incentre of triangle $PQR$, and $\angle QIR = 125^\circ$. What is the measure of $\angle QPR$?",
  "MCQ",
  r"$IQ$ and $IR$ bisect $\angle Q$ and $\angle R$, so $\angle QIR = 180^\circ - \frac{Q + R}{2} = 180^\circ - \frac{180^\circ - P}{2} = 90^\circ + \frac{P}{2}$. Then $90^\circ + \frac{P}{2} = 125^\circ$ gives $P = 70^\circ$.",
  "Forgetting to double after subtracting 90 degrees, or treating the angles as supplementary.",
  "C15C-centre-angles", "Needs the incentre angle result used in reverse.",
  correct=r"$70^\circ$",
  distractors=[(r"$35^\circ$", r"Computes $125^\circ - 90^\circ$ and does not double it."),
               (r"$55^\circ$", r"Treats $\angle QIR$ and $\angle QPR$ as supplementary: $180^\circ - 125^\circ$."),
               (r"$110^\circ$", r"Uses $\angle QIR = 180^\circ - \frac{P}{2}$, giving $P = 2(180^\circ - 125^\circ)$.")],
  check=_c009, values=[70, 35, 55, 110],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Understanding")

# ---------------------------------------------------------------- 010
def _c010():
    S, Q, R = Point(0, 0), Point(10, 0), Point(0, 24)     # right angle at S
    G = Triangle(S, Q, R).centroid
    return S.distance(G)
q("C15-C-010", TOPIC, "Distance from the right-angle vertex to the centroid", "Easy",
  "Multi-step word problem",
  r"In triangle $PQR$, $\angle Q = 90^\circ$, $PQ = 10$ cm and $QR = 24$ cm. $G$ is the centroid of the triangle. What is the length $QG$?",
  "MCQ",
  r"The hypotenuse is $PR = \sqrt{10^2 + 24^2} = 26$ cm. The median from the right angle $Q$ goes to the midpoint of $PR$, which is the circumcentre, so its length is $\frac{26}{2} = 13$ cm. $G$ lies two thirds of the way along it, so $QG = \frac{2}{3} \times 13 = \frac{26}{3}$ cm.",
  "Stopping at the median length, or taking the wrong fraction of it.",
  "C15C-right-median-centroid", "Two linked facts: median to hypotenuse is half of it, and the 2 : 1 split.",
  correct=r"$\frac{26}{3}$ cm",
  distractors=[(r"$\frac{13}{3}$ cm", r"Takes one third of the median instead of two thirds."),
               (r"$\frac{52}{3}$ cm", r"Takes the median as the full hypotenuse $26$ and then two thirds of it."),
               (r"$\frac{34}{3}$ cm", r"Takes the median as the average of the legs, $\frac{10 + 24}{2} = 17$, then two thirds of it.")],
  check=_c010, values=[Rational(26, 3), Rational(13, 3), Rational(52, 3), Rational(34, 3)], cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    P, Q, R = _tri(9, 10, 17)
    return Triangle(P, Q, R).inradius
q("C15-C-011", TOPIC, "Inradius of a scalene triangle as area over semi-perimeter", "Easy",
  "Multi-step word problem",
  r"A triangular garden has sides $9$ m, $10$ m and $17$ m. A circular pond is built inside it so that the pond touches all three sides of the garden. What is the radius of the pond, in metres?",
  "TITA",
  r"The pond is the incircle. The semi-perimeter is $s = 18$, and Heron's formula gives area $\sqrt{18 \times 9 \times 8 \times 1} = \sqrt{1296} = 36$ m$^2$. The inradius is $\frac{\text{Area}}{s} = \frac{36}{18} = 2$ m.",
  "Dividing the area by the full perimeter instead of the semi-perimeter.",
  "C15C-inradius-area-over-s", "Heron's formula followed by $r = \\frac{\\Delta}{s}$.",
  tita_answer=2, check=_c011, values=[2],
  tita_traps=[(1, "Divides the area $36$ by the perimeter $36$ instead of the semi-perimeter."),
              (4, r"Uses $r = \frac{2\Delta}{s}$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 012
def _c012():
    P, Q, R = _tri(7, 8, 9)
    M = Point(4, 0)
    return P.distance(M)
q("C15-C-012", TOPIC, "Median length from the three sides (Apollonius)", "Easy",
  "Single-step computation",
  r"In triangle $PQR$, $PQ = 7$ cm, $QR = 8$ cm and $PR = 9$ cm. What is the length of the median from $P$ to the side $QR$?",
  "MCQ",
  r"By Apollonius' theorem, $PQ^2 + PR^2 = 2PM^2 + 2QM^2$ where $M$ is the midpoint of $QR$. So $49 + 81 = 2PM^2 + 2 \times 16$, giving $PM^2 = 49$ and $PM = 7$ cm.",
  "Using a shortcut such as averaging the two sides, or forgetting the division in the median formula.",
  "C15C-apollonius-median", "Direct use of Apollonius' theorem.",
  correct=r"$7$ cm",
  distractors=[(r"$8$ cm", r"Takes the median as the average of $PQ$ and $PR$."),
               (r"$4$ cm", r"Takes the median as half of $QR$, which holds only if $\angle P = 90^\circ$."),
               (r"$14$ cm", r"Uses $PM^2 = 2PQ^2 + 2PR^2 - QR^2 = 196$, forgetting to divide by $4$.")],
  check=_c012, values=[7, 8, 4, 14], cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    T = Triangle(Point(0, 0), Point(16, 0), Point(0, 30))
    return T.circumradius + T.inradius
q("C15-C-013", TOPIC, "Sum of circumradius and inradius of a right triangle", "Medium",
  "Multi-step word problem",
  r"A right-angled triangle has legs $16$ cm and $30$ cm. What is the sum of its circumradius and its inradius?",
  "MCQ",
  r"The hypotenuse is $\sqrt{16^2 + 30^2} = 34$ cm. In a right triangle the hypotenuse is a diameter of the circumcircle, so $R = 17$ cm. The inradius is $r = \frac{\text{Area}}{s} = \frac{240}{40} = 6$ cm (equivalently $\frac{16 + 30 - 34}{2}$). The sum is $23$ cm.",
  "Taking the hypotenuse itself as the circumradius, or dividing the area by the full perimeter.",
  "C15C-right-r-R", "Two separate radius facts for a right triangle combined.",
  correct=r"$23$ cm",
  distractors=[(r"$40$ cm", r"Takes the circumradius as the whole hypotenuse $34$, plus $r = 6$."),
               (r"$29$ cm", r"Uses $r = 16 + 30 - 34 = 12$ without halving, plus $R = 17$."),
               (r"$20$ cm", r"Uses $r = \frac{\text{Area}}{\text{perimeter}} = \frac{240}{80} = 3$, plus $R = 17$.")],
  check=_c013, values=[23, 40, 29, 20], cognitive="Application")

# ---------------------------------------------------------------- 014
def _c014():
    n = 0
    for b in range(1, 1000):
        c2 = 20 * 20 + b * b
        c = math.isqrt(c2)
        if c * c == c2:
            n += 1
    return n
q("C15-C-014", TOPIC, "Count integer right triangles with a given leg", "Medium",
  "Casework/optimisation",
  r"How many right-angled triangles with all three sides of integer length (in cm) have one of the two shorter sides equal to $20$ cm? (Triangles with the same three side lengths are counted once.)",
  "TITA",
  r"Let the other leg be $b$ and the hypotenuse $c$. Then $c^2 - b^2 = 400$, so $(c - b)(c + b) = 400$ with both factors of the same parity, hence both even. Writing $c - b = 2u$, $c + b = 2v$ with $uv = 100$, $u < v$: $(u, v) = (1, 100), (2, 50), (4, 25), (5, 20)$, giving $b = 99, 48, 21, 15$. So there are $4$ triangles: $(20, 99, 101)$, $(20, 48, 52)$, $(20, 21, 29)$, $(15, 20, 25)$.",
  "Counting factor pairs of 400 without the same-parity condition.",
  "C15C-triple-count", "Factor-pair casework with a parity condition.",
  tita_answer=4, check=_c014, values=[4],
  tita_traps=[(7, "Counts all factor pairs $d < e$ of $400$, ignoring that both factors must be even."),
              (5, r"Also counts the pair $(10, 10)$, which gives a zero leg, or adds $(12, 16, 20)$ where $20$ is the hypotenuse.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 015
def _c015():
    P, Q, R = _tri(13, 21, 20)
    T = Triangle(P, Q, R)
    return min(Segment(*s.points).length for s in T.altitudes.values())
q("C15-C-015", TOPIC, "Shortest altitude via Heron's formula", "Medium",
  "Multi-step word problem",
  r"A triangle has sides $13$ cm, $20$ cm and $21$ cm. What is the length of its shortest altitude, in cm?",
  "TITA",
  r"Here $s = 27$ and the area is $\sqrt{27 \times 14 \times 7 \times 6} = \sqrt{15876} = 126$ cm$^2$. The shortest altitude is the one drawn to the longest side: $h = \frac{2 \times 126}{21} = 12$ cm.",
  "Dropping the factor 2 when converting area to altitude, or using the shortest side as base.",
  "C15C-heron-area", "Heron's formula plus the insight that the shortest altitude meets the longest side.",
  tita_answer=12, check=_c015, values=[12],
  tita_traps=[(6, r"Uses $h = \frac{\text{Area}}{\text{base}}$ without the factor $2$."),
              (126, "Reports the area instead of the altitude.")],
  cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    a, x, y = symbols('a x y', real=True)
    # M at origin, Q=(-a/2,0), R=(a/2,0), P=(x,y): PM=8, PQ=10, PR=14
    sols = solve([x**2 + y**2 - 64, (x + a / 2)**2 + y**2 - 100, (x - a / 2)**2 + y**2 - 196], [a, x, y], dict=True)
    vals = {simplify(s[a]) for s in sols if s[a].is_positive}
    assert len(vals) == 1
    return vals.pop()
q("C15-C-016", TOPIC, "Find a side from two sides and the median to it", "Medium",
  "Inverse/parameter",
  r"In triangle $PQR$, $PQ = 10$ cm, $PR = 14$ cm, and the median from $P$ to $QR$ has length $8$ cm. What is the length of $QR$?",
  "MCQ",
  r"Let $M$ be the midpoint of $QR$ and $QR = 2x$. Apollonius' theorem gives $PQ^2 + PR^2 = 2PM^2 + 2x^2$, so $100 + 196 = 128 + 2x^2$, hence $x^2 = 84$ and $x = 2\sqrt{21}$. So $QR = 4\sqrt{21}$ cm.",
  "Misremembering the coefficients in Apollonius' theorem.",
  "C15C-apollonius-median", "Apollonius used in reverse with a surd answer.",
  correct=r"$4\sqrt{21}$ cm",
  distractors=[(r"$2\sqrt{42}$ cm", r"Uses $PM^2 = \frac{PQ^2 + PR^2 - QR^2}{2}$, giving $QR^2 = 296 - 128 = 168$."),
               (r"$4\sqrt{33}$ cm", r"Forgets to divide by $4$: $PM^2 = 2PQ^2 + 2PR^2 - QR^2$, giving $QR^2 = 592 - 64 = 528$."),
               (r"$2\sqrt{10}$ cm", r"Forgets the factor $2$ on the sides: $4PM^2 = PQ^2 + PR^2 - QR^2$, giving $QR^2 = 296 - 256 = 40$.")],
  check=_c016, values=[4 * sqrt(21), 2 * sqrt(42), 4 * sqrt(33), 2 * sqrt(10)], cognitive="Application")

# ---------------------------------------------------------------- 017
def _c017():
    P, Q, R = Point(2, 9), Point(0, 0), Point(11, 0)
    T = Triangle(P, Q, R)
    G = T.centroid; M = Point(Rational(11, 2), 0)
    frac = abs(Triangle(G, Q, M).area) / abs(T.area)
    return frac * 72
_Pc, _Qc, _Rc = (2.5, 6.0), (0.0, 0.0), (9.0, 0.0)
_Mc = (4.5, 0.0); _Gc = (11.5 / 3, 2.0)
_f = Fig()
_f.shade([_Gc, _Qc, _Mc])
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
_M = _f.pt("M", *_Mc, offset=(0, -1)); _G = _f.pt("G", *_Gc, offset=(1, 0.4))
_f.poly(_P, _Q, _R); _f.seg(_P, _M); _f.seg(_G, _Q)
_alt = "Triangle PQR with median PM to the midpoint M of QR, and centroid G on PM. Triangle GQM is shaded."
q("C15-C-017", TOPIC, "Area of a triangle cut off by the centroid and a midpoint", "Medium",
  "Conceptual/application",
  r"Triangle $PQR$ has area $72$ cm$^2$. $M$ is the midpoint of $QR$ and $G$ is the centroid of the triangle. What is the area of triangle $GQM$?",
  "MCQ",
  r"The median $PM$ splits the triangle into two halves, so triangle $PQM$ has area $36$. Triangles $GQM$ and $PQM$ share the base $QM$, and $GM = \frac{1}{3}PM$, so the height of $GQM$ is one third of that of $PQM$. Hence its area is $\frac{36}{3} = 12$ cm$^2$ (the three medians cut the triangle into six equal parts).",
  "Using the wrong fraction of the whole: one third, one quarter or one ninth.",
  "C15C-centroid-area-split", "Two area ratios chained, or the six-equal-parts fact.",
  correct=r"$12$ cm$^2$",
  distractors=[(r"$24$ cm$^2$", r"Takes triangle $GQR$ (one third of the area) instead of $GQM$."),
               (r"$18$ cm$^2$", r"Assumes the area is one quarter of the triangle, as for a midpoint triangle."),
               (r"$8$ cm$^2$", r"Squares the ratio $\frac{1}{3}$, as if the triangles were similar: $\frac{72}{9}$.")],
  check=_c017, values=[12, 24, 18, 8],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Understanding")

# ---------------------------------------------------------------- 018
def _c018():
    P, Q, R = _tri(10, 21, 17)
    I = Triangle(P, Q, R).incenter
    par = Line(I, I + (R - Q))                      # through I, parallel to QR
    X = par.intersection(Line(P, Q))[0]; Y = par.intersection(Line(P, R))[0]
    assert Segment(P, Q).contains(X) and Segment(P, R).contains(Y)
    return simplify(P.distance(X) + X.distance(Y) + Y.distance(P))
_Pc, _Qc, _Rc = _ftri(10, 21, 17)
_Ic = _incentre_f(_Pc, _Qc, _Rc)
_tx = (_Pc[1] - _Ic[1]) / _Pc[1]                    # fraction of the way from P down to QR
_Xc = (_Pc[0] + (1 - _tx) * (_Qc[0] - _Pc[0]), _Ic[1]); _Yc = (_Pc[0] + (1 - _tx) * (_Rc[0] - _Pc[0]), _Ic[1])
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
_X = _f.pt("X", *_Xc, offset=(0.7, -0.9)); _Y = _f.pt("Y", *_Yc, offset=(-0.7, -0.9)); _I = _f.pt("I", *_Ic, offset=(0, -1))
_f.poly(_P, _Q, _R); _f.seg(_X, _Y)
_f.label_seg(_P, _Q, "10"); _f.label_seg(_P, _R, "17"); _f.label_seg(_Q, _R, "21")
_alt = "Triangle PQR with PQ = 10, PR = 17 and QR = 21. A segment XY through the incentre I is parallel to QR, with X on PQ and Y on PR."
q("C15-C-018", TOPIC, "Perimeter cut off by the line through the incentre parallel to a side", "Medium",
  "Conceptual/application",
  r"In triangle $PQR$, $PQ = 10$ cm, $PR = 17$ cm and $QR = 21$ cm. $I$ is the incentre of the triangle. The line through $I$ parallel to $QR$ meets $PQ$ at $X$ and $PR$ at $Y$. What is the perimeter of triangle $PXY$?",
  "MCQ",
  r"$QI$ bisects $\angle Q$, and $XY \parallel QR$ gives $\angle XIQ = \angle IQR = \angle XQI$, so triangle $XQI$ is isosceles with $XI = XQ$. Similarly $YI = YR$. Hence the perimeter of $PXY$ is $PX + XI + IY + YP = (PX + XQ) + (PY + YR) = PQ + PR = 27$ cm.",
  "Treating XY as a midline, or as the line through the centroid, instead of using the two isosceles triangles at the incentre.",
  "C15C-incentre-parallel-line", "Needs the insight that the bisectors create two isosceles triangles; no lengths need to be computed.",
  correct=r"$27$ cm",
  distractors=[(r"$32$ cm", r"Treats $I$ as if it were the centroid, so $PXY$ is $\frac{2}{3}$ of $PQR$: $\frac{2}{3} \times 48$."),
               (r"$24$ cm", r"Treats $XY$ as the midline, so $PXY$ is half of $PQR$: $\frac{48}{2}$."),
               (r"$21$ cm", r"Uses the ratio $\frac{r}{h}$ instead of $\frac{h - r}{h}$ for the small triangle: $r = 3.5$, $h = 8$ to $QR$, giving $\frac{3.5}{8} \times 48$.")],
  check=_c018, values=[27, 32, 24, 21],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis")

# ---------------------------------------------------------------- 019
def _c019():
    P, Q, R = _tri(25, 56, 39)
    return 2 * Triangle(P, Q, R).circumradius
q("C15-C-019", TOPIC, "Circumcircle diameter from three sides", "Medium",
  "Multi-step word problem",
  r"Three villages are located at the corners of a triangle whose sides are $25$ km, $39$ km and $56$ km. A circular ring road is to pass through all three villages. What is the diameter of the ring road?",
  "MCQ",
  r"The circle through the three corners is the circumcircle. Here $s = 60$ and the area is $\sqrt{60 \times 35 \times 21 \times 4} = \sqrt{176400} = 420$ km$^2$. Then $R = \frac{abc}{4\Delta} = \frac{25 \times 39 \times 56}{1680} = \frac{65}{2}$, so the diameter is $65$ km.",
  "Using abc over 2 times area, or assuming the longest side is a diameter.",
  "C15C-circumradius-abc", "Heron's formula feeding $R = \\frac{abc}{4\\Delta}$.",
  correct=r"$65$ km",
  distractors=[(r"$130$ km", r"Uses $R = \frac{abc}{2\Delta} = 65$ and then doubles it."),
               (r"$56$ km", r"Assumes the longest side is a diameter, as in a right triangle."),
               (r"$14$ km", r"Finds the inradius $\frac{420}{60} = 7$ and doubles it.")],
  check=_c019, values=[65, 130, 56, 14], cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    n = 0
    for x in range(1, 50):
        s = sorted([8, 15, x])
        if s[0] + s[1] <= s[2]:
            continue
        if s[0]**2 + s[1]**2 < s[2]**2:
            n += 1
    return n
q("C15-C-020", TOPIC, "Count integer third sides making the triangle obtuse", "Medium",
  "Casework/optimisation",
  r"A triangle has sides $8$ cm, $15$ cm and $x$ cm, where $x$ is an integer. For how many values of $x$ is the triangle obtuse-angled?",
  "TITA",
  r"For a triangle, $7 < x < 23$, so $x = 8, 9, \ldots, 22$. If $15$ is the longest side, the triangle is obtuse when $8^2 + x^2 < 15^2$, i.e. $x^2 < 161$, so $x = 8, \ldots, 12$ ($5$ values). If $x$ is the longest side, it is obtuse when $x^2 > 8^2 + 15^2 = 289$, i.e. $x > 17$, so $x = 18, \ldots, 22$ ($5$ values). $x = 17$ gives a right triangle. Total $10$.",
  "Considering only the case where x is the longest side, or including the right-angled case.",
  "C15C-acute-obtuse-count", "Two cases for the longest side plus the triangle inequality.",
  tita_answer=10, check=_c020, values=[10],
  tita_traps=[(5, "Considers only one case for the longest side."),
              (11, r"Includes $x = 17$, where the triangle is right-angled.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 021
def _c021():
    h = 6
    QH = h / tan(pi / 4); HR = h / tan(pi / 6)
    return nsimplify(simplify(QH + HR))
_Qc = (0.0, 0.0); _Hc = (6.0, 0.0); _Pc = (6.0, 6.0); _Rc = (6.0 + 6 * _m.sqrt(3), 0.0)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _H = _f.pt("H", *_Hc, offset=(0, -1))
_f.poly(_P, _Q, _R); _f.seg(_P, _H, dashed=True); _f.right_angle(_R, _H, _P)
_f.angle_mark(_R, _Q, _P, "45^\\circ"); _f.angle_mark(_P, _R, _Q, "30^\\circ"); _f.label_seg(_P, _H, "6", side=-1)
_alt = "Triangle PQR with angle Q = 45 degrees and angle R = 30 degrees; PH is the perpendicular from P to QR, of length 6."
q("C15-C-021", TOPIC, "Base split by an altitude into 45-45-90 and 30-60-90 parts", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, $\angle Q = 45^\circ$ and $\angle R = 30^\circ$. The perpendicular from $P$ to $QR$ meets it at $H$, and $PH = 6$ cm. What is the length of $QR$?",
  "MCQ",
  r"Both base angles are acute, so $H$ lies between $Q$ and $R$. Triangle $PHQ$ is $45$-$45$-$90$, so $QH = PH = 6$. Triangle $PHR$ is $30$-$60$-$90$ with $PH$ opposite $30^\circ$, so $HR = 6\sqrt{3}$. Hence $QR = 6 + 6\sqrt{3}$ cm.",
  "Using the hypotenuses PQ and PR, or the wrong ratio in the 30-60-90 part.",
  "C15C-special-triangles-combined", "Two special triangles sharing an altitude.",
  correct=r"$6 + 6\sqrt{3}$ cm",
  distractors=[(r"$6 + 2\sqrt{3}$ cm", r"Takes $HR = \frac{6}{\sqrt{3}}$, putting $PH$ opposite the $60^\circ$ angle."),
               (r"$6\sqrt{2} + 6\sqrt{3}$ cm", r"Takes $QH$ as $6\sqrt{2}$, the hypotenuse $PQ$ of the $45$-$45$-$90$ part."),
               (r"$6\sqrt{2} + 12$ cm", r"Adds the hypotenuses $PQ = 6\sqrt{2}$ and $PR = 12$ instead of the projections.")],
  check=_c021, values=[6 + 6 * sqrt(3), 6 + 2 * sqrt(3), 6 * sqrt(2) + 6 * sqrt(3), 6 * sqrt(2) + 12],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Application")

# ---------------------------------------------------------------- 022
def _c022():
    hits = set()
    for p in range(1, 89):         # acute triangle needed for the centre-angle relation below
        qa = Fraction(180 - p, 2)
        QR = 10.0
        PQ = QR * _m.sin(_m.radians(float(qa))) / _m.sin(_m.radians(p))
        Q = (0.0, 0.0); R = (QR, 0.0)
        P = (PQ * _m.cos(_m.radians(float(qa))), PQ * _m.sin(_m.radians(float(qa))))
        I = _incentre_f(P, Q, R)
        if abs(_angle_deg(Q, I, R) - 115) < 1e-7:
            O = _circumcentre_f(P, Q, R)
            hits.add(round(_angle_deg(Q, O, R), 9))
    assert len(hits) == 1
    return hits.pop()
q("C15-C-022", TOPIC, "Link the incentre angle and the circumcentre angle on the same side", "Medium",
  "Conceptual/application",
  r"In an acute-angled triangle $PQR$, $I$ is the incentre and $O$ is the circumcentre. If $\angle QIR = 115^\circ$, what is the measure of $\angle QOR$?",
  "MCQ",
  r"For the incentre, $\angle QIR = 90^\circ + \frac{\angle P}{2}$, so $\frac{\angle P}{2} = 25^\circ$ and $\angle P = 50^\circ$. For the circumcentre of an acute triangle, $\angle QOR = 2\angle P = 100^\circ$.",
  "Assuming the two centres subtend the same angle at QR, or mixing the two formulas.",
  "C15C-centre-angles", "Two centre-angle results chained through the vertex angle.",
  correct=r"$100^\circ$",
  distractors=[(r"$115^\circ$", r"Assumes $\angle QOR = \angle QIR$."),
               (r"$130^\circ$", r"Finds $\angle P = 50^\circ$ and then takes $\angle QOR = 180^\circ - \angle P$."),
               (r"$50^\circ$", r"Stops at $\angle P = 50^\circ$ and reports it as $\angle QOR$.")],
  check=_c022, values=[100, 115, 130, 50], cognitive="Analysis")

# ---------------------------------------------------------------- 023
def _c023():
    # Arjun: north 8 km/h from minute 0; Fatima: east 7 km/h from minute 120. First minute at 25 km apart.
    for t in range(0, 24 * 60 + 1):
        n = Fraction(8 * t, 60)
        e = Fraction(7 * max(0, t - 120), 60)
        if n * n + e * e == 625:
            return t
        if n * n + e * e > 625:
            break
    # fall back: exact root
    x = symbols('x', positive=True)
    return [s for s in solve(Eq((8 * x)**2 + (7 * (x - 2))**2, 625), x) if s > 2][0] * 60
q("C15-C-023", TOPIC, "Perpendicular journeys with a staggered start", "Medium",
  "Multi-step word problem",
  r"Arjun starts cycling due north from a crossroads at $7{:}00$ am at a constant $8$ km/h. Fatima starts from the same crossroads at $9{:}00$ am and cycles due east at a constant $7$ km/h. Both ride along straight roads. How many minutes after Arjun starts are the two cyclists exactly $25$ km apart in a straight line?",
  "TITA",
  r"By $9{:}00$ am Arjun is $16$ km north, less than $25$ km, and after that the distance keeps increasing, so there is exactly one such moment. At $t$ hours after $7{:}00$ am the legs are $8t$ and $7(t - 2)$. Try the triple $7 : 24 : 25$: at $t = 3$ the legs are $24$ and $7$, and $\sqrt{24^2 + 7^2} = 25$. So the time is $3$ hours $= 180$ minutes after Arjun starts (equivalently, $64t^2 + 49(t-2)^2 = 625$ factorises as $(t - 3)(113t + 143) = 0$).",
  "Measuring the time from Fatima's start, or ignoring the two-hour head start.",
  "C15C-pythagoras-word", "Head start makes the legs unequal in time; a triple guess or a quadratic.",
  tita_answer=180, check=_c023, values=[180],
  tita_traps=[(60, "Reports the time after Fatima starts."),
              (141, r"Ignores the two-hour gap and treats both as starting at $7{:}00$ am: $\sqrt{113}\,t = 25$ gives about $141$ minutes.")],
  cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    s, x = symbols('s x', positive=True)
    h = s * sqrt(3) / 2
    Q, R, P = Point(0, 0), Point(s, 0), Point(s / 2, h)
    X = Point(x, 3)
    sol = solve([Eq(Line(Q, P).distance(X), 4), Eq(Line(R, P).distance(X), 5)], [s, x], dict=True)
    good = [d for d in sol if d[x] > 0 and d[x] < d[s]]
    sv = good[0][s]
    return simplify(sqrt(3) / 4 * sv**2)
_s = 8 * _m.sqrt(3)
_Qc, _Rc, _Pc = (0.0, 0.0), (_s, 0.0), (_s / 2, 12.0)
# point at height 3 whose distance to PQ is 4: line PQ is y = sqrt(3) x, distance = (sqrt(3)x - y)/2
_Xc = ((8.0 + 3.0) / _m.sqrt(3), 3.0)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _X = _f.pt("X", *_Xc, offset=(-0.3, 1))
_f.poly(_P, _Q, _R)
_F1 = _foot_f(_Xc, _Qc, _Rc); _F2 = _foot_f(_Xc, _Qc, _Pc); _F3 = _foot_f(_Xc, _Rc, _Pc)
_f.seg(_X, _F1, dashed=True); _f.seg(_X, _F2, dashed=True); _f.seg(_X, _F3, dashed=True)
_f.label_seg(_Xc, _F1, "3", side=-1); _f.label_seg(_Xc, _F2, "4", side=-1); _f.label_seg(_Xc, _F3, "5", side=-1)
_alt = "Equilateral triangle PQR with a point X inside. Dashed perpendiculars from X to the three sides have lengths 3, 4 and 5."
q("C15-C-024", TOPIC, "Equilateral triangle from the distances of an interior point to its sides", "Medium",
  "Conceptual/application",
  r"A point $X$ inside an equilateral triangle $PQR$ is at perpendicular distances $3$ cm, $4$ cm and $5$ cm from the three sides. What is the area of triangle $PQR$?",
  "MCQ",
  r"Join $X$ to the vertices. The three small triangles have the side $a$ as base, so $\frac{1}{2}a(3 + 4 + 5) = \frac{\sqrt{3}}{2}a \cdot \frac{a}{2}$, which shows that the height equals $3 + 4 + 5 = 12$ cm. Then $a = \frac{2 \times 12}{\sqrt{3}} = 8\sqrt{3}$ cm and the area is $\frac{1}{2} \times 8\sqrt{3} \times 12 = 48\sqrt{3}$ cm$^2$.",
  "Treating the sum of distances as a side, or as the inradius or circumradius.",
  "C15C-equilateral-interior-distances", "Needs the constant-sum-of-distances insight.",
  correct=r"$48\sqrt{3}$ cm$^2$",
  distractors=[(r"$36\sqrt{3}$ cm$^2$", r"Takes the side as $12$: $\frac{\sqrt{3}}{4} \times 144$."),
               (r"$96\sqrt{3}$ cm$^2$", r"Gets the side $8\sqrt{3}$ and height $12$ but forgets the $\frac{1}{2}$."),
               (r"$108\sqrt{3}$ cm$^2$", r"Takes $12$ as the circumradius, so height $18$, side $12\sqrt{3}$.")],
  check=_c024, values=[48 * sqrt(3), 36 * sqrt(3), 96 * sqrt(3), 108 * sqrt(3)],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis")

# ---------------------------------------------------------------- 025
def _c025():
    tri = set()
    for a in range(1, 65):
        for b in range(a, 65):
            if a * a + b * b == 65 * 65:
                tri.add((a, b))
    return len(tri)
q("C15-C-025", TOPIC, "Count integer right triangles with a given hypotenuse", "Difficult",
  "Casework/optimisation",
  r"How many different right-angled triangles have all sides of integer length (in cm) and a hypotenuse of exactly $65$ cm? (Triangles with the same three side lengths are counted once.)",
  "TITA",
  r"We need $a^2 + b^2 = 4225$ with $a < b$. Since $65 = 5 \times 13$, the triples come from $(3, 4, 5) \times 13 = (39, 52, 65)$, $(5, 12, 13) \times 5 = (25, 60, 65)$ and the primitive triples with hypotenuse $65$: $(16, 63, 65)$ and $(33, 56, 65)$. A quick check of the remaining squares confirms no others, so there are $4$.",
  "Listing only the scaled triples, or only the primitive ones.",
  "C15C-triple-count", "Requires both scaled and primitive triples with the same hypotenuse; the primitive pairs $(16, 63)$ and $(33, 56)$ are not standard triples and must be found by a systematic search or the sum-of-two-squares structure of $65$.",
  tita_answer=4, check=_c025, values=[4],
  tita_traps=[(2, "Lists only the scaled triples $(39, 52, 65)$ and $(25, 60, 65)$, or only the two primitive ones."),
              (3, "Misses one of the primitive triples.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 026
def _c026():
    P, Q, R = _tri(20, 24, 20)
    T = Triangle(P, Q, R)
    return T.circumradius / T.inradius
q("C15-C-026", TOPIC, "Ratio of circumradius to inradius of an isosceles triangle", "Medium",
  "Multi-step word problem",
  r"An isosceles triangle has a perimeter of $64$ cm and a base of $24$ cm. What is the ratio of its circumradius to its inradius?",
  "MCQ",
  r"The equal sides are $\frac{64 - 24}{2} = 20$ cm, so the height is $\sqrt{20^2 - 12^2} = 16$ cm and the area is $192$ cm$^2$. Then $r = \frac{192}{32} = 6$ and $R = \frac{20 \times 20 \times 24}{4 \times 192} = \frac{25}{2}$. The ratio $R : r = \frac{25}{2} : 6 = 25 : 12$.",
  "Using the perimeter instead of the semi-perimeter, or assuming the equilateral ratio 2 : 1.",
  "C15C-circumradius-abc", "Three quantities (height, area, then both radii) before a ratio.",
  correct=r"$25 : 12$",
  distractors=[(r"$2 : 1$", "Uses the equilateral-triangle ratio $R : r = 2 : 1$."),
               (r"$5 : 3$", r"Takes $R$ as half of an equal side, $10$, against $r = 6$."),
               (r"$25 : 6$", r"Uses $r = \frac{\text{Area}}{\text{perimeter}} = 3$ with $R = \frac{25}{2}$.")],
  check=_c026, values=[Rational(25, 12), 2, Rational(5, 3), Rational(25, 6)], cognitive="Application")

# ---------------------------------------------------------------- 027
def _c027():
    P, Q, R = _tri(4, 8, 6)
    T = Triangle(P, Q, R)
    return simplify(sum(Segment(*m.points).length**2 for m in T.medians.values()))
q("C15-C-027", TOPIC, "Sum of the squares of the three medians", "Medium",
  "Conceptual/application",
  r"A triangle has sides $4$ cm, $6$ cm and $8$ cm. What is the sum of the squares of the lengths of its three medians?",
  "MCQ",
  r"Apollonius' theorem gives $m_a^2 = \frac{2b^2 + 2c^2 - a^2}{4}$ for each median. Adding all three, the sum is $\frac{3(a^2 + b^2 + c^2)}{4} = \frac{3(16 + 36 + 64)}{4} = \frac{3 \times 116}{4} = 87$.",
  "Using the sum of the squares of the sides or the wrong multiplier.",
  "C15C-apollonius-median", "Summing Apollonius over all three medians gives a clean multiplier.",
  correct=r"$87$ cm$^2$",
  distractors=[(r"$116$ cm$^2$", r"Uses $m_a^2 = \frac{b^2 + c^2}{2}$, dropping the $-\frac{a^2}{4}$ term; the three terms then add to $a^2 + b^2 + c^2$."),
               (r"$58$ cm$^2$", r"Uses $m_a^2 = \frac{b^2 + c^2}{2} - \frac{a^2}{2}$ (subtracts half the square of the third side instead of a quarter): $116 - 58$."),
               (r"$29$ cm$^2$", r"Adds the three Apollonius terms but forgets the factor $3$: $\frac{a^2 + b^2 + c^2}{4} = \frac{116}{4}$.")],
  check=_c027, values=[87, 116, 58, 29], cognitive="Application")

# ---------------------------------------------------------------- 028
def _c028():
    S, Q, R = Point(0, 0), Point(18, 0), Point(0, 24)
    T = Triangle(S, Q, R)
    return T.centroid.distance(T.circumcenter)
q("C15-C-028", TOPIC, "Distance between centroid and circumcentre of a right triangle", "Medium",
  "Conceptual/application",
  r"A right-angled triangle has legs $18$ cm and $24$ cm. What is the distance between its centroid and its circumcentre, in cm?",
  "TITA",
  r"The hypotenuse is $30$ cm and the circumcentre is its midpoint. The median from the right-angle vertex therefore ends at the circumcentre and has length $15$ cm. The centroid lies on this median, two thirds of the way from the vertex, so its distance from the circumcentre is $\frac{1}{3} \times 15 = 5$ cm.",
  "Taking two thirds of the median instead of one third, or the full median.",
  "C15C-right-median-centroid", "Must see that both centres lie on the same median.",
  tita_answer=5, check=_c028, values=[5],
  tita_traps=[(10, "Takes two thirds of the median, the distance from the vertex to the centroid."),
              (15, "Reports the length of the median.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 029
def _c029():
    a, b = symbols('a b', positive=True)
    c = 26
    sols = solve([Eq(a**2 + b**2, c**2), Eq(a * b / 2, 4 * (a + b + c) / 2)], [a, b], dict=True)
    areas = {simplify(d[a] * d[b] / 2) for d in sols}
    assert len(areas) == 1
    return areas.pop()
q("C15-C-029", TOPIC, "Area of a right triangle from its inradius and hypotenuse", "Medium",
  "Inverse/parameter",
  r"A right-angled triangle has hypotenuse $26$ cm, and the radius of its incircle is $4$ cm. What is the area of the triangle?",
  "MCQ",
  r"For a right triangle $r = \frac{a + b - c}{2}$, so $a + b = 2 \times 4 + 26 = 34$ and the semi-perimeter is $s = \frac{34 + 26}{2} = 30$. The area is $r \times s = 4 \times 30 = 120$ cm$^2$. (The legs are $10$ and $24$.)",
  "Multiplying the inradius by the full perimeter or by the wrong length.",
  "C15C-right-r-R", "Two radius-area links needed in reverse.",
  correct=r"$120$ cm$^2$",
  distractors=[(r"$240$ cm$^2$", r"Uses $\text{Area} = r \times \text{perimeter} = 4 \times 60$."),
               (r"$52$ cm$^2$", r"Uses $\text{Area} = \frac{1}{2} r c = \frac{1}{2} \times 4 \times 26$."),
               (r"$136$ cm$^2$", r"Uses $\text{Area} = r(a + b) = 4 \times 34$.")],
  check=_c029, values=[120, 240, 52, 136], cognitive="Application")

# ---------------------------------------------------------------- 030
def _c030():
    P, Q, R = _tri(9, 14, 12)
    I = Triangle(P, Q, R).incenter
    D = Line(P, I).intersection(Line(Q, R))[0]
    return simplify(P.distance(I) / I.distance(D))
_Pc, _Qc, _Rc = _ftri(9, 14, 12)
_Ic = _incentre_f(_Pc, _Qc, _Rc)
_Dc = (14 * 9 / 21.0, 0.0)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
# I drawn at a generic point of PT (the midpoint) so that the asked ratio PI : IT cannot be read off
_I = _f.pt("I", (_Pc[0] + _Dc[0]) / 2, (_Pc[1] + _Dc[1]) / 2, offset=(1, 0.3)); _D = _f.pt("T", *_Dc, offset=(0, -1))
_f.poly(_P, _Q, _R); _f.seg(_P, _D)
_f.label_seg(_P, _Q, "9"); _f.label_seg(_P, _R, "12"); _f.text((10.0, -1.3), "QR = 14")
_alt = "Triangle PQR with PQ = 9, PR = 12 and QR = 14. The bisector of angle P meets QR at T and passes through the incentre I. Figure not to scale."
q("C15-C-030", TOPIC, "Ratio in which the incentre divides an angle bisector", "Medium",
  "Conceptual/application",
  r"In triangle $PQR$, $PQ = 9$ cm, $PR = 12$ cm and $QR = 14$ cm. The bisector of $\angle P$ meets $QR$ at $T$, and $I$ is the incentre of the triangle. What is the ratio $PI : IT$?",
  "MCQ",
  r"By the angle bisector theorem $QT : TR = 9 : 12$, so $QT = 14 \times \frac{9}{21} = 6$ cm. In triangle $PQT$, $QI$ bisects $\angle Q$, so $PI : IT = PQ : QT = 9 : 6 = 3 : 2$. (In general $PI : IT = (PQ + PR) : QR = 21 : 14$.)",
  "Assuming the incentre divides the bisector like the centroid divides a median, or inverting the ratio.",
  "C15C-incentre-bisector-ratio", "Angle bisector theorem applied twice.",
  correct=r"$3 : 2$",
  distractors=[(r"$2 : 3$", r"Inverts the ratio, using $QR : (PQ + PR)$."),
               (r"$2 : 1$", "Assumes the incentre divides the bisector in the centroid ratio."),
               (r"$3 : 4$", r"Uses $PQ : PR$, the ratio in which $T$ divides $QR$.")],
  check=_c030, values=[Rational(3, 2), Rational(2, 3), 2, Rational(3, 4)],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Application", exams=HARD)

# ---------------------------------------------------------------- 031
def _c031():
    found = set()
    for a in range(1, 400):
        for b in range(a, 400):
            c2 = a * a + b * b
            c = math.isqrt(c2)
            if c * c == c2 and Fraction(a * b, a + b + c) == 6:
                found.add((a, b, c))
    return len(found)
q("C15-C-031", TOPIC, "Count integer right triangles with a given inradius", "Difficult",
  "Casework/optimisation",
  r"How many right-angled triangles with all three sides of integer length (in cm) have an incircle of radius exactly $6$ cm? (Triangles with the same three side lengths are counted once.)",
  "TITA",
  r"With legs $a, b$ and hypotenuse $c$, $r = \frac{a + b - c}{2} = 6$ gives $c = a + b - 12$. Substituting in $a^2 + b^2 = c^2$: $0 = -24a - 24b + 2ab + 144$, i.e. $(a - 12)(b - 12) = 72$. Unordered factor pairs of $72$ are $(1, 72), (2, 36), (3, 24), (4, 18), (6, 12), (8, 9)$, so there are $6$ triangles, for example $(13, 84, 85)$ and $(20, 21, 29)$.",
  "Counting ordered factor pairs, or only primitive triples.",
  "C15C-right-inradius-count", "Needs the factorisation $(a - 2r)(b - 2r) = 2r^2$ and careful counting.",
  tita_answer=6, check=_c031, values=[6],
  tita_traps=[(12, "Counts ordered factor pairs, so each triangle twice."),
              (5, r"Lists factor pairs only with the smaller factor at most $6$, missing $(8, 9)$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 032
def _c032():
    T = Triangle(Point(0, 0), Point(12, 0), Point(0, 16))
    return simplify(T.circumcenter.distance(T.incenter))
q("C15-C-032", TOPIC, "Distance between incentre and circumcentre of a right triangle", "Medium",
  "Multi-step word problem",
  r"A triangle has sides $12$ cm, $16$ cm and $20$ cm. What is the distance between its incentre and its circumcentre?",
  "MCQ",
  r"Since $12^2 + 16^2 = 20^2$, the triangle is right-angled. Put the right angle at the origin with legs along the axes: $(12, 0)$ and $(0, 16)$. The circumcentre is the midpoint of the hypotenuse, $(6, 8)$. The inradius is $\frac{12 + 16 - 20}{2} = 4$, so the incentre is $(4, 4)$. The distance is $\sqrt{2^2 + 4^2} = 2\sqrt{5}$ cm. (This agrees with $OI^2 = R^2 - 2Rr = 100 - 80$.)",
  "Misremembering Euler's relation between OI, R and r.",
  "C15C-incentre-circumcentre-distance", "Spot the right angle, then locate both centres by coordinates; two or three short steps, but a misremembered formula gives a plausible surd.",
  correct=r"$2\sqrt{5}$ cm",
  distractors=[(r"$6\sqrt{5}$ cm", r"Uses $OI^2 = R^2 + 2Rr = 180$."),
               (r"$2\sqrt{21}$ cm", r"Uses $OI^2 = R^2 - r^2 = 84$."),
               (r"$2\sqrt{15}$ cm", r"Uses $OI^2 = R^2 - Rr = 60$.")],
  check=_c032, values=[2 * sqrt(5), 6 * sqrt(5), 2 * sqrt(21), 2 * sqrt(15)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 033
def _c033():
    qv, rv = symbols('qv rv', positive=True)
    # G at origin, median from Q along the x-axis, median from R along the y-axis (perpendicular)
    Q, R = Point(qv, 0), Point(0, rv)
    P = Point(-qv, -rv)          # forced: midpoint of PR lies on GQ extended, midpoint of PQ on GR extended
    sol = solve([Eq(P.distance(Q)**2, 22**2), Eq(P.distance(R)**2, 19**2)], [qv, rv], dict=True)[0]
    return simplify(Q.distance(R).subs(sol))
_qv, _rv = _m.sqrt(105), 8.0
_Qc, _Rc, _Pc = (_qv, 0.0), (0.0, _rv), (-_qv, -_rv)
_Nc = ((_Pc[0] + _Rc[0]) / 2, (_Pc[1] + _Rc[1]) / 2); _Mc = ((_Pc[0] + _Qc[0]) / 2, (_Pc[1] + _Qc[1]) / 2)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
_N = _f.pt("N", *_Nc, offset=(-1, 0.4)); _M = _f.pt("M", *_Mc, offset=(0.3, -1)); _G = _f.pt("G", 0, 0, offset=(-0.75, -0.75))
_f.poly(_P, _Q, _R); _f.seg(_Q, _N); _f.seg(_R, _M); _f.right_angle(_Q, (0, 0), _R)
_f.text((6.5, -7.0), "PQ = 22,  PR = 19")
_alt = "Triangle PQR with PQ = 22 and PR = 19. Medians QN and RM meet at G at right angles."
q("C15-C-033", TOPIC, "Third side when two medians are perpendicular", "Difficult",
  "Conceptual/application",
  r"In triangle $PQR$, $PQ = 22$ cm and $PR = 19$ cm. The medians drawn from $Q$ and from $R$ are perpendicular to each other. What is the length of $QR$, in cm?",
  "TITA",
  r"Let the medians from $Q$ and $R$ meet at the centroid $G$ at right angles, with $GQ = 2u$, $GR = 2v$ (so the other parts are $u$ and $v$). Pythagoras in the right triangles at $G$ gives $\left(\frac{PQ}{2}\right)^2 = 4u^2 + v^2$, $\left(\frac{PR}{2}\right)^2 = u^2 + 4v^2$ and $QR^2 = 4u^2 + 4v^2$. Adding the first two, $\frac{PQ^2 + PR^2}{4} = 5(u^2 + v^2) = \frac{5}{4}QR^2$, so $PQ^2 + PR^2 = 5QR^2$. Thus $QR^2 = \frac{484 + 361}{5} = 169$ and $QR = 13$ cm.",
  "Stopping at QR squared, or treating the triangle as right-angled at P.",
  "C15C-perpendicular-medians", "Requires setting up the centroid split with a right angle at G.",
  tita_answer=13, check=_c033, values=[13],
  tita_traps=[(169, r"Reports $QR^2$ instead of $QR$."),
              (29, r"Treats the angle at $P$ as right: $\sqrt{22^2 + 19^2} \approx 29.1$, typed as $29$.")],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 034
def _c034():
    areas = []
    for a in range(1, 50):                 # equal sides a, base b
        b = 50 - 2 * a
        if b <= 0 or 2 * a <= b:
            continue
        # Heron with perimeter p = 50: 16 * Area^2 = p (p - 2a)(p - 2a)(p - 2b)
        sq16 = 50 * (50 - 2 * a) * (50 - 2 * a) * (50 - 2 * b)
        root = math.isqrt(sq16)
        if root * root == sq16 and root % 4 == 0:
            areas.append(root // 4)
    return sum(areas)
q("C15-C-034", TOPIC, "Isosceles triangles with integer sides, fixed perimeter and integer area", "Difficult",
  "Casework/optimisation",
  r"An isosceles triangle has all three sides of integer length (in cm), a perimeter of $50$ cm, and an area that is a whole number of cm$^2$. Find the sum of the areas of all such triangles, in cm$^2$.",
  "TITA",
  r"Let the equal sides be $a$ and the base $b = 50 - 2a$, with $b < 2a$, so $13 \le a \le 24$. The height to the base is $\sqrt{a^2 - \frac{b^2}{4}}$ and the area is $\frac{b}{4}\sqrt{4a^2 - b^2}$. If $b$ were odd, $4a^2 - b^2$ would be odd, so the area would be irrational or of the form $\frac{bm}{4}$ with $bm$ odd; hence $b = 2k$ and the area is $k\sqrt{a^2 - k^2}$ with $a = 25 - k$. Then $a^2 - k^2 = 625 - 50k = 25(25 - 2k)$, which must be a perfect square, so $25 - 2k$ is an odd square below $25$: $1$ or $9$. This gives $k = 12$ (sides $13, 13, 24$, area $12 \times 5 = 60$) and $k = 8$ (sides $17, 17, 16$, area $8 \times 15 = 120$). The sum is $180$ cm$^2$.",
  "Stopping after one triangle, or reporting how many triangles there are.",
  "C15C-heronian-isosceles", "Parity argument plus a perfect-square condition over a range of cases; easy to miss one triangle.",
  tita_answer=180, check=_c034, values=[180],
  tita_traps=[(60, r"Finds only the $13, 13, 24$ triangle."),
              (120, r"Finds only the $17, 17, 16$ triangle."),
              (2, "Reports the number of triangles instead of the sum of their areas.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 035
def _c035():
    rr = symbols('rr', positive=True)
    rv = [v for v in solve(Eq((rr + 5)**2 + (rr + 12)**2, 17**2), rr) if v > 0][0]
    S, Q, P = Point(0, 0), Point(rv + 5, 0), Point(0, rv + 12)
    T = Triangle(S, Q, P)
    I = T.incenter
    F = Line(Q, P).projection(I)
    assert simplify(Q.distance(F) - 5) == 0 and simplify(P.distance(F) - 12) == 0
    return abs(T.area)
_Sc, _Qc, _Pc = (0.0, 0.0), (8.0, 0.0), (0.0, 15.0)
_Fc = (8.0 - 5 * 8 / 17.0, 5 * 15 / 17.0)
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _S = _f.pt("S", *_Sc); _F = _f.pt("T", *_Fc, offset=(1, 0.6))
_f.poly(_P, _Q, _S); _f.right_angle(_Q, _S, _P); _f.circle((3.0, 3.0), 3.0)
_f.label_seg(_Q, _F, "5"); _f.label_seg(_F, _P, "12")
_alt = "Right triangle PQS with the right angle at S. Its incircle touches the hypotenuse PQ at T, with QT = 5 and TP = 12."
q("C15-C-035", TOPIC, "Right triangle area from the incircle's split of the hypotenuse", "Difficult",
  "Inverse/parameter",
  r"In a right-angled triangle, the incircle touches the hypotenuse at a point that divides it into segments of $5$ cm and $12$ cm. What is the area of the triangle, in cm$^2$?",
  "TITA",
  r"Let the inradius be $r$. Equal tangents give legs $r + 5$ and $r + 12$, and the hypotenuse is $17$. Pythagoras: $(r + 5)^2 + (r + 12)^2 = 289$, so $r^2 + 17r - 60 = 0$ and $r = 3$. The legs are $8$ and $15$, so the area is $\frac{1}{2} \times 8 \times 15 = 60$ cm$^2$. (In general the area equals the product of the two segments.)",
  "Treating the two segments as the legs.",
  "C15C-incircle-tangent-lengths", "Equal tangents plus Pythagoras leads to a quadratic in r.",
  tita_answer=60, check=_c035, values=[60],
  tita_traps=[(30, r"Treats $5$ and $12$ as the legs: $\frac{1}{2} \times 5 \times 12$."),
              (40, "Reports the perimeter $8 + 15 + 17$.")],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    a, b = symbols('a b', positive=True)
    S, Q, R = Point(0, 0), Point(a, 0), Point(0, b)
    mQ = Q.distance(Point(0, b / 2)); mR = R.distance(Point(a / 2, 0))
    sol = solve([Eq(mQ**2, 25), Eq(mR**2, 40)], [a, b], dict=True)[0]
    return simplify(Q.distance(R).subs(sol))
q("C15-C-036", TOPIC, "Hypotenuse from the two medians drawn from the acute vertices", "Difficult",
  "Inverse/parameter",
  r"In a right-angled triangle, the medians drawn from the two acute-angled vertices have lengths $5$ cm and $2\sqrt{10}$ cm. What is the length of the hypotenuse?",
  "MCQ",
  r"Let the legs be $a$ and $b$. The median from the end of leg $a$ goes to the midpoint of leg $b$, so $a^2 + \frac{b^2}{4} = 25$ and similarly $b^2 + \frac{a^2}{4} = 40$. Adding, $\frac{5}{4}(a^2 + b^2) = 65$, so $c^2 = 52$ and $c = 2\sqrt{13}$ cm. (The legs are $4$ and $6$.)",
  "Adding the squares of the medians directly, or using a wrong multiplier.",
  "C15C-median-length-right", "Two median equations combined by adding, not solved separately.",
  correct=r"$2\sqrt{13}$ cm",
  distractors=[(r"$\sqrt{65}$ cm", r"Takes $c^2$ as the sum of the squares of the medians, $25 + 40$."),
               (r"$4\sqrt{13}$ cm", r"Gets $a^2 + b^2 = 52$ but then doubles $\sqrt{52}$, treating it as the median to the hypotenuse."),
               (r"$\frac{5\sqrt{13}}{2}$ cm", r"Inverts the multiplier: $c^2 = \frac{5}{4} \times 65$.")],
  check=_c036, values=[2 * sqrt(13), sqrt(65), 4 * sqrt(13), 5 * sqrt(13) / 2], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 037
def _c037():
    x, y, z = symbols('x y z', positive=True)      # squares of the sides a, b, c
    ma2, mb2, mc2 = 81, 144, 225
    sol = solve([Eq((2 * y + 2 * z - x) / 4, ma2), Eq((2 * x + 2 * z - y) / 4, mb2), Eq((2 * x + 2 * y - z) / 4, mc2)], [x, y, z], dict=True)[0]
    a, b, c = sqrt(sol[x]), sqrt(sol[y]), sqrt(sol[z])
    P, Q, R = _tri(c, a, b)
    T = Triangle(P, Q, R)
    meds = sorted(simplify(Segment(*m.points).length) for m in T.medians.values())
    assert meds == [9, 12, 15]
    return simplify(abs(T.area))
q("C15-C-037", TOPIC, "Area of a triangle from the lengths of its medians", "Difficult",
  "Conceptual/application",
  r"The three medians of a triangle have lengths $9$ cm, $12$ cm and $15$ cm. What is the area of the triangle?",
  "MCQ",
  r"A triangle whose sides equal the three medians has area $\frac{3}{4}$ of the original. Here the median triangle is $9$-$12$-$15$, which is right-angled with area $\frac{1}{2} \times 9 \times 12 = 54$. So the original area is $\frac{4}{3} \times 54 = 72$ cm$^2$. (Directly: extending a median by its centroid part forms a triangle with sides $\frac{2}{3}$ of the medians, of area $\frac{4}{9} \times 54 = 24$, which is one third of the original.)",
  "Reporting the area of the triangle formed by the medians, or using the centroid factor wrongly.",
  "C15C-centroid-medians-area", "Needs the median-triangle relation or a centroid construction.",
  correct=r"$72$ cm$^2$",
  distractors=[(r"$54$ cm$^2$", "Reports the area of the triangle whose sides are the medians."),
               (r"$108$ cm$^2$", "Doubles the area of the median triangle."),
               (r"$36$ cm$^2$", r"Multiplies the median-triangle area by $\frac{2}{3}$, the centroid ratio.")],
  check=_c037, values=[72, 54, 108, 36], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 038
def _c038():
    x, y = symbols('x y', real=True)
    V = [(0, 0), (6, 0), (0, 12)]
    f = sum((x - a)**2 + (y - b)**2 for a, b in V)
    sol = solve([diff(f, x), diff(f, y)], [x, y], dict=True)[0]
    return simplify(f.subs(sol))
q("C15-C-038", TOPIC, "Point minimising the sum of squared distances to the vertices", "Difficult",
  "Casework/optimisation",
  r"Three friends live at the corners of a right-angled triangular plot whose legs are $6$ km and $12$ km. They want to meet at a point $X$ for which the sum of the squares of the distances from $X$ to the three corners is as small as possible. What is this smallest sum, in km$^2$?",
  "MCQ",
  r"The sum $\sum |X - V_i|^2$ is smallest at the centroid $G$, and the minimum equals $\sum |G - V_i|^2 = \frac{4}{9}\sum m_i^2 = \frac{4}{9} \times \frac{3}{4}\sum a_i^2 = \frac{1}{3}(a^2 + b^2 + c^2)$. Here $a^2 + b^2 + c^2 = 36 + 144 + 180 = 360$, so the minimum is $120$ km$^2$. (Check with coordinates: corners $(0,0), (6,0), (0,12)$, $G = (2, 4)$, sum $= 20 + 32 + 68 = 120$.)",
  "Choosing the circumcentre or the right-angle corner, or omitting the 3/4 factor for medians.",
  "C15C-centroid-sum-of-squares", "Must identify the centroid as the minimiser and evaluate a sum of squares.",
  correct=r"$120$ km$^2$",
  distractors=[(r"$135$ km$^2$", r"Takes $X$ as the circumcentre, the midpoint of the hypotenuse: $3 \times 45$."),
               (r"$180$ km$^2$", r"Takes $X$ at the right-angle corner: $0 + 36 + 144$."),
               (r"$160$ km$^2$", r"Uses $\frac{4}{9}(a^2 + b^2 + c^2)$, leaving out the $\frac{3}{4}$ that converts sides to medians.")],
  check=_c038, values=[120, 135, 180, 160], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 039
def _c039():
    P, Q = Point(0, 0), Point(6, 0)
    R = Point(10 * cos(2 * pi / 3), 10 * sin(2 * pi / 3))
    return simplify(Triangle(P, Q, R).inradius)
_Pc, _Qc = (0.0, 0.0), (6.0, 0.0)
_Rc = (10 * _m.cos(_m.radians(120)), 10 * _m.sin(_m.radians(120)))
_f = Fig()
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc)
_f.poly(_P, _Q, _R); _f.angle_mark(_Q, _P, _R, "120^\\circ")
_f.label_seg(_P, _Q, "6"); _f.label_seg(_P, _R, "10")
_alt = "Triangle PQR with PQ = 6, PR = 10 and the angle at P marked 120 degrees."
q("C15-C-039", TOPIC, "Inradius of a triangle with a 120 degree angle", "Difficult",
  "Multi-step word problem",
  r"In triangle $PQR$, $PQ = 6$ cm, $PR = 10$ cm and $\angle QPR = 120^\circ$. What is the inradius of the triangle?",
  "MCQ",
  r"Drop the perpendicular from $R$ to line $QP$ extended beyond $P$, meeting it at $H$. Triangle $RHP$ is $30$-$60$-$90$ with $\angle RPH = 60^\circ$, so $PH = 5$ and $RH = 5\sqrt{3}$. Then $QR^2 = (6 + 5)^2 + 75 = 196$, so $QR = 14$. The area is $\frac{1}{2} \times 6 \times 5\sqrt{3} = 15\sqrt{3}$ and $s = \frac{6 + 10 + 14}{2} = 15$, so $r = \frac{15\sqrt{3}}{15} = \sqrt{3}$ cm.",
  "Dividing the area by the perimeter, or forgetting the half in the area.",
  "C15C-special-triangles-combined", "Needs an external 30-60-90 construction to find the third side, then area and inradius.",
  correct=r"$\sqrt{3}$ cm",
  distractors=[(r"$\frac{\sqrt{3}}{2}$ cm", r"Divides the area $15\sqrt{3}$ by the perimeter $30$."),
               (r"$\frac{14\sqrt{3}}{3}$ cm", r"Computes the circumradius $\frac{QR}{2\sin 120^\circ}$ instead."),
               (r"$2\sqrt{3}$ cm", r"Forgets the $\frac{1}{2}$ in the area, using $30\sqrt{3}$, and divides by $s = 15$.")],
  check=_c039, values=[sqrt(3), sqrt(3) / 2, 14 * sqrt(3) / 3, 2 * sqrt(3)],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 040
def _c040():
    x, y = symbols('x y', real=True)
    O, P = Point(0, 0), Point(0, 10)
    sol = solve([Eq(x**2 + y**2, 100), Eq(x**2 + (y - 10)**2, 256)], [x, y], dict=True)
    xs = {abs(d[x]) for d in sol}
    assert len(xs) == 1
    return 2 * xs.pop()
_Oc, _Pc = (0.0, 0.0), (0.0, 10.0)
_Qc, _Rc = (-9.6, -2.8), (9.6, -2.8)
_f = Fig()
_f.circle(_Oc, 10)
_P = _f.pt("P", *_Pc); _Q = _f.pt("Q", *_Qc); _R = _f.pt("R", *_Rc); _O = _f.pt("O", *_Oc, offset=(1, 0))
_f.poly(_P, _Q, _R)
_f.label_seg(_P, _Q, "16", side=-1); _f.label_seg(_P, _R, "16", side=-1)
_alt = "Isosceles triangle PQR with PQ = PR = 16 inscribed in a circle with centre O."
q("C15-C-040", TOPIC, "Base of an isosceles triangle from its equal sides and circumradius", "Difficult",
  "Inverse/parameter",
  r"An isosceles triangle $PQR$ with $PQ = PR = 16$ cm is inscribed in a circle of radius $10$ cm. What is the length of $QR$?",
  "MCQ",
  r"Let $h$ be the altitude from $P$; it passes through the centre. Using $R = \frac{abc}{4\Delta}$ with $\Delta = \frac{1}{2} \cdot QR \cdot h$ gives $PQ^2 = 2Rh$, so $256 = 20h$ and $h = 12.8$ cm. Then half of $QR$ is $\sqrt{16^2 - 12.8^2} = \sqrt{92.16} = 9.6$, so $QR = 19.2$ cm.",
  "Stopping at the half-base or the altitude, or assuming an equilateral triangle.",
  "C15C-circumradius-abc", "Needs the relation between equal side, altitude and circumradius, then Pythagoras.",
  correct=r"$19.2$ cm",
  distractors=[(r"$9.6$ cm", r"Stops at half of $QR$."),
               (r"$12.8$ cm", r"Reports the altitude from $P$."),
               (r"$16.0$ cm", "Assumes the triangle is equilateral.")],
  check=_c040, values=[Rational(96, 5), Rational(48, 5), Rational(64, 5), 16],
  figure=dict(svg=_f.svg(alt=_alt), alt=_alt, required=False), cognitive="Analysis", exams=HARD)
