import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from sympy.ntheory.modular import crt as _crt

T = "Modular arithmetic theorems"
HARD = ("CAT", "XAT")


def _brute_mod_pow(a, e, m):
    # repeated squaring written out, independent of pow()
    r, b = 1 % m, a % m
    while e:
        if e & 1:
            r = (r * b) % m
        b = (b * b) % m
        e >>= 1
    return r


# ---------------------------------------------------------------- EASY

def _e1():
    return _brute_mod_pow(3, 1000, 23)
q("C22-B-001", T, "Fermat's little theorem to reduce a large exponent modulo a prime", "Easy",
  "Single-step computation",
  r"What is the remainder when $3^{1000}$ is divided by $23$?",
  "MCQ",
  r"Since $23$ is prime and does not divide $3$, Fermat's little theorem gives $3^{22} \equiv 1 \pmod{23}$. As $1000 = 22 \times 45 + 10$, $3^{1000} \equiv 3^{10}$. Now $3^3 = 27 \equiv 4$, so $3^9 \equiv 4^3 = 64 \equiv 18$ and $3^{10} \equiv 54 \equiv 8$. The remainder is $8$.",
  "Reducing the exponent modulo $p$ instead of $p - 1$.",
  "C22B-fermat-power-mod-prime", "One application of Fermat's theorem and a short power computation.",
  correct=r"$8$",
  distractors=[(r"$1$", "Reduces the exponent modulo $23$ instead of $22$: $1000 = 23 \\times 43 + 11$, and $3^{11} = 177147 \\equiv 1 \\pmod{23}$, giving $1$."),
               (r"$10$", "Reports the reduced exponent $1000 \\bmod 22 = 10$ as the remainder."),
               (r"$15$", "Mixes Fermat with Wilson and takes $3^{22} \\equiv -1$, giving $(-1)^{45} \\cdot 8 = -8 \\equiv 15$.")],
  check=_e1, values=[8, 1, 10, 15], cognitive="Application")


def _e2():
    assert isprime(2027)
    return _brute_mod_pow(3, 2029, 2027)
q("C22-B-002", T, "Fermat's theorem when the exponent slightly exceeds the prime", "Easy",
  "Single-step computation",
  r"The number $2027$ is prime. What is the remainder when $3^{2029}$ is divided by $2027$?",
  "MCQ",
  r"By Fermat's little theorem $3^{2026} \equiv 1 \pmod{2027}$. Hence $3^{2029} = 3^{2026} \cdot 3^3 \equiv 27$. Since $27 < 2027$, the remainder is $27$.",
  r"Using $a^{p} \equiv 1$ in place of $a^{p-1} \equiv 1$.",
  "C22B-fermat-power-mod-prime", "Direct use of Fermat's theorem with a tiny leftover power.",
  correct=r"$27$",
  distractors=[(r"$9$", "Uses $3^{2027} \\equiv 1$, so $3^{2029} \\equiv 3^2 = 9$."),
               (r"$3$", "Applies the last-digit cycle of length $4$: $2029 \\bmod 4 = 1$, so takes $3^1$."),
               (r"$2000$", "Takes $3^{2026} \\equiv -1$ (Wilson's sign), giving $-27 \\equiv 2000$.")],
  check=_e2, values=[27, 9, 3, 2000], cognitive="Application")


def _e3():
    return (math.factorial(36) + 50) % 37
q("C22-B-003", T, "Wilson's theorem for (p-1)! plus a constant", "Easy",
  "Single-step computation",
  r"What is the remainder when $36! + 50$ is divided by $37$?",
  "TITA",
  r"$37$ is prime, so Wilson's theorem gives $36! \equiv -1 \pmod{37}$. Then $36! + 50 \equiv 49 \equiv 12 \pmod{37}$. The remainder is $12$.",
  r"Assuming $36!$ is a multiple of $37$, or taking $(p-1)! \equiv +1$.",
  "C22B-wilson-basic", "One recall of Wilson's theorem and a single reduction.",
  tita_answer=12, check=_e3,
  tita_traps=[(13, "Treats $36!$ as divisible by $37$, so reduces only $50 \\equiv 13$."),
              (14, "Uses $36! \\equiv +1$, so $51 \\equiv 14$.")],
  cognitive="Recall")


def _e4():
    phi = sum(1 for t in range(1, 46) if math.gcd(t, 45) == 1)
    assert phi == 24 and _brute_mod_pow(7, phi, 45) == 1
    return _brute_mod_pow(7, 2090, 45)
q("C22-B-004", T, "Euler's theorem with a composite modulus", "Easy",
  "Single-step computation",
  r"What is the remainder when $7^{2090}$ is divided by $45$?",
  "MCQ",
  r"$\gcd(7, 45) = 1$ and $\phi(45) = 45 \cdot \frac{2}{3} \cdot \frac{4}{5} = 24$, so $7^{24} \equiv 1 \pmod{45}$ by Euler's theorem. As $2090 = 24 \times 87 + 2$, $7^{2090} \equiv 7^2 = 49 \equiv 4 \pmod{45}$. The remainder is $4$.",
  r"Computing $\phi(45)$ as if $45$ were prime, or leaving out one of its prime factors.",
  r"C22B-euler-power-composite", r"Needs $\phi(n)$ for a composite $n$, then one reduction to a small exponent.",
  correct=r"$4$",
  distractors=[(r"$34$", "Takes $\\phi(45) = 44$ as for a prime: $2090 = 44 \\times 47 + 22$, and $7^{22} \\equiv 34 \\pmod{45}$."),
               (r"$31$", "Omits the prime $5$ and takes $\\phi(45) = 45 \\cdot \\frac{2}{3} = 30$: $2090 = 30 \\times 69 + 20$ and $7^{20} \\equiv 31 \\pmod{45}$."),
               (r"$2$", "Reports the reduced exponent $2090 \\bmod 24 = 2$ as the remainder.")],
  check=_e4, values=[4, 34, 31, 2], cognitive="Application")


def _e5():
    return sum(1 for t in range(1, 451) if math.gcd(t, 450) == 1)
q("C22-B-005", T, "Euler's totient as a count of numbers coprime to n", "Easy",
  "Single-step computation",
  r"Raffle tickets are numbered $1$ to $450$. A ticket is called lucky if its number has no common factor greater than $1$ with $450$. How many tickets are lucky?",
  "MCQ",
  r"The count is $\phi(450)$. Since $450 = 2 \cdot 3^2 \cdot 5^2$, $\phi(450) = 450 \cdot \frac{1}{2} \cdot \frac{2}{3} \cdot \frac{4}{5} = 120$.",
  "Leaving out one prime factor of $450$, or counting the complement.",
  "C22B-totient-count", "Direct use of the totient formula once $450$ is factorised.",
  correct=r"$120$",
  distractors=[(r"$330$", "Counts the tickets that do share a factor with $450$: $450 - 120$."),
               (r"$180$", "Omits the prime $3$: $450 \\cdot \\frac{1}{2} \\cdot \\frac{4}{5} = 180$."),
               (r"$240$", "Omits the prime $2$: $450 \\cdot \\frac{2}{3} \\cdot \\frac{4}{5} = 240$.")],
  check=_e5, values=[120, 330, 180, 240], cognitive="Application")


def _e6():
    return sum(1 for m in range(1, 84) if Fraction(m, 84).denominator == 84)
q("C22-B-006", T, "Totient count of fractions m/84 already in lowest terms", "Easy",
  "Single-step computation",
  r"Consider the $83$ fractions $\frac{m}{84}$ for $m = 1, 2, 3, \ldots, 83$. How many of them are already in lowest terms?",
  "TITA",
  r"$\frac{m}{84}$ is in lowest terms exactly when $\gcd(m, 84) = 1$, so the count is $\phi(84)$. With $84 = 2^2 \cdot 3 \cdot 7$, $\phi(84) = 84 \cdot \frac{1}{2} \cdot \frac{2}{3} \cdot \frac{6}{7} = 24$.",
  "Ignoring one prime factor of $84$ or counting the reducible fractions.",
  r"C22B-totient-count", r"Recognising the count as $\phi(84)$ and applying the formula.",
  tita_answer=24, check=_e6,
  tita_traps=[(36, "Omits the prime $3$: $84 \\cdot \\frac{1}{2} \\cdot \\frac{6}{7} = 36$."),
              (28, "Omits the prime $7$: $84 \\cdot \\frac{1}{2} \\cdot \\frac{2}{3} = 28$."),
              (59, "Counts the fractions that can be reduced: $83 - 24$.")],
  cognitive="Application")


def _e7():
    return sum(1 for n in range(1, 101) if (3 ** n - 1) % 13 == 0)
q("C22-B-007", T, "Order of 3 modulo 13 is smaller than the Fermat exponent", "Easy",
  "Conceptual/application",
  r"For how many integers $n$ with $1 \le n \le 100$ is $3^n - 1$ divisible by $13$?",
  "MCQ",
  r"$3^3 = 27 = 2 \cdot 13 + 1$, so $3^3 \equiv 1 \pmod{13}$, while $3^1 \equiv 3$ and $3^2 \equiv 9$. Hence $13 \mid 3^n - 1$ exactly when $3 \mid n$. The multiples of $3$ from $1$ to $100$ number $\lfloor 100/3 \rfloor = 33$.",
  "Assuming the cycle length is the Fermat exponent $12$ rather than the actual order $3$.",
  r"C22B-order-of-element", r"One observation ($3^3 \equiv 1$) then a simple count.",
  correct=r"$33$",
  distractors=[(r"$8$", "Uses only Fermat's period $12$: $\\lfloor 100/12 \\rfloor = 8$."),
               (r"$25$", "Uses the last-digit cycle of $3$ (length $4$): $\\lfloor 100/4 \\rfloor = 25$."),
               (r"$34$", "Counts $\\lfloor 100/3 \\rfloor + 1$, adding $n = 0$ which is outside the range.")],
  check=_e7, values=[33, 8, 25, 34], cognitive="Understanding")


def _e8():
    x = 1
    while (8 * x) % 29 != 1:
        x += 1
    return x
q("C22-B-008", T, "Modular inverse in a sharing problem", "Easy",
  "Inverse/parameter",
  r"Kabir buys some packets, each containing exactly $8$ pencils. He distributes all the pencils among $29$ students so that every student gets the same number of pencils, as many as possible, and exactly $1$ pencil is left over. What is the least number of packets he could have bought?",
  "TITA",
  r"If he buys $x$ packets, $8x \equiv 1 \pmod{29}$, so $x$ is the inverse of $8$ modulo $29$. Since $8 \times 11 = 88 = 3 \times 29 + 1$, $x = 11$ (and no smaller positive $x$ works, because $8x$ for $x = 1, \ldots, 10$ leaves remainders $8, 16, 24, 3, 11, 19, 27, 6, 14, 22$). He bought $11$ packets.",
  r"Solving $8x \equiv -1$ instead of $8x \equiv 1$, or reporting the pencils.",
  "C22B-modular-inverse", "Finding a single modular inverse by a short search.",
  tita_answer=11, check=_e8,
  tita_traps=[(18, "Solves $8x \\equiv -1$: $8 \\times 18 = 144 = 5 \\times 29 - 1$, one pencil short, not one over."),
              (88, "Reports the number of pencils instead of packets.")],
  cognitive="Application")


def _e9():
    return sum(1 for k in range(1, 61) if Fraction(k, 60).denominator == 12)
q("C22-B-009", T, "Reduced fractions k/60 with a given denominator count via phi", "Easy",
  "Conceptual/application",
  r"Each of the $60$ fractions $\frac{k}{60}$, $k = 1, 2, \ldots, 60$, is reduced to lowest terms. How many of the reduced fractions have denominator exactly $12$?",
  "MCQ",
  r"$\frac{k}{60}$ reduces to denominator $12$ exactly when $k = 5j$ with $1 \le j \le 12$ and $\gcd(j, 12) = 1$, since then $\frac{k}{60} = \frac{j}{12}$ in lowest terms. The count is $\phi(12) = 4$: $j = 1, 5, 7, 11$.",
  "Counting every multiple of $5$, or removing only one prime factor of $12$.",
  r"C22B-totient-fraction-structure", r"Single idea: denominators after reduction are counted by $\phi$.",
  correct=r"$4$",
  distractors=[(r"$12$", "Counts all multiples of $5$ from $5$ to $60$ without checking whether they reduce further."),
               (r"$6$", "Removes only even $j$, keeping $j = 1, 3, 5, 7, 9, 11$."),
               (r"$8$", "Removes only multiples of $3$, keeping $8$ values of $j$.")],
  check=_e9, values=[4, 12, 6, 8], cognitive="Understanding")


def _e10():
    return sum(_brute_mod_pow(k, 16, 17) for k in range(1, 17)) % 17
q("C22-B-010", T, "Sum of (p-1)th powers over a full set of non-zero residues", "Easy",
  "Conceptual/application",
  r"What is the remainder when $1^{16} + 2^{16} + 3^{16} + \cdots + 16^{16}$ is divided by $17$?",
  "MCQ",
  r"$17$ is prime and none of $1, \ldots, 16$ is divisible by $17$, so each $k^{16} \equiv 1 \pmod{17}$ by Fermat's little theorem. The sum is $\equiv 16 \times 1 = 16$. The remainder is $16$.",
  r"Treating the sum as $1 + 2 + \cdots + 16$, or as a single term $\equiv 1$.",
  "C22B-sum-of-powers-mod-prime", "One application of Fermat's theorem to every term.",
  correct=r"$16$",
  distractors=[(r"$0$", "Replaces each $k^{16}$ by $k$: $1 + 2 + \\cdots + 16 = 136 \\equiv 0$."),
               (r"$1$", "Treats the whole sum as $\\equiv 1$, as if Fermat applied to the sum rather than each term."),
               (r"$8$", "Pairs $k$ with $17 - k$ and counts each of the $8$ pairs as contributing $1$.")],
  check=_e10, values=[16, 0, 1, 8], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM

def _m1():
    from functools import reduce
    return reduce(math.gcd, [n ** 7 - n for n in range(2, 60)])
q("C22-B-011", T, "Largest integer dividing n^7 - n for every integer n", "Medium",
  "Conceptual/application",
  r"What is the largest positive integer that divides $n^7 - n$ for every integer $n$?",
  "MCQ",
  r"For $n = 2$, $n^7 - n = 126 = 2 \cdot 3^2 \cdot 7$, and for $n = 3$, $n^7 - n = 2184 = 2^3 \cdot 3 \cdot 7 \cdot 13$, so the answer divides $\gcd(126, 2184) = 42$. Conversely $7 \mid n^7 - n$ by Fermat's little theorem, $3 \mid n^7 - n = n(n^6 - 1)$ because $n^2 \equiv 1 \pmod 3$ when $3 \nmid n$, and $n^7 - n$ is always even. So $42$ divides it for every $n$, and the answer is $42$.",
  "Applying Fermat only for $p = 7$, or assuming every prime up to $7$ works.",
  "C22B-fermat-universal-divisor", "Needs Fermat for several primes plus a test value to show maximality.",
  correct=r"$42$",
  distractors=[(r"$7$", "Uses only Fermat's theorem for the prime $7$."),
               (r"$14$", "Uses Fermat for $7$ and parity, but misses the factor $3$."),
               (r"$210$", "Assumes every prime up to $7$ divides $n^7 - n$, including $5$ (but $5 \\nmid 126$).")],
  check=_m1, values=[42, 7, 14, 210], cognitive="Analysis")


def _m2():
    return math.factorial(40) % 43
q("C22-B-012", T, "Wilson's theorem for (p-3)! modulo p", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $40!$ is divided by $43$?",
  "MCQ",
  r"By Wilson's theorem $42! \equiv -1 \pmod{43}$. Also $42! = 40! \cdot 41 \cdot 42 \equiv 40! \cdot (-2)(-1) = 2 \cdot 40!$. So $2 \cdot 40! \equiv -1 \equiv 42$, giving $40! \equiv 21 \pmod{43}$. Check: $2 \times 21 = 42$.",
  "Applying Wilson's theorem directly to $40!$, or losing the sign when dividing.",
  "C22B-wilson-near-prime", "Wilson's theorem plus removing two factors and a modular division.",
  correct=r"$21$",
  distractors=[(r"$42$", "Applies Wilson's theorem to $40!$ directly, taking $40! \\equiv -1$."),
               (r"$22$", "Drops the sign: solves $2 \\cdot 40! \\equiv +1$, giving $22$."),
               (r"$1$", "Extends the pattern $(p-2)! \\equiv 1$ to $(p-3)!$ without computing.")],
  check=_m2, values=[21, 42, 22, 1], cognitive="Application")


def _m3():
    return _brute_mod_pow(13, 2026, 100)
q("C22-B-013", T, "Last two digits of a power via Euler's theorem modulo 100", "Medium",
  "Multi-step word problem",
  r"The number formed by the last two digits of $13^{2026}$ is",
  "MCQ",
  r"$\gcd(13, 100) = 1$ and $\phi(100) = 40$, so $13^{40} \equiv 1 \pmod{100}$ by Euler's theorem. As $2026 = 40 \times 50 + 26$, $13^{2026} \equiv 13^{26} = 13^{20} \cdot 13^6 \pmod{100}$. Squaring, $13^2 \equiv 69$, $13^4 \equiv 61$, $13^5 \equiv 93$, $13^{10} \equiv 49$, $13^{20} \equiv 01$, so $13^{2026} \equiv 13^6 = 13^4 \cdot 13^2 \equiv 61 \times 69 = 4209 \equiv 09$. The last two digits are $09$.",
  "Using the last-digit cycle for two digits, or ignoring the tens digit of the base.",
  "C22B-euler-last-two-digits", "Euler modulo $100$ with a few squarings; several tempting shortcuts fail.",
  correct=r"$09$",
  distractors=[(r"$69$", "Uses the last-digit cycle of length $4$: $2026 \\bmod 4 = 2$, giving $13^2 = 169$."),
               (r"$29$", "Keeps only $3^{2026}$ from $(10 + 3)^{2026}$: $3^{2026} \\equiv 3^6 = 729$."),
               (r"$59$", "Expands $(10 + 3)^{2026}$ but drops the coefficient $2026$ on the cross term: $3^{2026} + 10 \\cdot 3^{2025} \\equiv 29 + 30$.")],
  check=_m3, values=[9, 69, 29, 59], cognitive="Application")


def _m4():
    e = _brute_mod_pow(3, 100, 12)
    return _brute_mod_pow(7, e + 12, 13)
q("C22-B-014", T, "Power tower modulo a prime: reduce the exponent modulo p-1", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $7^{3^{100}}$ is divided by $13$? (Here the exponent is $3^{100}$.)",
  "MCQ",
  r"By Fermat, $7^{12} \equiv 1 \pmod{13}$, so we need $3^{100} \bmod 12$. It is divisible by $3$, and $3^{100} = 9^{50} \equiv 1 \pmod 4$; the residue modulo $12$ that is $\equiv 0 \pmod 3$ and $\equiv 1 \pmod 4$ is $9$. So $7^{3^{100}} \equiv 7^9$. Now $7^2 = 49 \equiv -3$, $7^4 \equiv 9$, $7^8 \equiv 81 \equiv 3$, so $7^9 \equiv 21 \equiv 8$.",
  "Reducing the tower exponent modulo $13$ instead of $12$.",
  "C22B-power-tower", "Two layers: exponent modulo $12$ by a mini CRT, then a power modulo $13$.",
  correct=r"$8$",
  distractors=[(r"$5$", "Reduces the exponent modulo $13$: $3^{100} \\equiv 3^{1} = 3 \\pmod{13}$, then $7^3 = 343 \\equiv 5$."),
               (r"$7$", "Reduces the exponent using its last digit: $3^{100}$ ends in $1$, so takes $7^1$."),
               (r"$9$", "Reports the reduced exponent $3^{100} \\bmod 12 = 9$ as the remainder.")],
  check=_m4, values=[8, 5, 7, 9], cognitive="Application", exams=HARD)


def _m5():
    e = _brute_mod_pow(3, 2026, 22)
    return _brute_mod_pow(2, e, 23)
q("C22-B-015", T, "Power tower with base 2 modulo 23", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $2^{3^{2026}}$ is divided by $23$? (Here the exponent is $3^{2026}$.)",
  "TITA",
  r"By Fermat, $2^{22} \equiv 1 \pmod{23}$, so reduce $3^{2026}$ modulo $22$. It is odd, and modulo $11$, $3^5 = 243 \equiv 1$, so $3^{2026} = (3^5)^{405} \cdot 3 \equiv 3$. The residue modulo $22$ that is odd and $\equiv 3 \pmod{11}$ is $3$. Hence $2^{3^{2026}} \equiv 2^3 = 8 \pmod{23}$.",
  "Reducing the exponent modulo $23$ instead of $22$.",
  "C22B-power-tower", "Exponent must be reduced modulo $22$ using a cycle modulo $11$.",
  tita_answer=8, check=_m5,
  tita_traps=[(6, "Reduces the exponent modulo $23$: $3^{2026} \\equiv 9 \\pmod{23}$, then $2^9 = 512 \\equiv 6$."),
              (3, "Reports the reduced exponent $3$ instead of $2^3$.")],
  cognitive="Application", exams=HARD)


def _m6():
    r, M = _crt([9, 7], [_brute_mod_pow(3, 2026, 9), _brute_mod_pow(3, 2026, 7)])
    assert M == 63
    return int(r)
q("C22-B-016", T, "Splitting a modulus that shares a factor with the base", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $3^{2026}$ is divided by $63$?",
  "MCQ",
  r"Write $63 = 9 \times 7$. Modulo $9$: $3^{2026} \equiv 0$. Modulo $7$: Fermat gives $3^6 \equiv 1$, and $2026 = 6 \times 337 + 4$, so $3^{2026} \equiv 3^4 = 81 \equiv 4$. The number below $63$ that is a multiple of $9$ and $\equiv 4 \pmod 7$ is $18$ (from $0, 9, 18, \ldots$, $18 = 2 \cdot 7 + 4$). The remainder is $18$.",
  "Treating $3$ as coprime to $9$, or reporting only the residue modulo $7$.",
  "C22B-crt-split-modulus", "Base not coprime to the modulus, so the modulus must be split and recombined.",
  correct=r"$18$",
  distractors=[(r"$4$", "Reports only the residue modulo $7$."),
               (r"$46$", "Applies Euler modulo $9$ as if $\\gcd(3, 9) = 1$, takes $3^{2026} \\equiv 1 \\pmod 9$, and combines with $4 \\pmod 7$."),
               (r"$36$", "Takes $3^{2026} \\equiv 1 \\pmod 7$ by Fermat without reducing $2026$ modulo $6$, and combines with $0 \\pmod 9$.")],
  check=_m6, values=[18, 4, 46, 36], cognitive="Analysis")


def _m7():
    return _brute_mod_pow(6, 2026, 100)
q("C22-B-017", T, "Last two digits of a power of 6 via CRT with moduli 4 and 25", "Medium",
  "Multi-step word problem",
  r"What is the number formed by the last two digits of $6^{2026}$?",
  "TITA",
  r"Work modulo $4$ and $25$. Modulo $4$: $6^{2026} \equiv 0$. Modulo $25$: $\phi(25) = 20$ and $2026 \equiv 6 \pmod{20}$, so $6^{2026} \equiv 6^6 = 46656 \equiv 6 \pmod{25}$. Among $6, 31, 56, 81$ (the numbers below $100$ that are $\equiv 6 \pmod{25}$) the multiple of $4$ is $56$. The last two digits are $56$.",
  "Believing every power of $6$ ends in $76$, or misaligning the cycle of last two digits.",
  "C22B-euler-last-two-digits", "Base shares a factor with $100$, so Euler must be applied modulo $25$ and combined.",
  tita_answer=56, check=_m7,
  tita_traps=[(76, "Assumes all high powers of $6$ end in $76$."),
              (36, "Lists the cycle $36, 16, 96, 76, 56$ (which starts at $6^2$) and picks its first term because $2026 \\bmod 5 = 1$.")],
  cognitive="Application")


def _m8():
    for N in range(1001):
        if N % 7 == 3 and N % 11 == 5 and N % 13 == 6:
            return N
q("C22-B-018", T, "Recovering a remainder modulo 1001 from remainders modulo 7, 11 and 13", "Medium",
  "Multi-step word problem",
  r"A positive integer $N$ leaves remainders $3$, $5$ and $6$ when divided by $7$, $11$ and $13$ respectively. What is the remainder when $N$ is divided by $1001$?",
  "MCQ",
  r"Since $1001 = 7 \cdot 11 \cdot 13$, the remainder is the unique solution below $1001$. From $N \equiv 3 \pmod 7$ and $N \equiv 5 \pmod{11}$: $N = 3 + 7j$ with $7j \equiv 2 \pmod{11}$, so $j \equiv 5$ and $N \equiv 38 \pmod{77}$. Next $N = 38 + 77k$; modulo $13$, $38 \equiv 12$ and $77 \equiv -1$, so $12 - k \equiv 6$, $k = 6$, and $N \equiv 38 + 462 = 500 \pmod{1001}$.",
  "Stopping after two congruences, or slipping on the sign of $77$ modulo $13$.",
  "C22B-crt-three-moduli", "Two rounds of combining congruences with inverses.",
  correct=r"$500$",
  distractors=[(r"$38$", "Combines only the first two conditions and stops."),
               (r"$577$", "Takes $77 \\equiv +1 \\pmod{13}$, so $12 + k \\equiv 6$ gives $k = 7$ and $38 + 539 = 577$."),
               (r"$462$", "Finds $k = 6$ but reports $77k = 462$ without adding $38$.")],
  check=_m8, values=[500, 38, 577, 462], cognitive="Application", exams=HARD)


def _m9():
    r, M = _crt([7, 11], [_brute_mod_pow(12, 2027, 7), _brute_mod_pow(12, 2027, 11)])
    return int(r)
q("C22-B-019", T, "Power modulo 77 by combining Fermat modulo 7 and 11", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $12^{2027}$ is divided by $77$?",
  "MCQ",
  r"Modulo $11$: $12 \equiv 1$, so $12^{2027} \equiv 1$. Modulo $7$: $12 \equiv 5$, $5^6 \equiv 1$ and $2027 = 6 \times 337 + 5$, so $12^{2027} \equiv 5^5 = 3125 \equiv 3$. The numbers below $77$ that are $\equiv 1 \pmod{11}$ are $1, 12, 23, 34, 45, 56, 67$; the one $\equiv 3 \pmod 7$ is $45$. The remainder is $45$.",
  "Treating $77$ as prime, or reporting a single residue.",
  "C22B-crt-split-modulus", "Two Fermat reductions plus a CRT combination.",
  correct=r"$45$",
  distractors=[(r"$34$", "Treats $77$ as prime and reduces the exponent modulo $76$: $12^{51} \\equiv 34 \\pmod{77}$."),
               (r"$3$", "Reports only the residue modulo $7$."),
               (r"$23$", "Reduces the exponent modulo $7$ instead of $6$: $5^{4} \\equiv 2 \\pmod 7$, then combines to $23$.")],
  check=_m9, values=[45, 34, 3, 23], cognitive="Application")


def _m10():
    return sum(1 for x in range(1, 201) if (7 * x - 3) % 26 == 0)
q("C22-B-020", T, "Counting solutions of a linear congruence in a range", "Medium",
  "Casework/optimisation",
  r"For how many integers $x$ with $1 \le x \le 200$ does $7x$ leave remainder $3$ when divided by $26$?",
  "TITA",
  r"$7 \times 15 = 105 = 4 \times 26 + 1$, so $7^{-1} \equiv 15 \pmod{26}$ and $x \equiv 3 \times 15 = 45 \equiv 19 \pmod{26}$. The values are $19, 45, 71, \ldots$; the largest not exceeding $200$ is $19 + 6 \times 26 = 175$. That gives $7$ values.",
  "Estimating the count as $200/26$ rounded up, or reporting the smallest solution.",
  "C22B-modular-inverse", "Needs an inverse, then a careful count in the range.",
  tita_answer=7, check=_m10,
  tita_traps=[(8, "Rounds $200/26 \\approx 7.7$ up instead of listing the solutions."),
              (19, "Reports the smallest solution instead of the count.")],
  cognitive="Application")


def _m11():
    return sum(k ** 5 for k in range(1, 21)) % 17
q("C22-B-021", T, "Sum of fifth powers modulo 17 by pairing k with 17 - k", "Medium",
  "Conceptual/application",
  r"What is the remainder when $1^5 + 2^5 + 3^5 + \cdots + 20^5$ is divided by $17$?",
  "MCQ",
  r"Since $5$ is odd, $k^5 + (17 - k)^5 \equiv k^5 + (-k)^5 = 0 \pmod{17}$, so pairing $1$ with $16$, $2$ with $15$, and so on gives $1^5 + \cdots + 16^5 \equiv 0 \pmod{17}$. Also $17^5 \equiv 0$, and $18, 19, 20 \equiv 1, 2, 3$. The sum is $\equiv 1 + 32 + 243 = 276 = 16 \times 17 + 4$, so the remainder is $4$.",
  r"Applying Fermat's $k^{p-1} \equiv 1$ to an exponent that is not a multiple of $p - 1$.",
  "C22B-sum-of-powers-mod-prime", "Requires seeing that odd powers cancel in pairs $k$, $17 - k$ modulo $17$, plus a leftover tail.",
  correct=r"$4$",
  distractors=[(r"$0$", "Treats all $20$ terms as one complete residue set whose sum vanishes."),
               (r"$2$", "Takes $k^5 \\equiv 1$ for every $k$ not divisible by $17$, so the sum is $16 + 0 + 3 = 19 \\equiv 2$."),
               (r"$6$", "Replaces $k^5$ by $k$: $1 + 2 + \\cdots + 20 = 210 \\equiv 6$.")],
  check=_m11, values=[4, 0, 2, 6], cognitive="Analysis")


def _m12():
    n = 1
    while (2 ** n - 1) % 47 != 0:
        n += 1
    return n
q("C22-B-022", T, "Least exponent n with 2^n congruent to 1 modulo 47", "Medium",
  "Inverse/parameter",
  r"What is the least positive integer $n$ for which $2^n - 1$ is divisible by $47$?",
  "TITA",
  r"By Fermat $2^{46} \equiv 1 \pmod{47}$, so the least such $n$ divides $46$: it is $1$, $2$, $23$ or $46$. Clearly $n = 1, 2$ fail. For $23$: $2^{10} = 1024 \equiv -10$, so $2^{20} \equiv 100 \equiv 6$ and $2^{23} \equiv 48 \equiv 1 \pmod{47}$. Hence $n = 23$.",
  "Assuming the Fermat exponent $p - 1$ is always the least one.",
  "C22B-order-of-element", "Uses that the order divides $p - 1$, then tests one candidate.",
  tita_answer=23, check=_m12,
  tita_traps=[(46, "Takes the Fermat exponent $p - 1$ as the least exponent.")],
  cognitive="Analysis")


def _m13():
    return len({Fraction(p, qq) for qq in range(2, 11) for p in range(1, qq)})
q("C22-B-023", T, "Distinct proper fractions with denominator at most 10 as a sum of totients", "Medium",
  "Conceptual/application",
  r"How many distinct values are taken by the fractions $\frac{p}{q}$ where $p$ and $q$ are integers with $1 \le p < q \le 10$? (Equal values such as $\frac{1}{2}$ and $\frac{2}{4}$ are counted once.)",
  "MCQ",
  r"Each value has exactly one lowest-terms form $\frac{p}{q}$ with $\gcd(p, q) = 1$, so the count is $\phi(2) + \phi(3) + \cdots + \phi(10) = 1 + 2 + 2 + 4 + 2 + 6 + 4 + 6 + 4 = 31$.",
  "Counting all pairs without removing equal values.",
  "C22B-totient-fraction-structure", "Recognising the count as a sum of totients over denominators.",
  correct=r"$31$",
  distractors=[(r"$45$", "Counts all $\\binom{10}{2} = 45$ pairs $(p, q)$ without merging equal values."),
               (r"$32$", "Adds $\\phi(1) = 1$ by including denominator $1$."),
               (r"$35$", "Discards only the $10$ fractions with both $p$ and $q$ even.")],
  check=_m13, values=[31, 45, 32, 35], cognitive="Understanding")


def _m14():
    return sum(1 for n in range(1, 1001) if math.gcd(n, 210) == 1)
q("C22-B-024", T, "Count of integers up to 1000 coprime to 210 (partial totient block)", "Medium",
  "Casework/optimisation",
  r"How many integers from $1$ to $1000$ (inclusive) have no prime factor in common with $210$?",
  "MCQ",
  r"$210 = 2 \cdot 3 \cdot 5 \cdot 7$ and $\phi(210) = 48$. Inclusion and exclusion on $1$ to $1000$: multiples of $2, 3, 5, 7$ number $500 + 333 + 200 + 142 = 1175$; of pairs $166 + 100 + 71 + 66 + 47 + 28 = 478$; of triples $33 + 23 + 14 + 9 = 79$; of $210$: $4$. So the count is $1000 - 1175 + 478 - 79 + 4 = 228$. (Check: $1001$ to $1050$ contain $12$ such numbers, and $5 \times 48 - 12 = 228$.)",
  r"Scaling $\phi(210)$ proportionally and rounding, or counting a full fifth block.",
  "C22B-totient-count", "The range is not a whole number of periods, so the totient must be adjusted carefully.",
  correct=r"$228$",
  distractors=[(r"$229$", "Scales $1000 \\cdot \\frac{48}{210} \\approx 228.6$ and rounds up."),
               (r"$240$", "Counts five full blocks of $210$, that is up to $1050$: $5 \\times 48$."),
               (r"$772$", "Counts the numbers that do share a prime factor with $210$.")],
  check=_m14, values=[228, 229, 240, 772], cognitive="Application", exams=HARD)


def _m15():
    return _brute_mod_pow(99, 99, 101)
q("C22-B-025", T, "Fermat's theorem with a negative residue base modulo 101", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $99^{99}$ is divided by $101$?",
  "MCQ",
  r"$99 \equiv -2 \pmod{101}$, so $99^{99} \equiv -2^{99}$. By Fermat $2^{100} \equiv 1$, so $2^{99} \equiv 2^{-1} \equiv 51$ (as $2 \times 51 = 102 \equiv 1$). Hence $99^{99} \equiv -51 \equiv 50 \pmod{101}$.",
  "Losing the minus sign from the negative base.",
  "C22B-fermat-power-mod-prime", "Needs a negative residue, Fermat, and a modular inverse.",
  correct=r"$50$",
  distractors=[(r"$51$", "Computes $2^{99} \\equiv 51$ but forgets the sign from $(-2)^{99}$."),
               (r"$100$", "Treats $99$ as $-1$ (as it would be modulo $100$), giving $(-1)^{99} \\equiv 100$."),
               (r"$25$", "Uses $2^{101} \\equiv 1$, so $2^{99} \\equiv 4^{-1} \\equiv 76$ and $-76 \\equiv 25$.")],
  check=_m15, values=[50, 51, 100, 25], cognitive="Application")


def _m16():
    return sum(1 for n in range(2, 31) if math.factorial(n - 1) % n != 0)
q("C22-B-026", T, "When n fails to divide (n-1)!: primes by Wilson plus the exception 4", "Medium",
  "Conceptual/application",
  r"For how many integers $n$ with $2 \le n \le 30$ does $(n-1)!$ leave a non-zero remainder when divided by $n$?",
  "TITA",
  r"If $n$ is prime, Wilson's theorem gives $(n-1)! \equiv -1 \pmod n$, a non-zero remainder; there are $10$ primes up to $30$. If $n = ab$ is composite with $1 < a < b < n$, both $a$ and $b$ appear in $(n-1)!$. If $n = p^2$ with $p \ge 3$, both $p$ and $2p < n$ appear. The only exception is $n = 4$: $3! = 6 \equiv 2 \pmod 4$. So the count is $10 + 1 = 11$.",
  "Forgetting the composite exception $n = 4$, or wrongly excluding all prime squares.",
  "C22B-wilson-primality", "Needs Wilson for primes and a separate argument for composites with one exception.",
  tita_answer=11, check=_m16,
  tita_traps=[(10, "Counts only the primes and misses $n = 4$."),
              (13, "Also counts $9$ and $25$, thinking $p^2 \\nmid (p^2 - 1)!$ for every prime $p$.")],
  cognitive="Analysis")


# ---------------------------------------------------------------- DIFFICULT

def _d1():
    from functools import reduce
    return reduce(math.gcd, [n ** 13 - n for n in range(2, 80)])
q("C22-B-027", T, "Largest integer dividing n^13 - n for all n", "Difficult",
  "Conceptual/application",
  r"What is the largest positive integer that divides $n^{13} - n$ for every integer $n$?",
  "MCQ",
  r"A prime $p$ divides $n^{13} - n$ for all $n$ when $p - 1 \mid 12$, because then $n^{13} = n \cdot (n^{p-1})^{12/(p-1)} \equiv n$; this gives $p = 2, 3, 5, 7, 13$. No square of a prime works, since $p^{13} - p = p(p^{12} - 1)$ is not divisible by $p^2$. Other primes fail: $n = 2$ gives $8190 = 2 \cdot 3^2 \cdot 5 \cdot 7 \cdot 13$, which has no other prime factor. The answer is $2 \cdot 3 \cdot 5 \cdot 7 \cdot 13 = 2730$.",
  r"Missing a prime $p$ with $p - 1 \mid 12$, or including every prime up to $13$.",
  r"C22B-fermat-universal-divisor", r"Must characterise all primes through $p - 1 \mid 12$ and rule out squares.",
  correct=r"$2730$",
  distractors=[(r"$546$", "Misses the prime $5$ (overlooks that $4 \\mid 12$): $2 \\cdot 3 \\cdot 7 \\cdot 13$."),
               (r"$390$", "Misses the prime $7$ (overlooks that $6 \\mid 12$): $2 \\cdot 3 \\cdot 5 \\cdot 13$."),
               (r"$30030$", "Takes every prime up to $13$, including $11$, although $10 \\nmid 12$.")],
  check=_d1, values=[2730, 546, 390, 30030], cognitive="Analysis", exams=HARD)


def _d2():
    E = 2 ** 2026  # exact exponent, then reduce via the 4 x 25 split by direct computation
    r4 = 0
    r25 = _brute_mod_pow(2, E % 20 + 20, 25)
    for x in range(100):
        if x % 4 == r4 and x % 25 == r25:
            return x
q("C22-B-028", T, "Last two digits of a power tower 2^(2^2026)", "Difficult",
  "Multi-step word problem",
  r"What is the number formed by the last two digits of $2^{2^{2026}}$? (Here the exponent is $2^{2026}$.)",
  "TITA",
  r"Let $E = 2^{2026}$. Modulo $4$: $2^E \equiv 0$. Modulo $25$: $\phi(25) = 20$, so we need $E \bmod 20$. Now $E \equiv 0 \pmod 4$, and modulo $5$, $2^4 \equiv 1$ with $2026 \equiv 2 \pmod 4$, so $E \equiv 4 \pmod 5$; hence $E \equiv 4 \pmod{20}$ and $2^E \equiv 2^4 = 16 \pmod{25}$. Since $16$ is also $\equiv 0 \pmod 4$, the last two digits are $16$.",
  "Reducing the exponent modulo $25$ instead of $20$, or assuming it is a multiple of $20$.",
  "C22B-power-tower", "Three layers: exponent modulo $20$ by CRT, Euler modulo $25$, then CRT modulo $100$.",
  tita_answer=16, check=_d2,
  tita_traps=[(84, "Reduces $E$ modulo $25$ instead of $20$: $E \\equiv 14$, and $2^{14} = 16384$ ends in $84$."),
              (76, "Assumes $E$ is a multiple of $20$ and uses the fact that $2^{20k}$ ends in $76$.")],
  cognitive="Analysis", exams=HARD)


def _d3():
    k = 1
    while int("1" * k) % 63 != 0:
        k += 1
    return k
q("C22-B-029", T, "Least repunit divisible by 63 using the order of 10 modulo 7", "Difficult",
  "Inverse/parameter",
  r"A number is written using only the digit $1$, such as $11$, $111$ or $1111$. What is the least number of digits such a number can have if it is divisible by $63$?",
  "MCQ",
  r"The $k$-digit number is $R_k = \frac{10^k - 1}{9}$, and $63 = 9 \times 7$. Divisibility by $9$ needs the digit sum $k$ to be a multiple of $9$. Since $\gcd(7, 9) = 1$, $7 \mid R_k$ exactly when $10^k \equiv 1 \pmod 7$; the order of $10$ modulo $7$ is $6$ ($10^3 \equiv -1$), so $6 \mid k$. The least $k$ is $\operatorname{lcm}(9, 6) = 18$.",
  r"Requiring $63 \mid 10^k - 1$ instead of $63 \mid \frac{10^k - 1}{9}$.",
  "C22B-repunit-order", "Two separate conditions, one hidden by the factor $9$ in the repunit formula.",
  correct=r"$18$",
  distractors=[(r"$6$", "Solves $10^k \\equiv 1 \\pmod{63}$, forgetting that $R_k$ is $\\frac{10^k - 1}{9}$."),
               (r"$9$", "Checks only divisibility by $9$ (digit sum)."),
               (r"$54$", "Multiplies the two conditions $9 \\times 6$ instead of taking their lcm.")],
  check=_d3, values=[18, 6, 9, 54], cognitive="Analysis", exams=HARD)


def _d4():
    pairs = set()
    for N in range(180):
        pairs.add((N % 12, N % 15))
    return len(pairs)
q("C22-B-030", T, "Solvability of a CRT system with non-coprime moduli", "Difficult",
  "Casework/optimisation",
  r"Integers $a$ and $b$ are chosen with $0 \le a \le 11$ and $0 \le b \le 14$. For how many of the $180$ ordered pairs $(a, b)$ does there exist an integer $N$ that leaves remainder $a$ when divided by $12$ and remainder $b$ when divided by $15$?",
  "TITA",
  r"Since $\gcd(12, 15) = 3$, any such $N$ forces $a \equiv N \equiv b \pmod 3$, and conversely this condition makes the system solvable (with a unique solution modulo $\operatorname{lcm}(12, 15) = 60$). For each $a$, exactly $5$ of the $15$ values of $b$ share its residue modulo $3$, giving $12 \times 5 = 60$ pairs. Equivalently, the $60$ residues modulo $60$ give $60$ distinct pairs.",
  "Applying the Chinese remainder theorem as if $12$ and $15$ were coprime.",
  "C22B-crt-compatibility", "Needs the compatibility condition for non-coprime moduli and a count.",
  tita_answer=60, check=_d4,
  tita_traps=[(180, "Assumes every pair is solvable, as if the moduli were coprime."),
              (12, "Believes $N \\bmod 12$ fixes $N \\bmod 15$, allowing one $b$ per $a$.")],
  cognitive="Analysis", exams=HARD)


def _d5():
    for x in range(1001):
        if (x - 2 ** 2026) % 1001 == 0:
            return x
q("C22-B-031", T, "Large power modulo 1001 by Fermat on 7, 11, 13 and CRT", "Difficult",
  "Multi-step word problem",
  r"What is the remainder when $2^{2026}$ is divided by $1001$?",
  "MCQ",
  r"$1001 = 7 \cdot 11 \cdot 13$. Modulo $7$: $2^3 \equiv 1$, $2026 \equiv 1 \pmod 3$, so $2$. Modulo $11$: $2^{10} \equiv 1$, $2026 \equiv 6$, so $64 \equiv 9$. Modulo $13$: $2^{12} \equiv 1$, $2026 \equiv 10$, so $1024 \equiv 10$. Combine $x = 10 + 13t \equiv 9 \pmod{11}$: $10 + 2t \equiv 9$, $t \equiv 5$, $x \equiv 75 \pmod{143}$. Then $75 + 143s \equiv 2 \pmod 7$: $5 + 3s \equiv 2$, $s \equiv 6$, so $x = 75 + 858 = 933$.",
  "Treating $1001$ as prime, or reducing an exponent modulo $p$ instead of $p - 1$.",
  "C22B-crt-split-modulus", "Three Fermat reductions and two CRT combinations.",
  correct=r"$933$",
  distractors=[(r"$163$", "Modulo $13$ reduces the exponent modulo $13$: $2^{11} \\equiv 7$, then combines $2, 9, 7$."),
               (r"$114$", "Modulo $11$ reduces the exponent modulo $11$: $2^{2} \\equiv 4$, then combines $2, 4, 10$."),
               (r"$823$", "Treats $1001$ as prime, uses $2^{1000} \\equiv 1$ and computes $2^{26} \\equiv 823 \\pmod{1001}$.")],
  check=_d5, values=[933, 163, 114, 823], cognitive="Application", exams=HARD)


def _d6():
    return math.factorial(51) ** 2 % 103
q("C22-B-032", T, "Square of the half factorial modulo a prime 3 mod 4", "Difficult",
  "Conceptual/application",
  r"What is the remainder when $(51!)^2$ is divided by $103$? ($103$ is prime.)",
  "TITA",
  r"Wilson's theorem gives $102! \equiv -1 \pmod{103}$. Pair each $k$ from $1$ to $51$ with $103 - k$: $k(103 - k) \equiv -k^2$. So $102! \equiv (-1)^{51} (51!)^2 = -(51!)^2$. Hence $-(51!)^2 \equiv -1$, and $(51!)^2 \equiv 1 \pmod{103}$. The remainder is $1$.",
  "Dropping the factor $(-1)^{51}$ from the pairing.",
  "C22B-wilson-half-factorial", "Non-obvious pairing argument built on Wilson's theorem with a sign trap.",
  tita_answer=1, check=_d6,
  tita_traps=[(102, "Pairs $k$ with $103 - k$ as $k^2$, dropping the sign, so gets $(51!)^2 \\equiv -1$."),
              (0, "Assumes the large factorial is divisible by $103$.")],
  cognitive="Analysis", exams=HARD)


def _d7():
    return sum(1 for n in range(1, 101) if (2 ** n + 3 ** n) % 7 == 0)
q("C22-B-033", T, "Exponents n for which 7 divides 2^n + 3^n", "Difficult",
  "Casework/optimisation",
  r"For how many integers $n$ with $1 \le n \le 100$ is $2^n + 3^n$ divisible by $7$?",
  "MCQ",
  r"Modulo $7$, $2$ has order $3$ and $3$ has order $6$, so $2^n + 3^n \bmod 7$ repeats with period $6$. For $n = 1, \ldots, 6$ the values are $5, 13, 35, 97, 275, 793$, with remainders $5, 6, 0, 6, 2, 2$. So $7 \mid 2^n + 3^n$ exactly when $n \equiv 3 \pmod 6$: $n = 3, 9, \ldots, 99$, which is $\frac{99 - 3}{6} + 1 = 17$ values.",
  "Using the wrong period, or an off-by-one in counting an arithmetic progression.",
  "C22B-order-of-element", "Combining two different orders into one period and testing a full cycle.",
  correct=r"$17$",
  distractors=[(r"$16$", "Counts $\\frac{99 - 3}{6} = 16$ without adding the first term."),
               (r"$33$", "Uses the period $3$ of $2$ alone and takes every multiple of $3$."),
               (r"$25$", "Uses the last-digit period $4$ and takes $n \\equiv 3 \\pmod 4$.")],
  check=_d7, values=[17, 16, 33, 25], cognitive="Analysis", exams=HARD)


def _d8():
    return sum(1 for x in range(1, 1001) if (x * x - 1) % 105 == 0)
q("C22-B-034", T, "Counting square roots of 1 modulo 105 in a range via CRT", "Difficult",
  "Casework/optimisation",
  r"For how many integers $x$ with $1 \le x \le 1000$ does $x^2$ leave remainder $1$ when divided by $105$?",
  "TITA",
  r"$105 = 3 \cdot 5 \cdot 7$, and modulo a prime $p$, $x^2 \equiv 1$ means $x \equiv \pm 1$. By the Chinese remainder theorem there are $2^3 = 8$ residues modulo $105$: $1, 29, 34, 41, 64, 71, 76, 104$. The range $1$ to $945$ is $9$ full periods, giving $72$. The remaining numbers $946$ to $1000$ have residues $1$ to $55$, which contain $1, 29, 34, 41$: $4$ more. Total $76$.",
  r"Thinking $x \equiv \pm 1$ are the only roots, or counting the partial period wrongly.",
  "C22B-crt-root-count", "CRT count of roots plus listing them to handle a partial period.",
  tita_answer=76, check=_d8,
  tita_traps=[(80, "Counts $10$ full periods, as if $1000$ were a multiple of $105$."),
              (19, "Takes only $x \\equiv \\pm 1 \\pmod{105}$, giving $10 + 9$ values.")],
  cognitive="Analysis", exams=HARD)


def _d9():
    return math.factorial(99) % 103
q("C22-B-035", T, "Wilson's theorem for (p-4)! requiring a modular inverse", "Difficult",
  "Multi-step word problem",
  r"What is the remainder when $99!$ is divided by $103$? ($103$ is prime.)",
  "MCQ",
  r"By Wilson, $102! \equiv -1 \pmod{103}$. Also $102! = 99! \cdot 100 \cdot 101 \cdot 102 \equiv 99! \cdot (-3)(-2)(-1) = -6 \cdot 99!$. So $-6 \cdot 99! \equiv -1$, that is $6 \cdot 99! \equiv 1$, and $99! \equiv 6^{-1}$. Since $6 \times 86 = 516 = 5 \times 103 + 1$, $99! \equiv 86$.",
  "Multiplying by the removed factors instead of dividing, or a sign slip.",
  "C22B-wilson-near-prime", "Wilson's theorem, three negative residues and a modular inverse.",
  correct=r"$86$",
  distractors=[(r"$6$", "Multiplies instead of dividing: $99! \\equiv (-1)(-6) = 6$."),
               (r"$17$", "Loses one sign and solves $6 \\cdot 99! \\equiv -1$, giving $-86 \\equiv 17$."),
               (r"$102$", "Applies Wilson's theorem to $99!$ directly.")],
  check=_d9, values=[86, 6, 17, 102], cognitive="Analysis", exams=HARD)
