import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

CX = ("CAT", "XAT")
TOPIC = "Multiple transactions and optimisation"


# ================================================================= EASY (12)

def _c1():
    kg, cp = 200, Fraction(60)
    lots = [(120, Fraction(25, 100)), (50, Fraction(10, 100)), (30, Fraction(-20, 100))]
    assert sum(q for q, _ in lots) == kg
    rev = sum(q * cp * (1 + r) for q, r in lots)
    return (rev - kg * cp) / (kg * cp) * 100
q("C02-D-001", TOPIC, "Overall profit percent when one stock is sold in three lots at different rates", "Easy",
  "Multi-step word problem",
  r"A fruit seller buys $200$ kg of mangoes at Rs. $60$ per kg. He sells $120$ kg at a profit of $25\%$, then $50$ kg at a profit of $10\%$, and the remaining mangoes at a loss of $20\%$. His overall profit percentage on the whole purchase is",
  "MCQ",
  r"Total cost is $200 \times 60 = 12{,}000$. Profit on the lots: $120 \times 15 = 1{,}800$, $50 \times 6 = 300$, and a loss of $30 \times 12 = 360$. Net profit $= 1{,}800 + 300 - 360 = 1{,}740$, which is $\frac{1{,}740}{12{,}000} = 14.5\%$.",
  "Averaging the three percentages without weighting them by the quantity in each lot.",
  "C02D-lots-weighted-overall-percent", "One idea (weight each rate by its lot) with a sign trap on the loss lot.",
  correct=r"$14.5\%$",
  distractors=[(r"$5.0\%$", r"Takes the plain average $\frac{25 + 10 - 20}{3} = 5\%$, ignoring lot sizes."),
               (r"$17.5\%$", r"Leaves out the third lot altogether: $\frac{1{,}800 + 300}{12{,}000} = 17.5\%$."),
               (r"$20.5\%$", r"Adds the Rs. $360$ loss as if it were profit: $\frac{2{,}460}{12{,}000} = 20.5\%$.")],
  check=_c1, values=[Fraction(29, 2), 5, Fraction(35, 2), Fraction(41, 2)], cognitive="Application")


def _c2():
    costs = [5, 4, 1]  # lakh
    rates = [Fraction(40, 100), Fraction(15, 100), Fraction(-10, 100)]
    profit = sum(c * r for c, r in zip(costs, rates))
    return profit / sum(costs) * 100
q("C02-D-002", TOPIC, "Overall profit percent on three items of different cost sold at different rates", "Easy",
  "Multi-step word problem",
  r"A used-car dealer buys three cars for Rs. $5$ lakh, Rs. $4$ lakh and Rs. $1$ lakh. He sells the first at a profit of $40\%$, the second at a profit of $15\%$ and the third at a loss of $10\%$. What is his overall profit percentage on the three cars?",
  "MCQ",
  r"Profits are $40\%$ of $5 = 2$ lakh, $15\%$ of $4 = 0.6$ lakh, and a loss of $10\%$ of $1 = 0.1$ lakh. Net profit $= 2 + 0.6 - 0.1 = 2.5$ lakh on a cost of $10$ lakh, that is $25\%$.",
  "Averaging the percentages instead of weighting each by its cost price.",
  "C02D-lots-weighted-overall-percent", "Single weighting step; traps are the unweighted average and the selling-price base.",
  correct=r"$25\%$",
  distractors=[(r"$15\%$", r"Plain average of the three rates: $\frac{40 + 15 - 10}{3} = 15\%$."),
               (r"$20\%$", "Divides the profit of $2.5$ lakh by the total selling price of $12.5$ lakh."),
               (r"$27\%$", r"Treats the $0.1$ lakh loss as a profit: $\frac{2.7}{10} = 27\%$.")],
  check=_c2, values=[25, 15, 20, 27], cognitive="Application")


def _c3():
    x = symbols('x')
    n, c = 80, 1500
    eq = Eq(50 * c * Rational(12, 100) + 30 * c * x / 100, Rational(15, 100) * n * c)
    return solve(eq, x)[0]
q("C02-D-003", TOPIC, "Profit rate needed on the unsold part of a lot to reach a target overall profit", "Easy",
  "Inverse/parameter",
  r"Priya buys $80$ chairs at Rs. $1{,}500$ each. She sells $50$ of them at a profit of $12\%$. At what profit percentage must she sell the remaining $30$ chairs so that her overall profit on all $80$ chairs is $15\%$? (Type the answer as a percentage.)",
  "TITA",
  r"Target profit $= 15\%$ of $80 \times 1{,}500 = 18{,}000$. Profit already earned $= 50 \times 180 = 9{,}000$. The remaining $30$ chairs (cost $45{,}000$) must earn $9{,}000$, which is $\frac{9{,}000}{45{,}000} = 20\%$.",
  "Averaging the two rates as if both parts had the same cost.",
  "C02D-lots-required-rate-remainder", "One balancing step on rupee profits; the trap is an unweighted average.",
  tita_answer=20, check=_c3,
  tita_traps=[(18, r"Solves $\frac{12 + x}{2} = 15$, treating the two parts as equal in size."),
              (3, "Types the gap $15 - 12$ between the target and the rate on the first part.")],
  cognitive="Application")


def _c4():
    eggs, c = 500, Fraction(6)
    good = eggs - eggs * Fraction(10, 100)
    return eggs * c * Fraction(120, 100) / good
q("C02-D-004", TOPIC, "Selling price per item when part of the stock is spoiled and a target profit is set", "Easy",
  "Multi-step word problem",
  r"A grocer buys $500$ eggs at Rs. $6$ each. On the way to the shop, $10\%$ of the eggs break and are thrown away. At what price per egg must he sell the remaining eggs to make an overall profit of $20\%$ on the whole purchase?",
  "MCQ",
  r"Cost $= 500 \times 6 = 3{,}000$, so the target revenue is $1.2 \times 3{,}000 = 3{,}600$. Only $450$ eggs are left, so each must sell for $\frac{3{,}600}{450} = $ Rs. $8$.",
  "Pricing for the target profit on cost per egg without spreading the cost of the broken eggs over the good ones.",
  "C02D-spoilage-price-for-target", "Single idea: the whole cost must be recovered from the unbroken eggs.",
  correct=r"Rs. $8.00$",
  distractors=[(r"Rs. $7.20$", r"Ignores the breakage: $6 \times 1.2 = 7.20$."),
               (r"Rs. $7.80$", r"Adds the two percentages: $6 \times 1.3 = 7.80$."),
               (r"Rs. $7.92$", r"Raises the price by $20\%$ and then by $10\%$: $6 \times 1.2 \times 1.1 = 7.92$.")],
  check=_c4, values=[8, Fraction(36, 5), Fraction(39, 5), Fraction(198, 25)], cognitive="Application")


def _c5():
    ravi = 0
    cost = 40000
    ravi -= cost
    to_meera = cost * Fraction(115, 100); ravi += to_meera
    back = to_meera * Fraction(90, 100); ravi -= back
    ravi += 44000
    return ravi
q("C02-D-005", TOPIC, "Net profit of a person who sells, buys back and resells the same scooter", "Easy",
  "Multi-step word problem",
  r"Ravi buys a scooter for Rs. $40{,}000$ and sells it to Meera at a profit of $15\%$. Some months later Meera sells it back to Ravi at a loss of $10\%$ on her cost. Ravi finally sells the scooter to Kabir for Rs. $44{,}000$. What is Ravi's total profit from all his dealings in this scooter?",
  "MCQ",
  r"Ravi sells to Meera for $1.15 \times 40{,}000 = 46{,}000$ and buys back for $0.9 \times 46{,}000 = 41{,}400$. Profit on the first round is $46{,}000 - 40{,}000 = 6{,}000$ and on the second round $44{,}000 - 41{,}400 = 2{,}600$. Total profit is Rs. $8{,}600$.",
  "Comparing only the first purchase price with the last sale price and ignoring the buy-back.",
  "C02D-buy-sell-back-chain", "Two short rounds of cash flow; the trap is skipping the middle transactions.",
  correct=r"Rs. $8{,}600$",
  distractors=[(r"Rs. $4{,}000$", "Uses only the first purchase and the final sale: $44{,}000 - 40{,}000$."),
               (r"Rs. $6{,}000$", "Counts only the profit on the sale to Meera."),
               (r"Rs. $2{,}600$", "Counts only the profit on the final sale to Kabir, measured from the buy-back price.")],
  check=_c5, values=[8600, 4000, 6000, 2600], cognitive="Application")


def _c6():
    M = Fraction(600)  # any equal amount
    c1, c2, p = Fraction(3, 2), Fraction(5, 2), Fraction(12, 5)
    n = M / c1 + M / c2
    return (n * p - 2 * M) / (2 * M) * 100
q("C02-D-006", TOPIC, "Equal money spent on two lots bought at different rates, all sold at one rate", "Easy",
  "Conceptual/application",
  r"A vendor spends equal amounts of money on two lots of oranges. The first lot is bought at $2$ for Rs. $3$ and the second at $2$ for Rs. $5$. He sells all the oranges at $5$ for Rs. $12$. His overall profit percentage is",
  "MCQ",
  r"Each orange sells for Rs. $2.40$, which is a $60\%$ profit on the first lot (cost Rs. $1.50$) and a $4\%$ loss on the second (cost Rs. $2.50$). Because the money invested in the two lots is equal, the overall percentage is the plain average of the two: $\frac{60 - 4}{2} = 28\%$. (Check with Rs. $600$ in each lot: $400 + 240 = 640$ oranges fetch Rs. $1{,}536$ against a cost of Rs. $1{,}200$, a profit of $28\%$.)",
  "Assuming equal numbers of oranges in the two lots when the money, not the number, is equal.",
  "C02D-mixed-lots-unit-rates", "One insight: equal investment makes the rupee-weighted average a plain average.",
  correct=r"$28\%$",
  distractors=[(r"$20\%$", r"Assumes equal numbers of oranges, so the average cost is Rs. $2$ and the profit is $\frac{0.4}{2} = 20\%$."),
               (r"$60\%$", "Computes the profit on the cheaper lot only."),
               (r"$56\%$", "Divides the total profit by the money spent on just one lot.")],
  check=_c6, values=[28, 20, 60, 56], cognitive="Understanding")


def _c7():
    c = symbols('c', positive=True)
    return solve(Eq(c * Rational(120, 100) - c * Rational(108, 100), 132), c)[0]
q("C02-D-007", TOPIC, "Cost price from two selling scenarios differing by a fixed amount", "Easy",
  "Inverse/parameter",
  r"Sneha sells a bookshelf at a profit of $8\%$. Had she sold it for Rs. $132$ more, her profit would have been $20\%$. What is the cost price of the bookshelf in rupees?",
  "TITA",
  r"The extra Rs. $132$ raises the profit from $8\%$ to $20\%$, so $12\%$ of the cost price is Rs. $132$. The cost price is $\frac{132}{0.12} = 1{,}100$ rupees.",
  "Dividing the extra amount by one of the profit rates instead of by their difference.",
  "C02D-two-scenarios-price-change", "One step: the price difference equals the difference in profit percent of the cost.",
  tita_answer=1100, check=_c7,
  tita_traps=[(660, "Divides $132$ by $0.20$, the new profit rate."),
              (1650, "Divides $132$ by $0.08$, the original profit rate.")],
  cognitive="Application")


def _c8():
    bundle, cost, mon_cap, mon_p, tue_cap, tue_p = 25, 20, 110, 40, 30, 30
    best = None
    for b in range(0, 21):
        n = b * bundle
        mon = min(n, mon_cap)
        left = n - mon
        fresh = left - left * Fraction(20, 100)
        tue = min(fresh, tue_cap)
        prof = mon * mon_p + tue * tue_p - n * cost
        best = prof if best is None or prof > best else best
    return best
q("C02-D-008", TOPIC, "Best number of bundles to buy when leftovers partly wilt and sell next day at a lower price", "Difficult",
  "Casework/optimisation",
  r"Meera, a florist, can buy roses only in bundles of $25$, at Rs. $20$ per rose, on Monday morning. On Monday she can sell at most $110$ roses, at Rs. $40$ each, and she sells as many as she can. Roses unsold on Monday are kept overnight; $20\%$ of them wilt and are thrown away, and on Tuesday she can sell at most $30$ of the rest, at Rs. $30$ each. Any roses still left are thrown away. If she buys the number of bundles that gives her the greatest total profit, what is that profit?",
  "MCQ",
  r"With $4$ bundles ($100$ roses) the profit is $100 \times 20 = 2{,}000$. With $5$ bundles, $15$ are left on Monday, $12$ survive and sell on Tuesday: $4{,}400 + 360 - 2{,}500 = 2{,}260$. With $6$ bundles, $40$ are left, $32$ survive and $30$ sell: $4{,}400 + 900 - 3{,}000 = 2{,}300$. With $7$ bundles Tuesday sales are still capped at $30$: $4{,}400 + 900 - 3{,}500 = 1{,}800$, and more bundles do worse. The greatest profit is Rs. $2{,}300$.",
  "Stopping at the smallest order that covers Monday's demand, or forgetting that a fifth of the leftover roses wilt.",
  "C02D-order-quantity-salvage", "Casework over bundle sizes across two days, with a wilting loss and a second-day cap; the order that just covers Monday is not optimal.",
  correct=r"Rs. $2{,}300$",
  distractors=[(r"Rs. $2{,}260$", "Buys $5$ bundles, the smallest order that covers Monday's demand, and stops there."),
               (r"Rs. $2{,}350$", r"Forgets the wilting, so $5$ bundles seem best: $4{,}400 + 15 \times 30 - 2{,}500$."),
               (r"Rs. $2{,}000$", "Buys only $4$ bundles so as never to carry roses overnight.")],
  check=_c8, values=[2300, 2260, 2350, 2000], cognitive="Analysis", exams=CX)


def _c9():
    n = symbols('n', positive=True)
    nn = solve(Eq(520 * n - 1600, 450 * n + 1200), n)[0]   # both equal total cost
    total_cost = 450 * nn + 1200
    return total_cost / nn
q("C02-D-009", TOPIC, "Cost per item from a loss at one price and a profit at another price for a whole lot", "Easy",
  "Inverse/parameter",
  r"Kabir has a lot of identical shirts. If he sells every shirt at Rs. $450$, he makes a total loss of Rs. $1{,}200$ on the lot. If he sells every shirt at Rs. $520$, he makes a total profit of Rs. $1{,}600$. What is the cost price of one shirt in rupees?",
  "TITA",
  r"Raising the price by Rs. $70$ per shirt changes the result by $1{,}200 + 1{,}600 = 2{,}800$, so there are $\frac{2{,}800}{70} = 40$ shirts. The lot cost $40 \times 450 + 1{,}200 = 19{,}200$, which is Rs. $480$ per shirt.",
  "Taking the midpoint of the two prices as the cost, as if the profit and the loss were equal.",
  "C02D-two-prices-lot-gain-loss", "Two short steps: the swing gives the count, then the cost follows.",
  tita_answer=480, check=_c9,
  tita_traps=[(485, "Takes the midpoint of Rs. $450$ and Rs. $520$ as the cost."),
              (40, "Stops after finding the number of shirts.")],
  cognitive="Application")


def _c10():
    N = 100
    C = Fraction(1)
    p = N * C / 80          # 80 bags recover the full cost
    return (N * p - N * C) / (N * C) * 100
q("C02-D-010", TOPIC, "Profit percent when part of the stock recovers the entire cost", "Easy",
  "Conceptual/application",
  r"A trader buys $100$ identical bags of rice. After selling $80$ of them at a fixed price per bag, he has recovered exactly the total cost of all $100$ bags. He then sells the remaining $20$ bags at the same price. What is his overall profit percentage? (Type the answer as a percentage.)",
  "TITA",
  r"The $80$ bags bring in the cost of $100$ bags, so the price of one bag equals the cost of $\frac{100}{80}$ bags. Selling all $100$ bags brings in the cost of $125$ bags, a profit of $25\%$. Equivalently, the revenue from the last $20$ bags is pure profit, and it is $\frac{20}{80}$ of the revenue from the first $80$ bags, which equals the total cost: $25\%$.",
  "Measuring the profit of $20$ bags against all $100$ bags instead of against the $80$ bags whose revenue equals the cost.",
  "C02D-cost-recovered-part-stock", "One insight: profit is the leftover stock measured against the stock that paid for everything.",
  tita_answer=25, check=_c10,
  tita_traps=[(20, "Divides the $20$ leftover bags by $100$."),
              (80, "Types the number of bags needed to recover the cost.")],
  cognitive="Understanding")


def _c11():
    p0, c, q0 = 50, 40, 400
    before = (p0 - c) * q0
    after = (p0 * Fraction(90, 100) - c) * q0 * Fraction(150, 100)
    return (after - before) / before * 100
q("C02-D-011", TOPIC, "Effect on profit of a price cut that raises sales volume", "Easy",
  "Conceptual/application",
  r"A shop sells $400$ units of a product each week at Rs. $50$ per unit. Each unit costs the shop Rs. $40$. The owner cuts the price by $10\%$, and weekly sales rise by $50\%$. The unit cost does not change. As a result, the weekly profit",
  "MCQ",
  r"Profit before $= (50 - 40) \times 400 = 4{,}000$. After the cut, the price is Rs. $45$ and sales are $600$, so profit $= 5 \times 600 = 3{,}000$. The profit decreases by $\frac{1{,}000}{4{,}000} = 25\%$.",
  "Judging the change by revenue or by the percentage changes in price and volume rather than by the margin per unit.",
  "C02D-price-cut-volume-tradeoff", "One idea: a small price cut halves the margin; volume must be weighed against margin.",
  correct=r"decreases by $25\%$",
  distractors=[(r"increases by $35\%$", r"Tracks revenue: $0.9 \times 1.5 = 1.35$."),
               (r"increases by $40\%$", "Adds the percentage changes: $-10 + 50$."),
               (r"decreases by $50\%$", "Sees the margin halve from Rs. $10$ to Rs. $5$ and ignores the higher volume.")],
  check=_c11, values=[-25, 35, 40, -50], cognitive="Understanding")


def _c12():
    x = symbols('x', positive=True)
    total, c = 300, 40
    return solve(Eq(x * c * Rational(25, 100) - (total - x) * c * Rational(10, 100), total * c * Rational(11, 100)), x)[0]
q("C02-D-012", TOPIC, "Splitting a lot between a profit rate and a loss rate to hit an overall rate", "Easy",
  "Inverse/parameter",
  r"Harpreet buys $300$ kg of wheat at Rs. $40$ per kg. She sells part of it at a profit of $25\%$ and the rest at a loss of $10\%$. Her overall profit on the $300$ kg is $11\%$. How much wheat did she sell at a profit?",
  "MCQ",
  r"Let $x$ kg be sold at $25\%$ profit. Working in percentage points per kg: $25x - 10(300 - x) = 11 \times 300$, so $35x = 6{,}300$ and $x = 180$ kg. (By alligation the two parts are in the ratio $(11 + 10) : (25 - 11) = 3 : 2$.)",
  "Reversing the alligation ratio, or ignoring the loss on the second part.",
  "C02D-alligation-split-of-lot", "Single linear equation (or one alligation) with a reversal trap.",
  correct=r"$180$ kg",
  distractors=[(r"$120$ kg", "Reverses the alligation ratio and reports the quantity sold at a loss."),
               (r"$150$ kg", "Assumes the stock was split equally."),
               (r"$132$ kg", r"Ignores the loss on the rest: $0.25x = 0.11 \times 300$.")],
  check=_c12, values=[180, 120, 150, 132], cognitive="Application")


# ================================================================= MEDIUM (18)

def _c13():
    x = symbols('x')
    return solve(Eq(Rational(40, 100) * 25 + Rational(30, 100) * (-10) + Rational(30, 100) * x, 13), x)[0]
q("C02-D-013", TOPIC, "Rate needed on the last part of a stock after one profitable and one loss-making part", "Medium",
  "Inverse/parameter",
  r"A wholesaler sells $40\%$ of his stock of rice at a profit of $25\%$ and another $30\%$ of the stock at a loss of $10\%$. The whole stock was bought at one price per kg. At what profit percentage must he sell the rest of the stock so that his overall profit is $13\%$?",
  "MCQ",
  r"Weight each rate by its share of the cost: $0.4 \times 25 + 0.3 \times (-10) + 0.3x = 13$. This gives $10 - 3 + 0.3x = 13$, so $0.3x = 6$ and $x = 20\%$.",
  r"Averaging the three rates equally, or forgetting that the last part is only $30\%$ of the stock.",
  "C02D-lots-required-rate-remainder", "Three parts with a negative rate; the weighting and the final division are both traps.",
  correct=r"$20\%$",
  distractors=[(r"$24\%$", r"Solves $\frac{25 - 10 + x}{3} = 13$, ignoring the shares."),
               (r"$6\%$", r"Finds $13 - 7 = 6$ but does not divide by the $30\%$ share."),
               (r"$13\%$", "Assumes the rest should simply be sold at the target rate.")],
  check=_c13, values=[20, 24, 6, 13], cognitive="Application")


def _c14():
    n, c = 120, 300
    target = n * c * Fraction(118, 100)
    got = 45 * 360 + 30 * 360 * Fraction(90, 100)
    rest = n - 45 - 30
    p = 0
    while got + rest * p < target:   # smallest whole-rupee price
        p += 1
    return p
q("C02-D-014", TOPIC, "Minimum price for the last part of a lot after two earlier sales", "Medium",
  "Inverse/parameter",
  r"Ananya buys $120$ identical lamps at Rs. $300$ each. She sells $45$ lamps at Rs. $360$ each. She then sells $30$ more lamps at a price $10\%$ lower than Rs. $360$. What is the lowest price per lamp, in rupees, at which she must sell the remaining lamps so that her overall profit on all $120$ lamps is at least $18\%$?",
  "TITA",
  r"Required revenue $= 1.18 \times 120 \times 300 = 42{,}480$. She has received $45 \times 360 = 16{,}200$ and $30 \times 324 = 9{,}720$, a total of $25{,}920$. The remaining $45$ lamps must bring $42{,}480 - 25{,}920 = 16{,}560$, which is $\frac{16{,}560}{45} = 368$ rupees per lamp.",
  "Forgetting the price reduction on the second batch, or applying the target rate only to the last batch.",
  "C02D-lots-required-rate-remainder", "Three batches and a revenue target; two easy-to-miss adjustments.",
  tita_answer=368, check=_c14,
  tita_traps=[(344, "Treats the second batch as sold at Rs. $360$ too."),
              (354, r"Applies the $18\%$ target only to the last batch: $300 \times 1.18$.")],
  cognitive="Application")


def _c15():
    kg, c = 250, 64
    good = kg - kg * Fraction(20, 100) - 8
    sp = kg * c * Fraction(120, 100) / good
    return sp / Fraction(80, 100)
q("C02-D-015", TOPIC, "Marked price needed after spoilage, free samples and a discount", "Medium",
  "Multi-step word problem",
  r"A vendor buys $250$ kg of grapes at Rs. $64$ per kg. During storage, $20\%$ of the weight is lost to spoilage, and he also gives away $8$ kg as free samples. He sells all the remaining grapes at a discount of $20\%$ on the marked price. If he wants an overall profit of $20\%$ on his purchase, what marked price per kg must he set?",
  "MCQ",
  r"Target revenue $= 1.2 \times 250 \times 64 = 19{,}200$. Saleable grapes $= 250 - 50 - 8 = 192$ kg, so the selling price must be $\frac{19{,}200}{192} = 100$ per kg. The selling price is $80\%$ of the marked price, so the marked price is $\frac{100}{0.8} = $ Rs. $125$ per kg.",
  "Ignoring the free samples or the spoilage when spreading the cost, or forgetting to gross up for the discount.",
  "C02D-spoilage-price-for-target", "Three adjustments in sequence (spoilage, samples, discount) each with its own trap.",
  correct=r"Rs. $125$",
  distractors=[(r"Rs. $120$", r"Ignores the $8$ kg of free samples: $\frac{19{,}200}{200} = 96$ and $\frac{96}{0.8} = 120$."),
               (r"Rs. $96$", r"Ignores both spoilage and samples: $\frac{64 \times 1.2}{0.8} = 96$."),
               (r"Rs. $100$", "Finds the required selling price and forgets the discount.")],
  check=_c15, values=[125, 120, 96, 100], cognitive="Application")


def _c16():
    f = symbols('f')
    cost_each = Rational(80, 12)
    return solve(Eq((1 - f) * 9, Rational(108, 100) * cost_each), f)[0] * 100
q("C02-D-016", TOPIC, "Fraction of stock spoiled, from the selling price and the overall profit", "Medium",
  "Inverse/parameter",
  r"A fruit seller buys apples at Rs. $80$ per dozen. Some of the apples rot and are thrown away, and he sells each of the rest at Rs. $9$. His overall profit on the purchase is $8\%$. What percentage of the apples rotted?",
  "MCQ",
  r"Cost per apple $= \frac{80}{12} = \frac{20}{3}$. If a fraction $f$ rots, revenue per apple bought is $9(1 - f)$, and this must be $1.08 \times \frac{20}{3} = 7.2$. So $1 - f = 0.8$ and $f = 20\%$.",
  "Working with the gap between the markup and the overall profit instead of the ratio of revenues.",
  "C02D-spoilage-find-quantity", "Requires a per-apple revenue equation and a ratio, with several tempting shortcuts.",
  correct=r"$20\%$",
  distractors=[(r"$25\%$", "Measures the shortfall $9 - 7.2 = 1.8$ against Rs. $7.2$ instead of Rs. $9$."),
               (r"$27\%$", r"Subtracts percentages: markup $35\%$ minus profit $8\%$."),
               (r"$80\%$", "Finds $1 - f = 0.8$ and reports that as the rotten share.")],
  check=_c16, values=[20, 25, 27, 80], cognitive="Analysis")


def _c17():
    n, c, sp, comp = 600, 45, 60, 15
    for b in range(0, n + 1):
        if sp * (n - b) + comp * b - n * c == 4500:
            return b
q("C02-D-017", TOPIC, "Number of items broken in transit given the profit, with compensation for each broken item", "Easy",
  "Inverse/parameter",
  r"A crockery dealer buys $600$ glass tumblers at Rs. $45$ each. Some tumblers break in transit. The transporter pays the dealer Rs. $15$ for each broken tumbler, and the dealer sells every unbroken tumbler at Rs. $60$. His overall profit, including the compensation, is Rs. $4{,}500$. How many tumblers broke?",
  "TITA",
  r"If $b$ tumblers broke, receipts are $60(600 - b) + 15b = 36{,}000 - 45b$. Cost is $600 \times 45 = 27{,}000$, so profit $= 9{,}000 - 45b = 4{,}500$, giving $b = 100$.",
  "Leaving out the compensation, which reduces the effect of each broken tumbler from Rs. $60$ to Rs. $45$.",
  "C02D-spoilage-find-quantity", "One linear equation once the two receipts are combined; the single trap is leaving out the compensation.",
  tita_answer=100, check=_c17,
  tita_traps=[(75, "Ignores the compensation: $9{,}000 - 60b = 4{,}500$."),
              (60, "Adds the compensation as a further loss: $9{,}000 - 75b = 4{,}500$.")],
  cognitive="Application")


def _c18():
    best = max(range(30, 101), key=lambda p: (p - 30) * (200 - 4 * (p - 50)))
    return best
q("C02-D-018", TOPIC, "Profit-maximising price when demand falls linearly with price", "Medium",
  "Casework/optimisation",
  r"A shop sells $200$ units of a gadget per day at Rs. $50$ each. Each gadget costs the shop Rs. $30$. Market tests show that every Rs. $1$ increase in price reduces daily sales by $4$ units, and every Rs. $1$ decrease increases daily sales by $4$ units. The price must be a whole number of rupees. At what price, in rupees, is the daily profit the greatest?",
  "TITA",
  r"At price $p$ the daily sales are $200 - 4(p - 50) = 400 - 4p$, so the profit is $(p - 30)(400 - 4p)$. This is zero at $p = 30$ and at $p = 100$, and the parabola peaks midway: $p = \frac{30 + 100}{2} = 65$ rupees, with a profit of $35 \times 140 = 4{,}900$.",
  "Maximising revenue instead of profit, which ignores the unit cost.",
  "C02D-price-demand-max-profit", "Requires building the demand line and using the symmetry of a quadratic.",
  tita_answer=65, check=_c18,
  tita_traps=[(50, "Maximises revenue $p(400 - 4p)$ instead of profit."),
              (100, "Gives the price at which sales fall to zero.")],
  cognitive="Analysis")


def _c19():
    k = 0
    cash = 0
    cash -= 50000
    p1 = 50000 * Fraction(120, 100); cash += p1
    p2 = p1 * Fraction(75, 100); cash -= p2
    p3 = p2 * Fraction(120, 100); cash += p3
    return cash
q("C02-D-019", TOPIC, "Total profit over three sales of the same painting between two people", "Medium",
  "Multi-step word problem",
  r"Kabir buys a painting for Rs. $50{,}000$ and sells it to Fatima at a profit of $20\%$. Fatima later sells it back to Kabir at a loss of $25\%$ on her cost. Kabir then sells it to Fatima again at a profit of $20\%$ on his new cost. Kabir no longer owns the painting. What is Kabir's total profit from these dealings, in rupees?",
  "TITA",
  r"Kabir sells for $60{,}000$ (profit $10{,}000$), buys back for $0.75 \times 60{,}000 = 45{,}000$, and sells again for $1.2 \times 45{,}000 = 54{,}000$ (profit $9{,}000$). Total profit $= 10{,}000 + 9{,}000 = 19{,}000$ rupees. Equivalently, net cash $= -50{,}000 + 60{,}000 - 45{,}000 + 54{,}000 = 19{,}000$.",
  "Comparing only the first buying price with the last selling price.",
  "C02D-buy-sell-back-chain", "Four cash flows with percentages on changing bases.",
  tita_answer=19000, check=_c19,
  tita_traps=[(4000, "Uses only the first purchase and the final sale: $54{,}000 - 50{,}000$."),
              (10000, "Counts only the first sale.")],
  cognitive="Application")


def _c20():
    p = symbols('p', positive=True)
    C = 10000
    sol = solve(Eq(C * (1 + p) - C * (1 + p) * (1 - p), 2400), p)
    return [s for s in sol if s > 0][0] * 100
q("C02-D-020", TOPIC, "Common rate from the net cash gain on a sell and buy-back pair", "Medium",
  "Inverse/parameter",
  r"Joseph owns a machine that cost him Rs. $10{,}000$. He sells it to Meera at a profit of $p\%$. Meera later sells it back to Joseph at a loss of $p\%$ on her cost. After these two deals Joseph has the machine again and Rs. $2{,}400$ more cash than he had just before selling it to Meera. The value of $p$ is",
  "MCQ",
  r"Joseph receives $10{,}000(1 + r)$ and pays back $10{,}000(1 + r)(1 - r)$, where $r = \frac{p}{100}$. The difference is $10{,}000\,r(1 + r) = 2{,}400$, so $r^2 + r - 0.24 = 0$, giving $(r - 0.2)(r + 1.2) = 0$ and $r = 0.2$. Hence $p = 20$.",
  r"Taking the buy-back price as $p\%$ below Joseph's original cost instead of $p\%$ below Meera's own purchase price.",
  "C02D-buy-sell-back-chain", "Needs a quadratic in the rate and the correct base for the second percentage.",
  correct=r"$20$",
  distractors=[(r"$24$", r"Sets $r = 0.24$, treating Joseph's gain as simply $p\%$ of his cost."),
               (r"$12$", r"Takes the buy-back price as $p\%$ below Joseph's original cost, $10{,}000(1 - r)$, so the gain is $20{,}000r = 2{,}400$."),
               (r"$25$", "Divides the gain of Rs. $2{,}400$ by the buy-back price of Rs. $9{,}600$.")],
  check=_c20, values=[20, 24, 12, 25], cognitive="Analysis")


def _c21():
    s, c = symbols('s c', positive=True)
    sol = solve([Eq(10 * (s - c), 50), Eq(16 * (Rational(9, 10) * s - c), 32)], [s, c], dict=True)[0]
    return sol[c]
q("C02-D-021", TOPIC, "Cost per item from profits on two sales of different sizes at different prices", "Medium",
  "Inverse/parameter",
  r"A shopkeeper sells $10$ notebooks at a certain price each and makes a total profit of Rs. $50$. On another day he sells $16$ notebooks of the same kind at a price $10\%$ lower than before and makes a total profit of Rs. $32$. The cost price of each notebook is unchanged. What is the cost price of one notebook?",
  "MCQ",
  r"Let the first price be $s$ and the cost $c$. Then $s - c = 5$ and $0.9s - c = \frac{32}{16} = 2$. Subtracting, $0.1s = 3$, so $s = 30$ and $c = $ Rs. $25$.",
  "Dividing the second day's profit by the wrong number of notebooks.",
  "C02D-two-scenarios-price-change", "Two equations from per-item profits; the second needs the right count.",
  correct=r"Rs. $25$",
  distractors=[(r"Rs. $30$", "Reports the original selling price."),
               (r"Rs. $13$", r"Uses $\frac{32}{10}$ as the second per-item profit, so $0.1s = 1.8$, $s = 18$, $c = 13$."),
               (r"Rs. $27$", r"Reports the reduced selling price $0.9 \times 30$.")],
  check=_c21, values=[25, 30, 13, 27], cognitive="Application")


def _c22():
    x = symbols('x', positive=True)
    s = Rational(120, 100) * x
    return solve(Eq(s - 30, Rational(125, 100) * Rational(90, 100) * x), x)[0]
q("C02-D-022", TOPIC, "Cost price when a cheaper purchase and a lower sale would raise the profit percent", "Medium",
  "Inverse/parameter",
  r"Fatima sells a lamp at a profit of $20\%$. Had she bought it for $10\%$ less and sold it for Rs. $30$ less, her profit would have been $25\%$. What is the cost price of the lamp?",
  "MCQ",
  r"Let the cost be $x$, so the price is $1.2x$. In the second case the cost is $0.9x$ and the price is $1.25 \times 0.9x = 1.125x$. So $1.2x - 30 = 1.125x$, giving $0.075x = 30$ and $x = $ Rs. $400$.",
  "Measuring the new profit against the original cost instead of the reduced cost.",
  "C02D-two-scenarios-cost-and-price-change", "Both cost and price change, so the new profit needs the new base.",
  correct=r"Rs. $400$",
  distractors=[(r"Rs. $600$", r"Takes the $25\%$ on the original cost: $1.2x - 30 - 0.9x = 0.25x$ gives $x = 600$."),
               (r"Rs. $480$", "Reports the original selling price."),
               (r"Rs. $300$", r"Treats Rs. $30$ as the $10\%$ saving on the cost: $0.1x = 30$.")],
  check=_c22, values=[400, 600, 480, 300], cognitive="Application")


def _c23():
    price = Fraction(16000) * Fraction(125, 100)   # sale 1
    n = 1
    while price <= 39000:
        outlay = price * Fraction(80, 100) + 1000
        price = outlay * Fraction(125, 100)
        n += 1
    return n
q("C02-D-023", TOPIC, "Sale number at which the price first crosses a level when an item is repeatedly bought back, refurbished and resold", "Difficult",
  "Conceptual/application",
  r"Ravi, a dealer, buys a new generator for Rs. $16{,}000$ and sells it to a customer at a profit of $25\%$. After that he repeats the following cycle: he buys the generator back from its current owner at $80\%$ of the price that owner paid him, spends Rs. $1{,}000$ refurbishing it, and sells it to a new customer at a profit of $25\%$ on his total outlay for that cycle (buy-back price plus refurbishment). Counting the first sale as sale number $1$, in which sale does the selling price first exceed Rs. $39{,}000$? (Type the sale number.)",
  "TITA",
  r"If a sale is at price $S$, the next outlay is $0.8S + 1{,}000$ and the next price is $1.25(0.8S + 1{,}000) = S + 1{,}250$, because $0.8 \times 1.25 = 1$. So the prices are $20{,}000, 21{,}250, 22{,}500, \ldots$, and sale $n$ is at $20{,}000 + 1{,}250(n - 1)$. Sale $16$ is at $38{,}750$ and sale $17$ at $40{,}000$, so the answer is $17$.",
  "Ignoring the markup on the refurbishment cost, or counting the number of price rises instead of the sale number.",
  "C02D-buyback-refurbish-cycles", "The cycle hides an invariant (the buy-back and the markup cancel, leaving a fixed rise); spotting it avoids sixteen rounds of arithmetic, and the counting is a trap.",
  tita_answer=17, check=_c23,
  tita_traps=[(16, r"Counts the $16$ price rises of Rs. $1{,}250$ instead of the sale number."),
              (21, r"Lets the price rise by only the Rs. $1{,}000$ refurbishment each cycle, forgetting the $25\%$ markup on it."),
              (15, r"Treats each cycle as a net $25\% - 20\% = 5\%$ rise and compounds: $20{,}000 \times 1.05^{14} > 39{,}000$.")],
  cognitive="Analysis", exams=CX)


def _c24():
    c1, c2, p = Fraction(9, 4), Fraction(17, 6), Fraction(8, 3)
    # equal numbers in each lot; search the total N
    for N in range(2, 5000, 2):
        h = N // 2
        if h % 4 or h % 6 or N % 3:
            continue
        if N * p - h * c1 - h * c2 == 75:
            return N
q("C02-D-024", TOPIC, "Total quantity from the profit when equal numbers are bought at two rates", "Medium",
  "Inverse/parameter",
  r"A trader buys some pens at $4$ for Rs. $9$ and an equal number of pens at $6$ for Rs. $17$. He sells all the pens at $3$ for Rs. $8$ and makes a total profit of Rs. $75$. How many pens did he buy in all?",
  "MCQ",
  r"Average cost per pen $= \frac{1}{2}\left(\frac{9}{4} + \frac{17}{6}\right) = \frac{61}{24}$, and the selling price is $\frac{8}{3} = \frac{64}{24}$. Profit per pen is $\frac{3}{24} = \frac{1}{8}$ rupee, so the number of pens is $75 \times 8 = 600$.",
  "Losing track of whether a count refers to one lot or to both lots together.",
  "C02D-mixed-lots-unit-rates", "Fractional unit costs must be averaged correctly before the count appears.",
  correct=r"$600$",
  distractors=[(r"$300$", "Finds the number in one lot only."),
               (r"$1{,}200$", r"Finds $75 \times 8 = 600$ correctly but takes it as the number bought at each rate, and doubles it."),
               (r"$180$", r"Uses the first lot's cost alone: profit per pen $\frac{8}{3} - \frac{9}{4} = \frac{5}{12}$.")],
  check=_c24, values=[600, 300, 1200, 180], cognitive="Application")


def _c25():
    n = symbols('n', positive=True)
    nn = solve(Eq(36 * n + 120, 42 * n - 240), n)[0]
    unit = (36 * nn + 120) / nn
    return unit * Rational(125, 100)
q("C02-D-025", TOPIC, "Price for a target profit after deducing the cost from a loss at one price and a profit at another", "Medium",
  "Multi-step word problem",
  r"Ravi has a box of identical toy cars. Selling all of them at Rs. $36$ each would give him a total loss of Rs. $120$. Selling all of them at Rs. $42$ each would give him a total profit of Rs. $240$. At what price per car should he sell them to make a profit of $25\%$?",
  "MCQ",
  r"The Rs. $6$ rise per car swings the result by $120 + 240 = 360$, so there are $60$ cars. Total cost $= 60 \times 36 + 120 = 2{,}160 + 120 = 2{,}280$, that is Rs. $38$ per car. For $25\%$ profit the price is $1.25 \times 38 = $ Rs. $47.50$.",
  r"Taking the midpoint of the two prices as the cost, or applying the $25\%$ to one of the given prices.",
  "C02D-two-prices-lot-gain-loss", "Count, then unit cost, then markup: three linked steps.",
  correct=r"Rs. $47.50$",
  distractors=[(r"Rs. $48.75$", r"Takes the cost as the midpoint Rs. $39$ and adds $25\%$."),
               (r"Rs. $45.00$", r"Adds $25\%$ to the loss-making price Rs. $36$."),
               (r"Rs. $52.50$", r"Adds $25\%$ to the profit-making price Rs. $42$.")],
  check=_c25, values=[Fraction(95, 2), Fraction(195, 4), 45, Fraction(105, 2)], cognitive="Application")


def _c26():
    cap = Fraction(50000)
    start = cap
    for _ in range(3):
        goods_cost = cap
        good = goods_cost * Fraction(80, 100)   # cost value of the stock that survives
        cap = good * Fraction(150, 100)
    return cap - start
q("C02-D-026", TOPIC, "Capital after repeated buy-and-sell cycles with spoilage in each cycle", "Medium",
  "Multi-step word problem",
  r"A vegetable trader starts with Rs. $50{,}000$. In each cycle he spends all his money on stock; $20\%$ of the stock spoils, and he sells the rest at $50\%$ above its cost. He then uses the entire amount received for the next cycle. What is his total profit after three such cycles?",
  "MCQ",
  r"Each cycle turns every rupee into $0.8 \times 1.5 = 1.2$ rupees. After three cycles the capital is $50{,}000 \times 1.2^3 = 50{,}000 \times 1.728 = 86{,}400$, so the profit is Rs. $36{,}400$.",
  "Subtracting the spoilage percentage from the markup, or adding the cycles' profits without compounding.",
  "C02D-reinvest-capital-cycles", "Needs the per-cycle multiplier and compounding over three cycles.",
  correct=r"Rs. $36{,}400$",
  distractors=[(r"Rs. $30{,}000$", r"Adds $20\%$ of Rs. $50{,}000$ three times without compounding."),
               (r"Rs. $59{,}850$", r"Uses a $30\%$ gain per cycle ($50 - 20$) and compounds: $50{,}000(1.3^3 - 1)$."),
               (r"Rs. $45{,}000$", r"Uses $30\%$ per cycle without compounding: $3 \times 15{,}000$.")],
  check=_c26, values=[36400, 30000, 59850, 45000], cognitive="Application")


def _c27():
    N = Fraction(1); C = Fraction(1)
    p = (C / 2) / Fraction(40, 100)    # 40% of the stock recovers half the cost
    rev = Fraction(40, 100) * p + Fraction(60, 100) * p * Fraction(110, 100)
    return (rev - C) * 100
q("C02-D-027", TOPIC, "Overall profit when early sales recover part of the cost and the price is then raised", "Medium",
  "Conceptual/application",
  r"A bookseller sells the first $40\%$ of his stock of a new title at a fixed price and finds that this has recovered exactly half of the total cost of the stock. He then raises the price by $10\%$ and sells the rest of the stock. What is his overall profit percentage?",
  "MCQ",
  r"Let the whole stock cost $1$. Selling $40\%$ of it brings in $0.5$, so the first price is $\frac{0.5}{0.4} = 1.25$ times cost (a $25\%$ markup). The rest sells at $1.25 \times 1.1 = 1.375$. Revenue $= 0.4 \times 1.25 + 0.6 \times 1.375 = 0.5 + 0.825 = 1.325$, a profit of $32.5\%$.",
  r"Adding the $10\%$ price rise to the $25\%$ markup, or applying the new price to the whole stock.",
  "C02D-cost-recovered-part-stock", "Infer the markup from the recovery fact, then weight two prices.",
  correct=r"$32.5\%$",
  distractors=[(r"$25.0\%$", "Uses the first price for the whole stock."),
               (r"$37.5\%$", "Uses the raised price for the whole stock."),
               (r"$35.0\%$", r"Adds $10$ percentage points to the $25\%$ markup.")],
  check=_c27, values=[Fraction(65, 2), 25, Fraction(75, 2), 35], cognitive="Analysis")


def _c28():
    old_margin = 80 - 60
    new_price = 80 * Fraction(85, 100)
    new_margin = new_price - 60
    return (Fraction(old_margin) / new_margin - 1) * 100
q("C02-D-028", TOPIC, "Sales increase needed to keep profit unchanged after a price cut", "Medium",
  "Conceptual/application",
  r"A retailer buys an item at Rs. $60$ and sells it at Rs. $80$. He plans to cut the selling price by $15\%$ while the cost stays the same. By what percentage must the number of items sold increase so that his total profit stays the same? (Type the answer as a percentage.)",
  "TITA",
  r"The margin falls from $80 - 60 = 20$ to $68 - 60 = 8$ rupees per item. To keep the total profit unchanged, volume must rise by a factor of $\frac{20}{8} = 2.5$, that is by $150\%$.",
  r"Assuming that a $15\%$ price cut needs only a $15\%$ rise in volume.",
  "C02D-price-cut-volume-tradeoff", "Requires reasoning with margins rather than prices, and converting a factor to a percentage increase.",
  tita_answer=150, check=_c28,
  tita_traps=[(250, r"Types the factor $2.5$ as $250\%$ instead of an increase of $150\%$."),
              (15, "Assumes volume must rise by the same percentage as the price cut.")],
  cognitive="Analysis")


def _c29():
    a = symbols('a', positive=True)
    ca = solve(Eq(a * Rational(20, 100) - (9000 - a) * Rational(10, 100), 9000 * Rational(6, 100)), a)[0]
    return 9000 - ca
q("C02-D-029", TOPIC, "Cost of each of two items from their total cost and the overall profit", "Medium",
  "Inverse/parameter",
  r"Joseph buys two bicycles for a total of Rs. $9{,}000$. He sells one at a profit of $20\%$ and the other at a loss of $10\%$, and his overall profit on the two is $6\%$. What was the cost price of the bicycle he sold at a loss?",
  "MCQ",
  r"Let the profitable bicycle cost $a$. Then $0.2a - 0.1(9{,}000 - a) = 0.06 \times 9{,}000 = 540$, so $0.3a = 1{,}440$ and $a = 4{,}800$. The other bicycle cost Rs. $4{,}200$. (Alligation: $(6 + 10) : (20 - 6) = 8 : 7$.)",
  "Reversing the alligation ratio and so reporting the other bicycle's cost.",
  "C02D-alligation-split-of-lot", "Linear equation with a negative rate and a reversal trap.",
  correct=r"Rs. $4{,}200$",
  distractors=[(r"Rs. $4{,}800$", "Reports the cost of the bicycle sold at a profit."),
               (r"Rs. $4{,}500$", "Assumes the two bicycles cost the same."),
               (r"Rs. $3{,}000$", "Splits the Rs. $9{,}000$ in the ratio of the rates $20 : 10$ and gives the smaller share.")],
  check=_c29, values=[4200, 4800, 4500, 3000], cognitive="Application")


def _c30():
    demand, price, cost, salvage, lot = 70, 50, 30, 20, 20
    best = None
    for lots in range(0, 10):
        n = lots * lot
        sold = min(n, demand)
        prof = sold * price + (n - sold) * salvage - n * cost
        best = prof if best is None or prof > best else best
    return best
q("C02-D-030", TOPIC, "Best order size when stock comes in fixed lots and leftovers sell at a salvage price", "Medium",
  "Casework/optimisation",
  r"A florist can buy roses only in bundles of $20$, at Rs. $30$ per rose. Tomorrow she can sell exactly $70$ roses at Rs. $50$ each, and no more at that price. Any roses left over can be sold to a decorator at Rs. $20$ each. If she buys the number of bundles that gives her the greatest profit, what is that profit?",
  "MCQ",
  r"With $3$ bundles ($60$ roses) the profit is $60 \times 20 = 1{,}200$. With $4$ bundles ($80$ roses) she sells $70$ at Rs. $50$ and $10$ at Rs. $20$: $3{,}500 + 200 - 2{,}400 = 1{,}300$. With $5$ bundles: $3{,}500 + 600 - 3{,}000 = 1{,}100$, and more bundles do worse. The greatest profit is Rs. $1{,}300$.",
  "Ordering only up to the demand, without checking that one extra bundle still pays.",
  "C02D-order-quantity-salvage", "Short casework over bundle counts; the obvious choice is not optimal.",
  correct=r"Rs. $1{,}300$",
  distractors=[(r"Rs. $1{,}200$", "Buys only $3$ bundles so as never to have leftovers."),
               (r"Rs. $1{,}400$", r"Assumes exactly $70$ roses can be bought: $70 \times 20$."),
               (r"Rs. $1{,}100$", "Buys $5$ bundles to cover demand with a margin.")],
  check=_c30, values=[1300, 1200, 1400, 1100], cognitive="Analysis")


# ================================================================= DIFFICULT (10)

def _c31():
    # price in steps of Rs 2 from Rs 20; each step changes sales by 20 cups
    best = None
    for k in range(-6, 16):
        p = 20 + 2 * k
        cups = 300 - 20 * k
        if cups < 0 or p <= 0:
            continue
        prof = (p - 8) * cups
        best = prof if best is None or prof > best else best
    return best
q("C02-D-031", TOPIC, "Maximum profit when price can change only in fixed steps and demand responds linearly", "Medium",
  "Casework/optimisation",
  r"A tea stall sells $300$ cups a day at Rs. $20$ per cup, and each cup costs Rs. $8$ to make. The owner can change the price only in steps of Rs. $2$. Each Rs. $2$ increase reduces daily sales by $20$ cups, and each Rs. $2$ decrease increases daily sales by $20$ cups. What is the greatest daily profit, in rupees, that the stall can make?",
  "TITA",
  r"After $k$ steps up, the profit is $(12 + 2k)(300 - 20k) = 40(6 + k)(15 - k)$. The product $(6 + k)(15 - k)$ is largest when $k$ is nearest to $4.5$, so $k = 4$ or $k = 5$, both giving $10 \times 11 = 110$. The maximum profit is $40 \times 110 = 4{,}400$ rupees (at Rs. $28$ or Rs. $30$ per cup).",
  "Using the unrestricted optimum (price Rs. $29$) although the price can move only in Rs. $2$ steps.",
  "C02D-price-demand-max-profit", "Upper Medium: a factored quadratic in the step count, with the vertex between two allowed steps that must be compared.",
  tita_answer=4400, check=_c31,
  tita_traps=[(4410, "Uses $k = 4.5$ (price Rs. $29$), which is not an allowed price."),
              (3600, r"Gives the present profit $12 \times 300$.")],
  cognitive="Analysis", exams=CX)


def _c32():
    best = max(range(0, 41), key=lambda k: (2000 + 100 * k - 400) * (80 - 2 * k))
    return 2000 + 100 * best
q("C02-D-032", TOPIC, "Profit-maximising rent when vacancies rise with rent and upkeep applies to occupied rooms", "Difficult",
  "Casework/optimisation",
  r"A hotel has $80$ rooms, all occupied every night at a rent of Rs. $2{,}000$ per room. For every Rs. $100$ increase in rent, $2$ more rooms stay vacant. Each occupied room costs the hotel Rs. $400$ per night in upkeep; a vacant room costs nothing. The rent can be changed only in multiples of Rs. $100$. At what rent per room is the hotel's nightly profit the greatest?",
  "MCQ",
  r"After $k$ increases, profit $= (2{,}000 + 100k - 400)(80 - 2k) = 200(16 + k)(40 - k)$. This is largest when $k$ is midway between $-16$ and $40$, at $k = 12$. The rent is $2{,}000 + 1{,}200 = $ Rs. $3{,}200$, with $56$ rooms let and a profit of Rs. $1{,}56{,}800$.",
  "Maximising revenue (or charging upkeep on all $80$ rooms, or on the vacant ones), which misplaces the optimum.",
  "C02D-price-demand-max-profit", "Must set up profit with a cost that scales with occupancy, then use the vertex; several plausible near-misses.",
  correct=r"Rs. $3{,}200$",
  distractors=[(r"Rs. $3{,}000$", "Maximises revenue $(2{,}000 + 100k)(80 - 2k)$, ignoring upkeep, giving $k = 10$."),
               (r"Rs. $4{,}000$", "Takes the midpoint of the present rent Rs. $2{,}000$ and the rent Rs. $6{,}000$ at which every room is vacant."),
               (r"Rs. $2{,}800$", r"Charges the upkeep on the vacant rooms instead of the occupied ones: $(2{,}000 + 100k)(80 - 2k) - 400 \times 2k$ peaks at $k = 8$.")],
  check=_c32, values=[3200, 3000, 4000, 2800], cognitive="Analysis", exams=CX)


def _c33():
    def prof(p):
        return (p - 24) * (120 - 3 * (p - 40))
    now = prof(40)
    ok = [p for p in range(24, 81) if prof(p) >= now]
    return max(ok)
q("C02-D-033", TOPIC, "Highest price that keeps profit at least at its present level under linear demand", "Difficult",
  "Conceptual/application",
  r"A bakery sells $120$ cakes a day at Rs. $40$ each; each cake costs Rs. $24$ to make. Every Rs. $1$ increase in price reduces daily sales by $3$ cakes. The price is always a whole number of rupees. What is the highest price at which the bakery's daily profit is not less than its present daily profit?",
  "MCQ",
  r"At price $p$, sales are $120 - 3(p - 40) = 240 - 3p$ and profit is $(p - 24)(240 - 3p)$, a downward parabola with roots $24$ and $80$, so it is symmetric about $p = 52$. The present price $40$ is $12$ below $52$, so the profit is the same again at $52 + 12 = 64$ and lower beyond it. The highest such price is Rs. $64$. (Check: $40 \times 48 = 1{,}920 = 16 \times 120$.)",
  "Reporting the profit-maximising price instead of the far end of the range where profit stays at or above its present level.",
  "C02D-price-demand-profit-threshold", "Uses the symmetry of the profit parabola about its vertex rather than brute expansion.",
  correct=r"Rs. $64$",
  distractors=[(r"Rs. $52$", "Gives the profit-maximising price."),
               (r"Rs. $80$", "Gives the price at which sales fall to zero."),
               (r"Rs. $60$", "Takes the midpoint of the present price Rs. $40$ and the zero-sales price Rs. $80$.")],
  check=_c33, values=[64, 52, 80, 60], cognitive="Analysis", exams=CX)


def _c34():
    a, b = symbols('a b')
    sol = solve([Eq(a - 40 * b, 300), Eq(a - 45 * b, 250)], [a, b], dict=True)[0]
    A, B = sol[a], sol[b]
    rent = 2560
    return sum(1 for p in range(0, 200) if A - B * p >= 0 and (p - 30) * (A - B * p) - rent >= 0)
q("C02-D-034", TOPIC, "Number of whole-rupee prices that avoid a loss, with demand inferred from two trials and a fixed weekly cost", "Difficult",
  "Casework/optimisation",
  r"A shop sells a lunch box that costs it Rs. $30$ each. At a price of Rs. $40$ it sold $300$ boxes a week, and at Rs. $45$ it sold $250$ boxes a week. Assume weekly sales change linearly with price. The shop also pays a fixed rent of Rs. $2{,}560$ a week for the counter, whatever the price. If the price must be a whole number of rupees, for how many different prices does the shop avoid a weekly loss, that is, make a weekly profit of zero or more?",
  "MCQ",
  r"Sales fall by $50$ for a Rs. $5$ rise, so sales $= 700 - 10p$, and the weekly profit is $10(p - 30)(70 - p) - 2{,}560$. Writing $p = 50 + u$, $(p - 30)(70 - p) = 400 - u^2$, so the condition is $400 - u^2 \ge 256$, that is $|u| \le 12$. The prices run from Rs. $38$ to Rs. $62$ (with zero profit at both ends), which is $25$ prices.",
  "Dropping the two break-even prices, or forgetting the fixed rent.",
  "C02D-price-demand-profit-threshold", "Must build the demand line from two data points, add a fixed cost and solve a quadratic inequality, then count integers with care at the ends.",
  correct=r"$25$",
  distractors=[(r"$23$", r"Requires a strictly positive profit, which drops Rs. $38$ and Rs. $62$, where the profit is exactly zero."),
               (r"$24$", r"Counts the prices as $62 - 38$, an off-by-one slip."),
               (r"$41$", r"Ignores the rent and counts every price from Rs. $30$ to Rs. $70$.")],
  check=_c34, values=[25, 23, 24, 41], cognitive="Analysis", exams=CX)


def _c35():
    c, s = symbols('c s', positive=True)
    sol = solve([Eq(s + 75, Rational(150, 100) * Rational(80, 100) * c), Eq(s - 75, Rational(95, 100) * c)], [c, s], dict=True)[0]
    return sol[c]
q("C02-D-035", TOPIC, "Cost price from two hypothetical scenarios that change cost and price", "Medium",
  "Inverse/parameter",
  r"Sneha bought a watch and later sold it. Had she bought it for $20\%$ less and sold it for Rs. $75$ more than she actually did, her profit would have been $50\%$. Had she instead paid the actual price but sold it for Rs. $75$ less than she actually did, she would have made a loss of $5\%$. What did Sneha pay for the watch, in rupees?",
  "TITA",
  r"Let the cost be $c$ and the actual selling price $s$. First scenario: $s + 75 = 1.5 \times 0.8c = 1.2c$. Second scenario: $s - 75 = 0.95c$. Subtracting, $150 = 0.25c$, so $c = 600$ rupees (and $s = 645$, an actual profit of $7.5\%$).",
  "Measuring the first hypothetical profit against the original cost instead of the reduced cost.",
  "C02D-two-scenarios-cost-and-price-change", "Two hypotheticals with different bases give a pair of linear equations; subtracting them finishes it in about two minutes.",
  tita_answer=600, check=_c35,
  tita_traps=[(645, "Reports the actual selling price."),
              (1000, r"Takes the second scenario as a $5\%$ profit: $s - 75 = 1.05c$, giving $0.15c = 150$.")],
  cognitive="Application")


def _c36():
    target = Fraction(100000)
    W = 10000
    def final(x):
        cap = Fraction(x)
        for _ in range(3):
            cap = cap * Fraction(125, 100) - W
        return cap
    # final is linear and increasing in x; solve exactly
    a = final(1) - final(0)
    b = final(0)
    return (target - b) / a
q("C02-D-036", TOPIC, "Starting capital from the final capital after repeated profitable cycles with fixed withdrawals", "Difficult",
  "Inverse/parameter",
  r"A trader spends all his capital on stock and sells the stock at a profit of $25\%$. After each such sale he withdraws Rs. $10{,}000$ for household use and invests everything that is left in the next round. After the third round and its withdrawal, he has exactly Rs. $1{,}00{,}000$. With how many rupees did he start?",
  "TITA",
  r"Work backwards. Before the third withdrawal he had $1{,}10{,}000$, so the third round began with $\frac{1{,}10{,}000}{1.25} = 88{,}000$. Before the second withdrawal: $98{,}000$, so the second round began with $78{,}400$. Before the first withdrawal: $88{,}400$, so he started with $\frac{88{,}400}{1.25} = 70{,}720$ rupees.",
  "Ignoring the withdrawals, or adding them back only once at the end.",
  "C02D-reinvest-capital-cycles", "Three compounding rounds interleaved with withdrawals; working backwards is the clean route.",
  tita_answer=70720, check=_c36,
  tita_traps=[(51200, r"Ignores the withdrawals: $\frac{1{,}00{,}000}{1.25^3}$."),
              (66560, r"Adds all three withdrawals at the end: $\frac{1{,}30{,}000}{1.25^3}$.")],
  cognitive="Analysis", exams=CX)


def _c37():
    best = 0
    for x in range(0, 61):
        for y in range(0, 61 - x):
            if 200 * x + 125 * y <= 10000:
                best = max(best, 50 * x + 40 * y)
    return best
q("C02-D-037", TOPIC, "Best integer purchase mix of two items under a budget and a space limit", "Difficult",
  "Casework/optimisation",
  r"A shopkeeper has Rs. $10{,}000$ and shelf space for at most $60$ items. He can stock kettles, which cost Rs. $200$ each and are sold at a profit of Rs. $50$ each, and toasters, which cost Rs. $125$ each and are sold at a profit of Rs. $40$ each. Every item he stocks will be sold. What is the greatest profit he can make?",
  "MCQ",
  r"Kettles give more profit per item, toasters more per rupee, so both limits bind. Using all $60$ slots, $x$ kettles and $60 - x$ toasters cost $7{,}500 + 75x \le 10{,}000$, so $x \le 33$. Profit $= 50x + 40(60 - x) = 2{,}400 + 10x$, largest at $x = 33$: $33$ kettles and $27$ toasters cost Rs. $9{,}975$ and give Rs. $2{,}730$. No other mix does better: with $x \le 33$ kettles the profit is at most $2{,}400 + 10x \le 2{,}730$, and with $x \ge 34$ the budget allows at most $\frac{10{,}000 - 200x}{125}$ toasters, so the profit is at most $50x + 3{,}200 - 64x = 3{,}200 - 14x \le 2{,}724$.",
  r"Rounding the fractional optimum $x = 33\frac{1}{3}$ up, which breaks the budget, or filling the shelf with a single item.",
  "C02D-purchase-mix-optimisation", "Two binding constraints and an integer optimum just below a fractional corner.",
  correct=r"Rs. $2{,}730$",
  distractors=[(r"Rs. $2{,}740$", "Rounds up to $34$ kettles and $26$ toasters, which costs Rs. $10{,}050$ and is over budget."),
               (r"Rs. $2{,}500$", "Spends everything on $50$ kettles, the higher profit per item."),
               (r"Rs. $2{,}400$", "Fills the shelf with $60$ toasters, the higher profit per rupee.")],
  check=_c37, values=[2730, 2740, 2500, 2400], cognitive="Analysis", exams=CX)


def _c38():
    best = 0
    for x in range(0, 31):
        for y in range(0, 31 - x):
            if 1200 * x + 3500 * y <= 60000:
                best = max(best, 300 * x + 800 * y)
    return best
q("C02-D-038", TOPIC, "Integer purchase mix maximising profit when the rounded corner point is not optimal", "Difficult",
  "Casework/optimisation",
  r"An appliance dealer has Rs. $60{,}000$ to spend and room for at most $30$ units. Fans cost Rs. $1{,}200$ each and earn a profit of Rs. $300$ each; coolers cost Rs. $3{,}500$ each and earn a profit of Rs. $800$ each. Every unit he buys will be sold. What is the greatest profit he can make, in rupees?",
  "TITA",
  r"With $y$ coolers, the most fans he can add is the smaller of $30 - y$ and $\lfloor \frac{60{,}000 - 3{,}500y}{1{,}200} \rfloor$. Checking $y$ near the crossing point ($y \approx 10.4$): $y = 10$ allows $20$ fans, profit $14{,}000$; $y = 11$ allows $17$ fans, profit $13{,}900$; $y = 12$ allows $15$ fans, profit $4{,}500 + 9{,}600 = 14{,}100$; $y = 13$ allows $12$ fans, profit $14{,}000$; $y = 14, 15, 16, 17$ give $13{,}900$, $13{,}800$, $13{,}700$, $13{,}600$. For $y \le 10$ space binds and the profit is $9{,}000 + 500y \le 14{,}000$. The maximum is $14{,}100$ rupees.",
  "Stopping at the rounded corner point ($20$ fans, $10$ coolers) without checking nearby integer mixes.",
  "C02D-purchase-mix-optimisation", "The integer optimum is not the rounded LP corner; needs careful casework on leftover budget.",
  tita_answer=14100, check=_c38,
  tita_traps=[(14000, "Takes the rounded corner point of $20$ fans and $10$ coolers."),
              (13600, "Spends everything on $17$ coolers.")],
  cognitive="Analysis", exams=CX)


def _c39():
    a, b, c = symbols('a b c', positive=True)
    sol = solve([Eq(a + b + c, 36000),
                 Eq(a * Rational(10, 100) - b * Rational(5, 100) + c * Rational(5, 100), 1800),
                 Eq(-a * Rational(4, 100) + b * Rational(15, 100) + c * Rational(5, 100), 1160)], [a, b, c], dict=True)[0]
    return sol[a] * Rational(5, 100) + sol[b] * Rational(20, 100) - sol[c] * Rational(10, 100)
q("C02-D-039", TOPIC, "Result of a third pricing plan after deducing three costs from two plans and the total", "Difficult",
  "Multi-step word problem",
  r"Priya bought a sofa, a dining table and a bed for a total of Rs. $36{,}000$. Had she sold the sofa at a profit of $10\%$, the table at a loss of $5\%$ and the bed at a profit of $5\%$, her overall profit would have been Rs. $1{,}800$. Had she sold the sofa at a loss of $4\%$, the table at a profit of $15\%$ and the bed at a profit of $5\%$, her overall profit would have been Rs. $1{,}160$. She actually sells the sofa at a profit of $5\%$, the table at a profit of $20\%$ and the bed at a loss of $10\%$. Her overall profit is",
  "MCQ",
  r"Let the costs be $a$, $b$ and $36{,}000 - a - b$. The first plan gives $0.1a - 0.05b + 0.05(36{,}000 - a - b) = 1{,}800$, so $0.05a - 0.1b = 0$ and $a = 2b$. Subtracting the second plan from the first gives $0.14a - 0.2b = 640$, so $0.28b - 0.2b = 640$, $b = 8{,}000$, $a = 16{,}000$ and the bed cost $12{,}000$. The actual result is $800 + 1{,}600 - 1{,}200 = $ Rs. $1{,}200$.",
  "Assuming equal costs, or attaching the deduced costs to the wrong items.",
  "C02D-alligation-split-of-lot", "Three unknown costs must be recovered from two plans and the total (the bed's common rate is the key to eliminating it), then a third plan with mixed signs is evaluated.",
  correct=r"Rs. $1{,}200$",
  distractors=[(r"Rs. $1{,}800$", r"Assumes each item cost Rs. $12{,}000$: $600 + 2{,}400 - 1{,}200$."),
               (r"Rs. $2{,}400$", r"Swaps the sofa and table costs: $5\%$ of $8{,}000$ plus $20\%$ of $16{,}000$ minus $1{,}200$."),
               (r"Rs. $3{,}600$", r"Adds the $10\%$ on the bed as a profit: $800 + 1{,}600 + 1{,}200$.")],
  check=_c39, values=[1200, 1800, 2400, 3600], cognitive="Analysis", exams=CX)


def _c40():
    r = symbols('r', positive=True)  # markup per unbroken bangle over cost per bought bangle
    m = solve(Eq((1 - Rational(10, 100)) * r, Rational(126, 100)), r)[0]
    return ((1 - Rational(30, 100)) * m - 1) * 100
q("C02-D-040", TOPIC, "Result under a higher breakage rate, given the profit under a lower one at the same price", "Difficult",
  "Conceptual/application",
  r"A trader buys a consignment of glass bangles and fixes a selling price per bangle. If $10\%$ of the bangles break in transit and he sells all the rest at that price, he makes a profit of $26\%$ on the consignment. If instead $30\%$ of the bangles break and he sells all the rest at the same price, what is his result on the consignment?",
  "MCQ",
  r"With $10\%$ broken, revenue is $1.26$ times the cost from $90\%$ of the bangles, so each bangle sells at $\frac{1.26}{0.9} = 1.4$ times its cost. With $30\%$ broken, revenue is $0.7 \times 1.4 = 0.98$ times the cost, a loss of $2.0\%$.",
  "Subtracting the extra breakage percentage directly from the profit percentage.",
  "C02D-spoilage-two-scenarios", "Must recover the per-bangle markup from one scenario and rescale; the linear subtraction shortcut is wrong.",
  correct=r"a loss of $2.0\%$",
  distractors=[(r"a profit of $6.0\%$", r"Subtracts the extra $20$ percentage points of breakage from the $26\%$ profit."),
               (r"a loss of $4.8\%$", r"Takes the price as $1.36$ times cost (adding $10$ to $26$), so $0.7 \times 1.36 = 0.952$."),
               (r"a profit of $0.8\%$", r"Cuts the old revenue by $20\%$: $1.26 \times 0.8 = 1.008$.")],
  check=_c40, values=[-2, 6, Fraction(-24, 5), Fraction(4, 5)], cognitive="Analysis", exams=CX)
