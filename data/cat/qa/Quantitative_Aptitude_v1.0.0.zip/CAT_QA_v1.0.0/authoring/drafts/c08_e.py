import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
ALL = ("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET")
HARD = ("CAT", "XAT")
MC = "Meeting and chasing"
SP = "Stoppages and periodic departures"


def _hm(h, m=0):
    """Clock time as minutes after midnight (24-hour h)."""
    return 60 * h + m


def _first_zero(diff, bps, t0, t1):
    """First t in (t0, t1] where the piecewise-linear diff(t) reaches 0 (breakpoints in bps)."""
    pts = sorted(set([F(t0), F(t1)] + [F(b) for b in bps if t0 < b < t1]))
    for a, b in zip(pts, pts[1:]):
        da, db = diff(a), diff(b)
        if da == 0 and a > t0:
            return a
        if (da < 0 <= db) or (da > 0 >= db):
            return a + (b - a) * da / (da - db)
    return None


def _bounce(v, D, t, start):
    """Position (from end 0) of a mover on [0, D] starting at `start` (0 or D), turning at the ends."""
    x = (v * t) % (2 * D)
    p = x if x <= D else 2 * D - x
    return p if start == 0 else D - p


def _road_meetings(D, v1, v2, n, T=200):
    """First n meetings (time, position from end 0) of movers starting at 0 and D, any kind of meeting."""
    D, v1, v2 = F(D), F(v1), F(v2)
    bps = set()
    for v in (v1, v2):
        k = 0
        while k * D / v <= T:
            bps.add(k * D / v)
            k += 1
    bps = sorted(bps)
    res = []
    for a, b in zip(bps, bps[1:]):
        da = _bounce(v1, D, a, 0) - _bounce(v2, D, a, D)
        db = _bounce(v1, D, b, 0) - _bounce(v2, D, b, D)
        if da * db < 0:
            t = a + (b - a) * da / (da - db)
            res.append((t, _bounce(v1, D, t, 0)))
        if db == 0:
            res.append((b, _bounce(v1, D, b, 0)))
        if len(res) >= n:
            break
    return res[:n]


def _halt_pos(v, run, halt, t):
    """Distance covered by time t (t >= 0) by a vehicle that runs `run` hours at v then halts `halt` hours, repeatedly."""
    t = F(t)
    cyc = run + halt
    k = int(t // cyc)
    r = t - k * cyc
    return v * run * k + v * min(r, run)


# =====================================================================================
# EASY
# =====================================================================================

def _c1():
    t = symbols('t', positive=True)
    h = solve(Eq(50 * t + 40 * t, 180), t)[0]
    return _hm(9) + 60 * h
q("C08-E-001", MC, "Two cars from opposite towns, simultaneous start: clock time of meeting", "Easy",
  "Single-step computation",
  r"Rampur and Sitapur are $180$ km apart on a straight highway. At $9{:}00$ am Ravi leaves Rampur for Sitapur driving at a constant $50$ km/h, and at the same moment Meera leaves Sitapur for Rampur on the same highway, driving at a constant $40$ km/h. At what time do they meet?",
  "MCQ",
  r"They approach each other at $50 + 40 = 90$ km/h, so the $180$ km gap closes in $\frac{180}{90} = 2$ hours. They meet at $11{:}00$ am. (Check: Ravi covers $100$ km and Meera $80$ km, which add up to $180$ km.)",
  "Treating the meeting as happening at the midpoint, or timing one car alone instead of using the closing speed.",
  "C08E-opposite-meet-time", "One idea (closing speed = sum of speeds) and one division; midpoint trap.",
  correct=r"$11{:}00$ am",
  distractors=[(r"$1{:}00$ pm", r"Divides $180$ km by the average of the two speeds, $45$ km/h, instead of their sum: $4$ hours."),
               (r"$11{:}15$ am", r"Assumes they meet at the midpoint and times Meera's $90$ km at $40$ km/h: $2$ hours $15$ minutes."),
               (r"$10{:}48$ am", r"Assumes they meet at the midpoint and times Ravi's $90$ km at $50$ km/h: $1.8$ hours $= 1$ hour $48$ minutes.")],
  check=_c1, values=[_hm(11), _hm(13), _hm(11, 15), _hm(10, 48)], cognitive="Application", exams=ALL)


def _c2():
    t = symbols('t', positive=True)
    h = solve(Eq(15 * t + 9 * t, 72), t)[0]
    return 9 * h
q("C08-E-002", MC, "Meeting point measured from the slower rider's end, simultaneous start", "Easy",
  "Single-step computation",
  r"Arjun and Fatima start cycling at the same time from towns P and Q, which are $72$ km apart, and ride toward each other along the same straight road. Arjun rides at a constant $15$ km/h and Fatima at a constant $9$ km/h. How far from Q, in km, do they meet?",
  "TITA",
  r"In equal times distances are in the ratio of speeds, $15 : 9 = 5 : 3$. So the $72$ km splits into $45$ km for Arjun (from P) and $27$ km for Fatima (from Q). They meet $27$ km from Q.",
  "Reporting the distance from the wrong town, or assuming a midpoint meeting.",
  "C08E-meeting-point-ratio", "Direct split of a distance in the speed ratio, with a which-end trap.",
  tita_answer=27, check=_c2, values=[27],
  tita_traps=[(45, "Gives the distance from P, which is Arjun's distance."),
              (36, "Assumes they meet at the midpoint.")],
  cognitive="Application", exams=ALL)


def _c3():
    t = symbols('t', positive=True)
    h = solve(Eq(54 * t - 42 * t, 36), t)[0]
    return (54 + 42) * h
q("C08-E-003", MC, "Difference of distances at the meeting gives the meeting time and the total distance", "Easy",
  "Multi-step word problem",
  r"Two cars start at the same time from towns P and Q and drive toward each other along a straight road at constant speeds of $54$ km/h and $42$ km/h respectively. When they meet, the car from P has travelled $36$ km more than the car from Q. What is the distance between P and Q?",
  "MCQ",
  r"The difference between their distances grows at $54 - 42 = 12$ km/h, so a difference of $36$ km means they have driven for $\frac{36}{12} = 3$ hours. In $3$ hours they together cover $(54 + 42) \times 3 = 288$ km, which is PQ.",
  "Reporting one car's distance instead of the sum of both.",
  "C08E-meeting-distance-difference", "Two short steps: time from the difference of speeds, then distance from the sum.",
  correct=r"$288$ km",
  distractors=[(r"$162$ km", r"Reports only the distance covered by the car from P, $54 \times 3$."),
               (r"$126$ km", r"Reports only the distance covered by the car from Q, $42 \times 3$."),
               (r"$144$ km", r"Multiplies the $3$ hours by the average speed $48$ km/h, as though only one car were moving.")],
  check=_c3, values=[288, 162, 126, 144], cognitive="Application", exams=ALL)


def _c4():
    t = symbols('t', positive=True)  # hours after 8:00
    h = solve(Eq(12 * t, 30 * (t - F(1, 2))), t)[0]
    return _hm(8) + 60 * h
q("C08-E-004", MC, "Second person starts half an hour later from the same point and catches up", "Easy",
  "Multi-step word problem",
  r"Sneha leaves home at $8{:}00$ am and cycles along a straight road at a constant $12$ km/h. Her brother Kabir leaves the same home at $8{:}30$ am and follows her along the same road on a scooter at a constant $30$ km/h. At what time does Kabir catch up with Sneha?",
  "MCQ",
  r"By $8{:}30$ am Sneha is $12 \times \frac{1}{2} = 6$ km ahead. Kabir gains on her at $30 - 12 = 18$ km/h, so he needs $\frac{6}{18} = \frac{1}{3}$ hour $= 20$ minutes. He catches her at $8{:}50$ am, $10$ km from home.",
  "Dividing the head start by the chaser's own speed, as if the leader stood still.",
  "C08E-chase-delayed-start", "Head start then relative speed; the trap is ignoring the leader's motion.",
  correct=r"$8{:}50$ am",
  distractors=[(r"$8{:}42$ am", r"Divides the $6$ km lead by Kabir's speed alone: $\frac{6}{30}$ hour $= 12$ minutes after $8{:}30$ am."),
               (r"$9{:}10$ am", r"Takes Sneha's lead as $12$ km (a full hour of cycling): $\frac{12}{18}$ hour $= 40$ minutes after $8{:}30$ am."),
               (r"$9{:}20$ am", r"Correctly finds that Kabir catches her $\frac{30 \times 30}{18} = 50$ minutes after Sneha's start, but counts the $50$ minutes from Kabir's start at $8{:}30$ am.")],
  check=_c4, values=[_hm(8, 50), _hm(8, 42), _hm(9, 10), _hm(9, 20)], cognitive="Application", exams=ALL)


def _c5():
    m = symbols('m', positive=True)
    return solve(Eq(75 * (60 - m) / 60, 60), m)[0]
q("C08-E-005", SP, "Minutes stopped per hour from speeds with and without stoppages", "Easy",
  "Single-step computation",
  r"Excluding stoppages, a bus runs at $75$ km/h; including stoppages, its average speed is $60$ km/h. If the bus stops for the same length of time in every hour of its journey, for how many minutes per hour does it stop?",
  "TITA",
  r"Because of the stoppages the bus covers $75 - 60 = 15$ km less in each hour. At its running speed, $15$ km takes $\frac{15}{75} \times 60 = 12$ minutes, so it stops for $12$ minutes per hour.",
  "Dividing the lost distance by the speed with stoppages instead of the running speed.",
  "C08E-stoppage-minutes-per-hour", "One standard idea; the only trap is the base speed used to convert the lost distance.",
  tita_answer=12, check=_c5, values=[12],
  tita_traps=[(15, r"Divides the $15$ km lost by $60$ km/h, the speed including stoppages.")],
  cognitive="Application", exams=ALL)


def _c6():
    gap = F(200, 1000)
    t = gap / (10 - 8)
    # verify by stepping the chase in small exact steps
    thief, cop, s, step = gap, F(0), F(0), t / 50
    while cop < thief:
        s += step; thief += 8 * step; cop += 10 * step
    assert s == t
    return 8 * t * 1000
q("C08-E-006", MC, "Thief and policeman start together with a fixed gap; thief's distance until caught", "Easy",
  "Multi-step word problem",
  r"A thief is $200$ m ahead of a policeman when both start running at the same instant along a straight road, the thief at a constant $8$ km/h and the policeman, chasing him, at a constant $10$ km/h. How far does the thief run before he is caught?",
  "MCQ",
  r"The policeman gains $10 - 8 = 2$ km/h, so closing the $0.2$ km gap takes $\frac{0.2}{2} = 0.1$ hour. In that time the thief runs $8 \times 0.1 = 0.8$ km $= 800$ m, while the policeman runs $1000$ m, exactly $200$ m more.",
  "Reporting the chaser's distance, or scaling the gap by the speed ratio.",
  "C08E-thief-policeman-gap", "Relative speed closes a gap; the trap is whose distance is asked.",
  correct=r"$800$ m",
  distractors=[(r"$1000$ m", r"Reports the policeman's distance."),
               (r"$160$ m", r"Scales the $200$ m gap by $\frac{8}{10}$."),
               (r"$250$ m", r"Scales the $200$ m gap by $\frac{10}{8}$.")],
  check=_c6, values=[800, 1000, 160, 250], cognitive="Application", exams=ALL)


def _c7():
    p, qq, t = symbols('p q t', positive=True)
    sol = solve([Eq(4 * p, qq * t), Eq(9 * qq, p * t), Eq(qq, 1)], [p, qq, t], dict=True)
    return sol[0][p] / sol[0][qq]
q("C08-E-007", MC, "Speed ratio from the times taken after the meeting", "Easy",
  "Conceptual/application",
  r"Two cars start at the same time from towns P and Q and drive toward each other along a straight road at constant speeds. After they pass each other, the car from P takes $4$ more hours to reach Q and the car from Q takes $9$ more hours to reach P. What is the ratio of the speed of the car from P to the speed of the car from Q?",
  "MCQ",
  r"Let the speeds be $p$ and $q$ and the meeting time $t$. After the meeting each car covers what the other covered before it: $4p = qt$ and $9q = pt$. Dividing, $\frac{4p}{9q} = \frac{q}{p}$, so $\frac{p^2}{q^2} = \frac{9}{4}$ and $p : q = 3 : 2$.",
  "Taking the speed ratio equal to the time ratio, or inverting the square-root rule.",
  "C08E-after-meeting-speed-ratio", "One known principle (square root of the inverse ratio of post-meeting times).",
  correct=r"$3 : 2$",
  distractors=[(r"$2 : 3$", r"Inverts the rule, taking the ratio as $\sqrt{4} : \sqrt{9}$."),
               (r"$9 : 4$", r"Takes the ratio of the post-meeting times $9 : 4$ without the square root."),
               (r"$4 : 9$", r"Takes the speed ratio equal to the ratio of the times, $4 : 9$.")],
  check=_c7, values=[F(3, 2), F(2, 3), F(9, 4), F(4, 9)], cognitive="Understanding", exams=ALL)


def _c8():
    m, j, t = symbols('m j t', positive=True)
    sol = solve([Eq(16 * m, j * t), Eq(25 * j, m * t), Eq(j, 1)], [m, j, t], dict=True)
    return sol[0][t]
q("C08-E-008", MC, "Meeting time as the geometric mean of the two post-meeting times", "Easy",
  "Conceptual/application",
  r"Meera and Joseph start walking at the same time from the two ends of a straight road toward each other, each at a constant speed. After they meet, Meera takes $16$ more minutes to reach Joseph's starting point and Joseph takes $25$ more minutes to reach Meera's starting point. How many minutes after starting did they meet?",
  "TITA",
  r"Let them meet after $t$ minutes, with speeds $m$ and $j$. Meera's remaining distance is what Joseph walked before the meeting, so $16m = jt$; similarly $25j = mt$. Multiplying, $400\,mj = mj\,t^2$, so $t = \sqrt{16 \times 25} = 20$ minutes.",
  "Averaging or adding the two post-meeting times instead of taking their geometric mean.",
  "C08E-after-meeting-meet-time", r"Direct use of $t = \sqrt{t_1 t_2}$ once the two relations are written.",
  tita_answer=20, check=_c8, values=[20],
  tita_traps=[(41, "Adds the two post-meeting times."),
              (9, "Takes the difference of the two post-meeting times.")],
  cognitive="Understanding", exams=ALL)


def _c9():
    v = symbols('v', positive=True)
    return solve(Eq(v * F(45, 60), 60), v)[0]
q("C08-E-009", SP, "Running speed from average speed and minutes stopped per hour", "Easy",
  "Inverse/parameter",
  r"A bus stops for $15$ minutes in every hour of its journey, and its average speed including these stoppages is $60$ km/h. What is its speed when it is moving?",
  "MCQ",
  r"In each hour the bus moves for only $45$ minutes, that is $\frac{3}{4}$ of an hour, and covers $60$ km. So its moving speed is $60 \div \frac{3}{4} = 80$ km/h.",
  "Adding the stop fraction to the speed (or multiplying by it) instead of dividing by the running fraction.",
  "C08E-stoppage-running-speed", "One step, but the direction of the scaling is the trap.",
  correct=r"$80$ km/h",
  distractors=[(r"$75$ km/h", r"Raises $60$ by $25\%$ (the $15$ minutes as a fraction of $60$) instead of dividing by $\frac{3}{4}$."),
               (r"$45$ km/h", r"Multiplies $60$ by $\frac{3}{4}$ instead of dividing."),
               (r"$48$ km/h", r"Treats $60$ km/h as the moving speed and adds a $15$ minute stop after every hour of running: $\frac{60}{1.25} = 48$.")],
  check=_c9, values=[80, 75, 45, 48], cognitive="Application", exams=ALL)


def _c10():
    t = symbols('t', positive=True)  # minutes; cyclist leaves the depot at minute 5
    times = []
    for k in (1, 2, 3):
        times.append(solve(Eq(F(40, 60) * (t - 15 * k), F(20, 60) * (t - 5)), t)[0])
    assert times[2] - times[1] == times[1] - times[0]
    return times[1] - times[0]
q("C08-E-010", SP, "Interval at which buses from a depot overtake a cyclist going the same way", "Easy",
  "Multi-step word problem",
  r"Buses leave a depot every $15$ minutes and travel along a straight road at a constant $40$ km/h. Harpreet cycles along the same road, away from the depot in the same direction as the buses, at a constant $20$ km/h. At what interval, in minutes, is she overtaken by successive buses?",
  "TITA",
  r"Consecutive buses are $40 \times \frac{15}{60} = 10$ km apart on the road. Each bus gains on Harpreet at $40 - 20 = 20$ km/h, so the next bus closes the $10$ km gap $\frac{10}{20}$ hour $= 30$ minutes after the previous one passes her.",
  "Using the sum of speeds for vehicles moving the same way, or taking the departure interval as the overtaking interval.",
  "C08E-buses-overtake-interval", "Spacing on the road, then relative speed: two short steps.",
  tita_answer=30, check=_c10, values=[30],
  tita_traps=[(10, r"Uses the closing speed $40 + 20 = 60$ km/h, as if she rode toward the depot."),
              (15, "Takes the departure interval itself.")],
  cognitive="Application", exams=ALL)


def _c11():
    t = symbols('t', positive=True)  # hours after 10:00
    h = solve(Eq(50 * t + 30 * (t - 1), 210), t)[0]
    assert h >= 1
    return _hm(10) + 60 * h
q("C08-E-011", MC, "Opposite-direction meeting when one train starts an hour later", "Easy",
  "Multi-step word problem",
  r"Stations P and Q are $210$ km apart on a double-track railway line. A passenger train leaves P for Q at $10{:}00$ am and runs at a constant $50$ km/h. A goods train leaves Q for P at $11{:}00$ am on the other track and runs at a constant $30$ km/h. Treating each train as a point, at what time do the two trains pass each other?",
  "MCQ",
  r"By $11{:}00$ am the passenger train has covered $50$ km, leaving a gap of $160$ km. From then on the trains close it at $50 + 30 = 80$ km/h, which takes $2$ hours. They pass each other at $1{:}00$ pm.",
  "Mishandling the head start: giving it to the wrong train or counting the joint time from the wrong clock time.",
  "C08E-staggered-start-opposite", "Head start then closing speed; the clock-time bookkeeping is the trap.",
  correct=r"$1{:}00$ pm",
  distractors=[(r"$1{:}15$ pm", r"Gives the one-hour head start to the goods train: $50(t - 1) + 30t = 210$ gives $t = 3.25$ hours after $10{:}00$ am."),
               (r"$12{:}00$ noon", r"Finds the $2$ hours of joint running but counts them from the passenger train's start at $10{:}00$ am."),
               (r"$2{:}00$ pm", r"Solves $50t + 30(t - 1) = 210$ for $t = 3$ hours after $10{:}00$ am but counts the $3$ hours from the goods train's start.")],
  check=_c11, values=[_hm(13), _hm(13, 15), _hm(12), _hm(14)], cognitive="Application", exams=ALL)


def _c12():
    t, x = _road_meetings(6, 5, 7, 2)[1]
    return 60 * t
q("C08-E-012", MC, "Second meeting on a straight road with turnarounds at both ends", "Easy",
  "Conceptual/application",
  r"Ananya and Rohan start at the same time from the two ends of a straight $6$ km road and move toward each other at constant speeds of $5$ km/h and $7$ km/h respectively. Each turns back instantly on reaching an end of the road and keeps going at the same speed. Counting every time they are at the same point at the same instant, how many minutes after the start do they meet for the second time?",
  "TITA",
  r"At the first meeting they have together covered one road length, $6$ km, in $\frac{6}{12}$ hour $= 30$ minutes. Each must then reach the far end and turn, so at the second meeting they have together covered three road lengths, $18$ km, taking $\frac{18}{12} = 1.5$ hours $= 90$ minutes. (Check: Ananya has gone $7.5$ km, to Rohan's end and $1.5$ km back; Rohan has gone $10.5$ km, to Ananya's end and $4.5$ km back; both are $4.5$ km from Ananya's end.)",
  "Assuming two road lengths are covered between the first and second meetings instead of three in all.",
  "C08E-repeated-meetings-turnaround", "Single principle (combined distance $3L$ at the second meeting).",
  tita_answer=90, check=_c12, values=[90],
  tita_traps=[(60, "Takes the combined distance at the second meeting as two road lengths."),
              (30, "Reports the first meeting.")],
  cognitive="Understanding", exams=ALL)


def _c13():
    t = symbols('t', positive=True)
    h = solve(Eq(54 * t - 36 * t, 3 + F(3, 2)), t)[0]
    return 60 * h
q("C08-E-013", MC, "Car behind a truck: time to close the gap and then lead by a fixed distance", "Easy",
  "Multi-step word problem",
  r"A car travelling at a constant $54$ km/h is $3$ km behind a truck travelling in the same direction at a constant $36$ km/h on a straight highway. How many minutes will it take for the car to be $1.5$ km ahead of the truck?",
  "MCQ",
  r"Relative to the truck the car moves at $54 - 36 = 18$ km/h, and it must gain $3 + 1.5 = 4.5$ km: first close the gap, then open the lead. Time $= \frac{4.5}{18}$ hour $= 15$ minutes.",
  "Counting only the gap to be closed (or only the lead) rather than their sum.",
  "C08E-catch-up-and-lead", "Relative speed with a gain made of two parts.",
  correct=r"$15$ minutes",
  distractors=[(r"$10$ minutes", r"Counts only the time to draw level, $\frac{3}{18}$ hour."),
               (r"$5$ minutes", r"Counts only the $1.5$ km lead, $\frac{1.5}{18}$ hour."),
               (r"$3$ minutes", r"Uses the sum of the speeds, $\frac{4.5}{90}$ hour.")],
  check=_c13, values=[15, 10, 5, 3], cognitive="Application", exams=ALL)


# =====================================================================================
# MEDIUM
# =====================================================================================

def _c14():
    p, qq, t = symbols('p q t', positive=True)
    sol = solve([Eq(4 * p, qq * t), Eq(9 * qq, p * t), Eq(p, 54)], [p, qq, t], dict=True)[0]
    return (sol[p] + sol[qq]) * sol[t]
q("C08-E-014", MC, "Distance between towns from post-meeting times and one speed", "Medium",
  "Multi-step word problem",
  r"Two trucks start at the same time from towns P and Q and travel toward each other along a straight highway at constant speeds. After they cross, the truck from P reaches Q in $4$ hours and the truck from Q reaches P in $9$ hours. If the truck from P travels at $54$ km/h, what is the distance between P and Q?",
  "MCQ",
  r"Speeds are in the ratio $\sqrt{9} : \sqrt{4} = 3 : 2$, so the truck from Q runs at $36$ km/h. They meet after $\sqrt{4 \times 9} = 6$ hours, so PQ $= (54 + 36) \times 6 = 540$ km. (Check: the truck from P covers $324$ km before the crossing and $216$ km in the $4$ hours after it.)",
  "Inverting the square-root ratio, dropping the square root, or using the arithmetic mean for the meeting time.",
  "C08E-after-meeting-speed-ratio", "Two results combined: the speed-ratio rule and the meeting-time rule.",
  correct=r"$540$ km",
  distractors=[(r"$810$ km", r"Inverts the ratio, taking the other truck's speed as $81$ km/h: $(54 + 81) \times 6$."),
               (r"$468$ km", r"Takes the speed ratio as $9 : 4$ without the square root, so the other speed is $24$ km/h: $(54 + 24) \times 6$."),
               (r"$585$ km", r"Takes the meeting time as the arithmetic mean $6.5$ hours: $90 \times 6.5$.")],
  check=_c14, values=[540, 810, 468, 585], cognitive="Application", exams=ALL)


def _c15():
    t, a, b = symbols('t a b', positive=True)  # minutes; fractions of PQ per minute
    sol = solve([Eq(a, F(1, 96)), Eq(b, F(1, 160)), Eq((a + b) * t, 1)], [a, b, t], dict=True)[0]
    return sol[t]
q("C08-E-015", MC, "Meeting time from the two arrival times, simultaneous start", "Medium",
  "Inverse/parameter",
  r"Fatima and Joseph start at $7{:}00$ am from towns P and Q respectively and travel toward each other along the same road at constant speeds. Fatima reaches Q at $8{:}36$ am and Joseph reaches P at $9{:}40$ am. How many minutes after $7{:}00$ am do they meet?",
  "TITA",
  r"Fatima's whole trip takes $96$ minutes and Joseph's $160$ minutes, so each minute they cover $\frac{1}{96}$ and $\frac{1}{160}$ of PQ. Together they cover $\frac{1}{96} + \frac{1}{160} = \frac{5 + 3}{480} = \frac{1}{60}$ of PQ per minute, so they meet after $60$ minutes. (Check: after meeting Fatima needs $36$ more minutes and Joseph $100$, and $\sqrt{36 \times 100} = 60$.)",
  "Averaging the two journey times instead of adding the rates.",
  "C08E-after-meeting-meet-time", "Requires converting arrival clock times into rates and combining them.",
  tita_answer=60, check=_c15, values=[60],
  tita_traps=[(128, "Averages the two journey times, $96$ and $160$ minutes.")],
  cognitive="Application", exams=ALL)


def _c16():
    found = []
    eps = F(1, 10**6)
    for D in range(37, 400):
        ms = _road_meetings(D, 36, D - 36, 2)
        if ms[0][1] == 36 and D - ms[1][1] == 24:
            t = ms[1][0]
            # head-on: the two riders' velocities have opposite signs just before the meeting
            v1 = _bounce(36, D, t, 0) - _bounce(36, D, t - eps, 0)
            v2 = _bounce(D - 36, D, t, D) - _bounce(D - 36, D, t - eps, D)
            if v1 * v2 < 0:
                found.append(D)
    assert len(found) == 1
    return found[0]
q("C08-E-016", MC, "Road length from the first and second meeting points with turnarounds", "Medium",
  "Conceptual/application",
  r"Kabir and Sneha start at the same time from towns P and Q respectively and cycle toward each other along a straight road at constant speeds. Each turns back instantly on reaching the other town and keeps riding at the same speed. They first meet $36$ km from P. The next time they meet, they are again riding toward each other, at a point $24$ km from Q. What is the distance between P and Q?",
  "MCQ",
  r"At the first meeting they have together covered PQ $= d$, and Kabir has covered $36$ km. At the second meeting they have together covered $3d$, so Kabir has covered $3 \times 36 = 108$ km: all the way to Q and $24$ km back. Hence $108 = d + 24$ and $d = 84$ km. (Their speeds are in the ratio $36 : 48 = 3 : 4$, and indeed neither catches the other from behind in between.)",
  "Using $2d$ instead of $3d$ for the combined distance at the second meeting, or measuring the second point from the wrong end.",
  "C08E-repeated-meetings-turnaround", "Needs the $3d$ insight and careful handling of which end each distance is measured from.",
  correct=r"$84$ km",
  distractors=[(r"$66$ km", r"Places the second meeting $24$ km from P instead of Q, so Kabir has ridden $d + (d - 24) = 108$ km."),
               (r"$108$ km", r"Takes Kabir's $3 \times 36 = 108$ km as the length of the road, forgetting the $24$ km he rides back from Q."),
               (r"$60$ km", r"Simply adds the two given distances, $36 + 24$.")],
  check=_c16, values=[84, 66, 108, 60], cognitive="Analysis", exams=ALL)


def _c17():
    t = symbols('t', positive=True)  # hours after 7:00
    t25 = solve(Eq(20 * t, 25 * (t - F(1, 2))), t)[0]
    t30 = solve(Eq(20 * t, 30 * (t - F(1, 2))), t)[0]
    return 60 * (t25 - t30)
q("C08-E-017", MC, "Effect of a higher chasing speed on the catch-up time after a delayed start", "Medium",
  "Multi-step word problem",
  r"Ravi leaves a town at $7{:}00$ am and cycles along a straight road at a constant $20$ km/h. Meera leaves the same town at $7{:}30$ am and follows him along the same road. Riding at a constant $25$ km/h she would catch up with him at a certain time. Had she instead ridden at a constant $30$ km/h, how many minutes earlier would she have caught up with him?",
  "MCQ",
  r"At $7{:}30$ am Ravi is $10$ km ahead. At $25$ km/h Meera gains $5$ km/h and needs $2$ hours, catching him at $9{:}30$ am. At $30$ km/h she gains $10$ km/h and needs only $1$ hour, catching him at $8{:}30$ am. That is $60$ minutes earlier: doubling the relative speed halves the chase.",
  "Keeping the old catch-up point, or scaling time by the ratio of actual speeds instead of relative speeds.",
  "C08E-chase-delayed-start", "Two chase scenarios compared; tempting proportional shortcuts give wrong values.",
  correct=r"$60$ minutes",
  distractors=[(r"$20$ minutes", r"Keeps the original catch-up point $50$ km from town: $\frac{50}{25} - \frac{50}{30} = \frac{1}{3}$ hour."),
               (r"$24$ minutes", r"Assumes a $20\%$ rise in her speed cuts the $2$ hour chase by $20\%$."),
               (r"$4$ minutes", r"Compares only the times to ride the $10$ km lead at each speed, $\frac{10}{25} - \frac{10}{30} = \frac{1}{15}$ hour, ignoring that Ravi keeps moving.")],
  check=_c17, values=[60, 20, 24, 4], cognitive="Analysis", exams=ALL)


def _c18():
    # t in hours after 2:00 pm
    thief = lambda t: 30 * min(t, F(1)) + 6 * max(F(0), t - 1)
    jeep = lambda t: 36 * max(F(0), t - F(1, 2))
    t = _first_zero(lambda s: jeep(s) - thief(s), [F(1, 2), F(1)], F(1, 2), 10)
    return _hm(14) + 60 * t
q("C08-E-018", MC, "Chase in which the fugitive switches from cycling to walking before being caught", "Medium",
  "Multi-step word problem",
  r"A thief rides off on a stolen bicycle at $2{:}00$ pm at a constant $30$ km/h along a straight road. At $3{:}00$ pm he abandons the bicycle and continues in the same direction on foot at a constant $6$ km/h. A police jeep leaves the same spot at $2{:}30$ pm and follows him along the same road at a constant $36$ km/h. At what time does the jeep catch him?",
  "MCQ",
  r"At $3{:}00$ pm the thief is $30$ km out and the jeep, after half an hour, is $18$ km out, so it has not caught him yet. From then on the jeep gains $36 - 6 = 30$ km/h on the walking thief and closes the $12$ km gap in $\frac{12}{30}$ hour $= 24$ minutes. The jeep catches him at $3{:}24$ pm, $32.4$ km from the start.",
  "Treating the fugitive's speed as fixed for the whole chase, or ignoring his walking after he leaves the bicycle.",
  "C08E-chase-mode-change", "Two phases: check that no catch happens in the first phase, then a relative-speed chase in the second.",
  correct=r"$3{:}24$ pm",
  distractors=[(r"$5{:}00$ pm", r"Ignores the switch to walking: the $15$ km lead at $2{:}30$ pm closed at $36 - 30 = 6$ km/h takes $2.5$ hours."),
               (r"$3{:}20$ pm", r"Treats the thief as standing still after $3{:}00$ pm: the $12$ km gap at $36$ km/h takes $20$ minutes."),
               (r"$2{:}54$ pm", r"Correctly finds the final $24$ minutes of chasing but counts them from the jeep's start at $2{:}30$ pm.")],
  check=_c18, values=[_hm(15, 24), _hm(17), _hm(15, 20), _hm(14, 54)], cognitive="Application", exams=ALL)


def _c19():
    thief, cop, steps = F(60), F(0), 0     # distances in thief-steps
    cop_step = F(4, 3)
    while cop < thief:
        thief += 5
        cop += 4 * cop_step
        steps += 4
    assert cop == thief
    return steps
q("C08-E-019", MC, "Chase measured in steps: different step rates and step lengths", "Difficult",
  "Multi-step word problem",
  r"A policeman spots a thief who is $60$ of the thief's own steps ahead, and both start running at the same instant along a straight road. While the thief takes $5$ steps the policeman takes $4$, and $3$ of the policeman's steps cover the same distance as $4$ of the thief's. If both keep these rates and step lengths, how many steps does the policeman take to catch the thief?",
  "TITA",
  r"Measure distance in thief-steps; one policeman-step is $\frac{4}{3}$ thief-steps. In the time the policeman takes $4$ steps he covers $\frac{16}{3}$ thief-steps while the thief covers $5$, so he gains $\frac{1}{3}$ thief-step. To gain $60$ thief-steps he needs $60 \times 3 = 180$ such intervals, that is $180 \times 4 = 720$ steps.",
  "Mixing the two units (step rate and step length) or reporting the number of intervals or the thief's steps.",
  "C08E-chase-steps-ratio", "Step rate and step length must be fused into a speed ratio in one unit, the lead is in the thief's unit and the answer in the policeman's; three conversions where any slip gives a trap value.",
  tita_answer=720, check=_c19, values=[720],
  tita_traps=[(180, r"Reports the number of $4$-step intervals."),
              (900, r"Reports the thief's steps, $180 \times 5$.")],
  cognitive="Analysis", exams=HARD)


def _c20():
    pos, t, rests = F(0), F(0), 0
    while pos < 60:
        pos += 12
        t += F(12, 18) * 60
        if pos < 60:
            t += 10
            rests += 1
    return t
q("C08-E-020", SP, "Journey time with a fixed rest after every fixed distance (fencepost count)", "Medium",
  "Casework/optimisation",
  r"Joseph cycles at a constant $18$ km/h and rests for $10$ minutes after every $12$ km that he rides, except that he does not rest after reaching his destination. How long does he take, including rests, to ride $60$ km from his start?",
  "MCQ",
  r"His riding time is $\frac{60}{18} = 3\frac{1}{3}$ hours $= 3$ hours $20$ minutes. He rests after $12$, $24$, $36$ and $48$ km; no rest is counted after the $60$th km because he has arrived. Four rests add $40$ minutes, so the total is $4$ hours.",
  "Counting a rest at the destination (an off-by-one in the number of rests).",
  "C08E-rest-after-fixed-distance", "Fencepost counting of stops on top of a plain time computation.",
  correct=r"$4$ hours",
  distractors=[(r"$4$ hours $10$ minutes", r"Counts $\frac{60}{12} = 5$ rests, including one after arriving."),
               (r"$3$ hours $20$ minutes", r"Ignores the rests."),
               (r"$3$ hours $50$ minutes", r"Takes one rest after each full hour of riding, $3$ rests in all.")],
  check=_c20, values=[240, 250, 200, 230], cognitive="Application", exams=ALL)


def _c21():
    b, w, T = symbols('b w T', positive=True)
    s = b * T
    sol = solve([Eq(s, 10 * (b + w)), Eq(s, 15 * (b - w)), Eq(b, 1)], [b, w, T], dict=True)[0]
    return sol[T]
q("C08-E-021", SP, "Departure interval from the meeting and overtaking intervals seen by a walker", "Medium",
  "Conceptual/application",
  r"Buses run in both directions along a straight road between two depots, all at the same constant speed, and leave each depot at the same regular interval. Kabir walks along the road at a constant speed. A bus coming toward him passes him every $10$ minutes, and a bus from behind overtakes him every $15$ minutes. At what interval do buses leave each depot?",
  "MCQ",
  r"Let the bus speed be $b$, Kabir's speed $w$ and the spacing between buses $s = bT$. Then $s = 10(b + w)$ and $s = 15(b - w)$, so $b + w = \frac{s}{10}$ and $b - w = \frac{s}{15}$. Adding, $2b = s\left(\frac{1}{10} + \frac{1}{15}\right) = \frac{s}{6}$, so $T = \frac{s}{b} = 12$ minutes, the harmonic mean of $10$ and $15$.",
  "Using the arithmetic mean of the two intervals.",
  "C08E-buses-both-directions", "Two relative-speed equations must be combined; the shortcut is a harmonic mean.",
  correct=r"$12$ minutes",
  distractors=[(r"$12.5$ minutes", r"Takes the arithmetic mean of $10$ and $15$."),
               (r"$6$ minutes", r"Computes $\frac{10 \times 15}{10 + 15}$, the harmonic mean without the factor $2$."),
               (r"$15$ minutes", r"Treats Kabir as stationary and takes the overtaking interval as the departure interval.")],
  check=_c21, values=[12, F(25, 2), 6, 15], cognitive="Analysis", exams=ALL)


def _c22():
    v = symbols('v', positive=True)
    return solve(Eq(v * F(10, 60), (v - 12) * F(15, 60)), v)[0]
q("C08-E-022", SP, "Bus speed from departure interval and the interval at which a cyclist is overtaken", "Medium",
  "Inverse/parameter",
  r"Buses leave a depot every $10$ minutes and travel along a straight road at the same constant speed. A cyclist riding along that road at a constant $12$ km/h, in the same direction as the buses, is overtaken by a bus every $15$ minutes. What is the speed of the buses, in km/h?",
  "TITA",
  r"Let the bus speed be $v$ km/h; consecutive buses are $\frac{10v}{60} = \frac{v}{6}$ km apart. Each bus gains on the cyclist at $v - 12$ km/h and closes that gap in $\frac{1}{4}$ hour, so $\frac{v}{6} = \frac{v - 12}{4}$, giving $4v = 6v - 72$ and $v = 36$ km/h.",
  "Swapping the roles of the departure interval and the overtaking interval in the formula.",
  "C08E-buses-overtake-interval", "Set up the spacing in terms of the unknown speed and equate two expressions.",
  tita_answer=36, check=_c22, values=[36],
  tita_traps=[(24, r"Uses $v = \frac{12 \times 10}{15 - 10}$, putting the departure interval where the overtaking interval belongs."),
              (18, r"Takes the spacing as the cyclist's $3$ km in $15$ minutes and lets a bus cover it in $10$ minutes.")],
  cognitive="Application", exams=ALL)


def _c23():
    L = F(1)
    start, dur = _hm(9), 180
    count = 0
    for d in range(_hm(5), _hm(21) + 1, 30):
        # our bus from P: x = (t - start)/dur ; bus from Q: x = 1 - (t - d)/dur  (fraction of PQ from P)
        t = symbols('t')
        tm = solve(Eq((t - start) / F(dur), L - (t - d) / F(dur)), t)[0]
        if start < tm < start + dur and d < tm < d + dur:
            count += 1
    return count
q("C08-E-023", SP, "Counting opposite-direction buses met on the road between terminals", "Medium",
  "Casework/optimisation",
  r"Buses leave town P for town Q every $30$ minutes from $5{:}00$ am to $9{:}00$ pm, and buses leave Q for P on the same schedule. Every bus takes exactly $3$ hours for the trip in either direction, along the same road. How many buses from Q does the bus that leaves P at $9{:}00$ am pass on the road, not counting any bus it meets at a terminus?",
  "TITA",
  r"Our bus is on the road from $9{:}00$ am to $12{:}00$ noon, and two buses heading toward each other on the same road at overlapping times must cross. A bus from Q is on the road for the $3$ hours after it departs, so the overlap needs a departure after $6{:}00$ am and before $12{:}00$ noon. The bus leaving Q at $6{:}00$ am reaches P just as ours departs and the one leaving at noon departs just as ours arrives; both are terminus meetings. That leaves departures from $6{:}30$ am to $11{:}30$ am: $11$ buses.",
  "Counting only buses that depart during one's own trip, or including the two terminus meetings.",
  "C08E-buses-met-count", "Counting with careful endpoints over a time window.",
  tita_answer=11, check=_c23, values=[11],
  tita_traps=[(13, "Includes the two buses met at the termini."),
              (6, r"Counts only buses leaving Q from $9{:}00$ am to $11{:}30$ am, during its own trip.")],
  cognitive="Analysis", exams=ALL)


def _c24():
    t = symbols('t', positive=True)  # hours after Meera starts
    t0 = solve(Eq(12 * t + 8 * t, 60), t)[0]
    x0 = 12 * t0
    t1 = solve(Eq(12 * (t - F(1, 2)) + 8 * t, 60), t)[0]
    x1 = 12 * (t1 - F(1, 2))
    return x0 - x1
q("C08-E-024", MC, "Shift in the meeting point when one rider starts half an hour late", "Medium",
  "Conceptual/application",
  r"Towns P and Q are $60$ km apart. Ravi rides from P toward Q at a constant $12$ km/h and Meera rides from Q toward P at a constant $8$ km/h. If they start together, they meet at a certain point. If instead Ravi starts $30$ minutes after Meera, how far from that earlier meeting point do they meet?",
  "MCQ",
  r"Starting together they meet $60 \times \frac{12}{20} = 36$ km from P. With the delay, Meera rides $4$ km alone; the remaining $56$ km is then shared in the ratio $12 : 8$, so Ravi covers $33.6$ km. The meeting point moves $36 - 33.6 = 2.4$ km toward P. (Shortcut: the shift is Meera's $4$ km head start times Ravi's share, $4 \times \frac{12}{20}$.)",
  "Assuming the meeting point moves by the whole head-start distance.",
  "C08E-meeting-point-shift", "Needs the idea that a head start is itself shared in the speed ratio.",
  correct=r"$2.4$ km",
  distractors=[(r"$4$ km", r"Assumes the point moves by Meera's whole head start of $4$ km."),
               (r"$6$ km", r"Assumes the point moves by the $6$ km Ravi would have ridden in $30$ minutes."),
               (r"$1.6$ km", r"Splits Meera's $4$ km head start with her own share, $4 \times \frac{8}{20}$.")],
  check=_c24, values=[F(12, 5), 4, 6, F(8, 5)], cognitive="Analysis", exams=ALL)


def _c25():
    r, t = symbols('r t', positive=True)
    base = 50 * 10 / (10 + r)                           # meeting point from P, simultaneous start
    tt = solve(Eq(10 * (t + F(1, 2)) + r * t, 50), t)[0]  # t = hours after Ruchi starts
    new = 10 * (tt + F(1, 2))
    sol = [s for s in solve(Eq(new - base, 3), r) if s > 0]
    assert len(sol) == 1
    return sol[0]
q("C08-E-025", MC, "Unknown speed from the shift in meeting point caused by a head start", "Medium",
  "Inverse/parameter",
  r"Towns P and Q are $50$ km apart. Ankit cycles from P toward Q at a constant $10$ km/h and Ruchi cycles from Q toward P at a constant speed. If they start at the same time, they meet at a point R. If Ankit starts $30$ minutes earlier and Ruchi starts at the same time as before, they meet at a point $3$ km closer to Q than R. What is Ruchi's speed, in km/h?",
  "TITA",
  r"Let Ruchi's speed be $r$ km/h. In his head start Ankit rides $5$ km, and the rest of the road is shared in the ratio $10 : r$, so the meeting point moves toward Q by Ruchi's share of those $5$ km: $5 \times \frac{r}{10 + r} = 3$. This gives $5r = 30 + 3r$, so $r = 15$ km/h. (Check: R is $20$ km from P; the new point is $5 + 45 \times \frac{10}{25} = 23$ km from P.)",
  "Assuming the meeting point moves by the whole head-start distance or dividing the shift by the delay.",
  "C08E-meeting-point-shift", "Reverse use of the head-start shift, giving a linear equation in the unknown speed.",
  tita_answer=15, check=_c25, values=[15],
  tita_traps=[(6, r"Divides the $3$ km shift by the half-hour head start.")],
  cognitive="Analysis", exams=ALL)


def _c26():
    D = 100
    R = lambda t: 30 * min(t, F(3, 2)) + 30 * max(F(0), t - 2)   # 45 km by t = 1.5, stopped until t = 2
    M = lambda t: D - 20 * t
    t = _first_zero(lambda s: R(s) - M(s), [F(3, 2), 2], 0, 5)
    return _hm(9) + 60 * t
q("C08-E-026", SP, "One traveller's single stop delays an opposite-direction meeting", "Medium",
  "Multi-step word problem",
  r"Towns P and Q are $100$ km apart. At $9{:}00$ am Ravi leaves P for Q at a constant $30$ km/h and Meera leaves Q for P at a constant $20$ km/h, on the same road. After covering $45$ km, Ravi stops for $30$ minutes and then continues at $30$ km/h. At what time do they meet?",
  "MCQ",
  r"Ravi reaches the $45$ km mark at $10{:}30$ am, when Meera has covered $30$ km; the $25$ km gap is more than Meera can cover during the stop. In the half-hour stop she covers $10$ km, so at $11{:}00$ am the gap is $15$ km, which they close at $50$ km/h in $18$ minutes. They meet at $11{:}18$ am. (Equivalently, the stop delays the no-stop meeting time of $11{:}00$ am by $30 \times \frac{30}{50} = 18$ minutes.)",
  "Adding the whole stop to the meeting time, ignoring that the other person keeps moving.",
  "C08E-stoppage-delays-meeting", "Three phases (both moving, one stopped, both moving) must be tracked.",
  correct=r"$11{:}18$ am",
  distractors=[(r"$11{:}30$ am", r"Adds the whole $30$ minute stop to the no-stop meeting time of $11{:}00$ am."),
               (r"$11{:}00$ am", r"Ignores the stop."),
               (r"$11{:}12$ am", r"Adds $30 \times \frac{20}{50} = 12$ minutes, using Meera's share of the closing speed instead of Ravi's.")],
  check=_c26, values=[_hm(11, 18), _hm(11, 30), _hm(11), _hm(11, 12)], cognitive="Application", exams=ALL)


def _c27():
    k, s = symbols('k s', positive=True)
    sol = solve([Eq(3 * k - 3 * s, 18), Eq(3 * k, F(9, 2) * s)], [k, s], dict=True)[0]
    return 3 * (sol[k] + sol[s])
q("C08-E-027", MC, "Distance from the meeting time, the difference covered and one post-meeting time", "Medium",
  "Inverse/parameter",
  r"Kabir and Sneha start at the same time from towns P and Q respectively and travel toward each other along a straight road at constant speeds. They meet after $3$ hours, at which point Kabir has covered $18$ km more than Sneha. Sneha reaches P $4$ hours $30$ minutes after the meeting. What is the distance between P and Q, in km?",
  "TITA",
  r"Kabir gains $18$ km over Sneha in $3$ hours, so $k - s = 6$. After the meeting Sneha covers Kabir's $3k$ km in $4.5$ hours, so $3k = 4.5s$, that is $k = 1.5s$. Then $0.5s = 6$, so $s = 12$ and $k = 18$ km/h, and PQ $= 3(18 + 12) = 90$ km.",
  "Reporting one traveller's distance to the meeting point instead of the whole distance.",
  "C08E-meeting-distance-difference", "Two equations from two different facts must be set up and solved.",
  tita_answer=90, check=_c27, values=[90],
  tita_traps=[(54, "Gives Kabir's distance to the meeting point."),
              (36, "Gives Sneha's distance to the meeting point.")],
  cognitive="Application", exams=ALL)


def _c28():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(24, (a + b) * 1), Eq(24, (a - b) * 6)], [a, b], dict=True)[0]
    return min(sol[a], sol[b])
q("C08-E-028", MC, "Two speeds from the meeting time and the catch-up time over the same gap", "Medium",
  "Inverse/parameter",
  r"Two cyclists are $24$ km apart on a straight road, each riding at a constant speed. If they start at the same time and ride toward each other, they meet in $1$ hour. If they start at the same time and ride in the same direction, with the faster cyclist behind, the faster one catches the slower one in $6$ hours. What is the speed of the slower cyclist?",
  "MCQ",
  r"Riding toward each other, the sum of the speeds is $\frac{24}{1} = 24$ km/h; riding the same way, the difference is $\frac{24}{6} = 4$ km/h. So the speeds are $\frac{24 + 4}{2} = 14$ km/h and $\frac{24 - 4}{2} = 10$ km/h, and the slower cyclist rides at $10$ km/h.",
  "Reporting the faster speed or the relative speed instead of the slower speed.",
  "C08E-toward-vs-same-direction", "Sum and difference of speeds from two scenarios, then solve.",
  correct=r"$10$ km/h",
  distractors=[(r"$14$ km/h", r"Gives the faster cyclist's speed."),
               (r"$12$ km/h", r"Halves the sum of the speeds, as though the speeds were equal."),
               (r"$4$ km/h", r"Reports the difference of the speeds.")],
  check=_c28, values=[10, 14, 12, 4], cognitive="Application", exams=ALL)


def _c29():
    t = symbols('t', positive=True)  # hours after 8:00
    h = solve(Eq(60 * t + 75 * (t - F(3, 2)), 315), t)[0]
    assert h > F(3, 2)
    return 60 * h
q("C08-E-029", MC, "Meeting point from P when the car from Q starts 90 minutes later", "Medium",
  "Multi-step word problem",
  r"Towns P and Q are $315$ km apart. A car leaves P for Q at $8{:}00$ am at a constant $60$ km/h, and another car leaves Q for P at $9{:}30$ am at a constant $75$ km/h, on the same road. How far from P do they meet?",
  "MCQ",
  r"By $9{:}30$ am the first car has covered $90$ km, leaving $225$ km. The cars close this at $135$ km/h, taking $\frac{225}{135} = \frac{5}{3}$ hours, during which the first car covers another $100$ km. They meet $90 + 100 = 190$ km from P.",
  "Ignoring the staggered start, or dropping the distance covered before the second car starts.",
  "C08E-staggered-start-opposite", "Head start plus a fractional joint time; several places to slip.",
  correct=r"$190$ km",
  distractors=[(r"$140$ km", r"Ignores the staggered start and splits $315$ km in the ratio $60 : 75$."),
               (r"$125$ km", r"Gives the second car's distance, which is measured from Q."),
               (r"$100$ km", r"Forgets the $90$ km covered before $9{:}30$ am.")],
  check=_c29, values=[190, 140, 125, 100], cognitive="Application", exams=ALL)


def _c30():
    t = symbols('t', positive=True)  # hours after 10:00
    tov = solve(Eq(40 * t, 60 * (t - 1)), t)[0]
    stop_at = 60 * (tov + F(1, 2) - 1)
    tr = solve(Eq(40 * t, stop_at), t)[0]
    return 60 * (tr - (tov + F(1, 2)))
q("C08-E-030", MC, "After overtaking, the faster driver stops and waits for the slower one", "Medium",
  "Multi-step word problem",
  r"Ravi leaves a town at $10{:}00$ am and drives along a straight highway at a constant $40$ km/h. Meera leaves the same town at $11{:}00$ am and drives along the same highway at a constant $60$ km/h. Exactly $30$ minutes after overtaking Ravi, Meera stops by the roadside and waits for him. For how many minutes does she wait?",
  "MCQ",
  r"Ravi's $40$ km lead closes at $20$ km/h, so Meera overtakes him at $1{:}00$ pm. In the next $30$ minutes she pulls ahead by $20 \times \frac{1}{2} = 10$ km. Ravi covers those $10$ km at $40$ km/h in $15$ minutes, so she waits $15$ minutes.",
  "Ignoring the slower driver's progress or using the wrong speed to close the final gap.",
  "C08E-catch-up-and-lead", "Catch-up, then a lead built at relative speed, then the gap closed at the follower's own speed.",
  correct=r"$15$ minutes",
  distractors=[(r"$30$ minutes", r"Assumes she waits as long as she drove after overtaking."),
               (r"$10$ minutes", r"Divides the $10$ km gap by Meera's speed of $60$ km/h."),
               (r"$45$ minutes", r"Takes the gap as her full $30$ km in that half hour, ignoring Ravi's progress, and divides by $40$ km/h.")],
  check=_c30, values=[15, 30, 10, 45], cognitive="Application", exams=ALL)


def _c31():
    s, T = symbols('s T', positive=True)  # spacing km, interval minutes
    sol = solve([Eq(s, (30 - 6) * F(15, 60)), Eq(T, s / 30 * 60)], [s, T], dict=True)[0]
    return sol[T]
q("C08-E-031", SP, "Departure interval of buses from the interval at which they overtake a walker", "Medium",
  "Inverse/parameter",
  r"Buses leave a depot at regular intervals and run along a straight road at a constant $30$ km/h. Priya walks along that road, in the same direction as the buses, at a constant $6$ km/h, and a bus overtakes her every $15$ minutes. At what interval, in minutes, do the buses leave the depot?",
  "TITA",
  r"Each bus gains on Priya at $30 - 6 = 24$ km/h, so in $15$ minutes it gains $6$ km: consecutive buses are $6$ km apart. A bus covers $6$ km in $\frac{6}{30}$ hour $= 12$ minutes, which is the departure interval.",
  "Taking the overtaking interval as the departure interval, or using the sum of speeds.",
  "C08E-buses-overtake-interval", "Reverse problem: recover the spacing from the overtaking interval, then convert to time.",
  tita_answer=12, check=_c31, values=[12],
  tita_traps=[(15, "Takes the overtaking interval itself."),
              (18, r"Uses the closing speed $30 + 6 = 36$ km/h: spacing $9$ km, then $\frac{9}{30}$ hour.")],
  cognitive="Application", exams=ALL)


def _c32():
    # simulate the dog leg by leg; its position converges to the walkers' meeting point
    r, p, dog, t = F(0), F(18), F(0), F(0)
    target = 1  # 1 = running toward Priya
    for _ in range(60):
        if target == 1:
            dt = (p - dog) / (15 + 4)
        else:
            dt = (dog - r) / (15 + 5)
        t += dt; r += 5 * dt; p -= 4 * dt
        dog = p if target == 1 else r
        target = -target
    meet_t = solve(Eq(5 * symbols('x') + 4 * symbols('x'), 18), symbols('x'))[0]
    assert abs(t - meet_t) < F(1, 10**9) and abs(dog - 5 * meet_t) < F(1, 10**9)
    return 5 * meet_t
q("C08-E-032", MC, "Dog running back and forth between two approaching walkers: final position", "Medium",
  "Conceptual/application",
  r"Rohan and Priya are $18$ km apart on a straight road and start walking toward each other at the same moment, at constant speeds of $5$ km/h and $4$ km/h respectively. At that moment Rohan's dog starts running toward Priya at a constant $15$ km/h; each time it reaches one walker it turns back instantly toward the other, and it stops when the two walkers meet. How far from Rohan's starting point is the dog at that moment?",
  "MCQ",
  r"When the walkers meet, the dog is with them, so only the walkers' meeting point matters. They close at $9$ km/h and meet after $2$ hours, $5 \times 2 = 10$ km from Rohan's start. The dog is therefore $10$ km from Rohan's starting point, even though it has run $15 \times 2 = 30$ km in all.",
  "Confusing the total distance run with the final position.",
  "C08E-runner-back-and-forth", "Insight question: the endless back-and-forth reduces to the walkers' meeting point.",
  correct=r"$10$ km",
  distractors=[(r"$30$ km", r"Gives the total distance the dog runs instead of its position."),
               (r"$9$ km", r"Assumes the walkers meet at the midpoint."),
               (r"$8$ km", r"Gives Priya's distance, which is measured from her own start.")],
  check=_c32, values=[10, 30, 9, 8], cognitive="Analysis", exams=ALL)


def _c33():
    a, D = symbols('a D', positive=True)
    sol = solve([Eq(15 * 2 + a * 2, D), Eq(a * 2, F(4, 7) * D)], [a, D], dict=True)[0]
    return sol[D]
q("C08-E-033", MC, "Distance from the fraction of the road covered at the meeting and one speed", "Medium",
  "Multi-step word problem",
  r"Two cyclists start at the same time from towns P and Q and ride toward each other along a straight road at constant speeds. They meet after $2$ hours at a point $\frac{4}{7}$ of the way from P to Q. If the cyclist from Q rides at $15$ km/h, what is the distance between P and Q?",
  "MCQ",
  r"In $2$ hours the cyclist from Q covers $30$ km, which is the remaining $\frac{3}{7}$ of PQ. So PQ $= 30 \times \frac{7}{3} = 70$ km. (The cyclist from P covers the other $40$ km, at $20$ km/h.)",
  "Matching the known distance to the wrong fraction of the road.",
  "C08E-meeting-point-ratio", "Fractions of the road must be matched to the right rider.",
  correct=r"$70$ km",
  distractors=[(r"$52.5$ km", r"Treats the $30$ km covered from Q as $\frac{4}{7}$ of the road."),
               (r"$40$ km", r"Gives the distance covered by the cyclist from P."),
               (r"$210$ km", r"Treats the $30$ km as the $\frac{1}{7}$ of PQ by which the two shares differ, $\frac{4}{7} - \frac{3}{7}$: $30 \times 7$.")],
  check=_c33, values=[70, F(105, 2), 40, 210], cognitive="Application", exams=ALL)


# =====================================================================================
# DIFFICULT
# =====================================================================================

def _c34():
    ms = _road_meetings(24, 15, 9, 3)
    return ms[2][1]
q("C08-E-034", MC, "Third meeting on a road with turnarounds when it is an overtaking, not head-on", "Difficult",
  "Casework/optimisation",
  r"Ravi and Meera start at the same time from the two ends P and Q of a straight $24$ km road, riding toward each other at constant speeds of $15$ km/h and $9$ km/h respectively. Each turns back instantly on reaching an end and keeps riding at the same speed. Counting every occasion on which they are at the same point at the same instant, whether riding toward each other or one catching up with the other from behind, how far from P, in km, are they at their third meeting?",
  "TITA",
  r"First meeting: $24$ km closed at $24$ km/h, so $t = 1$ hour, $15$ km from P. Second: combined distance $3 \times 24 = 72$ km at $t = 3$ hours; Ravi has ridden $45$ km (to Q and $21$ km back), so they meet head-on $3$ km from P. Meera reached P at $t = \frac{24}{9} = 2\frac{2}{3}$ hours and is now riding toward Q; Ravi reaches P at $t = \frac{48}{15} = 3.2$ hours, when Meera is $9 \times \left(3.2 - 2\frac{2}{3}\right) = 4.8$ km from P. Both now ride toward Q and Ravi gains $6$ km/h, catching her after $0.8$ hour at $t = 4$ hours, $15 \times 0.8 = 12$ km from P. This overtaking is the third meeting, before the head-on meeting that the $5 \times 24$ rule predicts at $t = 5$ hours.",
  "Applying the odd-multiples rule for head-on meetings without checking for an overtaking in between.",
  "C08E-repeated-meetings-turnaround", "Requires tracking both riders through turnarounds and spotting an overtaking that the standard rule misses.",
  tita_answer=12, check=_c34, values=[12],
  tita_traps=[(21, r"Applies the head-on rule (combined $5 \times 24 = 120$ km at $t = 5$ hours), missing the overtaking at $t = 4$ hours."),
              (3, "Gives the second meeting point.")],
  cognitive="Analysis", exams=HARD)


def _c35():
    p, qq, t = symbols('p q t', positive=True)
    sol = solve([Eq(1 * p, qq * t), Eq(F(9, 4) * qq, p * t), Eq((p + qq) * t, 150)], [p, qq, t], dict=True)[0]
    P, Q = sol[p], sol[qq]
    s = symbols('s', positive=True)  # hours after the car from P starts
    ts = solve(Eq(P * s + Q * (s + F(1, 2)), 150), s)[0]
    return P * ts
q("C08-E-035", MC, "Post-meeting times give the speeds; then a head start shifts the meeting point", "Difficult",
  "Multi-step word problem",
  r"Two cars start at the same time from towns P and Q, $150$ km apart, and drive toward each other at constant speeds. After they pass each other, the car from P takes $1$ hour to reach Q and the car from Q takes $2$ hours $15$ minutes to reach P. If instead the car from Q had started $30$ minutes before the car from P (with the same speeds), how far from P would they have met?",
  "MCQ",
  r"The speeds are in the ratio $\sqrt{2.25} : \sqrt{1} = 3 : 2$ and they meet after $\sqrt{1 \times 2.25} = 1.5$ hours, so the combined speed is $\frac{150}{1.5} = 100$ km/h: $60$ km/h and $40$ km/h. With the head start, the car from Q covers $20$ km alone, and the remaining $130$ km is shared $3 : 2$, so the car from P covers $78$ km. They meet $78$ km from P (the original point was $90$ km from P).",
  "Ignoring the head start or shifting the meeting point by the wrong share of it.",
  "C08E-after-meeting-speed-ratio", "Three stages: speed ratio, actual speeds via the meeting time, then the head-start shift.",
  correct=r"$78$ km",
  distractors=[(r"$90$ km", r"Ignores the head start and gives the original meeting point."),
               (r"$102$ km", r"Moves the original point $12$ km toward Q instead of toward P."),
               (r"$82$ km", r"Shifts the original point by $20 \times \frac{2}{5} = 8$ km, using the slower car's share.")],
  check=_c35, values=[78, 90, 102, 82], cognitive="Analysis", exams=HARD)


def _c36():
    v, t = symbols('v t', positive=True)  # t: hours after 8:00
    sols = []
    for vv in solve(Eq((2 * v - 15) / (v - 15) - 2 * v / (v - 10), 1), v) + solve(Eq(2 * v / (v - 10) - (2 * v - 15) / (v - 15), 1), v):
        if vv > 15:
            tR = solve(Eq(vv * (t - 2), 10 * t), t)[0]
            tM = solve(Eq(vv * (t - 2), 15 * (t - 1)), t)[0]
            if abs(tR - tM) == 1:
                sols.append(vv)
    assert len(sols) == 1
    return sols[0]
q("C08-E-036", MC, "A third traveller overtakes two earlier starters exactly one hour apart", "Difficult",
  "Inverse/parameter",
  r"Ravi, Meera and Kabir set out from the same point along the same straight road. Ravi leaves at $8{:}00$ am at a constant $10$ km/h, Meera at $9{:}00$ am at a constant $15$ km/h, and Kabir at $10{:}00$ am at a constant speed greater than $15$ km/h. Kabir overtakes Ravi and Meera exactly one hour apart. What is Kabir's speed, in km/h?",
  "TITA",
  r"Measure $t$ in hours after $8{:}00$ am and let Kabir's speed be $v$. He draws level with Ravi when $v(t - 2) = 10t$, at $t_R = \frac{2v}{v - 10}$, and with Meera when $v(t - 2) = 15(t - 1)$, at $t_M = \frac{2v - 15}{v - 15}$. Setting $t_M - t_R = 1$ and clearing denominators gives $v(v - 20) = 0$, so $v = 20$ km/h. (Check: he passes Ravi at $12{:}00$ noon, $40$ km out, and Meera at $1{:}00$ pm, $60$ km out. The other order, Meera first, needs $v > 30$ and then the two overtakings are only minutes apart.)",
  "Assuming the overtakings happen together, or not checking which traveller is caught first.",
  "C08E-third-person-overtakes", "Two catch-up times as functions of an unknown speed; the order of overtaking must be decided.",
  tita_answer=20, check=_c36, values=[20],
  tita_traps=[(30, r"Makes Kabir overtake both at the same instant, at $30$ km at $11{:}00$ am.")],
  cognitive="Analysis", exams=HARD)


def _c37():
    thief = lambda t: 54 * min(t, F(2, 3)) + 54 * max(F(0), t - F(11, 12))   # stops 10:40 to 10:55
    jeep = lambda t: 72 * max(F(0), t - F(1, 3))
    t = _first_zero(lambda s: jeep(s) - thief(s), [F(1, 3), F(2, 3), F(11, 12)], F(1, 3), 5)
    return _hm(10) + 60 * t
q("C08-E-037", MC, "Police chase where the catch happens during the fugitive's refuelling stop", "Difficult",
  "Casework/optimisation",
  r"A thief drives away from a town at $10{:}00$ am at a constant $54$ km/h along a straight highway. A police jeep sets off after him from the same town at $10{:}20$ am at a constant $72$ km/h. At $10{:}40$ am the thief stops for $15$ minutes to refuel and then drives on at $54$ km/h. At what time does the jeep catch the thief?",
  "MCQ",
  r"At $10{:}40$ am the thief is $54 \times \frac{2}{3} = 36$ km out and the jeep is $72 \times \frac{1}{3} = 24$ km out. With the thief stationary, the jeep needs $\frac{12}{72}$ hour $= 10$ minutes to cover the remaining $12$ km, which is within the $15$ minute stop. So the jeep reaches him at $10{:}50$ am, while he is still refuelling.",
  "Treating the stop as a simple time adjustment to the no-stop answer instead of checking when the catch actually happens.",
  "C08E-thief-policeman-gap", "Casework on whether the catch happens before, during or after the stop; shortcuts mislead.",
  correct=r"$10{:}50$ am",
  distractors=[(r"$11{:}20$ am", r"Ignores the stop: the $18$ km lead at $10{:}20$ am closed at $18$ km/h takes $1$ hour."),
               (r"$11{:}05$ am", r"Subtracts the $15$ minute stop from the no-stop answer of $11{:}20$ am."),
               (r"$10{:}35$ am", r"Cuts the $18$ km lead by the $13.5$ km the thief loses while stopped and closes the remaining $4.5$ km at $18$ km/h from $10{:}20$ am, before the stop has begun.")],
  check=_c37, values=[_hm(10, 50), _hm(11, 20), _hm(11, 5), _hm(10, 35)], cognitive="Analysis", exams=HARD)


def _c38():
    bus = lambda t: _halt_pos(60, F(1), F(1, 4), t)        # t hours after 6:00
    car = lambda t: 75 * max(F(0), t - F(3, 2))
    bps = [k * F(5, 4) + e for k in range(12) for e in (0, 1)]
    t = _first_zero(lambda s: car(s) - bus(s), bps, F(3, 2), 20)
    return car(t)
q("C08-E-038", SP, "Car catching a bus that halts for a fixed time after every hour of running", "Difficult",
  "Casework/optimisation",
  r"A bus leaves a depot at $6{:}00$ am and runs along a straight highway at a constant $60$ km/h, but after every full hour of running it halts for exactly $15$ minutes (it runs from $6{:}00$ am to $7{:}00$ am, halts until $7{:}15$ am, runs until $8{:}15$ am, and so on). A car leaves the same depot at $7{:}30$ am and follows the same highway at a constant $75$ km/h without stopping. How far from the depot, in km, does the car catch up with the bus?",
  "TITA",
  r"The bus restarts from $60$ km at $7{:}15$ am, from $120$ km at $8{:}30$ am and from $180$ km at $9{:}45$ am. At $9{:}45$ am the car has run $2.25$ hours, $168.75$ km, so it is $11.25$ km behind (at the earlier halts it was further behind: at $9{:}30$ am it is at $150$ km while the bus waits at $180$ km). From $9{:}45$ am both move and the car gains $15$ km/h, closing $11.25$ km in $0.75$ hour, at $10{:}30$ am, before the bus's next halt at $10{:}45$ am. The car has then gone $75 \times 3 = 225$ km.",
  "Replacing the bus's stop-start motion by its average speed, which gives the wrong catch-up point.",
  "C08E-rest-after-fixed-distance", "Piecewise motion: the catch must be located in the correct running or halting phase.",
  tita_answer=225, check=_c38, values=[225],
  tita_traps=[(200, r"Uses the bus's average speed $48$ km/h: a $72$ km lead at $7{:}30$ am closed at $27$ km/h."),
              (375, r"Uses the bus's true position of $75$ km at $7{:}30$ am but ignores its later halts, closing at $15$ km/h for $5$ hours.")],
  cognitive="Analysis", exams=HARD)


def _c39():
    v, s = symbols('v s', positive=True)
    sol = solve([Eq(s, (v + 18) * F(5, 60)), Eq(s, (v - 18) * F(20, 60))], [v, s], dict=True)[0]
    return sol[s]
q("C08-E-039", SP, "Spacing of buses from the meeting and overtaking intervals seen by a cyclist", "Difficult",
  "Inverse/parameter",
  r"Buses run in both directions along a straight road between two depots, all at the same constant speed, and leave each depot at the same regular interval. Fatima cycles along the road at a constant $18$ km/h. A bus coming toward her passes her every $5$ minutes, and a bus going her way overtakes her every $20$ minutes. How far apart are consecutive buses travelling in the same direction?",
  "MCQ",
  r"Let the bus speed be $v$ km/h and the spacing $s$ km. Then $s = \frac{v + 18}{12}$ and $s = \frac{v - 18}{3}$, so $v + 18 = 4(v - 18)$, giving $v = 30$ km/h and $s = \frac{48}{12} = 4$ km. (Buses leave every $\frac{4}{30}$ hour $= 8$ minutes.)",
  "Taking the spacing as the distance covered by one party in one of the given intervals.",
  "C08E-buses-both-directions", "Two unknowns (speed and spacing) from two relative-speed equations.",
  correct=r"$4$ km",
  distractors=[(r"$6$ km", r"Takes the spacing as the distance Fatima rides in $20$ minutes."),
               (r"$10$ km", r"Takes the spacing as the distance a bus travels in $20$ minutes."),
               (r"$2.5$ km", r"Takes the spacing as the distance a bus travels in $5$ minutes.")],
  check=_c39, values=[4, 6, 10, F(5, 2)], cognitive="Analysis", exams=HARD)


def _c40():
    start, dur, odur = _hm(11), 240, 180
    t = symbols('t')
    count = 0
    for d in range(_hm(5), _hm(22) + 1, 60):
        tm = solve(Eq((t - start) / F(dur), 1 - (t - d) / F(odur)), t)[0]
        if start < tm < start + dur and d < tm < d + odur:
            count += 1
    return count
q("C08-E-040", SP, "Counting buses met when the two directions have different journey times", "Difficult",
  "Casework/optimisation",
  r"Buses leave Pune for Mumbai every hour on the hour from $5{:}00$ am to $10{:}00$ pm, each taking exactly $4$ hours. Buses leave Mumbai for Pune every hour on the hour over the same hours, each taking exactly $3$ hours. All buses use the same road. How many Mumbai-to-Pune buses does the bus that leaves Pune at $11{:}00$ am pass on the road, not counting any bus it meets at either terminus?",
  "MCQ",
  r"Our bus is on the road from $11{:}00$ am to $3{:}00$ pm. A Mumbai bus leaving at hour $d$ is on the road from $d$ to $d + 3$, and two buses heading toward each other on the same road at overlapping times must cross. They overlap if $d + 3 > 11$ and $d < 15$, that is $8 < d < 15$. The bus leaving Mumbai at $8{:}00$ am reaches Pune at $11{:}00$ am as ours departs, and the $3{:}00$ pm bus departs as ours arrives; both are terminus meetings. That leaves departures from $9{:}00$ am to $2{:}00$ pm: $6$ buses.",
  "Using one's own journey time for the other buses, or mishandling the terminus meetings.",
  "C08E-buses-met-count", "Unequal journey times make the counting window asymmetric; endpoints need care.",
  correct=r"$6$",
  distractors=[(r"$8$", r"Includes the two buses met at the termini."),
               (r"$7$", r"Uses its own $4$ hour journey time for the Mumbai buses, so counts departures from $8{:}00$ am to $2{:}00$ pm."),
               (r"$5$", r"Counts the buses leaving Mumbai from $11{:}00$ am to $3{:}00$ pm, during its own trip.")],
  check=_c40, values=[6, 8, 7, 5], cognitive="Analysis", exams=HARD)


def _c41():
    m, j = symbols('m j', positive=True)
    sols = solve([Eq(3 * (m + j), 96), Eq(3 * j * (j + 8), 3 * m * (m - 8))], [m, j], dict=True)
    sols = [s for s in sols if s[m] > 8]
    assert len(sols) == 1
    return sols[0][m]
q("C08-E-041", MC, "Speeds changed after the meeting so that both arrive together", "Difficult",
  "Inverse/parameter",
  r"Meera and Joseph start at the same time from towns P and Q, $96$ km apart, and travel toward each other at constant speeds, meeting after $3$ hours. Immediately after the meeting, Meera reduces her speed by $8$ km/h and Joseph increases his by $8$ km/h, and they then reach Q and P respectively at the same moment. What was Meera's original speed?",
  "MCQ",
  r"Let the speeds be $m$ and $j$; then $3(m + j) = 96$, so $m + j = 32$. After the meeting Meera has $3j$ km to go at $m - 8$ and Joseph has $3m$ km at $j + 8$, so $\frac{3j}{m - 8} = \frac{3m}{j + 8}$, giving $j^2 + 8j = m^2 - 8m$, that is $(m - j)(m + j) = 8(m + j)$ and $m - j = 8$. Hence $m = 20$ km/h and $j = 12$ km/h; after the meeting they have in effect swapped speeds, and each takes $3$ more hours.",
  "Mishandling the factorisation, or assuming equal speeds because they arrive together.",
  "C08E-post-meeting-speed-change", "Nonlinear equation that collapses only after spotting the factorisation.",
  correct=r"$20$ km/h",
  distractors=[(r"$12$ km/h", r"Gives Joseph's original speed."),
               (r"$16$ km/h", r"Assumes equal speeds because they arrive together."),
               (r"$24$ km/h", r"Writes $m - j = 16$, counting the $8$ km/h change twice.")],
  check=_c41, values=[20, 12, 16, 24], cognitive="Analysis", exams=HARD)


def _c42():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(60 * a / (a + b), 36), Eq(b * 1 + (60 - b * 1) * b / (a + b), 30)], [a, b], dict=True)
    sol = [s for s in sol if s[a] > 0 and s[b] > 0]
    assert len(sol) == 1
    return sol[0][a]
q("C08-E-042", MC, "Speeds from two scenarios: simultaneous start and a one-hour delay", "Medium",
  "Inverse/parameter",
  r"Towns P and Q are $60$ km apart. Arjun cycles from P toward Q and Fatima from Q toward P, each at a constant speed. If they start at the same time, they meet $6$ km from the midpoint of PQ, on Q's side. If Arjun starts $1$ hour after Fatima, they meet exactly at the midpoint. What is Arjun's speed?",
  "MCQ",
  r"Starting together, Arjun covers $36$ km while Fatima covers $24$ km, so the speeds are in the ratio $3 : 2$; call them $3k$ and $2k$. With her $1$ hour head start Fatima rides $2k$ km alone, and the remaining $60 - 2k$ km is shared $3 : 2$, so her total is $2k + \frac{2}{5}(60 - 2k) = 30$. This gives $\frac{6k}{5} = 6$, so $k = 5$: Arjun rides at $15$ km/h and Fatima at $10$ km/h.",
  "Assuming the meeting point moves by a whole hour's ride of one cyclist.",
  "C08E-meeting-point-shift", "Two steps: a speed ratio from one scenario, then one linear head-start equation from the other.",
  correct=r"$15$ km/h",
  distractors=[(r"$10$ km/h", r"Gives Fatima's speed."),
               (r"$6$ km/h", r"Assumes the meeting point moves back by Arjun's full hour of riding, so Arjun rides $6$ km in that hour."),
               (r"$9$ km/h", r"Assumes the point moves by Fatima's whole head-start distance, so Fatima rides $6$ km/h and Arjun $9$ km/h.")],
  check=_c42, values=[15, 10, 6, 9], cognitive="Analysis", exams=ALL)


def _c43():
    count = 0
    t = symbols('t')
    for d in range(0, 24 * 60, 10):           # bus departures, minutes after 6:00
        # bus at (t - d)/2 km, Ananya at (t - 5)/10 km, both for t >= start
        tm = solve(Eq((t - d) / F(2), (t - 5) / F(10)), t)[0]
        if tm > max(d, 5) and tm <= 65 and d > 0:
            count += 1
        # a bus that left before her (d = 0) is ahead of her at t = 5 and never meets her
    return count
q("C08-E-043", SP, "Counting buses that overtake a walker within a fixed time window", "Difficult",
  "Casework/optimisation",
  r"Buses leave a depot every $10$ minutes, starting at $6{:}00$ am, and run along a straight road at a constant $30$ km/h. Ananya starts walking from the depot along the same road, in the same direction as the buses, at $6{:}05$ am at a constant $6$ km/h. How many buses overtake her during the first hour of her walk, from $6{:}05$ am to $7{:}05$ am?",
  "MCQ",
  r"Measure $t$ in minutes after $6{:}00$ am. The bus leaving at minute $d$ is $\frac{t - d}{2}$ km out and Ananya is $\frac{t - 5}{10}$ km out, so that bus draws level with her when $5(t - d) = t - 5$, at $t = \frac{5d - 5}{4}$. The $6{:}00$ am bus is already ahead of her and never overtakes. For the others we need $\frac{5d - 5}{4} \le 65$, so $d \le 53$: the buses leaving at $6{:}10$ am, $6{:}20$ am, $6{:}30$ am, $6{:}40$ am and $6{:}50$ am, which is $5$ buses (the $6{:}50$ am bus passes her at $7{:}01{:}15$ am; the $7{:}00$ am bus only at $7{:}13{:}45$ am).",
  "Assuming every bus that leaves during the walk catches her within the window.",
  "C08E-buses-overtake-count-window", "Casework on which departures catch the walker inside a window; endpoint traps.",
  correct=r"$5$",
  distractors=[(r"$6$", r"Counts every bus that leaves during her walk ($6{:}10$ am to $7{:}00$ am), assuming each reaches her in time."),
               (r"$7$", r"Also counts the $6{:}00$ am bus, which is ahead of her from the start."),
               (r"$4$", r"Measures her hour from $6{:}00$ am to $7{:}00$ am, which cuts off the $6{:}50$ am bus.")],
  check=_c43, values=[5, 6, 7, 4], cognitive="Analysis", exams=HARD)


def _c44():
    X = lambda t: _halt_pos(60, F(1), F(1, 6), t)
    Y = lambda t: 210 - 40 * t
    bps = [k * F(7, 6) + e for k in range(6) for e in (0, 1)]
    t = _first_zero(lambda s: X(s) - Y(s), bps, 0, 10)
    return X(t)
q("C08-E-044", SP, "Opposite-direction meeting when one bus halts after every hour of running", "Difficult",
  "Casework/optimisation",
  r"Towns P and Q are $210$ km apart. At $8{:}00$ am bus X leaves P for Q and bus Y leaves Q for P, on the same road. Bus X runs at a constant $60$ km/h but halts for $10$ minutes after every full hour of running; bus Y runs at a constant $40$ km/h without halting. How far from P do the buses meet?",
  "MCQ",
  r"X runs from $8{:}00$ am to $9{:}00$ am (to $60$ km), halts until $9{:}10$ am, runs until $10{:}10$ am (to $120$ km) and halts until $10{:}20$ am. At $10{:}10$ am Y has run $2\frac{1}{6}$ hours, $86\frac{2}{3}$ km, so it is $123\frac{1}{3}$ km from P, just $3\frac{1}{3}$ km from X. Y covers that in $5$ minutes, during X's halt, so they meet at $10{:}15$ am at X's halting point, $120$ km from P.",
  "Ignoring the halts or assuming the meeting happens while both are moving.",
  "C08E-stoppage-delays-meeting", "The meeting must be located in the right phase of a stop-start schedule.",
  correct=r"$120$ km",
  distractors=[(r"$126$ km", r"Ignores X's halts and splits $210$ km in the ratio $60 : 40$."),
               (r"$122$ km", r"Allows for only the first halt: $60\left(t - \frac{1}{6}\right) + 40t = 210$ gives $t = 2.2$ hours and X at $122$ km, though X is halted by then."),
               (r"$90$ km", r"Gives Y's distance, which is measured from Q.")],
  check=_c44, values=[120, 126, 122, 90], cognitive="Analysis", exams=HARD)


def _c45():
    t, k = symbols('t k', positive=True)   # t: hours after 6:00; k = Ravi's speed / Meera's speed
    sol = solve([Eq(k * 1, t - 1), Eq(6, k * t)], [t, k], dict=True)
    sol = [s for s in sol if s[t] > 1]
    assert len(sol) == 1
    return 60 * sol[0][t]
q("C08-E-045", MC, "Meeting time from post-meeting times when the starts are staggered", "Difficult",
  "Inverse/parameter",
  r"Ravi leaves town P for town Q at $6{:}00$ am and Meera leaves Q for P at $7{:}00$ am, along the same road, each at a constant speed. After they meet, Ravi takes $1$ more hour to reach Q and Meera takes $6$ more hours to reach P. How many minutes after $6{:}00$ am do they meet?",
  "TITA",
  r"Let them meet $t$ hours after $6{:}00$ am, so Ravi has ridden $t$ hours and Meera $t - 1$ hours; let Ravi's speed be $k$ times Meera's. After the meeting each covers what the other covered before it: Ravi's $1$ hour equals Meera's $t - 1$ hours, so $k = t - 1$; Meera's $6$ hours equal Ravi's $t$ hours, so $6 = kt$. Hence $t(t - 1) = 6$, so $t = 3$: they meet at $9{:}00$ am, $180$ minutes after $6{:}00$ am, with Ravi twice as fast.",
  "Applying $\\sqrt{t_1 t_2}$, which holds only for a simultaneous start, or measuring time from the later start.",
  "C08E-after-meeting-meet-time", "The standard square-root rule fails; the relations must be rebuilt with the stagger.",
  tita_answer=180, check=_c45, values=[180],
  tita_traps=[(120, r"Gives the time after Meera's start, or attaches the one-hour delay to Ravi so that $t(t + 1) = 6$.")],
  cognitive="Analysis", exams=HARD)
