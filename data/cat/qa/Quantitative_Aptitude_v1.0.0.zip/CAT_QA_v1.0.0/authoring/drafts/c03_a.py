import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

import datetime

F = Fraction
T = "Simple interest"
CX = ("CAT", "XAT")


def _si(p, r, t):
    """Simple interest on p at r percent per annum for t years (exact)."""
    c = lambda v: Rational(v.numerator, v.denominator) if isinstance(v, Fraction) else sympify(v)
    return c(p) * c(r) * c(t) / 100


# ---------------------------------------------------------------- EASY (11)

def _e1():
    p, r = 12500, 8
    t = 3 + F(6, 12)
    return p + _si(p, r, t)
q("C03-A-001", T, "Amount after a period given in years and months", "Easy",
  "Multi-step word problem",
  r"Meera deposits Rs. $12{,}500$ in a savings scheme that pays simple interest at $8\%$ per annum. If she withdraws the deposit together with all the interest after $3$ years $6$ months, how much does she receive?",
  "MCQ",
  r"Time $= 3\frac{1}{2}$ years. Interest $= 12500 \times \frac{8}{100} \times \frac{7}{2} = 1000 \times 3.5 = 3500$. She receives $12500 + 3500 =$ Rs. $16{,}000$.",
  "Reading $3$ years $6$ months as $3.6$ years, or reporting the interest instead of the amount.",
  "C03A-si-formula-direct", "One application of the simple interest formula with a months-to-years conversion.",
  correct=r"Rs. $16{,}000$",
  distractors=[(r"Rs. $3{,}500$", r"Reports only the interest $12500 \times 0.08 \times 3.5 = 3500$, not the amount."),
               (r"Rs. $15{,}500$", r"Ignores the $6$ months: $12500 + 12500 \times 0.08 \times 3 = 15500$."),
               (r"Rs. $16{,}100$", r"Treats $3$ years $6$ months as $3.6$ years: $12500 + 1000 \times 3.6 = 16100$.")],
  check=_e1, values=[16000, 3500, 15500, 16100], cognitive="Application")


def _e2():
    d0, d1 = datetime.date(2026, 3, 12), datetime.date(2026, 6, 5)
    days = (d1 - d0).days            # excludes day of borrowing, includes day of repayment
    return _si(36500, 10, F(days, 365))
q("C03-A-002", T, "Interest for an exact number of days between two dates", "Easy",
  "Single-step computation",
  r"Kabir borrows Rs. $36{,}500$ on $12$ March and repays it on $5$ June of the same year, at simple interest of $10\%$ per annum. Interest is charged for each day, counting the day of repayment but not the day of borrowing, and a year is taken as $365$ days. How much interest, in rupees, does he pay?",
  "TITA",
  r"Days: $19$ in March (13th to 31st), $30$ in April, $31$ in May and $5$ in June, a total of $85$ days. Interest $= 36500 \times \frac{10}{100} \times \frac{85}{365} = 10 \times 85 = 850$.",
  "Counting both the first and the last day, or miscounting the days in a month.",
  "C03A-days-count-interest", "One day count across months and one multiplication; the trap is the day-counting convention.",
  tita_answer=850, check=_e2,
  tita_traps=[(860, r"Counts both $12$ March and $5$ June, using $86$ days."),
              (840, r"Excludes both end days, using $84$ days.")],
  cognitive="Application")


def _e3():
    r = symbols('r', positive=True)
    return solve(Eq(5000 + 5000 * r / 100 * Rational(5, 2), 6500), r)[0]
q("C03-A-003", T, "Rate from principal, amount and a period in years and months", "Easy",
  "Inverse/parameter",
  r"A sum of Rs. $5{,}000$ invested at simple interest grows to Rs. $6{,}500$ in $2$ years $6$ months. What is the rate of interest per annum?",
  "MCQ",
  r"Interest $= 6500 - 5000 = 1500$ over $2.5$ years, that is $600$ per year. Rate $= \frac{600}{5000} \times 100 = 12\%$ per annum.",
  "Dropping the $6$ months or forgetting to divide by the time.",
  "C03A-si-formula-direct", "Single formula rearranged for the rate; the trap is the fractional time.",
  correct=r"$12\%$",
  distractors=[(r"$15\%$", r"Uses $2$ years: $\frac{1500}{5000 \times 2} = 15\%$."),
               (r"$10\%$", r"Rounds the time up to $3$ years: $\frac{1500}{5000 \times 3} = 10\%$."),
               (r"$30\%$", r"Does not divide by the time: $\frac{1500}{5000} = 30\%$.")],
  check=_e3, values=[12, 15, 10, 30], cognitive="Application")


def _e4():
    m = 0
    while True:
        m += 1
        if 3200 + _si(3200, F(15, 2), F(m, 12)) >= 3680:
            return m
q("C03-A-004", T, "Time in months for a sum to reach a target amount", "Easy",
  "Inverse/parameter",
  r"Fatima deposits Rs. $3{,}200$ at simple interest of $7.5\%$ per annum. After how many months will her deposit amount to Rs. $3{,}680$?",
  "TITA",
  r"Interest needed $= 3680 - 3200 = 480$. Interest per year $= 3200 \times 0.075 = 240$, so the time is $\frac{480}{240} = 2$ years $= 24$ months.",
  "Answering in years when months are asked for.",
  "C03A-si-formula-direct", "One subtraction and one division, then a unit change.",
  tita_answer=24, check=_e4,
  tita_traps=[(2, "Enters the time in years instead of months."),
              (184, r"Forgets to subtract the principal: one month's interest is $\frac{3200 \times 0.075}{12} = 20$, and $\frac{3680}{20} = 184$.")],
  cognitive="Application")


def _e5():
    r = F(25, 5)                      # percent per year from 25% growth in 5 years
    t = symbols('t', positive=True)
    return solve(Eq(1 + r * t / 100, F(5, 2)), t)[0]
q("C03-A-005", T, "Time for a sum to become a given multiple from a known growth", "Easy",
  "Conceptual/application",
  r"A sum invested at simple interest grows by $25\%$ in $5$ years. In how many years from the start will the amount become $2.5$ times the sum?",
  "TITA",
  r"The interest is $5\%$ of the sum per year. To become $2.5$ times, the interest must be $150\%$ of the sum, which takes $\frac{150}{5} = 30$ years.",
  r"Treating '$2.5$ times' as $250\%$ interest, or scaling the time in proportion to the amount.",
  "C03A-n-fold-growth", "One rate and one division; the trap is amount versus interest.",
  tita_answer=30, check=_e5,
  tita_traps=[(50, r"Takes the required interest as $250\%$: $\frac{250}{5} = 50$."),
              (10, r"Scales the time with the amount: $5 \times \frac{2.5}{1.25} = 10$.")],
  cognitive="Understanding")


def _e6():
    p, i = symbols('p i', positive=True)
    s = solve([Eq(p + 3 * i, 9440), Eq(p + 5 * i, 10400)], [p, i], dict=True)[0]
    return s[p]
q("C03-A-006", T, "Principal from amounts after two different periods", "Easy",
  "Multi-step word problem",
  r"A sum lent at simple interest amounts to Rs. $9{,}440$ after $3$ years and to Rs. $10{,}400$ after $5$ years. What is the sum?",
  "MCQ",
  r"The extra $2$ years earn $10400 - 9440 = 960$, so one year's interest is $480$. Three years' interest is $1440$, so the sum is $9440 - 1440 =$ Rs. $8{,}000$.",
  "Not dividing the difference by the number of extra years, or subtracting the wrong number of years' interest.",
  "C03A-two-amounts-two-periods", "Two subtractions and a division; the trap is the year count.",
  correct=r"Rs. $8{,}000$",
  distractors=[(r"Rs. $8{,}960$", r"Subtracts only one year's interest from the $3$-year amount: $9440 - 480$."),
               (r"Rs. $8{,}480$", r"Subtracts two years' interest from the $3$-year amount: $9440 - 960$."),
               (r"Rs. $6{,}560$", r"Takes $960$ as one year's interest and subtracts three years of it: $9440 - 2880$.")],
  check=_e6, values=[8000, 8960, 8480, 6560], cognitive="Application")


def _e7():
    r = symbols('r', positive=True)          # Kabir's rate
    return solve(Eq(_si(12000, 8, 3) + _si(8000, 1, 2) * r, 4320), r)[0]
q("C03-A-007", T, "Unknown rate on one of two loans with different periods from the total interest", "Easy",
  "Inverse/parameter",
  r"Ravi lends Rs. $12{,}000$ to Meera at $8\%$ per annum simple interest for $3$ years, and Rs. $8{,}000$ to Kabir at simple interest for $2$ years at some other rate per annum. The total interest he receives from the two loans is Rs. $4{,}320$. At what rate per annum did Kabir borrow?",
  "MCQ",
  r"Meera pays $12000 \times 0.08 \times 3 = 2880$, so Kabir pays $4320 - 2880 = 1440$ in $2$ years, that is $720$ a year. His rate is $\frac{720}{8000} \times 100 = 9\%$ per annum.",
  "Using the wrong period for one of the two loans.",
  "C03A-unknown-rate-two-loans", "One subtraction and one division; the trap is matching each loan with its own period.",
  correct=r"$9\%$",
  distractors=[(r"$18\%$", r"Does not divide Kabir's interest by his $2$ years: $\frac{1440}{8000} = 18\%$."),
               (r"$6\%$", r"Uses Meera's $3$ years for Kabir's loan as well: $\frac{1440}{8000 \times 3} = 6\%$."),
               (r"$21\%$", r"Subtracts only one year of Meera's interest: $\frac{4320 - 960}{8000 \times 2} = 21\%$.")],
  check=_e7, values=[9, 18, 6, 21], cognitive="Application")


def _e8():
    r = symbols('r', positive=True)
    return solve(Eq(_si(4000, 1, 1) * r * r, 2560), r)[0]
q("C03-A-008", T, "Rate when the rate percent equals the number of years", "Easy",
  "Inverse/parameter",
  r"Sneha lends Rs. $4{,}000$ at simple interest and receives Rs. $2{,}560$ as interest. The number of years for which she lent the money is numerically equal to the rate of interest per annum. What is the rate of interest, in percent per annum?",
  "TITA",
  r"With rate $r\%$ for $r$ years, $4000 \times \frac{r \times r}{100} = 2560$, so $r^2 = 64$ and $r = 8$.",
  "Halving the product instead of taking its square root.",
  "C03A-rate-equals-time", "One equation in one unknown that needs a square root.",
  tita_answer=8, check=_e8,
  tita_traps=[(64, r"Stops at $r^2 = 64$."),
              (32, r"Halves $64$ instead of taking the square root.")],
  cognitive="Application")


def _e9():
    p = symbols('p', positive=True)
    return solve(Eq(_si(1, 9, 3) * p - _si(1, 7, 3) * p, 540), p)[0]
q("C03-A-009", T, "Principal from the extra interest a higher rate would give", "Easy",
  "Inverse/parameter",
  r"Arjun invested a sum for $3$ years at $7\%$ per annum simple interest. Had the rate been $9\%$ per annum, he would have earned Rs. $540$ more in interest over the same $3$ years. How much did he invest?",
  "MCQ",
  r"The extra $2\%$ per year for $3$ years is $6\%$ of the sum, so $0.06 \times P = 540$ and $P =$ Rs. $9{,}000$.",
  "Ignoring the time, or treating the extra interest as the whole interest at the higher rate.",
  "C03A-rate-difference-extra-interest", "One equation from the rate difference; the trap is the time factor.",
  correct=r"Rs. $9{,}000$",
  distractors=[(r"Rs. $27{,}000$", r"Ignores the $3$ years: $\frac{540}{0.02} = 27000$."),
               (r"Rs. $2{,}000$", r"Treats $540$ as the full interest at $9\%$ for $3$ years: $\frac{540}{0.27} = 2000$."),
               (r"Rs. $6{,}000$", r"Treats Rs. $540$ as one year's interest at the higher rate: $\frac{540}{0.09} = 6000$.")],
  check=_e9, values=[9000, 27000, 2000, 6000], cognitive="Application")


def _e10():
    p, t = 25000, 4
    received = _si(p, F(21, 2), t)
    paid = _si(p, 7, t)
    return received - paid
q("C03-A-010", T, "Gain from borrowing at one rate and lending at a higher rate", "Easy",
  "Single-step computation",
  r"Harpreet borrows Rs. $25{,}000$ at $7\%$ per annum simple interest and immediately lends the whole amount at $10.5\%$ per annum simple interest. What is his gain at the end of $4$ years?",
  "MCQ",
  r"His gain is the rate difference of $3.5\%$ per year on Rs. $25{,}000$, that is $875$ per year. Over $4$ years he gains $875 \times 4 =$ Rs. $3{,}500$.",
  "Reporting the interest received or paid instead of the difference, or forgetting the time.",
  "C03A-borrow-lend-gain", "One rate difference applied for a given time.",
  correct=r"Rs. $3{,}500$",
  distractors=[(r"Rs. $10{,}500$", r"Reports the interest received: $25000 \times 0.105 \times 4$."),
               (r"Rs. $7{,}000$", r"Reports the interest paid: $25000 \times 0.07 \times 4$."),
               (r"Rs. $875$", r"Finds only one year's gain: $25000 \times 0.035$.")],
  check=_e10, values=[3500, 10500, 7000, 875], cognitive="Application")


def _e11():
    r = symbols('r', positive=True)
    p = 100
    a = p + _si(p, 1, 5) * r
    return solve(Eq(_si(p, 1, 5) * r, a / 5), r)[0]
q("C03-A-011", T, "Rate when the interest is a given fraction of the amount", "Easy",
  "Conceptual/application",
  r"After $5$ years, the simple interest on a deposit is one-fifth of the amount (principal plus interest) at that time. What is the rate of interest per annum?",
  "MCQ",
  r"If the interest is $\frac{1}{5}$ of the amount, the principal is $\frac{4}{5}$ of it, so the interest is $\frac{1}{4}$ of the principal, that is $25\%$ in $5$ years. The rate is $\frac{25}{5} = 5\%$ per annum.",
  "Taking the fraction of the amount as a fraction of the principal.",
  "C03A-interest-fraction-of-amount", "One ratio conversion and one division; the trap is amount versus principal.",
  correct=r"$5\%$",
  distractors=[(r"$4\%$", r"Takes the interest as $\frac{1}{5}$ of the principal: $\frac{20}{5} = 4\%$."),
               (r"$20\%$", r"Takes $\frac{1}{5}$ of the principal as the interest and does not divide by $5$ years."),
               (r"$25\%$", r"Finds the interest is $25\%$ of the principal but does not divide by $5$ years.")],
  check=_e11, values=[5, 4, 20, 25], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM (15)

def _m1():
    p, r = symbols('p r', positive=True)
    s = solve([Eq(p * (1 + 2 * r / 100), 10000), Eq(p * (1 + 5 * r / 100), 13000)], [p, r], dict=True)[0]
    return s[r]
q("C03-A-012", T, "Rate from amounts after two different periods", "Medium",
  "Multi-step word problem",
  r"A sum lent at simple interest amounts to Rs. $10{,}000$ after $2$ years and to Rs. $13{,}000$ after $5$ years. What is the rate of interest per annum?",
  "MCQ",
  r"The $3$ extra years earn $3000$, so the interest is $1000$ per year. The sum is $10000 - 2 \times 1000 = 8000$, and the rate is $\frac{1000}{8000} \times 100 = 12.5\%$.",
  "Using the first amount as the principal when finding the rate.",
  "C03A-two-amounts-two-periods", "Needs the yearly interest, then the principal, then the rate; the tempting base is the first amount.",
  correct=r"$12.5\%$",
  distractors=[(r"$10\%$", r"Divides the yearly interest $1000$ by the $2$-year amount $10000$ as if it were the principal."),
               (r"$30\%$", r"Divides the $3$-year increase $3000$ by $10000$ and does not divide by $3$ years."),
               (r"$37.5\%$", r"Finds the principal $8000$ but divides the $3$-year increase $3000$ by it without dividing by $3$.")],
  check=_m1, values=[F(25, 2), 10, 30, F(75, 2)], cognitive="Application")


def _m2():
    r1 = F(200, 20)                    # triples in 20 years
    r2 = r1 + F(5, 2)
    t = symbols('t', positive=True)
    return solve(Eq(1 + r2 * t / 100, 4), t)[0]
q("C03-A-013", T, "Time for a sum to become four times at a raised rate", "Medium",
  "Conceptual/application",
  r"At a certain rate of simple interest, any sum becomes $3$ times itself in $20$ years. At a rate $2.5$ percentage points higher, in how many years would a sum become $4$ times itself?",
  "TITA",
  r"Becoming $3$ times means interest of $200\%$ in $20$ years, so the rate is $10\%$. The new rate is $12.5\%$. Becoming $4$ times needs $300\%$ interest, which takes $\frac{300}{12.5} = 24$ years.",
  r"Treating 'becomes $n$ times' as $n \times 100\%$ interest.",
  "C03A-n-fold-growth", "Two linked n-fold conversions with a rate change in between.",
  tita_answer=24, check=_m2,
  tita_traps=[(32, r"Takes '$4$ times' as $400\%$ interest: $\frac{400}{12.5} = 32$."),
              (30, r"Keeps the old rate $10\%$: $\frac{300}{10} = 30$.")],
  cognitive="Application")


def _m3():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(x + y, 33000), Eq(x + _si(x, 8, 3), y + _si(y, 8, 5))], [x, y], dict=True)[0]
    return s[x]
q("C03-A-014", T, "Splitting a sum so that amounts after different periods are equal", "Medium",
  "Multi-step word problem",
  r"Priya divides Rs. $33{,}000$ into two parts. She lends the first part for $3$ years and the second part for $5$ years, both at $8\%$ per annum simple interest. The amounts she receives back at the end of the two periods are equal. What is the first part?",
  "MCQ",
  r"The first part grows by $24\%$ and the second by $40\%$, so $1.24x = 1.40y$ and $x : y = 140 : 124 = 35 : 31$. The first part is $\frac{35}{66} \times 33000 =$ Rs. $17{,}500$.",
  "Equating the interests instead of the amounts.",
  "C03A-split-equal-amounts", "Needs the amount ratio and a proportional split; the tempting set-up equates interests.",
  correct=r"Rs. $17{,}500$",
  distractors=[(r"Rs. $15{,}500$", r"Reports the second part."),
               (r"Rs. $20{,}625$", r"Equates interests: $0.24x = 0.40y$ gives $x : y = 5 : 3$ and $x = \frac{5}{8} \times 33000$."),
               (r"Rs. $12{,}375$", r"Equates interests and inverts the ratio: $x = \frac{3}{8} \times 33000$.")],
  check=_m3, values=[17500, 15500, 20625, 12375], cognitive="Application", exams=CX)


def _m4():
    a, b, c, k = symbols('a b c k', positive=True)
    s = solve([Eq(a + b + c, 35400), Eq(a + _si(a, 10, 2), k), Eq(b + _si(b, 10, 3), k), Eq(c + _si(c, 10, 5), k)],
              [a, b, c, k], dict=True)[0]
    return s[k]
q("C03-A-015", T, "Three parts lent for different periods with equal final amounts", "Medium",
  "Multi-step word problem",
  r"Rs. $35{,}400$ is divided into three parts, lent at $10\%$ per annum simple interest for $2$, $3$ and $5$ years respectively. The three amounts received at the end of their periods are all equal. What is this common amount, in rupees?",
  "TITA",
  r"If the common amount is $K$, the parts are $\frac{K}{1.2}$, $\frac{K}{1.3}$ and $\frac{K}{1.5}$. Their sum is $K\left(\frac{5}{6} + \frac{10}{13} + \frac{2}{3}\right) = K \times \frac{177}{78}$. So $K = 35400 \times \frac{78}{177} = 15600$.",
  "Reporting one of the parts instead of the common amount.",
  "C03A-split-equal-amounts", "Three-way split with unlike growth factors; fraction arithmetic must be exact.",
  tita_answer=15600, check=_m4,
  tita_traps=[(13000, r"Reports the part lent for $2$ years, $\frac{15600}{1.2}$, instead of the common amount."),
              (12000, r"Reports the part lent for $3$ years, $\frac{15600}{1.3}$."),
              (10400, r"Reports the part lent for $5$ years, $\frac{15600}{1.5}$.")],
  cognitive="Application", exams=CX)


def _m5():
    p = 15000
    total = 0
    for year in range(1, 8):
        rate = 6 if year <= 2 else (9 if year <= 5 else 11)
        total += _si(p, rate, 1)
    return total
q("C03-A-016", T, "Total interest when the rate changes in stages", "Medium",
  "Multi-step word problem",
  r"Kabir deposits Rs. $15{,}000$ in a scheme that pays simple interest at $6\%$ per annum for the first $2$ years, $9\%$ per annum for the next $3$ years and $11\%$ per annum for every year after that. What is the total interest he earns in $7$ years?",
  "MCQ",
  r"The rates apply for $2$, $3$ and $2$ years, giving $12\% + 27\% + 22\% = 61\%$ of the deposit. Interest $= 0.61 \times 15000 =$ Rs. $9{,}150$.",
  "Miscounting how many years fall in the last stage.",
  "C03A-rate-changes-over-time", "Three stages to add up; the trap is the year count in each stage.",
  correct=r"Rs. $9{,}150$",
  distractors=[(r"Rs. $10{,}800$", r"Counts the last stage as $3$ years ($7 - 5 + 1$) while keeping $3$ years at $9\%$: $12\% + 27\% + 33\% = 72\%$."),
               (r"Rs. $8{,}250$", r"Applies the $6\%$ only once for the first stage: $6\% + 27\% + 22\% = 55\%$."),
               (r"Rs. $24{,}150$", r"Reports the final amount $15000 + 9150$ instead of the interest.")],
  check=_m5, values=[9150, 10800, 8250, 24150], cognitive="Application")


def _m6():
    r = symbols('r', positive=True)
    return solve(Eq(_si(12000, 1, 3) * r + _si(12000, 1, 4) * (r + 2), 6840), r)[0]
q("C03-A-017", T, "Unknown rate in a two-stage rate schedule", "Medium",
  "Inverse/parameter",
  r"Joseph invests Rs. $12{,}000$ at simple interest. The rate is $r\%$ per annum for the first $3$ years and $(r+2)\%$ per annum for the next $4$ years. His total interest at the end of $7$ years is Rs. $6{,}840$. What is the value of $r$?",
  "TITA",
  r"One percent of Rs. $12{,}000$ is $120$ per year. The interest is $120(3r + 4(r+2)) = 120(7r + 8) = 6840$, so $7r + 8 = 57$ and $r = 7$.",
  "Reporting the second-stage rate.",
  "C03A-rate-changes-over-time", "One linear equation built from two stages.",
  tita_answer=7, check=_m6,
  tita_traps=[(9, r"Reports the second-stage rate $r + 2$."),
              (57, r"Stops at $7r + 8 = 57$ and enters $57$.")],
  cognitive="Application")


def _m7():
    # cost in rupees for a loan lasting m months; find the largest m for which P is not cheaper
    cost_p = lambda m: _si(40000, 12, sympify(m) / 12) + Rational(15, 1000) * 40000
    cost_q = lambda m: _si(40000, 13, sympify(m) / 12)
    t = symbols('t', positive=True)
    tb = solve(Eq(cost_p(12 * t), cost_q(12 * t)), t)[0]
    m = tb * 12
    assert cost_p(m + 1) < cost_q(m + 1) and cost_p(m) == cost_q(m) and cost_p(m - 1) > cost_q(m - 1)
    return m
q("C03-A-018", T, "Break-even duration between a lower rate with a fee and a higher rate", "Medium",
  "Inverse/parameter",
  r"Harpreet needs a loan of Rs. $40{,}000$, to be repaid in one payment with interest at the end. Lender P charges simple interest at $12\%$ per annum plus a one-time processing fee of $1.5\%$ of the loan. Lender Q charges simple interest at $13\%$ per annum with no fee. Both charge interest for the exact duration of the loan. The total cost of borrowing from P is less than from Q exactly when the loan lasts longer than how many months?",
  "TITA",
  r"The fee is $600$. P saves $1\%$ of Rs. $40{,}000$, that is $400$ per year, over Q. The saving covers the fee after $\frac{600}{400} = 1.5$ years $= 18$ months, and P is cheaper for any longer loan.",
  "Giving the break-even time in years.",
  "C03A-compare-loan-offers", "Compares a fixed cost with a rate saving per year; the answer must be in months.",
  tita_answer=18, check=_m7,
  tita_traps=[(2, r"Rounds the break-even time of $1.5$ years to $2$ and enters years."),
              (15, r"Reads $1.5$ years as $1$ year $5$ months.")],
  cognitive="Analysis")


def _m8():
    t = 0
    while True:
        t += 1
        q_int = sum(F(6 if y <= 2 else 11) for y in range(1, t + 1))
        if q_int > 8 * t:
            return t
q("C03-A-019", T, "Least whole number of years for a step-up scheme to beat a flat rate", "Medium",
  "Casework/optimisation",
  r"Ananya can deposit a sum in Scheme P, which pays simple interest at $8\%$ per annum, or in Scheme Q, which pays simple interest at $6\%$ per annum for the first $2$ years and $11\%$ per annum for every year after that. Considering only whole numbers of years, what is the least number of years for which Scheme Q gives strictly more total interest than Scheme P?",
  "MCQ",
  r"For $t \ge 2$ years, Q gives $12 + 11(t - 2) = 11t - 10$ percent and P gives $8t$ percent. Q is ahead when $3t > 10$, that is $t > 3\frac{1}{3}$. At $3$ years Q gives $23\%$ against $24\%$; at $4$ years it gives $34\%$ against $32\%$. The least value is $4$ years.",
  "Rounding the break-even time down, or ignoring Q's slower first two years.",
  "C03A-compare-loan-offers", "Needs a crossover inequality and a careful whole-number check at the boundary.",
  correct=r"$4$ years",
  distractors=[(r"$3$ years", r"Rounds the break-even $3\frac{1}{3}$ years down."),
               (r"$8$ years", r"Compares only the interest after year $2$ with all of P's interest: $11(t - 2) > 8t$ gives $t > 7\frac{1}{3}$."),
               (r"$6$ years", r"Takes the first stage as $6\%$ in total: $6 + 11(t - 2) > 8t$ gives $t > 5\frac{1}{3}$.")],
  check=_m8, values=[4, 3, 8, 6], cognitive="Analysis")


def _m9():
    d0 = datetime.date(2027, 1, 18)
    per_day = _si(73000, 9, F(1, 365))
    days = Rational(1854) / per_day
    assert days.q == 1
    d1 = d0 + datetime.timedelta(days=int(days))
    return d1.timetuple().tm_yday
q("C03-A-020", T, "Withdrawal date from interest earned on a day basis", "Medium",
  "Inverse/parameter",
  r"Joseph deposited Rs. $73{,}000$ on $18$ January $2027$ in a scheme paying simple interest at $9\%$ per annum. Interest is calculated for the exact number of days, counting the day of withdrawal but not the day of deposit, with a $365$-day year ($2027$ is not a leap year). When he withdrew the money, he received Rs. $1{,}854$ as interest. On which date did he withdraw it?",
  "MCQ",
  r"One day's interest is $\frac{73000 \times 0.09}{365} = 18$, so the money was held for $\frac{1854}{18} = 103$ days. From $18$ January: $13$ days to the end of January, $28$ in February ($41$), $31$ in March ($72$), $30$ in April ($102$), and the $103$rd day is $1$ May $2027$.",
  "Counting both end days, or giving February $30$ days.",
  "C03A-days-count-interest", "Reverse day count across four months after finding the number of days.",
  correct=r"$1$ May $2027$",
  distractors=[(r"$30$ April $2027$", r"Counts both the deposit day and the withdrawal day, so the $103$ days end one day earlier."),
               (r"$2$ May $2027$", r"Counts neither the deposit day nor the withdrawal day, so the $103$ days end one day later."),
               (r"$29$ April $2027$", r"Gives February $30$ days, so the count reaches $103$ two days earlier.")],
  check=_m9, values=[121, 120, 122, 119], cognitive="Application")


def _m10():
    t = 0
    while True:
        t += 1
        total = _si(10000, 6, t) + (_si(15000, 8, t - 3) if t > 3 else 0)
        if total == 9000:
            return t
q("C03-A-021", T, "Time for total interest from two staggered loans to reach a target", "Medium",
  "Inverse/parameter",
  r"Kabir lends Rs. $10{,}000$ to a friend at $6\%$ per annum simple interest. Exactly $3$ years later, he lends Rs. $15{,}000$ to another friend at $8\%$ per annum simple interest. Neither loan is repaid in the meantime. How many years after the first loan will his total interest from the two loans be Rs. $9{,}000$?",
  "MCQ",
  r"Let $T$ be the years after the first loan. Interest $= 600T + 1200(T - 3) = 1800T - 3600 = 9000$, so $T = 7$ years.",
  "Measuring time from the second loan, or ignoring the gap between the loans.",
  "C03A-staggered-principals", "Two loans running for different lengths of time; the trap is the 3-year offset.",
  correct=r"$7$ years",
  distractors=[(r"$4$ years", r"Solves correctly but measures the time from the second loan: $7 - 3$."),
               (r"$5$ years", r"Ignores the $3$-year gap: $1800T = 9000$."),
               (r"$3$ years", r"Adds the gap instead of subtracting it: $1800T + 3600 = 9000$.")],
  check=_m10, values=[7, 4, 5, 3], cognitive="Application")


def _m11():
    balance, total = 30000, 0
    for year in range(1, 8):           # simulate year by year; interest paid out, not added
        total += _si(balance, 8, 1)
        if year == 2:
            balance -= 10000
        if year == 5:
            balance += 15000
    return total
q("C03-A-022", T, "Total interest on a deposit with a partial withdrawal and a later top-up", "Medium",
  "Multi-step word problem",
  r"Meera opens a deposit of Rs. $30{,}000$ that earns simple interest at $8\%$ per annum. The interest is paid out to her at the end of each year and is never added to the deposit. At the end of the $2$nd year, just after that year's interest is paid, she withdraws Rs. $10{,}000$ from the deposit. At the end of the $5$th year, just after that year's interest is paid, she adds Rs. $15{,}000$ to the deposit. What is the total interest she receives over the $7$ years?",
  "MCQ",
  r"The deposit is Rs. $30{,}000$ for $2$ years, Rs. $20{,}000$ for the next $3$ years and Rs. $35{,}000$ for the last $2$ years. Interest $= 0.08(30000 \times 2 + 20000 \times 3 + 35000 \times 2) = 0.08 \times 190000 =$ Rs. $15{,}200$.",
  "Ignoring the changes in the deposit, or applying each change one year late.",
  "C03A-staggered-principals", "Three principal stages of different lengths; the trap is the timing of each change.",
  correct=r"Rs. $15{,}200$",
  distractors=[(r"Rs. $16{,}800$", r"Ignores both changes: $30000 \times 0.08 \times 7$."),
               (r"Rs. $12{,}800$", r"Applies the withdrawal but forgets the top-up: $0.08(30000 \times 2 + 20000 \times 5)$."),
               (r"Rs. $14{,}800$", r"Applies each change one year late, giving stages of $3$, $3$ and $1$ years: $0.08(90000 + 60000 + 35000)$.")],
  check=_m11, values=[15200, 16800, 12800, 14800], cognitive="Application")


def _m12():
    return sum(1 for r in range(1, 21) for t in range(1, 200) if _si(2400, r, t) == 1440)
q("C03-A-023", T, "Counting whole-number rate and time combinations for a given interest", "Medium",
  "Casework/optimisation",
  r"Rs. $2{,}400$ is lent at simple interest for a whole number of years, at a rate that is a whole number percent per annum not exceeding $20\%$. The interest earned is Rs. $1{,}440$. How many different combinations of rate and time are possible?",
  "MCQ",
  r"$2400 \times \frac{rt}{100} = 1440$ gives $rt = 60$. The rate must be a divisor of $60$ that is at most $20$: $1, 2, 3, 4, 5, 6, 10, 12, 15, 20$. Each gives a whole number of years, so there are $10$ combinations.",
  "Ignoring the cap on the rate, or counting unordered factor pairs.",
  "C03A-integer-rate-time-count", "Reduces to counting divisors under a bound; boundary and ordering traps.",
  correct=r"$10$",
  distractors=[(r"$12$", r"Counts all $12$ divisors of $60$, ignoring the $20\%$ cap."),
               (r"$6$", r"Counts unordered factor pairs of $60$."),
               (r"$9$", r"Reads 'not exceeding $20\%$' as below $20\%$ and drops $r = 20$.")],
  check=_m12, values=[10, 12, 6, 9], cognitive="Analysis")


def _m13():
    a, b, c = symbols('a b c', positive=True)
    s = solve([Eq(_si(1, 4, 6) * a, _si(1, 6, 4) * b), Eq(_si(1, 6, 4) * b, _si(1, 9, 3) * c), Eq(c, 8)], [a, b, c], dict=True)[0]
    return (s[a], s[b], s[c])
q("C03-A-024", T, "Ratio of principals that earn equal interest", "Medium",
  "Conceptual/application",
  r"Three sums are lent at simple interest: the first at $4\%$ per annum for $6$ years, the second at $6\%$ per annum for $4$ years and the third at $9\%$ per annum for $3$ years. All three earn the same interest. What is the ratio of the first sum to the second sum to the third sum?",
  "MCQ",
  r"Equal interest means each sum is inversely proportional to rate $\times$ time: $\frac{1}{24} : \frac{1}{24} : \frac{1}{27}$. Multiplying by $216$ gives $9 : 9 : 8$.",
  "Taking the principals in direct proportion to rate times time, or using only the rates or only the times.",
  "C03A-equal-interest-ratio", "Inverse proportion to the product of rate and time.",
  correct=r"$9 : 9 : 8$",
  distractors=[(r"$8 : 8 : 9$", r"Uses the products $24 : 24 : 27$ directly instead of their reciprocals."),
               (r"$9 : 6 : 4$", r"Inverts only the rates: $\frac{1}{4} : \frac{1}{6} : \frac{1}{9}$."),
               (r"$2 : 3 : 4$", r"Inverts only the times: $\frac{1}{6} : \frac{1}{4} : \frac{1}{3}$.")],
  check=_m13, values=[(9, 9, 8), (8, 8, 9), (9, 6, 4), (2, 3, 4)], cognitive="Understanding")


def _m14():
    r1 = F(100, 10)          # doubles in 10 years
    r2 = F(200, 25)          # triples in 25 years
    x, y = symbols('x y', positive=True)
    s = solve([Eq(x * r1 * 5, y * r2 * 5), Eq(y, 5)], [x, y], dict=True)[0]
    return F(int(s[x]), int(s[y]))
q("C03-A-025", T, "Ratio of two sums from their doubling and tripling times", "Medium",
  "Conceptual/application",
  r"Two sums are lent at simple interest. At the rate for the first sum, any sum doubles in $10$ years; at the rate for the second sum, any sum triples in $25$ years. In $5$ years the two sums earn equal interest. What is the ratio of the first sum to the second sum?",
  "MCQ",
  r"Doubling in $10$ years means $10\%$ per annum; tripling in $25$ years means $200\%$ in $25$ years, that is $8\%$ per annum. Equal interest in $5$ years gives $50\%$ of the first $= 40\%$ of the second, so the ratio is $40 : 50 = 4 : 5$.",
  r"Treating 'triples' as $300\%$ interest, or inverting the ratio.",
  "C03A-equal-interest-ratio", "Two rate conversions from n-fold times, then an inverse ratio.",
  correct=r"$4 : 5$",
  distractors=[(r"$5 : 4$", r"Writes the ratio in direct proportion to the rates instead of inversely."),
               (r"$6 : 5$", r"Takes 'triples in $25$ years' as $300\%$, a rate of $12\%$, so $0.5x = 0.6y$."),
               (r"$5 : 6$", r"Uses the $12\%$ rate for the second sum and also inverts the ratio.")],
  check=_m14, values=[F(4, 5), F(5, 4), F(6, 5), F(5, 6)], cognitive="Application")


def _m15():
    p, r = symbols('p r', positive=True)
    s = solve([Eq(p + _si(1, 1, 2) * p * r, 9440), Eq(p + _si(1, 1, 2) * p * (r + 3), 9920)], [p, r], dict=True)[0]
    return s[r]
q("C03-A-026", T, "Rate from the change in amount when the rate is raised", "Medium",
  "Multi-step word problem",
  r"Fatima lends a sum for $2$ years at simple interest and receives Rs. $9{,}440$ in all at the end. Had the rate been $3$ percentage points higher, she would have received Rs. $9{,}920$. What was the rate of interest per annum?",
  "MCQ",
  r"The extra $3\%$ for $2$ years, that is $6\%$ of the sum, equals $9920 - 9440 = 480$, so the sum is $8000$. The actual interest is $1440$ over $2$ years, so the rate is $\frac{720}{8000} \times 100 = 9\%$.",
  r"Confusing the extra interest fraction with the rate, or not dividing by the time.",
  "C03A-rate-difference-extra-interest", "Principal from the rate change, then the rate; two time-factor traps.",
  correct=r"$9\%$",
  distractors=[(r"$12\%$", r"Reports the raised rate $9 + 3$."),
               (r"$6\%$", r"Stops at $\frac{480}{8000} = 6\%$, the extra interest over $2$ years as a fraction of the sum, and reports it as the rate."),
               (r"$18\%$", r"Finds the sum $8000$ but does not divide the interest $1440$ by $2$ years.")],
  check=_m15, values=[9, 12, 6, 18], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (9)

def _d1():
    a, b, c = symbols('a b c', positive=True)
    s = solve([Eq(a + b + c, 60000),
               Eq(a + _si(a, 5, 4), b + _si(b, 10, 5)),
               Eq(_si(a, 5, 4) + _si(b, 10, 5) + _si(c, 12, 5), 26400)], [a, b, c], dict=True)[0]
    return s[c]
q("C03-A-027", T, "Three parts with unlike periods linked by equal amounts and a total interest", "Difficult",
  "Multi-step word problem",
  r"Ravi divides Rs. $60{,}000$ into three parts and lends them at simple interest: the first part at $5\%$ per annum for $4$ years, the second at $10\%$ per annum for $5$ years and the third at $12\%$ per annum for $5$ years. The amount (principal plus interest) he gets back from the first part equals the amount he gets back from the second part, and his total interest from the three parts is Rs. $26{,}400$. How much, in rupees, is the third part?",
  "TITA",
  r"The first part grows by $20\%$ and the second by $50\%$, so $1.2a = 1.5b$ and $b = 0.8a$. The third part is $60000 - 1.8a$ and earns $60\%$. Total interest: $0.2a + 0.5(0.8a) + 0.6(60000 - 1.8a) = 0.6a + 36000 - 1.08a = 36000 - 0.48a = 26400$, so $a = 20000$, $b = 16000$ and the third part is $60000 - 36000 = 24000$.",
  "Equating the interests instead of the amounts, or reporting another part.",
  "C03A-split-total-interest", "Two conditions of different kinds (equal amounts and a total interest) across three parts with unlike periods must be combined before a single equation appears.",
  tita_answer=24000, check=_d1,
  tita_traps=[(16000, "Reports the second part."), (20000, "Reports the first part.")],
  cognitive="Analysis", exams=CX)


def _d2():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(x + y, 64000), Eq((_si(x, 12, 3) + _si(y, 8, 3)) - (_si(x, 8, 3) + _si(y, 12, 3)), 1440)], [x, y], dict=True)[0]
    return _si(s[x], 8, 3) + _si(s[y], 12, 3)
q("C03-A-028", T, "Two parts whose rates, if interchanged, change the total interest", "Difficult",
  "Conceptual/application",
  r"Sneha lends Rs. $64{,}000$ in two parts, one part at $8\%$ and the other at $12\%$ per annum simple interest. If she had lent each part at the other rate, her total interest over $3$ years would have been Rs. $1{,}440$ more. What is her actual total interest over $3$ years?",
  "MCQ",
  r"Swapping the rates moves $4\%$ per year from one part to the other, so the change is $0.04 \times 3 \times (x - y) = 1440$, where $x$ is the part at $8\%$. Thus $x - y = 12000$, so $x = 38000$ and $y = 26000$. Actual interest $= 3(0.08 \times 38000 + 0.12 \times 26000) = 3(3040 + 3120) =$ Rs. $18{,}480$.",
  "Reporting the interchanged total, or dropping the 3-year factor from the difference.",
  "C03A-split-interchange", "Needs the interchange insight to get the difference of the parts, then a recombination; several tempting totals.",
  correct=r"Rs. $18{,}480$",
  distractors=[(r"Rs. $19{,}920$", r"Reports the total after interchanging the rates: $18480 + 1440$."),
               (r"Rs. $19{,}200$", r"Assumes the average rate $10\%$ on the whole sum: $64000 \times 0.10 \times 3$."),
               (r"Rs. $17{,}040$", r"Drops the $3$ years in the difference: $x - y = 36000$ gives $x = 50000$, $y = 14000$ and $3(4000 + 1680)$.")],
  check=_d2, values=[18480, 19920, 19200, 17040], cognitive="Analysis", exams=CX)


def _d3():
    r = symbols('r', positive=True)
    rr = solve(Eq(100 / r - 100 / (r + Rational(5, 2)), 2), r)
    rr = [v for v in rr if v > 0][0]
    return 100 / rr
q("C03-A-029", T, "Doubling time from the change caused by a higher rate", "Difficult",
  "Inverse/parameter",
  r"Ravi invests a sum at simple interest. If the rate had been $2.5$ percentage points higher, the sum would have doubled $2$ years sooner than it actually does. In how many years does the sum double at the actual rate?",
  "TITA",
  r"At $r\%$ a sum doubles in $\frac{100}{r}$ years. So $\frac{100}{r} - \frac{100}{r + 2.5} = 2$, giving $250 = 2r(r + 2.5)$, that is $r^2 + 2.5r - 125 = 0 = (r - 10)(r + 12.5)$. So $r = 10$ and the doubling time is $\frac{100}{10} = 10$ years. (Check: at $12.5\%$ it takes $8$ years.)",
  "Reporting the doubling time at the higher rate, or the rate itself.",
  "C03A-doubling-time-rate-change", "Leads to a quadratic in the rate; the unknown asked for is a derived quantity.",
  tita_answer=10, check=_d3,
  tita_traps=[(8, "Reports the doubling time at the higher rate."),
              (82, r"Reads $2.5$ percentage points as a $2.5\%$ relative rise in the rate: $\frac{100}{r}\left(1 - \frac{1}{1.025}\right) = 2$ gives $\frac{100}{r} = 82$.")],
  cognitive="Analysis", exams=CX)


def _d4():
    best = 0
    step = 500
    for x in range(0, 100001, step):
        for z in range(0, 100001 - x, step):
            y = 100000 - x - z
            if z <= x and y <= 2 * x:
                best = max(best, _si(x, 5, 1) + _si(y, 7, 1) + _si(z, 11, 1))
    # LP vertices of the feasible region (exact): confirm the grid optimum is the true optimum
    vertices = [(F(100000), 0, 0), (F(50000), 0, F(50000)), (F(100000, 3), F(200000, 3), 0), (F(25000), F(50000), F(25000))]
    lp = max(_si(x, 5, 1) + _si(y, 7, 1) + _si(z, 11, 1) for x, y, z in vertices)
    assert lp == best
    return best
q("C03-A-030", T, "Maximising annual interest across three schemes under limits", "Difficult",
  "Casework/optimisation",
  r"Meera has Rs. $1{,}00{,}000$ to invest across three schemes paying simple interest at $5\%$, $7\%$ and $11\%$ per annum. The amount in the $11\%$ scheme cannot exceed the amount in the $5\%$ scheme, and the amount in the $7\%$ scheme cannot exceed twice the amount in the $5\%$ scheme. She invests the whole sum, and any scheme may receive nothing. What is the maximum total interest, in rupees, she can earn in one year?",
  "TITA",
  r"Every rupee in the $11\%$ scheme needs at least one rupee in the $5\%$ scheme, and such a pair earns an average of $8\%$, more than the $7\%$ scheme. So money is best placed in equal amounts in the $5\%$ and $11\%$ schemes: Rs. $50{,}000$ each. Interest $= 2500 + 5500 = 8000$. (Filling the $7\%$ scheme to its limit, Rs. $25{,}000$, $50{,}000$, $25{,}000$, gives only $7500$.)",
  "Assuming the middle scheme should be filled to its limit.",
  "C03A-allocation-optimisation", "Linear optimisation with two constraints; the insight is pairing the extreme rates.",
  tita_answer=8000, check=_d4,
  tita_traps=[(7500, r"Makes both limits binding: Rs. $25{,}000$, $50{,}000$ and $25{,}000$ in the three schemes."),
              (11000, r"Ignores the limits and puts everything at $11\%$.")],
  cognitive="Analysis", exams=CX)


def _d5():
    f = symbols('f', positive=True)
    face = solve(Eq(f - _si(1, 10, 5) * f, 60000), f)[0]
    repay_p = face
    repay_q = 60000 + _si(60000, 12, 5)
    return repay_p - repay_q
q("C03-A-031", T, "Comparing a loan with interest deducted upfront against a standard loan", "Difficult",
  "Conceptual/application",
  r"Kabir needs exactly Rs. $60{,}000$ in hand for $5$ years. Lender P charges simple interest at $10\%$ per annum but deducts the interest for the full $5$ years from the loan amount at the start, and the full loan amount is repaid at the end of $5$ years. Lender Q charges simple interest at $12\%$ per annum, with the amount lent and the interest repaid together at the end of $5$ years. With either lender Kabir borrows just enough to have Rs. $60{,}000$ in hand. By how much does his repayment at the end of $5$ years to P exceed his repayment to Q?",
  "MCQ",
  r"With P, half of the loan amount ($50\%$ for $5$ years) is deducted, so to receive Rs. $60{,}000$ he must borrow Rs. $1{,}20{,}000$ and repay that. With Q he repays $60000 + 60000 \times 0.12 \times 5 = 96000$. The difference is Rs. $24{,}000$.",
  "Computing P's deduction on the Rs. $60{,}000$ he needs rather than on the larger loan amount.",
  "C03A-interest-deducted-upfront", "The loan amount must be grossed up for the deduction; the natural shortcut reverses which lender is cheaper.",
  correct=r"Rs. $24{,}000$",
  distractors=[(r"Rs. $6{,}000$", r"Takes P's interest as $50\%$ of Rs. $60{,}000$, so P's repayment is $90000$, and reports the size of the gap to $96000$."),
               (r"Rs. $84{,}000$", r"Borrows $120000$ from P but also adds $5$ years' interest at the end: $180000 - 96000$."),
               (r"Rs. $60{,}000$", r"Compares P's repayment $120000$ with Q's principal $60000$, leaving out Q's interest.")],
  check=_d5, values=[24000, 6000, 84000, 60000], cognitive="Analysis", exams=CX)


def _d6():
    count = 0
    for k in range(1, 21):            # principal = 1000k, up to Rs 20,000
        for r in range(1, 16):
            for t in range(1, 11):
                if _si(1000 * k, r, t) == 1200:
                    count += 1
    return count
q("C03-A-032", T, "Counting principal, rate and time combinations for a fixed interest", "Difficult",
  "Casework/optimisation",
  r"A principal that is a multiple of Rs. $1{,}000$ and does not exceed Rs. $20{,}000$ is lent at simple interest at a whole number rate of at most $15\%$ per annum for a whole number of years, at most $10$. The interest earned is exactly Rs. $1{,}200$. How many different combinations of principal, rate and time are possible?",
  "MCQ",
  r"With principal $1000k$, interest $= 10krt = 1200$, so $krt = 120$ with $k \le 20$, $r \le 15$, $t \le 10$. For each $t$ dividing $120$, count $r \mid \frac{120}{t}$ with $r \le 15$ and $\frac{120}{rt} \le 20$: $t = 1$: $5$; $t = 2$: $7$; $t = 3$: $5$; $t = 4$: $6$; $t = 5$: $6$; $t = 6$: $5$; $t = 8$: $4$; $t = 10$: $6$. Total $= 44$.",
  "Dropping one of the three bounds.",
  "C03A-integer-rate-time-count", "Three-variable divisor casework under three separate bounds.",
  correct=r"$44$",
  distractors=[(r"$54$", r"Ignores the Rs. $20{,}000$ cap on the principal."),
               (r"$66$", r"Ignores the $10$-year cap on the time."),
               (r"$40$", r"Reads 'at most $15\%$' as below $15\%$ and drops $r = 15$.")],
  check=_d6, values=[44, 54, 66, 40], cognitive="Analysis", exams=CX)


def _d7():
    r1 = F(100, 8)            # doubles in 8 years
    r2 = F(200, 20)           # triples in 20 years
    x = symbols('x', positive=True)
    return solve(Eq(_si(x, r1, 6) + _si(48000 - x, r2, 3), 23400), x)[0]
q("C03-A-033", T, "Split from n-fold rates with the two parts held for different periods", "Difficult",
  "Multi-step word problem",
  r"Ananya divides Rs. $48{,}000$ into two parts. She invests the first part at a simple interest rate at which any sum doubles in $8$ years, and withdraws it after $6$ years. She invests the second part at a simple interest rate at which any sum triples in $20$ years, and withdraws it after $3$ years. Her total interest from the two parts is Rs. $23{,}400$. What is the first part?",
  "MCQ",
  r"Doubling in $8$ years means $100\%$ interest in $8$ years, a rate of $12.5\%$; tripling in $20$ years means $200\%$ in $20$ years, a rate of $10\%$. Over its $6$ years the first part earns $75\%$, and over its $3$ years the second earns $30\%$. So $0.75x + 0.3(48000 - x) = 23400$, giving $14400 + 0.45x = 23400$ and $x =$ Rs. $20{,}000$.",
  "Converting 'doubles' or 'triples' into the wrong interest percentage, or matching the holding periods to the wrong parts.",
  "C03A-split-total-interest", "Two n-fold rate conversions, unequal holding periods for the two parts and a split equation, with a trap at each stage.",
  correct=r"Rs. $20{,}000$",
  distractors=[(r"Rs. $28{,}000$", r"Reports the second part."),
               (r"Rs. $7{,}500$", r"Takes 'doubles' as $200\%$ interest, a rate of $25\%$: $1.5x + 0.3(48000 - x) = 23400$."),
               (r"Rs. $24{,}000$", r"Swaps the holding periods, $3$ years for the first part and $6$ for the second: $0.375x + 0.6(48000 - x) = 23400$.")],
  check=_d7, values=[20000, 28000, 7500, 24000], cognitive="Analysis", exams=CX)


def _d8():
    count = 0
    for m in range(12, 61):
        p_int = F(8) * (m // 12)
        q_int = F(15, 2) * F(m, 12)
        if p_int > q_int:
            count += 1
    return count
q("C03-A-034", T, "Months for which completed-year crediting beats exact-time crediting", "Difficult",
  "Casework/optimisation",
  r"Bank P pays simple interest at $8\%$ per annum but credits interest only for completed years of a deposit, paying nothing for any incomplete part of a year. Bank Q pays simple interest at $7.5\%$ per annum for the exact time the money is held. Joseph will deposit a sum in one of them and withdraw it after $m$ months, where $m$ is a whole number from $12$ to $60$. For how many values of $m$ does Bank P pay strictly more interest than Bank Q?",
  "TITA",
  r"For $12k \le m < 12(k+1)$, P pays $8k\%$ and Q pays $\frac{7.5m}{12}\% = 0.625m\%$. P is ahead when $m < 12.8k$. For $k = 1$: $m = 12$ ($1$ value). $k = 2$: $m = 24, 25$ ($2$). $k = 3$: $36$ to $38$ ($3$). $k = 4$: $48$ to $51$ ($4$). $k = 5$: only $m = 60$, which is below $64$ ($1$). Total $= 11$.",
  "Forgetting the single value in the last year, or only counting whole years.",
  "C03A-whole-year-credit", "Casework over five ranges of months with a step-function interest.",
  tita_answer=11, check=_d8,
  tita_traps=[(10, r"Misses $m = 60$ at the end of the range."),
              (5, r"Counts only exact whole years $12, 24, 36, 48, 60$.")],
  cognitive="Analysis", exams=CX)


def _d9():
    # simulate in steps of 1/100 year with exact arithmetic; find the moment the balances meet
    arjun = lambda T: 20000 + _si(20000, 6, T)
    def fatima(T):
        if T < 3:
            return None
        s = T - 3
        return 16000 + _si(16000, 10, min(s, 4)) + _si(16000, 15, max(s - 4, 0))
    meets = []
    for k in range(300, 4001):
        T = F(k, 100)
        if fatima(T) == arjun(T):
            meets.append(T)
    assert len(meets) == 1
    return arjun(meets[0])
q("C03-A-035", T, "Common balance when a later deposit with a step-up rate catches up", "Difficult",
  "Multi-step word problem",
  r"Arjun deposits Rs. $20{,}000$ in a scheme paying simple interest at $6\%$ per annum. Exactly $3$ years later, Fatima deposits Rs. $16{,}000$ in a scheme that pays simple interest on her deposit at $10\%$ per annum for the first $4$ years after she deposits and at $15\%$ per annum after that. Neither withdraws anything, and each balance is the deposit plus the simple interest earned so far. What is the balance of each at the moment their balances become equal?",
  "MCQ",
  r"Let $T$ be the years after Arjun's deposit; his balance is $20000 + 1200T$. At $T = 7$, when Fatima's rate changes, she has $16000 + 1600 \times 4 = 22400$ against his $28400$, so they have not met yet. After that she gains $2400$ a year to his $1200$: $22400 + 2400(T - 7) = 20000 + 1200T$ gives $1200T = 14400$, so $T = 12$. The common balance is $20000 + 1200 \times 12 =$ Rs. $34{,}400$.",
  "Ignoring the change in Fatima's rate, or timing the change from Arjun's deposit.",
  "C03A-catch-up-amounts", "Piecewise growth with an offset start: the stage in which the balances meet must be identified before solving, with timing traps at each stage.",
  correct=r"Rs. $34{,}400$",
  distractors=[(r"Rs. $46{,}400$", r"Ignores the rise to $15\%$: $16000 + 1600(T - 3) = 20000 + 1200T$ gives $T = 22$."),
               (r"Rs. $32{,}000$", r"Times the rate change from Arjun's deposit, so Fatima earns $10\%$ only until $T = 4$: the balances meet at $T = 10$."),
               (r"Rs. $27{,}200$", r"Ignores Fatima's $3$-year late start and grows her deposit from $T = 0$: the balances meet at $T = 6$.")],
  check=_d9, values=[34400, 46400, 32000, 27200], cognitive="Analysis", exams=CX)
