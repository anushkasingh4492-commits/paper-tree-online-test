import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Factors and divisibility"
HEAVY = ("CAT", "XAT")


def _divs(n):
    out = []
    i = 1
    while i * i <= n:
        if n % i == 0:
            out.append(i)
            if i != n // i:
                out.append(n // i)
        i += 1
    return sorted(out)


def _nd(n):
    return len(_divs(n))


def _is_sq(n):
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def _is_cube(n):
    r = round(n ** (1.0 / 3))
    return any((r + e) ** 3 == n for e in (-1, 0, 1))


# 001
def _c001():
    return sum(1 for g in range(1, 181) if 180 % g == 0)
q("C21-A-001", T, "Number of factors via equal grouping of a class", "Easy",
  "Single-step computation",
  r"A school has $180$ students in Class X. The principal wants to divide all of them into groups of equal size, with every student in exactly one group. A single group of all $180$ students and $180$ groups of one student each are both allowed. Two divisions are different if their group sizes are different. In how many different ways can the students be divided? Enter the number of ways.",
  "TITA",
  r"Each division corresponds to a group size that divides $180$. Since $180 = 2^2 \times 3^2 \times 5$, the number of divisors is $(2+1)(2+1)(1+1) = 18$. So there are $18$ ways.",
  "Multiplying or adding the exponents without adding $1$ to each, or discarding the two extreme groupings that the stem allows.",
  "C21A-divisor-count-direct", "One prime factorisation and the divisor-count formula.",
  tita_answer=18, check=_c001,
  tita_traps=[(16, "Discards the single group and the groups of one, although the stem allows both."),
              (4, "Multiplies the exponents $2 \\times 2 \\times 1$ without adding $1$ to each.")],
  cognitive="Application")

# 002
def _c002():
    return _nd(math.factorial(10))
q("C21-A-002", T, "Number of factors of a factorial", "Medium",
  "Conceptual/application",
  r"How many positive integers divide $10! = 1 \times 2 \times 3 \times \cdots \times 10$ exactly?",
  "MCQ",
  r"The exponent of $2$ in $10!$ is $5 + 2 + 1 = 8$, of $3$ is $3 + 1 = 4$, of $5$ is $2$ and of $7$ is $1$. So $10! = 2^8 \times 3^4 \times 5^2 \times 7$ and the number of divisors is $9 \times 5 \times 3 \times 2 = 270$.",
  "Counting only the multiples of each prime and missing the extra factors contributed by $4$, $8$ and $9$.",
  "C21A-divisor-count-direct", "Needs the prime exponents of a factorial before applying the formula.",
  correct=r"$270$",
  distractors=[(r"$216$", "Takes the exponent of $3$ as $3$ (multiples of $3$ only, missing the extra $3$ in $9$): $9 \\times 4 \\times 3 \\times 2 = 216$."),
               (r"$180$", "Takes the exponent of $2$ as $5$ (multiples of $2$ only): $6 \\times 5 \\times 3 \\times 2 = 180$."),
               (r"$135$", "Leaves out the prime $7$: $9 \\times 5 \\times 3 = 135$.")],
  check=_c002, values=[270, 216, 180, 135], cognitive="Application")

# 003
def _c003():
    N = 2**4 * 3**3
    dn = set(_divs(N))
    return sum(1 for x in _divs(N * N) if x < N and x not in dn)
q("C21-A-003", T, "Divisors of N squared below N that do not divide N", "Difficult",
  "Conceptual/application",
  r"Let $N = 2^4 \times 3^3$. How many positive divisors of $N^2$ are less than $N$ but do not divide $N$?",
  "MCQ",
  r"$N^2 = 2^8 \times 3^6$ has $9 \times 7 = 63$ divisors. They pair up as $(x, \frac{N^2}{x})$ with one member below $N$, except $x = N$ itself, so $\frac{63 - 1}{2} = 31$ divisors are less than $N$. Every divisor of $N$ other than $N$ is among these; $N$ has $5 \times 4 = 20$ divisors, so $19$ of them are less than $N$. The required count is $31 - 19 = 12$.",
  "Subtracting all divisors of $N$ including $N$ itself, or forgetting to remove the divisors of $N$ at all.",
  "C21A-divisors-of-square", "Requires the pairing argument for divisors of a square and a careful subtraction.",
  correct=r"$12$",
  distractors=[(r"$11$", "Subtracts all $20$ divisors of $N$, including $N$, which is not less than $N$: $31 - 20 = 11$."),
               (r"$31$", "Counts all divisors of $N^2$ below $N$ without removing those that divide $N$."),
               (r"$19$", "Reports the number of divisors of $N$ that are less than $N$.")],
  check=_c003, values=[12, 11, 31, 19], cognitive="Analysis", exams=HEAVY)

# 004
def _c004():
    return sum(1 for x in _divs(5400) if x % 2 == 0)
q("C21-A-004", T, "Number of even factors", "Easy",
  "Single-step computation",
  r"How many even positive factors does $5400$ have?",
  "MCQ",
  r"$5400 = 2^3 \times 3^3 \times 5^2$. An even factor must use $2^1$, $2^2$ or $2^3$, so the count is $3 \times 4 \times 3 = 36$.",
  "Including $2^0$ in the choices for the power of $2$, which also counts the odd factors.",
  "C21A-odd-even-factors", "Direct use of the restricted exponent choice for $2$.",
  correct=r"$36$",
  distractors=[(r"$12$", "Counts the odd factors, $4 \\times 3 = 12$."),
               (r"$48$", "Counts all factors, $4 \\times 4 \\times 3 = 48$."),
               (r"$47$", "Treats $1$ as the only odd factor and subtracts it from the total $48$.")],
  check=_c004, values=[36, 12, 48, 47], cognitive="Application")

# 005
def _c005():
    sols = []
    for a in range(1, 30):
        for b in range(1, 30):
            N = 2**a * 3**b * 5
            odd = (b + 1) * 2
            even = (a + 1) * (b + 1) * 2 - odd
            if odd == 12 and even == 48:
                sols.append(N)
    assert len(sols) == 1
    N = sols[0]
    from sympy import divisor_count
    return int(divisor_count(4 * N))
q("C21-A-005", T, "Recover exponents from odd and even factor counts", "Medium",
  "Inverse/parameter",
  r"A positive integer $N = 2^a \times 3^b \times 5$, where $a$ and $b$ are positive integers. $N$ has exactly $12$ odd positive factors and exactly $48$ even positive factors. How many positive factors does $4N$ have? Enter the number of factors.",
  "TITA",
  r"Odd factors use only $3$ and $5$: $(b+1)(1+1) = 12$, so $b = 5$. Even factors use $2^1$ to $2^a$: $a \times 6 \times 2 = 48$, so $a = 4$. Then $4N = 2^6 \times 3^5 \times 5$, which has $7 \times 6 \times 2 = 84$ factors.",
  "Writing the even-factor count as $(a+1)$ times the odd count, or answering for $N$ instead of $4N$.",
  "C21A-odd-even-factors", "Two equations from two factor counts, then a change of exponent.",
  tita_answer=84, check=_c005,
  tita_traps=[(60, "Gives the number of factors of $N$ itself, $12 + 48 = 60$."),
              (72, "Uses $(a+1) \\times 12 = 48$, so $a = 3$, and then $4N = 2^5 \\times 3^5 \\times 5$ has $6 \\times 6 \\times 2 = 72$ factors.")],
  cognitive="Analysis")

# 006
def _c006():
    N = 2**4 * 3**5 * 7**2
    return sum(1 for x in _divs(N) if _is_sq(x))
q("C21-A-006", T, "Perfect-square factors", "Easy",
  "Single-step computation",
  r"How many positive factors of $N = 2^4 \times 3^5 \times 7^2$ are perfect squares? (Count $1$ as a perfect square.)",
  "MCQ",
  r"A square factor needs an even exponent on each prime: $2^0, 2^2, 2^4$ (3 ways), $3^0, 3^2, 3^4$ (3 ways), $7^0, 7^2$ (2 ways). Total $3 \times 3 \times 2 = 18$.",
  "Allowing an even exponent that exceeds the available power, or leaving out the factor $1$.",
  "C21A-square-cube-factors", "Single counting rule with even exponents.",
  correct=r"$18$",
  distractors=[(r"$17$", "Leaves out $1$, although the stem counts it as a perfect square."),
               (r"$24$", "Allows $3^6$ for the prime $3$, giving $4$ choices: $3 \\times 4 \\times 2 = 24$."),
               (r"$90$", "Counts all factors, $5 \\times 6 \\times 3 = 90$.")],
  check=_c006, values=[18, 17, 24, 90], cognitive="Application")

# 007
def _c007():
    return sum(1 for x in _divs(21600) if _is_sq(x) and not _is_cube(x))
q("C21-A-007", T, "Factors that are squares but not cubes", "Medium",
  "Casework/optimisation",
  r"How many positive factors of $21600$ are perfect squares but not perfect cubes? (The number $1$ is both a perfect square and a perfect cube.) Enter the count.",
  "TITA",
  r"$21600 = 2^5 \times 3^3 \times 5^2$. Square factors: exponents of $2$ in $\{0, 2, 4\}$, of $3$ in $\{0, 2\}$, of $5$ in $\{0, 2\}$, giving $3 \times 2 \times 2 = 12$. A square that is also a cube is a sixth power; the only sixth-power factor is $1$, since no exponent here reaches $6$. So the answer is $12 - 1 = 11$.",
  "Subtracting all cube factors instead of only those cubes that are also squares.",
  "C21A-square-cube-factors", "Needs to see that square and cube means sixth power before subtracting.",
  tita_answer=11, check=_c007,
  tita_traps=[(8, "Subtracts all $4$ cube factors ($2$ choices for $2$, $2$ for $3$, $1$ for $5$) from $12$."),
              (12, "Forgets to remove $1$, which is also a cube.")],
  cognitive="Analysis")

# 008
def _c008():
    N = 2**8 * 3**6 * 5**4
    return sum(1 for x in _divs(N) if _is_sq(x) != _is_cube(x))
q("C21-A-008", T, "Factors that are squares or cubes but not both", "Medium",
  "Casework/optimisation",
  r"How many positive factors of $2^8 \times 3^6 \times 5^4$ are perfect squares or perfect cubes, but not both? (The number $1$ is both a perfect square and a perfect cube.)",
  "MCQ",
  r"Squares: $5 \times 4 \times 3 = 60$ (even exponents up to $8$, $6$, $4$). Cubes: exponents in $\{0,3,6\}$, $\{0,3,6\}$, $\{0,3\}$, so $3 \times 3 \times 2 = 18$. Both means sixth powers: $\{0,6\}$, $\{0,6\}$, $\{0\}$, so $2 \times 2 \times 1 = 4$. The sixth powers sit inside both counts, so exactly one of the two properties holds for $(60 - 4) + (18 - 4) = 70$ factors.",
  "Removing the sixth powers only once, which gives the count of squares or cubes including those that are both.",
  "C21A-square-cube-factors", "Three counts combined by inclusion and exclusion.",
  correct=r"$70$",
  distractors=[(r"$74$", "Removes the $4$ sixth powers only once, $60 + 18 - 4 = 74$, which keeps the factors that are both."),
               (r"$78$", "Adds $60 + 18$ without removing the $4$ sixth powers at all."),
               (r"$56$", "Counts only the squares that are not cubes, $60 - 4$, and forgets the cubes that are not squares.")],
  check=_c008, values=[70, 74, 78, 56], cognitive="Application")

# 009
def _c009():
    return sum(_divs(108))
q("C21-A-009", T, "Sum of all factors", "Easy",
  "Single-step computation",
  r"What is the sum of all the positive factors of $108$, including $1$ and $108$? Enter the sum.",
  "TITA",
  r"$108 = 2^2 \times 3^3$. The sum of factors is $(1 + 2 + 4)(1 + 3 + 9 + 27) = 7 \times 40 = 280$.",
  "Leaving out $1$ or the number itself from the sum.",
  "C21A-sum-of-factors", "Direct use of the sum-of-divisors product.",
  tita_answer=280, check=_c009,
  tita_traps=[(172, "Leaves out $108$ itself: $280 - 108$."),
              (279, "Leaves out the factor $1$.")],
  cognitive="Application")

# 010
def _c010():
    return sum(x for x in _divs(720) if x % 2 == 1)
q("C21-A-010", T, "Sum of odd factors", "Medium",
  "Conceptual/application",
  r"What is the sum of all the odd positive factors of $720$?",
  "MCQ",
  r"$720 = 2^4 \times 3^2 \times 5$. Odd factors are the factors of $3^2 \times 5 = 45$, whose sum is $(1 + 3 + 9)(1 + 5) = 13 \times 6 = 78$.",
  "Dropping the $1$ term in each bracket of the sum formula, or summing the even factors.",
  "C21A-sum-of-factors", "Must isolate the odd part before applying the sum formula.",
  correct=r"$78$",
  distractors=[(r"$60$", "Drops the $1$ in each bracket: $(3 + 9)(5) = 60$."),
               (r"$2340$", "Sums the even factors: $31 \\times 13 \\times 6 - 78 = 2340$."),
               (r"$2418$", "Sums all factors: $31 \\times 13 \\times 6 = 2418$.")],
  check=_c010, values=[78, 60, 2340, 2418], cognitive="Application")

# 011
def _c011():
    return sum(x for x in _divs(1800) if x % 10 == 0)
q("C21-A-011", T, "Sum of factors that are multiples of a given number", "Medium",
  "Conceptual/application",
  r"What is the sum of all positive factors of $1800$ that are multiples of $10$?",
  "MCQ",
  r"A factor of $1800$ that is a multiple of $10$ is $10k$ with $k$ a factor of $180 = 2^2 \times 3^2 \times 5$. The sum is $10 \times (1+2+4)(1+3+9)(1+5) = 10 \times 7 \times 13 \times 6 = 5460$.",
  "Summing the factors of $180$ and forgetting to multiply by $10$, or using multiples of $5$ only.",
  "C21A-sum-of-factors", "Two steps: reduce to factors of $N/10$, then scale the sum.",
  correct=r"$5460$",
  distractors=[(r"$546$", "Sums the factors of $180$ but forgets to multiply by $10$."),
               (r"$5850$", "Sums the factors divisible by $5$: $6045 - 195 = 5850$."),
               (r"$6045$", "Sums all factors of $1800$: $15 \\times 13 \\times 31$.")],
  check=_c011, values=[5460, 546, 5850, 6045], cognitive="Application")

# 012
def _c012():
    p = 1
    for x in _divs(72):
        p *= x
    f = factorint(p)
    return f[2] + f[3]
q("C21-A-012", T, "Product of all factors in prime-power form", "Easy",
  "Single-step computation",
  r"The product of all the positive factors of $72$ is written in the form $2^a \times 3^b$. What is $a + b$? Enter the value.",
  "TITA",
  r"$72 = 2^3 \times 3^2$ has $4 \times 3 = 12$ factors, which pair up to give product $72$ in each of $6$ pairs. The product is $72^6 = 2^{18} \times 3^{12}$, so $a + b = 30$.",
  "Taking the product as $N^{d}$ rather than $N^{d/2}$.",
  "C21A-product-of-factors", "One pairing idea and one exponent calculation.",
  tita_answer=30, check=_c012,
  tita_traps=[(60, "Uses $72^{12}$, forgetting that factors pair up."),
              (5, "Gives the exponent sum of $72$ itself, $3 + 2$.")],
  cognitive="Application")

# 013
def _c013():
    cnt = 0
    for N in range(2, 50):
        p = 1
        for x in _divs(N):
            p *= x
        if p == N**4:
            cnt += 1
    return cnt
q("C21-A-013", T, "Product of factors equals a given power of N", "Medium",
  "Inverse/parameter",
  r"For how many integers $N$ with $1 < N < 50$ is the product of all positive factors of $N$ equal to $N^4$? Enter the count.",
  "TITA",
  r"The product of the factors of $N$ is $N^{d/2}$ where $d$ is the number of factors. With $N > 1$, $N^{d/2} = N^4$ forces $d = 8$. Numbers with $8$ factors have the form $p^7$, $p^3 q$ or $pqr$. Below $50$: $p^7$ gives none ($2^7 = 128$); $p^3 q$ gives $24$ and $40$ ($3^3 \times 2 = 54$ is too big); $pqr$ gives $30$ and $42$. So there are $4$ values.",
  "Missing the form $pqr$, or counting $N = 1$, which the stem excludes.",
  "C21A-product-of-factors", "Converts a product condition into a factor count, then enumerates forms.",
  tita_answer=4, check=_c013,
  tita_traps=[(2, "Considers only the form $p^3 q$, missing $30$ and $42$."),
              (5, "Includes $N = 1$, which is excluded by $1 < N$.")],
  cognitive="Analysis")

# 014
def _c014():
    p = 1
    for x in _divs(72):
        if x % 2 == 0:
            p *= x
    return p
q("C21-A-014", T, "Product of all even factors", "Medium",
  "Conceptual/application",
  r"The product of all the even positive factors of $72$ equals",
  "MCQ",
  r"Each even factor of $72$ is $2k$ with $k$ a factor of $36$, and $36 = 2^2 \times 3^2$ has $9$ factors. The product is $2^9 \times (\text{product of factors of } 36) = 2^9 \times 36^{9/2} = 2^9 \times 6^9 = 2^{18} \times 3^9$.",
  "Pairing the even factors as if they were all the factors of $72$, or losing the $2^9$ that comes from writing each even factor as $2k$.",
  "C21A-product-of-factors", "Two steps: write each even factor as $2k$ with $k \\mid 36$, then apply the pairing product to the factors of $36$.",
  correct=r"$2^{18} \times 3^{9}$",
  distractors=[(r"$2^{18} \times 3^{12}$", "Gives the product of all factors of $72$, $72^6$."),
               (r"$2^{9} \times 3^{9}$", "Uses the product of the factors of $36$, $6^9$, and drops the $2^9$."),
               (r"$2^{27} \times 3^{18}$", "Uses $2^9 \\times 36^9$, taking the product of factors of $36$ as $36^9$ instead of $36^{9/2}$.")],
  check=_c014, values=[2**18 * 3**9, 2**18 * 3**12, 2**9 * 3**9, 2**27 * 3**18],
  cognitive="Analysis")

# 015
def _c015():
    return sum(1 for n in range(1, 201) if _nd(n) == 3)
q("C21-A-015", T, "Numbers with exactly three factors in a range", "Easy",
  "Conceptual/application",
  r"How many integers from $1$ to $200$ (both inclusive) have exactly three positive factors?",
  "MCQ",
  r"A number has exactly three factors only when it is the square of a prime. The prime squares up to $200$ are $4, 9, 25, 49, 121, 169$, so there are $6$.",
  "Counting every perfect square, since all squares have an odd number of factors.",
  "C21A-exactly-k-factors", "One structural fact and a short list.",
  correct=r"$6$",
  distractors=[(r"$14$", "Counts all perfect squares from $1$ to $196$."),
               (r"$13$", "Counts all perfect squares from $4$ to $196$, excluding only $1$."),
               (r"$5$", "Uses only odd primes and misses $4 = 2^2$.")],
  check=_c015, values=[6, 14, 13, 5], cognitive="Understanding")

# 016
def _c016():
    return sum(1 for n in range(1, 101) if _nd(n) == 6)
q("C21-A-016", T, "Numbers with exactly six factors in a range", "Medium",
  "Casework/optimisation",
  r"How many integers from $1$ to $100$ (both inclusive) have exactly six positive factors?",
  "MCQ",
  r"Six factors means the form $p^5$ or $p^2 q$ with $p \ne q$ primes. $p^5$: only $32$. $p^2 q$: with $p = 2$, $q \in \{3,5,7,11,13,17,19,23\}$ gives $8$ numbers; $p = 3$, $q \in \{2,5,7,11\}$ gives $4$; $p = 5$, $q \in \{2,3\}$ gives $2$; $p = 7$, $q = 2$ gives $98$. Total $1 + 8 + 4 + 2 + 1 = 16$.",
  "Missing the $p^5$ form, or listing $p^2 q$ only with $p < q$.",
  "C21A-exactly-k-factors", "Two forms and casework over the squared prime.",
  correct=r"$16$",
  distractors=[(r"$15$", "Misses the form $p^5$, that is $32$."),
               (r"$12$", "Lists $p^2 q$ only with $p < q$ (missing $18, 50, 75, 98$) but includes $32$."),
               (r"$11$", "Lists $p^2 q$ only with $p < q$ and also misses $32$.")],
  check=_c016, values=[16, 15, 12, 11], cognitive="Analysis")

# 017
def _c017():
    return sum(1 for n in range(1, 501) if _nd(n) == 9)
q("C21-A-017", T, "Numbers with exactly nine factors in a range", "Medium",
  "Casework/optimisation",
  r"How many integers from $1$ to $500$ (both inclusive) have exactly nine positive factors?",
  "MCQ",
  r"Nine factors means $p^8$ or $p^2 q^2$ with $p \ne q$ primes. $p^8$: only $256$. $p^2 q^2 = (pq)^2 \le 500$ needs $pq \le 22$ with distinct primes: $6, 10, 14, 15, 21, 22$, giving $36, 100, 196, 225, 441, 484$. Total $1 + 6 = 7$.",
  "Missing the $p^8$ form, or reading $p^2 q^2$ as $p^4$.",
  "C21A-exactly-k-factors", "Two factor-count forms and one bound on a product of two distinct primes; a short list.",
  correct=r"$7$",
  distractors=[(r"$6$", "Misses the form $p^8$, that is $256$."),
               (r"$13$", "Lists $p^2 q^2$ over ordered pairs of distinct primes $(p, q)$ with $pq \\le 22$, counting each square twice: $2 \\times 6 + 1 = 13$."),
               (r"$2$", "Takes $N = m^2$ with $m$ having $3$ factors, so $N = p^4$, listing only $16$ and $81$.")],
  check=_c017, values=[7, 6, 13, 2], cognitive="Analysis")

# 018
def _c018():
    n = 1
    while _nd(n) != 12:
        n += 1
    from sympy import divisor_count
    return int(divisor_count(n * n))
q("C21-A-018", T, "Smallest number with a given factor count, then its square", "Medium",
  "Inverse/parameter",
  r"Let $N$ be the smallest positive integer that has exactly $12$ positive factors. How many positive factors does $N^2$ have?",
  "MCQ",
  r"The factorisations $12$, $6 \times 2$, $4 \times 3$ and $3 \times 2 \times 2$ of the factor count give candidates $2^{11}$, $2^5 \times 3 = 96$, $2^3 \times 3^2 = 72$ and $2^2 \times 3 \times 5 = 60$. The smallest is $N = 60$. Then $N^2 = 2^4 \times 3^2 \times 5^2$ has $5 \times 3 \times 3 = 45$ factors.",
  "Taking $72$ or $96$ as the smallest, or squaring the factor count.",
  "C21A-smallest-with-k-factors", "Casework on factorisations of $12$, then a second count.",
  correct=r"$45$",
  distractors=[(r"$35$", "Takes $N = 72$, so $N^2 = 2^6 \\times 3^4$ has $7 \\times 5 = 35$ factors."),
               (r"$33$", "Takes $N = 96$, so $N^2 = 2^{10} \\times 3^2$ has $11 \\times 3 = 33$ factors."),
               (r"$144$", "Assumes the factor count of $N^2$ is $12^2$.")],
  check=_c018, values=[45, 35, 33, 144], cognitive="Analysis")

# 019
def _c019():
    n = 1
    while _nd(n) != 18:
        n += 2
    return n
q("C21-A-019", T, "Smallest odd number with a given factor count", "Difficult",
  "Casework/optimisation",
  r"What is the smallest odd positive integer that has exactly $18$ positive factors? Enter the number.",
  "TITA",
  r"The primes available are $3, 5, 7, \ldots$. Factorisations of $18$: $18$, $9 \times 2$, $6 \times 3$, $3 \times 3 \times 2$, giving candidates $3^{17}$, $3^8 \times 5 = 32805$, $3^5 \times 5^2 = 6075$ and $3^2 \times 5^2 \times 7 = 1575$ (larger exponents on smaller primes). The smallest is $1575$.",
  "Forgetting that the prime $2$ is not allowed, or giving the larger exponent to a larger prime.",
  "C21A-smallest-with-k-factors", "Casework on the factorisations of $18$ with the restriction to odd primes.",
  tita_answer=1575, check=_c019,
  tita_traps=[(180, "Ignores the odd condition: $2^2 \\times 3^2 \\times 5 = 180$ is the smallest overall."),
              (2205, "Gives the single exponent to $5$ instead of $7$: $3^2 \\times 5 \\times 7^2 = 2205$.")],
  cognitive="Analysis", exams=HEAVY)

# 020
def _c020():
    return [k for k in range(10) if int(f"72{k}49") % 11 == 0][0]
q("C21-A-020", T, "Missing digit for divisibility by 11", "Easy",
  "Inverse/parameter",
  r"The five-digit number $72k49$, where $k$ is a single digit, is divisible by $11$. What is the value of $k$?",
  "MCQ",
  r"For divisibility by $11$, the sum of the digits in odd positions minus the sum in even positions must be a multiple of $11$: $(7 + k + 9) - (2 + 4) = 10 + k$. With $0 \le k \le 9$, the only multiple of $11$ is $11$, so $k = 1$.",
  "Applying a digit-sum test in place of the alternating-sum test, or putting $k$ in the wrong position group.",
  "C21A-divisibility-11-rule", "One application of the rule for $11$.",
  correct=r"$1$",
  distractors=[(r"$0$", "Requires the plain digit sum $22 + k$ to be a multiple of $11$."),
               (r"$5$", "Requires the digit sum $22 + k$ to be a multiple of $9$."),
               (r"$7$", "Places $k$ among the even positions: $(7 + 4 + 9) - (2 + k) = 18 - k = 11$.")],
  check=_c020, values=[1, 0, 5, 7], cognitive="Application")

# 021
def _c021():
    return sum(1 for a in range(1, 10) for b in range(10) for c in range(10)
               if int(f"{a}{b}{c}{b}{a}") % 11 == 0)
q("C21-A-021", T, "Counting five-digit palindromes divisible by 11", "Medium",
  "Casework/optimisation",
  r"A palindrome reads the same from left to right and from right to left, such as $34543$. How many five-digit palindromes are divisible by $11$? Enter the count.",
  "TITA",
  r"Write the palindrome as $\overline{abcba}$ with $a \ne 0$. The alternating sum is $a - b + c - b + a = 2a - 2b + c$, which must be a multiple of $11$. For each of the $9 \times 10 = 90$ choices of $(a, b)$, $c$ is fixed modulo $11$ as $c \equiv 2(b - a)$, and a digit $c$ exists unless that residue is $10$. The residue is $10$ exactly when $b - a \equiv 5 \pmod{11}$, that is $b - a = 5$ ($4$ pairs) or $b - a = -6$ ($4$ pairs). So the count is $90 - 8 = 82$.",
  "Believing every palindrome is divisible by $11$, which holds only for an even number of digits.",
  "C21A-divisibility-11-rule", "Turns the rule for $11$ into a congruence and counts the failures.",
  tita_answer=82, check=_c021,
  tita_traps=[(90, "Assumes a suitable middle digit $c$ exists for each of the $90$ choices of $(a, b)$, missing the cases where $c$ would have to be $10$."),
              (86, "Removes only one of the two failing cases $b - a = 5$ and $b - a = -6$.")],
  cognitive="Analysis")

# 022
def _c022():
    g = 0
    for X in range(100, 1000):
        s = str(X)
        if s[2] != "0" and int(s[0]) > int(s[2]):
            g = math.gcd(g, X - int(s[::-1]))
    return g
q("C21-A-022", T, "Divisibility of a number minus its reverse", "Easy",
  "Conceptual/application",
  r"$X$ is a three-digit number whose units digit is not zero and whose hundreds digit is greater than its units digit, and $Y$ is the number obtained by writing the digits of $X$ in reverse order. What is the largest positive integer that divides $X - Y$ for every such $X$?",
  "MCQ",
  r"If $X = 100a + 10b + c$, then $Y = 100c + 10b + a$ and $X - Y = 99(a - c)$. Since $a - c$ can be $1$ (for example $211 - 112 = 99$), the largest integer dividing every difference is $99$.",
  "Stopping at a single divisibility rule instead of computing the difference algebraically.",
  "C21A-reversal-divisibility", "One line of place-value algebra.",
  correct=r"$99$",
  distractors=[(r"$9$", "Notes only that $X$ and $Y$ have the same digit sum, so $9$ divides the difference."),
               (r"$11$", "Notes only that the alternating sums of $X$ and $Y$ are negatives of each other."),
               (r"$792$", "Reads the largest integer asked for as the largest possible value of $X - Y$: $981 - 189 = 99 \\times 8 = 792$.")],
  check=_c022, values=[99, 9, 11, 792], cognitive="Understanding")

# 023
def _c023():
    s = [(a, b) for a in range(10) for b in range(10) if int(f"6{a}43{b}") % 72 == 0]
    assert len(s) == 1
    return s[0][0] + s[0][1]
q("C21-A-023", T, "Two missing digits for divisibility by 72", "Easy",
  "Inverse/parameter",
  r"The five-digit number $6a43b$, where $a$ and $b$ are digits, is divisible by $72$. What is $a + b$?",
  "MCQ",
  r"$72 = 8 \times 9$. For $8$, the last three digits $43b$ must be a multiple of $8$; between $430$ and $439$ only $432$ works, so $b = 2$. For $9$, the digit sum $6 + a + 4 + 3 + 2 = 15 + a$ must be a multiple of $9$, so $a = 3$. Hence $a + b = 5$.",
  "Testing $4$ instead of $8$, or $3$ instead of $9$.",
  "C21A-divisibility-72-digits", "Two standard rules applied in sequence.",
  correct=r"$5$",
  distractors=[(r"$14$", "Tests $4$ on the last two digits, picks $b = 6$, then $19 + a$ gives $a = 8$."),
               (r"$2$", "Tests $3$ instead of $9$ and takes the smallest $a = 0$ with $b = 2$."),
               (r"$9$", "With $b = 2$, requires $a + b$ alone to be a multiple of $9$, so $a = 7$.")],
  check=_c023, values=[5, 14, 2, 9], cognitive="Application")

# 024
def _c024():
    return sum(1 for a in range(10) for b in range(10) if int(f"3{a}7{b}4") % 72 == 0)
q("C21-A-024", T, "Counting digit pairs for divisibility by 72", "Medium",
  "Casework/optimisation",
  r"In the five-digit number $3a7b4$, $a$ and $b$ are digits (they may be equal, and either may be $0$). For how many pairs $(a, b)$ is the number divisible by $72$? Enter the count.",
  "TITA",
  r"For $8$, $\overline{7b4}$ must be a multiple of $8$: of $704, 714, \ldots, 794$ only $704, 744, 784$ work, so $b \in \{0, 4, 8\}$. For $9$, $3 + a + 7 + b + 4 = 14 + a + b$ must be a multiple of $9$, so $a + b = 4$ or $13$. $b = 0$: $a = 4$. $b = 4$: $a = 0$ or $9$. $b = 8$: $a = 5$. That is $4$ pairs.",
  "Using the test for $4$ instead of $8$, or overlooking $a = 0$.",
  "C21A-divisibility-72-digits", "Casework over the digit allowed by the test for $8$, with two possible digit sums.",
  tita_answer=4, check=_c024,
  tita_traps=[(3, "Misses $a = 0$ with $b = 4$ (the number $30744$)."),
              (6, "Tests $4$ on the last two digits, allowing every even $b$, and gets $(4,0), (2,2), (0,4), (9,4), (7,6), (5,8)$.")],
  cognitive="Analysis")

# 025
def _c025():
    return sum(1 for r in range(2, 144) if 144 % r == 0 and 144 // r >= 2)
q("C21-A-025", T, "Rectangular arrangements as factor pairs", "Easy",
  "Multi-step word problem",
  r"A gardener plants $144$ saplings in a rectangular grid with the same number of saplings in every row. There must be at least $2$ rows and at least $2$ saplings in each row. A layout of $r$ rows with $c$ saplings each is different from a layout of $c$ rows with $r$ saplings each. How many different layouts are possible? Enter the number.",
  "TITA",
  r"A layout is a choice of the number of rows $r$, a divisor of $144 = 2^4 \times 3^2$, which has $5 \times 3 = 15$ divisors. Removing $r = 1$ and $r = 144$ (one row, or one sapling per row) leaves $13$ layouts.",
  r"Not removing the one-row and one-column layouts, or treating $r \times c$ and $c \times r$ as the same.",
  "C21A-factor-pair-arrangements", "Divisor count with two exclusions.",
  tita_answer=13, check=_c025,
  tita_traps=[(15, "Keeps the layouts with $1$ row or $1$ sapling per row."),
              (7, "Treats $r \\times c$ and $c \\times r$ as the same layout.")],
  cognitive="Application")

# 026
def _c026():
    return sum(1 for a in range(1, 3601) if 3600 % a == 0 and a < 3600 // a)
q("C21-A-026", T, "Unordered products of two distinct factors", "Medium",
  "Conceptual/application",
  r"In how many ways can $3600$ be written as a product of two different natural numbers, if the order of the two numbers does not matter?",
  "MCQ",
  r"$3600 = 2^4 \times 3^2 \times 5^2$ has $5 \times 3 \times 3 = 45$ divisors. Since $3600 = 60^2$, one divisor pairs with itself; the other $44$ form $22$ unordered pairs of different numbers. The answer is $22$.",
  r"Including $60 \times 60$, or counting ordered pairs.",
  "C21A-factor-pair-arrangements", "Needs the perfect-square adjustment when pairing divisors.",
  correct=r"$22$",
  distractors=[(r"$23$", "Includes $60 \\times 60$, whose two numbers are not different."),
               (r"$45$", "Counts divisors rather than pairs."),
               (r"$44$", "Counts ordered pairs of different numbers.")],
  check=_c026, values=[22, 23, 45, 44], cognitive="Understanding")

# 027
def _c027():
    blocks = set()
    for a in range(1, 721):
        for b in range(1, 721):
            if 720 % (a * b) == 0:
                blocks.add(tuple(sorted((a, b, 720 // (a * b)))))
    return len(blocks)
q("C21-A-027", T, "Unordered factorisations into three factors (cuboid blocks)", "Difficult",
  "Casework/optimisation",
  r"Harpreet has $720$ identical unit cubes and glues all of them into one solid rectangular block whose length, breadth and height are whole numbers of units (an edge of $1$ unit is allowed). Two blocks count as the same if they have the same three edge lengths in some order. How many different blocks can she make? Enter the number of blocks.",
  "TITA",
  r"First count ordered triples $(a, b, c)$ with $abc = 720 = 2^4 \times 3^2 \times 5$: the exponents of each prime are shared among three places, giving $\binom{6}{2} \times \binom{4}{2} \times \binom{3}{2} = 15 \times 6 \times 3 = 270$. No triple has all three equal, since $720$ is not a cube. Triples with exactly two equal edges have the form $a^2 c = 720$, where $a^2$ divides $720$: $a = 2^i 3^j$ with $i \le 2$, $j \le 1$, so $6$ choices, each appearing in $3$ orders, which is $18$ ordered triples. The remaining $252$ ordered triples have three different edges and come $6$ to a block. So the number of blocks is $\frac{252}{6} + 6 = 48$.",
  "Dividing the ordered count by $6$ for every block, although blocks with two equal edges appear in only $3$ orders.",
  "C21A-three-factor-factorisations", "Ordered count by sharing exponents, then a correction for blocks with two equal edges.",
  tita_answer=48, check=_c027,
  tita_traps=[(270, "Counts ordered triples, treating a change of orientation as a new block."),
              (45, "Divides all $270$ ordered triples by $6$, ignoring that blocks with two equal edges occur in only $3$ orders.")],
  cognitive="Analysis", exams=HEAVY)

# 028
def _c028():
    lamps = [False] * 301
    for k in range(1, 301):
        for m in range(k, 301, k):
            lamps[m] = not lamps[m]
    return sum(lamps[1:])
q("C21-A-028", T, "Toggling lamps and numbers with an odd number of factors", "Easy",
  "Conceptual/application",
  r"A corridor has $300$ lamps numbered $1$ to $300$, all initially off. $300$ people walk past one after another; the $k$th person changes the state (on to off, or off to on) of every lamp whose number is a multiple of $k$. After all $300$ people have passed, how many lamps are on?",
  "MCQ",
  r"Lamp $n$ is switched once for each factor of $n$, so it ends on exactly when $n$ has an odd number of factors, that is when $n$ is a perfect square. The squares up to $300$ are $1^2, \ldots, 17^2$ ($18^2 = 324$), so $17$ lamps are on.",
  "Reporting the lamps that are off, or miscounting the squares up to $300$.",
  "C21A-toggle-odd-factors", "One structural fact: only squares have an odd number of factors.",
  correct=r"$17$",
  distractors=[(r"$283$", "Reports the number of lamps that are off, $300 - 17$."),
               (r"$16$", "Leaves out lamp $1$, believing a lamp switched by only one person is off."),
               (r"$18$", "Rounds $\\sqrt{300} \\approx 17.3$ up and counts $18$ squares.")],
  check=_c028, values=[17, 283, 16, 18], cognitive="Understanding")

# 029
def _c029():
    lamps = [False] * 301
    for k in range(1, 300, 2):
        for m in range(k, 301, k):
            lamps[m] = not lamps[m]
    return sum(lamps[1:])
q("C21-A-029", T, "Toggling with only odd-numbered people: odd factors", "Difficult",
  "Conceptual/application",
  r"A corridor has $300$ lamps numbered $1$ to $300$, all initially off. Only the people numbered $1, 3, 5, \ldots, 299$ walk past, one after another; person $k$ changes the state (on to off, or off to on) of every lamp whose number is a multiple of $k$. After all of them have passed, how many lamps are on? Enter the number.",
  "TITA",
  r"Lamp $n$ is switched once for each odd factor of $n$. Write $n = 2^a m$ with $m$ odd; the odd factors of $n$ are the factors of $m$, so the lamp is on exactly when $m$ is a perfect square. Then $n$ is either a square (when $a$ is even) or twice a square (when $a$ is odd). Squares up to $300$: $17$. Twice a square up to $300$: $2k^2 \le 300$ gives $k \le 12$, so $12$. Total $17 + 12 = 29$.",
  "Answering with the squares alone as in the version where everyone takes part.",
  "C21A-toggle-odd-factors", "Requires reducing the count to odd factors and seeing the square or twice-square structure.",
  tita_answer=29, check=_c029,
  tita_traps=[(17, "Counts only the perfect squares, as if every person took part."),
              (9, "Counts only the odd perfect squares $1^2, 3^2, \\ldots, 17^2$.")],
  cognitive="Analysis", exams=HEAVY)

# 030
def _c030():
    N = 2**5 * 3**4 * 5**2
    return sum(1 for x in _divs(N) if x % 30 == 0)
q("C21-A-030", T, "Factors that are multiples of a given number", "Easy",
  "Single-step computation",
  r"How many positive factors of $N = 2^5 \times 3^4 \times 5^2$ are multiples of $30$? Enter the count.",
  "TITA",
  r"A factor that is a multiple of $30$ is $30k$ with $k$ a factor of $\frac{N}{30} = 2^4 \times 3^3 \times 5$. The count is $5 \times 4 \times 2 = 40$.",
  "Forgetting to add $1$ to each exponent of $N/30$.",
  "C21A-factors-multiple-of-m", "One reduction to $N/30$ and the divisor-count formula.",
  tita_answer=40, check=_c030,
  tita_traps=[(90, "Counts all factors of $N$, $6 \\times 5 \\times 3$."),
              (12, "Multiplies the exponents of $N/30$, $4 \\times 3 \\times 1$, without adding $1$.")],
  cognitive="Application")

# 031
def _c031():
    return sum(1 for x in _divs(10800) if x % 12 == 0 and x % 24 != 0)
q("C21-A-031", T, "Factors that are multiples of one number but not another", "Medium",
  "Conceptual/application",
  r"How many positive factors of $10800$ are multiples of $12$ but not multiples of $24$?",
  "MCQ",
  r"$10800 = 2^4 \times 3^3 \times 5^2$. A multiple of $12$ that is not a multiple of $24$ has exactly $2^2$, at least $3^1$, and any power of $5$: $1 \times 3 \times 3 = 9$. (Check: $27$ multiples of $12$ minus $18$ multiples of $24$.)",
  "Counting only the multiples of $12$, or dropping the requirement of a factor $3$.",
  "C21A-factors-multiple-of-m", "Two conditions on exponents combined.",
  correct=r"$9$",
  distractors=[(r"$27$", "Counts all multiples of $12$: $3 \\times 3 \\times 3$."),
               (r"$18$", "Counts the multiples of $24$: $2 \\times 3 \\times 3$."),
               (r"$12$", "Fixes $2^2$ but allows the exponent of $3$ to be $0$: $1 \\times 4 \\times 3$.")],
  check=_c031, values=[9, 27, 18, 12], cognitive="Application")

# 032
def _c032():
    return sum(1 for x in _divs(30**4) if sum(1 for p in (2, 3, 5) if x % p == 0) == 2)
q("C21-A-032", T, "Factors divisible by exactly two of three primes", "Medium",
  "Casework/optimisation",
  r"How many positive factors of $30^4$ are divisible by exactly two of the three primes $2$, $3$ and $5$?",
  "MCQ",
  r"$30^4 = 2^4 \times 3^4 \times 5^4$. Choose which two primes appear ($3$ ways); each of them gets an exponent from $1$ to $4$ ($4 \times 4$ ways) and the third prime gets exponent $0$. Total $3 \times 16 = 48$.",
  "Allowing exponent $0$ for the chosen primes, or counting factors divisible by all three.",
  "C21A-factors-prime-support", "Casework over the choice of primes with restricted exponents.",
  correct=r"$48$",
  distractors=[(r"$75$", "Allows exponents $0$ to $4$ for the two chosen primes: $3 \\times 5 \\times 5$, counting overlaps."),
               (r"$64$", "Counts the factors divisible by all three primes, $4 \\times 4 \\times 4$."),
               (r"$16$", "Considers only one pair of primes.")],
  check=_c032, values=[48, 75, 64, 16], cognitive="Application")

# 033
def _c033():
    return sum(1 for n in range(-200, 200) if n != -1 and (n * n + 3 * n + 20) % (n + 1) == 0)
q("C21-A-033", T, "Integer values of a rational expression via divisors", "Medium",
  "Inverse/parameter",
  r"For how many integers $n$ (positive, negative or zero) is $\frac{n^2 + 3n + 20}{n + 1}$ an integer? Enter the count.",
  "TITA",
  r"$n^2 + 3n + 20 = (n + 1)(n + 2) + 18$, so the expression is an integer exactly when $n + 1$ divides $18$. $18$ has $6$ positive divisors, so $n + 1$ can take $12$ values ($\pm 1, \pm 2, \pm 3, \pm 6, \pm 9, \pm 18$), each giving a different $n$. The answer is $12$.",
  "Using only positive divisors, or only positive $n$.",
  "C21A-divisor-of-expression", "Polynomial division reduces the condition to divisors of a constant.",
  tita_answer=12, check=_c033,
  tita_traps=[(6, "Uses only the positive divisors of $18$."),
              (5, "Counts only positive $n$, that is $n + 1 \\in \\{2, 3, 6, 9, 18\\}$.")],
  cognitive="Application")

# 034
def _c034():
    return sum(1 for n in range(1, 2000) if (n**3 + 200) % (n + 8) == 0)
q("C21-A-034", T, "Positive n for which n+8 divides a cubic", "Difficult",
  "Inverse/parameter",
  r"For how many positive integers $n$ is $n^3 + 200$ divisible by $n + 8$?",
  "MCQ",
  r"Since $n \equiv -8 \pmod{n + 8}$, $n^3 + 200 \equiv -512 + 200 = -312$. So $n + 8$ must divide $312 = 2^3 \times 3 \times 13$, which has $16$ divisors. As $n \ge 1$, $n + 8 \ge 9$; the divisors $1, 2, 3, 4, 6, 8$ are too small, leaving $16 - 6 = 10$ values.",
  r"Forgetting the lower bound $n + 8 \ge 9$.",
  "C21A-divisor-of-expression", "Remainder substitution, factorisation, then a bound on the divisor.",
  correct=r"$10$",
  distractors=[(r"$16$", "Counts all positive divisors of $312$, ignoring $n + 8 \\ge 9$."),
               (r"$11$", "Also accepts the divisor $8$, which gives $n = 0$, not positive."),
               (r"$6$", "Counts the divisors of $312$ that are at most $8$.")],
  check=_c034, values=[10, 16, 11, 6], cognitive="Analysis", exams=HEAVY)

# 035
def _c035():
    g = 0
    for n in range(2, 300):
        g = math.gcd(g, n**5 - n)
    return g
q("C21-A-035", T, "Largest integer always dividing a polynomial expression", "Medium",
  "Conceptual/application",
  r"What is the largest positive integer that divides $n^5 - n$ for every integer $n \ge 2$?",
  "MCQ",
  r"$n^5 - n = (n - 1)n(n + 1)(n^2 + 1)$. Three consecutive integers give a factor $6$. Modulo $5$, $n^5 \equiv n$ for every $n$, so $5$ also divides it. Hence $30$ always divides it, and $n = 2$ gives $30$ itself, so nothing larger works.",
  "Spotting only the three consecutive integers, or treating the expression as five consecutive integers.",
  "C21A-always-divides", "Combines a consecutive-product argument with a divisibility by $5$.",
  correct=r"$30$",
  distractors=[(r"$6$", "Uses only the product of three consecutive integers."),
               (r"$10$", "Uses divisibility by $2$ and by $5$ but misses $3$."),
               (r"$120$", "Treats $n^5 - n$ as a product of five consecutive integers.")],
  check=_c035, values=[30, 6, 10, 120], cognitive="Analysis")

# 036
def _c036():
    g = 0
    for n in range(5, 600, 2):
        g = math.gcd(g, (n * n - 1) * (n * n - 9))
    return g
q("C21-A-036", T, "Largest integer dividing a product for all odd n", "Difficult",
  "Conceptual/application",
  r"What is the largest positive integer that divides $(n^2 - 1)(n^2 - 9)$ for every odd integer $n > 3$? Enter the number.",
  "TITA",
  r"The product is $(n - 3)(n - 1)(n + 1)(n + 3)$. With $n = 2k + 1$ it equals $(2k - 2)(2k)(2k + 2)(2k + 4) = 16(k - 1)k(k + 1)(k + 2)$. Four consecutive integers have a product divisible by $24$, so $16 \times 24 = 384$ always divides it. For $n = 5$ the value is $2 \times 4 \times 6 \times 8 = 384$, so no larger number works.",
  "Treating the four factors as consecutive integers rather than consecutive even numbers.",
  "C21A-always-divides", "Needs a substitution to expose four consecutive even numbers, then a tightness check.",
  tita_answer=384, check=_c036,
  tita_traps=[(24, "Treats the factors as four consecutive integers."),
              (16, "Takes one factor $2$ from each even factor and misses the $24$ from $(k-1)k(k+1)(k+2)$.")],
  cognitive="Analysis", exams=HEAVY)

# 037
def _c037():
    return sum(1 for p in itertools.permutations("0123456", 4)
               if p[0] != "0" and int("".join(p)) % 11 == 0)
q("C21-A-037", T, "Four-digit numbers from a digit set divisible by 11", "Difficult",
  "Casework/optimisation",
  r"Four-digit numbers with four different digits are formed using only the digits $0, 1, 2, 3, 4, 5, 6$; a number cannot begin with $0$. How many of these numbers are divisible by $11$? Enter the count.",
  "TITA",
  r"For $\overline{pqrs}$, $11$ divides the number exactly when $(p + r) - (q + s)$ is a multiple of $11$. Two different digits from the set sum to between $1$ and $11$, so the difference lies between $-10$ and $10$ and must be $0$: the four digits split into two disjoint pairs with equal sums. Listing pairs by sum, the splits are: sum $3$: $1$; sum $4$: $1$; sum $5$: $3$; sum $6$: $3$; sum $7$: $3$; sum $8$: $1$; sum $9$: $1$, a total of $13$ splits. Each split gives $2 \times 2 \times 2 = 8$ numbers (which pair takes the first and third places, and the order within each pair), so $104$ in all. In $6$ splits one pair contains $0$, and in $2$ of the $8$ numbers for such a split $0$ stands first. The answer is $104 - 12 = 92$.",
  "Forgetting to remove the arrangements that begin with $0$, or not swapping which pair occupies the odd places.",
  "C21A-digit-arrangement-divisibility", "Converts the test for $11$ into equal-sum pairings, then casework over sums with a leading-zero correction.",
  tita_answer=92, check=_c037,
  tita_traps=[(104, "Keeps the arrangements that begin with $0$."),
              (13, "Counts the splits into two equal-sum pairs instead of the numbers they produce.")],
  cognitive="Analysis", exams=HEAVY)

# 038
def _c038():
    return sum(1 for p in itertools.permutations("12345", 4) if int("".join(p)) % 12 == 0)
q("C21-A-038", T, "Four-digit arrangements divisible by 12", "Medium",
  "Multi-step word problem",
  r"Four-digit numbers with all digits different are formed using only the digits $1, 2, 3, 4, 5$. How many of them are divisible by $12$?",
  "MCQ",
  r"For divisibility by $3$, the four digits must sum to a multiple of $3$. The five digits sum to $15$, so the omitted digit must be a multiple of $3$, that is $3$: the digits are $1, 2, 4, 5$. For divisibility by $4$, the ending must be $12$, $24$ or $52$. Each ending leaves two digits to arrange in $2$ ways, so $3 \times 2 = 6$.",
  "Testing $2$ instead of $4$, or ignoring one of the two conditions.",
  "C21A-digit-arrangement-divisibility", "Combines the tests for $3$ and $4$ with a choice of digits.",
  correct=r"$6$",
  distractors=[(r"$12$", "Tests $2$ instead of $4$: last digit $2$ or $4$, giving $2 \\times 3! = 12$."),
               (r"$24$", "Checks only divisibility by $3$, giving $4! = 24$."),
               (r"$3$", "Counts only the valid endings and forgets to arrange the first two digits.")],
  check=_c038, values=[6, 12, 24, 3], cognitive="Application")

# 039
def _c039():
    best = max(_nd(n) for n in range(1, 101))
    return sum(1 for n in range(1, 101) if _nd(n) == best)
q("C21-A-039", T, "How many numbers in a range attain the largest factor count", "Difficult",
  "Casework/optimisation",
  r"Let $m$ be the largest number of positive factors that any integer from $1$ to $100$ (both inclusive) has. How many integers from $1$ to $100$ have exactly $m$ positive factors?",
  "MCQ",
  r"The smallest numbers with $13$, $14$, $15$ and $16$ factors are $2^{12}$, $2^6 \times 3 = 192$, $2^4 \times 3^2 = 144$ and $2^3 \times 3 \times 5 = 120$, and every larger factor count needs a number of at least $180$, so no number up to $100$ has more than $12$ factors. Twelve factors come from $p^2 q r$, $p^3 q^2$ or $p^5 q$: $p^2 q r$ gives $60$, $84$ and $90$; $p^3 q^2$ gives $72$; $p^5 q$ gives $96$; $p^{11}$ is too large. So $5$ integers attain the maximum of $12$ factors.",
  "Listing only one or two of the three forms that give $12$ factors, or assuming the maximiser is unique.",
  "C21A-max-factor-count", "Two stages: first prove that no integer up to $100$ has more than $12$ factors by bounding the smallest number with each larger factor count, then casework over three prime-exponent forms for $12$.",
  correct=r"$5$",
  distractors=[(r"$4$", "Misses the form $p^5 q$, that is $96$."),
               (r"$3$", "Uses only the form $p^2 q r$, listing $60$, $84$ and $90$."),
               (r"$1$", "Assumes the number with the most factors is unique and takes it to be $60$.")],
  check=_c039, values=[5, 4, 3, 1], cognitive="Analysis", exams=HEAVY)

# 040
def _c040():
    g = 0
    for x in range(10, 100):
        g = math.gcd(g, int(str(x) * 3))
    return g
q("C21-A-040", T, "Two-digit block written three times and the factor 10101", "Easy",
  "Conceptual/application",
  r"A six-digit number is formed by writing a two-digit number (from $10$ to $99$) three times in a row; for example, $47$ gives $474747$. What is the largest positive integer that divides every number formed in this way?",
  "MCQ",
  r"Writing $\overline{xy}$ three times gives $\overline{xy} \times 10000 + \overline{xy} \times 100 + \overline{xy} = 10101 \times \overline{xy}$. So $10101 = 3 \times 7 \times 13 \times 37$ divides every such number, and since $\overline{xy}$ can be $10$ and $11$ (coprime), nothing larger divides all of them. The answer is $10101$.",
  "Spotting only some of the prime factors $3$, $7$, $13$, $37$ of $10101$.",
  "C21A-repeated-block-place-value", "One place-value observation.",
  correct=r"$10101$",
  distractors=[(r"$3367$", "Finds the factors $7$, $13$ and $37$ but misses $3$."),
               (r"$1443$", "Finds the factors $3$, $13$ and $37$ but misses $7$."),
               (r"$777$", "Finds the factors $3$, $7$ and $37$ but misses $13$.")],
  check=_c040, values=[10101, 3367, 1443, 777], cognitive="Understanding")

# 041
def _c041():
    N = 2**3 * 3**4 * 5**2 * 7**2
    return sum(1 for x in _divs(N) if x % 4 == 1)
q("C21-A-041", T, "Divisors leaving remainder 1 on division by 4", "Difficult",
  "Conceptual/application",
  r"Let $N = 2^3 \times 3^4 \times 5^2 \times 7^2$. How many positive divisors of $N$ (including $1$) leave remainder $1$ when divided by $4$?",
  "MCQ",
  r"An even divisor leaves remainder $0$ or $2$, so only odd divisors $3^i 5^j 7^k$ count, with $0 \le i \le 4$, $0 \le j \le 2$, $0 \le k \le 2$. Modulo $4$, $3 \equiv -1$, $5 \equiv 1$ and $7 \equiv -1$, so the divisor is $\equiv (-1)^{i + k}$ and leaves remainder $1$ exactly when $i + k$ is even. That happens for $i, k$ both even ($3 \times 2 = 6$ ways) or both odd ($2 \times 1 = 2$ ways), so $8$ ways, and $j$ is free ($3$ ways). The count is $8 \times 3 = 24$.",
  "Treating $7$ like $5$ as a number of the form $4m + 1$, or counting every odd divisor.",
  "C21A-divisor-residue-mod-4", "Needs the residues of the primes modulo $4$ and a parity casework on two exponents.",
  correct=r"$24$",
  distractors=[(r"$21$", "Counts the odd divisors that leave remainder $3$, that is $45 - 24$."),
               (r"$27$", "Treats $7$ as leaving remainder $1$, so only the exponent of $3$ must be even: $3 \\times 3 \\times 3 = 27$."),
               (r"$45$", "Counts all odd divisors, $5 \\times 3 \\times 3 = 45$.")],
  check=_c041, values=[24, 21, 27, 45], cognitive="Analysis", exams=HEAVY)

# 042
def _c042():
    from sympy import divisor_count
    vals = set()
    for N in range(6, 200000, 6):
        if divisor_count(N) == 10:
            vals.add(int(divisor_count(N * N)))
    assert len(vals) == 1
    return vals.pop()
q("C21-A-042", T, "Factor count of N squared when N is not unique", "Difficult",
  "Casework/optimisation",
  r"A positive integer $N$ is a multiple of $6$ and has exactly $10$ positive factors. How many positive factors does $N^2$ have?",
  "MCQ",
  r"$10 = 10$ or $5 \times 2$, so $N = p^9$ or $p^4 q$. Being a multiple of $6$, $N$ has both $2$ and $3$, so $N = 2^4 \times 3 = 48$ or $N = 3^4 \times 2 = 162$. In either case $N^2$ is $2^8 \times 3^2$ or $2^2 \times 3^8$, which has $9 \times 3 = 27$ factors. So the answer is $27$, even though $N$ itself is not unique.",
  "Assuming the factor count doubles or squares when the number is squared.",
  "C21A-k-factors-casework", "Casework gives two possible $N$; the solver must see both lead to the same count.",
  correct=r"$27$",
  distractors=[(r"$20$", "Doubles the factor count of $N$."),
               (r"$19$", "Uses $2d - 1$ as the factor count of $N^2$."),
               (r"$100$", "Squares the factor count of $N$.")],
  check=_c042, values=[27, 20, 19, 100], cognitive="Analysis", exams=HEAVY)

# 043
def _c043():
    return sum(1 for n in range(1, 61) if int("".join(str(i) for i in range(1, n + 1))) % 9 == 0)
q("C21-A-043", T, "Divisibility by 9 of a number formed by writing 1 to n", "Medium",
  "Conceptual/application",
  r"For a positive integer $n$, let $W_n$ be the number formed by writing the integers $1, 2, 3, \ldots, n$ one after another; for example, $W_{12} = 123456789101112$. For how many values of $n$ from $1$ to $60$ is $W_n$ divisible by $9$?",
  "MCQ",
  r"Each integer is congruent to its own digit sum modulo $9$, so the digit sum of $W_n$ is congruent to $1 + 2 + \cdots + n = \frac{n(n+1)}{2}$. This is a multiple of $9$ exactly when $9$ divides $n(n+1)$, that is $n \equiv 0$ or $8 \pmod 9$. From $1$ to $60$: $8, 9, 17, 18, 26, 27, 35, 36, 44, 45, 53, 54$, which is $12$ values.",
  "Requiring $n$ itself to be a multiple of $9$, or applying the rule for $3$.",
  "C21A-concatenation-digit-sum", "Needs the digit-sum congruence applied to a whole block of numbers.",
  correct=r"$12$",
  distractors=[(r"$6$", "Counts only the multiples of $9$, missing $n \\equiv 8 \\pmod 9$."),
               (r"$13$", "Takes $n + 1$ a multiple of $9$ as $n \\equiv 1 \\pmod 9$, giving $n \\equiv 0$ or $1$."),
               (r"$40$", "Applies the rule for $3$: $n \\equiv 0$ or $2 \\pmod 3$.")],
  check=_c043, values=[12, 6, 13, 40], cognitive="Analysis")

# 044
def _c044():
    from sympy import divisor_count
    vals = set()
    for N in range(1, 200000):
        if divisor_count(N) == 12 and divisor_count(2 * N) == 15:
            vals.add(int(divisor_count(N * N)))
    assert len(vals) == 1
    return vals.pop()
q("C21-A-044", T, "Using the change in factor count when doubling N", "Medium",
  "Inverse/parameter",
  r"A positive integer $N$ has exactly $12$ positive factors, and $2N$ has exactly $15$ positive factors. How many positive factors does $N^2$ have?",
  "MCQ",
  r"Write $N = 2^a M$ with $M$ odd, and let $M$ have $m$ factors. Then $(a + 1)m = 12$ and $(a + 2)m = 15$; subtracting, $m = 3$ and $a = 3$. An odd number with $3$ factors is $p^2$ for an odd prime $p$, so $N = 2^3 p^2$ and $N^2 = 2^6 p^4$ has $7 \times 5 = 35$ factors.",
  "Assuming the factor count of $N^2$ is a simple function of the factor count of $N$.",
  "C21A-factor-count-shift", "Two counts give the exponent of $2$ and the structure of the odd part.",
  correct=r"$35$",
  distractors=[(r"$144$", "Squares the factor count of $N$."),
               (r"$23$", "Uses $2d - 1$ with $d = 12$."),
               (r"$24$", "Doubles the factor count of $N$.")],
  check=_c044, values=[35, 144, 23, 24], cognitive="Analysis")

# 045
def _c045():
    best = None
    for a in range(0, 30):
        for b in range(0, 30):
            N = 2**a * 3**b
            ds = _divs(N) if N < 10**7 else None
            if ds is None:
                continue
            sq = sum(1 for x in ds if _is_sq(x))
            cu = sum(1 for x in ds if _is_cube(x))
            if sq == 12 and cu == 6 and (best is None or N < best):
                best = N
    return best
q("C21-A-045", T, "Find N from its counts of square and cube factors", "Difficult",
  "Inverse/parameter",
  r"$N = 2^a \times 3^b$, where $a$ and $b$ are non-negative integers. Exactly $12$ positive factors of $N$ are perfect squares and exactly $6$ are perfect cubes (the factor $1$ is counted in both). What is the smallest possible value of $N$?",
  "MCQ",
  r"The counts are $(\lfloor a/2 \rfloor + 1)(\lfloor b/2 \rfloor + 1) = 12$ and $(\lfloor a/3 \rfloor + 1)(\lfloor b/3 \rfloor + 1) = 6$. If the cube count splits as $3 \times 2$, then $a \in \{6,7,8\}$ and $b \in \{3,4,5\}$; the square count $12 = 4 \times 3$ then needs $a \in \{6,7\}$ and $b \in \{4,5\}$, smallest $2^6 \times 3^4$. The split $2 \times 3$ gives at best $2^4 \times 3^6$, which is larger, and the splits $1 \times 6$, $6 \times 1$ make the square count $8, 9, 16$ or $18$, never $12$. So the smallest $N$ is $2^6 \times 3^4$.",
  "Assigning the larger exponent to the larger prime, or not taking the smallest exponents allowed.",
  "C21A-square-cube-inverse", "Two floor-function conditions with casework over splits of $6$ and $12$.",
  correct=r"$2^{6} \times 3^{4}$",
  distractors=[(r"$2^{4} \times 3^{6}$", "Uses the split with the larger exponent on $3$, which satisfies both counts but is larger."),
               (r"$2^{7} \times 3^{4}$", "Takes $a = 7$, which also works but is not the smallest exponent allowed."),
               (r"$2^{6} \times 3^{3}$", "Takes the smallest exponents meeting the cube count, $a = 6$ and $b = 3$, without checking the square count, which is then $4 \\times 2 = 8$.")],
  check=_c045, values=[2**6 * 3**4, 2**4 * 3**6, 2**7 * 3**4, 2**6 * 3**3],
  cognitive="Analysis", exams=HEAVY)
