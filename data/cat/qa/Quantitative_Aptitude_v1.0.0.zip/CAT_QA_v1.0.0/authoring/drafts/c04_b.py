import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Proportion and variation"
CX = ("CAT", "XAT")


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ---------------------------------------------------------------- EASY (12)

def _e1():
    k = F(1200, 12 * 8)                       # tiles per square metre
    return k * 15 * 12
q("C04-B-001", T, "Direct variation of a count with floor area when both dimensions change", "Easy",
  "Single-step computation",
  r"The number of identical tiles needed to cover a floor varies directly as the area of the floor. A rectangular hall $12$ m long and $8$ m wide needs $1{,}200$ tiles. How many such tiles are needed for a rectangular hall $15$ m long and $12$ m wide?",
  "MCQ",
  r"Tiles per square metre $= \frac{1200}{12 \times 8} = 12.5$. The new area is $15 \times 12 = 180$ m$^2$, so the hall needs $12.5 \times 180 = 2250$ tiles.",
  "Scaling by one dimension or by the perimeter instead of by the area.",
  "C04B-joint-variation-simple", "One proportion; the trap is scaling by a length instead of the area.",
  correct=r"$2250$",
  distractors=[(r"$1620$", r"Scales by the perimeter: $1200 \times \frac{54}{40} = 1620$."),
               (r"$1500$", r"Scales by the length only: $1200 \times \frac{15}{12} = 1500$."),
               (r"$1800$", r"Scales by the width only: $1200 \times \frac{12}{8} = 1800$.")],
  check=_e1, values=[2250, 1620, 1500, 1800], cognitive="Application")


def _e2():
    total_lines = 24 * 300
    new_pages = F(total_lines, 24 + 6)
    return 300 - new_pages
q("C04-B-002", T, "Inverse variation of page count with lines per page; pages saved", "Easy",
  "Multi-step word problem",
  r"For a fixed manuscript, the number of pages needed varies inversely as the number of lines printed on each page. At $24$ lines per page the manuscript fills $300$ pages. If the number of lines per page is increased by $6$, how many pages are saved?",
  "TITA",
  r"The total number of lines is $24 \times 300 = 7200$. At $30$ lines per page this needs $\frac{7200}{30} = 240$ pages, so $300 - 240 = 60$ pages are saved.",
  r"Assuming a $25\%$ rise in lines per page cuts pages by $25\%$.",
  "C04B-inverse-variation-basic", "Single inverse proportion with a percent trap.",
  tita_answer=60, check=_e2,
  tita_traps=[(75, r"Lines rise by $25\%$, so takes pages to fall by $25\%$ of $300$."),
              (240, r"Reports the new number of pages instead of the pages saved.")],
  cognitive="Application")


def _e3():
    k = F(9600, 8 * 150)
    return k * 5 * 240
q("C04-B-003", T, "Joint variation of transport cost with weight and distance", "Easy",
  "Single-step computation",
  r"The cost of transporting goods by a carrier varies jointly as the weight of the goods and the distance carried. Transporting $8$ tonnes over $150$ km costs Rs. $9{,}600$. What does it cost to transport $5$ tonnes over $240$ km?",
  "MCQ",
  r"Cost $= k \times \text{weight} \times \text{distance}$ with $k = \frac{9600}{8 \times 150} = 8$. Hence the cost is $8 \times 5 \times 240 =$ Rs. $9{,}600$; the product weight $\times$ distance is $1200$ in both cases.",
  "Scaling by only one of the two quantities.",
  "C04B-joint-variation-simple", "Direct substitution in a joint variation; the trap is using only one factor.",
  correct=r"Rs. $9{,}600$",
  distractors=[(r"Rs. $6{,}000$", r"Scales by weight only: $9600 \times \frac{5}{8} = 6000$."),
               (r"Rs. $15{,}360$", r"Scales by distance only: $9600 \times \frac{240}{150} = 15360$."),
               (r"Rs. $3{,}750$", r"Treats cost as varying inversely with distance: $9600 \times \frac{5}{8} \times \frac{150}{240} = 3750$.")],
  check=_e3, values=[9600, 6000, 15360, 3750], cognitive="Application")


def _e4():
    k = F(54, 6 ** 3)
    return k * 8 ** 3
q("C04-B-004", T, "Power varies as the cube of wind speed", "Easy",
  "Single-step computation",
  r"The power produced by a wind turbine varies as the cube of the wind speed. At a wind speed of $6$ m/s it produces $54$ kW. How much power does it produce at a wind speed of $8$ m/s?",
  "MCQ",
  r"Power $\propto v^3$, so the new power is $54 \times \left(\frac{8}{6}\right)^3 = 54 \times \frac{64}{27} = 128$ kW.",
  "Scaling linearly or by the square, or approximating the cube of a ratio by tripling its percent change.",
  "C04B-power-variation", "One power variation; the trap is the wrong exponent.",
  correct=r"$128$ kW",
  distractors=[(r"$72$ kW", r"Uses direct (first power) variation: $54 \times \frac{8}{6} = 72$."),
               (r"$96$ kW", r"Uses the square: $54 \times \frac{64}{36} = 96$."),
               (r"$108$ kW", r"Speed rises by $33\frac{1}{3}\%$; triples that to a $100\%$ rise, giving $108$.")],
  check=_e4, values=[128, 72, 96, 108], cognitive="Application")


def _e5():
    a, b = symbols('a b')
    s = solve([Eq(a + 40 * b, 14000), Eq(a + 65 * b, 20500)], [a, b])
    return s[a] + 90 * s[b]
q("C04-B-005", T, "Partly fixed, partly variable catering charge from two data points", "Easy",
  "Multi-step word problem",
  r"A caterer's charge for a party is partly fixed and partly varies directly as the number of guests. The charge is Rs. $14{,}000$ for $40$ guests and Rs. $20{,}500$ for $65$ guests. What is the charge, in rupees, for $90$ guests?",
  "TITA",
  r"$25$ extra guests add Rs. $6{,}500$, so the variable rate is Rs. $260$ per guest and the fixed part is $14000 - 40 \times 260 =$ Rs. $3{,}600$. For $90$ guests: $3600 + 90 \times 260 = 27000$.",
  "Treating the whole charge as directly proportional to the number of guests.",
  "C04B-fixed-plus-variable-linear", "Two linear equations; the trap is ignoring the fixed part.",
  tita_answer=27000, check=_e5,
  tita_traps=[(31500, r"Treats the whole charge as proportional: $14000 \times \frac{90}{40}$."),
              (23400, r"Reports only the variable part $90 \times 260$.")],
  cognitive="Application")


def _e6():
    a, b = 16, 36
    x = symbols('x', positive=True)
    return _pos(solve(Eq(F(a, b), b / x), x))[0]
q("C04-B-006", T, "Third proportional to two numbers", "Easy",
  "Single-step computation",
  r"The third proportional to $16$ and $36$ is",
  "MCQ",
  r"If $x$ is the third proportional, $16 : 36 = 36 : x$, so $x = \frac{36^2}{16} = \frac{1296}{16} = 81$.",
  "Mixing up third proportional with mean proportional or with the next term of an arithmetic progression.",
  "C04B-third-proportional", "Direct recall of the definition; one computation.",
  correct=r"$81$",
  distractors=[(r"$24$", r"Gives the mean proportional $\sqrt{16 \times 36} = 24$."),
               (r"$56$", r"Continues the difference: $36 + (36 - 16) = 56$."),
               (r"$26$", r"Gives the arithmetic mean $\frac{16 + 36}{2} = 26$.")],
  check=_e6, values=[81, 24, 56, 26], cognitive="Recall")


def _e7():
    p = 1
    n0 = F(1, p)
    n1 = F(1, F(p) * F(160, 100))
    return (n0 - n1) / n0 * 100
q("C04-B-007", T, "Percent fall in quantity bought when price rises, fixed budget", "Easy",
  "Conceptual/application",
  r"With a fixed budget, the number of notebooks a school can buy varies inversely as the price of a notebook. If the price of a notebook rises by $60\%$, by what percent does the number of notebooks the school can buy fall?",
  "MCQ",
  r"The number bought is proportional to $\frac{1}{\text{price}}$. The new number is $\frac{1}{1.6} = 0.625$ times the old, a fall of $37.5\%$.",
  "Assuming an inverse variation changes the other quantity by the same percent.",
  "C04B-percent-change-single", "One inverse proportion turned into a percent; the trap is the symmetric percent.",
  correct=r"$37.5\%$",
  distractors=[(r"$60\%$", r"Assumes the number falls by the same percent as the price rises."),
               (r"$62.5\%$", r"Reports the new number as a percent of the old, $\frac{1}{1.6} = 62.5\%$."),
               (r"$40\%$", r"Takes the fall as $100 - 60 = 40$ percent.")],
  check=_e7, values=[F(75, 2), 60, F(125, 2), 40], cognitive="Understanding")


def _e8():
    total = 120 * 45
    left = total - 120 * 15
    return F(left, 120 + 30)
q("C04-B-008", T, "Provisions after extra people join midway", "Easy",
  "Multi-step word problem",
  r"A hostel has enough food for $120$ students for $45$ days, each student eating the same amount daily. After $15$ days, $30$ more students join. For how many more days will the remaining food last after they join?",
  "TITA",
  r"After $15$ days, food for $120 \times 30 = 3600$ student-days remains. It is now shared by $150$ students, so it lasts $\frac{3600}{150} = 24$ more days.",
  "Ignoring the days already used, or counting from the start.",
  "C04B-provisions", "Inverse variation of days with people after one adjustment.",
  tita_answer=24, check=_e8,
  tita_traps=[(36, r"Ignores the $15$ days already used: $\frac{120 \times 45}{150}$."),
              (39, r"Adds the $15$ elapsed days to $24$ and reports the total from the start.")],
  cognitive="Application")


def _e9():
    return (1 - F(45, 60) ** 2) * 100
q("C04-B-009", T, "Percent change in braking distance when it varies as the square of speed", "Easy",
  "Conceptual/application",
  r"The braking distance of a car varies as the square of its speed. If the speed is reduced from $60$ km/h to $45$ km/h, by what percent does the braking distance fall?",
  "MCQ",
  r"The speed becomes $\frac{45}{60} = \frac{3}{4}$ of the original, so the braking distance becomes $\frac{9}{16} = 56.25\%$ of the original. It falls by $43.75\%$.",
  "Applying the percent change of speed directly, or doubling it.",
  "C04B-percent-change-single", "One square-law ratio; traps are linear scaling and the remaining fraction.",
  correct=r"$43.75\%$",
  distractors=[(r"$25\%$", r"Treats the distance as varying directly as speed."),
               (r"$56.25\%$", r"Reports the remaining distance $\frac{9}{16}$ as the fall."),
               (r"$50\%$", r"Doubles the $25\%$ fall in speed because of the square.")],
  check=_e9, values=[F(175, 4), 25, F(225, 4), 50], cognitive="Understanding")


def _e10():
    k = F(4500, 15 * 2)
    return k * 24 * F(5, 2)
q("C04-B-010", T, "Joint variation of brick count with length and height of a wall", "Easy",
  "Single-step computation",
  r"For walls of the same thickness, the number of bricks needed varies jointly as the length and the height of the wall. A wall $15$ m long and $2$ m high needs $4{,}500$ bricks. How many bricks are needed for a wall of the same thickness that is $24$ m long and $2.5$ m high?",
  "MCQ",
  r"Bricks per square metre of wall face $= \frac{4500}{15 \times 2} = 150$. The new wall face is $24 \times 2.5 = 60$ m$^2$, so it needs $150 \times 60 = 9000$ bricks.",
  "Scaling by only one dimension, or treating one dimension inversely.",
  "C04B-joint-variation-simple", "Direct joint-variation substitution with one trap.",
  correct=r"$9000$",
  distractors=[(r"$7200$", r"Scales by length only: $4500 \times \frac{24}{15} = 7200$."),
               (r"$5625$", r"Scales by height only: $4500 \times \frac{2.5}{2} = 5625$."),
               (r"$5760$", r"Treats height inversely: $4500 \times \frac{24}{15} \times \frac{2}{2.5} = 5760$.")],
  check=_e10, values=[9000, 7200, 5625, 5760], cognitive="Application")


def _e11():
    a, b = symbols('a b')
    s = solve([Eq(a + 12 * b, 228), Eq(a + 20 * b, 340)], [a, b])
    return s[a] + 32 * s[b]
q("C04-B-011", T, "Taxi fare as fixed charge plus a part proportional to distance", "Easy",
  "Multi-step word problem",
  r"A taxi fare consists of a fixed charge plus a charge that varies directly as the distance travelled. A $12$ km ride costs Rs. $228$ and a $20$ km ride costs Rs. $340$. What is the fare for a $32$ km ride?",
  "MCQ",
  r"The extra $8$ km cost Rs. $112$, so the rate is Rs. $14$ per km and the fixed charge is $228 - 12 \times 14 =$ Rs. $60$. For $32$ km the fare is $60 + 32 \times 14 =$ Rs. $508$.",
  "Treating the fare as proportional to distance.",
  "C04B-fixed-plus-variable-linear", "Two-point linear model; trap is ignoring the fixed charge.",
  correct=r"Rs. $508$",
  distractors=[(r"Rs. $544$", r"Scales the $20$ km fare proportionally: $340 \times \frac{32}{20} = 544$."),
               (r"Rs. $608$", r"Scales the $12$ km fare proportionally: $228 \times \frac{32}{12} = 608$."),
               (r"Rs. $448$", r"Reports only the distance part $32 \times 14 = 448$.")],
  check=_e11, values=[508, 544, 608, 448], cognitive="Application")


def _e12():
    d = symbols('d', positive=True)
    k = 400 * 3 ** 2
    return _pos(solve(Eq(k / d ** 2, 25), d))[0]
q("C04-B-012", T, "Inverse square variation of light intensity with distance", "Easy",
  "Inverse/parameter",
  r"The intensity of light from a lamp varies inversely as the square of the distance from the lamp. At a distance of $3$ m the intensity is $400$ lux. At what distance from the lamp, in metres, is the intensity $25$ lux?",
  "TITA",
  r"Intensity $\times d^2$ is constant: $400 \times 9 = 25 \times d^2$, so $d^2 = 144$ and $d = 12$ m. Equivalently, the intensity falls to $\frac{1}{16}$, so the distance becomes $4$ times.",
  "Using inverse first-power variation.",
  "C04B-power-variation", "Single inverse-square relation solved for distance.",
  tita_answer=12, check=_e12,
  tita_traps=[(48, r"Uses inverse first-power variation: $3 \times 16 = 48$."),
              (144, r"Stops at $d^2 = 144$ and does not take the square root."),
              (4, r"Reports the factor by which the distance grows, $\sqrt{16} = 4$, instead of the distance.")],
  cognitive="Application")


# ---------------------------------------------------------------- MEDIUM (18)

def _m1():
    k = F(4800) / (F(2) * F(3, 2) * 4 ** 2)
    return k * F(5, 2) * F(6, 5) * 6 ** 2
q("C04-B-013", T, "Joint variation with area and square of thickness", "Medium",
  "Multi-step word problem",
  r"The price of a rectangular glass sheet of a given type varies jointly as its area and the square of its thickness. A sheet $2$ m by $1.5$ m and $4$ mm thick costs Rs. $4{,}800$. What is the price of a sheet $2.5$ m by $1.2$ m and $6$ mm thick?",
  "MCQ",
  r"Both sheets have area $3$ m$^2$, so only the thickness matters: the price scales by $\left(\frac{6}{4}\right)^2 = \frac{9}{4}$. The price is $4800 \times \frac{9}{4} =$ Rs. $10{,}800$.",
  "Using the wrong power of thickness or ignoring thickness once the areas match.",
  "C04B-joint-variation-power", "Two factors with a power; noticing equal areas is the shortcut.",
  correct=r"Rs. $10{,}800$",
  distractors=[(r"Rs. $7{,}200$", r"Scales by thickness to the first power: $4800 \times \frac{6}{4}$."),
               (r"Rs. $16{,}200$", r"Scales by the cube of thickness: $4800 \times \frac{27}{8}$."),
               (r"Rs. $4{,}800$", r"Notices the equal areas and stops, leaving out the thickness factor.")],
  check=_m1, values=[10800, 7200, 16200, 4800], cognitive="Application")


def _m2():
    a, b = symbols('a b')
    s = solve([Eq(a + b * 8 ** 2, 200), Eq(a + b * 12 ** 2, 400)], [a, b])
    return s[a] + s[b] * 18 ** 2
q("C04-B-014", T, "Partly fixed, partly varying as the square of diameter", "Medium",
  "Multi-step word problem",
  r"The price of a pizza at an outlet is partly fixed (for packing and delivery) and partly varies as the square of the diameter of the pizza. An $8$ inch pizza costs Rs. $200$ and a $12$ inch pizza costs Rs. $400$. What is the price of an $18$ inch pizza?",
  "MCQ",
  r"Let price $= a + bd^2$. Then $b(144 - 64) = 200$ gives $b = 2.5$, and $a = 200 - 2.5 \times 64 = 40$. For $d = 18$: $40 + 2.5 \times 324 =$ Rs. $850$.",
  "Ignoring the fixed part or treating the variable part as linear in the diameter.",
  "C04B-fixed-plus-square", "Two-point fit of a fixed part plus a square law.",
  correct=r"Rs. $850$",
  distractors=[(r"Rs. $700$", r"Treats the variable part as linear in diameter: Rs. $50$ per inch, so $400 + 6 \times 50 = 700$."),
               (r"Rs. $900$", r"Ignores the fixed part and scales the $12$ inch price by $\left(\frac{18}{12}\right)^2$."),
               (r"Rs. $600$", r"Ignores the fixed part and scales the $12$ inch price by $\frac{18}{12}$.")],
  check=_m2, values=[850, 700, 900, 600], cognitive="Application")


def _m3():
    c, B = symbols('c B')
    s = solve([Eq(c + B / 30, 650), Eq(c + B / 45, 550)], [c, B])
    return s[c] + s[B] / 60
q("C04-B-015", T, "Per-head cost as fixed per-head charge plus an equal share of a fixed bus hire", "Medium",
  "Multi-step word problem",
  r"The cost per student of a school trip is a fixed charge per student for meals and tickets, plus an equal share of the bus hire, which is a fixed total amount. With $30$ students the cost per student is Rs. $650$; with $45$ students it is Rs. $550$. What is the cost per student with $60$ students?",
  "MCQ",
  r"Let the bus hire be $B$. Then $\frac{B}{30} - \frac{B}{45} = 100$, so $\frac{B}{90} = 100$ and $B = 9000$. The per-student charge is $650 - 300 = 350$. With $60$ students: $350 + \frac{9000}{60} =$ Rs. $500$.",
  "Extrapolating the per-head cost linearly in the number of students.",
  "C04B-fixed-plus-inverse", "Two equations in a fixed part and an inverse-varying share.",
  correct=r"Rs. $500$",
  distractors=[(r"Rs. $450$", r"Extrapolates linearly: Rs. $100$ less for each $15$ extra students."),
               (r"Rs. $325$", r"Treats the whole per-head cost as inversely proportional: $650 \times \frac{30}{60}$."),
               (r"Rs. $625$", r"Writes $\frac{B}{30} - \frac{B}{45}$ as $\frac{B}{15}$, so $B = 1500$, per-head charge $600$, and $600 + 25$.")],
  check=_m3, values=[500, 450, 325, 625], cognitive="Application")


def _m4():
    x = symbols('x', positive=True)
    return _pos(solve(Eq((x - 3) * (x + 4), 12 ** 2), x))[0]
q("C04-B-016", T, "Unknown in two expressions whose mean proportional is given", "Medium",
  "Inverse/parameter",
  r"For a positive number $x$, the mean proportional between $x - 3$ and $x + 4$ is $12$. What is $x$?",
  "MCQ",
  r"$(x-3)(x+4) = 144$, so $x^2 + x - 156 = 0 = (x - 12)(x + 13)$. Since $x > 0$, $x = 12$; the two numbers are $9$ and $16$, whose mean proportional is $12$.",
  "Taking the magnitude of the negative root or reporting one of the two numbers.",
  "C04B-mean-proportional", "Definition leads to a quadratic with a root to reject.",
  correct=r"$12$",
  distractors=[(r"$13$", r"Takes the magnitude of the rejected root $-13$."),
               (r"$9$", r"Reports the smaller number $x - 3$."),
               (r"$16$", r"Reports the larger number $x + 4$.")],
  check=_m4, values=[12, 13, 9, 16], cognitive="Application")


def _m5():
    sols = []
    for a in range(1, 200):
        for b in range(1, 200):
            if a * b == 24 ** 2 and F(b * b, a) == 81:
                sols.append(a + b)
    return sols[0]
q("C04-B-017", T, "Two numbers from their mean proportional and third proportional", "Medium",
  "Inverse/parameter",
  r"The mean proportional between two positive numbers is $24$, and the third proportional to the first and the second (in that order) is $81$. What is the sum of the two numbers?",
  "TITA",
  r"Let the numbers be $a$ and $b$. Then $ab = 576$ and $\frac{b^2}{a} = 81$. Multiplying, $b^3 = 576 \times 81 = 46656 = 36^3$, so $b = 36$ and $a = 16$. The sum is $52$.",
  "Treating the mean proportional as the arithmetic mean.",
  "C04B-third-proportional", "Combining two definitions; the cube step is the insight.",
  tita_answer=52, check=_m5,
  tita_traps=[(48, r"Treats $24$ as the arithmetic mean, so the sum is $48$."),
              (20, r"Reports the difference $36 - 16$.")],
  exams=CX, cognitive="Analysis")


def _m6():
    first, fourth = 8100, 2400
    r = Rational(fourth, first) ** Rational(1, 3)
    terms = [first * r ** i for i in range(4)]
    assert all(t == int(t) for t in terms)
    return sum(terms)
q("C04-B-018", T, "Four prizes in continued proportion; total from first and last", "Medium",
  "Multi-step word problem",
  r"The four prizes in a quiz are in continued proportion, that is, first prize : second prize $=$ second prize : third prize $=$ third prize : fourth prize. The first prize is Rs. $8{,}100$ and the fourth prize is Rs. $2{,}400$. What is the total of the four prizes, in rupees?",
  "TITA",
  r"If the common ratio is $r$, then $r^3 = \frac{2400}{8100} = \frac{8}{27}$, so $r = \frac{2}{3}$. The prizes are $8100, 5400, 3600, 2400$, totalling Rs. $19{,}500$.",
  "Treating the prizes as an arithmetic progression.",
  "C04B-continued-proportion", "Needs the cube root of the end ratio, then the sum.",
  tita_answer=19500, check=_m6,
  tita_traps=[(21000, r"Uses equal differences: $2 \times (8100 + 2400)$."),
              (9000, r"Reports only the two missing prizes, $5400 + 3600$.")],
  cognitive="Application")


def _m7():
    p = symbols('p', positive=True)
    k = 1
    sales = lambda pr: k / pr ** 2
    rev = lambda pr: pr * sales(pr)
    return simplify((rev(p * Rational(5, 4)) - rev(p)) / rev(p) * 100)
q("C04-B-019", T, "Revenue change when sales vary inversely as the square of price", "Medium",
  "Conceptual/application",
  r"The number of units of a gadget sold each month varies inversely as the square of its price. If the price is raised by $25\%$, how does the monthly sales revenue change?",
  "MCQ",
  r"Revenue $=$ price $\times$ sales $\propto p \times \frac{1}{p^2} = \frac{1}{p}$. Raising the price by $25\%$ multiplies revenue by $\frac{1}{1.25} = 0.8$, a fall of $20\%$.",
  "Reading the change in sales as the change in revenue, or ignoring the drop in sales.",
  "C04B-percent-change-combined", "Must combine two variations into revenue before converting to a percent.",
  correct=r"It falls by $20\%$",
  distractors=[(r"It falls by $36\%$", r"Takes the change in units sold, $\frac{1}{1.25^2} = 0.64$, as the change in revenue."),
               (r"It falls by $25\%$", r"Assumes revenue falls by the same percent as the price rises."),
               (r"It rises by $25\%$", r"Assumes the number of units sold stays the same.")],
  check=_m7, values=[-20, -36, -25, 25], cognitive="Analysis")


def _m8():
    s0 = 60
    k = F(s0 - 51, 3)                          # reduction / sqrt(9)
    return s0 - k * 5                          # sqrt(25)
q("C04-B-020", T, "Speed reduction varies as the square root of the number of wagons", "Medium",
  "Multi-step word problem",
  r"An engine alone runs at $60$ km/h. When it pulls wagons, its speed is reduced by an amount that varies as the square root of the number of wagons. With $9$ wagons it runs at $51$ km/h. At what speed does it run with $25$ wagons?",
  "MCQ",
  r"Reduction $= k\sqrt{n}$. With $9$ wagons the reduction is $9 = 3k$, so $k = 3$. With $25$ wagons the reduction is $3 \times 5 = 15$, so the speed is $60 - 15 = 45$ km/h.",
  "Making the reduction proportional to the number of wagons, or applying the square root to the extra wagons only.",
  "C04B-speed-load-sqrt", "Fit one constant, then evaluate; the square root of a sum is the trap.",
  correct=r"$45$ km/h",
  distractors=[(r"$35$ km/h", r"Makes the reduction proportional to $n$: $1$ km/h per wagon, so $60 - 25 = 35$."),
               (r"$39$ km/h", r"Subtracts $3\sqrt{16} = 12$ for the $16$ extra wagons from $51$."),
               (r"$15$ km/h", r"Reports the reduction in speed instead of the speed.")],
  check=_m8, values=[45, 35, 39, 15], cognitive="Application")


def _m9():
    a, b, n = symbols('a b n', positive=True)
    s = solve([Eq(a + 500 * b, 6500), Eq(a + 800 * b, 9200)], [a, b])
    return solve(Eq((s[a] + s[b] * n) / n, 10), n)[0]
q("C04-B-021", T, "Number of copies at which the average cost per copy reaches a target", "Medium",
  "Inverse/parameter",
  r"The cost of a print run of a booklet is partly fixed and partly varies directly as the number of copies. A run of $500$ copies costs Rs. $6{,}500$ and a run of $800$ copies costs Rs. $9{,}200$. For how many copies is the average cost per copy exactly Rs. $10$?",
  "TITA",
  r"The extra $300$ copies cost Rs. $2{,}700$, so each copy costs Rs. $9$ and the fixed part is $6500 - 4500 =$ Rs. $2{,}000$. Average cost $= \frac{2000}{n} + 9 = 10$ gives $n = 2000$.",
  "Extrapolating the average cost per copy linearly.",
  "C04B-fixed-plus-inverse", "Fit the linear model, then invert the average cost.",
  tita_answer=2000, check=_m9,
  tita_traps=[(1100, r"Average cost is $13$ at $500$ and $11.5$ at $800$; extends that straight line to $10$."),
              (200, r"Divides the fixed cost by Rs. $10$, ignoring the Rs. $9$ per copy.")],
  cognitive="Application")


def _m10():
    k = F(2400) / (10 * 20 ** 2 / F(4))
    return k * 12 * 15 ** 2 / F(3)
q("C04-B-022", T, "Joint variation with breadth, square of depth and inverse of length", "Medium",
  "Multi-step word problem",
  r"The safe load on a wooden beam varies jointly as its breadth and the square of its depth, and inversely as its length. A beam $10$ cm broad, $20$ cm deep and $4$ m long carries a safe load of $2{,}400$ kg. What is the safe load on a beam of the same wood that is $12$ cm broad, $15$ cm deep and $3$ m long?",
  "MCQ",
  r"Load $\propto \frac{b d^2}{L}$. The ratio of new to old is $\frac{12}{10} \times \frac{225}{400} \times \frac{4}{3} = \frac{6}{5} \times \frac{9}{16} \times \frac{4}{3} = \frac{9}{10}$, so the load is $2400 \times \frac{9}{10} = 2160$ kg.",
  "Dropping the square on depth, flipping the length factor, or leaving it out.",
  "C04B-joint-variation-power", "Three factors with a square and an inverse; any slip changes the answer.",
  correct=r"$2160$ kg",
  distractors=[(r"$2880$ kg", r"Uses depth to the first power: $2400 \times \frac{6}{5} \times \frac{3}{4} \times \frac{4}{3}$."),
               (r"$1215$ kg", r"Treats load as varying directly as length: factor $\frac{3}{4}$ instead of $\frac{4}{3}$."),
               (r"$1620$ kg", r"Leaves out the length factor: $2400 \times \frac{6}{5} \times \frac{9}{16}$.")],
  check=_m10, values=[2160, 2880, 1215, 1620], cognitive="Application")


def _m11():
    k = F(4, 50 ** 2)                          # litres per hour = k v^2
    v, dist = 75, 200
    return k * v ** 2 * F(dist, v)
q("C04-B-023", T, "Fuel per hour varies as square of speed; fuel for a trip", "Medium",
  "Multi-step word problem",
  r"The fuel a launch burns per hour varies as the square of its speed. At $50$ km/h it burns $4$ litres per hour. How many litres of fuel does it burn on a $200$ km trip made at a constant $75$ km/h?",
  "TITA",
  r"At $75$ km/h it burns $4 \times \left(\frac{75}{50}\right)^2 = 9$ litres per hour. The trip takes $\frac{200}{75} = \frac{8}{3}$ hours, so it uses $9 \times \frac{8}{3} = 24$ litres. (Fuel per km varies as speed: $0.08 \times 1.5 \times 200 = 24$.)",
  "Treating fuel per km as constant, or using the time at the old speed.",
  "C04B-fuel-rate-speed", "Rate per hour must be converted to a trip total with the new time.",
  tita_answer=24, check=_m11,
  tita_traps=[(16, r"Takes fuel per km as constant: $\frac{4}{50} \times 200$."),
              (36, r"Uses $9$ litres per hour for $4$ hours, the time at $50$ km/h.")],
  cognitive="Application")


def _m13():
    w, c1, c2, c3 = symbols('w c1 c2 c3', positive=True)
    z = c3 * w ** 3
    y = c2 / sqrt(z)
    x = c1 * y ** 2
    return simplify(w * diff(x, w) / x)       # exponent of w
q("C04-B-024", T, "Chaining three variations into one", "Medium",
  "Conceptual/application",
  r"$x$ varies directly as $y^2$, $y$ varies inversely as $\sqrt{z}$, and $z$ varies directly as $w^3$. How does $x$ vary with $w$?",
  "MCQ",
  r"$x \propto y^2 \propto \left(\frac{1}{\sqrt{z}}\right)^2 = \frac{1}{z}$, and $\frac{1}{z} \propto \frac{1}{w^3}$. So $x \propto \frac{1}{w^3}$.",
  "Losing the inverse, or squaring at the wrong stage.",
  "C04B-chained-variation", "Three linked variations; each exponent must be tracked.",
  correct=r"$x \propto \frac{1}{w^{3}}$",
  distractors=[(r"$x \propto w^{3}$", r"Drops the inverse in the relation between $y$ and $z$."),
               (r"$x \propto \frac{1}{w^{3/2}}$", r"Does not square $y$: $x \propto \frac{1}{\sqrt{z}}$."),
               (r"$x \propto \frac{1}{w^{6}}$", r"Uses $y \propto \frac{1}{z}$ without the square root, then squares.")],
  check=_m13, values=[-3, 3, Rational(-3, 2), -6], cognitive="Understanding")


def _m14():
    V = 500000
    parts = [2, 3, 5]
    s = sum(parts)
    remaining = sum(F(p, s) ** 2 for p in parts) * V
    return V - remaining
q("C04-B-025", T, "Loss when value varies as square of weight and the gem breaks into three pieces", "Medium",
  "Multi-step word problem",
  r"The value of a gemstone varies as the square of its weight. A gemstone worth Rs. $5{,}00{,}000$ breaks into three pieces whose weights are in the ratio $2 : 3 : 5$. What is the loss in value, in rupees?",
  "TITA",
  r"Take the weight as $10$ units, so the value is $100$ units of Rs. $5{,}000$. The pieces are worth $4 + 9 + 25 = 38$ units, so $62$ units are lost: $62 \times 5000 = 310000$.",
  "Treating value as proportional to weight (no loss) or reporting the value of the pieces.",
  "C04B-value-square-breakage", "Square-law breakage with three pieces.",
  tita_answer=310000, check=_m14,
  tita_traps=[(190000, r"Reports the combined value of the pieces."),
              (0, r"Treats value as proportional to weight.")],
  cognitive="Application")


def _m15():
    return (F(6, 5) * F(3, 4) - 1) * 100
q("C04-B-026", T, "Percent change under joint variation when both factors change", "Medium",
  "Conceptual/application",
  r"The rent of a stall at a fair varies jointly as the floor area of the stall and the number of days it is booked. If the floor area is increased by $20\%$ and the number of days is decreased by $25\%$, how does the rent change?",
  "MCQ",
  r"Rent $\propto$ area $\times$ days, so it is multiplied by $1.2 \times 0.75 = 0.9$. The rent falls by $10\%$.",
  "Adding the percent changes, or treating one factor inversely.",
  "C04B-percent-change-combined", "Two multiplicative percent changes; the additive shortcut is the trap.",
  correct=r"It falls by $10\%$",
  distractors=[(r"It falls by $5\%$", r"Adds the percent changes: $20 - 25 = -5$."),
               (r"It rises by $60\%$", r"Treats rent as varying inversely as days: $\frac{1.2}{0.75} = 1.6$."),
               (r"It falls by $37.5\%$", r"Treats rent as varying inversely as area: $\frac{0.75}{1.2} = 0.625$.")],
  check=_m15, values=[-10, -5, 60, F(-75, 2)], cognitive="Understanding")


def _m16():
    n = symbols('n', positive=True)
    e = _pos(solve(Eq(F(15, 10) ** n, F(900, 400)), n))[0]
    d = symbols('d', positive=True)
    return _pos(solve(Eq(400 * (d / 10) ** e, 1600), d))[0]
q("C04-B-027", T, "Finding the power in a variation from two data points", "Medium",
  "Inverse/parameter",
  r"The load a steel rope can safely hold varies as a fixed power of its diameter. A rope of diameter $10$ mm can hold $400$ kg and a rope of diameter $15$ mm can hold $900$ kg. What diameter of rope, in mm, is needed to hold $1{,}600$ kg?",
  "TITA",
  r"$\left(\frac{15}{10}\right)^n = \frac{900}{400} = \left(\frac{3}{2}\right)^2$, so $n = 2$. To hold $4$ times the $400$ kg load, the diameter must be $\sqrt{4} = 2$ times $10$ mm, that is $20$ mm.",
  "Assuming direct (first power) variation.",
  "C04B-find-the-exponent", "First identify the exponent, then invert it.",
  tita_answer=20, check=_m16,
  tita_traps=[(40, r"Assumes load varies directly as diameter: $10 \times 4$."),
              (22, r"Treats load as linear in diameter through the two data points ($100$ kg per mm): $10 + \frac{1200}{100} = 22$.")],
  cognitive="Analysis")


def _m17():
    k = F(144, 100) / F(12, 5) ** 2          # L = k T^2 (metres)
    newL = k * 2 ** 2
    return (F(144, 100) - newL) * 100         # cm
q("C04-B-028", T, "Period varies as square root of length; change in length", "Medium",
  "Inverse/parameter",
  r"The time period of a simple pendulum varies as the square root of its length. A pendulum $1.44$ m long has a period of $2.4$ seconds. By how many centimetres must its length be reduced to make the period $2$ seconds?",
  "MCQ",
  r"Length $\propto$ period$^2$, so the new length is $1.44 \times \left(\frac{2}{2.4}\right)^2 = 1.44 \times \frac{25}{36} = 1$ m. The reduction is $1.44 - 1 = 0.44$ m $= 44$ cm.",
  "Scaling the length linearly with the period, or reporting the new length.",
  "C04B-power-variation", "Inverting a square-root law and converting units.",
  correct=r"$44$ cm",
  distractors=[(r"$24$ cm", r"Scales the length linearly: $1.44 \times \frac{2}{2.4} = 1.2$ m, a reduction of $24$ cm."),
               (r"$100$ cm", r"Reports the new length instead of the reduction."),
               (r"$4$ cm", r"Squares the fractional change: $1.44 \times \left(\frac{0.4}{2.4}\right)^2 = 0.04$ m.")],
  check=_m17, values=[44, 24, 100, 4], cognitive="Application")


def _m18():
    total_days, people, t, extra = 40, 240, 10, 6
    remaining = people * (total_days - t)
    stay = F(remaining, (total_days - t) + extra)
    return people - stay
q("C04-B-029", T, "How many people left if remaining provisions last longer", "Medium",
  "Inverse/parameter",
  r"A relief camp has enough food for $240$ people for $40$ days, each person eating the same amount daily. After $10$ days some people leave, and the remaining food then lasts $6$ days longer than it would have if nobody had left. How many people left?",
  "MCQ",
  r"After $10$ days the food would last $240$ people another $30$ days. It now lasts $36$ days, so $\frac{240 \times 30}{36} = 200$ people remain, and $40$ left.",
  "Using the wrong base number of days, or reporting the number who stayed.",
  "C04B-provisions", "Inverse variation after a time offset, solved backwards.",
  correct=r"$40$",
  distractors=[(r"$48$", r"Takes the fraction leaving as $\frac{6}{30}$ of $240$."),
               (r"$36$", r"Takes the fraction leaving as $\frac{6}{40}$ of $240$, using the original $40$ days."),
               (r"$200$", r"Reports the number of people who stayed.")],
  check=_m18, values=[40, 48, 36, 200], cognitive="Application")


def _m19():
    a, b, v = symbols('a b v', positive=True)
    s = solve([Eq(a + b / 30, 5), Eq(a + b / 40, 4)], [a, b])
    return solve(Eq(s[a] + s[b] / v, F(5, 2)), v)[0]
q("C04-B-030", T, "Time as fixed stoppage plus a part varying inversely as speed", "Medium",
  "Inverse/parameter",
  r"Harpreet's delivery round takes a fixed total time for stops plus driving time that varies inversely as her average driving speed. At $30$ km/h the round takes $5$ hours, and at $40$ km/h it takes $4$ hours. At what average driving speed will the round take $2$ hours $30$ minutes?",
  "MCQ",
  r"Let time $= a + \frac{b}{v}$. Then $\frac{b}{30} - \frac{b}{40} = 1$, so $b = 120$ and $a = 5 - 4 = 1$ hour. For $2.5$ hours: $\frac{120}{v} = 1.5$, so $v = 80$ km/h.",
  "Extrapolating linearly, or treating the whole time as inversely proportional to speed.",
  "C04B-fixed-plus-inverse", "Fit two parameters, then invert; several tempting shortcuts.",
  correct=r"$80$ km/h",
  distractors=[(r"$55$ km/h", r"Extrapolates linearly: each extra $10$ km/h saves $1$ hour, so $1.5$ hours less needs $40 + 15$."),
               (r"$48$ km/h", r"Takes the whole $2.5$ hours as driving time: $\frac{120}{2.5}$."),
               (r"$64$ km/h", r"Treats the whole time as inversely proportional to speed: $40 \times \frac{4}{2.5}$.")],
  check=_m19, values=[80, 55, 48, 64], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT (10)

def _d1():
    v = symbols('v', positive=True)
    k = F(200, 10 ** 3)
    per_km = k * v ** 2 + F(3200) / v
    crit = _pos(solve(diff(per_km, v), v))
    best = min(per_km.subs(v, c) for c in crit)
    # sanity: brute force over speeds
    grid = min(k * F(s, 10) ** 2 + F(3200) / F(s, 10) for s in range(10, 1000))
    assert best <= grid
    return best * 150
q("C04-B-031", T, "Minimum trip cost with fuel per hour varying as cube of speed plus fixed hourly cost", "Difficult",
  "Casework/optimisation",
  r"The fuel cost of running a boat per hour varies as the cube of its speed, and is Rs. $200$ per hour at $10$ km/h. Other running costs are Rs. $3{,}200$ per hour whatever the speed. The boat makes a $150$ km trip at a constant speed of its owner's choice. What is the minimum possible total cost of the trip, in rupees?",
  "TITA",
  r"Fuel per hour $= 0.2v^3$, so the cost per km is $0.2v^2 + \frac{3200}{v} = 0.2v^2 + \frac{1600}{v} + \frac{1600}{v}$. By AM $\geq$ GM this is at least $3\sqrt[3]{0.2 \times 1600^2} = 3 \times 80 = 240$, with equality when $0.2v^2 = \frac{1600}{v}$, that is $v = 20$ km/h. The minimum cost is $240 \times 150 = 36000$.",
  "Setting fuel cost equal to the fixed cost (the square-law rule) or evaluating at the reference speed.",
  "C04B-optimal-speed-cost", "Optimisation of a sum of a power and an inverse term; needs the split for AM-GM or calculus.",
  tita_answer=36000, check=_d1,
  tita_traps=[(51000, r"Uses the reference speed $10$ km/h: $\frac{200 + 3200}{10} \times 150$."),
              (12000, r"Finds $v = 20$ but counts only the fuel cost: $0.2 \times 400 \times 150$.")],
  exams=CX, cognitive="Analysis")


def _d2():
    best = None
    for s in range(1, 1601):                   # speeds 0.01 .. 16.00 km/h
        v = F(s, 100)
        per_km = (4 * v ** 2 + 1600) / v
        if best is None or per_km < best:
            best = per_km
    return best * 120
q("C04-B-032", T, "Most economical speed when the unconstrained optimum exceeds a speed limit", "Difficult",
  "Casework/optimisation",
  r"The fuel cost of running a ferry per hour varies as the square of its speed, and is Rs. $400$ per hour at $10$ km/h. Other running costs are Rs. $1{,}600$ per hour whatever the speed. The ferry cannot go faster than $16$ km/h. If it makes a $120$ km trip at a constant speed, what is the least possible total cost of the trip?",
  "MCQ",
  r"Fuel per hour $= 4v^2$, so cost per km $= 4v + \frac{1600}{v}$, which is least at $v = 20$ km/h and decreases all the way up to $20$. With the cap at $16$ km/h the best speed is $16$: cost per km $= 64 + 100 = 164$, total $164 \times 120 =$ Rs. $19{,}680$.",
  "Using the unconstrained optimum without checking the speed limit.",
  "C04B-optimal-speed-cost", "Optimum lies outside the feasible range, so the boundary case decides.",
  correct=r"Rs. $19{,}680$",
  distractors=[(r"Rs. $19{,}200$", r"Uses the unconstrained optimum $20$ km/h: $160 \times 120$, ignoring the $16$ km/h limit."),
               (r"Rs. $24{,}000$", r"Uses the reference speed $10$ km/h: $200 \times 120$."),
               (r"Rs. $16{,}800$", r"Takes fuel per hour as varying directly as speed ($40v$), so cost per km is $40 + \frac{1600}{v}$; at $16$ km/h, $140 \times 120$.")],
  check=_d2, values=[19680, 19200, 24000, 16800], exams=CX, cognitive="Analysis")


def _d3():
    s0, k = symbols('s0 k')
    s = solve([Eq(s0 - k * 2, 60), Eq(s0 - k * 5, 39)], [s0, k])
    n = 0
    while s[s0] - s[k] * sqrt(n + 1) > 0:
        n += 1
    return n
q("C04-B-033", T, "Largest load from two data points when speed reduction varies as square root", "Difficult",
  "Casework/optimisation",
  r"When an engine pulls $n$ wagons, its speed is reduced from its speed when running alone by an amount that varies as $\sqrt{n}$. With $4$ wagons it runs at $60$ km/h and with $25$ wagons it runs at $39$ km/h. What is the largest number of wagons the engine can pull and still move?",
  "TITA",
  r"Let speed $= s_0 - k\sqrt{n}$. Then $s_0 - 2k = 60$ and $s_0 - 5k = 39$, so $k = 7$ and $s_0 = 74$. The engine moves while $74 - 7\sqrt{n} > 0$, that is $\sqrt{n} < \frac{74}{7} \approx 10.57$, so $n < 111.76$. The largest number is $111$.",
  "Flooring the square root before squaring, or rounding the bound up.",
  "C04B-speed-load-sqrt", "Two-point fit with an unknown base speed and a careful integer bound.",
  tita_answer=111, check=_d3,
  tita_traps=[(112, r"Rounds $111.76$ up."),
              (100, r"Takes the integer part of $\frac{74}{7}$ first and squares $10$.")],
  exams=CX, cognitive="Analysis")


def _d4():
    a, b, c = symbols('a b c')
    s = solve([Eq(a + 10 * b + 100 * c, 2600), Eq(a + 20 * b + 400 * c, 4400), Eq(a + 35 * b + 1225 * c, 8225)], [a, b, c])
    return s[a] + 50 * s[b] + 2500 * s[c]
q("C04-B-034", T, "Cost with a constant part, a part varying as n and a part varying as n squared", "Difficult",
  "Multi-step word problem",
  r"The cost of running a weekend workshop is the sum of three parts: one constant, one varying directly as the number of participants $n$, and one varying directly as $n^2$. The cost is Rs. $2{,}600$ for $10$ participants, Rs. $4{,}400$ for $20$ participants and Rs. $8{,}225$ for $35$ participants. What is the cost for $50$ participants?",
  "MCQ",
  r"Let cost $= a + bn + cn^2$. The average increase per participant from $10$ to $20$ is $\frac{1800}{10} = 180 = b + 30c$, and from $20$ to $35$ it is $\frac{3825}{15} = 255 = b + 55c$. So $25c = 75$, $c = 3$, $b = 90$ and $a = 2600 - 900 - 300 = 1400$. For $50$ participants the cost is $1400 + 4500 + 7500 =$ Rs. $13{,}400$.",
  "Extending a linear trend instead of a quadratic one, or treating unequally spaced data as equally spaced.",
  "C04B-three-part-variation", "Three unknowns from unequally spaced data, so the equal-step difference shortcut fails; needs average rates over unequal intervals and a careful extrapolation.",
  correct=r"Rs. $13{,}400$",
  distractors=[(r"Rs. $12{,}050$", r"Extends the last average rate of Rs. $255$ per participant from $35$: $8225 + 15 \times 255$."),
               (r"Rs. $11{,}600$", r"Fits a constant plus a direct part through $n = 10$ and $n = 35$: Rs. $225$ per participant, so $8225 + 15 \times 225$."),
               (r"Rs. $14{,}075$", r"Treats the three data points as equally spaced: differences $1800$ and $3825$ grow by $2025$, so the next is $5850$ and $8225 + 5850$.")],
  check=_d4, values=[13400, 12050, 11600, 14075], exams=CX, cognitive="Analysis")


def _d5():
    def loss_frac(parts):
        s = sum(parts)
        return 1 - sum(F(p, s) ** 2 for p in parts)
    V = F(48000) / (loss_frac([3, 2]) - loss_frac([4, 1]))
    return V * loss_frac([1, 2, 2])
q("C04-B-035", T, "Square-law breakage: value from a loss difference, then a third split", "Difficult",
  "Multi-step word problem",
  r"The value of a gemstone varies as the square of its weight. If it broke into two pieces with weights in the ratio $3 : 2$, the loss in value would be Rs. $48{,}000$ more than if it broke into two pieces with weights in the ratio $4 : 1$. What would be the loss in value if it broke into three pieces with weights in the ratio $1 : 2 : 2$?",
  "MCQ",
  r"For a $3 : 2$ split the pieces keep $\frac{9 + 4}{25} = \frac{13}{25}$ of the value, a loss of $\frac{12}{25}$; for $4 : 1$ the loss is $\frac{8}{25}$. So $\frac{4}{25}V = 48000$ and $V = 300000$. For $1 : 2 : 2$ the pieces keep $\frac{1 + 4 + 4}{25} = \frac{9}{25}$, so the loss is $\frac{16}{25} \times 300000 =$ Rs. $1{,}92{,}000$.",
  "Mis-stating the two-piece loss fraction or dividing by the wrong fraction.",
  "C04B-value-square-breakage", "Two stages: recover the value from a difference of losses, then apply a new split.",
  correct=r"Rs. $1{,}92{,}000$",
  distractors=[(r"Rs. $3{,}84{,}000$", r"Uses $\frac{pq}{(p+q)^2}$ as the two-piece loss fraction, so $V = 600000$, then $\frac{16}{25}V$."),
               (r"Rs. $1{,}72{,}800$", r"Uses the cube of weight: loss fractions $\frac{90}{125}$ and $\frac{60}{125}$ give $V = 200000$, then $\frac{108}{125}V$."),
               (r"Rs. $64{,}000$", r"Divides $48000$ by the $3 : 2$ loss fraction $\frac{12}{25}$, so $V = 100000$, then $\frac{16}{25}V$.")],
  check=_d5, values=[192000, 384000, 172800, 64000], exams=CX, cognitive="Analysis")


def _d6():
    cnt = 0
    for n in range(1, 201):
        buses = -(-n // 45)
        if 800 + F(8100 * buses, n) <= 1000:
            cnt += 1
    return cnt
q("C04-B-036", T, "Per-head cost with a step-wise bus hire; counting feasible group sizes", "Difficult",
  "Casework/optimisation",
  r"For a college excursion, each participant pays Rs. $800$ for food and entry plus an equal share of the bus hire. Each bus seats $45$ and costs Rs. $8{,}100$, and the college hires the least number of buses that can seat everyone. For how many group sizes from $1$ to $200$ participants (inclusive) is the cost per participant at most Rs. $1{,}000$?",
  "TITA",
  r"With $b$ buses, the share is $\frac{8100b}{n} \leq 200$, so $n \geq 40.5b$, while $45(b-1) < n \leq 45b$. For $b = 1$: $n = 41$ to $45$ ($5$ sizes); $b = 2$: $81$ to $90$ ($10$); $b = 3$: $122$ to $135$ ($14$); $b = 4$: $162$ to $180$ ($19$); $b = 5$ would need $n \geq 202.5$. Total $5 + 10 + 14 + 19 = 48$.",
  "Ignoring that the number of buses jumps with the group size.",
  "C04B-per-head-share-step", "Casework over the number of buses with an integer bound in each case.",
  tita_answer=48, check=_d6,
  tita_traps=[(160, r"Uses one bus throughout: $n \geq 41$ up to $200$."),
              (49, r"Rounds $121.5$ down and includes $n = 121$.")],
  exams=CX, cognitive="Analysis")


def _d7():
    x, y, z = symbols('x y z', positive=True)
    sols = solve([Eq(x * z, y ** 2), Eq(x + y + z, 39), Eq(x ** 2 + y ** 2 + z ** 2, 819)], [x, y, z], dict=True)
    ys = {s[y] for s in sols}
    assert len(ys) == 1
    return ys.pop()
q("C04-B-037", T, "Middle term of three numbers in continued proportion from sum and sum of squares", "Difficult",
  "Conceptual/application",
  r"Three positive numbers $x$, $y$, $z$ are in continued proportion, that is $x : y = y : z$. Their sum is $39$ and the sum of their squares is $819$. What is $y$?",
  "MCQ",
  r"Since $xz = y^2$, $x^2 + y^2 + z^2 = (x + z)^2 - y^2 = (x + y + z)(x - y + z)$. So $x - y + z = \frac{819}{39} = 21$. Subtracting from $x + y + z = 39$ gives $2y = 18$, so $y = 9$ (the numbers are $27, 9, 3$).",
  "Reporting an intermediate quantity or assuming the middle term is the average.",
  "C04B-continued-proportion", "Needs the factorisation identity; brute algebra is long.",
  correct=r"$9$",
  distractors=[(r"$21$", r"Reports $x - y + z = \frac{819}{39}$ as $y$."),
               (r"$13$", r"Assumes the middle term is the average $\frac{39}{3}$."),
               (r"$27$", r"Reports the largest of the three numbers.")],
  check=_d7, values=[9, 21, 13, 27], exams=CX, cognitive="Analysis")


def _d8():
    p = symbols('p', positive=True)
    k = 1000 * 60 ** 2
    q_ = k / p ** 2
    profit = p * q_ - 20 * q_ - 15000
    crit = _pos(solve(diff(profit, p), p))
    best = max(profit.subs(p, c) for c in crit)
    grid = max(profit.subs(p, Rational(s, 10)) for s in range(201, 2000, 7))
    assert best >= grid
    return best
q("C04-B-038", T, "Maximum profit when demand varies inversely as the square of price", "Difficult",
  "Casework/optimisation",
  r"A shop finds that its weekly sales of a lamp vary inversely as the square of the selling price. At Rs. $60$ per lamp it sells $1{,}000$ lamps a week. Each lamp costs the shop Rs. $20$, and the shop has fixed costs of Rs. $15{,}000$ per week. If the shop can set any selling price above Rs. $20$, what is the maximum possible weekly profit?",
  "MCQ",
  r"Sales $= \frac{3600000}{p^2}$. Profit $= 3600000\left(\frac{1}{p} - \frac{20}{p^2}\right) - 15000$. With $t = \frac{1}{p}$, $t - 20t^2$ is greatest at $t = \frac{1}{40}$, giving $\frac{1}{40} - \frac{20}{1600} = \frac{1}{80}$. Profit $= \frac{3600000}{80} - 15000 = 45000 - 15000 =$ Rs. $30{,}000$ at $p =$ Rs. $40$.",
  "Leaving out fixed cost, not optimising the price, or using an inverse first-power demand.",
  "C04B-demand-profit", "Variation feeds an optimisation; a substitution turns it into a quadratic.",
  correct=r"Rs. $30{,}000$",
  distractors=[(r"Rs. $45{,}000$", r"Optimises correctly at Rs. $40$ but leaves out the fixed cost."),
               (r"Rs. $25{,}000$", r"Keeps the price at Rs. $60$: $60000 - 20000 - 15000$."),
               (r"Rs. $15{,}000$", r"Optimises correctly at Rs. $40$ (contribution Rs. $45{,}000$) but subtracts the fixed cost twice: $45000 - 30000 = 15000$.")],
  check=_d8, values=[30000, 45000, 25000, 15000], exams=CX, cognitive="Analysis")


def _d9():
    a, b, v = symbols('a b v', positive=True)
    s = solve([Eq(40 * a + 1600 * b, 24), Eq(60 * a + 3600 * b, 45)], [a, b])
    d = lambda sp_: s[a] * sp_ + s[b] * sp_ ** 2
    best = 0
    for sp_ in range(1, 400):
        if d(sp_) <= 105:
            best = sp_
    root = _pos(solve(Eq(d(v), 105), v))[0]
    assert root == best
    return best
q("C04-B-039", T, "Stopping distance as sum of a direct and a square-law part; speed limit for a distance", "Difficult",
  "Inverse/parameter",
  r"The stopping distance of a car is the sum of two parts: the reaction distance, which varies directly as the speed, and the braking distance, which varies as the square of the speed. At $40$ km/h the stopping distance is $24$ m and at $60$ km/h it is $45$ m. What is the highest speed, in km/h, at which the stopping distance does not exceed $105$ m?",
  "TITA",
  r"Let $d = av + bv^2$. Then $a + 40b = 0.6$ and $a + 60b = 0.75$, so $b = 0.0075$ and $a = 0.3$. Setting $0.3v + 0.0075v^2 = 105$ gives $v^2 + 40v - 14000 = 0 = (v - 100)(v + 140)$, so $v = 100$ km/h. As $d$ increases with $v$, the highest speed is $100$ km/h.",
  "Sign slip in the factorisation.",
  "C04B-sum-of-two-variations", "Two-part variation fitted from two data points and then inverted through a quadratic.",
  tita_answer=100, check=_d9,
  tita_traps=[(140, r"Takes the magnitude of the negative root of $v^2 + 40v - 14000 = 0$."),
              (175, r"Treats the whole stopping distance as varying directly as speed through the $40$ km/h point: $\frac{24}{40}v = 105$.")],
  exams=CX, cognitive="Analysis")


def _d10():
    f, v, k = symbols('f v k', positive=True)   # f = fixed cost per biscuit at original output, v = variable cost per biscuit
    s = solve(Eq(f / Rational(3, 2) + v, Rational(9, 10) * (f + v)), f)[0]
    kk = solve(Eq(s / k + v, Rational(8, 10) * (s + v)), k)[0]
    return (kk - 1) * 100
q("C04-B-040", T, "Partly fixed batch cost: percent increase in output for a target fall in cost per unit", "Difficult",
  "Inverse/parameter",
  r"The cost of a bakery's daily batch of biscuits is partly fixed and partly varies directly as the number of biscuits baked. When the number of biscuits is increased by $50\%$, the cost per biscuit falls by $10\%$. By what percent must the number of biscuits be increased, from the original number, for the cost per biscuit to fall by $20\%$ of its original value?",
  "MCQ",
  r"Per biscuit at the original output, let the fixed share be $f$ and the variable cost be $v$. Then $\frac{f}{1.5} + v = 0.9(f + v)$ gives $f = \frac{3}{7}v$, so the original cost per biscuit is $\frac{10}{7}v$. We need $\frac{f}{m} + v = 0.8 \times \frac{10}{7}v = \frac{8}{7}v$, so $\frac{f}{m} = \frac{v}{7}$ and $m = 3$. The output must be tripled, an increase of $200\%$.",
  "Assuming the fall in cost per biscuit is proportional to the increase in output.",
  "C04B-fixed-variable-percent", "Must split cost per biscuit into two parts and work with unknown proportions.",
  correct=r"$200\%$",
  distractors=[(r"$100\%$", r"Assumes the fall in cost per biscuit is proportional to the increase: $10\%$ per $50\%$."),
               (r"$300\%$", r"Finds that output must be tripled and reports $300\%$."),
               (r"$25\%$", r"Treats cost per biscuit as inversely proportional to output: $\frac{1}{m} = 0.8$.")],
  check=_d10, values=[200, 100, 300, 25], exams=CX, cognitive="Analysis")
