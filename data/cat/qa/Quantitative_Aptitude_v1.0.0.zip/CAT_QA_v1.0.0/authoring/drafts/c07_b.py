import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Pipes and cisterns"
ALL = ("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET")
HARD = ("CAT", "XAT")


def _first_full(pipes, level=Fraction(0), target=Fraction(1), horizon=500):
    """pipes: list of (rate, start, end) with rate as a fraction of the tank per unit time
    (negative for outlets), open on [start, end), end None meaning never closed.
    Returns the first time the level reaches target (rising)."""
    pts = sorted({Fraction(0)} | {Fraction(s) for _, s, _ in pipes} |
                 {Fraction(e) for _, _, e in pipes if e is not None} | {Fraction(horizon)})
    L = Fraction(level)
    for a, b in zip(pts, pts[1:]):
        net = sum(Fraction(r) for r, s, e in pipes if s <= a and (e is None or e > a))
        if net > 0 and L + net * (b - a) >= target:
            return a + (target - L) / net
        L += net * (b - a)
    return None


def _first_empty(pipes, level=Fraction(1), horizon=500):
    pts = sorted({Fraction(0)} | {Fraction(s) for _, s, _ in pipes} |
                 {Fraction(e) for _, _, e in pipes if e is not None} | {Fraction(horizon)})
    L = Fraction(level)
    for a, b in zip(pts, pts[1:]):
        net = sum(Fraction(r) for r, s, e in pipes if s <= a and (e is None or e > a))
        if net < 0 and L + net * (b - a) <= 0:
            return a + L / (-net)
        L += net * (b - a)
    return None


def _hm(h):
    """hours (Fraction) to minutes"""
    return Fraction(h) * 60


# ---------------------------------------------------------------- 001
def _c001():
    t = symbols('t', positive=True)
    return _hm(solve(Eq(t * (Rational(1, 12) + Rational(1, 18)), 1), t)[0])
q("C07-B-001", T, "Two inlets working together, time in hours and minutes", "Easy",
  "Single-step computation",
  r"The overhead tank of a housing society can be filled by pump P alone in $12$ hours and by pump Q alone in $18$ hours. If both pumps are started together on the empty tank, how long will it take to fill the tank?",
  "MCQ",
  r"In one hour the pumps fill $\frac{1}{12} + \frac{1}{18} = \frac{3 + 2}{36} = \frac{5}{36}$ of the tank. So the time is $\frac{36}{5} = 7.2$ hours, and $0.2$ hour is $12$ minutes, giving $7$ hours $12$ minutes.",
  "Averaging the two times, or converting $7.2$ hours into $7$ hours $20$ minutes.",
  "C07B-combined-inlets", "One idea (add rates) and a decimal-hour conversion trap.",
  correct=r"$7$ hours $12$ minutes",
  distractors=[(r"$15$ hours", "Takes the arithmetic mean of $12$ and $18$ hours."),
               (r"$36$ hours", "Subtracts the rates: $\\frac{1}{12} - \\frac{1}{18} = \\frac{1}{36}$."),
               (r"$7$ hours $20$ minutes", "Reads $7.2$ hours as $7$ hours $20$ minutes.")],
  check=_c001, values=[432, 900, 2160, 440], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 002
def _c002():
    return int(_first_full([(Fraction(1, 12), 0, None), (Fraction(1, 20), 0, None), (Fraction(1, 30), 0, None)]))
q("C07-B-002", T, "Three inlets working together", "Easy",
  "Single-step computation",
  r"A farm reservoir is fed by three borewell pumps. Working alone, the pumps would fill it in $12$ hours, $20$ hours and $30$ hours respectively. If all three pumps are switched on together when the reservoir is empty, in how many hours will it be full?",
  "TITA",
  r"Hourly work is $\frac{1}{12} + \frac{1}{20} + \frac{1}{30} = \frac{5 + 3 + 2}{60} = \frac{10}{60} = \frac{1}{6}$ of the reservoir. So the reservoir fills in $6$ hours.",
  "Adding the times instead of the rates.",
  "C07B-combined-inlets", "Direct addition of three rates with an LCM of $60$.",
  tita_answer=6, check=_c002,
  tita_traps=[(62, "Adds the three times $12 + 20 + 30$."),
              (4, "Divides the fastest time by the number of pumps, $12 \\div 3$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 003
def _c003():
    x = symbols('x', positive=True)
    return solve(Eq(Rational(1, 20) + 1 / x - Rational(1, 40), Rational(1, 15)), x)[0]
q("C07-B-003", T, "Find an inlet's time from the all-open time with an outlet present", "Medium",
  "Inverse/parameter",
  r"A tank has two inlets P and Q and an outlet R. Inlet P alone fills the empty tank in $20$ minutes, and outlet R alone empties the full tank in $40$ minutes. When P, Q and R are all opened together on the empty tank, it fills in $15$ minutes. In how many minutes would Q alone fill the empty tank?",
  "TITA",
  r"Per minute, P + Q $-$ R $= \frac{1}{15}$. So Q's rate is $\frac{1}{15} - \frac{1}{20} + \frac{1}{40} = \frac{8 - 6 + 3}{120} = \frac{5}{120} = \frac{1}{24}$. Hence Q alone takes $24$ minutes.",
  "Leaving out the outlet when isolating Q's rate.",
  "C07B-net-rate-inverse", "Two steps: isolate one unknown rate and remember the outlet's sign.",
  tita_answer=24, check=_c003,
  tita_traps=[(60, "Ignores R: $\\frac{1}{15} - \\frac{1}{20} = \\frac{1}{60}$."),
              (5, "Subtracts the times, $20 - 15$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 004
def _c004():
    return _first_full([(Fraction(1, 10), 0, None), (Fraction(-1, 15), 0, None)])
q("C07-B-004", T, "Inlet and outlet opened together on an empty tank", "Easy",
  "Single-step computation",
  r"An inlet pipe can fill an empty cistern in $10$ hours, and an outlet pipe can empty the full cistern in $15$ hours. Both are opened together when the cistern is empty. In how many hours will the cistern be full?",
  "MCQ",
  r"Net filling per hour is $\frac{1}{10} - \frac{1}{15} = \frac{3 - 2}{30} = \frac{1}{30}$ of the cistern. So it fills in $30$ hours.",
  "Adding the outlet's rate instead of subtracting it.",
  "C07B-inlet-outlet-net", "Single subtraction of rates; the trap is the sign of the outlet.",
  correct=r"$30$ hours",
  distractors=[(r"$6$ hours", "Adds the two rates: $\\frac{1}{10} + \\frac{1}{15} = \\frac{1}{6}$."),
               (r"$5$ hours", "Subtracts the times, $15 - 10$."),
               (r"$25$ hours", "Adds the times, $10 + 15$.")],
  check=_c004, values=[30, 6, 5, 25], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 005
def _c005():
    return _first_empty([(Fraction(-1, 12), 0, None), (Fraction(1, 18), 0, None)], level=Fraction(3, 4))
q("C07-B-005", T, "Partly full tank emptied with an inlet also running", "Easy",
  "Multi-step word problem",
  r"A water tank is three-fourths full. Its outlet can empty the full tank in $12$ hours and its inlet can fill the empty tank in $18$ hours. If both are opened at the same moment, in how many hours will the tank become empty?",
  "MCQ",
  r"Net emptying per hour is $\frac{1}{12} - \frac{1}{18} = \frac{3 - 2}{36} = \frac{1}{36}$ of the tank. Only $\frac{3}{4}$ of the tank has to be removed, so the time is $\frac{3}{4} \times 36 = 27$ hours.",
  "Using the whole tank instead of the three-fourths that is actually present.",
  "C07B-inlet-outlet-net", "Net rate plus a partial starting level.",
  correct=r"$27$ hours",
  distractors=[(r"$36$ hours", "Computes the time to empty a full tank and ignores that it is only three-fourths full."),
               (r"$9$ hours", "Ignores the inlet: $\\frac{3}{4} \\times 12 = 9$."),
               (r"$6$ hours", "Subtracts the times, $18 - 12$.")],
  check=_c005, values=[27, 36, 9, 6], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 006
def _c006():
    x = symbols('x', positive=True)
    return _hm(solve(Eq(Rational(1, 8) - 1 / x, Rational(1, 20)), x)[0])
q("C07-B-006", T, "Find inlet time from the time a full tank takes to empty with both open", "Medium",
  "Inverse/parameter",
  r"A full tank has an inlet and an outlet. The outlet alone empties the full tank in $8$ hours. When the inlet and the outlet are both open, the full tank becomes empty in $20$ hours. How long would the inlet alone take to fill the empty tank?",
  "MCQ",
  r"Let the inlet take $x$ hours. Emptying with both open: $\frac{1}{8} - \frac{1}{x} = \frac{1}{20}$, so $\frac{1}{x} = \frac{5 - 2}{40} = \frac{3}{40}$ and $x = \frac{40}{3}$ hours. Since $\frac{1}{3}$ hour is $20$ minutes, the inlet takes $13$ hours $20$ minutes.",
  "Subtracting times directly, or converting $13.33$ hours into $13$ hours $33$ minutes.",
  "C07B-net-rate-inverse", "Inverse use of the net rate plus a recurring-decimal conversion.",
  correct=r"$13$ hours $20$ minutes",
  distractors=[(r"$12$ hours", "Subtracts the times, $20 - 8$."),
               (r"$28$ hours", "Adds the times, $20 + 8$."),
               (r"$13$ hours $33$ minutes", "Reads $13.33$ hours as $13$ hours $33$ minutes.")],
  check=_c006, values=[800, 720, 1680, 813], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 007
def _c007():
    x = symbols('x', positive=True)
    return solve(Eq(Rational(1, 10) - 1 / x, Rational(1, 12)), x)[0]
q("C07-B-007", T, "Leak lengthens filling time; find the leak's emptying time", "Easy",
  "Inverse/parameter",
  r"A pump normally fills a sump in $10$ hours. Because of a leak at the bottom of the sump, it now takes $12$ hours to fill it. If the sump is full and the pump is switched off, how many hours will the leak take to empty it?",
  "MCQ",
  r"The leak's rate is the difference of the two filling rates: $\frac{1}{10} - \frac{1}{12} = \frac{6 - 5}{60} = \frac{1}{60}$ of the sump per hour. So it empties the full sump in $60$ hours.",
  "Treating the extra filling time as the leak's own time.",
  "C07B-leak-detect", "Single step: leak rate is the drop in net filling rate.",
  correct=r"$60$ hours",
  distractors=[(r"$2$ hours", "Takes the extra filling time, $12 - 10$, as the leak's time."),
               (r"$22$ hours", "Adds the two filling times."),
               (r"$120$ hours", "Uses the product $10 \\times 12$ and leaves out the division by the difference $2$.")],
  check=_c007, values=[60, 2, 22, 120], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 008
def _c008():
    x = symbols('x', positive=True)
    # half by pump alone (3 h), remaining half with leak took 7 - 3 = 4 h
    return solve(Eq(Rational(1, 2) / (Rational(1, 6) - 1 / x), 7 - 3), x)[0]
q("C07-B-008", T, "Leak starts midway; find the leak's emptying time", "Medium",
  "Inverse/parameter",
  r"A pump fills an empty tank in $6$ hours. One day, at the moment the tank was exactly half full, a leak developed at its bottom and stayed open, and the tank took $7$ hours in all to fill. Working alone, in how many hours would this leak empty the full tank?",
  "TITA",
  r"The first half took the usual $3$ hours, so the second half took $7 - 3 = 4$ hours, at a net rate of $\frac{1}{2} \div 4 = \frac{1}{8}$ per hour. Leak rate $= \frac{1}{6} - \frac{1}{8} = \frac{1}{24}$, so the leak empties the full tank in $24$ hours.",
  "Assuming the leak was present for the whole $7$ hours.",
  "C07B-leak-detect", "Two phases; the leak acts only during the second half.",
  tita_answer=24, check=_c008,
  tita_traps=[(42, "Treats the leak as present throughout: $\\frac{1}{6} - \\frac{1}{7} = \\frac{1}{42}$."),
              (12, "Reports the time the leak needs to empty half the tank.")],
  cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 009
def _c009():
    t_full = _first_full([(Fraction(1, 20), 0, 6), (Fraction(1, 30), 0, None)])
    return t_full - 6
q("C07-B-009", T, "One of two inlets closed after some minutes", "Easy",
  "Multi-step word problem",
  r"Pipes P and Q can fill an empty tank in $20$ minutes and $30$ minutes respectively. Both are opened together on the empty tank, and after $6$ minutes pipe P is closed. For how many more minutes must Q run to fill the tank?",
  "TITA",
  r"In $6$ minutes both fill $6\left(\frac{1}{20} + \frac{1}{30}\right) = 6 \times \frac{1}{12} = \frac{1}{2}$. Q must fill the other half alone, which takes $\frac{1}{2} \times 30 = 15$ minutes.",
  "Reporting the total time instead of the additional time.",
  "C07B-closed-after-time", "Two stages with one trap about what is asked.",
  tita_answer=15, check=_c009,
  tita_traps=[(21, "Gives the total time $6 + 15$ instead of the extra time."),
              (10, "Lets P finish the remaining half: $\\frac{1}{2} \\times 20$.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 010
def _c010():
    return _first_full([(Fraction(1, 10), 0, None), (Fraction(1, 15), 0, None), (Fraction(-1, 12), 0, 4)])
q("C07-B-010", T, "Outlet closed after some hours with two inlets running", "Medium",
  "Multi-step word problem",
  r"A tank has inlets P and Q, which can fill it in $10$ hours and $15$ hours respectively, and an outlet R, which can empty the full tank in $12$ hours. All three are opened together on the empty tank, and R is closed after $4$ hours. In how many hours from the start will the tank be full?",
  "MCQ",
  r"With all three open the net rate is $\frac{1}{10} + \frac{1}{15} - \frac{1}{12} = \frac{6 + 4 - 5}{60} = \frac{1}{12}$, so $4$ hours fill $\frac{1}{3}$. Then P and Q fill at $\frac{1}{6}$ per hour, so $\frac{2}{3}$ takes $4$ hours. Total $8$ hours.",
  "Reporting only the second stage, or ignoring R altogether.",
  "C07B-closed-after-time", "Two stages with a net rate that includes an outlet.",
  correct=r"$8$ hours",
  distractors=[(r"$4$ hours", "Reports only the time after R is closed."),
               (r"$12$ hours", "Keeps R open throughout: net $\\frac{1}{12}$ gives $12$ hours."),
               (r"$10$ hours", "Adds the full P and Q time of $6$ hours to the first $4$ hours, as if the tank were still empty.")],
  check=_c010, values=[8, 4, 12, 10], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 011
def _c011():
    # minutes after 4:00 pm
    t = _first_full([(Fraction(1, 30), 0, 12), (Fraction(1, 45), 0, None), (Fraction(-1, 36), 0, 20)])
    return 16 * 60 + t
q("C07-B-011", T, "Three-stage schedule where the level falls in the middle stage", "Difficult",
  "Multi-step word problem",
  r"Inlets P and Q can fill an empty tank in $30$ minutes and $45$ minutes respectively, and outlet R can empty the full tank in $36$ minutes. All three are opened together on the empty tank at $4{:}00$ pm. P is closed at $4{:}12$ pm and R is closed at $4{:}20$ pm, while Q stays open. At what time will the tank be full?",
  "MCQ",
  r"All three: $\frac{1}{30} + \frac{1}{45} - \frac{1}{36} = \frac{6 + 4 - 5}{180} = \frac{1}{36}$ per minute, so by $4{:}12$ the tank is $\frac{12}{36} = \frac{1}{3}$ full. From $4{:}12$ to $4{:}20$ only Q and R work: $\frac{1}{45} - \frac{1}{36} = -\frac{1}{180}$, so the level falls by $\frac{8}{180} = \frac{2}{45}$ to $\frac{13}{45}$. Q alone then needs $\frac{32}{45} \times 45 = 32$ minutes, so the tank is full at $4{:}52$ pm.",
  "Not noticing that Q and R together drain the tank in the middle stage.",
  "C07B-closed-after-time", "Three stages, and the middle one has a negative net rate that is easy to miss.",
  correct=r"$4{:}52$ pm",
  distractors=[(r"$4{:}50$ pm", "Treats the level as unchanged between $4{:}12$ and $4{:}20$, then lets Q fill $\\frac{2}{3}$ in $30$ minutes from $4{:}20$."),
               (r"$4{:}48$ pm", "Takes the middle-stage net as $+\\frac{1}{180}$ per minute, giving $\\frac{17}{45}$ at $4{:}20$ and $28$ more minutes."),
               (r"$4{:}40$ pm", "Keeps all three pipes open for the first $20$ minutes ($\\frac{5}{9}$), then $20$ minutes of Q alone.")],
  check=_c011, values=[16 * 60 + 52, 16 * 60 + 50, 16 * 60 + 48, 16 * 60 + 40], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 012
def _c012():
    # hours after midnight; P from 6, Q from 9
    t = _first_full([(Fraction(1, 15), 6, None), (Fraction(1, 10), 9, None)])
    return t * 60
q("C07-B-012", T, "Second inlet opened a few hours later, clock time", "Easy",
  "Multi-step word problem",
  r"Pipe P can fill an empty tank in $15$ hours and pipe Q can fill it in $10$ hours. P is opened on the empty tank at $6{:}00$ am, and Q is also opened at $9{:}00$ am. At what time will the tank be full?",
  "MCQ",
  r"By $9{:}00$ am, P has filled $\frac{3}{15} = \frac{1}{5}$. Together they fill $\frac{1}{15} + \frac{1}{10} = \frac{1}{6}$ per hour, so $\frac{4}{5}$ takes $\frac{4}{5} \times 6 = 4.8$ hours $= 4$ hours $48$ minutes. The tank is full at $1{:}48$ pm.",
  "Ignoring P's head start or converting $4.8$ hours wrongly.",
  "C07B-opened-later", "Two stages and a decimal-hour to clock conversion.",
  correct=r"$1{:}48$ pm",
  distractors=[(r"$12{:}00$ noon", "Uses the combined time of $6$ hours counted from $6{:}00$ am."),
               (r"$3{:}00$ pm", "Uses the combined time of $6$ hours counted from $9{:}00$ am, ignoring P's head start."),
               (r"$2{:}20$ pm", "Reads $4.8$ hours as $4$ hours $80$ minutes, that is $5$ hours $20$ minutes.")],
  check=_c012, values=[13 * 60 + 48, 12 * 60, 15 * 60, 14 * 60 + 20], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 013
def _c013():
    return int(_first_full([(Fraction(1, 8), 0, None), (Fraction(-1, 12), 2, None)]))
q("C07-B-013", T, "Outlet opened two hours after the inlet", "Easy",
  "Multi-step word problem",
  r"An inlet can fill an empty tank in $8$ hours and an outlet can empty the full tank in $12$ hours. The inlet is opened on the empty tank, and $2$ hours later the outlet is also opened; both then stay open. How many hours after the inlet was opened will the tank be full?",
  "TITA",
  r"In the first $2$ hours the inlet fills $\frac{2}{8} = \frac{1}{4}$. Then the net rate is $\frac{1}{8} - \frac{1}{12} = \frac{1}{24}$, so the remaining $\frac{3}{4}$ takes $18$ hours. Total $2 + 18 = 20$ hours.",
  "Reporting only the time after the outlet is opened.",
  "C07B-opened-later", "Two stages with a net rate; the question asks for total time.",
  tita_answer=20, check=_c013,
  tita_traps=[(18, "Gives only the time after the outlet is opened."),
              (24, "Treats both pipes as open from the start.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 014
def _c014():
    # P, Q from noon; R opens when half full
    t_half = Fraction(1, 2) / (Fraction(1, 10) + Fraction(1, 15))
    t = _first_full([(Fraction(1, 10), 0, None), (Fraction(1, 15), 0, None), (Fraction(-1, 12), t_half, None)])
    return t
q("C07-B-014", T, "Outlet that opens automatically at the halfway level", "Medium",
  "Multi-step word problem",
  r"Inlets P and Q can fill an empty tank in $10$ hours and $15$ hours respectively. Both are opened on the empty tank at $12{:}00$ noon. A float valve opens an outlet R the moment the tank becomes half full, and R stays open after that; R alone can empty the full tank in $12$ hours. At what time will the tank be full?",
  "MCQ",
  r"P and Q fill $\frac{1}{10} + \frac{1}{15} = \frac{1}{6}$ per hour, so the tank is half full at $3{:}00$ pm. After that the net rate is $\frac{1}{6} - \frac{1}{12} = \frac{1}{12}$, so the other half takes $6$ hours. The tank is full at $9{:}00$ pm.",
  "Applying the outlet to the whole tank, or applying the net rate to a whole tank instead of half.",
  "C07B-opened-later", "Two stages switched by the level, not by the clock.",
  correct=r"$9{:}00$ pm",
  distractors=[(r"$6{:}00$ pm", "Ignores R completely: $6$ hours from noon."),
               (r"$12{:}00$ midnight", "Keeps R open from the start: net $\\frac{1}{12}$ gives $12$ hours."),
               (r"$3{:}00$ am", "Takes $12$ hours at the net rate for the second half, as if a whole tank remained.")],
  check=_c014, values=[9, 6, 12, 15], cognitive="Application", exams=ALL)


# ---------------------------------------------------------------- 015-017 cyclic schedules
def _cycle(rates, start_level=Fraction(0), slot=1):
    L = Fraction(start_level); t = Fraction(0); i = 0
    while t < 1000:
        r = Fraction(rates[i % len(rates)])
        if r > 0 and L + r * slot >= 1:
            return t + (1 - L) / r
        L = max(Fraction(0), L + r * slot); t += slot; i += 1
    return None

def _c015():
    return _cycle([Fraction(1, 6), Fraction(1, 9)]) * 60
q("C07-B-015", T, "Two inlets opened alternately for an hour each", "Medium",
  "Conceptual/application",
  r"Pipes P and Q can fill an empty tank in $6$ hours and $9$ hours respectively. Starting with the empty tank, they are opened alternately for one hour each, beginning with P (P for the first hour, Q for the second, P for the third, and so on), with only one pipe open at any time. How long does it take to fill the tank?",
  "MCQ",
  r"Each $2$-hour cycle fills $\frac{1}{6} + \frac{1}{9} = \frac{5}{18}$. After $3$ cycles ($6$ hours) the tank holds $\frac{15}{18}$, leaving $\frac{3}{18} = \frac{1}{6}$. The next hour is P's, and P fills exactly $\frac{1}{6}$ in that hour. Total $7$ hours.",
  "Treating alternate working as half of simultaneous working, or forgetting which pipe works last.",
  "C07B-alternating-cycle", "Cycle counting with a check of which pipe finishes the job.",
  correct=r"$7$ hours",
  distractors=[(r"$7$ hours $12$ minutes", "Doubles the time with both open together: $2 \\times \\frac{18}{5} = 7.2$ hours."),
               (r"$7$ hours $30$ minutes", "After $6$ hours lets Q, instead of P, fill the remaining $\\frac{1}{6}$ alone: $\\frac{1}{6} \\times 9 = 1.5$ hours."),
               (r"$8$ hours", "Rounds up to a whole number of $2$-hour cycles.")],
  check=_c015, values=[420, 432, 450, 480], cognitive="Analysis", exams=ALL)

def _c016():
    return int(_cycle([Fraction(1, 4), Fraction(-1, 6)]))
q("C07-B-016", T, "Inlet and outlet alternate hourly; tank fills during an inlet hour", "Difficult",
  "Conceptual/application",
  r"An inlet can fill an empty tank in $4$ hours and an outlet can empty the full tank in $6$ hours. Starting with the empty tank, only the inlet is open in the first hour, only the outlet in the second hour, only the inlet in the third hour, and so on. After how many hours from the start will the tank be full for the first time?",
  "TITA",
  r"Each $2$-hour cycle gains $\frac{1}{4} - \frac{1}{6} = \frac{1}{12}$. The tank fills during an inlet hour once the level at the start of that hour is at least $1 - \frac{1}{4} = \frac{3}{4}$. That level $\frac{9}{12}$ is reached after $9$ cycles, that is $18$ hours. In the $19$th hour the inlet adds exactly $\frac{1}{4}$, so the tank is full after $19$ hours.",
  "Using the average gain per cycle all the way to a full tank.",
  "C07B-alternating-cycle", "The last cycle must be handled separately because the tank fills before the outlet's turn.",
  tita_answer=19, check=_c016,
  tita_traps=[(24, "Uses $12$ full cycles of net $\\frac{1}{12}$, that is $24$ hours."),
              (23, "Uses $12$ cycles but drops the final outlet hour.")],
  cognitive="Analysis", exams=HARD)

def _c017():
    return _cycle([Fraction(1, 10), Fraction(1, 15), Fraction(-1, 18)]) * 60
q("C07-B-017", T, "Three pipes in hourly rotation including an outlet", "Difficult",
  "Casework/optimisation",
  r"Inlets P and Q can fill an empty tank in $10$ hours and $15$ hours respectively, and outlet R can empty the full tank in $18$ hours. Starting with the empty tank, the pipes are opened one at a time for one hour each in the order P, Q, R, P, Q, R, and so on. How long after the start does the tank first become full?",
  "MCQ",
  r"One $3$-hour round adds $\frac{1}{10} + \frac{1}{15} - \frac{1}{18} = \frac{9 + 6 - 5}{90} = \frac{1}{9}$. Within a round the highest level is reached after Q's hour, $\frac{1}{6}$ above the starting level, so the tank fills in the round that starts at a level of at least $\frac{5}{6}$. After $8$ rounds ($24$ hours) the level is $\frac{8}{9}$. P's hour takes it to $\frac{8}{9} + \frac{1}{10} = \frac{89}{90}$, and Q needs $\frac{1}{90} \div \frac{1}{15} = \frac{1}{6}$ hour $= 10$ minutes. Total $25$ hours $10$ minutes.",
  "Using the average net gain per round all the way to a full tank.",
  "C07B-alternating-cycle", "Requires tracking the level inside the final round, not just per round.",
  correct=r"$25$ hours $10$ minutes",
  distractors=[(r"$27$ hours", "Uses $9$ full rounds of net $\\frac{1}{9}$."),
               (r"$26$ hours", "Counts full hours of P and Q in the ninth round."),
               (r"$24$ hours $40$ minutes", "After $8$ rounds lets P and Q run together on the last $\\frac{1}{9}$: $\\frac{1}{9} \\div \\frac{1}{6} = 40$ minutes.")],
  check=_c017, values=[1510, 1620, 1560, 1480], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 018
def _c018():
    t = symbols('t', positive=True)
    return solve(Eq(Rational(40, 30) - t / 45, 1), t)[0]
q("C07-B-018", T, "When to close an outlet so the tank fills at a target time", "Medium",
  "Inverse/parameter",
  r"An inlet P can fill an empty tank in $30$ minutes and an outlet Q can empty the full tank in $45$ minutes. Both are opened together on the empty tank. After how many minutes should Q be closed so that the tank is full exactly $40$ minutes after the start?",
  "MCQ",
  r"P runs all $40$ minutes and supplies $\frac{40}{30} = \frac{4}{3}$ of the tank. The extra $\frac{1}{3}$ must be removed by Q, which removes $\frac{1}{45}$ per minute, so Q must stay open $\frac{1}{3} \times 45 = 15$ minutes.",
  "Dividing the excess by the net rate instead of by Q's rate.",
  "C07B-when-to-close", "Inverse reasoning on the total supply and removal.",
  correct=r"$15$ minutes",
  distractors=[(r"$10$ minutes", "Uses P's time in place of Q's: $\\frac{1}{3} \\times 30$."),
               (r"$25$ minutes", "Reports the time for which Q is closed, $40 - 15$."),
               (r"$30$ minutes", "Divides $\\frac{1}{3}$ by the net rate $\\frac{1}{30} - \\frac{1}{45} = \\frac{1}{90}$.")],
  check=_c018, values=[15, 10, 25, 30], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 019
def _c019():
    r = symbols('r', positive=True)
    # 6 am to 11 am all three, 11 am to 3 pm P and Q
    rv = solve(Eq(9 * (Rational(1, 10) + Rational(1, 15)) - 5 * r, 1), r)[0]
    t = 1 / (Rational(1, 10) + Rational(1, 15) - rv)
    return 6 + t
q("C07-B-019", T, "Infer outlet rate from a schedule, then predict another schedule", "Difficult",
  "Inverse/parameter",
  r"Inlets P and Q can fill an empty tank in $10$ hours and $15$ hours respectively. The tank also has an outlet R. One day P, Q and R were all opened together on the empty tank at $6{:}00$ am; R was closed at $11{:}00$ am, and the tank became full at $3{:}00$ pm. On another day all three were opened on the empty tank at $6{:}00$ am and R was never closed. At what time was the tank full on that day?",
  "MCQ",
  r"P and Q fill $\frac{1}{6}$ per hour, so in $9$ hours they supply $\frac{3}{2}$ of the tank; R removed the extra $\frac{1}{2}$ in its $5$ hours, so R empties $\frac{1}{10}$ per hour. With R open throughout, the net rate is $\frac{1}{6} - \frac{1}{10} = \frac{1}{15}$, so the tank takes $15$ hours and is full at $9{:}00$ pm.",
  "Spreading R's removal over the wrong length of time when inferring its rate.",
  "C07B-when-to-close", "Two linked stages: infer a rate from one schedule, then apply it to another.",
  correct=r"$9{:}00$ pm",
  distractors=[(r"$6{:}00$ am the next day", "Divides the excess $\\frac{1}{2}$ by the $4$ hours after R was closed, so $r = \\frac{1}{8}$ and the net is $\\frac{1}{24}$, giving $24$ hours."),
               (r"$6{:}00$ pm", "Divides the excess $\\frac{1}{2}$ by the $6$ hours P and Q need, so $r = \\frac{1}{12}$ and the net is $\\frac{1}{12}$, giving $12$ hours."),
               (r"$3{:}00$ pm", "Overlooks that R was closed at $11{:}00$ am and spreads the excess $\\frac{1}{2}$ over all $9$ hours, so $r = \\frac{1}{18}$ and the net is $\\frac{1}{6} - \\frac{1}{18} = \\frac{1}{9}$, giving $9$ hours.")],
  check=_c019, values=[21, 30, 18, 15], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 020
def _c020():
    x = symbols('x', positive=True)
    # flow proportional to square of diameter (same water speed)
    # rate = 1/time is proportional to d^2: (1/x) / (1/36) = 2^2 / 3^2
    return solve(Eq(Integer(36) / x, Rational(2 ** 2, 3 ** 2)), x)[0]
q("C07-B-020", T, "Pipe flow proportional to cross-sectional area", "Easy",
  "Conceptual/application",
  r"Two circular pipes of diameters $2$ cm and $3$ cm feed a tank. Water flows through both at the same speed, so each pipe's rate of flow is proportional to its cross-sectional area. The $3$ cm pipe alone fills the empty tank in $36$ minutes. In how many minutes would the $2$ cm pipe alone fill it?",
  "MCQ",
  r"Rates are in the ratio of areas, $2^2 : 3^2 = 4 : 9$. Time is inversely proportional to rate, so the $2$ cm pipe takes $36 \times \frac{9}{4} = 81$ minutes.",
  "Scaling with the diameter instead of its square.",
  "C07B-pipe-cross-section", "One idea: area scales as the square of the diameter.",
  correct=r"$81$ minutes",
  distractors=[(r"$54$ minutes", "Scales with the diameter: $36 \\times \\frac{3}{2}$."),
               (r"$16$ minutes", "Multiplies by $\\frac{4}{9}$ instead of $\\frac{9}{4}$, as if the smaller pipe were faster."),
               (r"$24$ minutes", "Scales with the diameter and inverts it: $36 \\times \\frac{2}{3}$.")],
  check=_c020, values=[81, 54, 16, 24], cognitive="Understanding", exams=ALL)

# ---------------------------------------------------------------- 021
def _c021():
    k = Fraction(1)
    V = 25 * k * 40
    for n in range(1, 100):
        net = n * 4 * k - 9 * k
        if net > 0 and V / net <= 30:
            return n
q("C07-B-021", T, "Minimum number of small inlets against an outlet, flow by area", "Difficult",
  "Casework/optimisation",
  r"With no outlet open, a single inlet of diameter $5$ cm fills an empty tank in $40$ minutes. This inlet is replaced by several identical inlets of diameter $2$ cm, and a new outlet of diameter $3$ cm is fitted, which is kept open throughout the filling. Water flows through every pipe at the same speed, so each pipe's flow rate is proportional to its cross-sectional area. What is the least number of $2$ cm inlets needed so that the empty tank is filled in at most $30$ minutes?",
  "TITA",
  r"Take the flow per minute through a pipe as $d^2$ units. The tank holds $25 \times 40 = 1000$ units. With $n$ small inlets the net inflow is $4n - 9$ units per minute, and we need $\frac{1000}{4n - 9} \le 30$, that is $4n \ge 9 + 33.3 = 42.3$, so $n \ge 10.6$. The least whole number is $11$ (check: $11$ inlets give $\frac{1000}{35} \approx 28.6$ minutes, $10$ give $\frac{1000}{31} \approx 32.3$ minutes).",
  "Ignoring the outlet or rounding the bound down.",
  "C07B-min-number-of-pipes", "Combines area scaling, a net rate with an outlet, and an integer bound.",
  tita_answer=11, check=_c021,
  tita_traps=[(9, "Ignores the outlet: $4n \\ge 33.3$ gives $9$."),
              (10, "Rounds $10.6$ down.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 022
def _c022():
    # simulate in two phases by level
    t1 = Fraction(1, 3) / Fraction(1, 12)
    t2 = Fraction(2, 3) / (Fraction(1, 12) - Fraction(1, 24))
    return t1 + t2
q("C07-B-022", T, "Leak hole partway up the wall acts only above its level", "Medium",
  "Conceptual/application",
  r"A pipe fills an empty tank in $12$ hours. There is a small hole in the side wall at one-third of the tank's height from the bottom. Whenever the water level is above the hole, water escapes through it at a constant rate of $\frac{1}{24}$ of the tank's capacity per hour; below that level nothing escapes. The tank has vertical sides. How many hours does the pipe take to fill the empty tank?",
  "MCQ",
  r"The bottom third fills with no loss: $\frac{1}{3} \times 12 = 4$ hours. Above the hole the net rate is $\frac{1}{12} - \frac{1}{24} = \frac{1}{24}$, so the upper two-thirds take $\frac{2}{3} \times 24 = 16$ hours. Total $20$ hours.",
  "Applying the leak during the whole filling.",
  "C07B-outlet-at-height", "Needs the insight that the leak works only above its height.",
  correct=r"$20$ hours",
  distractors=[(r"$24$ hours", "Applies the leak for the whole filling: net $\\frac{1}{24}$."),
               (r"$16$ hours", "Applies the leak to the lower third ($8$ hours) and not to the upper two-thirds ($8$ hours)."),
               (r"$12$ hours", "Ignores the hole.")],
  check=_c022, values=[20, 24, 16, 12], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 023
def _c023():
    # step simulation in small exact steps by level phases
    inlet, bottom = Fraction(1, 12), Fraction(1, 6)
    mid = Fraction(1, 2) / 3
    L, t = Fraction(1), Fraction(0)
    # phase above mid height
    net = inlet - bottom - mid
    t += (L - Fraction(1, 2)) / (-net); L = Fraction(1, 2)
    net = inlet - bottom
    t += L / (-net)
    return t
q("C07-B-023", T, "Emptying a full tank with outlets at the bottom and at mid-height while an inlet runs", "Difficult",
  "Conceptual/application",
  r"A full tank with vertical sides has an inlet that can fill the empty tank in $12$ hours, an outlet at the bottom that can empty the full tank in $6$ hours, and a second outlet in the side wall at exactly half the tank's height. Water leaves through the side outlet at a constant rate only while the level is above it; on its own it would lower the level from full to the halfway mark in $3$ hours. All three are opened at the same moment. After how many hours does the tank first become empty?",
  "TITA",
  r"The side outlet removes $\frac{1}{2} \div 3 = \frac{1}{6}$ of the tank per hour. Upper half: net outflow $\frac{1}{6} + \frac{1}{6} - \frac{1}{12} = \frac{1}{4}$, so it takes $\frac{1}{2} \div \frac{1}{4} = 2$ hours. Lower half: only the bottom outlet works, net $\frac{1}{6} - \frac{1}{12} = \frac{1}{12}$, taking $6$ hours. Total $8$ hours.",
  "Letting the side outlet work all the way down.",
  "C07B-outlet-at-height", "Two phases switched by level, with an inlet working against two outlets.",
  tita_answer=8, check=_c023,
  tita_traps=[(4, "Keeps the side outlet working throughout: net $\\frac{1}{4}$ gives $4$ hours."),
              (12, "Ignores the side outlet: net $\\frac{1}{12}$ gives $12$ hours.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 024
def _c024():
    t_half = Fraction(1, 2) / (Fraction(1, 6) - Fraction(1, 9))
    return _first_full([(Fraction(1, 6), 0, None), (Fraction(-1, 9), 0, t_half)])
q("C07-B-024", T, "Outlet left open by mistake, closed at half full", "Easy",
  "Multi-step word problem",
  r"An inlet fills an empty tank in $6$ hours. While filling the empty tank, Meera forgot to close the outlet, which can empty the full tank in $9$ hours. She noticed it when the tank was exactly half full and closed the outlet at once. How long did the tank take to fill in all?",
  "MCQ",
  r"With both open the net rate is $\frac{1}{6} - \frac{1}{9} = \frac{1}{18}$, so the first half took $9$ hours. The second half at $\frac{1}{6}$ per hour took $3$ hours. Total $12$ hours.",
  "Keeping the outlet open throughout, or refilling a whole tank after the outlet is closed.",
  "C07B-outlet-left-open", "Two stages with a level-based switch.",
  correct=r"$12$ hours",
  distractors=[(r"$18$ hours", "Keeps the outlet open throughout."),
               (r"$9$ hours", "Reports only the time until the mistake was noticed."),
               (r"$15$ hours", "Adds a full $6$ hours after closing the outlet, as if a whole tank remained.")],
  check=_c024, values=[12, 18, 9, 15], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 025
def _c025():
    t = symbols('t', positive=True)
    return solve(Eq(Rational(7, 5) - t / 10, 1), t)[0]
q("C07-B-025", T, "How long an outlet was left open, from the delay", "Medium",
  "Inverse/parameter",
  r"An inlet normally fills an empty tank in $5$ hours. One day the outlet, which can empty the full tank in $10$ hours, was open when filling began; after a while it was closed, and the tank took $7$ hours in all to fill. For how many hours was the outlet open?",
  "TITA",
  r"The inlet ran $7$ hours and supplied $\frac{7}{5}$ of the tank, so the outlet removed $\frac{2}{5}$. At $\frac{1}{10}$ per hour that takes $4$ hours.",
  "Equating the delay itself with the outlet's open time.",
  "C07B-when-to-close", "Inverse reasoning from the delay; supply minus removal equals one tank.",
  tita_answer=4, check=_c025,
  tita_traps=[(2, "Takes the $2$ hour delay as the time the outlet was open."),
              (7, "Assumes the outlet was open for the whole $7$ hours.")],
  cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 026
def _c026():
    C = symbols('C', positive=True)
    return solve(Eq(C / 300 - 40, C / 480), C)[0]
q("C07-B-026", T, "Capacity from an outlet's flow in litres per minute", "Medium",
  "Inverse/parameter",
  r"An inlet fills an empty tank in $5$ hours. When an outlet that drains $40$ litres per minute is also open, the inlet takes $8$ hours to fill the empty tank. What is the capacity of the tank?",
  "MCQ",
  r"Let the capacity be $C$ litres. Inlet rate $\frac{C}{300}$ litres per minute; with the outlet the net rate is $\frac{C}{480}$. So $\frac{C}{300} - \frac{C}{480} = 40$, that is $C \cdot \frac{180}{144000} = 40$, so $\frac{C}{800} = 40$ and $C = 32{,}000$ litres.",
  "Treating the outlet as emptying the full tank in one of the given times.",
  "C07B-litres-flow-rates", "Mixes a time-based rate with a litre-based rate.",
  correct=r"$32{,}000$ litres",
  distractors=[(r"$19{,}200$ litres", "Multiplies $40$ litres per minute by the $480$ minute filling time."),
               (r"$12{,}000$ litres", "Multiplies $40$ litres per minute by the $300$ minute filling time."),
               (r"$7{,}200$ litres", "Multiplies $40$ litres per minute by the $180$ minute delay.")],
  check=_c026, values=[32000, 19200, 12000, 7200], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 027
def _c027():
    L, t = 300, 0
    while L < 1800:
        L += 25 - 10; t += 1
    return t
q("C07-B-027", T, "Partly filled tank, inflow and outflow in litres per minute", "Easy",
  "Single-step computation",
  r"A tank of capacity $1{,}800$ litres already holds $300$ litres of water. An inlet adds $25$ litres per minute and an outlet removes $10$ litres per minute. If both are opened at the same moment, how many minutes will the tank take to become full?",
  "MCQ",
  r"The tank needs $1800 - 300 = 1500$ litres, and the net inflow is $25 - 10 = 15$ litres per minute. Time $= \frac{1500}{15} = 100$ minutes.",
  "Ignoring the water already present or the outlet.",
  "C07B-litres-flow-rates", "One step once the remaining volume and net flow are seen.",
  correct=r"$100$ minutes",
  distractors=[(r"$120$ minutes", "Ignores the $300$ litres already present: $\\frac{1800}{15}$."),
               (r"$60$ minutes", "Ignores the outlet: $\\frac{1500}{25}$."),
               (r"$72$ minutes", "Ignores both the water present and the outlet: $\\frac{1800}{25}$.")],
  check=_c027, values=[100, 120, 60, 72], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 028
def _c028():
    C = symbols('C', positive=True)
    return solve(Eq(C / 20 + C / 30 - 15, C / 18), C)[0]
q("C07-B-028", T, "Capacity when an outlet is given in litres per minute", "Medium",
  "Inverse/parameter",
  r"Pipes P and Q can fill an empty tank in $20$ minutes and $30$ minutes respectively. An outlet R drains $15$ litres per minute. When P, Q and R are all open, the empty tank fills in $18$ minutes. What is the capacity of the tank in litres?",
  "TITA",
  r"P and Q together fill the tank in $12$ minutes, so in $18$ minutes they supply $\frac{18}{12} = \frac{3}{2}$ tanks. R removes the extra half tank in $18$ minutes, that is $15 \times 18 = 270$ litres. So half the tank is $270$ litres and the capacity is $540$ litres.",
  "Taking R's total outflow as the whole capacity.",
  "C07B-litres-flow-rates", "Converts a time-based supply and a litre-based drain into one equation.",
  tita_answer=540, check=_c028,
  tita_traps=[(270, "Takes R's outflow $15 \\times 18$ as the capacity instead of half of it."),
              (180, "Multiplies $15$ by the $12$ minute P and Q time.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 029
def _c029():
    old = Fraction(2400)
    new = Fraction(3600)
    pq = old / 6          # litres per hour
    r = old / 18
    return new / (pq + r) * 60
q("C07-B-029", T, "Larger replacement tank with an extra inlet", "Medium",
  "Conceptual/application",
  r"Two pipes together fill a $2{,}400$ litre tank in $6$ hours. The tank is replaced by a $3{,}600$ litre tank, and a third pipe is added; working alone, the third pipe would fill the old $2{,}400$ litre tank in $18$ hours. All three pipes keep their old flow rates. How long will the three pipes together take to fill the new tank?",
  "MCQ",
  r"The two pipes supply $400$ litres per hour and the third pipe $\frac{2400}{18} = \frac{400}{3}$ litres per hour, a total of $\frac{1600}{3}$ litres per hour. The new tank needs $3600 \div \frac{1600}{3} = \frac{27}{4}$ hours $= 6$ hours $45$ minutes.",
  "Applying the third pipe's time to the new tank, or ignoring the change in capacity.",
  "C07B-capacity-change", "Rates must be kept in litres when the capacity changes.",
  correct=r"$6$ hours $45$ minutes",
  distractors=[(r"$9$ hours", "Ignores the third pipe: $1.5 \\times 6$ hours."),
               (r"$4$ hours $30$ minutes", "Ignores the larger capacity: the old tank at $\\frac{1}{6} + \\frac{1}{18} = \\frac{2}{9}$ per hour."),
               (r"$6$ hours", "Applies the $18$ hours to the new tank: $\\frac{1}{9} + \\frac{1}{18} = \\frac{1}{6}$ of the new tank per hour.")],
  check=_c029, values=[405, 540, 270, 360], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 030
def _c030():
    # simulate in 1/60 hour steps with exact fractions
    rate = Fraction(1, 10); water = Fraction(0); block = Fraction(0); t = Fraction(0); dt = Fraction(1, 60)
    while water + block < 1:
        water += rate * dt; t += dt
        if t == 4:
            block = Fraction(1, 5)
    return int(t)
q("C07-B-030", T, "Submerged block reduces the volume of water needed", "Medium",
  "Conceptual/application",
  r"A pipe fills an empty tank in $10$ hours. Four hours after the pipe is opened, a solid stone block whose volume is one-fifth of the tank's capacity is lowered into the tank and left resting on its floor; the block is fully under water by the time the tank is full. The pipe keeps running. How many hours after the pipe was opened will the tank be full?",
  "TITA",
  r"The tank is full when water plus block fill the capacity, so the water needed is only $1 - \frac{1}{5} = \frac{4}{5}$ of the capacity. At $\frac{1}{10}$ per hour that takes $8$ hours, whatever the moment the block is lowered (here at $4$ hours, when only $\frac{2}{5}$ is filled). So the tank is full after $8$ hours.",
  "Ignoring the block's volume or adding it to the water needed.",
  "C07B-capacity-change", "Needs the insight that the block only changes the volume of water required.",
  tita_answer=8, check=_c030,
  tita_traps=[(10, "Ignores the block."),
              (12, "Adds the block's volume to the water needed: $\\frac{6}{5} \\times 10$.")],
  cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 031
def _c031():
    for n in range(1, 50):
        net = Fraction(n, 15) - Fraction(1, 10)
        if net > 0 and 1 / net <= 3:
            return n
q("C07-B-031", T, "Least number of identical inlets against an open outlet", "Medium",
  "Casework/optimisation",
  r"Each of several identical inlet pipes can fill an empty tank in $15$ hours, and an outlet that stays open can empty the full tank in $10$ hours. What is the least number of inlet pipes that must be opened together so that the empty tank is filled in at most $3$ hours?",
  "TITA",
  r"With $n$ inlets the net rate is $\frac{n}{15} - \frac{1}{10}$, and we need it to be at least $\frac{1}{3}$. So $\frac{n}{15} \ge \frac{1}{3} + \frac{1}{10} = \frac{13}{30}$, giving $n \ge 6.5$. The least number is $7$.",
  "Ignoring the outlet or rounding down.",
  "C07B-min-number-of-pipes", "An inequality with an integer answer.",
  tita_answer=7, check=_c031,
  tita_traps=[(5, "Ignores the outlet: $\\frac{n}{15} \\ge \\frac{1}{3}$."),
              (6, "Rounds $6.5$ down.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 032
def _c032():
    best = None
    # one pipe at a time; Q at least 3 h; try Q run times in quarter hours
    for q4 in range(12, 61):
        tq = Fraction(q4, 4)
        rem = 1 - tq / 15
        tp = max(Fraction(0), rem * 10)
        tot = tq + tp
        if best is None or tot < best:
            best = tot
    return best
q("C07-B-032", T, "One pipe at a time with a minimum running time for the slower pipe", "Medium",
  "Casework/optimisation",
  r"Pipes P and Q can fill an empty tank in $10$ hours and $15$ hours respectively. Both share one pump, so only one of them can run at any time, and the slower pipe Q must run for at least $3$ hours in total. What is the least time in which the empty tank can be filled?",
  "MCQ",
  r"Since only one pipe runs at a time and Q is the slower pipe, Q should run for exactly the required minimum of $3$ hours, filling $\frac{3}{15} = \frac{1}{5}$. P fills the remaining $\frac{4}{5}$ in $8$ hours. Least time $3 + 8 = 11$ hours.",
  "Running both together, or forgetting Q's contribution.",
  "C07B-constrained-scheduling", "An optimisation: give the slower pipe the minimum time.",
  correct=r"$11$ hours",
  distractors=[(r"$12$ hours", "Shares the pump time equally between the pipes: $t\\left(\\frac{1}{10} + \\frac{1}{15}\\right) = 1$ gives $t = 6$ hours each, $12$ hours in all."),
               (r"$15$ hours", "Runs Q for $3$ hours but then fills the remaining $\\frac{4}{5}$ at Q's rate: $3 + \\frac{4}{5} \\times 15 = 15$."),
               (r"$13$ hours", "Adds Q's $3$ hours to P's full $10$ hours, forgetting what Q filled.")],
  check=_c032, values=[11, 12, 15, 13], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- 033
def _c033():
    p = symbols('p', positive=True)
    return solve(Eq(1 / p + 1 / (p + 10), Rational(1, 12)), p)[0]
q("C07-B-033", T, "Two inlets whose times differ by a given amount", "Medium",
  "Inverse/parameter",
  r"Pipe Q takes $10$ hours longer than pipe P to fill an empty tank. Together they fill the empty tank in $12$ hours. How long does P alone take to fill it?",
  "MCQ",
  r"Let P take $p$ hours. Then $\frac{1}{p} + \frac{1}{p + 10} = \frac{1}{12}$, so $12(2p + 10) = p(p + 10)$, that is $p^2 - 14p - 120 = 0 = (p - 20)(p + 6)$. Hence $p = 20$ hours (and Q takes $30$ hours).",
  "Reporting Q's time, or averaging the times.",
  "C07B-pipe-time-relation", "Sets up and factors a quadratic in the unknown time.",
  correct=r"$20$ hours",
  distractors=[(r"$30$ hours", "Reports Q's time instead of P's."),
               (r"$24$ hours", "Treats the pipes as identical: $2 \\times 12$."),
               (r"$19$ hours", "Assumes the two times average $24$ hours, so $p + (p + 10) = 48$.")],
  check=_c033, values=[20, 30, 24, 19], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 034
def _c034():
    x = symbols('x', positive=True)
    return solve(Eq(Rational(2, 3) / (1 / x - 1 / (x + 2)), 40), x)[0]
q("C07-B-034", T, "Inlet time from a partly full tank, outlet slower by a fixed amount", "Difficult",
  "Inverse/parameter",
  r"An outlet takes $2$ hours longer to empty a full tank than an inlet takes to fill the empty tank. When the tank is one-third full and both are opened together, the tank becomes full in $40$ hours. How long does the inlet alone take to fill the empty tank?",
  "MCQ",
  r"Let the inlet take $x$ hours. Net rate $\frac{1}{x} - \frac{1}{x + 2} = \frac{2}{x(x + 2)}$, and it fills the remaining $\frac{2}{3}$ in $40$ hours, so $\frac{2}{x(x + 2)} = \frac{2}{3} \div 40 = \frac{1}{60}$. Then $x(x + 2) = 120 = 10 \times 12$, so $x = 10$ hours.",
  "Ignoring the water already in the tank.",
  "C07B-pipe-time-relation", "A quadratic set up from a partly full tank; several plausible slips.",
  correct=r"$10$ hours",
  distractors=[(r"$8$ hours", "Ignores the one-third already present and treats $40$ hours as the time for a whole tank: $x(x + 2) = 80$ gives $x = 8$."),
               (r"$12$ hours", "Reports the outlet's time."),
               (r"$60$ hours", "Reports the time to fill an empty tank with both open, $40 \\div \\frac{2}{3}$.")],
  check=_c034, values=[10, 8, 12, 60], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 035
def _c035():
    p = symbols('p', positive=True)
    return solve(Eq(p / 2 + Rational(1, 2) / (1 / p + Rational(1, 15)), 8), p)[0]
q("C07-B-035", T, "Half filled by one pipe, the rest by both; find the first pipe's time", "Difficult",
  "Inverse/parameter",
  r"An empty tank is filled as follows: pipe P alone fills the first half, and then pipe Q is also opened and the two together fill the second half. Q alone can fill the empty tank in $15$ hours, and the whole process takes $8$ hours. How long would P alone take to fill the empty tank?",
  "MCQ",
  r"Let P take $p$ hours. The first half takes $\frac{p}{2}$ hours, and the second half takes $\frac{1}{2} \div \left(\frac{1}{p} + \frac{1}{15}\right) = \frac{15p}{2(p + 15)}$ hours. So $\frac{p}{2} + \frac{15p}{2(p + 15)} = 8$, which gives $p^2 + 14p - 240 = 0 = (p - 10)(p + 24)$. Hence $p = 10$ hours.",
  "Treating the first half as the whole process, or assuming the two halves take equal time.",
  "C07B-staged-by-level", "Unknown rate enters both level-based stages, so the time equation is rational in $p$ and leads to a quadratic; no shortcut gives the rate directly.",
  correct=r"$10$ hours",
  distractors=[(r"$15$ hours", "Reports Q's time."),
               (r"$16$ hours", "Assumes P's first half took all $8$ hours, so P alone would take $16$."),
               (r"$8$ hours", "Assumes the two halves take equal time, $4$ hours each, so P alone takes $2 \\times 4 = 8$ hours.")],
  check=_c035, values=[10, 15, 16, 8], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    P, Q, R = Fraction(1, 9), Fraction(1, 18), Fraction(-1, 36)
    L, t, dt = Fraction(0), Fraction(0), Fraction(1, 60)
    while L < 1:
        if L < Fraction(1, 3):
            rate = P
        elif L < Fraction(2, 3):
            rate = P + Q
        else:
            rate = Q + R
        L += rate * dt; t += dt
    return t
q("C07-B-036", T, "Pipes switched at one-third and two-thirds levels including an outlet", "Medium",
  "Multi-step word problem",
  r"Pipe P fills an empty tank in $9$ hours and pipe Q in $18$ hours; outlet R empties the full tank in $36$ hours. Starting with the empty tank, P alone runs until the tank is one-third full; then Q is also opened; when the tank is two-thirds full, P is closed and R is opened, while Q keeps running. How many hours after the start is the tank full?",
  "MCQ",
  r"First third at $\frac{1}{9}$ per hour: $3$ hours. Second third with P and Q at $\frac{1}{9} + \frac{1}{18} = \frac{1}{6}$: $2$ hours. Last third with Q and R at $\frac{1}{18} - \frac{1}{36} = \frac{1}{36}$: $12$ hours. Total $17$ hours.",
  "Mixing up which pipes run in which stage, or treating R as an inlet.",
  "C07B-staged-by-level", "Three short rate calculations switched by level; the trap is the slow final stage with the outlet.",
  correct=r"$17$ hours",
  distractors=[(r"$11$ hours", "Ignores R in the last stage: Q alone takes $6$ hours."),
               (r"$9$ hours", "Adds R's rate as if it were an inlet: $\\frac{1}{18} + \\frac{1}{36} = \\frac{1}{12}$, so the last third takes $4$ hours."),
               (r"$21$ hours", "Closes P at the one-third mark, so Q fills the middle third alone in $6$ hours: $3 + 6 + 12$.")],
  check=_c036, values=[17, 11, 9, 21], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 037
def _c037():
    # hours after Monday 0:00
    L, t, dt = Fraction(0), Fraction(6), Fraction(1, 60)
    while L < 1:
        h = t % 24
        supply = (6 <= h < 8) or (18 <= h < 20)
        L += ((Fraction(1, 4) if supply else 0) - Fraction(1, 36)) * dt
        L = max(L, Fraction(0))
        t += dt
    return t
q("C07-B-037", T, "Inlet available only in daily supply windows, continuous outflow", "Difficult",
  "Casework/optimisation",
  r"A municipal line supplies water to an apartment tank only from $6{:}00$ am to $8{:}00$ am and from $6{:}00$ pm to $8{:}00$ pm every day; during these hours it would fill the empty tank in $4$ hours if nothing were drawn. Residents draw water all day and night at a constant rate that would empty the full tank in $36$ hours. The tank is empty at $6{:}00$ am on Monday. When does it first become full?",
  "MCQ",
  r"During supply the net gain is $\frac{1}{4} - \frac{1}{36} = \frac{2}{9}$ per hour, so each window adds $\frac{4}{9} = \frac{8}{18}$; each $10$-hour gap loses $\frac{10}{36} = \frac{5}{18}$. In eighteenths the level runs $8, 3, 11, 6$ by $6{:}00$ am Tuesday, then $14, 9, 17$ at $8{:}00$ pm Tuesday (not yet full) and $12$ at $6{:}00$ am Wednesday. The last $\frac{6}{18} = \frac{1}{3}$ needs $\frac{1}{3} \div \frac{2}{9} = 1.5$ hours, so the tank is full at $7{:}30$ am on Wednesday.",
  "Forgetting the draw between windows or ignoring the end of a supply window.",
  "C07B-timed-supply-windows", "Tracking the level window by window with a continuous drain; the near miss on Tuesday evening is a trap.",
  correct=r"$7{:}30$ am on Wednesday",
  distractors=[(r"$6{:}30$ am on Tuesday", "Ignores the draw outside the supply windows."),
               (r"$7{:}20$ pm on Tuesday", "Ignores the draw during the supply windows, using $\\frac{1}{4}$ per hour then."),
               (r"$8{:}15$ pm on Tuesday", "At $6{:}00$ pm Tuesday the tank is half full; lets the supply run $2.25$ hours past the end of the window.")],
  check=_c037, values=[Rational(111, 2), Rational(61, 2), Rational(130, 3), Rational(177, 4)], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 038
def _c038():
    full = Fraction(1, 6) + Fraction(1, 12)
    t = _first_full([(full, 0, 2), (full * Fraction(3, 4), 2, None)])
    return t * 60
q("C07-B-038", T, "Both inlets slow down to a fraction of their rates midway", "Medium",
  "Multi-step word problem",
  r"Pipes P and Q can fill an empty tank in $6$ hours and $12$ hours respectively. Both are opened together on the empty tank. After $2$ hours a pressure drop makes each pipe deliver only three-fourths of its usual flow for the rest of the time. How long does it take to fill the tank in all?",
  "MCQ",
  r"Normally they fill $\frac{1}{6} + \frac{1}{12} = \frac{1}{4}$ per hour, so $2$ hours fill $\frac{1}{2}$. After the drop they fill $\frac{3}{4} \times \frac{1}{4} = \frac{3}{16}$ per hour, so the remaining $\frac{1}{2}$ takes $\frac{8}{3}$ hours $= 2$ hours $40$ minutes. Total $4$ hours $40$ minutes.",
  "Increasing the time by one-fourth instead of dividing by three-fourths.",
  "C07B-rate-change-midway", "Two stages; time scales by the reciprocal of the rate factor.",
  correct=r"$4$ hours $40$ minutes",
  distractors=[(r"$4$ hours", "Ignores the pressure drop."),
               (r"$5$ hours $20$ minutes", "Applies the drop from the start: $4 \\div \\frac{3}{4}$."),
               (r"$4$ hours $30$ minutes", "Increases the remaining $2$ hours by one-fourth, to $2.5$ hours, instead of dividing by $\\frac{3}{4}$.")],
  check=_c038, values=[280, 240, 320, 270], cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 039
def _c039():
    return int(_first_full([(Fraction(1, 12), 0, 3), (Fraction(1, 24), 3, None)]))
q("C07-B-039", T, "Pump runs at half rate after a fault", "Easy",
  "Multi-step word problem",
  r"A pump can fill an empty tank in $12$ hours. After running for $3$ hours on the empty tank it develops a fault, and from then on it works at half its usual rate. In how many hours from the start will the tank be full?",
  "TITA",
  r"In $3$ hours the pump fills $\frac{3}{12} = \frac{1}{4}$. At half rate it fills $\frac{1}{24}$ per hour, so the remaining $\frac{3}{4}$ takes $18$ hours. Total $3 + 18 = 21$ hours.",
  "Applying the half rate to the whole tank or reporting only the second stage.",
  "C07B-rate-change-midway", "Two stages with a changed rate.",
  tita_answer=21, check=_c039,
  tita_traps=[(24, "Uses the half rate for the whole tank."),
              (18, "Reports only the time after the fault.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- 040
def _c040():
    rates = [Fraction(1, 6), Fraction(1, 9), Fraction(1, 18)]
    cap = Fraction(3)
    # For total time Tt (in minutes), the pipes can run t_i <= min(3, Tt) with sum t_i <= 2*Tt
    # (two pipes at a time; such run times can always be scheduled). Fill greedily, fastest first.
    for m in range(1, 24 * 60):
        Tt = Fraction(m, 60)
        budget = 2 * Tt
        vol = Fraction(0)
        for r in rates:
            ti = min(cap, Tt, budget)
            vol += r * ti
            budget -= ti
        if vol >= 1:
            return m
q("C07-B-040", T, "Minimum filling time with a cap on each pipe's running time and on simultaneous pipes", "Difficult",
  "Casework/optimisation",
  r"Pipes P, Q and R can fill an empty tank in $6$ hours, $9$ hours and $18$ hours respectively. To protect the pumps, each pipe may run for at most $3$ hours in total (it may be switched on and off any number of times), and at most two pipes may run at the same time. What is the least time, in minutes, in which the empty tank can be filled?",
  "TITA",
  r"Running $3$ hours each, the pipes deliver $\frac{3}{6} + \frac{3}{9} + \frac{3}{18} = \frac{1}{2} + \frac{1}{3} + \frac{1}{6} = 1$ tank, exactly the capacity, so every pipe must run its full $3$ hours: $9$ pipe-hours in all. With at most two pipes at once, this needs at least $4.5$ hours. It can be done: P and Q for $1.5$ hours, P and R for $1.5$ hours, then Q and R for $1.5$ hours. Least time $4.5$ hours $= 270$ minutes.",
  "Running all three pipes together, or not using the two-at-a-time slots fully.",
  "C07B-constrained-scheduling", "An optimisation needing both a lower bound and a schedule that attains it.",
  tita_answer=270, check=_c040,
  tita_traps=[(180, "Runs all three pipes together for $3$ hours, breaking the two-at-a-time rule."),
              (360, "Runs P and Q together for $3$ hours, then R alone for $3$ hours.")],
  cognitive="Analysis", exams=HARD)
