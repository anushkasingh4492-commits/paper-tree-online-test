import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TP = "Population and depreciation"
TC = "Price, consumption and expenditure"
HARD = ("CAT", "XAT")


def _grow(p, rates):
    """Apply year-wise percentage changes (as Fractions of 100) one year at a time."""
    for r in rates:
        p = p * (1 + F(r) / 100)
    return p


# ================================================================ EASY (14)

def _c1():
    return _grow(62500, [8, -4])
q("C01-B-001", TP, "Population after two years with a rise in one year and a fall in the next", "Easy",
  "Single-step computation",
  r"The population of Rampur was $62{,}500$ at the start of 2023. It increased by $8\%$ during 2023 and decreased by $4\%$ during 2024, each change being on the population at the start of that year. What was the population of Rampur at the end of 2024?",
  "TITA",
  r"End of 2023: $62500 \times 1.08 = 67500$. End of 2024: $67500 \times 0.96 = 64800$.",
  r"Netting the two rates to a single $4\%$ rise and applying it to the starting population.",
  "C01B-pop-yearwise-forward", r"Two multiplications; the trap is netting $+8\%$ and $-4\%$ into $+4\%$.",
  tita_answer=64800, check=_c1,
  tita_traps=[(65000, r"Nets the rates to $+4\%$: $62500 \times 1.04 = 65000$."),
              (67500, r"Stops after the first year: $62500 \times 1.08 = 67500$.")],
  cognitive="Application")


def _c2():
    p = symbols('p', positive=True)
    return solve(Eq(p * F(11, 10) * F(11, 10), 145200), p)[0]
q("C01-B-002", TP, "Population two years ago from the present population and a constant growth rate", "Easy",
  "Single-step computation",
  r"The population of a town is $1{,}45{,}200$ today. It has grown by $10\%$ in each of the last two years, each year's growth being on the population at the start of that year. What was the population of the town two years ago?",
  "MCQ",
  r"If the population two years ago was $p$, then $p \times 1.1 \times 1.1 = 1.21p = 145200$, so $p = \frac{145200}{1.21} = 120000$.",
  "Subtracting percentages of the present population instead of dividing by the growth factor.",
  "C01B-pop-backward", r"One division by $1.21$; the trap is subtracting $20\%$ of today's figure or reducing it by $10\%$ twice.",
  correct=r"$1{,}20{,}000$",
  distractors=[(r"$1{,}16{,}160$", r"Subtracts $20\%$ of the present population: $145200 \times 0.8 = 116160$."),
               (r"$1{,}17{,}612$", r"Reduces the present population by $10\%$ twice: $145200 \times 0.9 \times 0.9 = 117612$."),
               (r"$1{,}21{,}000$", r"Treats the two years as a single $20\%$ rise: $145200 \div 1.2 = 121000$.")],
  check=_c2, values=[120000, 116160, 117612, 121000], cognitive="Application")


def _c3():
    p0 = 80000
    births = p0 * F(45, 1000)
    deaths = p0 * F(15, 1000)
    out = p0 * F(1, 100)
    return p0 + births - deaths - out
q("C01-B-003", TP, "Population after one year from births, deaths and out-migration rates", "Easy",
  "Single-step computation",
  r"At the start of a year the population of Sitapur was $80{,}000$. During the year, births equalled $4.5\%$ of this starting population, deaths equalled $1.5\%$ of it, and $1\%$ of it moved out of the town; nobody moved in. What was the population of Sitapur at the end of the year?",
  "TITA",
  r"Net change $= 4.5\% - 1.5\% - 1\% = 2\%$ of $80000$, that is $1600$. Population at the end of the year $= 80000 + 1600 = 81600$.",
  "Ignoring migration or treating it as an addition.",
  "C01B-pop-births-deaths-migration", "One net rate and one multiplication; the trap is the sign of each component.",
  tita_answer=81600, check=_c3,
  tita_traps=[(82400, r"Ignores the $1\%$ who moved out: $80000 \times 1.03 = 82400$."),
              (83200, r"Adds the $1\%$ migration instead of subtracting it: $80000 \times 1.04 = 83200$.")],
  cognitive="Application")


def _c4():
    v = 250000
    for _ in range(3):
        v -= v * F(20, 100)
    return v
q("C01-B-004", TP, "Value of a machine after three years of reducing-balance depreciation", "Easy",
  "Single-step computation",
  r"A printing machine is bought for Rs. $2{,}50{,}000$. Each year its value falls by $20\%$ of its value at the start of that year. What is its value at the end of $3$ years?",
  "MCQ",
  r"Value $= 250000 \times 0.8^3 = 250000 \times 0.512 = 128000$, that is Rs. $1{,}28{,}000$.",
  r"Charging $20\%$ of the purchase price every year (straight-line) or miscounting the years.",
  "C01B-depreciation-forward", "One power and one multiplication; the trap is straight-line thinking.",
  correct=r"Rs. $1{,}28{,}000$",
  distractors=[(r"Rs. $1{,}00{,}000$", r"Takes $20\%$ of the purchase price each year: $250000 \times (1 - 0.6) = 100000$."),
               (r"Rs. $1{,}60{,}000$", r"Applies only two years of depreciation: $250000 \times 0.64 = 160000$."),
               (r"Rs. $1{,}02{,}400$", r"Applies four years of depreciation: $250000 \times 0.4096 = 102400$.")],
  check=_c4, values=[128000, 100000, 160000, 102400], cognitive="Application")


def _c5():
    v = 800000
    deps = []
    for _ in range(3):
        d = v * F(15, 100)
        deps.append(d)
        v -= d
    return deps[2]
q("C01-B-005", TP, "Amount of depreciation charged in a particular year", "Easy",
  "Multi-step word problem",
  r"A car is bought for Rs. $8{,}00{,}000$. Each year its value falls by $15\%$ of its value at the start of that year. By how much does its value fall during the third year?",
  "MCQ",
  r"Value at the start of the third year $= 800000 \times 0.85^2 = 800000 \times 0.7225 = 578000$. The fall during the third year is $15\%$ of this: $0.15 \times 578000 = 86700$, that is Rs. $86{,}700$.",
  r"Taking $15\%$ of the wrong year's opening value.",
  "C01B-depreciation-yearly-amount", "Needs the opening value of the third year, then one percentage.",
  correct=r"Rs. $86{,}700$",
  distractors=[(r"Rs. $1{,}20{,}000$", r"Takes $15\%$ of the purchase price: $0.15 \times 800000$."),
               (r"Rs. $1{,}02{,}000$", r"Uses the opening value of the second year: $0.15 \times 680000$."),
               (r"Rs. $73{,}695$", r"Uses the value at the end of the third year: $0.15 \times 491300$.")],
  check=_c5, values=[86700, 120000, 102000, 73695], cognitive="Application")


def _c6():
    p = symbols('p', positive=True)
    start24 = solve(Eq(p * F(8, 100), 4000), p)[0]
    start25 = start24 * F(108, 100)
    return start25 * F(8, 100)
q("C01-B-006", TP, "Next year's increase in population from this year's increase at a constant growth rate", "Easy",
  "Conceptual/application",
  r"The population of a town grows by $8\%$ every year, each year's growth being on the population at the start of that year. During 2024 the population of the town increased by $4{,}000$. By how many people did it increase during 2025?",
  "MCQ",
  r"The 2024 increase is $8\%$ of the population at the start of 2024, so that population was $\frac{4000}{0.08} = 50000$. The population at the start of 2025 was $54000$, and $8\%$ of it is $4320$. Quick route: each year's increase is $1.08$ times the previous year's, so $4000 \times 1.08 = 4320$.",
  "Assuming the yearly increase stays the same when the rate is constant.",
  "C01B-pop-yearly-increase", r"One idea: with a constant rate the increase itself grows by $8\%$; the trap is keeping it at $4000$.",
  correct=r"$4{,}320$",
  distractors=[(r"$4{,}000$", r"Assumes a constant rate gives the same increase every year, as in straight-line growth."),
               (r"$8{,}320$", r"Reports the total increase over 2024 and 2025: $4000 + 4320$."),
               (r"$320$", r"Reports only how much larger the 2025 increase is than the 2024 increase: $0.08 \times 4000$.")],
  check=_c6, values=[4320, 4000, 8320, 320], cognitive="Understanding")


def _c7():
    r = symbols('r', positive=True)
    after1 = 40000 * F(125, 100)
    return solve(Eq(after1 * (1 + r / 100), 54000), r)[0]
q("C01-B-007", TP, "Second-year growth rate from the populations at the start and the end", "Easy",
  "Inverse/parameter",
  r"The population of a town was $40{,}000$ at the start of 2024. It increased by $25\%$ during 2024, and at the end of 2025 it was $54{,}000$. By what percent did the population increase during 2025? Enter the number only.",
  "TITA",
  r"At the end of 2024 the population was $40000 \times 1.25 = 50000$. The rise in 2025 was $54000 - 50000 = 4000$ on a base of $50000$, that is $8\%$.",
  "Measuring the 2025 increase against the 2024 starting population.",
  "C01B-pop-unknown-year-rate", "One forward step and one percentage; the trap is the base.",
  tita_answer=8, check=_c7,
  tita_traps=[(10, r"Divides the 2025 increase by the 2024 starting population: $\frac{4000}{40000}$."),
              (35, r"Reports the overall two-year increase $\frac{14000}{40000}$.")],
  cognitive="Application")


def _c8():
    r = symbols('r', positive=True)
    sol = solve(Eq(625000 * (1 - r / 100) ** 2, 400000), r)
    return [s for s in sol if 0 < s < 100][0]
q("C01-B-008", TP, "Constant annual depreciation rate from purchase price and value after two years", "Easy",
  "Inverse/parameter",
  r"A tractor bought for Rs. $6{,}25{,}000$ is worth Rs. $4{,}00{,}000$ after $2$ years. Each year its value fell by the same percentage of its value at the start of that year. What is that annual percentage?",
  "MCQ",
  r"$\left(1 - \frac{r}{100}\right)^2 = \frac{400000}{625000} = 0.64$, so $1 - \frac{r}{100} = 0.8$ and $r = 20$. The annual rate is $20\%$.",
  "Splitting the total fall equally between the two years.",
  "C01B-depreciation-find-rate-or-cost", r"One square root; the trap is dividing the $36\%$ total fall by two.",
  correct=r"$20\%$",
  distractors=[(r"$18\%$", r"Halves the total fall: $\frac{36\%}{2} = 18\%$."),
               (r"$36\%$", r"Reports the total fall over two years, $1 - 0.64$."),
               (r"$25\%$", r"Inverts the ratio, $\sqrt{\frac{625000}{400000}} = 1.25$, and reports $25\%$, measuring each year's fall against the end-of-year value.")],
  check=_c8, values=[20, 18, 36, 25], cognitive="Application")


def _c9():
    v = 120000
    total = 0
    for _ in range(3):
        d = v * F(10, 100)
        total += d
        v -= d
    return total
q("C01-B-009", TP, "Total depreciation over three years on a reducing balance", "Easy",
  "Multi-step word problem",
  r"A scooter costs Rs. $1{,}20{,}000$. Each year its value falls by $10\%$ of its value at the start of that year. What is the total fall in its value over the first $3$ years?",
  "MCQ",
  r"Value after $3$ years $= 120000 \times 0.9^3 = 120000 \times 0.729 = 87480$. Total fall $= 120000 - 87480 = 32520$, that is Rs. $32{,}520$.",
  r"Taking $10\%$ of the cost each year, or reporting the remaining value.",
  "C01B-depreciation-forward", "One power and one subtraction; the trap is straight-line depreciation.",
  correct=r"Rs. $32{,}520$",
  distractors=[(r"Rs. $36{,}000$", r"Takes $10\%$ of the cost each year: $3 \times 12000$."),
               (r"Rs. $9{,}720$", r"Gives only the third year's fall: $0.1 \times 97200$."),
               (r"Rs. $87{,}480$", r"Reports the value left after $3$ years.")],
  check=_c9, values=[32520, 36000, 9720, 87480], cognitive="Application")


def _c10():
    c = symbols('c', positive=True)
    # expenditure unchanged: 160 * 1 = 200 * c
    cnew = solve(Eq(200 * c, 160), c)[0]
    return (1 - cnew) * 100
q("C01-B-010", TC, "Cut in consumption that keeps expenditure unchanged after a price rise", "Easy",
  "Conceptual/application",
  r"The price of cooking oil rises from Rs. $160$ to Rs. $200$ per litre. By what percent must a family reduce its monthly consumption of oil so that its monthly expenditure on oil does not change? Enter the number only.",
  "TITA",
  r"Expenditure $=$ price $\times$ consumption, so consumption must fall to $\frac{160}{200} = 0.8$ of its old level, a reduction of $20\%$. (Quick rule: a rise of $25\%$ needs a cut of $\frac{25}{125} = 20\%$.)",
  "Cutting consumption by the same percentage as the price rise.",
  "C01B-constant-expenditure-cut", r"One ratio; the trap is using the $25\%$ price rise as the cut.",
  tita_answer=20, check=_c10,
  tita_traps=[(25, r"Cuts consumption by the price-rise percentage $\frac{40}{160} = 25\%$."),
              (80, r"Reports the new consumption level as a percentage of the old one.")],
  cognitive="Understanding")


def _c11():
    return 4500 * F(120, 100) * F(90, 100)
q("C01-B-011", TC, "New monthly bill when price rises and consumption falls", "Easy",
  "Multi-step word problem",
  r"Meera's monthly petrol bill is Rs. $4{,}500$. The price of petrol rises by $20\%$ and she reduces the quantity of petrol she buys each month by $10\%$. What is her new monthly petrol bill?",
  "MCQ",
  r"New bill $= 4500 \times 1.2 \times 0.9 = 4500 \times 1.08 = 4860$, that is Rs. $4{,}860$.",
  "Adding the two percentage changes, or ignoring one of them.",
  "C01B-expenditure-price-and-consumption", r"Two factors multiplied; the trap is netting $+20\%$ and $-10\%$ to $+10\%$.",
  correct=r"Rs. $4{,}860$",
  distractors=[(r"Rs. $4{,}950$", r"Nets the changes to $+10\%$: $4500 \times 1.1$."),
               (r"Rs. $5{,}400$", r"Ignores the cut in quantity: $4500 \times 1.2$."),
               (r"Rs. $5{,}040$", r"Uses $1 + 0.2 - 0.1 + 0.02 = 1.12$, adding the product term instead of subtracting it.")],
  check=_c11, values=[4860, 4950, 5400, 5040], cognitive="Application")


def _c12():
    l, b = 40, 25
    a0 = l * b
    a1 = (l * F(125, 100)) * (b * F(88, 100))
    return (a1 - a0) / a0 * 100
q("C01-B-012", TC, "Percentage change in the area of a rectangle when one side grows and the other shrinks", "Easy",
  "Single-step computation",
  r"A rectangular plot measures $40$ m by $25$ m. Its length is increased by $25\%$ and its breadth is decreased by $12\%$. What is the percentage change in its area?",
  "MCQ",
  r"New area factor $= 1.25 \times 0.88 = 1.10$. (Check: new plot is $50$ m by $22$ m $= 1100$ m$^2$ against $1000$ m$^2$.) The area increases by $10\%$.",
  "Adding the percentage changes or mishandling the product term.",
  "C01B-area-change-dimensions", "One product of two factors; the trap is $25 - 12 = 13$.",
  correct=r"$10\%$ increase",
  distractors=[(r"$13\%$ increase", r"Adds the changes: $25 - 12 = 13$."),
               (r"$16\%$ increase", r"Uses $25 - 12 + \frac{25 \times 12}{100} = 16$, with the wrong sign on the product term."),
               (r"$37\%$ increase", r"Treats both changes as increases: $25 + 12$.")],
  check=_c12, values=[10, 13, 16, 37], cognitive="Application")


def _c13():
    p = symbols('p', positive=True)
    return solve(Eq(1200 / (p * F(3, 4)) - 1200 / p, 5), p)[0]
q("C01-B-013", TC, "Original price per kg from the extra quantity a fixed sum buys after a price cut", "Easy",
  "Multi-step word problem",
  r"After a $25\%$ fall in the price of rice, Fatima finds that Rs. $1{,}200$ buys $5$ kg more rice than before. What was the original price of rice per kg?",
  "MCQ",
  r"The saving is $25\%$ of Rs. $1200 =$ Rs. $300$, and this buys the extra $5$ kg at the new price, so the new price is Rs. $60$ per kg. The original price is $60 \div 0.75 =$ Rs. $80$ per kg. (Check: $1200 \div 80 = 15$ kg, $1200 \div 60 = 20$ kg.)",
  "Reporting the new price as the original one.",
  "C01B-price-change-extra-quantity", "Two short steps; the trap is stopping at the new price.",
  correct=r"Rs. $80$",
  distractors=[(r"Rs. $60$", r"Reports the new price $\frac{300}{5}$."),
               (r"Rs. $75$", r"Raises the new price by $25\%$: $60 \times 1.25$."),
               (r"Rs. $45$", r"Cuts the new price by a further $25\%$: $60 \times 0.75$.")],
  check=_c13, values=[80, 60, 75, 45], cognitive="Application")


def _c14():
    r, h = symbols('r h', positive=True)
    v0 = pi * r**2 * h
    v1 = pi * (F(6, 5) * r)**2 * (F(3, 4) * h)
    return simplify((v1 - v0) / v0 * 100)
q("C01-B-014", TC, "Percentage change in the volume of a cylinder when radius and height change", "Easy",
  "Conceptual/application",
  r"The radius of a cylindrical water tank is increased by $20\%$ and its height is decreased by $25\%$. What is the percentage change in its capacity?",
  "MCQ",
  r"Volume is proportional to $r^2 h$, so the factor is $1.2^2 \times 0.75 = 1.44 \times 0.75 = 1.08$. The capacity increases by $8\%$.",
  "Treating the radius as entering the volume linearly.",
  "C01B-volume-change-dimensions", "One idea (radius is squared) and one product.",
  correct=r"$8\%$ increase",
  distractors=[(r"$10\%$ decrease", r"Uses the radius linearly: $1.2 \times 0.75 = 0.9$."),
               (r"$15\%$ increase", r"Doubles the radius change and subtracts the height change: $40 - 25$."),
               (r"$44\%$ increase", r"Ignores the change in height: $1.2^2 = 1.44$.")],
  check=_c14, values=[8, -10, 15, 44], cognitive="Understanding")


# ================================================================ MEDIUM (20)

def _c15():
    return _grow(50000, [5, -10, 20])
q("C01-B-015", TP, "Population after three years with year-wise rates including a decline", "Medium",
  "Multi-step word problem",
  r"The population of Kalyanpur was $50{,}000$ at the start of 2023. It increased by $5\%$ in 2023, decreased by $10\%$ in 2024 and increased by $20\%$ in 2025, each change being on the population at the start of that year. What was the population at the end of 2025?",
  "MCQ",
  r"Population $= 50000 \times 1.05 \times 0.9 \times 1.2$. Step by step: $52500$, then $47250$, then $56700$.",
  "Adding the year-wise rates, or applying a later rate to the original population.",
  "C01B-pop-yearwise-forward", "Three successive factors, one a decrease; adding the rates gives a listed value.",
  correct=r"$56{,}700$",
  distractors=[(r"$57{,}500$", r"Adds the rates to $+15\%$: $50000 \times 1.15$."),
               (r"$57{,}000$", r"Takes the 2024 fall as $10\%$ of $50000$: $(52500 - 5000) \times 1.2$."),
               (r"$47{,}250$", r"Stops at the end of 2024.")],
  check=_c15, values=[56700, 57500, 57000, 47250], cognitive="Application")


def _c16():
    p = symbols('p', positive=True)
    return solve(Eq(p * F(12, 10) * F(9, 10) * F(11, 10), 118800), p)[0]
q("C01-B-016", TP, "Population three years earlier from year-wise rates and today's figure", "Medium",
  "Multi-step word problem",
  r"The population of a town at the end of 2025 was $1{,}18{,}800$. During 2023 it rose by $20\%$, during 2024 it fell by $10\%$ and during 2025 it rose by $10\%$, each change being on the population at the start of that year. What was the population at the start of 2023?",
  "MCQ",
  r"Overall factor $= 1.2 \times 0.9 \times 1.1 = 1.188$. So the population at the start of 2023 was $\frac{118800}{1.188} = 100000$, that is $1{,}00{,}000$.",
  "Netting the rates, or subtracting a percentage of the final figure instead of dividing.",
  "C01B-pop-backward", "Undoing three factors; the shortcut of netting the rates gives a close wrong value.",
  correct=r"$1{,}00{,}000$",
  distractors=[(r"$99{,}000$", r"Nets the rates to $+20\%$ and divides: $118800 \div 1.2$."),
               (r"$95{,}040$", r"Nets the rates to $+20\%$ and subtracts $20\%$ of the final figure: $118800 \times 0.8$."),
               (r"$1{,}08{,}000$", r"Undoes only the 2025 change: $118800 \div 1.1$.")],
  check=_c16, values=[100000, 99000, 95040, 108000], cognitive="Application")


def _c17():
    p = symbols('p', positive=True)
    end = p + p * F(3, 100) - p * F(125, 10000) - p * F(2, 100) + 6000
    return solve(Eq(end, 245400), p)[0]
q("C01-B-017", TP, "Starting population from the year-end figure with births, deaths and migration", "Medium",
  "Inverse/parameter",
  r"During a year, births in a town equalled $3\%$ of its population at the start of the year, deaths equalled $1.25\%$ of it, and $2\%$ of it moved away. In the same year $6{,}000$ people moved into the town. The population at the end of the year was $2{,}45{,}400$. What was the population at the start of the year?",
  "TITA",
  r"Let the starting population be $p$. The percentage changes give a net factor $1 + 0.03 - 0.0125 - 0.02 = 0.9975$, so $0.9975p + 6000 = 245400$. Then $0.9975p = 239400$ and $p = 240000$.",
  "Removing the newcomers but not undoing the percentage changes.",
  "C01B-pop-births-deaths-migration", "Mixes percentage changes with an absolute inflow and runs the model backwards.",
  tita_answer=240000, check=_c17,
  tita_traps=[(239400, r"Subtracts the $6000$ newcomers but does not divide by the net factor $0.9975$.")],
  cognitive="Application")


def _c18():
    return _grow(1000000, [-20, -15, -10, -10])
q("C01-B-018", TP, "Value of a vehicle after four years with different depreciation rates in different years", "Medium",
  "Multi-step word problem",
  r"A delivery van is bought for Rs. $10{,}00{,}000$. Its value falls by $20\%$ in the first year, by $15\%$ in the second year and by $10\%$ in every year after that, each fall being on its value at the start of that year. What is its value at the end of $4$ years?",
  "MCQ",
  r"Value $= 1000000 \times 0.8 \times 0.85 \times 0.9 \times 0.9$. Step by step: $800000$, $680000$, $612000$, $550800$, that is Rs. $5{,}50{,}800$.",
  r"Adding the rates, or misreading which years use the $10\%$ rate.",
  "C01B-depreciation-forward", "Four year-wise factors; the phrase 'every year after that' must be read correctly.",
  correct=r"Rs. $5{,}50{,}800$",
  distractors=[(r"Rs. $4{,}50{,}000$", r"Adds the rates to $55\%$ of the cost: $1000000 \times 0.45$."),
               (r"Rs. $6{,}12{,}000$", r"Applies the $10\%$ rate only once, giving the value after $3$ years."),
               (r"Rs. $5{,}83{,}200$", r"Uses $10\%$ from the second year on: $1000000 \times 0.8 \times 0.9^3$.")],
  check=_c18, values=[550800, 450000, 612000, 583200], cognitive="Application")


def _c19():
    p = symbols('p', positive=True)
    return solve(Eq(p * F(9, 10) * F(8, 10) * F(8, 10), 288000), p)[0]
q("C01-B-019", TP, "Purchase price of a machine from its value after three years", "Medium",
  "Inverse/parameter",
  r"A lathe loses $10\%$ of its value in its first year and $20\%$ of its value in every later year, each loss being on its value at the start of that year. After $3$ years it is worth Rs. $2{,}88{,}000$. What was its purchase price, in rupees?",
  "TITA",
  r"Value after $3$ years $= P \times 0.9 \times 0.8 \times 0.8 = 0.576P$. So $0.576P = 288000$ and $P = 500000$. The purchase price was Rs. $5{,}00{,}000$.",
  r"Adding the yearly rates to a single $50\%$ loss.",
  "C01B-depreciation-find-rate-or-cost", "Builds a three-factor product and divides; adding rates gives a tempting value.",
  tita_answer=500000, check=_c19,
  tita_traps=[(576000, r"Adds the rates to a $50\%$ loss: $288000 \div 0.5$."),
              (432000, r"Adds $50\%$ back to the final value: $288000 \times 1.5$.")],
  cognitive="Application")


def _c20():
    v, n = F(1), 0
    while v >= F(1, 2):
        v *= F(85, 100)
        n += 1
    return n
q("C01-B-020", TP, "Number of years for a depreciating asset to fall below half its cost", "Medium",
  "Casework/optimisation",
  r"Each year a printing press loses $15\%$ of its value at the start of that year. After how many complete years will its value first be less than half of its purchase price?",
  "TITA",
  r"We need the smallest $n$ with $0.85^n < 0.5$. $0.85^2 = 0.7225$, $0.85^3 \approx 0.614$, $0.85^4 \approx 0.522$, $0.85^5 \approx 0.444$. So the value first drops below half after $5$ years.",
  "Using straight-line depreciation, which reaches half the cost sooner.",
  "C01B-depreciation-years-threshold", "Year-by-year powers with a near miss at $n = 4$ ($0.522$).",
  tita_answer=5, check=_c20,
  tita_traps=[(4, r"Uses $15\%$ of the cost each year: $4 \times 15 = 60 > 50$; also tempting because $0.85^4 \approx 0.52$ is close to half.")],
  cognitive="Analysis")


def _c21():
    p = symbols('p', positive=True)
    r = symbols('r', positive=True)
    # depreciation in year 2 and year 3 at a constant rate r (fraction)
    sol = solve([Eq(p * (1 - r) * r, 48000), Eq(p * (1 - r)**2 * r, 38400)], [p, r], dict=True)
    return [s[p] for s in sol if 0 < s[r] < 1][0]
q("C01-B-021", TP, "Purchase price from the depreciation amounts of two consecutive years", "Medium",
  "Inverse/parameter",
  r"A machine loses the same percentage of its value every year, each loss being on its value at the start of that year. Its value falls by Rs. $48{,}000$ during the second year and by Rs. $38{,}400$ during the third year. What was its purchase price?",
  "MCQ",
  r"The third year's loss is the second year's loss scaled by the retention factor, so the factor is $\frac{38400}{48000} = 0.8$ and the rate is $20\%$. The second year's loss is $20\%$ of the value at the start of the second year, so that value is $\frac{48000}{0.2} = 240000$. Purchase price $= \frac{240000}{0.8} = 300000$, that is Rs. $3{,}00{,}000$.",
  "Treating the second year's loss as the first year's, or undoing a fall by adding a percentage.",
  "C01B-depreciation-yearly-amount", "Needs the rate from the ratio of losses, then two backward steps.",
  correct=r"Rs. $3{,}00{,}000$",
  distractors=[(r"Rs. $2{,}40{,}000$", r"Treats Rs. $48000$ as the first year's loss: $48000 \div 0.2$, which is the value at the start of the second year."),
               (r"Rs. $3{,}75{,}000$", r"Treats Rs. $48000$ as the third year's loss: $48000 \div (0.8^2 \times 0.2)$."),
               (r"Rs. $2{,}88{,}000$", r"Undoes the first year by adding $20\%$: $240000 \times 1.2$.")],
  check=_c21, values=[300000, 240000, 375000, 288000], cognitive="Analysis")


def _c22():
    p0 = F(100000)  # any starting population; the answer does not depend on it
    old_inc = p0 * F(4, 100) - p0 * F(15, 1000)
    new_inc = p0 * F(35, 1000) - p0 * F(12, 1000)
    return (old_inc - new_inc) / old_inc * 100
q("C01-B-022", TP, "Percentage fall in the natural increase when birth and death rates both change", "Medium",
  "Conceptual/application",
  r"In a town, births in a year equal $4\%$ of the population at the start of the year and deaths equal $1.5\%$ of it. After a health campaign, births fall to $3.5\%$ and deaths fall to $1.2\%$ of the population at the start of the year. For the same starting population, by what percent does the yearly natural increase (births minus deaths) fall?",
  "MCQ",
  r"The natural increase was $4 - 1.5 = 2.5\%$ of the starting population and becomes $3.5 - 1.2 = 2.3\%$ of it. It falls by $0.2$ percentage points, which is $\frac{0.2}{2.5} \times 100 = 8\%$ of the old increase.",
  "Reporting the fall in percentage points as a percent, or treating fewer deaths as a further cut in growth.",
  "C01B-birth-death-rate-change", "Two rate changes netted, then a fall in percentage points converted to a percent of the old net rate.",
  correct=r"$8\%$",
  distractors=[(r"$0.2\%$", r"Reports the fall of $0.2$ percentage points in the net rate as a percent."),
               (r"$20\%$", r"Ignores the fall in deaths: $\frac{0.5}{2.5} \times 100$."),
               (r"$32\%$", r"Treats the fall in deaths as also cutting the increase: $\frac{0.5 + 0.3}{2.5} \times 100$.")],
  check=_c22, values=[8, F(2, 10), 20, 32], cognitive="Analysis")


def _c23():
    p = F(80000)
    p = p + p * F(4, 100) - p * F(15, 1000)          # 2024
    births25 = F(4, 100) * F(125, 100)                # 25% higher birth rate
    deaths25 = F(15, 1000) - F(5, 1000)               # 0.5 percentage points lower
    return p + p * births25 - p * deaths25            # 2025
q("C01-B-023", TP, "Population after two years when the birth rate rises by a percent and the death rate falls by percentage points", "Medium",
  "Multi-step word problem",
  r"The population of Nandgaon was $80{,}000$ at the start of 2024. In 2024, births equalled $4\%$ and deaths equalled $1.5\%$ of the population at the start of the year. In 2025, the birth rate was $25\%$ higher than in 2024 and the death rate was $0.5$ percentage points lower than in 2024, both again measured on the population at the start of the year. Nobody moved in or out. What was the population at the end of 2025?",
  "MCQ",
  r"In 2024 the net rate is $4 - 1.5 = 2.5\%$, so the population becomes $80000 \times 1.025 = 82000$. In 2025 the birth rate is $4 \times 1.25 = 5\%$ and the death rate is $1.5 - 0.5 = 1\%$, a net rate of $4\%$. End of 2025: $82000 \times 1.04 = 85280$.",
  r"Confusing a $25\%$ rise in a rate with a rise in percentage points, or applying the 2025 rate to the 2024 starting population.",
  "C01B-birth-death-rate-change", "Two years with different net rates; percent versus percentage-point changes in the rates must be read correctly.",
  correct=r"$85{,}280$",
  distractors=[(r"$85{,}200$", r"Applies both years' net rates to the 2024 starting population: $80000 \times (1 + 0.025 + 0.04)$."),
               (r"$84{,}870$", r"Ignores the fall in the death rate: net $5 - 1.5 = 3.5\%$, so $82000 \times 1.035$."),
               (r"$84{,}665$", r"Reads the $25\%$ rise in the birth rate as $0.25$ percentage points: net $4.25 - 1 = 3.25\%$, so $82000 \times 1.0325$.")],
  check=_c23, values=[85280, 85200, 84870, 84665], cognitive="Application")


def _c24():
    p, qq = F(120000), F(80000)
    for _ in range(2):
        p *= F(9, 10)
        qq *= F(12, 10)
    return qq - p
q("C01-B-024", TP, "Gap between two towns after two years of opposite growth trends", "Medium",
  "Multi-step word problem",
  r"Town P has $1{,}20{,}000$ people and its population falls by $10\%$ every year. Town Q has $80{,}000$ people and its population rises by $20\%$ every year. Each change is on the population at the start of that year. After $2$ years, by how many people does the population of Q exceed that of P?",
  "TITA",
  r"P after $2$ years: $120000 \times 0.81 = 97200$. Q after $2$ years: $80000 \times 1.44 = 115200$. Q exceeds P by $115200 - 97200 = 18000$.",
  "Applying the rates to the original populations every year.",
  "C01B-pop-yearwise-forward", "Two compounded populations compared; straight-line growth gives a close wrong value.",
  tita_answer=18000, check=_c24,
  tita_traps=[(16000, r"Applies the rates to the original figures each year: $112000 - 96000$.")],
  cognitive="Application")


def _c25():
    q0 = symbols('q0', positive=True)
    p2 = 45000 * F(6, 5)**2
    return solve(Eq(q0 * F(9, 10)**2, p2), q0)[0]
q("C01-B-025", TP, "Initial population of a declining town that is overtaken by a growing town", "Medium",
  "Inverse/parameter",
  r"Town P has $45{,}000$ people and grows by $20\%$ every year. Town R shrinks by $10\%$ every year. Each change is on the population at the start of that year. After exactly $2$ years the two towns have equal populations. What is the present population of R?",
  "MCQ",
  r"After $2$ years P has $45000 \times 1.44 = 64800$. So R's population $x$ satisfies $0.81x = 64800$, giving $x = 80000$, that is $80{,}000$.",
  "Combining the two yearly falls into one, or undoing a fall by adding a percentage.",
  "C01B-two-towns-equalise", "Forward for one town and backward for the other; several shortcuts give listed values.",
  correct=r"$80{,}000$",
  distractors=[(r"$81{,}000$", r"Treats two $10\%$ falls as a single $20\%$ fall: $64800 \div 0.8$."),
               (r"$72{,}000$", r"Undoes only one year of decline: $64800 \div 0.9$."),
               (r"$78{,}408$", r"Undoes each fall by adding $10\%$: $64800 \times 1.1^2$.")],
  check=_c25, values=[80000, 81000, 72000, 78408], cognitive="Application")


def _c26():
    c = symbols('c', positive=True)
    price = F(120, 100) * F(125, 100)
    cnew = solve(Eq(price * c, F(114, 100)), c)[0]
    return (1 - cnew) * 100
q("C01-B-026", TC, "Consumption cut after two successive price rises when expenditure may rise only partly", "Medium",
  "Inverse/parameter",
  r"The price of cooking gas rises by $20\%$, and a few months later it rises by a further $25\%$ on the raised price. A household decides that its monthly expenditure on gas will be exactly $14\%$ higher than it was before the first rise. By what percent must it reduce its monthly consumption of gas, compared with its consumption before the first rise? Enter the number only.",
  "TITA",
  r"The price factor is $1.2 \times 1.25 = 1.5$. Expenditure factor $=$ price factor $\times$ consumption factor, so $1.5 \times c = 1.14$, giving $c = 0.76$. Consumption must fall by $24\%$.",
  "Adding the two price rises and then subtracting the allowed rise in expenditure.",
  "C01B-expenditure-target-consumption", r"Two steps: combine the two price rises into one factor, then divide; the additive shortcut gives $31$.",
  tita_answer=24, check=_c26,
  tita_traps=[(31, r"Adds the price rises and subtracts the allowed rise: $20 + 25 - 14$."),
              (76, r"Reports the new consumption level as a percentage of the old one.")],
  cognitive="Application")


def _c27():
    u = symbols('u', positive=True)
    p0 = symbols('p0', positive=True)
    sol = solve(Eq(p0 * F(3, 4) * u, F(9, 10) * p0 * 240), u)
    return sol[0]
q("C01-B-027", TC, "New consumption in units when the tariff falls and the bill falls less", "Medium",
  "Inverse/parameter",
  r"Arjun's household used $240$ units of electricity a month. The tariff per unit was then cut by $25\%$, and the household's monthly electricity bill fell by $10\%$. How many units a month does the household now use?",
  "MCQ",
  r"Bill $=$ tariff $\times$ units, so $0.75 \times u = 0.9 \times 240$, giving $u = \frac{216}{0.75} = 288$ units.",
  "Subtracting percentages, or assuming the bill stayed the same.",
  "C01B-expenditure-target-consumption", "Recognising that both factors change; subtraction shortcuts give listed values.",
  correct=r"$288$ units",
  distractors=[(r"$276$ units", r"Raises usage by $25 - 10 = 15\%$: $240 \times 1.15$."),
               (r"$320$ units", r"Keeps the bill unchanged: $240 \div 0.75$."),
               (r"$270$ units", r"Multiplies by $1.25$ to undo the tariff cut: $240 \times 1.25 \times 0.9$.")],
  check=_c27, values=[288, 276, 320, 270], cognitive="Application")


def _c28():
    students, price, per_head = F(120, 100), F(125, 100), F(80, 100)
    return 300000 * students * price * per_head
q("C01-B-028", TC, "Hostel food bill when the number of consumers, price and per-head consumption all change", "Medium",
  "Multi-step word problem",
  r"A hostel's monthly food bill is Rs. $3{,}00{,}000$. The number of students rises by $20\%$, the price of food rises by $25\%$, and the food served to each student is reduced by $20\%$. What is the new monthly food bill?",
  "MCQ",
  r"Bill $=$ students $\times$ quantity per student $\times$ price. New bill $= 300000 \times 1.2 \times 0.8 \times 1.25 = 300000 \times 1.2 = 360000$, that is Rs. $3{,}60{,}000$.",
  "Adding the three percentage changes, or leaving out one factor.",
  "C01B-consumers-per-head-expenditure", "Three factors; the price rise and the per-head cut cancel, which is easy to miss.",
  correct=r"Rs. $3{,}60{,}000$",
  distractors=[(r"Rs. $3{,}75{,}000$", r"Adds the changes: $20 + 25 - 20 = 25\%$."),
               (r"Rs. $3{,}00{,}000$", r"Ignores the rise in the number of students: $1.25 \times 0.8 = 1$."),
               (r"Rs. $4{,}50{,}000$", r"Ignores the cut per student: $300000 \times 1.2 \times 1.25$.")],
  check=_c28, values=[360000, 375000, 300000, 450000], cognitive="Application")


def _c29():
    c = symbols('c', positive=True)
    cnew = solve(Eq(F(5, 4) * F(6, 5) * c, F(105, 100)), c)[0]
    return (1 - cnew) * 100
q("C01-B-029", TC, "Per-person cut needed when family size and price both rise and the budget may rise a little", "Medium",
  "Inverse/parameter",
  r"Kabir's family of $4$ becomes a family of $5$, and the price of milk rises by $20\%$. The family wants its monthly expenditure on milk to rise by exactly $5\%$. By what percent must the milk consumed per person be reduced? Enter the number only.",
  "TITA",
  r"Expenditure $=$ members $\times$ consumption per person $\times$ price. So $\frac{5}{4} \times c \times 1.2 = 1.05$, that is $1.5c = 1.05$ and $c = 0.7$. Consumption per person must fall by $30\%$.",
  "Adding and subtracting the percentage changes.",
  "C01B-consumers-per-head-expenditure", "Three factors with an inverse step; the additive shortcut gives $40$.",
  tita_answer=30, check=_c29,
  tita_traps=[(40, r"Uses $25 + 20 - 5 = 40$."),
              (70, r"Reports the new per-person level as a percentage of the old one.")],
  cognitive="Application")


def _c30():
    p = symbols('p', positive=True)
    price = solve(Eq(1800 / p - 1800 / (p * F(5, 4)), 3), p)[0]
    return 1800 / price
q("C01-B-030", TC, "Original quantity bought for a fixed sum when a price rise reduces it by a known amount", "Medium",
  "Multi-step word problem",
  r"After a $25\%$ rise in the price of apples, Rs. $1{,}800$ buys $3$ kg fewer apples than before. How many kg of apples did Rs. $1{,}800$ buy before the rise?",
  "TITA",
  r"For a fixed sum, quantity is inversely proportional to price, so the new quantity is $\frac{1}{1.25} = 0.8$ of the old. The drop is $20\%$ of the old quantity, so $0.2Q = 3$ and $Q = 15$ kg. (Prices: Rs. $120$ then Rs. $150$ per kg.)",
  r"Taking the $3$ kg drop as $25\%$ of the original quantity.",
  "C01B-price-change-extra-quantity", r"Uses the inverse relation between price and quantity; the $25\%$ shortcut gives the new quantity.",
  tita_answer=15, check=_c30,
  tita_traps=[(12, r"Treats $3$ kg as $25\%$ of the quantity, $\frac{3}{0.25}$, which is the new quantity."),
              (120, r"Reports the original price per kg instead of the quantity.")],
  cognitive="Application")


def _c31():
    w = [F(5), F(3), F(2)]
    rise = [F(10), F(20), F(30)]
    return sum(a * b for a, b in zip(w, rise)) / sum(w)
q("C01-B-031", TC, "Rise in total household expenditure when items in a basket rise by different percentages", "Medium",
  "Conceptual/application",
  r"Sneha's household spends its monthly grocery money on rice, oil and vegetables in the ratio $5 : 3 : 2$. The prices of rice, oil and vegetables rise by $10\%$, $20\%$ and $30\%$ respectively, and the household buys the same quantities as before. By what percent does its monthly grocery expenditure rise?",
  "MCQ",
  r"The overall rise is the expenditure-weighted average: $\frac{5 \times 10 + 3 \times 20 + 2 \times 30}{5 + 3 + 2} = \frac{170}{10} = 17\%$.",
  "Averaging the price rises without weights, or attaching the weights to the wrong items.",
  "C01B-weighted-average-rate", r"Weighted average of three rates; the plain average gives $20\%$.",
  correct=r"$17\%$",
  distractors=[(r"$20\%$", r"Takes the plain average of $10$, $20$ and $30$."),
               (r"$23\%$", r"Reverses the weights: $\frac{2 \times 10 + 3 \times 20 + 5 \times 30}{10}$."),
               (r"$18\%$", r"Mis-pairs the rises of oil and vegetables: $\frac{5 \times 10 + 3 \times 30 + 2 \times 20}{10}$.")],
  check=_c31, values=[17, 20, 23, 18], cognitive="Understanding")


def _c32():
    km, price, mileage = F(3, 2), F(6, 5), F(5, 4)
    litres = km / mileage
    return (litres * price - 1) * 100
q("C01-B-032", TC, "Fuel expenditure when price, distance driven and mileage all change", "Medium",
  "Multi-step word problem",
  r"Joseph's monthly fuel expenditure depends on the distance he drives, the price of fuel per litre and his car's mileage in km per litre. The price of fuel rises by $20\%$, he drives $50\%$ more km each month, and he switches to a car whose mileage is $25\%$ higher. By what percent does his monthly fuel expenditure rise?",
  "MCQ",
  r"Litres used $= \frac{\text{distance}}{\text{mileage}}$, which changes by the factor $\frac{1.5}{1.25} = 1.2$. Expenditure $=$ litres $\times$ price, so the factor is $1.2 \times 1.2 = 1.44$. Expenditure rises by $44\%$.",
  "Multiplying by $0.75$ for the mileage gain instead of dividing by $1.25$.",
  "C01B-fuel-mileage-expenditure", "Mileage enters inversely; three factors to combine.",
  correct=r"$44\%$",
  distractors=[(r"$35\%$", r"Multiplies by $0.75$ for the mileage gain: $1.2 \times 1.5 \times 0.75 = 1.35$."),
               (r"$45\%$", r"Adds and subtracts the rates: $20 + 50 - 25$."),
               (r"$80\%$", r"Ignores the mileage: $1.2 \times 1.5 = 1.8$.")],
  check=_c32, values=[44, 35, 45, 80], cognitive="Application")


def _c33():
    s = symbols('s', positive=True)
    side = solve(Eq(s**2, F(144, 100)), s)[0]
    cost = side * 4 * F(125, 100)        # fence length x price per metre, original = 4 x 1
    return (cost / 4 - 1) * 100
q("C01-B-033", TC, "Change in fencing cost of a square plot when its area and the price per metre both rise", "Medium",
  "Conceptual/application",
  r"Each side of a square garden is increased by the same percentage, so that its area increases by $44\%$. At the same time, the cost of fencing per metre rises by $25\%$. By what percent does the cost of fencing the whole boundary of the garden rise?",
  "MCQ",
  r"Area scales as the square of the side, so the side, and with it the perimeter, grows by the factor $\sqrt{1.44} = 1.2$. Fencing cost $=$ perimeter $\times$ cost per metre, so the factor is $1.2 \times 1.25 = 1.5$. The cost rises by $50\%$.",
  "Treating the perimeter as growing like the area, or adding the percentage changes.",
  "C01B-area-change-dimensions", "Two ideas: the square-root link from area to perimeter, then a product of factors for the cost.",
  correct=r"$50\%$",
  distractors=[(r"$80\%$", r"Lets the perimeter grow like the area: $1.44 \times 1.25 = 1.8$."),
               (r"$69\%$", r"Adds the area change to the price rise: $44 + 25$."),
               (r"$45\%$", r"Adds the perimeter change to the price rise: $20 + 25$.")],
  check=_c33, values=[50, 80, 69, 45], cognitive="Application")


def _c34():
    a = symbols('a', positive=True)
    k = solve(Eq(a**2, F(121, 100)), a)[0]
    return (k**3 - 1) * 100
q("C01-B-034", TC, "Percentage change in the volume of a cube from the change in its surface area", "Medium",
  "Conceptual/application",
  r"Each edge of a cubical storage box is increased by the same percentage, and its total surface area increases by $21\%$. By what percent does its volume increase?",
  "MCQ",
  r"Surface area scales as the square of the edge, so the edge factor is $\sqrt{1.21} = 1.1$. Volume scales as the cube: $1.1^3 = 1.331$. The volume increases by $33.1\%$.",
  r"Scaling the surface-area change by $\frac{3}{2}$ linearly, or tripling the edge change.",
  "C01B-volume-change-dimensions", "Area to length to volume, two different powers.",
  correct=r"$33.1\%$",
  distractors=[(r"$31.5\%$", r"Multiplies the area change by $\frac{3}{2}$: $21 \times 1.5$."),
               (r"$30\%$", r"Triples the $10\%$ edge change without compounding."),
               (r"$21\%$", r"Assumes the volume changes by the same percentage as the surface area.")],
  check=_c34, values=[F(331, 10), F(315, 10), 30, 21], cognitive="Application")


# ================================================================ DIFFICULT (11)

def _c35():
    N = symbols('N', positive=True)
    p = F(40000)
    y1 = p * F(105, 100) - N
    y2 = y1 * F(105, 100) - N
    return solve(Eq(y2, 43280), N)[0]
q("C01-B-035", TP, "Fixed yearly out-migration from start and end populations with birth and death rates", "Difficult",
  "Inverse/parameter",
  r"Each year in Devgaon, births equal $6\%$ and deaths equal $1\%$ of the population at the start of that year. At the end of each year, after these births and deaths, the same number of people leave the town for good. The population was $40{,}000$ at the start of the first year and $43{,}280$ at the end of the second year. How many people leave the town at the end of each year?",
  "TITA",
  r"Let $N$ people leave each year. End of year $1$: $40000 \times 1.05 - N = 42000 - N$. End of year $2$: $1.05(42000 - N) - N = 44100 - 2.05N$. So $44100 - 2.05N = 43280$, giving $2.05N = 820$ and $N = 400$.",
  "Splitting the shortfall equally between the years, ignoring that the first year's leavers would also have grown.",
  "C01B-pop-births-deaths-migration", "The first year's departures also lose a year of growth; equal splitting gives $410$.",
  tita_answer=400, check=_c35,
  tita_traps=[(410, r"Splits the shortfall $44100 - 43280 = 820$ equally over two years."),
              (820, r"Reports the total shortfall against pure $5\%$ growth.")],
  exams=HARD, cognitive="Analysis")


def _c36():
    x, y, n = F(900000), F(400000), 0
    while not x < y:
        x *= F(8, 10)
        y *= F(95, 100)
        n += 1
    return n
q("C01-B-036", TP, "Year in which a fast-depreciating costly machine becomes worth less than a slow-depreciating cheaper one", "Difficult",
  "Casework/optimisation",
  r"Harpreet buys two machines on the same day. Machine X costs Rs. $9{,}00{,}000$ and loses $20\%$ of its value each year; machine Y costs Rs. $4{,}00{,}000$ and loses $5\%$ of its value each year. Each loss is on the machine's value at the start of that year. After how many complete years will X first be worth less than Y?",
  "TITA",
  r"Values (in thousands of rupees): after $3$ years X $= 900 \times 0.512 = 460.8$, Y $= 400 \times 0.857375 \approx 342.95$; after $4$ years X $= 368.64$, Y $\approx 325.80$; after $5$ years X $= 294.912$, Y $\approx 309.51$. X first falls below Y after $5$ years. (Equivalently, the smallest $n$ with $\left(\frac{0.8}{0.95}\right)^n < \frac{4}{9}$.)",
  "Using straight-line depreciation on the purchase prices.",
  "C01B-depreciation-years-threshold", "Two geometric sequences compared year by year; straight-line reasoning gives $4$.",
  tita_answer=5, check=_c36,
  tita_traps=[(4, r"Uses straight-line losses of Rs. $180000$ and Rs. $20000$ a year: $900000 - 180000n < 400000 - 20000n$ first holds at $n = 4$."),
              (3, r"Solves the straight-line inequality $160000n > 500000$ and rounds $3.125$ down.")],
  exams=HARD, cognitive="Analysis")


def _c37():
    r = symbols('r', positive=True)
    end = (40000 * (1 + r / 100) - 1000) * (1 + (r + 5) / 100)
    sol = solve(Eq(end, 49450), r)
    return [s for s in sol if s > 0][0]
q("C01-B-037", TP, "Unknown growth rate with a percentage-point link between years and a departure in between", "Difficult",
  "Inverse/parameter",
  r"The population of a town was $40{,}000$ at the start of 2024 and grew by $r\%$ during 2024. At the very end of 2024, $1{,}000$ people moved away. During 2025 the population grew at a rate $5$ percentage points higher than in 2024, and it was $49{,}450$ at the end of 2025. Each growth rate is on the population at the start of that year. What is the value of $r$?",
  "TITA",
  r"End of 2024 after the departure: $40000(1 + \frac{r}{100}) - 1000 = 39000 + 400r$. Then $(39000 + 400r)(1 + \frac{r + 5}{100}) = 49450$. Dividing by $100$: $(390 + 4r)(105 + r) = 49450$, so $4r^2 + 810r - 8500 = 0$, that is $2r^2 + 405r - 4250 = 0 = (r - 10)(2r + 425)$. Hence $r = 10$. (Check: $44000 - 1000 = 43000$, and $43000 \times 1.15 = 49450$.)",
  "Reporting the 2025 rate, or ignoring the departure when setting up the equation.",
  "C01B-pop-unknown-year-rate", "A quadratic from compounding with a percentage-point link and an absolute outflow between the years; no options to test.",
  tita_answer=10, check=_c37,
  tita_traps=[(15, r"Reports the 2025 growth rate $r + 5$ instead of $r$.")],
  exams=HARD, cognitive="Analysis")


def _c38():
    # brute force over every possible population of P two years ago (total fixed at 1,00,000)
    total = 100000
    found = []
    for p0 in range(0, total + 1):
        p, qq = F(p0), F(total - p0)
        for _ in range(2):
            p, qq = p - p / 10 + qq / 5, qq - qq / 5 + p / 10
        if p == 63400 and qq == 36600:
            found.append(p0)
    assert len(found) == 1
    return found[0]
q("C01-B-038", TP, "Population two years earlier when two towns exchange fixed percentages of residents every year", "Difficult",
  "Multi-step word problem",
  r"Towns P and Q have no births or deaths, and nobody moves in from or out to any other place. Each year, $10\%$ of the people living in P at the start of the year move to Q, and $20\%$ of the people living in Q at the start of the year move to P. Today P has $63{,}400$ people and Q has $36{,}600$. How many people lived in P two years ago?",
  "MCQ",
  r"The total stays $100000$. If P has $x$ at the start of a year, Q has $100000 - x$, and at the end P has $0.9x + 0.2(100000 - x) = 0.7x + 20000$. Going back one year: $0.7x + 20000 = 63400$ gives $x = 62000$. Going back again: $0.7x + 20000 = 62000$ gives $x = 60000$. So P had $60{,}000$ people two years ago.",
  "Applying the percentages to today's populations when working backwards.",
  "C01B-two-town-migration-flow", "The movers are percentages of start-of-year figures that are unknown; the fixed total must be used to undo two years.",
  correct=r"$60{,}000$",
  distractors=[(r"$62{,}000$", r"Goes back only one year."),
               (r"$61{,}146$", r"Undoes each year using percentages of the later figures: $63400 + 6340 - 7320 = 62420$, then $62420 + 6242 - 7516 = 61146$."),
               (r"$61{,}440$", r"Takes today's net inflow into P, $0.2 \times 36600 - 0.1 \times 63400 = 980$, as the same in both years: $63400 - 2 \times 980$.")],
  check=_c38, values=[60000, 62000, 61146, 61440], exams=HARD, cognitive="Analysis")


def _c39():
    p, n = symbols('p n', positive=True)
    actual = (p * F(120, 100) - n) * F(110, 100)
    other = (p - n) * F(120, 100) * F(110, 100)
    sol = solve([Eq(actual, 125400), Eq(other, 124608)], [p, n], dict=True)
    return sol[0][p]
q("C01-B-039", TP, "Starting population and size of a departing group from two possible timings of the departure", "Difficult",
  "Inverse/parameter",
  r"The population of a town grew by $20\%$ during 2024. At the very start of 2025 a group of people moved away for good, and the remaining population grew by $10\%$ during 2025, reaching $1{,}25{,}400$ at the end of 2025. Had the same group moved away at the very start of 2024 instead, with the same growth rates in both years, the population at the end of 2025 would have been $1{,}24{,}608$. What was the population at the start of 2024?",
  "MCQ",
  r"Let the population be $p$ and the group $n$. Actual: $(1.2p - n) \times 1.1 = 1.32p - 1.1n = 125400$. Alternative: $(p - n) \times 1.32 = 1.32p - 1.32n = 124608$. Subtracting, $0.22n = 792$, so $n = 3600$. Then $1.32p = 125400 + 3960 = 129360$ and $p = 98000$. (Check: $117600 - 3600 = 114000$, $\times 1.1 = 125400$.)",
  "Taking the gap between the two final figures as the size of the group, or ignoring when the group left.",
  "C01B-migration-timing-two-scenarios", "Two timings of the same departure must be compared to find the group size before working back; several shortcuts give listed values.",
  correct=r"$98{,}000$",
  distractors=[(r"$98{,}600$", r"Finds $n = 3600$ but combines the growth factors first and adds the group at the end: $\frac{125400}{1.32} + 3600$."),
               (r"$95{,}000$", r"Ignores the departing group: $\frac{125400}{1.32}$."),
               (r"$92{,}000$", r"Finds $n = 3600$ but subtracts it when going back: $\frac{114000 - 3600}{1.2}$.")],
  check=_c39, values=[98000, 98600, 95000, 92000], exams=HARD, cognitive="Analysis")


def _c40():
    p, r = symbols('p r', positive=True)
    sol = solve([Eq(p * (1 - r)**2, 576000), Eq(p * (1 - r)**4, 368640)], [p, r], dict=True)
    s = [s for s in sol if 0 < s[r] < 1][0]
    return s[p] * s[r]
q("C01-B-040", TP, "First-year depreciation from values at the ends of the second and fourth years", "Difficult",
  "Inverse/parameter",
  r"A bulldozer loses the same percentage of its value every year, each loss being on its value at the start of that year. It was worth Rs. $5{,}76{,}000$ at the end of the second year and Rs. $3{,}68{,}640$ at the end of the fourth year. By how much did its value fall during the first year?",
  "MCQ",
  r"Over two years the value is multiplied by $\frac{368640}{576000} = 0.64$, so the yearly factor is $0.8$ and the rate is $20\%$. Purchase price $= \frac{576000}{0.64} = 900000$. The fall in the first year is $20\%$ of $900000$, that is Rs. $1{,}80{,}000$.",
  "Averaging the two-year fall, or computing the loss of the wrong year.",
  "C01B-depreciation-yearly-amount", "Rate from a two-year ratio, back two years, then one percentage; several near-miss values.",
  correct=r"Rs. $1{,}80{,}000$",
  distractors=[(r"Rs. $1{,}44{,}000$", r"Gives the second year's fall: $0.2 \times 720000$."),
               (r"Rs. $1{,}03{,}680$", r"Takes half of the fall from year $2$ to year $4$: $\frac{576000 - 368640}{2}$."),
               (r"Rs. $3{,}24{,}000$", r"Gives the total fall over the first two years: $900000 - 576000$.")],
  check=_c40, values=[180000, 144000, 103680, 324000], exams=HARD, cognitive="Analysis")


def _c41():
    c = symbols('c', positive=True)
    cereal = F(60, 100) * F(120, 100)
    cnew = solve(Eq(cereal + F(40, 100) * F(150, 100) * c, F(126, 100)), c)[0]
    return (1 - cnew) * 100
q("C01-B-041", TC, "Cut in one item's consumption to hold total basket expenditure to a target rise", "Difficult",
  "Inverse/parameter",
  r"Ananya's household spends $60\%$ of its grocery budget on cereals and $40\%$ on pulses. The price of cereals rises by $20\%$ and the price of pulses rises by $50\%$. The household keeps its cereal consumption unchanged and reduces its consumption of pulses so that its total grocery expenditure rises by exactly $26\%$. By what percent does it reduce its consumption of pulses?",
  "MCQ",
  r"Take the old budget as $100$. Cereals now cost $60 \times 1.2 = 72$, so pulses may cost $126 - 72 = 54$. At the old quantity pulses would cost $40 \times 1.5 = 60$, so the quantity must fall to $\frac{54}{60} = 0.9$ of the old level, a cut of $10\%$.",
  "Measuring the cut against the total budget or against the old pulse expenditure.",
  "C01B-basket-target-with-cut", "Splits the budget, then works one item backwards; three different bases give three listed values.",
  correct=r"$10\%$",
  distractors=[(r"$6\%$", r"Takes the shortfall $60 - 54 = 6$ as a percentage of the whole budget."),
               (r"$15\%$", r"Compares $\frac{54}{40} = 1.35$ with $1.5$ and reports $150 - 135 = 15$."),
               (r"$16\%$", r"Applies the overall $26\%$ target to pulses alone: $1 - \frac{1.26}{1.5}$.")],
  check=_c41, values=[10, 6, 15, 16], exams=HARD, cognitive="Analysis")


def _c42():
    p, c = symbols('p c', positive=True)
    sol = solve([Eq(F(6, 5) * p * (c - 3) - p * c, 24), Eq(F(6, 5) * p * (c - 5) - p * c, -72)], [p, c], dict=True)
    return sol[0][c]
q("C01-B-042", TC, "Original consumption from two consumption scenarios after a price rise", "Difficult",
  "Multi-step word problem",
  r"The price of sugar rises by $20\%$. Priya's family cuts its monthly sugar consumption by $3$ kg, and its monthly expenditure on sugar still rises by Rs. $24$. Had the family cut its consumption by $5$ kg instead, its monthly expenditure on sugar would have fallen by Rs. $72$. What was the family's monthly sugar consumption, in kg, before the price rise?",
  "TITA",
  r"Cutting $2$ kg more changes the bill by $24 - (-72) = 96$, so the new price is $\frac{96}{2} = 48$ per kg and the old price is $\frac{48}{1.2} = 40$. With consumption $c$: $48(c - 3) - 40c = 24$, so $8c = 168$ and $c = 21$ kg.",
  "Ignoring the change in the bill when setting up the equation.",
  "C01B-price-consumption-two-scenarios", "Two scenarios must be compared to find the price before the consumption can be found.",
  tita_answer=21, check=_c42,
  tita_traps=[(18, r"Assumes the bill is unchanged with the $3$ kg cut: $40c = 48(c - 3)$."),
              (40, r"Reports the original price per kg.")],
  exams=HARD, cognitive="Analysis")


def _c43():
    x = symbols('x', positive=True)
    sol = solve(Eq((1 + x / 100) * (1 - x / 200), F(112, 100)), x)
    return [s for s in sol if s < 50][0]
q("C01-B-043", TC, "Unknown price rise when the consumption cut is half the price rise", "Difficult",
  "Inverse/parameter",
  r"The price of a commodity rises by $x\%$, where $x < 50$. A household reduces its consumption of the commodity by $\frac{x}{2}\%$, and its expenditure on the commodity rises by $12\%$. What is $x$?",
  "MCQ",
  r"$(1 + \frac{x}{100})(1 - \frac{x}{200}) = 1.12$. Multiplying out, $1 + \frac{x}{200} - \frac{x^2}{20000} = 1.12$, so $x^2 - 100x + 2400 = 0$, that is $(x - 40)(x - 60) = 0$. Since $x < 50$, $x = 40$. (Check: $1.4 \times 0.8 = 1.12$.)",
  "Dropping the product term and solving a linear equation.",
  "C01B-linked-price-consumption-unknown", "A quadratic with two positive roots; the stated condition selects one.",
  correct=r"$40$",
  distractors=[(r"$24$", r"Drops the product term: $x - \frac{x}{2} = 12$."),
               (r"$20$", r"Expands with the wrong sign on the product term: $x^2 + 100x - 2400 = 0$."),
               (r"$12$", r"Ignores the consumption cut and equates the price rise to the expenditure rise.")],
  check=_c43, values=[40, 24, 20, 12], exams=HARD, cognitive="Analysis")


def _c44():
    best_k, best = None, None
    for k in range(0, 21):
        price = 500 + 50 * k
        buyers = 1200 - 60 * k
        total = price * buyers
        if best is None or total > best:
            best, best_k = total, k
    return 500 + 50 * best_k
q("C01-B-044", TC, "Price that maximises total spending when each price rise loses a fixed share of buyers", "Difficult",
  "Casework/optimisation",
  r"A monthly bus pass costs Rs. $500$ and $1{,}200$ commuters buy it. The operator may raise the price only in steps of $10\%$ of the original price. Each such step reduces the number of buyers by $5\%$ of the original $1{,}200$. At what price, in rupees, is the total amount spent by commuters on passes the greatest?",
  "TITA",
  r"After $k$ steps the price is $500 + 50k$ and the buyers number $1200 - 60k$. Total $= (500 + 50k)(1200 - 60k) = 3000(10 + k)(20 - k)$. For a fixed sum $(10 + k) + (20 - k) = 30$, the product is greatest when the two factors are equal, at $k = 5$. The price is $500 + 250 =$ Rs. $750$ (total Rs. $6{,}75{,}000$).",
  "Reporting the maximum total or the size of the increase instead of the price.",
  "C01B-expenditure-maximisation", "Builds a quadratic in the number of steps and maximises it.",
  tita_answer=750, check=_c44,
  tita_traps=[(675000, r"Reports the maximum total spent instead of the price."),
              (250, r"Reports the increase in price instead of the new price.")],
  exams=HARD, cognitive="Analysis")


def _c45():
    base = symbols('base', positive=True)
    old_price = base * (1 + F(20, 100))
    new_price = base * F(120, 100) * (1 + F(35, 100))
    c = symbols('c', positive=True)
    cnew = solve(Eq(new_price * c, old_price * F(108, 100)), c)[0]
    return (1 - cnew) * 100
q("C01-B-045", TC, "Consumption cut after a base-price rise and a tax rate increase in percentage points", "Difficult",
  "Inverse/parameter",
  r"The retail price of CNG in a city is its base price plus a tax equal to $20\%$ of the base price. The base price rises by $20\%$, and the tax rate is raised by $15$ percentage points, to $35\%$ of the new base price. A taxi operator allows its monthly CNG expenditure to rise by $8\%$. By what percent must it reduce its monthly CNG consumption?",
  "MCQ",
  r"Take the old base price as $100$: old retail price $= 120$. New base $= 120$, new retail price $= 120 \times 1.35 = 162$, a factor of $\frac{162}{120} = 1.35$. Then $1.35 \times c = 1.08$, so $c = 0.8$ and consumption must fall by $20\%$.",
  "Ignoring the base-price rise, or adding and subtracting the percentages.",
  "C01B-tax-points-price-consumption", "Percentage points on a tax rate combined with a base change, then an inverse step.",
  correct=r"$20\%$",
  distractors=[(r"$27\%$", r"Adds and subtracts the figures: $20 + 15 - 8$."),
               (r"$4\%$", r"Ignores the base-price rise: price factor $\frac{135}{120} = 1.125$, then $1 - \frac{1.08}{1.125}$."),
               (r"$25\%$", r"Measures the cut against the new level: $\frac{1.35 - 1.08}{1.08}$.")],
  check=_c45, values=[20, 27, 4, 25], exams=HARD, cognitive="Analysis")
