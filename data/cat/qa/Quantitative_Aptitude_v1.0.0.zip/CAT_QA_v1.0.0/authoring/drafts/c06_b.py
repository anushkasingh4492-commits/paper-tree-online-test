import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Replacement"
HARD = ("CAT", "XAT")


def _rep(state, draw, add=None):
    """Draw `draw` litres of a well-mixed liquid, then pour in the litres in `add`."""
    tot = sum(state.values())
    f = Fraction(draw) / tot
    new = {k: v * (1 - f) for k, v in state.items()}
    for k, v in (add or {}).items():
        new[k] = new.get(k, 0) + Fraction(v)
    return new


def _r(*xs):
    """A ratio as a tuple normalised by its first term (for 3-term ratios)."""
    return tuple(Fraction(x) / Fraction(xs[0]) for x in xs)


# ---------------------------------------------------------------- EASY

def _c1():
    s = {"juice": Fraction(64), "water": Fraction(0)}
    for _ in range(3):
        s = _rep(s, 16, {"water": 16})
    return s["juice"]
q("C06-B-001", T, "Juice left after three equal replacements with water", "Easy",
  "Multi-step word problem",
  r"A drum holds $64$ litres of pure orange juice. Priya draws out $16$ litres and replaces it with $16$ litres of water, mixing thoroughly. She performs this draw and replace step $3$ times in all. How many litres of orange juice does the drum now contain?",
  "TITA",
  r"Each step removes $\frac{16}{64} = \frac{1}{4}$ of whatever is in the drum, so the juice is multiplied by $\frac{3}{4}$ each time. After $3$ steps the juice is $64 \times \left(\frac{3}{4}\right)^3 = 64 \times \frac{27}{64} = 27$ litres.",
  "Subtracting $16$ litres of juice in every step, as if each draw were pure juice.",
  r"C06B-repeated-replacement-amount-left", r"Direct use of the factor $(1 - \frac{x}{V})^n$ once the student sees that each draw takes a fixed fraction.",
  tita_answer=27, check=_c1, values=[27],
  tita_traps=[(16, r"Subtracts $16$ litres of juice three times: $64 - 48 = 16$."),
              (36, r"Applies the factor $\frac{3}{4}$ only twice: $64 \times \frac{9}{16} = 36$.")],
  cognitive="Application")


def _c2():
    s = {"m": Fraction(50), "w": Fraction(0)}
    for _ in range(2):
        s = _rep(s, 5, {"w": 5})
    return s["m"] / s["w"]
q("C06-B-002", T, "Milk to water ratio after two equal replacements", "Easy",
  "Multi-step word problem",
  r"A can contains $50$ litres of pure milk. Joseph draws out $5$ litres and replaces it with $5$ litres of water, then mixes thoroughly. He repeats this once more. What is the ratio of milk to water in the can now?",
  "MCQ",
  r"Each draw removes $\frac{5}{50} = \frac{1}{10}$ of the contents, so milk becomes $50 \times \left(\frac{9}{10}\right)^2 = 40.5$ litres. Water is $50 - 40.5 = 9.5$ litres, so milk : water $= 40.5 : 9.5 = 81 : 19$.",
  "Treating each draw as pure milk, which gives the linear answer $40 : 10$.",
  "C06B-repeated-replacement-amount-left", "Two applications of the replacement factor and a ratio; the linear trap is natural.",
  correct=r"$81 : 19$",
  distractors=[(r"$4 : 1$", r"Removes $5$ litres of pure milk each time: milk $40$, water $10$."),
               (r"$81 : 100$", r"Writes milk : total, $40.5 : 50$, as the answer."),
               (r"$9 : 1$", r"Stops after one replacement: milk $45$, water $5$.")],
  check=_c2, values=[Fraction(81, 19), 4, Fraction(81, 100), 9], cognitive="Application")


def _c3():
    s = {"m": Fraction(1), "w": Fraction(0)}
    for _ in range(4):
        s = _rep(s, Fraction(1, 3), {"w": Fraction(1, 3)})
    return s["w"] / (s["m"] + s["w"])
q("C06-B-003", T, "Fraction of water after four one-third replacements", "Easy",
  "Single-step computation",
  r"A jar is full of pure milk. Each time, one-third of the contents of the jar is poured out and the jar is refilled to the brim with water, and the contents are mixed thoroughly. After this is done $4$ times, what fraction of the liquid in the jar is water?",
  "MCQ",
  r"Each operation keeps $\frac{2}{3}$ of the milk, so after $4$ operations the milk is $\left(\frac{2}{3}\right)^4 = \frac{16}{81}$ of the jar. Water is therefore $1 - \frac{16}{81} = \frac{65}{81}$ of the liquid.",
  "Reporting the milk fraction, or raising the removed fraction to the power instead of the retained fraction.",
  "C06B-repeated-replacement-amount-left", "One formula with the retained fraction; the volume is not even needed.",
  correct=r"$\frac{65}{81}$",
  distractors=[(r"$\frac{16}{81}$", r"Reports the fraction of milk, $\left(\frac{2}{3}\right)^4$."),
               (r"$\frac{80}{81}$", r"Raises the removed fraction to the power: $1 - \left(\frac{1}{3}\right)^4$."),
               (r"$\frac{19}{27}$", r"Uses only $3$ operations: $1 - \left(\frac{2}{3}\right)^3$.")],
  check=_c3, values=[Fraction(65, 81), Fraction(16, 81), Fraction(80, 81), Fraction(19, 27)], cognitive="Understanding")


def _c4():
    s = {"m": Fraction(30), "w": Fraction(10)}
    s = _rep(s, 8, {"w": 8})
    return s["m"] / s["w"]
q("C06-B-004", T, "New ratio after one replacement of a milk and water mixture with water", "Easy",
  "Single-step computation",
  r"A $40$ litre can is full of a mixture of milk and water in the ratio $3 : 1$. Harpreet draws out $8$ litres of the mixture and replaces it with $8$ litres of water. What is the ratio of milk to water in the can now?",
  "MCQ",
  r"Initially milk is $30$ litres and water $10$ litres. The $8$ litres drawn is $\frac{1}{5}$ of the can, so it removes $6$ litres of milk and $2$ litres of water. Milk becomes $24$ and water becomes $10 - 2 + 8 = 16$, giving $24 : 16 = 3 : 2$.",
  "Treating the drawn liquid as pure milk, or not removing any water with the draw.",
  "C06B-mixture-replaced-with-water", "One replacement on a mixture; the trap is the composition of the drawn liquid.",
  correct=r"$3 : 2$",
  distractors=[(r"$11 : 9$", r"Takes all $8$ litres drawn as milk: milk $22$, water $18$."),
               (r"$4 : 3$", r"Removes $6$ litres of milk but no water, then adds $8$: milk $24$, water $18$."),
               (r"$3 : 5$", r"Reports milk : total, $24 : 40$.")],
  check=_c4, values=[Fraction(3, 2), Fraction(11, 9), Fraction(4, 3), Fraction(3, 5)], cognitive="Application")


def _c5():
    x = symbols('x', positive=True)
    # 60 L at 40% acid, x drawn and replaced with water, becomes 30%
    return solve(Eq(Rational(40, 100) * (60 - x), Rational(30, 100) * 60), x)[0]
q("C06-B-005", T, "Volume to replace with water to dilute an acid solution to a target strength", "Easy",
  "Inverse/parameter",
  r"A tank holds $60$ litres of a $40\%$ acid solution (by volume). Fatima draws out some of the solution and replaces it with the same volume of water, so that the tank now holds a $30\%$ acid solution. How many litres of solution did she draw out?",
  "TITA",
  r"Acid falls from $0.4 \times 60 = 24$ litres to $0.3 \times 60 = 18$ litres, so $6$ litres of acid left with the drawn solution. Each litre drawn carries $0.4$ litre of acid, so the volume drawn is $\frac{6}{0.4} = 15$ litres. Equivalently, the acid is multiplied by $\frac{30}{40} = \frac{3}{4}$, so $\frac{1}{4}$ of $60$ litres was drawn.",
  "Treating the drawn liquid as pure acid, or subtracting percentages directly.",
  "C06B-single-replacement-to-target", "One inverse step; the trap is assuming the drawn liquid is pure acid.",
  tita_answer=15, check=_c5, values=[15],
  tita_traps=[(6, r"Treats the drawn liquid as pure acid, so $24 - x = 18$ gives $x = 6$."),
              (45, r"Reports the volume of original solution left, $60 - 15$.")],
  cognitive="Application")


def _c6():
    s = {"a": Fraction(24), "w": Fraction(16)}
    s = _rep(s, 10, {"a": 2, "w": 8})
    return 100 * s["a"] / (s["a"] + s["w"])
q("C06-B-006", T, "Concentration after replacing part of a solution with a weaker solution", "Easy",
  "Single-step computation",
  r"A container holds $40$ litres of a $60\%$ alcohol solution (by volume). Kabir draws out $10$ litres and replaces it with $10$ litres of a $20\%$ alcohol solution, then mixes thoroughly. What is the alcohol concentration of the solution now?",
  "MCQ",
  r"Alcohol initially is $24$ litres. The $10$ litres drawn carries $6$ litres of alcohol, and the $10$ litres added carries $2$ litres. Alcohol becomes $24 - 6 + 2 = 20$ litres in $40$ litres, which is $50\%$.",
  "Averaging the two strengths, or treating the added solution as plain water.",
  "C06B-replace-with-solution", "One replacement step with a non-water replacement liquid.",
  correct=r"$50\%$",
  distractors=[(r"$40\%$", r"Takes the simple average of $60\%$ and $20\%$."),
               (r"$45\%$", r"Ignores the alcohol in the added solution: $\frac{24 - 6}{40} = 45\%$."),
               (r"$65\%$", r"Adds the $2$ litres of alcohol without removing any: $\frac{26}{40}$.")],
  check=_c6, values=[50, 40, 45, 65], cognitive="Application")


def _c7():
    s = {"m": Fraction(80), "w": Fraction(0)}
    for d in (16, 20, 40):
        s = _rep(s, d, {"w": d})
    return s["m"]
q("C06-B-007", T, "Milk left after three replacements of different volumes", "Easy",
  "Multi-step word problem",
  r"A vessel holds $80$ litres of pure milk. Sneha draws out $16$ litres and replaces it with water. After mixing, she draws out $20$ litres and replaces it with water. After mixing again, she draws out $40$ litres and replaces it with water. How many litres of milk are left in the vessel?",
  "MCQ",
  r"The volume stays $80$ litres, so the three draws remove $\frac{16}{80} = \frac{1}{5}$, $\frac{20}{80} = \frac{1}{4}$ and $\frac{40}{80} = \frac{1}{2}$ of the milk present. Milk left $= 80 \times \frac{4}{5} \times \frac{3}{4} \times \frac{1}{2} = 24$ litres.",
  "Subtracting the drawn volumes from the milk as if each draw were pure milk.",
  "C06B-unequal-draws", "Three different factors, each easy; the trap is linear subtraction.",
  correct=r"$24$ litres",
  distractors=[(r"$4$ litres", r"Subtracts all the drawn volumes from the milk: $80 - 16 - 20 - 40$."),
               (r"$48$ litres", r"Stops after the first two draws: $80 \times \frac{4}{5} \times \frac{3}{4}$."),
               (r"$56$ litres", r"Reports the water in the vessel, $80 - 24$.")],
  check=_c7, values=[24, 4, 48, 56], cognitive="Application")


def _c8():
    s = {"j": Fraction(40), "w": Fraction(0)}
    for _ in range(2):
        s = _rep(s, 10, {"w": 20})
    return s["j"]
q("C06-B-008", T, "Draw one volume, add a larger volume of water: juice left after two steps", "Easy",
  "Multi-step word problem",
  r"A large tank contains $40$ litres of pure juice. In one step, Ananya draws out $10$ litres of the liquid in the tank and then pours in $20$ litres of water, mixing thoroughly. She carries out this step twice. How many litres of juice are in the tank now?",
  "TITA",
  r"First step: $10$ of $40$ litres is drawn, a quarter of the juice, leaving $30$ litres of juice in $50$ litres of liquid. Second step: $10$ of $50$ litres is drawn, one-fifth of the juice, leaving $30 \times \frac{4}{5} = 24$ litres of juice.",
  "Using the original $40$ litres as the volume in the second step, although the tank now holds $50$ litres.",
  "C06B-draw-and-add-unequal", "Two short steps; the only trap is that the volume grows after the first step.",
  tita_answer=24, check=_c8, values=[24],
  tita_traps=[(20, r"Subtracts $10$ litres of juice in each step: $40 - 20$."),
              (30, r"Stops after the first step.")],
  cognitive="Application")


def _c9():
    s = {"c": Fraction(48), "w": Fraction(0)}
    n = 0
    while s["c"] >= 3:
        s = _rep(s, 24, {"w": 24})
        n += 1
    return n
q("C06-B-009", T, "First operation after which the original liquid falls below a level", "Easy",
  "Casework/optimisation",
  r"A jar holds $48$ litres of pure coconut water. In each operation, half the liquid in the jar is poured out and the jar is refilled to the same level with plain water, then mixed thoroughly. After how many operations will the jar first contain less than $3$ litres of coconut water?",
  "TITA",
  r"Each operation halves the coconut water: $48, 24, 12, 6, 3, 1.5$. After $4$ operations it is exactly $3$ litres, which is not less than $3$. It first drops below $3$ litres after $5$ operations.",
  "Stopping at the operation that gives exactly $3$ litres, though the condition is strictly less than $3$.",
  "C06B-min-operations-threshold", "Repeated halving; the trap is the boundary case at exactly $3$ litres.",
  tita_answer=5, check=_c9, values=[5],
  tita_traps=[(4, r"Stops when the coconut water equals $3$ litres instead of falling below it.")],
  cognitive="Application")


def _c10():
    x = symbols('x', positive=True)
    sols = solve(Eq(72 * (1 - x / 72) ** 2, 32), x)
    return [s for s in sols if s < 72][0]
q("C06-B-010", T, "Quantity drawn each time from the milk left after two replacements", "Easy",
  "Inverse/parameter",
  r"A container holds $72$ litres of pure milk. Arjun draws out a certain quantity and replaces it with an equal volume of water, mixes thoroughly, and then repeats this with the same quantity once more. The container now holds $32$ litres of milk. How much did he draw out each time?",
  "MCQ",
  r"If $x$ litres is drawn each time, $72\left(1 - \frac{x}{72}\right)^2 = 32$, so $\left(1 - \frac{x}{72}\right)^2 = \frac{4}{9}$ and $1 - \frac{x}{72} = \frac{2}{3}$. Hence $x = 24$ litres.",
  "Treating the two draws as one, or as linear removals of milk.",
  "C06B-find-volume-removed", "One square root after forming the replacement equation.",
  correct=r"$24$ litres",
  distractors=[(r"$40$ litres", r"Treats it as a single draw: $72 - x = 32$."),
               (r"$20$ litres", r"Subtracts $x$ litres of milk each time: $72 - 2x = 32$."),
               (r"$48$ litres", r"Takes the retained fraction $\frac{2}{3}$ as the fraction drawn: $\frac{2}{3} \times 72$.")],
  check=_c10, values=[24, 40, 20, 48], cognitive="Application")


def _c11():
    s = {"m": Fraction(20), "w": Fraction(0)}
    s = _rep(s, 5, {"w": 5})
    s = _rep(s, 5, {"m": 5})
    return s["m"]
q("C06-B-011", T, "Replace with water, then replace the mixture with milk", "Easy",
  "Conceptual/application",
  r"A jug contains $20$ litres of pure milk. Pooja draws out $5$ litres and replaces it with $5$ litres of water, mixing thoroughly. She then draws out $5$ litres of the mixture and replaces it with $5$ litres of pure milk. How many litres of milk are in the jug now?",
  "MCQ",
  r"After the first step there are $15$ litres of milk in $20$ litres. The second draw is a quarter of the jug, so it removes $\frac{15}{4} = 3.75$ litres of milk, leaving $11.25$ litres; adding $5$ litres of milk gives $16.25$ litres. The second step does not undo the first, because the draw is a mixture, not pure water.",
  "Believing the second step exactly reverses the first.",
  "C06B-alternating-replacement", "Two steps; the conceptual trap is that the second draw is a mixture.",
  correct=r"$16.25$ litres",
  distractors=[(r"$20$ litres", r"Assumes the second step takes out the $5$ litres of water that was added, restoring pure milk."),
               (r"$15$ litres", r"Takes the second draw as $5$ litres of pure milk: $15 - 5 + 5$."),
               (r"$18.75$ litres", r"Uses the water fraction for the milk removed in the second draw: $15 - 5 \times \frac{1}{4} + 5$.")],
  check=_c11, values=[Fraction(65, 4), 20, 15, Fraction(75, 4)], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM

def _c12():
    s = {"m": Fraction(45), "w": Fraction(27)}
    for _ in range(2):
        s = _rep(s, 24, {"w": 24})
    return s["m"]
q("C06-B-012", T, "Milk left after two replacements when the vessel starts with a mixture", "Medium",
  "Multi-step word problem",
  r"A vessel holds $72$ litres of a mixture of milk and water in the ratio $5 : 3$. Ravi draws out $24$ litres of the mixture and replaces it with $24$ litres of water, mixes thoroughly, and repeats this once more. How many litres of milk does the vessel now contain?",
  "TITA",
  r"Milk initially is $\frac{5}{8} \times 72 = 45$ litres. Each draw removes $\frac{24}{72} = \frac{1}{3}$ of the contents, so milk is multiplied by $\frac{2}{3}$ each time: $45 \times \frac{4}{9} = 20$ litres.",
  "Removing a fixed $15$ litres of milk in each draw, as if the milk fraction did not change.",
  "C06B-mixture-replaced-with-water", "Needs the initial milk from the ratio, then two replacement factors.",
  tita_answer=20, check=_c12, values=[20],
  tita_traps=[(15, r"Removes $\frac{5}{8} \times 24 = 15$ litres of milk in both draws: $45 - 30$."),
              (30, r"Stops after one replacement.")],
  cognitive="Application")


def _c13():
    x = symbols('x', positive=True)
    # 60 L, milk 36 water 24; draw x, replace with milk; final 4:1 so water 12
    return solve(Eq(24 * (1 - x / 60), 12), x)[0]
q("C06-B-013", T, "Volume to replace with pure milk to raise a mixture to a target ratio", "Medium",
  "Inverse/parameter",
  r"A can holds $60$ litres of a mixture of milk and water in the ratio $3 : 2$. Meera wants to draw out some of the mixture and replace it with the same volume of pure milk so that the ratio of milk to water becomes $4 : 1$. How many litres should she draw out?",
  "MCQ",
  r"Water is $24$ litres and must become $\frac{1}{5} \times 60 = 12$ litres. Only the draw removes water, and every litre drawn carries $\frac{2}{5}$ litre of water. So $\frac{2}{5}x = 12$, giving $x = 30$ litres.",
  "Treating the drawn mixture as pure water, or using the wrong share for the water carried out by each litre drawn.",
  "C06B-single-replacement-to-target", "Inverse step; tracking the water, which only the draw changes, is the key insight.",
  correct=r"$30$ litres",
  distractors=[(r"$12$ litres", r"Treats the drawn liquid as pure water: $24 - x = 12$."),
               (r"$18$ litres", r"Turns water : milk $= 2 : 3$ into a water fraction of $\frac{2}{3}$ instead of $\frac{2}{5}$: $\frac{2}{3}x = 12$ gives $x = 18$."),
               (r"$20$ litres", r"Uses the milk share $\frac{3}{5}$ as the water carried out per litre drawn: $\frac{3}{5}x = 12$.")],
  check=_c13, values=[30, 12, 18, 20], cognitive="Application")


def _c14():
    x = symbols('x', positive=True)
    # 90 L, 4:1 -> milk 72; after two replacements milk : water = 16 : 29, so milk = 32
    sols = solve(Eq(72 * (1 - x / 90) ** 2, Rational(16, 45) * 90), x)
    return [s for s in sols if s < 90][0]
q("C06-B-014", T, "Volume drawn each time from a final ratio, mixture start", "Medium",
  "Inverse/parameter",
  r"A container holds $90$ litres of milk and water in the ratio $4 : 1$. A certain volume of the mixture is drawn out and replaced with water, and after thorough mixing the same volume is again drawn out and replaced with water. The ratio of milk to water is now $16 : 29$. How many litres were drawn out each time?",
  "TITA",
  r"Milk is $72$ litres at the start and $\frac{16}{45} \times 90 = 32$ litres at the end. So $72\left(1 - \frac{x}{90}\right)^2 = 32$, giving $\left(1 - \frac{x}{90}\right)^2 = \frac{4}{9}$ and $1 - \frac{x}{90} = \frac{2}{3}$. Hence $x = 30$ litres.",
  "Using $90$ litres as the starting milk, or taking the retained fraction as the drawn fraction.",
  "C06B-find-volume-removed", "Inverse problem with a mixture start: two conversions before the square root.",
  tita_answer=30, check=_c14, values=[30],
  tita_traps=[(60, r"Takes the retained fraction $\frac{2}{3}$ as the fraction drawn."),
              (50, r"Treats it as one replacement: $72\left(1 - \frac{x}{90}\right) = 32$.")],
  cognitive="Application")


def _c15():
    f = symbols('f', positive=True)
    sols = solve(Eq((1 - f) ** 3, Rational(1, 64)), f)
    fr = [s for s in sols if s.is_real and 0 < s < 1][0]
    return fr * 64
q("C06-B-015", T, "Volume drawn each time from the ratio after three replacements", "Medium",
  "Inverse/parameter",
  r"A $64$ litre cask is full of pure wine. A fixed volume is drawn out and replaced with water, and this is done $3$ times in all, with thorough mixing after each step. The ratio of wine to water in the cask is now $1 : 63$. How many litres were drawn out each time?",
  "MCQ",
  r"Wine is now $\frac{1}{64}$ of the cask, so $\left(1 - \frac{x}{64}\right)^3 = \frac{1}{64}$ and $1 - \frac{x}{64} = \frac{1}{4}$. Each draw removed $\frac{3}{4}$ of the cask, that is $48$ litres.",
  "Using a square root for three operations, or treating the draws as removing wine linearly.",
  "C06B-find-volume-removed", "Cube root of the retained fraction, with three tempting misreadings.",
  correct=r"$48$ litres",
  distractors=[(r"$16$ litres", r"Takes the retained fraction $\frac{1}{4}$ as the drawn fraction."),
               (r"$56$ litres", r"Uses a square root as if there were $2$ operations: $1 - \frac{x}{64} = \frac{1}{8}$."),
               (r"$21$ litres", r"Assumes the wine falls linearly: $3x = 63$.")],
  check=_c15, values=[48, 16, 56, 21], cognitive="Application")


def _c16():
    f = symbols('f', positive=True)
    return solve(Eq(Rational(7, 12) * (1 - f), Rational(1, 2)), f)[0]
q("C06-B-016", T, "Fraction of a mixture to replace with water to equalise milk and water", "Medium",
  "Inverse/parameter",
  r"A drum is full of a mixture of milk and water in the ratio $7 : 5$. What fraction of the mixture must be drawn out and replaced with water so that the drum contains equal volumes of milk and water?",
  "MCQ",
  r"Milk is $\frac{7}{12}$ of the drum and must become $\frac{1}{2}$. Drawing a fraction $f$ multiplies the milk by $1 - f$, so $\frac{7}{12}(1 - f) = \frac{1}{2}$, giving $1 - f = \frac{6}{7}$ and $f = \frac{1}{7}$.",
  "Working with the difference of ratio terms instead of the multiplicative effect of the draw.",
  "C06B-single-replacement-to-target", "Inverse with fractions only; the ratio-term traps are tempting.",
  correct=r"$\frac{1}{7}$",
  distractors=[(r"$\frac{1}{6}$", r"Uses the difference of the ratio terms over the total: $\frac{7 - 5}{12}$."),
               (r"$\frac{1}{12}$", r"Moves one part of milk out of $12$ parts, ignoring that the draw also removes water."),
               (r"$\frac{6}{7}$", r"Reports the retained fraction $1 - f$.")],
  check=_c16, values=[Fraction(1, 7), Fraction(1, 6), Fraction(1, 12), Fraction(6, 7)], cognitive="Application")


def _c17():
    s = {"s": Fraction(81), "w": Fraction(0)}
    n = 0
    while s["s"] != 16:
        s = _rep(s, 27, {"w": 27})
        n += 1
        assert n < 20
    return n
q("C06-B-017", T, "Number of operations from the original liquid left", "Medium",
  "Inverse/parameter",
  r"A vat holds $81$ litres of pure sugar syrup. In each operation, $27$ litres of the liquid is drawn out and replaced with $27$ litres of water, and the vat is stirred thoroughly. After a certain number of operations the vat contains exactly $16$ litres of syrup. How many operations were carried out?",
  "TITA",
  r"Each operation keeps $1 - \frac{27}{81} = \frac{2}{3}$ of the syrup. We need $81\left(\frac{2}{3}\right)^n = 16$, that is $\left(\frac{2}{3}\right)^n = \frac{16}{81} = \left(\frac{2}{3}\right)^4$. So $n = 4$.",
  "Thinking linearly and concluding that the syrup would be gone after $3$ draws of $27$ litres.",
  r"C06B-find-number-of-operations", r"Recognising $\frac{16}{81}$ as a power of the retained fraction.",
  tita_answer=4, check=_c17, values=[4],
  tita_traps=[(3, r"Linear model: $27$ litres of syrup removed per draw, so $81 / 27 = 3$ draws."),
              (5, r"Counts the initial state as an operation, adding one to the power.")],
  cognitive="Application")


def _c18():
    s = {"m": Fraction(40), "w": Fraction(0)}
    n = 0
    while not s["w"] > s["m"]:
        s = _rep(s, 8, {"w": 8})
        n += 1
    return n
q("C06-B-018", T, "Least number of replacements for water to exceed milk", "Medium",
  "Casework/optimisation",
  r"A churn holds $40$ litres of pure milk. In each operation, $8$ litres of the liquid is drawn out and replaced with $8$ litres of water, followed by thorough mixing. What is the least number of operations after which the churn contains more water than milk?",
  "TITA",
  r"Each operation keeps $\frac{4}{5}$ of the milk. Milk exceeds half the churn while $\left(\frac{4}{5}\right)^n > \frac{1}{2}$: $\left(\frac{4}{5}\right)^3 = 0.512$ (milk $20.48$ litres) but $\left(\frac{4}{5}\right)^4 = 0.4096$ (milk $16.384$ litres). So water first exceeds milk after $4$ operations.",
  "Assuming $8$ litres of milk leaves in every draw, which gives $3$ operations.",
  "C06B-min-operations-threshold", "Needs powers of $0.8$ and a careful comparison near the halfway mark.",
  tita_answer=4, check=_c18, values=[4],
  tita_traps=[(3, r"Linear model: after $3$ draws $24$ litres of milk is gone, leaving $16$ litres of milk.")],
  cognitive="Analysis")


def _c19():
    s = {"a": Fraction(64), "w": Fraction(16)}
    for _ in range(2):
        s = _rep(s, 40, {"a": 8, "w": 32})
    return 100 * s["a"] / (s["a"] + s["w"])
q("C06-B-019", T, "Concentration after two replacements with a weaker solution", "Medium",
  "Multi-step word problem",
  r"A tank holds $80$ litres of an $80\%$ acid solution (by volume). Twice in succession, $40$ litres of the solution is drawn out and replaced with $40$ litres of a $20\%$ acid solution, with thorough mixing after each step. What is the acid concentration in the tank now?",
  "MCQ",
  r"Each step replaces half the tank, so the excess of the concentration over $20\%$ is halved each time. The excess starts at $80 - 20 = 60$ points, becomes $30$ and then $15$. The final concentration is $20 + 15 = 35\%$. (Directly: $50\%$ after one step, then $\frac{50 + 20}{2} = 35\%$.)",
  r"Applying the replacement factor to the whole $80\%$ instead of only the excess over the strength of the incoming solution.",
  "C06B-replace-with-solution", "Repeated replacement where the incoming liquid is not pure water.",
  correct=r"$35\%$",
  distractors=[(r"$20\%$", r"Ignores the acid in the incoming solution: $80 \times \frac{1}{4}$."),
               (r"$50\%$", r"Stops after one replacement."),
               (r"$40\%$", r"Multiplies the full $80$ by $\frac{1}{4}$ and then adds $20$.")],
  check=_c19, values=[35, 20, 50, 40], cognitive="Application", exams=HARD)


def _c20():
    s = {"m": Fraction(90), "w": Fraction(0)}
    for _ in range(2):
        s = _rep(s, 30, {"w": 30})
    sp_ = 90           # price units: 1 per litre of pure milk
    cp = s["m"]        # cost of the milk in the mixture
    return 100 * (sp_ - cp) / cp
q("C06-B-020", T, "Profit from selling a replaced mixture at the cost price of milk", "Medium",
  "Multi-step word problem",
  r"A dairy owner has $90$ litres of pure milk. He draws out $30$ litres and replaces it with water, mixes thoroughly, and repeats this once more. He sells all $90$ litres of the final mixture at the price per litre at which he bought the pure milk. Water costs nothing, and the liquid drawn out is not sold. What is his profit as a percentage of the cost of the milk in the mixture he sells?",
  "MCQ",
  r"Each draw keeps $\frac{2}{3}$ of the milk, so milk left is $90 \times \frac{4}{9} = 40$ litres. He is paid for $90$ litres but the milk in it cost him $40$ litres' worth. Profit $= \frac{90 - 40}{40} \times 100 = 125\%$.",
  "Computing the milk linearly, or reporting selling price as a percentage of cost.",
  "C06B-replacement-profit", "Replacement followed by a profit percentage on the right base.",
  correct=r"$125\%$",
  distractors=[(r"$50\%$", r"Uses only one replacement: milk $60$ litres, profit $\frac{30}{60}$."),
               (r"$200\%$", r"Takes $60$ litres of milk out in two draws: milk $30$ litres, profit $\frac{60}{30}$."),
               (r"$225\%$", r"Reports selling price as a percentage of cost, $\frac{90}{40} \times 100$.")],
  check=_c20, values=[125, 50, 200, 225], cognitive="Application")


def _c21():
    meera = _rep({"m": Fraction(80), "w": Fraction(0)}, 40, {"w": 40})["m"]
    a = {"m": Fraction(80), "w": Fraction(0)}
    for _ in range(2):
        a = _rep(a, 20, {"w": 20})
    return a["m"] - meera   # positive means Arjun has more milk
q("C06-B-021", T, "One large replacement against two smaller ones using the same total water", "Medium",
  "Conceptual/application",
  r"Meera and Arjun each have a can holding $80$ litres of pure milk. Meera draws out $40$ litres once and replaces it with water. Arjun draws out $20$ litres and replaces it with water, mixes thoroughly, and then again draws out $20$ litres and replaces it with water. Which statement is true?",
  "MCQ",
  r"Meera keeps $80 \times \frac{1}{2} = 40$ litres of milk. Arjun keeps $80 \times \left(\frac{3}{4}\right)^2 = 45$ litres, because his second draw takes some of the water he had already added. So Arjun's can has $5$ litres more milk.",
  "Thinking that equal total water poured in means equal dilution.",
  "C06B-one-draw-versus-several", "Comparison of two schemes; the insight is that later draws remove added water.",
  correct=r"Arjun's can has $5$ litres more milk than Meera's",
  distractors=[(r"Both cans have the same quantity of milk", r"Assumes equal water poured in means equal milk removed."),
               (r"Meera's can has $5$ litres more milk than Arjun's", r"Gets the size right but believes smaller repeated draws dilute more."),
               (r"Arjun's can has $15$ litres more milk than Meera's", r"Uses the water fraction $\frac{1}{4}$ for the milk in Arjun's second draw: milk $80 - 20 - 5 = 55$.")],
  check=_c21, values=[5, 0, -5, 15], cognitive="Understanding")


def _c22():
    s = {"m": Fraction(64), "w": Fraction(0)}
    out_w = Fraction(0)
    for _ in range(3):
        out_w += s["w"] * Fraction(16) / (s["m"] + s["w"])
        s = _rep(s, 16, {"w": 16})
    return out_w
q("C06-B-022", T, "Total water drawn out over three replacements", "Medium",
  "Conceptual/application",
  r"A vessel holds $64$ litres of pure milk. Three times in succession, $16$ litres of the liquid is drawn out and replaced with $16$ litres of water, with thorough mixing after each step. In all, how many litres of water were drawn out of the vessel in the three draws?",
  "MCQ",
  r"Water poured in totals $48$ litres. Milk left is $64 \times \left(\frac{3}{4}\right)^3 = 27$ litres, so the vessel holds $37$ litres of water. The water drawn out is $48 - 37 = 11$ litres. (Check: the first draw has no water, the second takes $\frac{16}{64} \times 16 = 4$ and the third $\frac{16}{64} \times 28 = 7$.)",
  "Reporting the water present, or counting only one of the draws.",
  "C06B-total-water-drawn-out", "Uses a conservation idea (poured in minus present) rather than step-by-step tracking.",
  correct=r"$11$ litres",
  distractors=[(r"$37$ litres", r"Reports the water now in the vessel."),
               (r"$7$ litres", r"Counts only the water in the third draw."),
               (r"$4$ litres", r"Counts only the water in the second draw.")],
  check=_c22, values=[11, 37, 7, 4], cognitive="Analysis")


def _c23():
    s = {"m": Fraction(125), "w": Fraction(0)}
    drawn = []
    for _ in range(3):
        drawn.append(s["m"] * Fraction(25, 125))
        s = _rep(s, 25, {"w": 25})
    return drawn[2]
q("C06-B-023", T, "Milk contained in the third draw of a repeated replacement", "Medium",
  "Conceptual/application",
  r"A tank holds $125$ litres of pure milk. Each time, $25$ litres of the liquid is drawn out and replaced with $25$ litres of water, followed by thorough mixing. How many litres of milk are contained in the liquid drawn out the third time?",
  "MCQ",
  r"Each draw is $\frac{1}{5}$ of the tank, so it carries $\frac{1}{5}$ of the milk present. Before the third draw the milk is $125 \times \left(\frac{4}{5}\right)^2 = 80$ litres, so the third draw carries $\frac{80}{5} = 16$ litres of milk. (The milk in successive draws is $25, 20, 16$.)",
  "Taking a draw as pure milk, or reporting the wrong draw.",
  "C06B-kth-draw-content", "Needs the milk before the third draw, not after it.",
  correct=r"$16$ litres",
  distractors=[(r"$20$ litres", r"Reports the milk in the second draw."),
               (r"$25$ litres", r"Takes the third draw as pure milk."),
               (r"$61$ litres", r"Adds the milk in all three draws, $25 + 20 + 16$.")],
  check=_c23, values=[16, 20, 25, 61], cognitive="Understanding")


def _c24():
    s = {"m": Fraction(40), "w": Fraction(20), "j": Fraction(0)}
    for _ in range(2):
        s = _rep(s, 15, {"j": 15})
    return _r(s["m"], s["w"], s["j"])
q("C06-B-024", T, "Three-component ratio after replacing a milk and water mixture with juice twice", "Medium",
  "Multi-step word problem",
  r"A vessel holds $60$ litres of milk and water in the ratio $2 : 1$. Kabir draws out $15$ litres and replaces it with $15$ litres of mango juice, mixes thoroughly, and does this once more. What is the ratio milk : water : juice in the vessel now?",
  "MCQ",
  r"Each draw keeps $\frac{3}{4}$ of every liquid present. Milk becomes $40 \times \frac{9}{16} = 22.5$, water $20 \times \frac{9}{16} = 11.25$, and juice is the rest, $60 - 33.75 = 26.25$ litres. The ratio is $22.5 : 11.25 : 26.25 = 6 : 3 : 7$.",
  "Forgetting that the second draw also removes juice, or decaying only the milk.",
  "C06B-third-liquid-replacement", "Three components must be tracked through two draws.",
  correct=r"$6 : 3 : 7$",
  distractors=[(r"$2 : 1 : 1$", r"Stops after one replacement: $30 : 15 : 15$."),
               (r"$2 : 1 : 3$", r"Removes $10$ litres of milk and $5$ of water in each draw and none of the juice: $20 : 10 : 30$."),
               (r"$9 : 8 : 7$", r"Applies $\frac{9}{16}$ to the milk only and leaves water at $20$: $22.5 : 20 : 17.5$.")],
  check=_c24, values=[_r(6, 3, 7), _r(2, 1, 1), _r(2, 1, 3), _r(9, 8, 7)], cognitive="Application", exams=HARD)


def _c25():
    s = {"m": Fraction(64), "w": Fraction(0), "j": Fraction(0)}
    s = _rep(s, 16, {"w": 16})
    s = _rep(s, 16, {"j": 16})
    s = _rep(s, 16, {"w": 16})
    return s["w"]
q("C06-B-025", T, "Water after replacements alternating between water and juice", "Medium",
  "Multi-step word problem",
  r"A container holds $64$ litres of pure milk. Fatima draws out $16$ litres and replaces it with water. After mixing, she draws out $16$ litres and replaces it with orange juice. After mixing again, she draws out $16$ litres and replaces it with water. How many litres of water does the container hold now?",
  "MCQ",
  r"Each draw is a quarter of the container, so it keeps $\frac{3}{4}$ of every liquid present. After step $1$: milk $48$, water $16$. After step $2$: milk $36$, water $12$, juice $16$. After step $3$: milk $27$, water $9 + 16 = 25$, juice $12$. So the container holds $25$ litres of water.",
  "Not scaling down the water already present before the final top up, or forgetting the earlier water altogether.",
  "C06B-third-liquid-replacement", "Three steps with two different incoming liquids; every component must be scaled by the retained fraction each time.",
  correct=r"$25$ litres",
  distractors=[(r"$28$ litres", r"Does not reduce the water in the third draw: $12 + 16$."),
               (r"$32$ litres", r"Adds up all the water poured in and ignores the draws: $16 + 16$."),
               (r"$16$ litres", r"Reports only the $16$ litres of water poured in at the last step, forgetting the $9$ litres of earlier water still present.")],
  check=_c25, values=[25, 28, 32, 16], cognitive="Application")


def _c26():
    V = symbols('V', positive=True)
    sols = solve(Eq((1 - 10 / V) ** 2, Rational(4, 9)), V)
    return [s for s in sols if s > 10][0]
q("C06-B-026", T, "Capacity of a vessel from the ratio after two equal replacements", "Medium",
  "Inverse/parameter",
  r"A vessel is full of pure milk. Joseph draws out $10$ litres and replaces it with water, mixes thoroughly, and does this once more. The ratio of milk to water in the vessel is now $4 : 5$. What is the capacity of the vessel?",
  "MCQ",
  r"Milk is now $\frac{4}{9}$ of the vessel, so $\left(1 - \frac{10}{V}\right)^2 = \frac{4}{9}$ and $1 - \frac{10}{V} = \frac{2}{3}$. Hence $\frac{10}{V} = \frac{1}{3}$ and $V = 30$ litres.",
  "Treating the two draws as linear, or as a single draw.",
  "C06B-find-capacity", "Inverse use of the replacement formula with the capacity unknown.",
  correct=r"$30$ litres",
  distractors=[(r"$36$ litres", r"Assumes the draws remove milk linearly: $\frac{20}{V} = \frac{5}{9}$."),
               (r"$18$ litres", r"Treats it as one draw: $\frac{10}{V} = \frac{5}{9}$."),
               (r"$15$ litres", r"Takes the retained fraction as the drawn fraction: $\frac{10}{V} = \frac{2}{3}$.")],
  check=_c26, values=[30, 36, 18, 15], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT

def _c27():
    s = {"m": Fraction(256), "w": Fraction(0)}
    for _ in range(2):
        s = _rep(s, 64, {"w": 64})
        s = _rep(s, 64, {"m": 64})
    return s["w"]
q("C06-B-027", T, "Water after two cycles of water replacement followed by milk replacement", "Difficult",
  "Multi-step word problem",
  r"A drum holds $256$ litres of pure milk. One cycle consists of two steps: first $64$ litres is drawn out and replaced with water, then, after mixing, $64$ litres is drawn out and replaced with pure milk. The contents are mixed thoroughly after every step. How many litres of water are in the drum after $2$ complete cycles?",
  "TITA",
  r"Each draw is a quarter of the drum, so it keeps $\frac{3}{4}$ of every liquid present; only the water step adds water. Cycle $1$: water becomes $64$, then $\frac{3}{4} \times 64 = 48$. Cycle $2$: water becomes $\frac{3}{4} \times 48 + 64 = 100$, then $\frac{3}{4} \times 100 = 75$. In general one cycle sends water $w$ to $\frac{3}{4}\left(\frac{3}{4}w + 64\right)$, so $75$ litres of water remain.",
  "Believing that the milk step cancels the water step, or stopping after one cycle.",
  "C06B-alternating-replacement", "Four draws with a non-half retained fraction and alternating incoming liquids; the water must be scaled by $\\frac{3}{4}$ at every draw, including the milk steps, through a two-step recurrence.",
  tita_answer=75, check=_c27, values=[75],
  tita_traps=[(48, r"Stops after the first cycle."),
              (100, r"Stops after the water step of the second cycle."),
              (0, r"Assumes each milk step undoes the preceding water step.")],
  cognitive="Analysis", exams=HARD)


def _c28():
    s = {"a": Fraction(40), "w": Fraction(10)}
    n = 0
    while not 100 * s["a"] / (s["a"] + s["w"]) < 35:
        s = _rep(s, 10, {"a": 2, "w": 8})
        n += 1
    return n
q("C06-B-028", T, "Least number of replacements with a weaker solution to fall below a strength", "Difficult",
  "Casework/optimisation",
  r"A tank holds $50$ litres of an $80\%$ acid solution (by volume). In each operation, $10$ litres of the solution is drawn out and replaced with $10$ litres of a $20\%$ acid solution, with thorough mixing. What is the least number of operations after which the acid concentration in the tank is below $35\%$?",
  "TITA",
  r"Each operation multiplies the excess of the concentration over $20\%$ by $\frac{4}{5}$, so after $n$ operations it is $20 + 60\left(\frac{4}{5}\right)^n$ percent. We need $60\left(\frac{4}{5}\right)^n < 15$, that is $\left(\frac{4}{5}\right)^n < \frac{1}{4}$. Since $\left(\frac{4}{5}\right)^6 \approx 0.262$ and $\left(\frac{4}{5}\right)^7 \approx 0.210$, the answer is $7$.",
  "Treating the incoming solution as water, which makes the strength fall much faster.",
  "C06B-min-operations-threshold", "Needs the excess-over-incoming-strength model and careful powers near the boundary.",
  tita_answer=7, check=_c28, values=[7],
  tita_traps=[(4, r"Treats the incoming liquid as water, $80\left(\frac{4}{5}\right)^n < 35$, or assumes a fixed fall of $12$ points per operation; both give $4$.")],
  cognitive="Analysis", exams=HARD)


def _c29():
    p = symbols('p', positive=True)
    s = {"salt": Integer(6), "w": Integer(24)}
    for _ in range(2):
        s = {k: v * Rational(4, 5) for k, v in s.items()}
        s["salt"] += 6 * p / 100
        s["w"] += 6 - 6 * p / 100
    return solve(Eq(100 * s["salt"] / 30, Rational(344, 10)), p)[0]
q("C06-B-029", T, "Strength of the incoming solution from the final concentration", "Difficult",
  "Inverse/parameter",
  r"A container holds $30$ litres of a $20\%$ salt solution (by volume). Twice in succession, $6$ litres of the solution is drawn out and replaced with $6$ litres of another salt solution of fixed strength, with thorough mixing after each step. The final concentration is $34.4\%$. What is the strength of the solution that was poured in?",
  "MCQ",
  r"Let the incoming strength be $p\%$. Each step multiplies the gap between the tank's strength and $p$ by $\frac{4}{5}$, so after two steps $c = p + (20 - p)\left(\frac{4}{5}\right)^2 = 0.36p + 12.8$. Setting $0.36p + 12.8 = 34.4$ gives $p = 60$, so the strength is $60\%$.",
  "Not decaying the original salt, or modelling two steps as one larger linear replacement.",
  "C06B-replace-with-solution", "Inverse of the replacement-with-solution formula; three plausible mis-models give clean wrong answers.",
  correct=r"$60\%$",
  distractors=[(r"$92\%$", r"Uses only one replacement: $0.8 \times 20 + 0.2p = 34.4$."),
               (r"$40\%$", r"Keeps the original $20\%$ undiminished: $20 + 0.36p = 34.4$."),
               (r"$56\%$", r"Treats the two draws as replacing $\frac{2}{5}$ of the tank at once: $0.6 \times 20 + 0.4p = 34.4$.")],
  check=_c29, values=[60, 92, 40, 56], cognitive="Analysis", exams=HARD)


def _c30():
    x = symbols('x', positive=True)
    sols = solve(Eq(100 * (1 - x / 100) * (1 - 2 * x / 100), 28), x)
    return [s for s in sols if 2 * s < 100][0]
q("C06-B-030", T, "First draw from the milk left after two draws, the second twice the first", "Difficult",
  "Inverse/parameter",
  r"A $100$ litre vessel is full of pure milk. Ravi draws out some milk and replaces it with water. After mixing, he draws out twice that volume of the mixture and replaces it with water. The vessel now contains $28$ litres of milk. How many litres did he draw out the first time?",
  "MCQ",
  r"If the first draw is $x$ litres, $100\left(1 - \frac{x}{100}\right)\left(1 - \frac{2x}{100}\right) = 28$, that is $(100 - x)(100 - 2x) = 2800$, or $x^2 - 150x + 3600 = 0 = (x - 30)(x - 120)$. The second draw $2x$ cannot exceed $100$ litres, so $x = 30$ litres.",
  "Reading the given $28$ litres as water, reporting the second draw, or treating removals as linear.",
  "C06B-unequal-draws", "Quadratic from two different factors, with one root rejected by a physical constraint.",
  correct=r"$30$ litres",
  distractors=[(r"$10$ litres", r"Takes $28$ litres as the water, so milk is $72$: $(100 - x)(100 - 2x) = 7200$ gives $x = 10$."),
               (r"$60$ litres", r"Reports the second draw $2x$."),
               (r"$24$ litres", r"Assumes the draws remove milk linearly: $100 - 3x = 28$.")],
  check=_c30, values=[30, 10, 60, 24], cognitive="Analysis", exams=HARD)


def _c31():
    x = symbols('x', positive=True)
    s = {"m": Integer(60), "w": Integer(0)}
    s = {"m": s["m"] * Rational(48, 60), "w": s["w"] + 24}          # draw 12 of 60, add 24 water
    tot = s["m"] + s["w"]
    k = 1 - x / tot
    sols = solve(Eq(7 * s["m"] * k, 6 * (s["w"] * k + 24)), x)
    return [v for v in sols if 0 < v < tot][0]
q("C06-B-031", T, "Volume of the second draw from the final ratio when more water is added than is drawn", "Difficult",
  "Inverse/parameter",
  r"A large tank contains $60$ litres of pure milk. Harpreet draws out $12$ litres and pours in $24$ litres of water. After mixing, she draws out some of the mixture and pours in another $24$ litres of water, and mixes again. The ratio of milk to water in the tank is now $6 : 7$. How many litres did she draw out the second time?",
  "MCQ",
  r"After the first step the tank has $48$ litres of milk and $24$ of water, $72$ litres in all. If the second draw keeps a fraction $k$ of the tank, milk is $48k$ and water is $24k + 24$. Then $7 \times 48k = 6(24k + 24)$ gives $192k = 144$, so $k = \frac{3}{4}$. The draw removed $\frac{1}{4}$ of $72$ litres, that is $18$ litres.",
  "Taking the tank volume before the second draw as the original $60$ litres (or $84$ litres), or reporting the volume kept.",
  "C06B-draw-and-add-unequal", "Inverse unknown on a tank whose volume changes every step; both components shrink in the draw and water is then topped up, so the set-up needs care before a linear solve.",
  correct=r"$18$ litres",
  distractors=[(r"$15$ litres", r"Uses $60$ litres as the tank volume before the second draw: $\frac{x}{60} = \frac{1}{4}$."),
               (r"$21$ litres", r"Forgets that $12$ litres was drawn first and takes the volume as $60 + 24 = 84$: $\frac{x}{84} = \frac{1}{4}$."),
               (r"$54$ litres", r"Reports the volume kept in the tank, $\frac{3}{4} \times 72$, instead of the volume drawn.")],
  check=_c31, values=[18, 15, 21, 54], cognitive="Analysis", exams=HARD)


def _c32():
    for x in range(1, 40):
        s = {"m": Fraction(40), "w": Fraction(0)}
        for _ in range(3):
            s = _rep(s, x, {"w": x})
        assert sum(s.values()) == 40
        profit = (40 - s["m"]) / s["m"]          # SP = 40 litres at milk price, CP = milk left
        if profit >= Fraction(3, 5):
            return x
q("C06-B-032", T, "Least volume per draw for a target profit after a fixed number of replacements", "Difficult",
  "Inverse/parameter",
  r"A milk vendor starts each day with a can holding $40$ litres of pure milk. He performs exactly $3$ operations; in each, he draws out the same whole number of litres from the can and replaces it with the same volume of water, then mixes thoroughly. He sells all $40$ litres of the final contents at the price per litre he paid for pure milk. Water is free, and the liquid drawn out is used at home, so his cost for the sale is only the cost of the pure milk that remains in the can when it is sold. What is the least number of litres he must draw in each operation so that his profit on the sale is at least $60\%$ of this cost?",
  "TITA",
  r"Profit of at least $60\%$ on cost means the milk left is at most $\frac{40}{1.6} = 25$ litres. If $x$ litres are drawn each time, the milk left is $40\left(\frac{40 - x}{40}\right)^3 = \frac{(40 - x)^3}{1600}$, so we need $(40 - x)^3 \le 40000$. Since $34^3 = 39304 \le 40000$ and $35^3 = 42875 > 40000$, we need $40 - x \le 34$, that is $x \ge 6$. The least volume is $6$ litres.",
  r"Setting the water share of the mixture to $60\%$, which measures profit on the selling price instead of on cost, or treating each draw as removing pure milk.",
  "C06B-replacement-profit", "Three layers: turning a profit-on-cost target into a cap on the milk left, writing that cap as a cube in the unknown draw, and locating a cube root between consecutive integers with the correct rounding direction.",
  tita_answer=6, check=_c32, values=[6],
  tita_traps=[(5, r"Treats every draw as pure milk, a linear model: $40 - 3x \le 25$ gives $x \ge 5$."),
              (11, r"Requires water to be at least $60\%$ of the can, that is milk at most $16$ litres: $(40 - x)^3 \le 25600$, so $40 - x \le 29$ and $x = 11$.")],
  cognitive="Analysis", exams=HARD)


def _c33():
    x, V = symbols('x V', positive=True)
    # milk in 2nd draw = x(1 - x/V) = 12, milk in 3rd draw = x(1 - x/V)^2 = 9
    sols = solve([Eq(x * (1 - x / V), 12), Eq(x * (1 - x / V) ** 2, 9)], [x, V], dict=True)
    return [s[V] for s in sols if s[V] > s[x] > 0][0]
q("C06-B-033", T, "Capacity from the milk contained in two successive draws", "Difficult",
  "Conceptual/application",
  r"A cask is full of pure milk. The same volume is drawn out and replaced with water several times, with thorough mixing after each step. The liquid drawn out the second time contains $12$ litres of milk, and the liquid drawn out the third time contains $9$ litres of milk. What is the capacity of the cask?",
  "MCQ",
  r"The milk in successive draws falls by the retained factor $1 - f$ each time, so $1 - f = \frac{9}{12} = \frac{3}{4}$ and $f = \frac{1}{4}$. The first draw is pure milk, so its volume is $\frac{12}{3/4} = 16$ litres. That is a quarter of the cask, so the capacity is $64$ litres.",
  "Equating a later draw's milk to a quarter of the cask, as if that draw were pure milk.",
  "C06B-kth-draw-content", "Must see that draw contents form a geometric sequence and work back to the first draw.",
  correct=r"$64$ litres",
  distractors=[(r"$48$ litres", r"Treats $12$ litres as a quarter of the cask, so $V = 48$."),
               (r"$16$ litres", r"Reports the volume drawn each time instead of the capacity."),
               (r"$36$ litres", r"Treats $9$ litres as a quarter of the cask, so $V = 36$.")],
  check=_c33, values=[64, 48, 16, 36], cognitive="Analysis", exams=HARD)


def _c34():
    V = symbols('V', positive=True)
    sols = solve(Eq(V * (1 - 12 / V) ** 2, 27), V)
    return [s for s in sols if s > 12][0]
q("C06-B-034", T, "Capacity from the milk left after two replacements of a fixed volume", "Difficult",
  "Inverse/parameter",
  r"A vessel is full of pure milk. Ananya draws out $12$ litres and replaces it with water, mixes thoroughly, and does this once more. The vessel now contains $27$ litres of milk. What is the capacity of the vessel, in litres?",
  "TITA",
  r"With capacity $V$, milk left is $V\left(1 - \frac{12}{V}\right)^2 = \frac{(V - 12)^2}{V} = 27$. So $V^2 - 51V + 144 = 0 = (V - 48)(V - 3)$. A $3$ litre vessel cannot supply a $12$ litre draw, so $V = 48$ litres.",
  "Subtracting $24$ litres of milk directly, or not rejecting the impossible root.",
  "C06B-find-capacity", "Unknown capacity leads to a quadratic with a root that must be rejected.",
  tita_answer=48, check=_c34, values=[48],
  tita_traps=[(51, r"Assumes both draws are pure milk: $V - 24 = 27$."),
              (39, r"Treats it as one draw: $V - 12 = 27$."),
              (3, r"Keeps the other root of the quadratic without checking it against the $12$ litre draw.")],
  cognitive="Analysis", exams=HARD)


def _c35():
    # second draw of x litres contains 8 L milk and 2 L water -> x = 10, water fraction x/V = 2/10 -> V = 50
    x = 8 + 2
    V = x / Fraction(2, x)
    s = {"m": Fraction(V), "w": Fraction(0)}
    for _ in range(3):
        s = _rep(s, x, {"w": x})
    return s["m"] / s["w"]
q("C06-B-035", T, "Inferring draw size and capacity from one draw, then the ratio after three replacements", "Difficult",
  "Conceptual/application",
  r"A barrel is full of pure milk. A fixed volume is drawn out and replaced with water, and this is done $3$ times in all, with thorough mixing after each step. The liquid drawn out the second time contains $8$ litres of milk and $2$ litres of water. What is the ratio of milk to water in the barrel after the third replacement?",
  "MCQ",
  r"The second draw is $10$ litres, so each draw is $10$ litres. Before the second draw the barrel's water was exactly the $10$ litres added in the first step, and it made up $\frac{2}{10} = \frac{1}{5}$ of the barrel, so the capacity is $50$ litres. After $3$ replacements milk is $50 \times \left(\frac{4}{5}\right)^3 = 25.6$ litres and water $24.4$ litres, giving $25.6 : 24.4 = 64 : 61$.",
  "Stopping at the state after two replacements, or giving milk to total.",
  "C06B-infer-from-draw-composition", "The capacity is hidden: it must be inferred from the composition of one draw before the replacement formula applies.",
  correct=r"$64 : 61$",
  distractors=[(r"$16 : 9$", r"Gives the ratio after two replacements: milk $32$, water $18$."),
               (r"$4 : 1$", r"Uses the composition of the second draw, which is the state after one replacement."),
               (r"$64 : 125$", r"Reports milk : total, $\left(\frac{4}{5}\right)^3$.")],
  check=_c35, values=[Fraction(64, 61), Fraction(16, 9), 4, Fraction(64, 125)], cognitive="Analysis", exams=HARD)
