import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Ratio puzzles"
HARD = ("CAT", "XAT")


def _pos(sol, var):
    """Return the unique solution value of var from a sympy solve() result list of dicts."""
    vals = [s[var] for s in sol]
    assert len(vals) == 1, vals
    return vals[0]


# ---------------------------------------------------------------- EASY

def _e1():
    k = symbols('k', positive=True)
    s = solve(Eq(5 * (5 * k - 12), 3 * (3 * k + 12)), k, dict=True)
    return 5 * _pos(s, k)
q("C04-D-001", T, "Transfer from one group to another reverses the ratio; find an original count", "Easy",
  "Multi-step word problem",
  r"Two examination halls hold candidates in the ratio $5 : 3$. When $12$ candidates are shifted from the first hall to the second, and no one else enters or leaves, the ratio of candidates in the first hall to the second becomes $3 : 5$. How many candidates were in the first hall originally?",
  "MCQ",
  r"Let the halls hold $5k$ and $3k$. After the shift, $\frac{5k - 12}{3k + 12} = \frac{3}{5}$, so $25k - 60 = 9k + 36$, giving $16k = 96$ and $k = 6$. The first hall had $5k = 30$ candidates. (Quick view: the total $8k$ is fixed and the first hall falls from $5$ to $3$ of the $8$ parts, so $2$ parts $= 12$.)",
  "Treating the shift of 12 as covering the whole swing from +2 parts to -2 parts, or reporting a count after the shift.",
  "C04D-transfer-two-groups", "One transfer equation; the trap is how many parts the 12 candidates represent.",
  correct=r"$30$",
  distractors=[(r"$18$", "Reports the first hall's count after the shift (or the second hall's original count)."),
               (r"$48$", "Reports the total number of candidates in both halls."),
               (r"$15$", "Takes $12$ candidates as the full swing of $4$ parts in the difference ($+2$ to $-2$), so one part is $3$ and the first hall is $5 \\times 3 = 15$.")],
  check=_e1, values=[30, 18, 48, 15], cognitive="Application")


def _e2():
    # simulate the halt for every multiplier and keep the one that ends equal
    out = []
    for k in range(1, 500):
        first, second = 7 * k, 5 * k
        first -= 6; second += 6        # shift between the buses
        second += 12                   # new passengers board the second bus
        if first == second:
            out.append(7 * k)
    assert len(out) == 1
    return out[0]
q("C04-D-002", T, "A transfer between two groups plus newcomers to one group; recover an original count", "Easy",
  "Multi-step word problem",
  r"Two buses carry passengers in the ratio $7 : 5$. At a halt, $6$ passengers move from the first bus to the second, and $12$ new passengers board the second bus; nobody gets off and nobody else boards. The two buses now carry equal numbers of passengers. How many passengers were in the first bus before the halt?",
  "TITA",
  r"Let the buses carry $7k$ and $5k$. After the halt the first bus has $7k - 6$ and the second has $5k + 6 + 12 = 5k + 18$. Equal numbers give $2k = 24$, so $k = 12$ and the first bus had $7k = 84$ passengers (afterwards $78$ in each bus).",
  "Letting the shifted passengers change only one bus, or reporting a count after the halt.",
  "C04D-transfer-plus-outside-change", "One equation, but the shift changes both buses while the newcomers change only one.",
  tita_answer=84, check=_e2,
  tita_traps=[(63, "Subtracts the $6$ from the first bus but does not add them to the second: $7k - 6 = 5k + 12$ gives $k = 9$."),
              (78, "Reports the first bus's count after the halt."),
              (144, "Reports the original total in both buses.")],
  cognitive="Application")


def _e3():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(7 * x - 3 * y, 10000), Eq(5 * x - 2 * y, 8000)], [x, y], dict=True)
    return 2 * _pos(s, y)
q("C04-D-003", T, "Incomes and expenditures in given ratios with two different savings; find an expenditure", "Easy",
  "Multi-step word problem",
  r"The monthly incomes of Harpreet and Joseph are in the ratio $7 : 5$, and their monthly expenditures are in the ratio $3 : 2$. Harpreet saves Rs. $10{,}000$ a month and Joseph saves Rs. $8{,}000$ a month. What is Joseph's monthly expenditure?",
  "MCQ",
  r"Let the incomes be $7x$, $5x$ and the expenditures $3y$, $2y$. Then $7x - 3y = 10000$ and $5x - 2y = 8000$. Doubling the first and tripling the second gives $14x - 6y = 20000$ and $15x - 6y = 24000$, so $x = 4000$ and $3y = 28000 - 10000$, $y = 6000$. Joseph spends $2y = $ Rs. $12{,}000$ (he earns Rs. $20{,}000$; Harpreet earns Rs. $28{,}000$ and spends Rs. $18{,}000$).",
  "Using one multiplier for both income and expenditure, or reading off the wrong person's figure.",
  "C04D-income-expenditure-savings", "Two linear equations from two ratios with different multipliers.",
  correct=r"Rs. $12{,}000$",
  distractors=[(r"Rs. $20{,}000$", "Reports Joseph's income."),
               (r"Rs. $18{,}000$", "Reports Harpreet's expenditure."),
               (r"Rs. $5{,}000$", "Uses one multiplier for income and expenditure with Harpreet's data: $7 - 3 = 4$ parts $= 10000$, one part $2500$, Joseph's expenditure $2 \\times 2500$.")],
  check=_e3, values=[12000, 20000, 18000, 5000], cognitive="Application")


def _e4():
    x, r = symbols('x r', positive=True)
    kabir_inc, priya_inc = 3 * x, 2 * x
    kabir_exp = kabir_inc * Rational(80, 100)
    priya_exp = kabir_exp / 2                      # expenditures in the ratio 2 : 1
    s = solve(Eq(priya_inc * (1 - r / 100), priya_exp), r, dict=True)
    return _pos(s, r)
q("C04-D-004", T, "Income and expenditure ratios with one saving rate; find the other saving rate", "Easy",
  "Multi-step word problem",
  r"The monthly incomes of Kabir and Priya are in the ratio $3 : 2$, and their monthly expenditures are in the ratio $2 : 1$. Kabir saves $20\%$ of his income. What percentage of her income does Priya save? Enter the number of percent.",
  "TITA",
  r"Take the incomes as $3$ and $2$ units. Kabir spends $80\%$ of $3$, that is $2.4$ units, so Priya spends half of that, $1.2$ units, out of her $2$ units. She spends $60\%$ and saves $40\%$ of her income.",
  "Assuming both save the same share of income, or reporting the share spent.",
  "C04D-income-saving-percent", "Turn one saving rate into an expenditure, scale it by the expenditure ratio, compare with the other income.",
  tita_answer=40, check=_e4,
  tita_traps=[(20, "Assumes Priya saves the same share as Kabir."),
              (60, "Reports the share of her income that Priya spends."),
              (25, "Applies the $2 : 1$ ratio to Kabir's income instead of his expenditure: Priya spends $1.5$ of her $2$ units, $75\\%$, and saves $25\\%$.")],
  cognitive="Application")


def _e5():
    k = symbols('k', positive=True)
    s = solve(Eq(5 * k * Rational(6, 5) + 4 * k * Rational(5, 4), 1100), k, dict=True)
    return 4 * _pos(s, k)
q("C04-D-005", T, "Two groups grow by different percentages; recover an original count from the new total", "Easy",
  "Multi-step word problem",
  r"Last year the numbers of boys and girls in a school were in the ratio $5 : 4$. This year the number of boys has increased by $20\%$ and the number of girls by $25\%$, and the school now has $1{,}100$ students. How many girls were there in the school last year?",
  "TITA",
  r"Take last year's numbers as $5k$ boys and $4k$ girls. This year there are $1.2 \times 5k = 6k$ boys and $1.25 \times 4k = 5k$ girls, so $11k = 1100$ and $k = 100$. Last year there were $4k = 400$ girls.",
  "Answering with this year's count, or splitting the new total in the old ratio.",
  "C04D-percent-change-in-groups", "Each group scales to a whole number of parts; one division finishes it.",
  tita_answer=400, check=_e5,
  tita_traps=[(500, "Reports this year's number of girls."), (900, "Reports last year's total strength.")],
  cognitive="Application")


def _e6():
    k = symbols('k', positive=True)
    s = solve(Eq(4 * 5 * k, 5 * (3 * k + 8)), k, dict=True)
    return 5 * _pos(s, k)
q("C04-D-006", T, "Only one group changes; new ratio gives the unchanged group", "Easy",
  "Multi-step word problem",
  r"On a bus, the numbers of men and women are in the ratio $5 : 3$. At the next stop $8$ women get on and nobody gets off. The ratio of men to women is now $5 : 4$. How many men are on the bus?",
  "MCQ",
  r"The number of men is unchanged, so keep it as $5$ parts in both ratios. Women go from $3$ parts to $4$ parts, so $1$ part $= 8$. Men $= 5 \times 8 = 40$.",
  "Thinking both ratio terms change, or answering with the number of women.",
  "C04D-change-one-group", "Fixed group keeps the same number of parts, so one part equals the newcomers.",
  correct=r"$40$",
  distractors=[(r"$24$", "Reports the number of women before the stop."),
               (r"$32$", "Reports the number of women after the stop."),
               (r"$64$", "Reports the total number of passengers before the stop.")],
  check=_e6, values=[40, 24, 32, 64], cognitive="Understanding")


def _e7():
    # test each offered amount for Joseph's original savings against both strict conditions
    ok = []
    for joseph in (4500, 5000, 1000, 5500):
        sneha = Fraction(3 * joseph, 5)
        r = (sneha + 1000) / (joseph + 3000)
        if Fraction(2, 5) < r < Fraction(1, 2):
            ok.append(joseph)
    assert len(ok) == 1
    return ok[0]
q("C04-D-007", T, "Unequal additions to two amounts in a ratio; range of the original amount from two strict bounds", "Medium",
  "Casework/optimisation",
  r"The savings of Sneha and Joseph are in the ratio $3 : 5$. Sneha adds Rs. $1{,}000$ to her savings and Joseph adds Rs. $3{,}000$ to his. After the additions Sneha's savings are less than half of Joseph's but more than two-fifths of Joseph's. Which of the following could have been Joseph's savings before the additions?",
  "MCQ",
  r"Let the savings be $3k$ and $5k$. Less than half: $2(3k + 1000) < 5k + 3000$, so $k < 1000$. More than two-fifths: $5(3k + 1000) > 2(5k + 3000)$, so $5k > 1000$. Hence Joseph's original savings $5k$ lie strictly between Rs. $1{,}000$ and Rs. $5{,}000$, and of the values offered only Rs. $4{,}500$ fits (then Sneha has Rs. $2{,}700$, and $3700 : 7500$ lies between $\frac{2}{5}$ and $\frac{1}{2}$).",
  "Treating a strict bound as allowing equality, or reversing an inequality while solving.",
  "C04D-range-possible-values", "Two strict inequalities on the multiplier, each with unequal additions, and both endpoints are traps.",
  correct=r"Rs. $4{,}500$",
  distractors=[(r"Rs. $5{,}000$", "Allows equality in the first condition: at $k = 1000$ the ratio is exactly $4000 : 8000 = 1 : 2$, which the stem excludes."),
               (r"Rs. $1{,}000$", "Allows equality in the second condition: at $k = 200$ the ratio is exactly $1600 : 4000 = 2 : 5$, which the stem excludes."),
               (r"Rs. $5{,}500$", "Reverses the first inequality while solving, reading it as $k > 1000$; at $k = 1100$ Sneha has $4300$ against $8500$, more than half.")],
  check=_e7, values=[4500, 5000, 1000, 5500], cognitive="Analysis")


def _e8():
    for k in range(1, 1000):
        men, women = 4 * k, 3 * k
        if men + 20 == women + 40:
            return men + women
q("C04-D-008", T, "Newcomers join in their own ratio and equalise the groups", "Easy",
  "Conceptual/application",
  r"A club's members are men and women in the ratio $4 : 3$. Then $60$ new members join, with men and women among the newcomers in the ratio $1 : 2$. After this the club has equal numbers of men and women. How many members did the club have before the newcomers joined?",
  "MCQ",
  r"The newcomers are $20$ men and $40$ women. With $4k$ men and $3k$ women originally, $4k + 20 = 3k + 40$, so $k = 20$. The club had $7k = 140$ members (then $100$ men and $100$ women).",
  "Reporting the strength after joining, or one gender's count.",
  "C04D-joining-in-a-ratio", "Split the newcomers first; then the gap of k closes by 20.",
  correct=r"$140$",
  distractors=[(r"$200$", "Reports the club's strength after the newcomers joined."),
               (r"$80$", "Reports the original number of men."),
               (r"$60$", "Reports the original number of women.")],
  check=_e8, values=[140, 200, 80, 60], cognitive="Application")


def _e9():
    k = symbols('k', positive=True)
    s = solve(Eq(7 * k + 6000, 2 * 5 * k), k, dict=True)
    kk = _pos(s, k)
    return 7 * kk - 5 * kk
q("C04-D-009", T, "Income rises with expenditure fixed; find the original savings", "Easy",
  "Multi-step word problem",
  r"Priya's monthly income and expenditure are in the ratio $7 : 5$. Her income then increases by Rs. $6{,}000$ while her expenditure stays the same, and the ratio of her income to expenditure becomes $2 : 1$. What were her monthly savings before the increase?",
  "MCQ",
  r"Let income $= 7k$ and expenditure $= 5k$. Then $7k + 6000 = 2 \times 5k$, so $3k = 6000$ and $k = 2000$. The original savings were $7k - 5k = 2k = $ Rs. $4{,}000$.",
  "Reporting the savings after the raise, or the income.",
  "C04D-income-expenditure-one-person", "One equation with expenditure as the fixed anchor.",
  correct=r"Rs. $4{,}000$",
  distractors=[(r"Rs. $10{,}000$", "Reports the savings after the increase ($20000 - 10000$)."),
               (r"Rs. $14{,}000$", "Reports the original income."),
               (r"Rs. $2{,}000$", "Reports the multiplier $k$ as the savings.")],
  check=_e9, values=[4000, 10000, 14000, 2000], cognitive="Application")


def _e10():
    sols = [2 * k for k in range(1, 100) if 40 < 5 * k < 50]
    assert len(sols) == 1
    return sols[0]
q("C04-D-010", T, "Ratio plus a strict range fixes the class strength", "Easy",
  "Casework/optimisation",
  r"In a class the ratio of boys to girls is $3 : 2$. The class has more than $40$ and fewer than $50$ students. How many girls are in the class?",
  "TITA",
  r"The strength is $5k$, a multiple of $5$, strictly between $40$ and $50$. The only such number is $45$, so $k = 9$ and there are $2k = 18$ girls.",
  "Allowing 40 or 50, or reporting boys.",
  "C04D-integer-total-constraint", "Divisibility by the ratio sum plus a strict window.",
  tita_answer=18, check=_e10,
  tita_traps=[(27, "Reports the number of boys."), (20, "Allows a strength of $50$, which the stem excludes."), (16, "Allows a strength of $40$, which the stem excludes.")],
  cognitive="Understanding")


def _e11():
    a, b = Fraction(9), Fraction(4)
    moved = a / 3
    return (a - moved) / (b + moved)
q("C04-D-011", T, "A fraction of one group moves to the other; new ratio", "Easy",
  "Conceptual/application",
  r"Two baskets hold mangoes in the ratio $9 : 4$. One-third of the mangoes in the first basket are moved into the second basket. What is now the ratio of mangoes in the first basket to the second?",
  "MCQ",
  r"Take $9$ and $4$ units. One-third of $9$ is $3$, so the first basket keeps $6$ and the second gets $4 + 3 = 7$. The ratio is $6 : 7$.",
  "Changing only one basket, or reversing the order.",
  "C04D-fraction-transferred", "One move applied to both sides of the ratio.",
  correct=r"$6 : 7$",
  distractors=[(r"$3 : 2$", "Removes $3$ from the first basket but does not add them to the second: $6 : 4$."),
               (r"$7 : 6$", "Writes the new ratio in the reverse order."),
               (r"$9 : 7$", "Adds $3$ to the second basket but does not remove them from the first.")],
  check=_e11, values=[Fraction(6, 7), Fraction(3, 2), Fraction(7, 6), Fraction(9, 7)], cognitive="Understanding")


# ---------------------------------------------------------------- MEDIUM

def _m1():
    t = symbols('t', positive=True)
    first, second = Rational(11, 18) * 900, Rational(7, 18) * 900
    s = solve(Eq(5 * (first - t), 4 * (second + t)), t, dict=True)
    return _pos(s, t)
q("C04-D-012", T, "Find the transfer that produces a target ratio", "Easy",
  "Inverse/parameter",
  r"Two warehouses hold a total of $900$ bags of cement in the ratio $11 : 7$. How many bags must be moved from the first warehouse to the second so that the ratio of bags in the first to the second becomes $4 : 5$?",
  "MCQ",
  r"Now the warehouses hold $\frac{11}{18} \times 900 = 550$ and $350$. The total stays $900$, so the target is $\frac{4}{9} \times 900 = 400$ and $500$. The first warehouse must give up $550 - 400 = 150$ bags.",
  "Reading the target ratio in reverse, or aiming to equalise.",
  "C04D-transfer-two-groups", "Split a fixed total twice and compare.",
  correct=r"$150$",
  distractors=[(r"$100$", "Moves enough bags to make the two warehouses equal ($450$ each)."),
               (r"$50$", "Reads the target as $5 : 4$, i.e. $500$ and $400$, so moves $550 - 500$."),
               (r"$400$", "Reports the first warehouse's holding after the move.")],
  check=_m1, values=[150, 100, 50, 400], cognitive="Application")


def _m2():
    r, s_ = symbols('r s', positive=True)
    sol = solve([Eq(r - 200, s_ + 200), Eq(3 * (r + 200), 7 * (s_ - 200))], [r, s_], dict=True)
    return _pos(sol, r)
q("C04-D-013", T, "Two alternative transfers give two ratios; find one amount", "Medium",
  "Multi-step word problem",
  r"If Ravi gives Rs. $200$ to Sneha, they will have equal amounts of money. If instead Sneha gives Rs. $200$ to Ravi, the ratio of Ravi's money to Sneha's will be $7 : 3$. How much money does Ravi have?",
  "MCQ",
  r"The first condition gives $r - 200 = s + 200$, so $r = s + 400$. The second gives $3(r + 200) = 7(s - 200)$, that is $3(s + 600) = 7s - 1400$, so $4s = 3200$ and $s = 800$. Ravi has Rs. $1{,}200$ (check: $1400 : 600 = 7 : 3$).",
  "Taking the gap between them as Rs. 200 rather than Rs. 400.",
  "C04D-alternative-transfers", "Two hypothetical transfers, each changing both amounts; the gap is twice the transfer.",
  correct=r"Rs. $1{,}200$",
  distractors=[(r"Rs. $800$", "Reports Sneha's money."),
               (r"Rs. $2{,}000$", "Reports the combined money of both."),
               (r"Rs. $850$", "Takes Ravi's excess as Rs. $200$: $3(s + 400) = 7(s - 200)$ gives $s = 650$, so $r = 850$.")],
  check=_m2, values=[1200, 800, 2000, 850], cognitive="Application")


def _m3():
    sols = []
    for m in range(0, 361):
        a = 360 - m
        for x in range(1, 361):
            if m - x > 0 and a - x > 0 and 2 * (m - x) == a + x and 4 * (m + x) == 5 * (a - x):
                sols.append(x)
    assert len(sols) == 1
    return sols[0]
q("C04-D-014", T, "Same transfer in either direction with a fixed total", "Medium",
  "Inverse/parameter",
  r"Meera and Arjun have $360$ stickers between them. If Meera gives $x$ stickers to Arjun, the ratio of Meera's stickers to Arjun's becomes $1 : 2$. If instead Arjun gives $x$ stickers to Meera, the ratio of Meera's stickers to Arjun's becomes $5 : 4$. What is the value of $x$?",
  "TITA",
  r"The total stays $360$ in both cases. In the first case Meera ends with $\frac{1}{3} \times 360 = 120$, so $m - x = 120$. In the second she ends with $\frac{5}{9} \times 360 = 200$, so $m + x = 200$. Subtracting, $2x = 80$ and $x = 40$ (Meera has $160$, Arjun $200$).",
  "Answering with Meera's count or with 2x.",
  "C04D-alternative-transfers", "Uses the conserved total to turn both ratios into Meera's counts.",
  tita_answer=40, check=_m3,
  tita_traps=[(80, "Reports $2x$, the difference $200 - 120$."), (160, "Reports Meera's number of stickers.")],
  cognitive="Analysis")


def _m4():
    # work forward from every candidate start and keep the one that matches
    sols = []
    for a in range(2, 301, 2):
        for p in range(0, 301):
            if a + p != 150:
                continue
            A, P = Fraction(a), Fraction(p)
            g = A / 2; A -= g; P += g
            h = P / 3; P -= h; A += h
            if 2 * A == 3 * P:
                sols.append(a)
    assert len(sols) == 1
    return sols[0]
q("C04-D-015", T, "Two successive fractional transfers; work backwards from the final ratio", "Medium",
  "Multi-step word problem",
  r"Arjun and Priya have $150$ marbles between them. Arjun first gives half of his marbles to Priya. Priya then gives one-third of the marbles she has at that moment to Arjun. Now the ratio of Arjun's marbles to Priya's is $3 : 2$. How many marbles did Arjun have at the start?",
  "TITA",
  r"At the end Arjun has $90$ and Priya $60$. Priya kept two-thirds of what she had, so before her gift she had $90$ and gave $30$; Arjun then had $90 - 30 = 60$. That $60$ is half of Arjun's starting stock, so he began with $120$ (and Priya with $30$).",
  "Undoing only one of the two transfers.",
  "C04D-successive-transfers-backwards", "Two reverse steps, each with a fraction of a changed amount.",
  tita_answer=120, check=_m4,
  tita_traps=[(60, "Stops after undoing Priya's gift and reports Arjun's count at that stage."), (90, "Reports Arjun's final count.")],
  cognitive="Analysis")


def _m5():
    x, y = symbols('x y', positive=True)
    s = solve([Eq(5 * x, 30000), Eq(2 * (5 * x - 7 * y), 4 * x - 5 * y)], [x, y], dict=True)
    return 5 * s[0][y]
q("C04-D-016", T, "Incomes, expenditures and savings all in ratios; find an expenditure", "Medium",
  "Multi-step word problem",
  r"The monthly incomes of Fatima and Ananya are in the ratio $5 : 4$, their monthly expenditures are in the ratio $7 : 5$, and their monthly savings are in the ratio $1 : 2$. Fatima's monthly income is Rs. $30{,}000$. What is Ananya's monthly expenditure?",
  "MCQ",
  r"The income multiplier is $x = 6000$, so the incomes are Rs. $30{,}000$ and Rs. $24{,}000$. With expenditures $7y$ and $5y$, the savings condition gives $2(30000 - 7y) = 24000 - 5y$, so $9y = 36000$ and $y = 4000$. Ananya spends $5y = $ Rs. $20{,}000$ (savings Rs. $2{,}000$ and Rs. $4{,}000$).",
  "Reversing the savings ratio, or reading off the wrong person's figure.",
  "C04D-income-expenditure-savings", "Three ratios with two multipliers; the savings ratio links them.",
  correct=r"Rs. $20{,}000$",
  distractors=[(r"Rs. $28{,}000$", "Reports Fatima's expenditure $7y$."),
               (r"Rs. $24{,}000$", "Reports Ananya's income."),
               (r"Rs. $4{,}000$", "Reports Ananya's monthly savings, $24000 - 20000$, which also equals the multiplier $y$.")],
  check=_m5, values=[20000, 28000, 24000, 4000], cognitive="Application")


def _m6():
    # general incomes 4a, 3a and savings 5s, 3s (any a, s with positive expenditures)
    a, s = symbols('a s', positive=True)
    inc = [4 * a, 3 * a]
    sav = [5 * s, 3 * s]
    exp_ = [i - v for i, v in zip(inc, sav)]
    g = [Rational(11, 10), Rational(13, 10)]
    new_sav = [g[i] * inc[i] - g[i] * exp_[i] for i in range(2)]
    return simplify(new_sav[0] / new_sav[1])
q("C04-D-017", T, "Each person's income and expenditure scale together; new ratio of savings", "Medium",
  "Conceptual/application",
  r"The monthly incomes of Arjun and Fatima are in the ratio $4 : 3$, and their monthly savings are in the ratio $5 : 3$. Next year Arjun's income and his expenditure both rise by $10\%$, while Fatima's income and her expenditure both rise by $30\%$. What will be the ratio of Arjun's monthly savings to Fatima's?",
  "MCQ",
  r"Savings are income minus expenditure. When a person's income and expenditure both rise by the same percentage, the savings rise by that percentage too. So Arjun's savings become $1.1 \times 5 = 5.5$ parts and Fatima's become $1.3 \times 3 = 3.9$ parts, and the ratio is $5.5 : 3.9 = 55 : 39$. The income ratio $4 : 3$ is not needed.",
  "Applying the growth factors to the income ratio instead of the savings ratio, or assuming savings stay unchanged.",
  "C04D-proportional-scaling-savings", "One insight (equal percentage rise in income and expenditure scales savings) and a distracting income ratio.",
  correct=r"$55 : 39$",
  distractors=[(r"$44 : 39$", "Applies the growth factors to the income ratio: $4 \\times 1.1 : 3 \\times 1.3$."),
               (r"$5 : 3$", "Assumes the savings do not change because each person's income and expenditure rise together."),
               (r"$65 : 33$", "Swaps the growth factors: $5 \\times 1.3 : 3 \\times 1.1$.")],
  check=_m6, values=[Rational(55, 39), Rational(44, 39), Rational(5, 3), Rational(65, 33)], cognitive="Analysis")


def _m7():
    b, g = symbols('b g', positive=True)
    return solve(Eq(3 * b * Rational(5, 4), 5 * g * Rational(9, 10)), b)[0] / g
q("C04-D-018", T, "Find the original ratio from percentage changes and the new ratio", "Medium",
  "Inverse/parameter",
  r"In a firm, the number of men employees rises by $25\%$ and the number of women employees falls by $10\%$. After these changes the ratio of men to women employees is $5 : 3$. What was the ratio of men to women employees before the changes?",
  "MCQ",
  r"If the original counts are $m$ and $w$, then $\frac{1.25m}{0.9w} = \frac{5}{3}$, so $\frac{m}{w} = \frac{5 \times 0.9}{3 \times 1.25} = \frac{4.5}{3.75} = \frac{6}{5}$. The original ratio was $6 : 5$.",
  "Undoing a percentage change by applying the opposite percentage to the new value.",
  "C04D-percent-change-in-groups", "Reverse two different percentage changes inside a ratio.",
  correct=r"$6 : 5$",
  distractors=[(r"$25 : 22$", "Undoes the changes by taking $25\\%$ off $5$ and adding $10\\%$ to $3$: $3.75 : 3.3$."),
               (r"$22 : 15$", "Treats the $10\\%$ fall as a rise: $\\frac{5 \\times 1.1}{3 \\times 1.25}$."),
               (r"$5 : 6$", "Writes the ratio as women to men.")],
  check=_m7, values=[Rational(6, 5), Rational(25, 22), Rational(22, 15), Rational(5, 6)], cognitive="Application")


def _m8():
    f = symbols('f', positive=True)
    return solve(Eq(Rational(3, 4) * 5, 2 * f * 3), f)[0]
q("C04-D-019", T, "Fractions of two groups attend; find the unknown fraction from the attendance ratio", "Medium",
  "Inverse/parameter",
  r"At a conference the ratio of men to women delegates is $5 : 3$. Three-quarters of the men and a certain fraction of the women attend the dinner, and the ratio of men to women at the dinner is $2 : 1$. What fraction of the women delegates attend the dinner?",
  "MCQ",
  r"Take $5$ men and $3$ women. Men at the dinner $= \frac{3}{4} \times 5 = \frac{15}{4}$. Women at the dinner must be half of that, $\frac{15}{8}$, which is $\frac{15}{8} \div 3 = \frac{5}{8}$ of the women.",
  "Ignoring that only three-quarters of the men attend.",
  "C04D-percent-change-in-groups", "Two group fractions linked through a ratio; one unknown fraction.",
  correct=r"$\frac{5}{8}$",
  distractors=[(r"$\frac{5}{6}$", "Uses all $5$ men at the dinner: women at dinner $= 2.5$, and $\\frac{2.5}{3} = \\frac{5}{6}$."),
               (r"$\frac{3}{8}$", "Gives the fraction of women who do not attend."),
               (r"$\frac{9}{40}$", "Takes men to women as $3 : 5$: $\\frac{3}{4} \\times 3 = 2 \\times 5f$.")],
  check=_m8, values=[Rational(5, 8), Rational(5, 6), Rational(3, 8), Rational(9, 40)], cognitive="Application")


def _m9():
    for k in range(1, 10000):
        P, Q, R = 2 * k, 3 * k, 4 * k
        if P % 7 == 0 and Q % 12 == 0 and R % 3 == 0:
            return P + Q + R
q("C04-D-020", T, "Three sections with internal boy-girl ratios; least total for whole numbers", "Medium",
  "Casework/optimisation",
  r"The strengths of three sections P, Q and R of a class are in the ratio $2 : 3 : 4$. The ratio of boys to girls is $3 : 4$ in section P, $5 : 7$ in section Q and $1 : 2$ in section R. What is the least possible total number of students in the three sections?",
  "TITA",
  r"Let the strengths be $2k$, $3k$, $4k$. Section P must be a multiple of $7$, so $7 \mid 2k$ and $7 \mid k$. Section Q must be a multiple of $12$, so $12 \mid 3k$ and $4 \mid k$. Section R must be a multiple of $3$, so $3 \mid 4k$ and $3 \mid k$. Hence $k$ is a multiple of $84$, and the least total is $9 \times 84 = 756$.",
  "Requiring the total, rather than each section, to fit the inner ratios.",
  "C04D-three-group-integer-min", "Three divisibility conditions on the multiplier, each needing care with common factors.",
  tita_answer=756, check=_m9,
  tita_traps=[(84, "Takes the total to be $\\text{lcm}(7, 12, 3) = 84$."), (2268, "Requires $k$ to be a multiple of $7 \\times 12 \\times 3 = 252$.")],
  cognitive="Analysis")


def _m10():
    sols = []
    for k in range(1, 100):
        total = 8 * k
        adults = 5 * k
        if 100 < total < 150 and adults % 7 == 0:
            sols.append(adults // 7 * 3)
    assert len(sols) == 1
    return sols[0]
q("C04-D-021", T, "Nested ratios with a range on the total; count one subgroup", "Medium",
  "Casework/optimisation",
  r"At a family function the ratio of adults to children is $5 : 3$, and among the adults the ratio of men to women is $4 : 3$. The total number of people at the function is more than $100$ and fewer than $150$. How many women are at the function?",
  "TITA",
  r"With $5k$ adults and $3k$ children, the adults split as $4 : 3$, so $5k$ must be a multiple of $7$, i.e. $k$ is a multiple of $7$. The total $8k$ is then a multiple of $56$, and the only one between $100$ and $150$ is $112$. So $k = 14$, adults $= 70$, and women $= \frac{3}{7} \times 70 = 30$.",
  "Ignoring the inner ratio's divisibility and picking any multiple of 8.",
  "C04D-integer-total-constraint", "Inner ratio forces a divisibility condition before the range is used.",
  tita_answer=30, check=_m10,
  tita_traps=[(40, "Reports the number of men."), (42, "Reports the number of children.")],
  cognitive="Analysis")


def _m11():
    sols = []
    for k in range(1, 100):
        R, S, K = 4 * k, 5 * k, 6 * k
        if R + S + K >= 150 or R % 3 or K % 4:
            continue
        sols.append(S + R // 3 + K // 4)
    assert len(sols) == 1
    return sols[0]
q("C04-D-022", T, "Fractional gifts require whole numbers; total bound fixes the counts", "Medium",
  "Casework/optimisation",
  r"Ravi, Sneha and Kabir have pens in the ratio $4 : 5 : 6$, and together they have fewer than $150$ pens. Ravi gives one-third of his pens to Sneha, and Kabir gives one-quarter of his pens to Sneha; all gifts are whole numbers of pens. How many pens does Sneha have now?",
  "MCQ",
  r"With $4k$, $5k$, $6k$ pens, one-third of $4k$ must be whole, so $3 \mid k$; one-quarter of $6k$ must be whole, so $2 \mid k$. Thus $k$ is a multiple of $6$ and the total $15k$ is a multiple of $90$; below $150$ only $90$ works, so $k = 6$. Sneha has $30 + \frac{24}{3} + \frac{36}{4} = 30 + 8 + 9 = 47$ pens.",
  "Swapping the two fractions or adding only one gift.",
  "C04D-three-group-integer-min", "Two divisibility conditions plus a bound, then a two-part update.",
  correct=r"$47$",
  distractors=[(r"$48$", "Swaps the fractions: Ravi gives $\\frac{24}{4} = 6$ and Kabir gives $\\frac{36}{3} = 12$, so $30 + 18$."),
               (r"$38$", "Adds only Ravi's gift: $30 + 8$."),
               (r"$30$", "Reports Sneha's count before the gifts.")],
  check=_m11, values=[47, 48, 38, 30], cognitive="Analysis")


def _m12():
    vals = set()
    for k in range(1, 1000):
        b, g = 5 * k, 4 * k
        if g + 10 > b and b - 3 > g:
            vals.add(9 * k)
    return len(vals)
q("C04-D-023", T, "Two inequality conditions on a ratio; count the possible totals", "Medium",
  "Casework/optimisation",
  r"In a class the ratio of boys to girls is $5 : 4$. If $10$ more girls joined the class, girls would outnumber boys. If instead $3$ boys left the class, boys would still outnumber girls. How many different values can the total number of students in the class take?",
  "TITA",
  r"Let there be $5k$ boys and $4k$ girls. The first condition is $4k + 10 > 5k$, so $k < 10$. The second is $5k - 3 > 4k$, so $k > 3$. Hence $k = 4, 5, \ldots, 9$, giving $6$ possible totals ($36, 45, \ldots, 81$).",
  "Treating 'outnumber' as 'at least as many as', which adds an end value.",
  "C04D-range-possible-values", "Two strict inequalities; endpoints must be checked.",
  tita_answer=6, check=_m12,
  tita_traps=[(7, "Includes one endpoint ($k = 10$ or $k = 3$), where the two groups would be equal."), (8, "Includes both endpoints $k = 3$ and $k = 10$.")],
  cognitive="Analysis")


def _m13():
    for k in range(1, 1000):
        fiction, nonfic = 5 * k, 4 * k
        if 3 * fiction == 5 * (nonfic - 24):
            return fiction - (nonfic - 24)
q("C04-D-024", T, "Withdrawals from one group then the other change the ratio in two stages", "Medium",
  "Multi-step word problem",
  r"A village library's fiction and non-fiction books are in the ratio $5 : 4$. After $24$ non-fiction books are withdrawn, the ratio of fiction to non-fiction books becomes $5 : 3$. The library then withdraws some fiction books, and no non-fiction books, after which it has equal numbers of fiction and non-fiction books. How many fiction books were withdrawn?",
  "MCQ",
  r"Fiction books are unchanged in the first withdrawal, so they stay at $5$ parts while non-fiction falls from $4$ parts to $3$ parts: $1$ part $= 24$. So there are $120$ fiction and $72$ non-fiction books left. To be equal, fiction must fall to $72$, so $120 - 72 = 48$ fiction books were withdrawn.",
  "Equalising fiction with the original non-fiction count.",
  "C04D-change-one-group", "Two stages, each changing only one group.",
  correct=r"$48$",
  distractors=[(r"$72$", "Reports the number of fiction books left at the end."),
               (r"$24$", "Equalises fiction with the original $96$ non-fiction books: $120 - 96$."),
               (r"$96$", "Reports the original number of non-fiction books.")],
  check=_m13, values=[48, 72, 24, 96], cognitive="Application")


def _m14():
    cur = [50, 70, 90]
    tgt = [Fraction(210 * r, 7) for r in (3, 2, 2)]
    return sum(max(Fraction(0), c - t) for c, t in zip(cur, tgt))
q("C04-D-025", T, "Least number of items moved to reach a target three-way ratio", "Medium",
  "Casework/optimisation",
  r"Three shelves P, Q and R hold $210$ books in the ratio $5 : 7 : 9$. Books are moved between the shelves, without adding or removing any, until the numbers on P, Q and R are in the ratio $3 : 2 : 2$. What is the least number of books that must be moved?",
  "MCQ",
  r"Now the shelves hold $50$, $70$, $90$. The target is $90$, $60$, $60$. Shelf P must gain $40$; Q has $10$ extra and R has $30$ extra. Moving exactly the surplus books ($10$ from Q and $30$ from R) to P works, so the least number moved is $40$.",
  "Adding gains and losses together, so each book is counted twice.",
  "C04D-min-moves-to-ratio", "Optimisation: moved books equal the total surplus, not the sum of all changes.",
  correct=r"$40$",
  distractors=[(r"$80$", "Adds all the changes $40 + 10 + 30$, counting every moved book twice."),
               (r"$30$", "Counts only the books leaving shelf R."),
               (r"$10$", "Counts only the books leaving shelf Q.")],
  check=_m14, values=[40, 80, 30, 10], cognitive="Analysis")


def _m15():
    f = symbols('f', positive=True)
    return solve(Eq(3 * (7 - 7 * f), 2 * (3 + 7 * f)), f)[0]
q("C04-D-026", T, "Fraction of one group to transfer for a target ratio", "Medium",
  "Inverse/parameter",
  r"Two teams of volunteers have members in the ratio $7 : 3$. What fraction of the first team's members must be moved to the second team so that the ratio of the first team's members to the second team's becomes $2 : 3$?",
  "MCQ",
  r"Take $7$ and $3$ units; the total of $10$ units does not change. The target $2 : 3$ means $4$ and $6$ units. So $3$ units leave the first team, which is $\frac{3}{7}$ of its members.",
  "Dividing the moved amount by the wrong base.",
  "C04D-transfer-two-groups", "Fixed total, then express the move as a fraction of the original first team.",
  correct=r"$\frac{3}{7}$",
  distractors=[(r"$\frac{3}{10}$", "Divides the $3$ units moved by the combined total of $10$."),
               (r"$\frac{4}{7}$", "Gives the fraction of the first team that stays."),
               (r"$\frac{3}{4}$", "Divides the $3$ units moved by the first team's final size of $4$.")],
  check=_m15, values=[Rational(3, 7), Rational(3, 10), Rational(4, 7), Rational(3, 4)], cognitive="Application")


# ---------------------------------------------------------------- DIFFICULT

def _norm(t):
    from math import gcd
    t = [Fraction(v) for v in t]
    L = 1
    for v in t:
        L = L * v.denominator // gcd(L, v.denominator)
    ints = [int(v * L) for v in t]
    g = 0
    for v in ints:
        g = gcd(g, v)
    return [v // g for v in ints]

def _d1():
    sols = set()
    for a in range(1, 41):
        for k in range(1, 41):
            for j in range(1, 41):
                A, K, J = Fraction(a), Fraction(k), Fraction(j)
                g = A / 4; A -= g; K += g
                g = K / 3; K -= g; J += g
                g = J / 5; J -= g; A += g
                if A == K == J:
                    sols.add(tuple(_norm([a, k, j])))
    assert len(sols) == 1
    return list(sols.pop())
q("C04-D-027", T, "Three successive fractional transfers end equal; recover the starting ratio", "Difficult",
  "Multi-step word problem",
  r"Ananya, Kabir and Joseph each have some money. First Ananya gives one-quarter of her money to Kabir. Then Kabir gives one-third of the money he now has to Joseph. Finally Joseph gives one-fifth of the money he now has to Ananya. After this all three have equal amounts. What was the ratio of the amounts Ananya, Kabir and Joseph had at the start?",
  "MCQ",
  r"Work backwards with final amounts $1, 1, 1$. Joseph kept $\frac{4}{5}$, so he had $\frac{5}{4}$ and gave $\frac{1}{4}$; Ananya had $\frac{3}{4}$ before that. Kabir kept $\frac{2}{3}$, so he had $\frac{3}{2}$ and gave $\frac{1}{2}$; Joseph started with $\frac{5}{4} - \frac{1}{2} = \frac{3}{4}$. Ananya kept $\frac{3}{4}$ of her start, so she began with $1$ and gave $\frac{1}{4}$; Kabir began with $\frac{3}{2} - \frac{1}{4} = \frac{5}{4}$. The ratio is $1 : \frac{5}{4} : \frac{3}{4} = 4 : 5 : 3$.",
  "Undoing 'gives one-fifth' by adding one-fifth of the amount after the gift.",
  "C04D-successive-transfers-backwards", "Three reverse steps; each fraction applies to an amount that has already changed.",
  correct=r"$4 : 5 : 3$",
  distractors=[(r"$15 : 17 : 13$", "Undoes each gift by adding that fraction of the after-gift amount (e.g. Joseph had $1 + \\frac{1}{5}$), giving $1 : \\frac{17}{15} : \\frac{13}{15}$."),
               (r"$16 : 14 : 9$", "Forgets that Ananya receives money in the last step and undoes her gift from a final $1$: $\\frac{4}{3} : \\frac{7}{6} : \\frac{3}{4}$."),
               (r"$3 : 4 : 5$", "Reports the ratio just before Joseph's gift, $\\frac{3}{4} : 1 : \\frac{5}{4}$.")],
  check=_d1, values=[[4, 5, 3], [15, 17, 13], [16, 14, 9], [3, 4, 5]], cognitive="Analysis", exams=HARD)


def _d2():
    sols = set()
    for p in range(1, 60):
        for k in range(1, 60):
            if p <= k:
                continue
            P, K = p - k, 2 * k          # Priya gives Kabir as many as Kabir has
            if K < P:
                continue
            K, P = K - P, 2 * P          # Kabir gives Priya as many as Priya has
            if 3 * P == 4 * K:
                sols.add(Fraction(p, k))
    assert len(sols) == 1
    return sols.pop()
q("C04-D-028", T, "Doubling exchanges between two people; initial ratio from the final ratio", "Difficult",
  "Multi-step word problem",
  r"Priya and Kabir each have some marbles. Priya gives Kabir as many marbles as Kabir has, which doubles Kabir's marbles. Kabir then gives Priya as many marbles as Priya has at that moment, which doubles Priya's marbles. Now the ratio of Priya's marbles to Kabir's is $4 : 3$. What was the ratio of Priya's marbles to Kabir's at the start?",
  "MCQ",
  r"Start with $p$ and $k$. After the first exchange: $p - k$ and $2k$. After the second: $2(p - k)$ and $2k - (p - k) = 3k - p$. So $3 \cdot 2(p - k) = 4(3k - p)$, i.e. $10p = 18k$ and $p : k = 9 : 5$. (Check: $9, 5 \to 4, 10 \to 8, 6$, and $8 : 6 = 4 : 3$.)",
  "Using Priya's original count, not her count after the first exchange, in the second step.",
  "C04D-successive-transfers-backwards", "Two linked exchanges where each gift depends on the other person's current amount.",
  correct=r"$9 : 5$",
  distractors=[(r"$11 : 10$", "In the second step lets Kabir give Priya her original $p$ marbles: $(2p - k) : (2k - p) = 4 : 3$ gives $10p = 11k$."),
               (r"$5 : 9$", "Writes the starting ratio as Kabir to Priya."),
               (r"$2 : 5$", "Reports the ratio after the first exchange, $4 : 10$.")],
  check=_d2, values=[Rational(9, 5), Rational(11, 10), Rational(5, 9), Rational(2, 5)], cognitive="Analysis", exams=HARD)


def _d3():
    x, y = symbols('x y', positive=True)
    sol = solve([Eq(4 * x * Rational(11, 10) - 3 * y, 3 * x * Rational(12, 10) - 2 * y),
                 Eq((4 * x - 3 * y) - (3 * x - 2 * y), 2000)], [x, y], dict=True)
    return 4 * _pos(sol, x)
q("C04-D-029", T, "Unequal percentage raises would equalise savings; recover an income from the present savings gap", "Difficult",
  "Multi-step word problem",
  r"The monthly incomes of Ravi and Sneha are in the ratio $4 : 3$ and their monthly expenditures are in the ratio $3 : 2$. At present Ravi saves Rs. $2{,}000$ a month more than Sneha. If Ravi's income rose by $10\%$ and Sneha's income rose by $20\%$, with both expenditures unchanged, the two of them would save equal amounts. What is Ravi's present monthly income, in rupees?",
  "TITA",
  r"Let the incomes be $4x, 3x$ and the expenditures $3y, 2y$. After the raises the savings are $4.4x - 3y$ and $3.6x - 2y$; equal savings give $0.8x = y$. The present gap is $(4x - 3y) - (3x - 2y) = x - y = 0.2x = 2000$, so $x = 10000$ and Ravi's income is $4x = 40000$ rupees. (Check: expenditures $24000$ and $16000$; savings now $16000$ and $14000$; after the raises $44000 - 24000 = 36000 - 16000 = 20000$.)",
  "Applying the percentage raises to savings instead of incomes, or reporting a figure after the raise.",
  "C04D-income-expenditure-savings", "Two stages with different multipliers: the percentage raises fix y in terms of x, then the present gap fixes x.",
  tita_answer=40000, check=_d3,
  tita_traps=[(44000, "Reports Ravi's income after the raise."), (30000, "Reports Sneha's income."), (16000, "Reports Ravi's present savings.")],
  cognitive="Analysis", exams=HARD)


def _d4():
    best = None
    for y in range(1, 20001):
        y = Fraction(y)
        x = (8000 + 3 * y) / 4          # Joseph: 4x - 3y = 8000
        if 3 * y > 24000 or 2 * y < 10000:
            continue
        s1 = 3 * x - 2 * y
        if best is None or s1 > best:
            best = s1
    return best
q("C04-D-030", T, "Bounds on expenditures give the range of one person's savings", "Difficult",
  "Casework/optimisation",
  r"The monthly incomes of Priya and Joseph are in the ratio $3 : 4$, and their monthly expenditures are in the ratio $2 : 3$. Joseph saves Rs. $8{,}000$ a month and spends at most Rs. $24{,}000$ a month. Priya spends at least Rs. $10{,}000$ a month. What is the greatest possible monthly saving of Priya?",
  "MCQ",
  r"Let the incomes be $3x, 4x$ and the expenditures $2y, 3y$. Joseph: $4x - 3y = 8000$, so $x = \frac{8000 + 3y}{4}$. Priya saves $3x - 2y = 6000 + \frac{9y}{4} - 2y = 6000 + \frac{y}{4}$, which grows with $y$. The limits give $3y \le 24000$ and $2y \ge 10000$, so $5000 \le y \le 8000$. The greatest saving is $6000 + 2000 = $ Rs. $8{,}000$ (incomes Rs. $24{,}000$ and Rs. $32{,}000$).",
  "Assuming savings follow the income ratio, or applying a bound to the wrong person.",
  "C04D-income-expenditure-range", "Express one saving in terms of the expenditure multiplier and optimise over a range.",
  correct=r"Rs. $8{,}000$",
  distractors=[(r"Rs. $7{,}250$", "Reports the least possible saving, at $y = 5000$."),
               (r"Rs. $6{,}000$", "Assumes the savings are in the income ratio $3 : 4$."),
               (r"Rs. $9{,}000$", "Applies the Rs. $24{,}000$ limit to Priya's expenditure: $2y = 24000$, $y = 12000$, saving $6000 + 3000$.")],
  check=_d4, values=[8000, 7250, 6000, 9000], cognitive="Analysis", exams=HARD)


def _d5():
    for k in range(1, 10000):
        a, m, o = 3 * k, 4 * k, 5 * k
        if 12 * k <= 1000:
            continue
        if (a * 2) % 7 or (m * 3) % 8 or o % 3:
            continue
        return a - a * 2 // 7 + m - m * 3 // 8 + o - o // 3
q("C04-D-031", T, "Fractions sold from three stocks in a ratio; least possible remainder", "Difficult",
  "Casework/optimisation",
  r"A fruit seller has apples, mangoes and oranges in the ratio $3 : 4 : 5$, and more than $1{,}000$ fruits in all. In a day he sells exactly $\frac{2}{7}$ of the apples, $\frac{3}{8}$ of the mangoes and $\frac{1}{3}$ of the oranges, each a whole number of fruits. What is the least possible number of fruits left unsold?",
  "TITA",
  r"With $3k$ apples, $4k$ mangoes and $5k$ oranges: $\frac{2}{7} \cdot 3k$ whole needs $7 \mid k$; $\frac{3}{8} \cdot 4k$ whole needs $2 \mid k$; $\frac{1}{3} \cdot 5k$ whole needs $3 \mid k$. So $k$ is a multiple of $42$. The total $12k > 1000$ gives $k \ge 84$. The unsold fruits are $\frac{5}{7} \cdot 3k + \frac{5}{8} \cdot 4k + \frac{2}{3} \cdot 5k = \frac{335k}{42}$, least at $k = 84$: $180 + 210 + 280 = 670$.",
  "Ignoring the lower bound on the stock, or reporting the stock or the number sold.",
  "C04D-three-group-integer-min", "Three divisibility conditions, a lower bound, then a three-part remainder.",
  tita_answer=670, check=_d5,
  tita_traps=[(335, "Ignores the condition of more than $1{,}000$ fruits and uses $k = 42$."), (1008, "Reports the least possible stock instead of the unsold fruits."), (338, "Reports the number of fruits sold at $k = 84$.")],
  cognitive="Analysis", exams=HARD)


def _d6():
    best = None
    for b in range(1, 200):
        for a in range(1, b):
            if 7 * a > 5 * b and 4 * a < 3 * b:
                if best is None or a + b < best:
                    best = a + b
    return best
q("C04-D-032", T, "A ratio strictly between two given ratios; least possible total", "Difficult",
  "Casework/optimisation",
  r"Meera and Kabir each have a whole number of postcards. The ratio of Meera's postcards to Kabir's is greater than $5 : 7$ and less than $3 : 4$. What is the least possible total number of postcards the two of them have?",
  "TITA",
  r"We need $\frac{5}{7} < \frac{m}{k} < \frac{3}{4}$. Both $5k - 7m$ and $3k - 4m$ are whole numbers, and here $5k - 7m < 0$ and $4m - 3k < 0$, so $7m - 5k \ge 1$ and $3k - 4m \ge 1$. Multiplying the first by $3$ and the second by $5$ and adding gives $21m - 20m \ge 3 + 5$, so $m \ge 8$; multiplying the first by $4$ and the second by $7$ and adding gives $21k - 20k \ge 4 + 7$, so $k \ge 11$. Hence $m + k \ge 19$, and $\frac{8}{11}$ attains it ($\frac{5}{7} < \frac{8}{11} < \frac{3}{4}$ since $55 < 56$ and $32 < 33$). The least total is $19$.",
  "Using a boundary ratio, which the strict inequalities exclude.",
  "C04D-range-possible-values", "Needs a fraction strictly between two close ratios with the smallest sum.",
  tita_answer=19, check=_d6,
  tita_traps=[(12, "Uses the boundary ratio $5 : 7$, which is excluded."), (7, "Uses the boundary ratio $3 : 4$, which is excluded."), (26, "Settles on $11 : 15$ without checking smaller totals.")],
  cognitive="Analysis", exams=HARD)


def _d7():
    sols = set()
    for a in range(1, 200):
        for b in range(1, 200):
            # P: 5a boys, 3a girls; Q: b boys, 3b girls; t boys P->Q, t girls Q->P
            if 8 * a - 4 * b != 36:
                continue
            for t in range(1, 3 * b + 1):
                if 5 * a - t == 3 * a + t and 3 * (b + t) == 2 * (3 * b - t):
                    sols.add(8 * a + 4 * b)
    assert len(sols) == 1
    return sols.pop()
q("C04-D-033", T, "Swap between two rooms reaches different internal ratios; find the total", "Difficult",
  "Conceptual/application",
  r"In room P the ratio of boys to girls is $5 : 3$, and in room Q it is $1 : 3$. Some boys move from P to Q and, at the same time, the same number of girls move from Q to P. After this, room P has equal numbers of boys and girls, and in room Q the ratio of boys to girls is $2 : 3$. Room P has $36$ more students than room Q. How many students are there in the two rooms together?",
  "MCQ",
  r"Let P have $5a$ boys and $3a$ girls, Q have $b$ boys and $3b$ girls, and $t$ students move each way. In P: $5a - t = 3a + t$, so $t = a$. In Q: $3(b + t) = 2(3b - t)$, so $5t = 3b$ and $b = \frac{5a}{3}$. The swap does not change room sizes, so $8a - 4b = 8a - \frac{20a}{3} = \frac{4a}{3} = 36$, giving $a = 27$ and $b = 45$. The total is $8a + 4b = 216 + 180 = 396$ (P ends with $108$ boys and $108$ girls, Q with $72$ boys and $108$ girls).",
  "Treating the 36-student gap as a boy-girl gap inside P, or answering for one room.",
  "C04D-two-rooms-swap", "Two internal ratios plus a swap; the swap size ties the two multipliers together before the size gap can be used.",
  correct=r"$396$",
  distractors=[(r"$216$", "Reports the number of students in room P."),
               (r"$264$", "Takes the $36$-student difference as P's $2$-part boy-girl gap, so $a = 18$, $b = 30$ and the total is $8a + 4b$."),
               (r"$180$", "Reports the number of students in room Q.")],
  check=_d7, values=[396, 216, 264, 180], cognitive="Analysis", exams=HARD)


def _d8():
    Tt, y = symbols('T y', positive=True)
    sol = solve([Eq(Rational(7, 15) * Tt - 500, Rational(3, 10) * Tt),
                 Eq(Rational(3, 15) * Tt + y, Rational(5, 10) * Tt)], [Tt, y], dict=True)
    Tv, yv = sol[0][Tt], sol[0][y]
    assert Rational(5, 15) * Tv + 500 - yv == Rational(2, 10) * Tv
    return yv
q("C04-D-034", T, "Chain of transfers among three people with different ratio totals", "Difficult",
  "Conceptual/application",
  r"Ananya, Ravi and Fatima have money in the ratio $7 : 5 : 3$. Ananya gives Rs. $500$ to Ravi, and then Ravi gives some money to Fatima. Nothing else changes, and the amounts of Ananya, Ravi and Fatima are now in the ratio $3 : 2 : 5$. How much did Ravi give Fatima?",
  "MCQ",
  r"The total $T$ is unchanged, but the ratio sums differ ($15$ and $10$), so compare fractions of $T$. Ananya goes from $\frac{7}{15}T$ to $\frac{3}{10}T$, a fall of $\frac{1}{6}T = 500$, so $T = 3000$. Fatima goes from $\frac{1}{5}T = 600$ to $\frac{1}{2}T = 1500$, so Ravi gave her Rs. $900$. (Ravi: $1000 + 500 - 900 = 600 = \frac{1}{5}T$, consistent.)",
  "Treating a part of 7:5:3 and a part of 3:2:5 as the same amount.",
  "C04D-three-way-transfer", "The two ratios have different sums, so parts are not comparable; must work with fractions of the fixed total.",
  correct=r"Rs. $900$",
  distractors=[(r"Rs. $250$", "Treats the parts of both ratios as equal: Ananya's $4$-part fall is $500$, so one part is $125$, and Fatima's $2$-part rise is $250$."),
               (r"Rs. $1{,}500$", "Reports Fatima's final amount."),
               (r"Rs. $400$", "Takes Ravi's net fall, $1000 - 600$, ignoring the Rs. $500$ he received.")],
  check=_d8, values=[900, 250, 1500, 400], cognitive="Analysis", exams=HARD)


def _d9():
    sols = []
    for r in range(11, 600):
        for b in range(11, 600):
            if r - 10 != b:
                continue
            for g in range(11, 600):
                if 2 * (b - 10) == g and 2 * (g - 10) == 3 * r:
                    sols.append(r + b + g)
    assert len(sols) == 1
    return sols[0]
q("C04-D-035", T, "Three separate hypothetical removals give a cyclic system of ratios", "Difficult",
  "Multi-step word problem",
  r"A shop has red, blue and green pens. Each statement below describes a separate situation, starting from the shop's actual stock. If $10$ red pens were removed, the numbers of red and blue pens would be equal. If $10$ blue pens were removed, the ratio of blue to green pens would be $1 : 2$. If $10$ green pens were removed, the ratio of green to red pens would be $3 : 2$. How many pens does the shop have in all?",
  "MCQ",
  r"From the statements: $b = r - 10$, $g = 2(b - 10) = 2r - 40$, and $2(g - 10) = 3r$. Substituting, $2(2r - 50) = 3r$, so $r = 100$, $b = 90$, $g = 160$. The shop has $350$ pens (check: $150 : 100 = 3 : 2$ and $80 : 160 = 1 : 2$).",
  "Applying a removal in the wrong direction, or answering after removals.",
  "C04D-cyclic-hypothetical-removals", "Three linked conditions in a cycle; substitution must be done carefully.",
  correct=r"$350$",
  distractors=[(r"$320$", "Reports the stock after removing $10$ pens of every colour."),
               (r"$190$", "Writes the green count in the third statement as $g + 10$: $2(g + 10) = 3r$ gives $r = 60$, $b = 50$, $g = 80$."),
               (r"$260$", "Adds only the red and green pens, $100 + 160$.")],
  check=_d9, values=[350, 320, 190, 260], cognitive="Analysis", exams=HARD)
