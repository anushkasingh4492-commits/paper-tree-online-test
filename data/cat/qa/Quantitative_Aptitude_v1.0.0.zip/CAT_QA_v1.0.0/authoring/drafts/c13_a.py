import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Arithmetic progressions"
X2 = ("CAT", "XAT")

# ---------------------------------------------------------------- EASY

def _c001():
    a, d = symbols('a d')
    s = solve([Eq(a + 4*d, 31), Eq(a + 11*d, 66)], [a, d])
    return s[a] + 19*s[d]
q("C13-A-001", T, "Find a later term of a uniformly growing quantity from two given terms", "Easy",
  "Multi-step word problem",
  r"The height of a plant, measured at the end of every week, increases by the same amount each week. At the end of week $5$ it is $31$ cm and at the end of week $12$ it is $66$ cm. If this pattern continues, what will its height be at the end of week $20$?",
  "MCQ",
  r"The weekly heights form an AP. From week $5$ to week $12$ there are $7$ steps, so $d = \frac{66-31}{7} = 5$ cm. From week $12$ to week $20$ there are $8$ more steps, so the height is $66 + 8 \times 5 = 106$ cm.",
  "Using $a + nd$ for the $n$th term, or treating height as proportional to the week number.",
  "C13A-term-from-two-terms", "Two given terms fix $d$; one more step reaches the required term.",
  correct=r"$106$ cm",
  distractors=[(r"$111$ cm", "Finds $a = 11$, $d = 5$ and then uses $a + 20d$ for the $20$th term."),
               (r"$101$ cm", "Takes the first term as $31 - 5d = 6$ (five steps back from week $5$) and then $6 + 19 \\times 5$."),
               (r"$124$ cm", "Assumes height is proportional to the week number: $31 \\times 4$.")],
  check=_c001, values=[106, 111, 101, 124], cognitive="Application")


def _c002():
    return sum(18 + 3*i for i in range(24))
q("C13-A-002", T, "Total seats in a theatre whose rows grow by a fixed number", "Easy",
  "Single-step computation",
  r"A theatre has $24$ rows of seats. The first row has $18$ seats and every row after it has $3$ seats more than the row just in front of it. How many seats does the theatre have in all?",
  "TITA",
  r"The last row has $18 + 23 \times 3 = 87$ seats. The total is $\frac{24}{2}(18 + 87) = 12 \times 105 = 1260$.",
  r"Taking the last row as $18 + 24 \times 3$, one step too many.",
  "C13A-seats-rows", "Direct use of the AP sum formula, with an off-by-one trap in the last term.",
  tita_answer=1260, check=_c002,
  tita_traps=[(1296, "Takes the last row as $18 + 24 \\times 3 = 90$, giving $12 \\times 108$."),
              (87, "Reports the seats in the last row only.")],
  cognitive="Application")


def _c003():
    return sum(1 for n in range(100, 1000) if n % 7 == 3)
q("C13-A-003", T, "Count three-digit numbers with a given remainder", "Easy",
  "Single-step computation",
  r"A building has lockers numbered $100$ to $999$. Every locker whose number leaves remainder $3$ when divided by $7$ is painted blue. How many lockers are painted blue?",
  "TITA",
  r"The blue numbers are $101, 108, 115, \ldots, 997$, an AP with difference $7$ ($101 = 7 \times 14 + 3$ and $997 = 7 \times 142 + 3$). The count is $\frac{997 - 101}{7} + 1 = 128 + 1 = 129$.",
  "Forgetting the $+1$ when counting terms, or counting from $1$ instead of from $100$.",
  "C13A-count-terms-in-range", "One AP count with an off-by-one trap.",
  tita_answer=129, check=_c003,
  tita_traps=[(128, "Uses $\\frac{997-101}{7}$ without adding $1$."),
              (143, "Counts all numbers from $1$ to $999$ with remainder $3$ (from $3$ to $997$).")],
  cognitive="Application")


def _c004():
    total = 0
    for m in range(24):
        total += 500 + 100*m
    return total
q("C13-A-004", T, "Total savings when the monthly saving rises by a fixed amount", "Easy",
  "Multi-step word problem",
  r"Meera saves Rs. $500$ in the first month of a job and, in every later month, saves Rs. $100$ more than in the previous month. What are her total savings, in rupees, at the end of $2$ years?",
  "TITA",
  r"There are $24$ months. The saving in month $24$ is $500 + 23 \times 100 = 2800$. Total $= \frac{24}{2}(500 + 2800) = 12 \times 3300 = 39{,}600$.",
  "Using $a + nd$ for the last month, or reporting only the last month's saving.",
  "C13A-savings-sum", "Convert years to months and apply the AP sum formula.",
  tita_answer=39600, check=_c004,
  tita_traps=[(40800, "Takes the last month as $500 + 24 \\times 100 = 2900$, giving $12 \\times 3400$."),
              (2800, "Reports the saving in the $24$th month instead of the total.")],
  cognitive="Application")


def _c005():
    n = symbols('n')
    S = 4*n**2 - 3*n
    return S.subs(n, 15) - S.subs(n, 14)
q("C13-A-005", T, "Term of an AP from a formula for the running total", "Easy",
  "Conceptual/application",
  r"A crew lays floor tiles. The total number of tiles laid in the first $n$ days is $4n^2 - 3n$. How many tiles are laid on the $15$th day alone?",
  "MCQ",
  r"Tiles on day $n$ equal $S_n - S_{n-1}$. So day $15$ gives $S_{15} - S_{14} = (900 - 45) - (784 - 42) = 855 - 742 = 113$. (In general the daily count is $8n - 7$.)",
  "Treating the running total $S_{15}$ as the amount for day $15$.",
  "C13A-sum-formula-to-term", "One subtraction of consecutive totals; the trap is reading the total as the term.",
  correct=r"$113$",
  distractors=[(r"$855$", "Reports $S_{15}$, the total for $15$ days."),
               (r"$121$", "Finds first term $1$ and $d = 8$, then uses $1 + 15 \\times 8$."),
               (r"$57$", "Divides $S_{15}$ by $15$, the average per day.")],
  check=_c005, values=[113, 855, 121, 57], cognitive="Understanding")


def _c006():
    return sum(x for x in range(10, 100) if x % 6 == 0)
q("C13-A-006", T, "Sum of all two-digit multiples of a number", "Easy",
  "Single-step computation",
  r"What is the sum of all two-digit natural numbers that are divisible by $6$?",
  "MCQ",
  r"They are $12, 18, \ldots, 96$: $\frac{96 - 12}{6} + 1 = 15$ terms. Sum $= \frac{15}{2}(12 + 96) = 15 \times 54 = 810$.",
  "Miscounting the terms, or including the one-digit multiple $6$.",
  "C13A-sum-of-multiples", "Count terms correctly and apply the sum formula.",
  correct=r"$810$",
  distractors=[(r"$816$", "Includes $6$, which is not a two-digit number."),
               (r"$756$", "Counts $14$ terms by omitting the $+1$: $14 \\times 54$."),
               (r"$864$", "Counts $\\frac{96}{6} = 16$ terms: $16 \\times 54$.")],
  check=_c006, values=[810, 816, 756, 864], cognitive="Application")


def _c007():
    d = Fraction(79 - 7, 12)
    return int(7 + 7*d)
q("C13-A-007", T, "A term between two given end terms of an AP", "Easy",
  "Multi-step word problem",
  r"A ramp is supported by $13$ equally spaced vertical posts. Their heights increase by the same amount from one post to the next, from $7$ cm for the first post to $79$ cm for the last. What is the height of the $8$th post, in cm?",
  "TITA",
  r"There are $12$ gaps between $13$ posts, so the common difference is $\frac{79-7}{12} = 6$ cm. The $8$th post is $7$ steps from the first: $7 + 7 \times 6 = 49$ cm.",
  "Counting $13$ gaps instead of $12$, or taking the $8$th post after the first as the $8$th post.",
  "C13A-terms-between-given-ends", "Count gaps correctly, then one step to the term.",
  tita_answer=49, check=_c007,
  tita_traps=[(55, "Takes $7 + 8 \\times 6$, i.e. the post $8$ steps after the first, which is the $9$th."),
              (43, "Takes $7 + 6 \\times 6$, the $7$th post.")],
  cognitive="Application")


def _c008():
    a, d = symbols('a d')
    sols = solve([Eq(3*a, 27), Eq((a - d)*a*(a + d), 504)], [a, d], dict=True)
    return max(s[a] + abs(s[d]) for s in sols)
q("C13-A-008", T, "Three terms in AP from their sum and product", "Easy",
  "Multi-step word problem",
  r"The ages, in whole years, of three sisters form an arithmetic progression. The sum of their ages is $27$ years and the product is $504$. What is the age of the eldest sister?",
  "MCQ",
  r"Write the ages as $a - d$, $a$, $a + d$. The sum gives $3a = 27$, so $a = 9$. Then $9(81 - d^2) = 504$, so $81 - d^2 = 56$ and $d = 5$. The ages are $4$, $9$, $14$; the eldest is $14$.",
  "Writing the terms as $a, a+d, a+2d$ but then treating $a$ as the middle term.",
  "C13A-symmetric-terms", "Symmetric choice of terms makes it one short computation.",
  correct=r"$14$ years",
  distractors=[(r"$4$ years", "Reports the youngest age $a - d$."),
               (r"$9$ years", "Reports the middle age found from the sum."),
               (r"$19$ years", "Finds $a = 9$, $d = 5$ but then writes the eldest as $a + 2d$.")],
  check=_c008, values=[14, 4, 9, 19], cognitive="Application")


def _c009():
    return sum(1 for k in range(1000) if 213 - 6*k > 0)
q("C13-A-009", T, "Number of positive terms of a decreasing AP", "Easy",
  "Single-step computation",
  r"How many terms of the arithmetic progression $213, 207, 201, 195, \ldots$ are positive?",
  "TITA",
  r"The $n$th term is $213 - 6(n-1) = 219 - 6n$. It is positive when $6n < 219$, that is $n < 36.5$. So $n = 1, 2, \ldots, 36$: $36$ positive terms (the $36$th term is $3$ and the $37$th is $-3$).",
  "Dividing $213$ by $6$ and forgetting that the first term itself is counted.",
  "C13A-count-positive-terms", "One inequality on the $n$th term.",
  tita_answer=36, check=_c009,
  tita_traps=[(35, "Uses $\\lfloor 213/6 \\rfloor = 35$ and forgets to count the first term."),
              (37, "Counts the first negative term as well.")],
  cognitive="Application")


def _c010():
    a, d = symbols('a d', positive=True)
    s = solve([Eq((a - d)**2 + a**2, (a + d)**2), Eq(3*a, 72)], [a, d], dict=True)[0]
    return (s[a] - s[d]) * s[a] / 2
q("C13-A-010", T, "Right triangle whose sides form an AP", "Easy",
  "Multi-step word problem",
  r"The three sides of a right-angled triangular plot of land form an arithmetic progression, and its perimeter is $72$ m. What is the area of the plot?",
  "MCQ",
  r"Let the sides be $a - d$, $a$, $a + d$. Then $3a = 72$, so $a = 24$. Pythagoras gives $(a-d)^2 + a^2 = (a+d)^2$, so $a^2 = 4ad$ and $a = 4d$, giving $d = 6$. The sides are $18, 24, 30$ and the area is $\frac{1}{2} \times 18 \times 24 = 216$ m$^2$.",
  r"Using the hypotenuse as one of the legs, or omitting the factor $\frac{1}{2}$.",
  "C13A-right-triangle-ap-sides", "Sum fixes the middle side; Pythagoras fixes $d$.",
  correct=r"$216$ m$^2$",
  distractors=[(r"$432$ m$^2$", "Multiplies the two legs and omits the factor $\\frac{1}{2}$."),
               (r"$270$ m$^2$", "Uses the shortest side and the hypotenuse: $\\frac{1}{2} \\times 18 \\times 30$."),
               (r"$360$ m$^2$", "Uses the two longer sides: $\\frac{1}{2} \\times 24 \\times 30$.")],
  check=_c010, values=[216, 432, 270, 360], cognitive="Application")


def _c011():
    a, d = 16, symbols('d')
    dv = solve(Eq(Rational(25, 2)*(2*a + 24*d) / 25, 40), d)[0]
    return a + 24*dv
q("C13-A-011", T, "Average of an AP equals the average of its end terms", "Easy",
  "Conceptual/application",
  r"The marks of $25$ students in a test, arranged in increasing order, form an arithmetic progression. The average mark is $40$ and the lowest mark is $16$. What is the highest mark?",
  "MCQ",
  r"For an AP the average equals the average of the first and last terms, so $\frac{16 + \ell}{2} = 40$ and $\ell = 64$. (The common difference is $\frac{64-16}{24} = 2$.)",
  "Using $a + nd$ for the last term after finding $d$.",
  "C13A-mean-is-middle", "One idea: the mean of an AP is the mean of its end terms.",
  correct=r"$64$",
  distractors=[(r"$66$", "Finds $d = 2$ and then uses $16 + 25 \\times 2$."),
               (r"$62$", "Finds $d = 2$ and then uses $16 + 23 \\times 2$."),
               (r"$80$", "Doubles the average and ignores the lowest mark.")],
  check=_c011, values=[64, 66, 62, 80], cognitive="Understanding")


def _c012():
    a, d = symbols('a d')
    s = solve([Eq(a + 2*d, 600), Eq(a + 6*d, 700)], [a, d])
    return sum(s[a] + k*s[d] for k in range(7))
q("C13-A-012", T, "Total output over several years from two known yearly outputs", "Easy",
  "Multi-step word problem",
  r"A factory's output rises by the same number of units every year. It produced $600$ units in its $3$rd year and $700$ units in its $7$th year. What was its total output over its first $7$ years?",
  "MCQ",
  r"From year $3$ to year $7$ there are $4$ steps, so $d = \frac{100}{4} = 25$ and year $1$ output is $600 - 2 \times 25 = 550$. Total $= \frac{7}{2}(550 + 700) = 4375$ units.",
  "Counting $5$ steps between the $3$rd and $7$th terms.",
  "C13A-term-from-two-terms", "Find $d$ and $a$ from two terms, then one sum.",
  correct=r"$4375$ units",
  distractors=[(r"$4340$ units", "Takes $d = \\frac{100}{5} = 20$, so year $1$ is $560$, then $\\frac{7}{2}(2 \\times 560 + 6 \\times 20)$."),
               (r"$4550$ units", "Multiplies $7$ by $650$, the average of the two given years."),
               (r"$4900$ units", "Multiplies the $7$th year output by $7$.")],
  check=_c012, values=[4375, 4340, 4550, 4900], cognitive="Application")


def _c013():
    rows = 0; s = 12
    while s <= 72:
        rows += 1; s += 4
    return rows
q("C13-A-013", T, "Number of rows from first row, last row and increment", "Easy",
  "Single-step computation",
  r"In an open-air auditorium the first row has $12$ seats and each row has $4$ seats more than the row in front of it. The last row has $72$ seats. How many rows are there?",
  "MCQ",
  r"The rows form an AP with $a = 12$, $d = 4$ and last term $72$. So $12 + (n-1) \times 4 = 72$, giving $n - 1 = 15$ and $n = 16$.",
  "Forgetting that the first row is counted, which loses one row.",
  "C13A-seats-rows", "One equation for $n$; the trap is the $+1$.",
  correct=r"$16$",
  distractors=[(r"$15$", "Computes $\\frac{72-12}{4}$ and does not add $1$."),
               (r"$18$", "Divides the last row by the increment: $\\frac{72}{4}$."),
               (r"$19$", "Divides the last row by the increment and adds $1$: $\\frac{72}{4} + 1$.")],
  check=_c013, values=[16, 15, 18, 19], cognitive="Application")

# ---------------------------------------------------------------- MEDIUM

def _c014():
    a, d = symbols('a d')
    t = lambda k: a + (k - 1)*d
    asol = solve(Eq(t(3) + t(7) + t(11) + t(15), 96), a)[0]
    return simplify(sum(t(k) for k in range(1, 18)).subs(a, asol))
q("C13-A-014", T, "Sum from a sum of terms placed symmetrically", "Medium",
  "Conceptual/application",
  r"In an arithmetic progression, the sum of the $3$rd, $7$th, $11$th and $15$th terms is $96$. What is the sum of the first $17$ terms?",
  "MCQ",
  r"In an AP, terms equidistant from the ends of a block have equal sums: $t_3 + t_{15} = t_7 + t_{11} = t_1 + t_{17}$. So $t_1 + t_{17} = \frac{96}{2} = 48$ and $S_{17} = \frac{17}{2} \times 48 = 408$.",
  r"Pairing correctly but then taking the wrong number of terms or dropping the factor $\frac{1}{2}$.",
  "C13A-symmetric-sum-pairs", "Needs the paired-terms property; $a$ and $d$ cannot be found separately.",
  correct=r"$408$",
  distractors=[(r"$816$", "Uses $S_{17} = 17 \\times 48$, dropping the $\\frac{1}{2}$."),
               (r"$384$", "Uses $16$ terms: $\\frac{16}{2} \\times 48$."),
               (r"$432$", "Uses $18$ terms: $\\frac{18}{2} \\times 48$.")],
  check=_c014, values=[408, 816, 384, 432], cognitive="Analysis")


def _c015():
    good = []
    for n in range(3, 200):
        angles = [100 + 10*k for k in range(n)]
        if sum(angles) == (n - 2)*180 and max(angles) < 180:
            good.append(n)
    assert len(good) == 1
    return good[0]
q("C13-A-015", T, "Number of sides of a convex polygon whose angles form an AP", "Medium",
  "Inverse/parameter",
  r"The interior angles of a convex polygon, taken in increasing order, form an arithmetic progression. The smallest angle is $100^\circ$ and the common difference is $10^\circ$. How many sides does the polygon have?",
  "TITA",
  r"Sum of angles $= \frac{n}{2}(200 + 10(n-1)) = 5n^2 + 95n$, and this equals $180(n-2)$. So $5n^2 - 85n + 360 = 0$, i.e. $n^2 - 17n + 72 = 0$, giving $n = 8$ or $9$. For $n = 9$ the largest angle would be $100 + 80 = 180^\circ$, impossible in a convex polygon. For $n = 8$ the largest is $170^\circ$. So $n = 8$.",
  r"Accepting both roots of the quadratic without checking that every angle is below $180^\circ$.",
  "C13A-polygon-angles-ap", "Quadratic in $n$ with a root that must be rejected using geometry.",
  tita_answer=8, check=_c015,
  tita_traps=[(9, "Takes the larger root without checking that the largest angle would be $180^\\circ$."),
              (17, "Adds the two roots of the quadratic.")],
  cognitive="Analysis")


def _c016():
    n = symbols('n')
    S1 = n*(3*n + 5); S2 = n*(5*n + 1)
    a7 = S1.subs(n, 7) - S1.subs(n, 6); b7 = S2.subs(n, 7) - S2.subs(n, 6)
    return Rational(a7, b7)
q("C13-A-016", T, "Ratio of corresponding terms from the ratio of sums", "Medium",
  "Conceptual/application",
  r"For two arithmetic progressions, the ratio of the sums of their first $n$ terms is $(3n + 5) : (5n + 1)$ for every $n$. What is the ratio of their $7$th terms?",
  "MCQ",
  r"$\frac{S_n}{S'_n} = \frac{2a + (n-1)d}{2a' + (n-1)d'}$. The $7$th terms are $a + 6d$ and $a' + 6d'$, which match the numerator and denominator when $n - 1 = 12$, i.e. $n = 13$. So the ratio is $\frac{3(13) + 5}{5(13) + 1} = \frac{44}{66} = 2 : 3$.",
  "Substituting $n = 7$ directly into the ratio of sums.",
  "C13A-ratio-of-sums-to-terms", "Requires matching $a + 6d$ with $2a + (n-1)d$ to pick $n = 13$.",
  correct=r"$2 : 3$",
  distractors=[(r"$13 : 18$", "Substitutes $n = 7$ into the ratio of sums: $26 : 36$."),
               (r"$47 : 71$", "Substitutes $n = 2 \\times 7 = 14$."),
               (r"$41 : 61$", "Substitutes $n = 12$, the value of $n - 1$, in place of $n = 13$.")],
  check=_c016, values=[Rational(2, 3), Rational(13, 18), Rational(47, 71), Rational(41, 61)], cognitive="Analysis")


def _c017():
    A = {17 + 4*k for k in range(101)}
    B = {16 + 5*k for k in range(101)}
    return len(A & B)
q("C13-A-017", T, "Number of terms common to two finite APs", "Medium",
  "Multi-step word problem",
  r"The first $101$ terms of the arithmetic progression $17, 21, 25, \ldots$ and the first $101$ terms of the arithmetic progression $16, 21, 26, \ldots$ are written down. How many numbers appear in both lists?",
  "TITA",
  r"The first list ends at $17 + 400 = 417$ and the second at $16 + 500 = 516$. The first common term is $21$, and common terms recur every $\mathrm{lcm}(4, 5) = 20$: $21, 41, \ldots$. They must not exceed the smaller last term $417$, so the last is $401$. Count $= \frac{401 - 21}{20} + 1 = 20$.",
  "Bounding the common terms by the larger list's last term.",
  "C13A-common-terms", "First common term, lcm of differences and the correct upper bound.",
  tita_answer=20, check=_c017,
  tita_traps=[(25, "Uses $516$, the end of the second list, as the bound: $21$ to $501$."),
              (19, "Computes $\\frac{401 - 21}{20}$ and forgets to add $1$.")],
  cognitive="Application")


def _c018():
    best = 0; s = 0
    for k in range(200):
        s += 50 - 3*k
        best = max(best, s)
    return best
q("C13-A-018", T, "Maximum running total of a decreasing AP", "Medium",
  "Casework/optimisation",
  r"A new stall earns a profit of Rs. $50$ on its first day, and on each later day its profit is Rs. $3$ less than on the day before (a negative profit is a loss). The stall stays open indefinitely. What is the maximum total profit, in rupees, that it has accumulated at the end of any day?",
  "TITA",
  r"The daily profits $50, 47, 44, \ldots$ stay positive while $50 - 3(n-1) > 0$, that is up to $n = 17$ (day $17$ earns Rs. $2$, day $18$ loses Rs. $1$). The total peaks after day $17$: $\frac{17}{2}(50 + 2) = 442$.",
  "Stopping one day early or one day late around the sign change.",
  "C13A-max-partial-sum", "Locate the last positive term, then sum.",
  tita_answer=442, check=_c018,
  tita_traps=[(440, "Stops after day $16$: $\\frac{16}{2}(50 + 5)$."),
              (441, "Includes day $18$, whose profit is $-1$.")],
  cognitive="Analysis")


def _c019():
    return sum(1 for d in range(1, 200) if (89 - 5) % d == 0)
q("C13-A-019", T, "Count integer APs with a fixed first term containing a given number", "Medium",
  "Casework/optimisation",
  r"An increasing arithmetic progression has first term $5$, all its terms are integers, and $89$ is one of its terms. How many such arithmetic progressions are there?",
  "TITA",
  r"If $89$ is the $(k+1)$th term then $5 + kd = 89$, so $kd = 84$ with $d$ a positive integer. Every positive divisor $d$ of $84$ works. Since $84 = 2^2 \times 3 \times 7$, it has $3 \times 2 \times 2 = 12$ divisors, so there are $12$ progressions.",
  "Excluding $d = 1$ or $d = 84$ as trivial cases.",
  "C13A-integer-ap-divisors", "Turn membership into divisibility and count divisors.",
  tita_answer=12, check=_c019,
  tita_traps=[(11, "Excludes $d = 84$ (where $89$ is the second term)."),
              (10, "Excludes both $d = 1$ and $d = 84$ as trivial cases.")],
  cognitive="Analysis")


def _c020():
    p = qq = 0
    for day in range(1, 100):
        p += 30
        qq += 12 + 3*(day - 1)
        if qq >= p:
            return day
q("C13-A-020", T, "Constant daily distance versus an AP of daily distances", "Medium",
  "Multi-step word problem",
  r"Priya and Kabir set out together from the same village along the same road in the same direction. Priya walks $30$ km every day. Kabir walks $12$ km on the first day and on each later day walks $3$ km more than on the previous day. They walk during the same hours each day, and each walks at a uniform speed during those hours. At the end of which day does Kabir catch up with Priya? Give the day number.",
  "TITA",
  r"After $n$ days Priya has covered $30n$ km and Kabir $\frac{n}{2}(24 + 3(n-1))$ km. Equating, $24 + 3(n - 1) = 60$, so $n - 1 = 12$ and $n = 13$. Check: Kabir covers $\frac{13}{2}(12 + 48) = 390 = 30 \times 13$ km. Before day $13$ ends he is behind.",
  "Finding when Kabir's daily distance equals $30$ km rather than when the totals are equal.",
  "C13A-constant-vs-ap-catchup", "Equate a linear total with an AP sum.",
  tita_answer=13, check=_c020,
  tita_traps=[(7, "Solves $12 + 3(n-1) = 30$: the day Kabir's daily distance matches Priya's."),
              (12, "Uses $\\frac{n}{2}(24 + 3n)$ for Kabir's total, giving $n = 12$.")],
  cognitive="Application")


def _c021():
    n = symbols('n', positive=True)
    nv = [s for s in solve(Eq(n*(2*1000 + (n - 1)*200)/2, 196000), n) if s > 0][0]
    return 1000 + (nv - 1)*200
q("C13-A-021", T, "Last instalment when instalments rise by a fixed amount", "Medium",
  "Multi-step word problem",
  r"Joseph repays an interest-free loan of Rs. $1{,}96{,}000$ in monthly instalments. The first instalment is Rs. $1{,}000$ and each instalment is Rs. $200$ more than the previous one. The loan is cleared exactly by the last instalment. What is the last instalment?",
  "MCQ",
  r"With $n$ instalments, $\frac{n}{2}(2000 + 200(n-1)) = 196000$, so $n(100n + 900) = 196000$, i.e. $n^2 + 9n - 1960 = 0 = (n - 40)(n + 49)$. So $n = 40$ and the last instalment is Rs. $1000 + 39 \times 200$, that is Rs. $8{,}800$.",
  "Using $a + nd$ for the last instalment.",
  "C13A-savings-sum", "Quadratic for the number of instalments, then the last term.",
  correct=r"Rs. $8{,}800$",
  distractors=[(r"Rs. $9{,}000$", "Uses $1000 + 40 \\times 200$ for the $40$th instalment."),
               (r"Rs. $4{,}900$", "Reports the average instalment $\\frac{196000}{40}$."),
               (r"Rs. $8{,}600$", "Uses $1000 + 38 \\times 200$.")],
  check=_c021, values=[8800, 9000, 4900, 8600], cognitive="Application")


def _c022():
    total = 0
    for m in range(1, 200):
        total += 200 + 50*(m - 1)
        if total >= 20000:
            return m
q("C13-A-022", T, "Months needed for AP savings to reach a target", "Medium",
  "Inverse/parameter",
  r"Arjun saves Rs. $200$ in the first month and, in every later month, Rs. $50$ more than in the previous month. At the end of which month do his total savings first reach Rs. $20{,}000$? Give the month number.",
  "TITA",
  r"$S_n = \frac{n}{2}(400 + 50(n-1)) = 25n^2 + 175n$. Setting $25n^2 + 175n = 20000$ gives $n^2 + 7n - 800 = 0 = (n - 25)(n + 32)$. So the total reaches exactly Rs. $20{,}000$ at the end of month $25$ (after $24$ months it is only Rs. $18{,}600$).",
  "Assuming a constant monthly saving, or stopping one month early.",
  "C13A-savings-sum", "Inverse use of the sum formula; solve a quadratic in $n$.",
  tita_answer=25, check=_c022,
  tita_traps=[(100, "Assumes he saves a constant Rs. $200$ every month."),
              (24, "Takes the month before the target is reached.")],
  cognitive="Application")


def _c023():
    res = []
    for N in range(3, 200, 2):
        m = (N - 1)//2
        # odd-position sum : even-position sum = (m+1) : m ; middle term M = 180 - 162
        M = 180 - 162
        if (m + 1)*M == 180 and m*M == 162:
            res.append(N)
    assert len(res) == 1
    return res[0]
q("C13-A-023", T, "Number of terms from sums at odd and even positions", "Medium",
  "Conceptual/application",
  r"An arithmetic progression has an odd number of terms. The sum of the terms in the odd positions ($1$st, $3$rd, $5$th, $\ldots$) is $180$ and the sum of the terms in the even positions ($2$nd, $4$th, $\ldots$) is $162$. How many terms does the progression have?",
  "MCQ",
  r"Let there be $2m + 1$ terms with middle term $M$. The $m + 1$ odd-position terms form an AP whose average is $M$, and so do the $m$ even-position terms. So $(m + 1)M = 180$ and $mM = 162$. Subtracting, $M = 18$ and $m = 9$, giving $2m + 1 = 19$ terms.",
  "Reporting $m$ or $m + 1$ instead of the total number of terms.",
  "C13A-odd-even-position-sums", "Uses the fact that both sub-progressions have the middle term as average.",
  correct=r"$19$",
  distractors=[(r"$9$", "Reports $m$, the number of even-position terms."),
               (r"$10$", "Reports $m + 1$, the number of odd-position terms."),
               (r"$18$", "Reports the middle term $180 - 162$.")],
  check=_c023, values=[19, 9, 10, 18], cognitive="Analysis")


def _c024():
    c = 0
    for n in range(100, 1000):
        x, y, z = map(int, str(n))
        if len({x, y, z}) == 3 and 2*y == x + z:
            c += 1
    return c
q("C13-A-024", T, "Count three-digit numbers whose distinct digits form an AP", "Medium",
  "Casework/optimisation",
  r"How many three-digit numbers have three different digits that, read from left to right, form an arithmetic progression (increasing or decreasing)?",
  "MCQ",
  r"Let the digits be $x, x + d, x + 2d$ with $d \neq 0$ and $x \geq 1$. Increasing ($d > 0$): $x + 2d \leq 9$ gives $7, 5, 3, 1$ choices of $x$ for $d = 1, 2, 3, 4$: $16$. Decreasing ($d = -e$, $e > 0$): the last digit $x - 2e \geq 0$ with $x \leq 9$ gives $8, 6, 4, 2$ choices for $e = 1, 2, 3, 4$: $20$. Total $36$.",
  "Counting only increasing progressions, or including numbers like $555$ with $d = 0$.",
  "C13A-count-ap-triples", "Casework on the sign and size of $d$ with the digit-zero asymmetry.",
  correct=r"$36$",
  distractors=[(r"$45$", "Includes the $9$ numbers $111, \\ldots, 999$ with $d = 0$, whose digits are not different."),
               (r"$16$", "Counts only increasing progressions."),
               (r"$32$", "Counts decreasing progressions like the increasing ones ($16$ each), missing those ending in $0$.")],
  check=_c024, values=[36, 45, 16, 32], cognitive="Analysis", exams=X2)


def _c025():
    ok = []
    for n in range(1, 100):
        rows = [24 - k for k in range(n)]
        if sum(rows) == 234 and min(rows) >= 1:
            ok.append(n)
    assert len(ok) == 1
    return ok[0]
q("C13-A-025", T, "Number of rows in a stack, rejecting an impossible root", "Medium",
  "Inverse/parameter",
  r"Logs are stacked in rows: $24$ logs in the bottom row, and each row above has one log fewer than the row below it. If $234$ logs are used in all, how many rows are there?",
  "MCQ",
  r"With $n$ rows, $\frac{n}{2}(48 - (n-1)) = 234$, so $n(49 - n) = 468$, i.e. $n^2 - 49n + 468 = 0 = (n - 13)(n - 36)$. With $36$ rows the top row would have $24 - 35 = -11$ logs, which is impossible. So there are $13$ rows (the top row has $12$ logs).",
  "Accepting the larger root without checking the top row.",
  "C13A-inverse-sum-rejected-root", "Quadratic in $n$ with one physically impossible root.",
  correct=r"$13$",
  distractors=[(r"$36$", "Takes the larger root of $n^2 - 49n + 468 = 0$ without checking the top row."),
               (r"$12$", "Reports the number of logs in the top row."),
               (r"$10$", "Divides $234$ by $24$ as if every row had $24$ logs, and rounds up.")],
  check=_c025, values=[13, 36, 12, 10], cognitive="Application")


def _c026():
    sols = set()
    for a in range(-50, 51):
        for d in range(1, 30):
            t = [a + k*d for k in range(4)]
            if sum(t) == 26 and t[0]*t[1]*t[2]*t[3] == 880:
                sols.add(t[3])
    assert len(sols) == 1
    return sols.pop()
q("C13-A-026", T, "Four integers in AP from their sum and product", "Medium",
  "Multi-step word problem",
  r"Four integers form an increasing arithmetic progression. Their sum is $26$ and their product is $880$. What is the largest of them?",
  "MCQ",
  r"Write them as $a - 3e, a - e, a + e, a + 3e$ (common difference $2e$). Then $4a = 26$, $a = 6.5$. The product is $(42.25 - 9e^2)(42.25 - e^2) = 880$. Trying $e = 1.5$ (difference $3$) gives $22 \times 40 = 880$: the numbers are $2, 5, 8, 11$. The other root of the quadratic in $e^2$ is not the square of a half-integer, so the terms would not be integers. The largest is $11$.",
  "Using $a + 4d$ for the fourth term, or reporting another term.",
  "C13A-symmetric-terms", "Symmetric choice with a half-integer centre and an integrality check.",
  correct=r"$11$",
  distractors=[(r"$8$", "Reports the third term."),
               (r"$14$", "Finds first term $2$ and $d = 3$, then writes the fourth term as $2 + 4 \\times 3$."),
               (r"$2$", "Reports the smallest of the four numbers.")],
  check=_c026, values=[11, 8, 14, 2], cognitive="Application")


def _c027():
    a, d = symbols('a d')
    s = solve([Eq(a + 11*d, 30), Eq(a + 29*d, -6)], [a, d])
    return sum(s[a] + k*s[d] for k in range(41))
q("C13-A-027", T, "Sum of the first 41 terms from two given terms, one of them negative", "Medium",
  "Conceptual/application",
  r"In an arithmetic progression, the $12$th term is $30$ and the $30$th term is $-6$. What is the sum of its first $41$ terms?",
  "MCQ",
  r"From the $12$th to the $30$th term there are $18$ steps, so $18d = -6 - 30 = -36$ and $d = -2$. Then $a = 30 + 11 \times 2 = 52$ and the $41$st term is $52 - 40 \times 2 = -28$. So $S_{41} = \frac{41}{2}(52 - 28) = 41 \times 12 = 492$.",
  "Off-by-one in the number of terms or in the first term.",
  "C13A-term-from-two-terms", "Two terms give $d$ and $a$; the sign change and the count of steps are the traps.",
  correct=r"$492$",
  distractors=[(r"$520$", "Sums only $40$ terms: $\\frac{40}{2}(104 - 78)$."),
               (r"$984$", "Uses $S_{41} = 41(52 - 28)$, dropping the $\\frac{1}{2}$."),
               (r"$574$", "Takes the first term as $30 + 12 \\times 2 = 54$, then $\\frac{41}{2}(108 - 80)$.")],
  check=_c027, values=[492, 520, 984, 574], cognitive="Application")


def _c028():
    ns = [n for n in range(1, 200) if sum(25 - 2*k for k in range(n)) == 144]
    return FiniteSet(*ns)
q("C13-A-028", T, "Two valid numbers of terms for a given sum", "Medium",
  "Conceptual/application",
  r"How many terms of the arithmetic progression $25, 23, 21, \ldots$, taken from the beginning, must be added to get a sum of $144$?",
  "MCQ",
  r"$S_n = \frac{n}{2}(50 - 2(n-1)) = n(26 - n) = 144$, so $n^2 - 26n + 144 = 0 = (n - 8)(n - 18)$. Both work: terms $9$ to $18$ are $9, 7, \ldots, -9$, which add to $0$. So $n = 8$ or $18$.",
  "Rejecting the larger root because some terms are negative.",
  "C13A-two-valid-term-counts", "Both roots are valid because the extra terms cancel out.",
  correct=r"$8$ or $18$",
  distractors=[(r"$8$ only", "Rejects $18$ on the belief that adding negative terms cannot give the same sum."),
               (r"$9$ or $16$", "Uses $\\frac{n}{2}(50 - 2n)$, so $n(25 - n) = 144$."),
               (r"$18$ only", "Keeps only the larger root, believing all $13$ positive terms must be included.")],
  check=_c028, values=[FiniteSet(8, 18), FiniteSet(8), FiniteSet(9, 16), FiniteSet(18)],
  cognitive="Analysis", exams=X2)


def _c029():
    P = Q = 0
    for yr in range(1, 100):
        P += 600000 + 20000*(yr - 1)
        Q += 480000 + 40000*(yr - 1)
        if Q > P:
            return yr
q("C13-A-029", T, "When one AP running total overtakes another", "Medium",
  "Inverse/parameter",
  r"Job offer P pays Rs. $6{,}00{,}000$ in the first year with a raise of Rs. $20{,}000$ every year. Job offer Q pays Rs. $4{,}80{,}000$ in the first year with a raise of Rs. $40{,}000$ every year. After how many complete years will the total amount earned under Q first exceed the total earned under P?",
  "MCQ",
  r"After $n$ years the totals are $\frac{n}{2}(1200000 + 20000(n-1))$ and $\frac{n}{2}(960000 + 40000(n-1))$. They are equal when $240000 = 20000(n - 1)$, i.e. $n = 13$. After that Q's total grows faster, so it first exceeds P's after $14$ years.",
  "Stopping at the year when the totals are equal, or comparing yearly salaries.",
  "C13A-constant-vs-ap-catchup", "Equate two AP sums, then interpret strict inequality.",
  correct=r"$14$",
  distractors=[(r"$13$", "Reports the year when the totals are equal, not when Q's is larger."),
               (r"$8$", "Compares yearly salaries: Q's salary first exceeds P's in year $8$."),
               (r"$12$", "Solves $n - 1 = 12$ and reports $12$.")],
  check=_c029, values=[14, 13, 8, 12], cognitive="Application")


def _c030():
    return sum(x for x in range(100, 501) if x % 7 != 0)
q("C13-A-030", T, "Sum of integers in a range not divisible by a number", "Medium",
  "Multi-step word problem",
  r"What is the sum of all integers from $100$ to $500$, both inclusive, that are not divisible by $7$?",
  "MCQ",
  r"Sum of all: $\frac{401}{2}(100 + 500) = 120300$. Multiples of $7$ in the range: $105, 112, \ldots, 497$, which is $\frac{497 - 105}{7} + 1 = 57$ terms with sum $\frac{57}{2}(105 + 497) = 17157$. Required sum $= 120300 - 17157 = 103143$.",
  "Miscounting the multiples of $7$ or the endpoints.",
  "C13A-sum-of-multiples", "Two AP sums and a subtraction.",
  correct=r"$103143$",
  distractors=[(r"$17157$", "Reports the sum of the multiples of $7$."),
               (r"$103640$", "Counts $56$ multiples of $7$ ending at $490$, sum $16660$."),
               (r"$102543$", "Excludes the endpoints $100$ and $500$ from the total.")],
  check=_c030, values=[103143, 17157, 103640, 102543], cognitive="Application")


def _c031():
    a = [4*n + 1 for n in range(1, 11)]
    b = [2*n + 3 for n in range(1, 11)]
    return Rational(sum(a), sum(b))
q("C13-A-031", T, "Ratio of sums from the ratio of nth terms", "Medium",
  "Conceptual/application",
  r"For two arithmetic progressions, the ratio of their $n$th terms is $(4n + 1) : (2n + 3)$ for every $n$. What is the ratio of the sums of their first $10$ terms?",
  "MCQ",
  r"The sum of the first $10$ terms of an AP is $10$ times the average of its $1$st and $10$th terms, which is the value of the linear $n$th-term formula at $n = 5.5$. So the ratio is $\frac{4(5.5) + 1}{2(5.5) + 3} = \frac{23}{14}$, i.e. $23 : 14$. (Directly: $\frac{5 + 41}{5 + 23} = \frac{46}{28}$.)",
  "Substituting $n = 10$ into the ratio of terms.",
  "C13A-ratio-of-sums-to-terms", "Reverse direction of the ratio rule; needs the average-term idea.",
  correct=r"$23 : 14$",
  distractors=[(r"$41 : 23$", "Substitutes $n = 10$ into the ratio of $n$th terms."),
               (r"$21 : 13$", "Substitutes $n = 5$, taking the middle as the $5$th term."),
               (r"$5 : 3$", "Substitutes $n = 6$: $25 : 15$.")],
  check=_c031, values=[Rational(23, 14), Rational(41, 23), Rational(21, 13), Rational(5, 3)],
  cognitive="Analysis", exams=X2)


def _c032():
    a, d = symbols('a d')
    S = lambda n: n*(2*a + (n - 1)*d)/2
    s = solve([Eq(S(5), 150), Eq(a + 11*d, 3*(a + d))], [a, d])
    return s[a] + 19*s[d]
q("C13-A-032", T, "A later term from a running total and a ratio between two terms", "Medium",
  "Multi-step word problem",
  r"A workshop assembles chairs, and its daily output rises by the same number of chairs every day. It assembles $150$ chairs in all in the first $5$ days, and on day $12$ it assembles three times as many chairs as on day $2$. How many chairs does it assemble on day $20$?",
  "MCQ",
  r"Let day $1$ give $a$ chairs and the daily rise be $d$. The ratio condition gives $a + 11d = 3(a + d)$, so $2a = 8d$ and $a = 4d$. The average of the first $5$ days is $\frac{150}{5} = 30$, which is the day $3$ figure: $a + 2d = 6d = 30$, so $d = 5$ and $a = 20$. Day $20$: $20 + 19 \times 5 = 115$ chairs.",
  "Taking the average of the first five days as the day $2$ figure instead of the day $3$ figure.",
  "C13A-sum-and-term-relation", "A ratio condition gives $a$ in terms of $d$; the running total then fixes $d$.",
  correct=r"$115$",
  distractors=[(r"$120$", "Uses $20 + 20 \\times 5$ for day $20$."),
               (r"$110$", "Uses $20 + 18 \\times 5$, the figure for day $19$."),
               (r"$138$", "Takes the five-day average $30$ as the day $2$ figure: $a + d = 5d = 30$, so $d = 6$, $a = 24$, then $24 + 19 \\times 6$.")],
  check=_c032, values=[115, 120, 110, 138], cognitive="Application")


def _c033():
    for n in range(1, 200):
        T0 = n*(n + 1)//2
        extra = 1000 - T0
        if 1 <= extra <= n:
            return extra
q("C13-A-033", T, "Page number added twice in the sum of 1 to n", "Medium",
  "Inverse/parameter",
  r"The pages of a book are numbered $1, 2, 3, \ldots$ up to the last page. While adding all the page numbers, Fatima added one page number twice by mistake and got $1{,}000$. Which page number did she add twice?",
  "TITA",
  r"The correct total $\frac{n(n+1)}{2}$ is less than $1000$ by at most $n$. Since $\frac{44 \times 45}{2} = 990$ and $\frac{45 \times 46}{2} = 1035$, the book has $44$ pages ($n = 43$ gives $946$, short by $54 > 43$). The repeated page is $1000 - 990 = 10$.",
  "Choosing the wrong $n$ by not checking that the excess is at most $n$.",
  "C13A-sum-of-naturals-error", "Bound $n$ using the triangular numbers, then subtract.",
  tita_answer=10, check=_c033,
  tita_traps=[(44, "Reports the number of pages instead of the repeated page."),
              (54, "Takes $n = 43$, total $946$, without checking that $54$ exceeds the last page.")],
  cognitive="Analysis")


def _c034():
    t = lambda k: 4 + 3*(k - 1)
    return sum(t(k) for k in range(2, 30, 3))
q("C13-A-034", T, "Sum of terms at positions forming an AP", "Medium",
  "Conceptual/application",
  r"An arithmetic progression has first term $4$ and common difference $3$. What is the sum $t_2 + t_5 + t_8 + \cdots + t_{29}$, where $t_k$ is its $k$th term?",
  "MCQ",
  r"Positions $2, 5, \ldots, 29$ number $\frac{29-2}{3} + 1 = 10$. The chosen terms form an AP with first term $t_2 = 7$ and difference $3 \times 3 = 9$, ending at $t_{29} = 4 + 28 \times 3 = 88$. Sum $= \frac{10}{2}(7 + 88) = 475$.",
  "Keeping the original difference $3$ for the selected terms, or miscounting positions.",
  "C13A-ap-subsequence-sum", "Recognise the selected terms form an AP with difference $3d$.",
  correct=r"$475$",
  distractors=[(r"$387$", "Counts $9$ positions, stopping at $t_{26} = 79$: $\\frac{9}{2}(7 + 79)$."),
               (r"$205$", "Uses $10$ terms from $7$ with the original difference $3$: $\\frac{10}{2}(14 + 27)$."),
               (r"$572$", "Counts $11$ positions, going up to $t_{32} = 97$: $\\frac{11}{2}(7 + 97)$.")],
  check=_c034, values=[475, 387, 205, 572], cognitive="Application")

# ---------------------------------------------------------------- DIFFICULT

def _c035():
    a = 82
    d = symbols('d')
    S = lambda n: n*(2*a + (n - 1)*d)/2
    dv = [x for x in solve(Eq(S(12), S(30)), d) if x != 0][0]
    best = None; s = 0
    for k in range(200):
        s += a + k*dv
        best = s if best is None else max(best, s)
    return best
q("C13-A-035", T, "Maximum partial sum when two partial sums are equal", "Difficult",
  "Casework/optimisation",
  r"The first term of an arithmetic progression is $82$, and the sum of its first $12$ terms equals the sum of its first $30$ terms. What is the greatest possible value of the sum of its first $n$ terms, over all positive integers $n$?",
  "MCQ",
  r"$S_{12} = S_{30}$ means $t_{13} + \cdots + t_{30} = 0$; these $18$ terms pair up as $t_{13} + t_{30} = 0$, i.e. $2a + 41d = 0$, so $d = -4$. The terms $82, 78, \ldots$ stay positive up to $t_{21} = 82 - 80 = 2$, and $t_{22} = -2$. So the maximum is $S_{21} = \frac{21}{2}(82 + 2) = 882$.",
  "Stopping one term early or late, or off-by-one in the $21$st term.",
  "C13A-max-partial-sum", "Turn equal sums into $d$, then locate the sign change.",
  correct=r"$882$",
  distractors=[(r"$880$", "Stops at $S_{20}$ (or includes $t_{22} = -2$, giving $S_{22}$); both equal $880$."),
               (r"$1764$", "Uses $21 \\times 84$, dropping the $\\frac{1}{2}$."),
               (r"$924$", "Takes $t_{21} = 82 - 19 \\times 4 = 6$, then $\\frac{21}{2}(82 + 6)$.")],
  check=_c035, values=[882, 880, 1764, 924], cognitive="Analysis", exams=X2)


def _c036():
    c = 0
    for n in range(3, 101):
        for a in range(1, 101):
            for d in range(1, 101):
                s = n*a + d*n*(n - 1)//2
                if s > 100:
                    break
                if s == 100:
                    c += 1
    return c
q("C13-A-036", T, "Count APs of positive integers with a fixed sum", "Difficult",
  "Casework/optimisation",
  r"An arithmetic progression has at least $3$ terms, its first term and common difference are positive integers, and the sum of all its terms is $100$. Two progressions are different if they differ in the first term, the common difference or the number of terms. How many such progressions are there?",
  "TITA",
  r"With $n$ terms, $n(2a + (n-1)d) = 200$, and $2a + (n-1)d \geq 2 + (n-1) = n + 1$, so $n(n+1) \leq 200$, $n \leq 13$; also $n$ divides $200$. $n = 4$: $2a + 3d = 50$, $d$ even, $d = 2, 4, \ldots, 16$: $8$. $n = 5$: $a + 2d = 20$, $d = 1, \ldots, 9$: $9$. $n = 8$: $2a + 7d = 25$, $d$ odd, $d = 1, 3$: $2$. $n = 10$: $2a + 9d = 20$, $d = 2$, $a = 1$: $1$. Total $8 + 9 + 2 + 1 = 20$.",
  "Missing a case for $n$ or a parity restriction on $d$.",
  "C13A-ap-fixed-sum-integers", "Divisor casework on $n$ with parity conditions on $d$.",
  tita_answer=20, check=_c036,
  tita_traps=[(19, "Misses the single progression with $10$ terms ($1, 3, \\ldots, 19$)."),
              (69, "Also counts the $49$ two-term progressions, which the stem excludes.")],
  cognitive="Analysis", exams=X2)


def _c037():
    c = 0
    for k in range(2, 200):
        for a in range(1, 1050):
            s = k*a + k*(k - 1)//2
            if s > 1050:
                break
            if s == 1050:
                c += 1
    return c
q("C13-A-037", T, "Ways to write a number as a sum of consecutive positive integers", "Difficult",
  "Casework/optimisation",
  r"A hall manager wants to arrange exactly $1{,}050$ chairs in at least two rows so that every row has at least one chair and each row has exactly one chair more than the row in front of it. In how many different ways can this be done (a way is fixed by the number of chairs in the front row and the number of rows)?",
  "TITA",
  r"With $k$ rows and $a$ chairs in front, $k(2a + k - 1) = 2100$. The factors $k$ and $2a + k - 1$ have opposite parity, the smaller one is $k$ and the larger is at least $k + 1$. Each odd divisor of $1050$ gives exactly one such factorisation of $2100$. Since $1050 = 2 \times 3 \times 5^2 \times 7$, its odd part $525$ has $2 \times 3 \times 2 = 12$ divisors. The divisor $1$ gives the single row $k = 1$, which is not allowed, so there are $11$ ways.",
  "Counting the single-row arrangement, or counting all divisors instead of odd divisors.",
  "C13A-consecutive-integer-sums", "Needs the odd-divisor characterisation of consecutive sums.",
  tita_answer=11, check=_c037,
  tita_traps=[(12, "Counts the trivial single-row arrangement."),
              (23, "Uses all $24$ divisors of $1050$ and subtracts $1$.")],
  cognitive="Analysis", exams=X2)


def _c038():
    p = qd = 0
    # P travels 1 to 4 March alone
    p = 30*4
    date = 4
    while True:
        date += 1
        p += 30
        qd += 15 + 6*(date - 5)
        if qd >= p:
            return date
q("C13-A-038", T, "Catch-up date when the AP traveller starts later", "Difficult",
  "Multi-step word problem",
  r"Harpreet leaves a town on the morning of $1$ March and travels $30$ km every day along a straight road. Ravi leaves the same town on the morning of $5$ March along the same road in the same direction. He travels $15$ km on his first day and, on each later day, $6$ km more than on the previous day. Both travel during the same hours each day at uniform speed. On which date does Ravi catch up with Harpreet?",
  "MCQ",
  r"By the time Ravi starts, Harpreet has $4$ days ($1$ to $4$ March) in hand. After Ravi's $n$th day, Harpreet has covered $30(n + 4)$ km and Ravi $15n + 3n(n - 1)$ km. Equating, $3n^2 - 18n - 120 = 0$, so $n^2 - 6n - 40 = 0 = (n - 10)(n + 4)$ and $n = 10$. Ravi's $10$th day is $14$ March, when both have covered $420$ km.",
  "Off-by-one when converting a day count into a date.",
  "C13A-constant-vs-ap-catchup", "Head start plus AP sum gives a quadratic, then a careful date conversion.",
  correct=r"$14$ March",
  distractors=[(r"$15$ March", "Adds $10$ days to $5$ March, counting the start day twice."),
               (r"$10$ March", "Reports Ravi's day count $n = 10$ as the date."),
               (r"$18$ March", "Adds Harpreet's $4$-day head start again to the correct date.")],
  check=_c038, values=[14, 15, 10, 18], cognitive="Analysis", exams=X2)


def _c039():
    found = set()
    for n in range(2, 200, 2):
        total = n*(n + 1)//2
        for k in range(1, n//2 + 1):
            if total - (2*k - 1) - 2*k == 1779:
                found.add(2*k)
    assert len(found) == 1
    return found.pop()
q("C13-A-039", T, "Identify a torn leaf from the sum of the remaining page numbers", "Difficult",
  "Inverse/parameter",
  r"The pages of a booklet are numbered $1, 2, 3, \ldots, n$, with $n$ even. Each leaf carries an odd-numbered page on its front and the next even-numbered page on its back. One leaf is torn out, and the page numbers on the remaining pages add up to $1{,}779$. What is the larger of the two page numbers on the torn leaf?",
  "TITA",
  r"The torn leaf has pages $2k - 1$ and $2k$, summing to $4k - 1 \leq 2n - 1$. So $\frac{n(n+1)}{2}$ lies between $1780$ and $1779 + 2n - 1$. $n = 58$ gives $1711 < 1779$, so $n \geq 60$; $n = 60$ gives $1830$, excess $51 = 4k - 1$, $k = 13$. $n = 62$ gives $1953$, excess $174$, which is more than $2n - 1 = 123$. So the leaf has pages $25$ and $26$, and the larger is $26$.",
  "Reporting the smaller page or the sum of the two pages.",
  "C13A-sum-of-naturals-error", "Bounding $n$ and the parity structure $4k - 1$ of a leaf.",
  tita_answer=26, check=_c039,
  tita_traps=[(25, "Reports the smaller page number on the leaf."),
              (51, "Reports the sum of the two missing page numbers.")],
  cognitive="Analysis", exams=X2)


def _c040():
    return sum(1 for t in itertools.combinations(range(1, 31), 3) if t[0] + t[2] == 2*t[1])
q("C13-A-040", T, "Count 3-element subsets of 1 to 30 that form an AP", "Difficult",
  "Casework/optimisation",
  r"In how many ways can three different numbers be chosen from $1, 2, 3, \ldots, 30$ so that they can be arranged to form an arithmetic progression?",
  "TITA",
  r"A chosen set $\{x, y, z\}$ with $x < y < z$ works exactly when $x + z = 2y$, i.e. $x$ and $z$ have the same parity (then $y$ is determined). There are $15$ odd and $15$ even numbers, so the choices are $\binom{15}{2} + \binom{15}{2} = 105 + 105 = 210$.",
  "Counting each set twice (increasing and decreasing order), or ignoring the parity condition.",
  "C13A-count-ap-triples", "Recast as choosing two endpoints of the same parity.",
  tita_answer=210, check=_c040,
  tita_traps=[(420, "Counts each set twice, once increasing and once decreasing."),
              (435, "Counts every pair of endpoints, $\\binom{30}{2}$, ignoring parity.")],
  cognitive="Analysis", exams=X2)


def _c041():
    A = set(4 + 7*k for k in range(60))
    B = set(3 + 5*k for k in range(100))
    return sum(x for x in A & B if x % 2 == 0)
q("C13-A-041", T, "Sum of the even terms common to two finite APs", "Difficult",
  "Multi-step word problem",
  r"List $1$ contains the first $60$ terms of the arithmetic progression $4, 11, 18, \ldots$ and list $2$ contains the first $100$ terms of the arithmetic progression $3, 8, 13, \ldots$. What is the sum of the even numbers that appear in both lists?",
  "MCQ",
  r"List $1$ ends at $4 + 59 \times 7 = 417$ and list $2$ at $3 + 99 \times 5 = 498$. Common terms satisfy $x \equiv 4 \pmod 7$ and $x \equiv 3 \pmod 5$; the first is $18$, and they recur every $35$, alternating between even and odd. So the even common terms are $18, 88, 158, \ldots$, recurring every $70$, and they cannot exceed $417$: $18, 88, 158, 228, 298, 368$, which is $6$ terms. Sum $= 3 \times (18 + 368) = 1158$.",
  "Using the larger list's last term as the bound, or forgetting the evenness condition.",
  "C13A-common-terms", "Three conditions: two residues and parity give a step of $70$, then the correct bound and a sum.",
  correct=r"$1158$",
  distractors=[(r"$2526$", "Ignores the word even and adds all $12$ common terms $18, 53, \\ldots, 403$: $6 \\times 421$."),
               (r"$1596$", "Bounds the common terms by $498$, the end of list $2$, so includes $438$: $7$ terms, $\\frac{7}{2}(18 + 438)$."),
               (r"$790$", "Counts $\\frac{368 - 18}{70} = 5$ even terms without adding $1$, stopping at $298$: $\\frac{5}{2}(18 + 298)$.")],
  check=_c041, values=[1158, 2526, 1596, 790], cognitive="Analysis", exams=X2)


def _c042():
    terms = [5 + 4*k for k in range(500)]
    assert terms[-1] == 2001
    sq = {i*i for i in range(1, 50)}
    return sum(1 for t in terms if t in sq)
q("C13-A-042", T, "Perfect squares among the terms of an AP", "Difficult",
  "Conceptual/application",
  r"How many terms of the arithmetic progression $5, 9, 13, 17, \ldots, 2001$ are perfect squares?",
  "MCQ",
  r"Every term leaves remainder $1$ on division by $4$. Even squares are multiples of $4$, while every odd square $(2m+1)^2 = 4m(m+1) + 1$ leaves remainder $1$. So the squares in the list are exactly the odd squares from $5$ to $2001$: $3^2, 5^2, \ldots, 43^2$ (since $45^2 = 2025$). Odd numbers $3$ to $43$ number $21$.",
  "Including $1^2$, which is below the first term, or counting all squares in the range.",
  "C13A-squares-in-ap", "Residue argument mod $4$ identifies exactly which squares occur.",
  correct=r"$21$",
  distractors=[(r"$22$", "Includes $1 = 1^2$, which is not a term."),
               (r"$42$", "Counts every perfect square from $3^2$ to $44^2$, odd or even."),
               (r"$10$", "Assumes the square root must also leave remainder $1$ on division by $4$: $5, 9, \\ldots, 41$.")],
  check=_c042, values=[21, 22, 42, 10], cognitive="Analysis", exams=X2)


def _c043():
    a, d = symbols('a d')
    S = lambda n: n*(2*a + (n - 1)*d)/2
    s = solve([Eq(S(10), 20), Eq(S(20), 70)], [a, d])
    n = 1
    while S(n).subs(s) < 1000:
        n += 1
    return n
q("C13-A-043", T, "Least number of terms for the sum to reach a target, given two partial sums", "Difficult",
  "Inverse/parameter",
  r"In an arithmetic progression, the sum of the first $10$ terms is $20$ and the sum of the first $20$ terms is $70$. What is the least number of terms, taken from the beginning, whose sum is at least $1000$?",
  "MCQ",
  r"The second block of $10$ terms sums to $70 - 20 = 50$, and each of its terms is $10d$ more than the matching term of the first block, so $100d = 30$ and $d = 0.3$. From $S_{10} = 5(2a + 9d) = 20$, $2a = 4 - 2.7 = 1.3$. Then $S_n = \frac{n}{2}(1.3 + 0.3(n - 1)) = \frac{n(3n + 10)}{20}$. Setting $n(3n + 10) = 20000$: $3n^2 + 10n - 20000 = 0$ has discriminant $100 + 240000 = 490^2$, so $n = \frac{-10 + 490}{6} = 80$. The sum of the first $80$ terms is exactly $1000$, and $S_{79} < 1000$, so the answer is $80$.",
  "Taking $70$ as the sum of terms $11$ to $20$, or treating the running totals as growing linearly.",
  "C13A-block-sums", "Two stages: block sums give $d$ and $a$, then a quadratic in $n$ with a large discriminant.",
  correct=r"$80$",
  distractors=[(r"$65$", "Takes $70$ as the sum of terms $11$ to $20$: $100d = 50$, $d = 0.5$, $a = -0.25$, so $S_n = \\frac{n(n-2)}{4}$, first reaching $1000$ at $n = 65$."),
               (r"$206$", "Assumes the running total grows by the same $50$ every $10$ terms, i.e. $5$ per term: $20 + 5(n - 10) \\geq 1000$ gives $n = 206$."),
               (r"$31$", "Takes consecutive block sums to differ by $10d$: $10d = 30$, $d = 3$, $a = -11.5$, so $S_n = \\frac{n(3n - 26)}{2}$, first reaching $1000$ at $n = 31$.")],
  check=_c043, values=[80, 65, 206, 31], cognitive="Analysis", exams=X2)


def _c044():
    return sum(x for x in range(100, 1000) if x % 5 == 2 and x % 3 != 0)
q("C13-A-044", T, "Sum of three-digit numbers with one remainder condition and one exclusion", "Difficult",
  "Multi-step word problem",
  r"What is the sum of all three-digit numbers that leave remainder $2$ when divided by $5$ but are not divisible by $3$?",
  "MCQ",
  r"Numbers with remainder $2$ mod $5$: $102, 107, \ldots, 997$, that is $180$ terms with sum $90 \times 1099 = 98910$. Among them, those divisible by $3$ satisfy $x \equiv 12 \pmod{15}$: $102, 117, \ldots, 987$, that is $60$ terms with sum $30 \times 1089 = 32670$. Required sum $= 98910 - 32670 = 66240$.",
  "Removing multiples of $15$ instead of the numbers that satisfy both conditions.",
  "C13A-sum-of-multiples", "Two interleaved APs found by combining remainders, then subtraction.",
  correct=r"$66240$",
  distractors=[(r"$98910$", "Ignores the condition about divisibility by $3$."),
               (r"$32670$", "Reports the sum of the numbers that are divisible by $3$."),
               (r"$66060$", "Subtracts the sum of all three-digit multiples of $15$, $32850$.")],
  check=_c044, values=[66240, 98910, 32670, 66060], cognitive="Application", exams=X2)


def _c045():
    pos = 0; dist = 0
    plants = [10 + 5*k for k in range(20)]
    for i, x in enumerate(plants):
        dist += abs(x - pos); pos = x
        if i % 2 == 1 and i < len(plants) - 1:
            dist += x; pos = 0
    return dist
q("C13-A-045", T, "Total walking distance with round trips serving two equally spaced points per trip", "Difficult",
  "Multi-step word problem",
  r"A gardener fills a bucket at a tap and waters $20$ plants standing in a straight line. The first plant is $10$ m from the tap, the plants are $5$ m apart, and the tap is on the same line, on the side of the first plant away from the others. One bucket holds exactly enough water for two plants. Starting at the tap with a full bucket, he waters the first and second plants, walks back to the tap, refills, waters the third and fourth plants, walks back, and so on. He stays at the last plant after watering it. What is the total distance he walks?",
  "MCQ",
  r"Plant $k$ is $5 + 5k$ m from the tap. Each trip goes out to the farther plant of a pair (plants $2, 4, \ldots, 20$) and back, so it covers twice the distance to that plant: $15, 25, \ldots, 105$, an AP of $10$ terms with sum $\frac{10}{2}(15 + 105) = 600$. All trips are round trips except the last, which is one way: total $= 2 \times 600 - 105 = 1095$ m.",
  "Treating each trip as serving one plant, or including the return trip from the last plant.",
  "C13A-round-trip-distance", "Two ideas: the pairing reduces the walk to an AP of alternate distances, and the final trip is one way; the alternate-term AP and the last-trip adjustment are both easy to get wrong.",
  correct=r"$1095$ m",
  distractors=[(r"$1200$ m", r"Includes a return to the tap after the last pair of plants: $2 \times 600$."),
               (r"$1000$ m", r"Doubles the distance to the nearer plant of each pair ($10, 20, \ldots, 100$, sum $550$), forgetting the $5$ m on to the second plant: $2 \times 550 - 100$."),
               (r"$2195$ m", r"Ignores that one bucket serves two plants and makes a trip for every plant: $2(10 + 15 + \cdots + 105) - 105$.")],
  check=_c045, values=[1095, 1200, 1000, 2195], cognitive="Analysis", exams=X2)
