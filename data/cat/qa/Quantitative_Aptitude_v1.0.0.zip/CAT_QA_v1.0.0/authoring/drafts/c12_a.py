import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
TOP = "Indices"
CX = ("CAT", "XAT")


def _lg(n, sub):
    """log of a positive integer n written through the logs of its prime factors (sub maps prime -> value)."""
    return sum(e * sub[p] for p, e in factorint(n).items())


def _pos_roots_t(expr, t):
    """Distinct positive real roots of a polynomial in t."""
    return sorted({r for r in solve(expr, t) if r.is_real and r > 0})


# ---------------------------------------------------------------- EASY (12)

def _e1():
    x = Symbol('x')
    # 2^(3x-1) * 4^(x+2) = 8^(x+3): compare exponents of 2 after expanding
    L = {2: 1}   # work with exponents of 2
    sol = solve(Eq((3*x - 1) * _lg(2, L) + (x + 2) * _lg(4, L), (x + 3) * _lg(8, L)), x)
    return sol[0]
q("C12-A-001", TOP, "Linear exponential equation after writing every base as a power of 2", "Easy",
  "Inverse/parameter",
  r"If $2^{3x-1} \cdot 4^{x+2} = 8^{x+3}$, then $x$ equals",
  "MCQ",
  r"Write everything as a power of $2$: $2^{3x-1} \cdot 2^{2x+4} = 2^{3x+9}$, so $5x + 3 = 3x + 9$, giving $2x = 6$ and $x = 3$.",
  "Converting only part of an exponent when changing base, for example writing $4^{x+2}$ as $2^{2x+2}$.",
  "C12A-same-base-linear", "Single conversion to base 2 and one linear equation; the trap is distributing the new exponent over the whole bracket.",
  correct=r"$3$",
  distractors=[(r"$4$", r"Writes $4^{x+2}$ as $2^{2x+2}$, so $5x + 1 = 3x + 9$ and $x = 4$."),
               (r"$0$", r"Writes $8^{x+3}$ as $2^{3x+3}$, so $5x + 3 = 3x + 3$ and $x = 0$."),
               (r"$6$", r"Reaches $5x + 3 = 3x + 9$ but moves the $3$ with the wrong sign, $2x = 12$, so $x = 6$.")],
  check=_e1, values=[3, 4, 0, 6], cognitive="Application")


def _e2():
    n = Symbol('n')
    return solve(Eq(5**(n + 1) + 5**n + 5**(n - 1), 775), n)[0]
q("C12-A-002", TOP, "Sum of three consecutive powers of 5 equal to a given number", "Easy",
  "Conceptual/application",
  r"If $5^{n+1} + 5^{n} + 5^{n-1} = 775$, what is the value of $n$?",
  "TITA",
  r"Take out the smallest power: $5^{n-1}(25 + 5 + 1) = 31 \cdot 5^{n-1} = 775$, so $5^{n-1} = 25 = 5^2$. Hence $n - 1 = 2$ and $n = 3$.",
  "Solving for the exponent of the factored power and reporting it as $n$.",
  "C12A-factor-common-power", "One factorisation step; the trap is reporting $n - 1$.",
  tita_answer=3, check=_e2, values=[3],
  tita_traps=[(2, r"Finds $5^{n-1} = 25$ and reports $n - 1 = 2$ as the answer."),
              (1, r"Factors out $5^{n+1}$ but keeps the bracket $25 + 5 + 1$, so $31 \cdot 5^{n+1} = 775$, $5^{n+1} = 25$ and $n = 1$.")],
  cognitive="Application")


def _e3():
    nums = {"2^60": 2**60, "3^40": 3**40, "5^30": 5**30, "7^20": 7**20}
    return max(nums.values())
q("C12-A-003", TOP, "Largest of four powers by reducing to a common exponent", "Easy",
  "Conceptual/application",
  r"Which of the following numbers is the largest?",
  "MCQ",
  r"All four exponents are multiples of $10$: $2^{60} = 64^{10}$, $3^{40} = 81^{10}$, $5^{30} = 125^{10}$ and $7^{20} = 49^{10}$. With a common exponent the largest base wins, so $5^{30}$ is the largest.",
  "Judging the size of a power by its exponent alone or by its base alone.",
  "C12A-compare-powers-common-exponent", "One idea (common exponent) applied to four numbers; traps are the largest base and the largest exponent.",
  correct=r"$5^{30}$",
  distractors=[(r"$2^{60}$", "Picks the number with the largest exponent."),
               (r"$7^{20}$", "Picks the number with the largest base."),
               (r"$3^{40}$", r"Divides the exponents by $20$ to compare $2^3 = 8$, $3^2 = 9$, $5^{1.5}$ and $7$, but estimates $5^{1.5}$ as $5 \times 1.5 = 7.5$ and so picks $3^{40}$.")],
  check=_e3, values=[5**30, 2**60, 7**20, 3**40], cognitive="Understanding")


def _e4():
    return F(6**8 * 10**3, 4**5 * 15**3 * 9**2)
q("C12-A-004", TOP, "Simplifying a quotient of powers by prime factorisation", "Easy",
  "Single-step computation",
  r"The value of $\dfrac{6^{8} \cdot 10^{3}}{4^{5} \cdot 15^{3} \cdot 9^{2}}$ is",
  "MCQ",
  r"In primes the numerator is $2^{8}3^{8} \cdot 2^{3}5^{3} = 2^{11}3^{8}5^{3}$ and the denominator is $2^{10} \cdot 3^{3}5^{3} \cdot 3^{4} = 2^{10}3^{7}5^{3}$. The quotient is $2^{1} \cdot 3^{1} = 6$.",
  "Converting a composite base to primes without raising the prime to the full power.",
  "C12A-prime-factor-simplify", "Routine prime factorisation of five bases; traps are mis-converted powers of 4 and 9.",
  correct=r"$6$",
  distractors=[(r"$192$", r"Writes $4^{5}$ as $2^{5}$, leaving $2^{6} \cdot 3 = 192$."),
               (r"$54$", r"Writes $9^{2}$ as $3^{2}$, leaving $2 \cdot 3^{3} = 54$."),
               (r"$48$", r"Writes $4^{5}$ as $2^{7}$ by adding $2 + 5$, leaving $2^{4} \cdot 3 = 48$.")],
  check=_e4, values=[6, 192, 54, 48], cognitive="Application")


def _e5():
    cells, t = 500, 0
    while cells < 64000:
        cells *= 2
        t += 20
    assert cells == 64000
    return t
q("C12-A-005", TOP, "Doubling growth: time to reach a given multiple", "Easy",
  "Multi-step word problem",
  r"A bacterial culture doubles in size every $20$ minutes. At $9{:}00$ am it contains $500$ cells, and it grows without any loss. How many minutes after $9{:}00$ am does it contain exactly $64{,}000$ cells?",
  "TITA",
  r"The culture must grow by a factor of $\frac{64000}{500} = 128 = 2^{7}$, which takes $7$ doublings. That is $7 \times 20 = 140$ minutes.",
  "Counting the starting size as one doubling, or treating doubling growth as linear growth.",
  "C12A-growth-word", "Recognise $128$ as $2^7$ and convert doublings to minutes; one trap.",
  tita_answer=140, check=_e5, values=[140],
  tita_traps=[(160, r"Counts $8$ doublings, taking the initial $500$ cells as the first doubling."),
              (2540, r"Treats the growth as linear, $500$ cells every $20$ minutes: $\frac{63500}{500} \times 20 = 2540$.")],
  cognitive="Application")


def _e6():
    t = Symbol('t', positive=True)
    r = [s for s in solve(Eq(t + 1/t, 4), t)][0]   # t = 3^x
    return nsimplify(simplify(r**2 + 1/r**2))
q("C12-A-006", TOP, "Power plus reciprocal power: squaring identity", "Easy",
  "Conceptual/application",
  r"If $3^{x} + 3^{-x} = 4$, then $9^{x} + 9^{-x}$ equals",
  "MCQ",
  r"Since $9^{x} = (3^{x})^{2}$, square the given relation: $(3^{x} + 3^{-x})^{2} = 9^{x} + 2 + 9^{-x} = 16$. Hence $9^{x} + 9^{-x} = 14$.",
  r"Forgetting the cross term $2 \cdot 3^{x} \cdot 3^{-x} = 2$ when squaring.",
  "C12A-power-plus-reciprocal", "One squaring step; the cross-term trap.",
  correct=r"$14$",
  distractors=[(r"$16$", "Squares the right side and ignores the cross term."),
               (r"$18$", r"Adds the cross term $2$ instead of subtracting it."),
               (r"$8$", r"Treats $9^{x} = 3^{2x}$ as $2 \cdot 3^{x}$ and simply doubles $4$.")],
  check=_e6, values=[14, 16, 18, 8], cognitive="Understanding")


def _e7():
    m = log(3) / log(2)
    return nsimplify(simplify(4**(m + 1) + 8**m))
q("C12-A-007", TOP, "Evaluating an expression in powers of 4 and 8 from a given power of 2", "Easy",
  "Single-step computation",
  r"If $2^{m} = 3$, what is the value of $4^{m+1} + 8^{m}$?",
  "MCQ",
  r"$4^{m+1} = 4 \cdot (2^{m})^{2} = 4 \cdot 9 = 36$ and $8^{m} = (2^{m})^{3} = 27$. The sum is $63$.",
  "Mishandling $4^{m}$ or $8^{m}$ when rewriting them through $2^{m}$.",
  "C12A-given-power-substitute", "Two direct substitutions using $(a^m)^n$.",
  correct=r"$63$",
  distractors=[(r"$40$", r"Reads $4^{m+1}$ as $4^{m} + 4 = 13$, giving $13 + 27 = 40$."),
               (r"$45$", r"Takes $8^{m} = 2^{3m}$ as $3 \cdot 2^{m} = 9$, giving $36 + 9 = 45$."),
               (r"$51$", r"Doubles instead of squaring, $4^{m} = 2 \cdot 3 = 6$, so $4^{m+1} = 24$ and the total is $51$.")],
  check=_e7, values=[63, 40, 45, 51], cognitive="Application")


def _e8():
    x = Symbol('x', real=True)
    sols = solve(Eq(4**x - 6 * 2**x + 8, 0), x)
    return sum(sols)
q("C12-A-008", TOP, "Quadratic in $2^x$: sum of the solutions", "Easy",
  "Single-step computation",
  r"What is the sum of all real values of $x$ that satisfy $4^{x} - 6 \cdot 2^{x} + 8 = 0$?",
  "MCQ",
  r"Put $t = 2^{x}$: $t^{2} - 6t + 8 = 0$, so $t = 2$ or $t = 4$, that is $x = 1$ or $x = 2$. The sum is $3$.",
  "Reporting a symmetric function of the roots in $t$ instead of in $x$.",
  "C12A-quadratic-in-power", "One substitution and a factorable quadratic.",
  correct=r"$3$",
  distractors=[(r"$6$", r"Reports the sum of the roots in $t = 2^{x}$, which is $2 + 4 = 6$."),
               (r"$2$", r"Multiplies the two values of $x$: $1 \times 2 = 2$."),
               (r"$8$", r"Reports the product of the roots in $t$, which is $2 \times 4 = 8$.")],
  check=_e8, values=[3, 6, 2, 8], cognitive="Application")


def _e9():
    x = Symbol('x')
    return solve(Eq((x - 2) * log(F(3, 5)), (x - 6) * log(F(125, 27))), x)[0]
q("C12-A-009", TOP, "Exponential equation with reciprocal fractional bases", "Easy",
  "Inverse/parameter",
  r"If $\left(\frac{3}{5}\right)^{x-2} = \left(\frac{125}{27}\right)^{x-6}$, then $x$ equals",
  "MCQ",
  r"Since $\frac{125}{27} = \left(\frac{5}{3}\right)^{3} = \left(\frac{3}{5}\right)^{-3}$, the equation becomes $x - 2 = -3(x - 6) = -3x + 18$. So $4x = 20$ and $x = 5$.",
  "Missing the reciprocal relation between the bases, which brings in a negative sign.",
  "C12A-same-base-linear", "One base conversion with a sign; traps are the missing minus sign and the missing cube.",
  correct=r"$5$",
  distractors=[(r"$8$", r"Takes $\frac{125}{27}$ as $\left(\frac{3}{5}\right)^{3}$, so $x - 2 = 3(x - 6)$ and $x = 8$."),
               (r"$4$", r"Takes $\frac{125}{27}$ as $\left(\frac{3}{5}\right)^{-1}$, so $x - 2 = -(x - 6)$ and $x = 4$."),
               (r"$-4$", r"Expands $-3(x - 6)$ as $-3x - 18$, so $4x = -16$ and $x = -4$.")],
  check=_e9, values=[5, 8, 4, -4], cognitive="Application")


def _e10():
    sols = [(a, b) for a in range(0, 20) for b in range(0, 20) if 2**a * 3**b == 648]
    assert len(sols) == 1
    return sum(sols[0])
q("C12-A-010", TOP, "Counting doubling and tripling steps from a final value", "Easy",
  "Multi-step word problem",
  r"A calculator display starts at $1$. Each press of a red key doubles the number on the display and each press of a blue key triples it; no other key is used. After Sneha presses these keys a number of times in some order, the display shows $648$. How many key presses did she make in all?",
  "TITA",
  r"Each press multiplies by $2$ or $3$, so $648 = 2^{a} \cdot 3^{b}$ where $a$ and $b$ are the numbers of red and blue presses. Since $648 = 8 \times 81 = 2^{3} \cdot 3^{4}$, and prime factorisation is unique, $a = 3$, $b = 4$ and the total is $7$ presses.",
  "Factorising carelessly or combining the two exponents in the wrong way.",
  "C12A-integer-exponent-system", "Prime factorisation of one number; the order of presses does not matter.",
  tita_answer=7, check=_e10, values=[7],
  tita_traps=[(12, r"Multiplies the exponents: $3 \times 4 = 12$."),
              (6, r"Takes $81$ as $3^{3}$, giving $3 + 3 = 6$.")],
  cognitive="Application")


def _e11():
    return sum(1 for x in range(-100, 101) if F(1, 8) < F(2)**(x - 3) <= 16)
q("C12-A-011", TOP, "Counting integers in a two-sided exponential inequality", "Easy",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $\frac{1}{8} < 2^{x-3} \le 16$?",
  "MCQ",
  r"Write both bounds as powers of $2$: $2^{-3} < 2^{x-3} \le 2^{4}$. Since the base exceeds $1$, $-3 < x - 3 \le 4$, that is $0 < x \le 7$. The integers are $1, 2, \ldots, 7$: there are $7$ of them.",
  "Mishandling the strict and non-strict ends of the range.",
  "C12A-exponential-inequality", "One conversion to a linear range; the trap is at the endpoints.",
  correct=r"$7$",
  distractors=[(r"$8$", r"Treats the left inequality as non-strict and includes $x = 0$."),
               (r"$6$", r"Treats the right inequality as strict and leaves out $x = 7$."),
               (r"$5$", r"Counts only the $x$ for which $2^{x-3}$ is a whole number, that is $x = 3, 4, 5, 6, 7$.")],
  check=_e11, values=[7, 8, 6, 5], cognitive="Application")


def _e12():
    return sum(1 for m in range(1, 50) for n in range(1, 50) if 2**m * 4**n == 1024)
q("C12-A-012", TOP, "Counting positive integer pairs with a fixed product of powers", "Easy",
  "Casework/optimisation",
  r"How many ordered pairs $(m, n)$ of positive integers satisfy $2^{m} \cdot 4^{n} = 1024$?",
  "TITA",
  r"$2^{m} \cdot 2^{2n} = 2^{10}$, so $m + 2n = 10$. With $m, n \ge 1$, $n$ can be $1, 2, 3, 4$ (giving $m = 8, 6, 4, 2$). There are $4$ pairs.",
  "Forgetting that $4^{n} = 2^{2n}$, or allowing zero values.",
  "C12A-count-exponent-solutions", "One linear Diophantine count after a base change.",
  tita_answer=4, check=_e12, values=[4],
  tita_traps=[(9, r"Uses $m + n = 10$, forgetting that $4^{n} = 2^{2n}$."),
              (6, r"Allows $m = 0$ or $n = 0$, counting $n = 0, 1, \ldots, 5$.")],
  cognitive="Application")


# ---------------------------------------------------------------- MEDIUM (18)

def _m1():
    for x in range(-20, 21):
        if F(27)**x * F(4)**(x + 2) / F(6)**(2 * x + 1) == 72:
            return x
q("C12-A-013", TOP, "Exponential equation in bases 27, 4 and 6 solved by prime exponents", "Medium",
  "Inverse/parameter",
  r"If $\dfrac{27^{x} \cdot 4^{x+2}}{6^{2x+1}} = 72$, what is the value of $x$?",
  "TITA",
  r"The left side is $\frac{3^{3x} \cdot 2^{2x+4}}{2^{2x+1} \cdot 3^{2x+1}} = 2^{3} \cdot 3^{x-1}$. Setting $8 \cdot 3^{x-1} = 72$ gives $3^{x-1} = 9$, so $x = 3$.",
  "Applying the exponent of $6^{2x+1}$ to only one of its prime factors.",
  "C12A-integer-exponent-system", "Two primes must be tracked separately and the powers of 2 cancel only partly.",
  tita_answer=3, check=_m1, values=[3],
  tita_traps=[(2, r"Writes $6^{2x+1}$ as $2^{2x+1} \cdot 3^{2x}$, so $8 \cdot 3^{x} = 72$ and $x = 2$.")],
  cognitive="Application")


def _m2():
    x = Symbol('x', real=True)
    sols = solve(Eq(3**(2*x + 2) - 82 * 3**x + 9, 0), x)
    return prod(sols)
q("C12-A-014", TOP, "Quadratic in $3^x$ with reciprocal roots: product of solutions", "Medium",
  "Inverse/parameter",
  r"What is the product of all real values of $x$ that satisfy $3^{2x+2} - 82 \cdot 3^{x} + 9 = 0$?",
  "MCQ",
  r"With $t = 3^{x}$ the equation is $9t^{2} - 82t + 9 = 0$, that is $(9t - 1)(t - 9) = 0$. So $t = 9$ or $t = \frac{1}{9}$, giving $x = 2$ or $x = -2$. The product is $-4$.",
  "Discarding a root less than $1$, or losing the sign of a negative exponent.",
  "C12A-quadratic-in-power", "Needs the substitution, a non-monic quadratic and care with a root below 1.",
  correct=r"$-4$",
  distractors=[(r"$1$", r"Reports the product of the roots in $t$, $9 \times \frac{1}{9} = 1$."),
               (r"$4$", r"Takes $3^{x} = \frac{1}{9}$ to mean $x = 2$ as well, losing the sign."),
               (r"$2$", r"Discards $t = \frac{1}{9}$ as impossible and keeps only $x = 2$.")],
  check=_m2, values=[-4, 1, 4, 2], cognitive="Application")


def _m3():
    x = Symbol('x', real=True)
    sols = solve(Eq(2**(x + 3) + 2**(-x), 9), x)
    return sum(s**2 for s in sols)
q("C12-A-015", TOP, "Power and reciprocal power giving a quadratic: sum of squares of solutions", "Medium",
  "Inverse/parameter",
  r"Find the sum of the squares of all real values of $x$ that satisfy $2^{x+3} + 2^{-x} = 9$.",
  "TITA",
  r"Let $t = 2^{x} > 0$: $8t + \frac{1}{t} = 9$, so $8t^{2} - 9t + 1 = 0 = (8t - 1)(t - 1)$. Then $t = 1$ or $t = \frac{1}{8}$, giving $x = 0$ or $x = -3$. The sum of squares is $0 + 9 = 9$.",
  "Spotting $x = 0$ by inspection and missing the second solution.",
  "C12A-quadratic-in-power", "Requires clearing the reciprocal to form a quadratic and finding a negative solution.",
  tita_answer=9, check=_m3, values=[9],
  tita_traps=[(0, r"Finds only $x = 0$ by trial and stops."),
              (3, r"Finds both solutions $x = 0$ and $x = -3$ but adds their absolute values, $0 + 3 = 3$, in place of their squares.")],
  cognitive="Application")


def _m4():
    nums = {6: 6**12, 2: 2**48, 5: 5**24, 3: 3**36}
    order = sorted(nums, key=lambda b: nums[b])
    return int("".join(str(b) for b in order))
q("C12-A-016", TOP, "Ordering four powers with different bases and exponents", "Medium",
  "Conceptual/application",
  r"Which of the following arranges $2^{48}$, $3^{36}$, $5^{24}$ and $6^{12}$ in increasing order?",
  "MCQ",
  r"All exponents are multiples of $12$: $2^{48} = 16^{12}$, $3^{36} = 27^{12}$, $5^{24} = 25^{12}$ and $6^{12}$. Comparing $6 < 16 < 25 < 27$ gives $6^{12} < 2^{48} < 5^{24} < 3^{36}$.",
  "Ordering by the base or by the exponent instead of by a common exponent.",
  "C12A-compare-powers-common-exponent", "Four numbers to reduce, and neither the bases nor the exponents give the order.",
  correct=r"$6^{12} < 2^{48} < 5^{24} < 3^{36}$",
  distractors=[(r"$2^{48} < 3^{36} < 5^{24} < 6^{12}$", "Orders the numbers by their bases."),
               (r"$6^{12} < 5^{24} < 3^{36} < 2^{48}$", "Orders the numbers by their exponents."),
               (r"$6^{12} < 3^{36} < 2^{48} < 5^{24}$", r"Uses exponent $12$ correctly but takes $3^{3}$ as $9$, comparing $6, 16, 25, 9$.")],
  check=_m4, values=[6253, 2356, 6532, 6325], cognitive="Analysis")


def _m5():
    best = None
    for n in range(1, 200):
        if n**200 < 5**300:
            best = n
    return best
q("C12-A-017", TOP, "Largest integer base below a given power, via a common exponent", "Medium",
  "Casework/optimisation",
  r"What is the largest positive integer $n$ for which $n^{200} < 5^{300}$?",
  "MCQ",
  r"Take the $100$th root of both sides: $n^{2} < 5^{3} = 125$. Since $11^{2} = 121 < 125 < 144 = 12^{2}$, the largest such $n$ is $11$.",
  "Mishandling the ratio of the exponents or the rounding of a square root.",
  "C12A-compare-powers-common-exponent", "Reduction by the common factor 100 then a bound on a square.",
  correct=r"$11$",
  distractors=[(r"$12$", r"Rounds $\sqrt{125} \approx 11.2$ up to $12$."),
               (r"$7$", r"Reduces to $n < 5^{1.5}$ and estimates $5^{1.5}$ as $5 \times 1.5 = 7.5$."),
               (r"$2$", r"Inverts the ratio of the exponents to get $n < 5^{2/3} \approx 2.9$.")],
  check=_m5, values=[11, 12, 7, 2], cognitive="Application")


def _m6():
    a = Rational(4, 100)**Rational(-3, 2)
    b = Rational(125, 1000)**Rational(2, 3)
    c = Rational(16, 100)**Rational(-1, 2)
    return nsimplify(a * b / c)
q("C12-A-018", TOP, "Decimal bases with negative and fractional exponents", "Medium",
  "Single-step computation",
  r"The value of $\dfrac{(0.04)^{-3/2} \cdot (0.125)^{2/3}}{(0.16)^{-1/2}}$ is",
  "MCQ",
  r"$(0.04)^{-3/2} = 25^{3/2} = 125$, $(0.125)^{2/3} = \left(\frac{1}{8}\right)^{2/3} = \frac{1}{4}$ and $(0.16)^{-1/2} = \left(\frac{25}{4}\right)^{1/2} = \frac{5}{2}$. The value is $\frac{125}{4} \div \frac{5}{2} = \frac{25}{2}$.",
  "Mishandling a negative exponent on a decimal, or the root of a decimal.",
  "C12A-prime-factor-simplify", "Three separate conversions of decimals with negative and fractional exponents.",
  correct=r"$\frac{25}{2}$",
  distractors=[(r"$\frac{625}{8}$", r"Takes $(0.16)^{-1/2}$ as $\frac{2}{5}$, so $\frac{125}{4} \div \frac{2}{5} = \frac{625}{8}$."),
               (r"$\frac{5}{4}$", r"Takes $\sqrt{0.16}$ as $0.04$, so $(0.16)^{-1/2} = 25$ and $\frac{125}{4} \div 25 = \frac{5}{4}$."),
               (r"$\frac{1}{2}$", r"Takes $(0.04)^{-3/2}$ as $25^{1/2} = 5$, dropping the cube, so $\frac{5}{4} \div \frac{5}{2} = \frac{1}{2}$.")],
  check=_m6, values=[F(25, 2), F(625, 8), F(5, 4), F(1, 2)], cognitive="Application")


def _m7():
    return F(3**2025 + 3**2023, 3**2024 - 3**2022)
q("C12-A-019", TOP, "Ratio of sums of huge powers by factoring the smallest power", "Medium",
  "Conceptual/application",
  r"The value of $\dfrac{3^{2025} + 3^{2023}}{3^{2024} - 3^{2022}}$ is",
  "MCQ",
  r"Take $3^{2022}$ out of both: the numerator is $3^{2022}(27 + 3) = 30 \cdot 3^{2022}$ and the denominator is $3^{2022}(9 - 1) = 8 \cdot 3^{2022}$. The value is $\frac{30}{8} = \frac{15}{4}$.",
  "Factoring different powers out of the numerator and the denominator and then cancelling them as if equal.",
  "C12A-factor-common-power", "Factor a common power from both parts; several slip points.",
  correct=r"$\frac{15}{4}$",
  distractors=[(r"$\frac{5}{4}$", r"Writes the numerator as $10 \cdot 3^{2023}$ and the denominator as $8 \cdot 3^{2022}$, then cancels $3^{2023}$ against $3^{2022}$."),
               (r"$\frac{3}{2}$", r"Writes $3^{2025}$ as $3^{2022} \cdot 3^{2}$, so the numerator becomes $12 \cdot 3^{2022}$ and the value $\frac{12}{8}$."),
               (r"$\frac{10}{3}$", r"Takes the denominator as $3^{2022} \cdot 9$, ignoring the subtracted term, so the value is $\frac{30}{9}$.")],
  check=_m7, values=[F(15, 4), F(5, 4), F(3, 2), F(10, 3)], cognitive="Understanding")


def _m8():
    nums = {"2^(2^5)": 2**(2**5), "3^(3^3)": 3**(3**3), "5^(2^4)": 5**(2**4), "7^(2^3)": 7**(2**3)}
    return max(nums.values())
q("C12-A-020", TOP, "Comparing stacked powers (towers read from the top)", "Medium",
  "Conceptual/application",
  r"A stacked power such as $a^{b^{c}}$ means $a^{(b^{c})}$. Which of the following numbers is the largest?",
  "MCQ",
  r"Evaluate the top first: $2^{2^{5}} = 2^{32}$, $3^{3^{3}} = 3^{27}$, $5^{2^{4}} = 5^{16}$ and $7^{2^{3}} = 7^{8}$. Now $7^{8} = 49^{4} < 5^{16} = 625^{4}$; $5^{16} = 25^{8} < 27^{9} = 3^{27}$; and $2^{32} = 16^{8} < 27^{9}$. So $3^{3^{3}}$ is the largest.",
  "Reading a stacked power from the bottom, as $(a^{b})^{c}$, or judging by the base or the top exponent.",
  "C12A-power-towers", "Requires correct reading of stacked exponents and then two common-exponent comparisons.",
  correct=r"$3^{3^{3}}$",
  distractors=[(r"$2^{2^{5}}$", r"Picks the number whose exponent $2^{5} = 32$ is the largest."),
               (r"$5^{2^{4}}$", r"Reads each stack from the bottom: $(2^{2})^{5} = 2^{10}$, $(3^{3})^{3} = 3^{9}$, $(5^{2})^{4} = 5^{8}$, $(7^{2})^{3} = 7^{6}$, and $5^{8}$ is the largest of these."),
               (r"$7^{2^{3}}$", "Picks the number with the largest base.")],
  check=_m8, values=[3**27, 2**32, 5**16, 7**8], cognitive="Analysis")


def _m9():
    a, b, lam = symbols('a b lam', positive=True)
    # 2^a = 3^b = 12^c = k with log k = lam: log 2 = lam/a, log 3 = lam/b
    log12 = _lg(12, {2: lam / a, 3: lam / b})
    return simplify(lam / log12)
q("C12-A-021", TOP, "Equal powers of 2, 3 and 12: expressing one exponent through the others", "Medium",
  "Conceptual/application",
  r"If $2^{a} = 3^{b} = 12^{c}$, where $a$, $b$ and $c$ are non-zero real numbers, then $c$ equals",
  "MCQ",
  r"Let the common value be $k$. Then $2 = k^{1/a}$, $3 = k^{1/b}$ and $12 = k^{1/c}$. Since $12 = 2^{2} \cdot 3$, $k^{1/c} = k^{2/a + 1/b}$, so $\frac{1}{c} = \frac{2}{a} + \frac{1}{b} = \frac{a + 2b}{ab}$ and $c = \frac{ab}{a + 2b}$.",
  "Factorising 12 carelessly, or stopping at the reciprocal.",
  "C12A-equal-powers-chain", "Introduce a common value, take roots, and match prime factors.",
  correct=r"$\frac{ab}{a + 2b}$",
  distractors=[(r"$\frac{ab}{2a + b}$", r"Puts the square on $3$, using $12 = 2 \cdot 3^{2}$."),
               (r"$\frac{ab}{a + b}$", r"Ignores the square in $12 = 2^{2} \cdot 3$ and uses $\frac{1}{c} = \frac{1}{a} + \frac{1}{b}$."),
               (r"$\frac{a + 2b}{ab}$", r"Finds $\frac{1}{c}$ correctly but reports it as $c$.")],
  check=_m9, values=[Symbol('a', positive=True) * Symbol('b', positive=True) / (Symbol('a', positive=True) + 2 * Symbol('b', positive=True)),
                     Symbol('a', positive=True) * Symbol('b', positive=True) / (2 * Symbol('a', positive=True) + Symbol('b', positive=True)),
                     Symbol('a', positive=True) * Symbol('b', positive=True) / (Symbol('a', positive=True) + Symbol('b', positive=True)),
                     (Symbol('a', positive=True) + 2 * Symbol('b', positive=True)) / (Symbol('a', positive=True) * Symbol('b', positive=True))],
  cognitive="Understanding")


def _m10():
    x, y = symbols('x y', real=True)
    sol = solve([Eq(2**x + 3**y, 17), Eq(2**(x + 2) - 3**(y + 1), 5)], [x, y], dict=True)
    s = sol[0]
    return simplify(s[x]**s[y])
q("C12-A-022", TOP, "Linear system in $2^x$ and $3^y$", "Medium",
  "Inverse/parameter",
  r"Real numbers $x$ and $y$ satisfy $2^{x} + 3^{y} = 17$ and $2^{x+2} - 3^{y+1} = 5$. What is the value of $x^{y}$?",
  "MCQ",
  r"Let $u = 2^{x}$ and $v = 3^{y}$. Then $u + v = 17$ and $4u - 3v = 5$. Adding $3$ times the first equation to the second gives $7u = 56$, so $u = 8$ and $v = 9$. Hence $x = 3$, $y = 2$ and $x^{y} = 9$.",
  "Answering a different combination of $x$ and $y$ than the one asked.",
  "C12A-substitution-linear-system", "Substitution turns it into a linear system, then a back-conversion to exponents.",
  correct=r"$9$",
  distractors=[(r"$8$", r"Computes $y^{x} = 2^{3}$ in place of $x^{y}$."),
               (r"$5$", r"Reports $x + y$."),
               (r"$6$", r"Reports $xy$.")],
  check=_m10, values=[9, 8, 5, 6], cognitive="Application")


def _m11():
    sols = [(a, b, c) for a in range(-12, 13) for b in range(-12, 13) for c in range(-12, 13)
            if F(18)**a * F(20)**b / F(15)**c == 576]
    assert len(sols) == 1
    return sum(sols[0])
q("C12-A-023", TOP, "Matching prime exponents to find three unknown integer exponents", "Medium",
  "Inverse/parameter",
  r"Integers $a$, $b$ and $c$ satisfy $\dfrac{18^{a} \cdot 20^{b}}{15^{c}} = 576$. What is the value of $a + b + c$?",
  "TITA",
  r"In primes the left side is $2^{a + 2b} \cdot 3^{2a - c} \cdot 5^{b - c}$, and $576 = 2^{6} \cdot 3^{2}$. So $a + 2b = 6$, $2a - c = 2$ and $b = c$. Then $a = 6 - 2b$ and $2(6 - 2b) - b = 2$, giving $b = 2$, $c = 2$, $a = 2$. Hence $a + b + c = 6$.",
  "Mishandling the denominator $15^{c}$: adding its exponents instead of subtracting them, or overlooking that the prime 5 must end with exponent zero.",
  "C12A-integer-exponent-system", "Three linear equations from three primes, including the hidden condition on the prime 5.",
  tita_answer=6, check=_m11, values=[6],
  tita_traps=[(2, r"Adds the exponents of $15^{c}$ instead of subtracting them: $a + 2b = 6$, $2a + c = 2$, $b + c = 0$, giving $a = 2$, $b = 2$, $c = -2$ and a sum of $2$."),
              (8, r"Solves correctly but reports the product $abc = 8$.")],
  cognitive="Analysis")


def _m12():
    return sum(F(2, 1 + F(3)**k) for k in range(-10, 11))
q("C12-A-024", TOP, "Pairing terms $k$ and $-k$ in a sum of reciprocal power expressions", "Medium",
  "Conceptual/application",
  r"Find the value of $\dfrac{2}{1 + 3^{-10}} + \dfrac{2}{1 + 3^{-9}} + \cdots + \dfrac{2}{1 + 3^{9}} + \dfrac{2}{1 + 3^{10}}$, where the exponent runs through every integer from $-10$ to $10$.",
  "TITA",
  r"For any $k$, $\frac{2}{1 + 3^{-k}} = \frac{2 \cdot 3^{k}}{3^{k} + 1}$, so $\frac{2}{1 + 3^{k}} + \frac{2}{1 + 3^{-k}} = \frac{2 + 2 \cdot 3^{k}}{1 + 3^{k}} = 2$. The $10$ pairs $k = \pm 1, \ldots, \pm 10$ give $20$, and the middle term $k = 0$ is $\frac{2}{2} = 1$. The total is $21$.",
  "Leaving out or mis-valuing the unpaired middle term.",
  "C12A-reciprocal-pairing-sum", "Needs the pairing insight and care with the unpaired term.",
  tita_answer=21, check=_m12, values=[21],
  tita_traps=[(20, r"Pairs the terms correctly but leaves out the middle term $k = 0$."),
              (22, r"Takes the middle term $\frac{2}{1 + 3^{0}}$ as $2$.")],
  cognitive="Analysis")


def _m13():
    # discrete simulation in 15-minute steps; growth events at the ends of periods
    p, qq, t = F(81), F(256), 0
    while True:
        t += 15
        p *= 2
        if t % 30 == 0:
            qq *= 3
        if p == qq:
            return t
q("C12-A-025", TOP, "Two cultures with different growth factors: when are they equal?", "Medium",
  "Multi-step word problem",
  r"Culture P starts with $81$ cells and doubles every $15$ minutes. Culture Q starts at the same moment with $256$ cells and triples every $30$ minutes. Both grow without loss. After how many minutes do the two cultures first contain the same number of cells?",
  "TITA",
  r"Per $30$ minutes P grows by $2^{2} = 4$ and Q by $3$. After $k$ such half-hours, $81 \cdot 4^{k} = 256 \cdot 3^{k}$, so $\left(\frac{4}{3}\right)^{k} = \frac{256}{81} = \left(\frac{4}{3}\right)^{4}$ and $k = 4$. The time is $4 \times 30 = 120$ minutes.",
  "Mixing the 15-minute and 30-minute periods.",
  "C12A-growth-word", "Requires a common time unit and recognising $256/81$ as a power of $4/3$.",
  tita_answer=120, check=_m13, values=[120],
  tita_traps=[(60, r"Finds $k = 4$ but multiplies by P's $15$-minute period.")],
  cognitive="Application")


def _m14():
    vals = {F(12**n * 9**(n + 1) * 8, 6**(n + 1) * 18**n) for n in range(1, 8)}
    assert len(vals) == 1
    return vals.pop()
q("C12-A-026", TOP, "Expression with a variable exponent that simplifies to a constant", "Medium",
  "Single-step computation",
  r"For every positive integer $n$, the expression $\dfrac{12^{n} \cdot 9^{n+1} \cdot 8}{6^{n+1} \cdot 18^{n}}$ has the same value. That value is",
  "MCQ",
  r"Numerator: $2^{2n}3^{n} \cdot 3^{2n+2} \cdot 2^{3} = 2^{2n+3}3^{3n+2}$. Denominator: $2^{n+1}3^{n+1} \cdot 2^{n}3^{2n} = 2^{2n+1}3^{3n+1}$. The quotient is $2^{2} \cdot 3 = 12$.",
  "Converting a composite base with a variable exponent and losing a constant term in the exponent.",
  "C12A-prime-factor-simplify", "Tracking linear exponents in $n$ for two primes across five factors.",
  correct=r"$12$",
  distractors=[(r"$4$", r"Writes $9^{n+1}$ as $3^{2n+1}$, so the powers of $3$ cancel completely."),
               (r"$36$", r"Writes $6^{n+1}$ as $2^{n+1} \cdot 3^{n}$, leaving $2^{2} \cdot 3^{2}$."),
               (r"$6$", r"Writes $8$ as $2^{2}$, leaving $2 \cdot 3$.")],
  check=_m14, values=[12, 4, 36, 6], cognitive="Application")


def _m15():
    return sum(1 for x in range(-100, 101) if F(1, 4)**(x * x - 3 * x) > F(8)**(2 * x - 10))
q("C12-A-027", TOP, "Exponential inequality with base below 1 reducing to a quadratic", "Medium",
  "Casework/optimisation",
  r"How many integers $x$ satisfy $\left(\frac{1}{4}\right)^{x^{2} - 3x} > 8^{2x - 10}$?",
  "MCQ",
  r"In base $2$: $2^{-2x^{2} + 6x} > 2^{6x - 30}$. As the base exceeds $1$, $-2x^{2} + 6x > 6x - 30$, that is $x^{2} < 15$. The integers are $-3, -2, \ldots, 3$: there are $7$.",
  r"Converting $\frac{1}{4}$ or $8$ to base 2 without multiplying the whole exponent.",
  "C12A-exponential-inequality", "Base conversion on both sides with a negative power, then a quadratic inequality.",
  correct=r"$7$",
  distractors=[(r"$12$", r"Writes $\left(\frac{1}{4}\right)^{x^{2} - 3x}$ as $2^{-(x^{2} - 3x)}$, giving $x^{2} + 3x - 30 < 0$, which holds for $x = -7, \ldots, 4$."),
               (r"$5$", r"Writes $8^{2x - 10}$ as $2^{6x - 10}$, giving $x^{2} < 5$, which holds for $x = -2, \ldots, 2$."),
               (r"$3$", r"Solves $x^{2} < 15$ correctly but counts only the positive integers $1, 2, 3$.")],
  check=_m15, values=[7, 12, 5, 3], cognitive="Application")


def _m16():
    t = Symbol('t', positive=True)
    r = solve(Eq(t - 1/t, 4), t)[0]          # t = 5^x
    return nsimplify(simplify(r**3 - 1/r**3))
q("C12-A-028", TOP, "Power minus reciprocal power: cubing identity", "Medium",
  "Conceptual/application",
  r"If $5^{x} - 5^{-x} = 4$, then $125^{x} - 125^{-x}$ equals",
  "MCQ",
  r"Let $p = 5^{x}$. Then $125^{x} - 125^{-x} = p^{3} - p^{-3} = (p - p^{-1})^{3} + 3(p - p^{-1}) = 64 + 12 = 76$.",
  "Cubing without the correction term, or using it with the wrong sign.",
  "C12A-power-plus-reciprocal", "Needs the cube identity for a difference, a step beyond squaring.",
  correct=r"$76$",
  distractors=[(r"$64$", r"Cubes $4$ and ignores the correction term $3(p - p^{-1})$."),
               (r"$52$", r"Uses $p^{3} - p^{-3} = (p - p^{-1})^{3} - 3(p - p^{-1})$, the identity for a sum."),
               (r"$12$", r"Since $125 = 5^{3}$, multiplies the given value $4$ by $3$.")],
  check=_m16, values=[76, 64, 52, 12], cognitive="Application")


def _m17():
    a = log(4) / log(3)
    b = log(5) / log(4)
    c = log(9) / log(5)
    return nsimplify(simplify(expand_log(a * b * c, force=True)))
q("C12-A-029", TOP, "Chained powers: product of exponents", "Medium",
  "Conceptual/application",
  r"Real numbers $a$, $b$ and $c$ satisfy $3^{a} = 4$, $4^{b} = 5$ and $5^{c} = 9$. What is the value of $abc$?",
  "TITA",
  r"Substitute along the chain: $9 = 5^{c} = (4^{b})^{c} = ((3^{a})^{b})^{c} = 3^{abc}$. Since $9 = 3^{2}$, $abc = 2$.",
  "Stopping at the final value instead of reading off the exponent.",
  "C12A-given-power-substitute", "Requires chaining three substitutions with the power-of-a-power law.",
  tita_answer=2, check=_m17, values=[2],
  tita_traps=[(9, r"Reaches $3^{abc} = 9$ and reports $9$."),
              (3, r"Reaches $3^{abc} = 9$ and divides $9$ by $3$.")],
  cognitive="Understanding")


def _m18():
    x = Symbol('x', positive=True)
    sols = solve(Eq(sqrt(x) * log(x), x / 2 * log(x)), x)
    return sum(sols)
q("C12-A-030", TOP, "Equation with the variable in both base and exponent", "Medium",
  "Casework/optimisation",
  r"What is the sum of all positive real numbers $x$ that satisfy $x^{\sqrt{x}} = \left(\sqrt{x}\right)^{x}$?",
  "MCQ",
  r"The right side is $x^{x/2}$. If $x = 1$ both sides equal $1$, so $x = 1$ works. Otherwise the exponents must match: $\sqrt{x} = \frac{x}{2}$, so $x = \frac{x^{2}}{4}$ and $x = 4$. The sum is $1 + 4 = 5$.",
  "Equating exponents without first considering the base $1$.",
  "C12A-variable-base-and-exponent", "Two cases: base 1 and equal exponents; the base-1 case is easily missed.",
  correct=r"$5$",
  distractors=[(r"$4$", r"Equates the exponents only and misses $x = 1$."),
               (r"$1$", r"Finds $x = 1$ by inspection and does not equate the exponents."),
               (r"$3$", r"Solves $\sqrt{x} = \frac{x}{2}$ as $x = 2$ and adds $1$.")],
  check=_m18, values=[5, 4, 1, 3], cognitive="Analysis")


# ---------------------------------------------------------------- DIFFICULT (10)

def _ok_one(base, ex):
    """True if base**ex is a defined real number equal to 1."""
    base, ex = nsimplify(base), nsimplify(ex)
    if base == 0:
        return False
    if base < 0 and not ex.is_integer:
        return False
    return simplify(base**ex - 1) == 0


def _d1():
    x = Symbol('x', real=True)
    B = x**2 - 9*x + 19
    E = x**2 - 10*x + 21
    cand = set(solve(B - 1, x)) | set(solve(E, x)) | set(solve(B + 1, x))
    good = {c for c in cand if _ok_one(B.subs(x, c), E.subs(x, c))}
    # no other real x can work: if |base| != 1 the exponent must be 0
    return len(good)
q("C12-A-031", TOP, "Variable base and variable exponent equal to 1: three cases with overlap and parity", "Difficult",
  "Casework/optimisation",
  r"Consider $\left(x^{2} - 9x + 19\right)^{x^{2} - 10x + 21} = 1$, where the left side is read as a real number: a negative base is allowed only with an integer exponent, and $0^{0}$ is not defined. How many real numbers $x$ satisfy the equation?",
  "TITA",
  r"Three cases. Base $1$: $x^{2} - 9x + 18 = 0$, so $x = 3$ or $6$. Exponent $0$ with non-zero base: $x = 3$ or $7$ (the base is $1$ and $5$). Base $-1$ with even exponent: $x^{2} - 9x + 20 = 0$ gives $x = 4$ (exponent $-3$, odd, rejected) and $x = 5$ (exponent $-4$, even, accepted). If the base is neither $1$ nor $-1$, the exponent must be $0$, so there are no others. The solutions are $3, 5, 6, 7$: four values.",
  "Counting $x = 3$ twice, or accepting base $-1$ without checking that the exponent is even.",
  "C12A-variable-base-cases", "Three cases, an overlap between two of them and a parity check on the third.",
  tita_answer=4, check=_d1, values=[4],
  tita_traps=[(6, r"Takes two roots from each of the three cases with no checks: $2 + 2 + 2$."),
              (5, r"Accepts $x = 4$ without checking that the exponent $-3$ is odd."),
              (3, r"Ignores the base $-1$ case, leaving $3, 6, 7$.")],
  exams=CX, cognitive="Analysis")


def _d2():
    cnt = 0
    for x in range(-60, 61):
        if x == 0:
            continue                       # 0^(-4) is undefined
        if F(x)**(x + 2) == F(x)**(3 * x - 4):
            cnt += 1
    return cnt
q("C12-A-032", TOP, "Integer solutions of equal powers of the same variable base", "Difficult",
  "Casework/optimisation",
  r"For how many integers $x$ is $x^{x+2} = x^{3x-4}$, with both sides defined?",
  "MCQ",
  r"If $|x| \ne 1$ and $x \ne 0$, equal powers of the same base need equal exponents: $x + 2 = 3x - 4$, so $x = 3$. Check the special bases: $x = 1$ gives $1 = 1$; $x = -1$ gives $(-1)^{1} = -1$ and $(-1)^{-7} = -1$, so it works; $x = 0$ gives $0^{-4}$, which is undefined. So $x = -1, 1, 3$: three integers.",
  "Equating exponents without checking the special bases $1$, $-1$ and $0$.",
  "C12A-variable-base-cases", "Casework on special bases, including a negative base with odd exponents on both sides.",
  correct=r"$3$",
  distractors=[(r"$1$", r"Only equates the exponents and finds $x = 3$."),
               (r"$2$", r"Adds the base $x = 1$ but does not test $x = -1$."),
               (r"$4$", r"Also accepts $x = 0$, treating $0^{-4}$ as $0$.")],
  check=_d2, values=[3, 1, 2, 4], exams=CX, cognitive="Analysis")


def _d3():
    N = 18**12 * 16**6
    pairs = set()
    for n in range(1, 200):
        r, exact = integer_nthroot(N, n)
        if exact:
            for m in (r, -r):
                if m**n == N:
                    pairs.add((m, n))
    return len(pairs)
q("C12-A-033", TOP, "Counting integer pairs $(m, n)$ with $m^n$ equal to a product of powers, signs included", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs $(m, n)$ of integers, with $n$ positive, satisfy $m^{n} = 18^{12} \cdot 16^{6}$?",
  "MCQ",
  r"In primes, $18^{12} \cdot 16^{6} = 2^{12} \cdot 3^{24} \cdot 2^{24} = 2^{36} \cdot 3^{24}$. By unique factorisation $|m| = 2^{i}3^{j}$ with $in = 36$ and $jn = 24$, so $n$ divides $\gcd(36, 24) = 12$: $n \in \{1, 2, 3, 4, 6, 12\}$, each giving one positive $m$. For the even values $n = 2, 4, 6, 12$ the negative $m$ also works, while for $n = 1, 3$ it does not. The total is $6 + 4 = 10$.",
  "Forgetting that a negative base works for an even exponent, or treating the prime exponents separately instead of requiring one common $n$.",
  "C12A-count-exponent-solutions", "Needs prime factorisation of a disguised product, the insight that $n$ divides the gcd of the prime exponents, and sign casework on the parity of $n$.",
  correct=r"$10$",
  distractors=[(r"$6$", r"Finds the six divisors of $12$ but counts only positive $m$."),
               (r"$12$", r"Allows both signs of $m$ for every divisor $n$, including the odd values $1$ and $3$."),
               (r"$9$", r"Handles the signs correctly but leaves out the trivial pair with $n = 1$.")],
  check=_d3, values=[10, 6, 12, 9], exams=CX, cognitive="Analysis")


def _d4():
    return sum(1 for n in range(1, 500) if 2**n < n**4)
q("C12-A-034", TOP, "Counting where an exponential is below a fourth power", "Difficult",
  "Casework/optimisation",
  r"For how many positive integers $n$ is $2^{n} < n^{4}$?",
  "TITA",
  r"At $n = 1$, $2 > 1$, so it fails. For $n = 2$ to $15$ it holds (for example $2^{15} = 32768 < 50625 = 15^{4}$). At $n = 16$ the two sides are equal, since $2^{16} = (2^{4})^{4} = 16^{4}$, and beyond that $2^{n}$ doubles while $n^{4}$ grows by the factor $\left(\frac{n+1}{n}\right)^{4} < 2$, so it never holds again. The count is $15 - 2 + 1 = 14$.",
  "Not checking the small end, or treating the equality at $n = 16$ as satisfying a strict inequality.",
  "C12A-exponential-vs-polynomial", "Two crossover points to locate, one of them an exact equality, plus a growth argument.",
  tita_answer=14, check=_d4, values=[14],
  tita_traps=[(15, r"Counts $n = 1$ to $15$ without testing $n = 1$."),
              (16, r"Counts $n = 1$ to $16$, also accepting the equality at $n = 16$.")],
  exams=CX, cognitive="Analysis")


def _d5():
    w = Symbol('w', positive=True)
    # w = 16^x with x > 0, so w > 1
    root = [z for z in solve(Eq(w + 1/w, 322), w) if N(z) > 1][0]
    val = N(root**Rational(3, 4) - root**Rational(-3, 4), 60)   # 8^x - 8^(-x)
    k = int(round(val))
    assert abs(val - k) < 1e-40
    return k
q("C12-A-035", TOP, "From $16^x + 16^{-x}$ to $8^x - 8^{-x}$ through $4^x + 4^{-x}$ and $2^x - 2^{-x}$", "Difficult",
  "Conceptual/application",
  r"A positive real number $x$ satisfies $16^{x} + 16^{-x} = 322$. What is the value of $8^{x} - 8^{-x}$?",
  "TITA",
  r"Let $u = 4^{x} + 4^{-x}$. Then $u^{2} = 16^{x} + 2 + 16^{-x} = 324$, so $u = 18$. Next let $d = 2^{x} - 2^{-x}$, which is positive because $x > 0$: $d^{2} = 4^{x} - 2 + 4^{-x} = 16$, so $d = 4$. Finally $8^{x} - 8^{-x} = d^{3} + 3d = 64 + 12 = 76$.",
  "Using the sum identity $s^{3} - 3s$ for a difference, or stopping at an intermediate stage.",
  "C12A-power-plus-reciprocal", "Three stages: a square root to step down from base 16 to base 4, a switch to the difference $2^{x} - 2^{-x}$ with its sign fixed by $x > 0$, then the cube identity for a difference.",
  tita_answer=76, check=_d5, values=[76],
  tita_traps=[(52, r"Finds $d = 4$ but uses the sum identity $d^{3} - 3d = 64 - 12 = 52$."),
              (64, r"Finds $d = 4$ and cubes it with no correction term."),
              (4, r"Stops at $2^{x} - 2^{-x} = 4$.")],
  exams=CX, cognitive="Analysis")


def _d6():
    p, q_, r, lam = symbols('p q r lam', positive=True)
    # 8^p = 27^q = 36^r = k, log k = lam
    log2 = lam / (3 * p)          # from 8^p = k
    log3 = lam / (3 * q_)         # from 27^q = k
    l36 = _lg(36, {2: log2, 3: log3})
    rr = lam / l36
    return simplify(rr / p + rr / q_)
q("C12-A-036", TOP, "Equal powers of 8, 27 and 36: a symmetric expression in the exponents", "Difficult",
  "Conceptual/application",
  r"Non-zero real numbers $p$, $q$ and $r$ satisfy $8^{p} = 27^{q} = 36^{r}$. What is the value of $\dfrac{r}{p} + \dfrac{r}{q}$?",
  "MCQ",
  r"Let the common value be $k$ (so $k \ne 1$). Then $2 = k^{1/(3p)}$ and $3 = k^{1/(3q)}$, so $36 = 2^{2} \cdot 3^{2} = k^{2/(3p) + 2/(3q)}$. Also $36 = k^{1/r}$, so $\frac{1}{r} = \frac{2}{3}\left(\frac{1}{p} + \frac{1}{q}\right)$. Multiplying by $r$: $\frac{r}{p} + \frac{r}{q} = \frac{3}{2}$.",
  "Losing either the cubes in $8$ and $27$ or the squares in $36$.",
  "C12A-equal-powers-chain", "Two layers of powers (cubes on one side, squares on the other) must both be tracked.",
  correct=r"$\frac{3}{2}$",
  distractors=[(r"$\frac{1}{2}$", r"Treats $8$ and $27$ as $2$ and $3$, so $\frac{1}{r} = \frac{2}{p} + \frac{2}{q}$."),
               (r"$3$", r"Treats $36$ as $6 = 2 \cdot 3$, so $\frac{1}{r} = \frac{1}{3p} + \frac{1}{3q}$."),
               (r"$1$", r"Ignores every power and writes $\frac{1}{r} = \frac{1}{p} + \frac{1}{q}$.")],
  check=_d6, values=[F(3, 2), F(1, 2), 3, 1], exams=CX, cognitive="Analysis")


def _d7():
    x = Symbol('x', positive=True)
    sols = solve(Eq(3 * x * log(x), x * log(3 * x)), x)
    sols = [s for s in sols if s > 0]
    assert len(sols) == 1
    s = sols[0]
    return simplify(s * 3 * s)
q("C12-A-037", TOP, "Solving $x^y = y^x$ when $y$ is a fixed multiple of $x$", "Difficult",
  "Inverse/parameter",
  r"Positive real numbers $x$ and $y$ satisfy $y = 3x$ and $x^{y} = y^{x}$. What is the value of $xy$?",
  "TITA",
  r"Substitute: $x^{3x} = (3x)^{x}$. Taking the positive $x$-th root of both sides, $x^{3} = 3x$, so $x^{2} = 3$ and $x = \sqrt{3}$, $y = 3\sqrt{3}$. Then $xy = 3x^{2} = 9$.",
  "Stopping at $x^{2} = 3$, or trying to guess integer solutions.",
  "C12A-variable-base-and-exponent", "Requires taking an $x$-th root to strip the variable exponent; the solution is irrational though $xy$ is an integer.",
  tita_answer=9, check=_d7, values=[9],
  tita_traps=[(3, r"Reaches $x^{2} = 3$ and reports it as the answer.")],
  exams=CX, cognitive="Analysis")


def _d8():
    x, y = symbols('x y', real=True)
    u, v = symbols('u v', positive=True)
    s = solve([Eq(u**2 - v**2, 544), Eq(u - v, 16)], [u, v], dict=True)[0]
    xs = solve(Eq(5**(x / 2), s[u]), x)[0]
    ys = solve(Eq(3**(y / 2), s[v]), y)[0]
    return simplify(xs + ys)
q("C12-A-038", TOP, "Difference of squares in exponential form", "Difficult",
  "Conceptual/application",
  r"Real numbers $x$ and $y$ satisfy $5^{x} - 3^{y} = 544$ and $5^{x/2} - 3^{y/2} = 16$. What is the value of $x + y$?",
  "MCQ",
  r"Let $u = 5^{x/2}$ and $v = 3^{y/2}$, both positive. Then $u^{2} - v^{2} = 544$ and $u - v = 16$, so $u + v = \frac{544}{16} = 34$. Hence $u = 25$, $v = 9$, so $\frac{x}{2} = 2$ and $\frac{y}{2} = 2$, giving $x = y = 4$ and $x + y = 8$.",
  r"Not seeing the difference of squares, or losing the factor $\frac{1}{2}$ in the exponents.",
  "C12A-difference-of-squares-exponents", "The key step is recognising $5^{x} - 3^{y}$ as a difference of squares of the second equation's terms.",
  correct=r"$8$",
  distractors=[(r"$4$", r"Finds $u = 25$, $v = 9$ but reads them as $5^{x}$ and $3^{y}$, so $x = y = 2$."),
               (r"$6$", r"Halves correctly for $x$ but reads $3^{y/2} = 9$ as $y = 2$."),
               (r"$16$", r"Finds $x = y = 4$ and reports $xy$.")],
  check=_d8, values=[8, 4, 6, 16], exams=CX, cognitive="Analysis")


def _d9():
    t = Symbol('t')
    cnt = 0
    for k in range(-10, 11):
        roots = _pos_roots_t(t**2 - (2 * k + 2) * t + 4 * k, t)
        if len(roots) == 1:
            cnt += 1
    return cnt
q("C12-A-039", TOP, "Parameter values for which an exponential equation has exactly one solution", "Difficult",
  "Inverse/parameter",
  r"For how many integers $k$ with $-10 \le k \le 10$ does the equation $9^{x} - (2k + 2) \cdot 3^{x} + 4k = 0$ have exactly one real solution $x$?",
  "MCQ",
  r"With $t = 3^{x} > 0$ the equation is $t^{2} - (2k + 2)t + 4k = (t - 2)(t - 2k) = 0$. The root $t = 2$ always gives one solution. The equation has exactly one solution when the other root $2k$ is not positive ($k \le 0$, that is $11$ values) or equals $2$ ($k = 1$). For $k \ge 2$ there are two solutions. The count is $11 + 1 = 12$.",
  "Overlooking the repeated root, or counting values that give at least one solution.",
  "C12A-parameter-root-count", "Factorise a parametric quadratic, then casework on the sign of a root and on a repeated root.",
  correct=r"$12$",
  distractors=[(r"$11$", r"Counts only $k \le 0$, overlooking that $k = 1$ makes both roots equal to $2$."),
               (r"$1$", r"Counts only the repeated-root case $k = 1$."),
               (r"$21$", r"Counts every $k$, since each one gives at least one solution $t = 2$.")],
  check=_d9, values=[12, 11, 1, 21], exams=CX, cognitive="Analysis")


def _d10():
    t = Symbol('t', positive=True)
    target = 3**7
    level = Integer(1)          # population at the start of the current 6-hour block (multiple of initial)
    for j in range(0, 20):
        start = 6 * j
        sol = [s for s in solve(Eq(level * 3**((t - start) / 2), target), t) if start <= s <= start + 6]
        if sol:
            return min(sol)
        level = level * 3**3 / 3        # grows 27-fold in 6 hours, then two-thirds removed
q("C12-A-040", TOP, "Tripling growth with periodic removal: first time a multiple is reached", "Difficult",
  "Multi-step word problem",
  r"A cell colony grows continuously and triples every $2$ hours. At $6$, $12$, $18$, $24, \ldots$ hours after the start, two-thirds of the cells present are removed at once, immediately after the count at that moment is recorded; growth then continues at the same rate. How many hours after the start does the colony first reach $2187$ times its initial size?",
  "MCQ",
  r"Each $6$-hour block multiplies the colony by $3^{3} = 27$, and the removal then divides it by $3$. Just before the removals at $6$ and $12$ hours the sizes are $27$ and $27 \cdot 9 = 243$ times the start, and just after the removal at $12$ hours it is $81$ times. From there it reaches $81 \times 27 = 2187$ times at $18$ hours, the moment before the third removal. The answer is $18$ hours.",
  "Ignoring the removals, or averaging growth and removal into one smooth rate.",
  "C12A-growth-word", "Multi-stage growth with interruptions; the target is reached exactly at a removal instant.",
  correct=r"$18$ hours",
  distractors=[(r"$14$ hours", r"Ignores the removals: $3^{7}$ needs $7$ triplings, $14$ hours."),
               (r"$21$ hours", r"Treats the net factor $9$ per $6$ hours as smooth growth: $9^{t/6} = 3^{7}$ gives $t = 21$."),
               (r"$24$ hours", r"Looks only at sizes just after removals ($9, 81, 729, 6561$ times) and takes the first one above $2187$.")],
  check=_d10, values=[18, 14, 21, 24], exams=CX, cognitive="Analysis")
