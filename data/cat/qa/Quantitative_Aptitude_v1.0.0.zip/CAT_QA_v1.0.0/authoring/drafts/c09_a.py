import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Systems of linear equations"
CX = ("CAT", "XAT")


def _solve(eqs, syms):
    """Unique solution of a linear system as a dict; raises if not unique."""
    sol = solve(eqs, syms, dict=True)
    assert len(sol) == 1 and all(s in sol[0] for s in syms), sol
    return sol[0]


def _kind(eqs, syms):
    """0 = no solution, 1 = unique, 2 = infinitely many."""
    s = linsolve(eqs, syms)
    if s == S.EmptySet:
        return 0
    (tup,) = list(s)
    return 2 if any(e.free_symbols & set(syms) for e in tup) else 1


# ================================================================ EASY (14)

def _c1():
    a, s = symbols('a s')
    return _solve([Eq(a + s, 420), Eq(150 * a + 90 * s, 47400)], [a, s])[a]
q("C09-A-001", T, "Two ticket types: total count and total revenue give the number of each", "Easy",
  "Multi-step word problem",
  r"A school play sold $420$ tickets in all. Each ticket was either an adult ticket at Rs. $150$ or a student ticket at Rs. $90$, and the total collection was Rs. $47{,}400$. How many adult tickets were sold?",
  "TITA",
  r"Let $a$ adult and $s$ student tickets be sold: $a + s = 420$ and $150a + 90s = 47400$. If all $420$ were student tickets the collection would be $420 \times 90 = 37800$; each adult ticket adds Rs. $60$, so $a = \frac{47400 - 37800}{60} = \frac{9600}{60} = 160$.",
  "Solving correctly but reporting the number of student tickets.",
  "C09A-ticket-count-revenue", "Two equations in two unknowns with a direct substitution; the only trap is which unknown is asked.",
  tita_answer=160, check=_c1,
  tita_traps=[(260, r"Reports the number of student tickets, $420 - 160$."),
              (210, r"Splits the $420$ tickets equally without using the collection.")],
  cognitive="Application")


def _c2():
    p, n = symbols('p n')
    return _solve([Eq(3 * p + 2 * n, 174), Eq(2 * p + 5 * n, 270)], [p, n])[n]
q("C09-A-002", T, "Two purchases of pens and notebooks; price of one notebook", "Easy",
  "Multi-step word problem",
  r"At a stationery shop, $3$ pens and $2$ notebooks cost Rs. $174$, while $2$ pens and $5$ notebooks cost Rs. $270$. What is the price of one notebook?",
  "MCQ",
  r"Let a pen cost $p$ and a notebook $n$. Doubling the first bill and tripling the second gives $6p + 4n = 348$ and $6p + 15n = 810$. Subtracting, $11n = 462$, so $n = 42$ (and then $p = 30$).",
  "Reporting the other unknown, or treating both items as if they had the same price.",
  "C09A-two-item-purchase", "Standard elimination in a $2 \\times 2$ system.",
  correct=r"Rs. $42$",
  distractors=[(r"Rs. $30$", r"Solves the system but reports the price of a pen."),
               (r"Rs. $37$", r"Adds the bills, $5p + 7n = 444$, and divides by the $12$ items as though a pen and a notebook cost the same."),
               (r"Rs. $72$", r"Reports the price of one pen and one notebook together, $30 + 42$.")],
  check=_c2, values=[42, 30, 37, 72], cognitive="Application")


def _c3():
    F_, r = symbols('F r')
    v = _solve([Eq(F_ + r, 1240), Eq((F_ + r) + (F_ / 2 + r), 1900)], [F_, r])
    return v[r]
q("C09-A-003", T, "Full and half train tickets sharing a full reservation charge", "Easy",
  "Multi-step word problem",
  r"On a train route, a full ticket costs the fare plus a reservation charge. A child's ticket costs half the fare plus the full reservation charge. One full ticket costs Rs. $1{,}240$, and one full ticket together with one child's ticket costs Rs. $1{,}900$. What is the reservation charge?",
  "MCQ",
  r"Let the fare be $F$ and the reservation charge $r$. Then $F + r = 1240$, and the child's ticket costs $1900 - 1240 = 660$, so $\frac{F}{2} + r = 660$. Subtracting, $\frac{F}{2} = 580$, so $F = 1160$ and $r = 1240 - 1160 = 80$.",
  "Halving the reservation charge along with the fare, or reporting the fare.",
  "C09A-full-half-ticket", "Two short equations; the trap is that only the fare is halved.",
  correct=r"Rs. $80$",
  distractors=[(r"Rs. $1{,}160$", r"Solves correctly but reports the fare."),
               (r"Rs. $660$", r"Takes the cost of the child's ticket, $1900 - 1240$, as the reservation charge."),
               (r"Rs. $580$", r"Finds $1240 - 660 = 580$, which is half the fare, and reports it.")],
  check=_c3, values=[80, 1160, 660, 580], cognitive="Application")


def _c4():
    c, w = symbols('c w')
    return _solve([Eq(c + w, 50), Eq(4 * c - w, 130)], [c, w])[c]
q("C09-A-004", T, "Positive and negative marking: number correct from total attempted and score", "Easy",
  "Multi-step word problem",
  r"A quiz has $50$ questions. Each correct answer earns $4$ marks and each wrong answer loses $1$ mark. Arjun attempted all $50$ questions and scored $130$ marks. How many questions did he answer correctly?",
  "TITA",
  r"Let $c$ be correct and $w$ wrong: $c + w = 50$ and $4c - w = 130$. Adding, $5c = 180$, so $c = 36$.",
  "Reporting the number of wrong answers, or ignoring the negative marking.",
  "C09A-scoring-plus-minus", "Two equations, one addition; the trap is the negative mark.",
  tita_answer=36, check=_c4,
  tita_traps=[(14, r"Reports the number of wrong answers, $50 - 36$."),
              (32, r"Ignores the penalty and takes $\frac{130}{4} = 32.5$, then truncates to $32$.")],
  cognitive="Application")


def _c5():
    k = symbols('k')
    ks = solve(Eq(3 * 10 - 6 * k, 0), k)
    good = []
    x, y = symbols('x y')
    for kv in ks:
        if _kind([Eq(3 * x + kv * y, 7), Eq(6 * x + 10 * y, 11)], [x, y]) == 0:
            good.append(kv)
    assert len(good) == 1
    return good[0]
q("C09-A-005", T, "Parameter value making a two-variable system inconsistent", "Easy",
  "Inverse/parameter",
  r"For what value of $k$ does the system $3x + ky = 7$, $6x + 10y = 11$ have no solution?",
  "MCQ",
  r"There is no solution when the left sides are proportional but the right sides are not: $\frac{3}{6} = \frac{k}{10} \neq \frac{7}{11}$. So $k = 5$, and since $\frac{7}{11} \neq \frac{1}{2}$ the lines are parallel and distinct.",
  "Setting up the proportion of coefficients the wrong way round or with the wrong sign.",
  "C09A-param-no-solution", "One proportion of coefficients and a check on the constants.",
  correct=r"$5$",
  distractors=[(r"$-5$", r"Sign slip when cross multiplying $3 \times 10 = 6k$."),
               (r"$20$", r"Inverts one ratio: $\frac{3}{6} = \frac{10}{k}$ gives $k = 20$."),
               (r"$10$", r"Thinks parallel lines need identical $y$ coefficients rather than proportional ones.")],
  check=_c5, values=[5, -5, 20, 10], cognitive="Understanding")


def _c6():
    k, p, c = symbols('k p c')
    v = _solve([Eq(k, p + 40), Eq(p, 2 * c), Eq(k + 2 * p + 3 * c, 355)], [k, p, c])
    return v[k]
q("C09-A-006", T, "Three prices linked by a difference and a multiple, with one bill", "Easy",
  "Multi-step word problem",
  r"At a bakery, a cake costs Rs. $40$ more than a pastry, and a pastry costs twice as much as a cookie. Priya paid Rs. $355$ for $1$ cake, $2$ pastries and $3$ cookies. What is the price of one cake, in rupees?",
  "TITA",
  r"Let a cookie cost $c$. Then a pastry costs $2c$ and a cake $2c + 40$. The bill gives $(2c + 40) + 2(2c) + 3c = 9c + 40 = 355$, so $c = 35$, a pastry costs $70$ and a cake $70 + 40 = 110$.",
  "Reversing the multiple between pastry and cookie, or reporting another price.",
  "C09A-chain-substitution", "Everything is expressed in one unknown; one linear equation follows.",
  tita_answer=110, check=_c6,
  tita_traps=[(70, r"Reports the price of a pastry."),
              (75, r"Reads it as a cookie costing twice a pastry: $(p + 40) + 2p + 6p = 355$ gives $p = 35$ and a cake at $75$."),
              (35, r"Reports the price of a cookie.")],
  cognitive="Application")


def _c7():
    P, Q, R = symbols('P Q R')
    return _solve([Eq(P + Q, 34), Eq(Q + R, 41), Eq(P + R, 37)], [P, Q, R])[R]
q("C09-A-007", T, "Three unknowns from their pairwise sums", "Easy",
  "Multi-step word problem",
  r"Three bags P, Q and R are weighed two at a time. Bags P and Q together weigh $34$ kg, Q and R together weigh $41$ kg, and P and R together weigh $37$ kg. What is the weight of bag R?",
  "MCQ",
  r"Adding the three pair weights counts each bag twice: $2(P + Q + R) = 112$, so $P + Q + R = 56$. Then $R = 56 - (P + Q) = 56 - 34 = 22$ kg.",
  "Forgetting to halve the sum of the pair weights, or subtracting the wrong pair.",
  "C09A-pairwise-sums", "Add all three equations, then one subtraction.",
  correct=r"$22$ kg",
  distractors=[(r"$15$ kg", r"Subtracts the pair Q and R from the total: this is the weight of P."),
               (r"$19$ kg", r"Subtracts the pair P and R from the total: this is the weight of Q."),
               (r"$78$ kg", r"Does not halve the sum and computes $112 - 34$.")],
  check=_c7, values=[22, 15, 19, 78], cognitive="Application")


def _c8():
    s, c = symbols('s c')
    v = _solve([Eq(2 * s + 3 * c, 1450), Eq(3 * s + 2 * c, 1800)], [s, c])
    return v[s] + v[c]
q("C09-A-008", T, "Adding symmetric equations to get the cost of one of each", "Easy",
  "Conceptual/application",
  r"Two shirts and three caps cost Rs. $1{,}450$, while three shirts and two caps cost Rs. $1{,}800$. What is the total cost of one shirt and one cap?",
  "MCQ",
  r"Adding the two bills gives $5$ shirts and $5$ caps for $1450 + 1800 = 3250$, so one shirt and one cap cost $\frac{3250}{5} = 650$. (Subtracting gives shirt minus cap $= 350$, so a shirt is $500$ and a cap $150$, but that is not needed.)",
  "Solving for one price and reporting it, instead of spotting that adding the equations gives the sum directly.",
  "C09A-swapped-quantities", "One addition of two equations once the symmetry is noticed.",
  correct=r"Rs. $650$",
  distractors=[(r"Rs. $500$", r"Reports the price of a shirt alone."),
               (r"Rs. $350$", r"Subtracts the bills and reports the difference between a shirt and a cap."),
               (r"Rs. $150$", r"Reports the price of a cap alone.")],
  check=_c8, values=[650, 500, 350, 150], cognitive="Understanding")


def _c9():
    k, t = symbols('k t')
    return _solve([Eq(k + t, 4000), Eq(Rational(11, 10) * k + Rational(95, 100) * t, 4160)], [k, t])[k]
q("C09-A-009", T, "Two prices with different percentage changes and two totals", "Easy",
  "Multi-step word problem",
  r"A kettle and a toaster together cost Rs. $4{,}000$. The price of the kettle then rises by $10\%$ and the price of the toaster falls by $5\%$, after which the two together cost Rs. $4{,}160$. What was the original price of the kettle?",
  "MCQ",
  r"Let the prices be $k$ and $t$ with $k + t = 4000$. Then $1.1k + 0.95t = 4160$. Substituting $t = 4000 - k$: $1.1k + 3800 - 0.95k = 4160$, so $0.15k = 360$ and $k = 2400$.",
  "Treating the net change as a single percentage of one price.",
  "C09A-percent-change-system", "Two equations, one with decimal coefficients; one substitution.",
  correct=r"Rs. $2{,}400$",
  distractors=[(r"Rs. $1{,}600$", r"Solves correctly but reports the toaster's price."),
               (r"Rs. $3{,}200$", r"Treats the Rs. $160$ rise as $10\% - 5\% = 5\%$ of the kettle price: $\frac{160}{0.05}$."),
               (r"Rs. $2{,}000$", r"Assumes the two items cost the same and splits Rs. $4{,}000$ equally.")],
  check=_c9, values=[2400, 1600, 3200, 2000], cognitive="Application")


def _c10():
    r, b = symbols('r b')
    return _solve([Eq(4 * r + 3 * b, 62), Eq(2 * r + 5 * b, 52)], [r, b])[r]
q("C09-A-010", T, "Points per target from two players' scores", "Easy",
  "Multi-step word problem",
  r"In a target game, every hit on a red disc earns the same number of points, and every hit on a blue disc earns the same (different) number of points. Fatima hit $4$ red and $3$ blue discs and scored $62$ points. Joseph hit $2$ red and $5$ blue discs and scored $52$ points. How many points does one hit on a red disc earn?",
  "TITA",
  r"Let a red hit be worth $r$ and a blue hit $b$: $4r + 3b = 62$ and $2r + 5b = 52$. Doubling the second, $4r + 10b = 104$; subtracting the first, $7b = 42$, so $b = 6$ and $r = \frac{62 - 18}{4} = 11$.",
  "Reporting the blue value, or eliminating with the wrong multiplier.",
  "C09A-two-item-purchase", "One elimination in a $2 \\times 2$ system.",
  tita_answer=11, check=_c10,
  tita_traps=[(6, r"Reports the points for a blue hit."),
              (17, r"Reports $r + b$, the points for one red and one blue hit together.")],
  cognitive="Application")


def _c11():
    x, y = symbols('x y')
    return _kind([Eq(2 * x - 3 * y, 5), Eq(6 * x - 9 * y, 15)], [x, y])
q("C09-A-011", T, "Recognising dependent equations (infinitely many solutions)", "Easy",
  "Conceptual/application",
  r"Consider the system of equations $2x - 3y = 5$ and $6x - 9y = 15$. Which of the following is true?",
  "MCQ",
  r"The second equation is exactly $3$ times the first ($6x - 9y = 15$ is $3(2x - 3y) = 3 \times 5$), so both describe the same line. Every point on $2x - 3y = 5$ satisfies both, so there are infinitely many solutions; $(4, 1)$ is just one of them.",
  "Finding one solution and assuming it is the only one.",
  "C09A-classify-system", "Comparing ratios of coefficients and constants; one idea.",
  correct=r"The system has infinitely many solutions",
  distractors=[(r"The system has exactly one solution", r"Assumes two equations in two unknowns always give one solution."),
               (r"The system has no solution", r"Sees equal ratios $\frac{2}{6} = \frac{-3}{-9}$ and concludes parallel lines without checking $\frac{5}{15}$."),
               (r"The system has exactly one solution, $x = 4$, $y = 1$", r"Checks that $(4, 1)$ satisfies both equations and assumes it is the only solution.")],
  check=_c11, values=[2, 1, 0, 3], cognitive="Understanding")


def _c12():
    a, b = symbols('a b')
    s = _solve([Eq(F(2, 4), 3 / a), Eq(F(2, 4), 7 / b)], [a, b])
    x, y = symbols('x y')
    assert _kind([Eq(2 * x + 3 * y, 7), Eq(4 * x + s[a] * y, s[b])], [x, y]) == 2
    return s[a] + s[b]
q("C09-A-012", T, "Two parameters making a system have infinitely many solutions", "Easy",
  "Inverse/parameter",
  r"The system $2x + 3y = 7$ and $4x + ay = b$ has infinitely many solutions. What is the value of $a + b$?",
  "MCQ",
  r"For infinitely many solutions the second equation must be a multiple of the first. Its $x$ coefficient is $2$ times that of the first, so $a = 2 \times 3 = 6$ and $b = 2 \times 7 = 14$, giving $a + b = 20$.",
  "Matching coefficients but leaving the constant unscaled, or using the wrong scale factor.",
  "C09A-param-infinite", "Read off one scale factor and apply it twice.",
  correct=r"$20$",
  distractors=[(r"$13$", r"Scales $a$ to $6$ but keeps $b = 7$, the original constant."),
               (r"$5$", r"Uses the scale factor $\frac{1}{2}$: $a = \frac{3}{2}$, $b = \frac{7}{2}$."),
               (r"$40$", r"Uses the new $x$ coefficient $4$ as the scale factor: $a = 12$, $b = 28$.")],
  check=_c12, values=[20, 13, 5, 40], cognitive="Understanding")


def _c13():
    r, d = symbols('r d')
    return _solve([Eq(5 * r + 3 * d, 490), Eq(3 * r + 5 * d, 550)], [r, d])[d]
q("C09-A-013", T, "Order with quantities interchanged; add and subtract the two bills", "Easy",
  "Multi-step word problem",
  r"Priya ordered $5$ kg of rice and $3$ kg of dal from a grocer and the bill was Rs. $490$. The next week she ordered $3$ kg of rice and $5$ kg of dal at the same prices, and the bill was Rs. $550$. What is the price of dal, in rupees per kg?",
  "TITA",
  r"Adding the bills: $8(r + d) = 1040$, so $r + d = 130$. Subtracting: $2(d - r) = 60$, so $d - r = 30$. Hence $d = \frac{130 + 30}{2} = 80$.",
  "Forgetting to halve the difference of the bills, or reporting the rice price.",
  "C09A-swapped-quantities", "Add and subtract two symmetric equations.",
  tita_answer=80, check=_c13,
  tita_traps=[(50, r"Reports the price of rice."),
              (95, r"Takes $d - r = 60$ without halving: $d = \frac{130 + 60}{2}$."),
              (65, r"Reports the average of the two prices, $\frac{130}{2}$.")],
  cognitive="Application")


def _c14():
    s, v, i = symbols('s v i')
    return _solve([Eq(s + v + i, 60), Eq(2 * s + v, 52), Eq(s + 2 * i, 64)], [s, v, i])[v]
q("C09-A-014", T, "Three snack prices from three orders", "Easy",
  "Multi-step word problem",
  r"At a canteen, one samosa, one vada and one idli together cost Rs. $60$. Two samosas and one vada cost Rs. $52$, and one samosa and two idlis cost Rs. $64$. What is the price of one vada?",
  "MCQ",
  r"Let the prices be $s$, $v$, $i$. Then $v = 52 - 2s$ and $i = \frac{64 - s}{2}$. Substituting in $s + v + i = 60$: $s + 52 - 2s + 32 - \frac{s}{2} = 60$, so $\frac{3s}{2} = 24$ and $s = 16$. Hence $v = 52 - 32 = 20$ (and $i = 24$).",
  "Dropping a coefficient of $2$ in one of the orders.",
  "C09A-three-var-purchase", "Three unknowns but two of them are expressed directly in terms of the third.",
  correct=r"Rs. $20$",
  distractors=[(r"Rs. $16$", r"Solves correctly but reports the price of a samosa."),
               (r"Rs. $24$", r"Solves correctly but reports the price of an idli."),
               (r"Rs. $36$", r"Finds $s = 16$ and then reads the second order as one samosa and one vada: $52 - 16$.")],
  check=_c14, values=[20, 16, 24, 36], cognitive="Application")


# ================================================================ MEDIUM (20)

def _c15():
    a, b, c = symbols('a b c')
    return _solve([Eq(a + b + c, 1200), Eq(300 * a + 500 * b + 800 * c, 522000), Eq(b, 2 * c)], [a, b, c])[a]
q("C09-A-015", T, "Three ticket classes with a count, a revenue and a ratio condition", "Medium",
  "Multi-step word problem",
  r"A stadium sold $1{,}200$ tickets for a match in three classes priced at Rs. $300$, Rs. $500$ and Rs. $800$. The total collection was Rs. $5{,}22{,}000$, and the number of Rs. $500$ tickets sold was twice the number of Rs. $800$ tickets sold. How many Rs. $300$ tickets were sold?",
  "TITA",
  r"Let $a$, $b$, $c$ be the numbers of Rs. $300$, $500$, $800$ tickets, with $b = 2c$. Then $a + 3c = 1200$ and $300a + 1000c + 800c = 522000$, that is $a + 6c = 1740$. Subtracting, $3c = 540$, so $c = 180$, $b = 360$ and $a = 1200 - 540 = 660$.",
  "Reporting another class's count after solving.",
  "C09A-ticket-count-revenue", "Three unknowns reduced to two by the ratio condition, then elimination.",
  tita_answer=660, check=_c15,
  tita_traps=[(360, r"Reports the number of Rs. $500$ tickets."),
              (180, r"Reports the number of Rs. $800$ tickets.")],
  cognitive="Application")


def _c16():
    x, y = symbols('x y')
    s = solve([Eq(3 / x + 2 / y, 12), Eq(9 / x - 4 / y, 6)], [x, y], dict=True)
    assert len(s) == 1
    return s[0][x] + s[0][y]
q("C09-A-016", T, "System linear in reciprocals; substitute and invert", "Medium",
  "Multi-step word problem",
  r"Non-zero real numbers $x$ and $y$ satisfy $\frac{3}{x} + \frac{2}{y} = 12$ and $\frac{9}{x} - \frac{4}{y} = 6$. What is the value of $x + y$?",
  "MCQ",
  r"Put $u = \frac{1}{x}$ and $v = \frac{1}{y}$: $3u + 2v = 12$ and $9u - 4v = 6$. Doubling the first and adding, $15u = 30$, so $u = 2$ and $v = 3$. Hence $x = \frac{1}{2}$, $y = \frac{1}{3}$ and $x + y = \frac{5}{6}$.",
  "Solving for the reciprocals and forgetting to invert them.",
  "C09A-reciprocal-substitution", "Needs the substitution and the final inversion; two steps.",
  correct=r"$\frac{5}{6}$",
  distractors=[(r"$5$", r"Solves for $u = 2$, $v = 3$ and adds them without inverting."),
               (r"$\frac{6}{5}$", r"Writes $x + y = \frac{1}{u} + \frac{1}{v} = \frac{u + v}{uv}$ but inverts it as $\frac{uv}{u + v}$."),
               (r"$6$", r"Computes $uv = 6$, the reciprocal of $xy$, and reports it.")],
  check=_c16, values=[F(5, 6), 5, F(6, 5), 6], cognitive="Application")


def _c17():
    b, f, s = symbols('b f s')
    return _solve([Eq(2 * b + f + s, 330), Eq(b + 2 * f + s, 290), Eq(b + f + 2 * s, 300)], [b, f, s])[s]
q("C09-A-017", T, "Three orders each doubling a different item; sum then subtract", "Medium",
  "Multi-step word problem",
  r"At a food stall, Ravi paid Rs. $330$ for $2$ burgers, $1$ plate of fries and $1$ shake; Priya paid Rs. $290$ for $1$ burger, $2$ plates of fries and $1$ shake; and Joseph paid Rs. $300$ for $1$ burger, $1$ plate of fries and $2$ shakes. All prices are fixed. What is the price of one shake, in rupees?",
  "TITA",
  r"Adding the three bills gives $4(b + f + s) = 920$, so $b + f + s = 230$. Joseph's bill exceeds this by exactly one shake: $s = 300 - 230 = 70$.",
  "Stopping at the sum of the three prices, or subtracting from the wrong bill.",
  "C09A-sum-all-three", "Three unknowns; the fast route needs the sum of all equations.",
  tita_answer=70, check=_c17,
  tita_traps=[(230, r"Reports the cost of one of each item, $b + f + s$."),
              (100, r"Subtracts $230$ from Ravi's bill, which gives the burger price."),
              (60, r"Subtracts $230$ from Priya's bill, which gives the fries price.")],
  cognitive="Application")


def _c18():
    x, y, z = symbols('x y z')
    sol = linsolve([Eq(5 * x + 9 * y + z, 410), Eq(7 * x + 13 * y + z, 580)], [x, y, z])
    (tup,) = list(sol)
    val = simplify(sum(tup))
    assert not val.free_symbols
    return val
q("C09-A-018", T, "Cost of one of each from two equations in three unknowns", "Medium",
  "Conceptual/application",
  r"At a shop with fixed prices, $5$ notebooks, $9$ pens and $1$ geometry box cost Rs. $410$, while $7$ notebooks, $13$ pens and $1$ geometry box cost Rs. $580$. What is the total cost, in rupees, of $1$ notebook, $1$ pen and $1$ geometry box?",
  "TITA",
  r"Look for multipliers $\alpha$, $\beta$ with $\alpha(5, 9, 1) + \beta(7, 13, 1) = (1, 1, 1)$. From $\alpha + \beta = 1$ and $5\alpha + 7\beta = 1$ we get $\beta = -2$, $\alpha = 3$, and indeed $3 \times 9 - 2 \times 13 = 1$. So the required cost is $3 \times 410 - 2 \times 580 = 1230 - 1160 = 70$.",
  "Believing the question cannot be answered without a third equation, or stopping at the difference of the bills.",
  "C09A-add-equations-combination", "Individual prices are not determined; the candidate must find the right combination of the two equations.",
  tita_answer=70, check=_c18,
  tita_traps=[(85, r"Subtracts the bills and halves: $2x + 4y = 170$ gives $x + 2y = 85$, which is not the required total."),
              (170, r"Reports the difference of the two bills.")],
  cognitive="Analysis", exams=CX)


def _c19():
    x, y, z = symbols('x y z')
    sol = linsolve([Eq(x + 2 * y + 3 * z, 145), Eq(2 * x + 3 * y + 4 * z, 220)], [x, y, z])
    (tup,) = list(sol)
    val = simplify(3 * tup[0] + 4 * tup[1] + 5 * tup[2])
    assert not val.free_symbols
    return val
q("C09-A-019", T, "Cost of a third order as a combination of two given orders", "Medium",
  "Conceptual/application",
  r"At a canteen, $1$ sandwich, $2$ juices and $3$ muffins cost Rs. $145$, and $2$ sandwiches, $3$ juices and $4$ muffins cost Rs. $220$. At the same prices, what is the cost of $3$ sandwiches, $4$ juices and $5$ muffins?",
  "MCQ",
  r"The orders step up by one of each item: the second order minus the first is $1$ sandwich, $1$ juice and $1$ muffin, costing $220 - 145 = 75$. The required order is the second order plus one of each: $220 + 75 = 295$. (Equivalently $2 \times 220 - 145$.)",
  "Adding or doubling the given bills without matching the item counts.",
  "C09A-add-equations-combination", "Two equations in three unknowns; the target must be built as a combination.",
  correct=r"Rs. $295$",
  distractors=[(r"Rs. $365$", r"Adds the two bills, which prices $3$ sandwiches, $5$ juices and $7$ muffins."),
               (r"Rs. $440$", r"Doubles the second bill and does not subtract the first."),
               (r"Rs. $290$", r"Doubles the first bill, which prices $2$ sandwiches, $4$ juices and $6$ muffins.")],
  check=_c19, values=[295, 365, 440, 290], cognitive="Analysis")


def _c20():
    K, S_, J = symbols('K S J')
    return _solve([Eq(K + S_, 144), Eq(S_ + J, 162), Eq(K + J, 150)], [K, S_, J])[J]
q("C09-A-020", T, "Individual scores from three pairwise averages", "Medium",
  "Multi-step word problem",
  r"The average score of Kabir and Sneha in a test is $72$, the average score of Sneha and Joseph is $81$, and the average score of Kabir and Joseph is $75$. What is Joseph's score, in marks?",
  "TITA",
  r"The pair sums are $144$, $162$ and $150$. Adding, $2(K + S + J) = 456$, so $K + S + J = 228$. Joseph's score is $228 - (K + S) = 228 - 144 = 84$.",
  "Working with the averages as though they were sums, or stopping at the overall average.",
  "C09A-pairwise-sums", "Converting averages to sums before adding; two steps.",
  tita_answer=84, check=_c20,
  tita_traps=[(76, r"Reports the average of all three, $\frac{228}{3}$."),
              (78, r"Reports Sneha's score, $228 - 150$."),
              (42, r"Adds the averages to get $228$ and halves it as if they were pair sums: $114 - 72$.")],
  cognitive="Application")


def _c21():
    c, w, u = symbols('c w u')
    return _solve([Eq(c + w + u, 60), Eq(3 * c - w, 112), Eq(c, 5 * w)], [c, w, u])[u]
q("C09-A-021", T, "Correct, wrong and unattempted counts with negative marking and a ratio", "Medium",
  "Multi-step word problem",
  r"A test has $60$ questions. A correct answer earns $3$ marks, a wrong answer loses $1$ mark and an unattempted question earns $0$. Ananya scored $112$ marks, and the number of questions she answered correctly was five times the number she answered wrongly. How many questions did she leave unattempted?",
  "MCQ",
  r"Let $w$ be wrong, so $5w$ are correct. Score: $3(5w) - w = 14w = 112$, so $w = 8$ and $5w = 40$. Unattempted $= 60 - 40 - 8 = 12$.",
  "Adding the penalty instead of subtracting it, or reporting a different count.",
  "C09A-scoring-plus-minus", "Three categories, a score equation and a ratio; three short steps.",
  correct=r"$12$",
  distractors=[(r"$8$", r"Solves correctly but reports the number of wrong answers."),
               (r"$20$", r"Reports $60 - 40$, the number not answered correctly, which includes the wrong ones."),
               (r"$18$", r"Adds the penalty: $15w + w = 112$ gives $w = 7$, $35$ correct and $60 - 42 = 18$.")],
  check=_c21, values=[12, 8, 20, 18], cognitive="Application")


def _c22():
    w, d, l = symbols('w d l')
    return _solve([Eq(w + d + l, 30), Eq(3 * w + d, 50), Eq(l, d)], [w, d, l])[d]
q("C09-A-022", T, "League points with wins, draws and losses", "Medium",
  "Multi-step word problem",
  r"In a football league a win earns $3$ points, a draw $1$ point and a loss $0$ points. A team played $30$ matches and finished with $50$ points. It lost exactly as many matches as it drew. How many matches did it draw?",
  "MCQ",
  r"Let $w$ wins and $d$ draws, with $d$ losses too. Then $w + 2d = 30$ and $3w + d = 50$. Multiplying the second by $2$ and subtracting the first, $5w = 70$, so $w = 14$ and $d = \frac{30 - 14}{2} = 8$.",
  "Leaving the losses out of the match count, or reporting the wins.",
  "C09A-match-points", "Three outcome counts reduced to two by a given relation.",
  correct=r"$8$",
  distractors=[(r"$14$", r"Solves correctly but reports the number of wins."),
               (r"$20$", r"Leaves out the losses: $w + d = 30$ with $3w + d = 50$ gives $w = 10$, $d = 20$."),
               (r"$16$", r"Reports draws and losses together, $2d$.")],
  check=_c22, values=[8, 14, 20, 16], cognitive="Application")


def _c23():
    k = symbols('k')
    x, y = symbols('x y')
    ks = solve(Eq(k * k - 3 * 12, 0), k)
    good = [kv for kv in ks if _kind([Eq(kv * x + 3 * y, kv - 3), Eq(12 * x + kv * y, kv)], [x, y]) == 0]
    return FiniteSet(*good)
q("C09-A-023", T, "Parameter for no solution where one root gives coincident lines", "Medium",
  "Inverse/parameter",
  r"For which value or values of $k$ does the system $kx + 3y = k - 3$, $12x + ky = k$ have no solution?",
  "MCQ",
  r"The left sides are proportional when $\frac{k}{12} = \frac{3}{k}$, that is $k^2 = 36$, $k = \pm 6$. For $k = 6$ the equations are $6x + 3y = 3$ and $12x + 6y = 6$, which are the same line, so there are infinitely many solutions. For $k = -6$ they are $-6x + 3y = -9$ and $12x - 6y = -6$, that is $2x - y = 3$ and $2x - y = -1$: parallel and distinct. So only $k = -6$.",
  "Stopping at the condition on the coefficients and not checking the constants.",
  "C09A-param-no-solution", "Quadratic in $k$ and a check of each root against the constants.",
  correct=r"$k = -6$ only",
  distractors=[(r"$k = 6$ only", r"Checks only the positive root and does not see that it gives the same line twice."),
               (r"$k = 6$ and $k = -6$", r"Uses only $k^2 = 36$ and does not test the constants."),
               (r"No real value of $k$", r"Sign slip in the cross product: writes $k^2 + 36 = 0$, which has no real root.")],
  check=_c23, values=[FiniteSet(-6), FiniteSet(6), FiniteSet(6, -6), S.EmptySet], cognitive="Analysis", exams=CX)


def _c24():
    a, b = symbols('a b')
    s = _solve([Eq(Rational(2, 4), (a - 4) / (a - 1)), Eq(Rational(2, 4), (2 * b + 1) / (5 * b - 1))], [a, b])
    x, y = symbols('x y')
    assert _kind([Eq(2 * x + (s[a] - 4) * y, 2 * s[b] + 1), Eq(4 * x + (s[a] - 1) * y, 5 * s[b] - 1)], [x, y]) == 2
    return s[a] + s[b]
q("C09-A-024", T, "Two parameters in both coefficients and constants for infinitely many solutions", "Medium",
  "Inverse/parameter",
  r"The system $2x + (a - 4)y = 2b + 1$ and $4x + (a - 1)y = 5b - 1$ has infinitely many solutions. Find the value of $a + b$.",
  "TITA",
  r"All three ratios must equal $\frac{2}{4} = \frac{1}{2}$. From $\frac{a - 4}{a - 1} = \frac{1}{2}$: $2a - 8 = a - 1$, so $a = 7$. From $\frac{2b + 1}{5b - 1} = \frac{1}{2}$: $4b + 2 = 5b - 1$, so $b = 3$. Hence $a + b = 10$.",
  "Equating coefficients directly instead of setting each ratio equal to the ratio of the $x$ coefficients.",
  "C09A-param-infinite", "Two separate ratio equations, each linear in a parameter.",
  tita_answer=10, check=_c24,
  tita_traps=[(7, r"Finds $a = 7$ and types it without finding $b$."),
              (3, r"Finds $b = 3$ and types it without finding $a$.")],
  cognitive="Application", exams=CX)


def _c25():
    k = symbols('k')
    x, y = symbols('x y')
    ks = solve(Eq(k * (k - 1) - 2 * 3, 0), k)
    bad = [kv for kv in ks if _kind([Eq(kv * x + 2 * y, 5), Eq(3 * x + (kv - 1) * y, 7)], [x, y]) != 1]
    for kv in range(-10, 11):
        if kv not in bad:
            assert _kind([Eq(kv * x + 2 * y, 5), Eq(3 * x + (kv - 1) * y, 7)], [x, y]) == 1
    return FiniteSet(*bad)
q("C09-A-025", T, "Values of the parameter excluded for a unique solution", "Medium",
  "Inverse/parameter",
  r"The system $kx + 2y = 5$, $3x + (k - 1)y = 7$ has a unique solution for every real value of $k$ except",
  "MCQ",
  r"A unique solution exists unless the determinant vanishes: $k(k - 1) - 2 \times 3 = 0$, that is $k^2 - k - 6 = (k - 3)(k + 2) = 0$. So the exceptions are $k = 3$ and $k = -2$ (both in fact give parallel lines).",
  "Factorising the quadratic with the wrong signs, or cross multiplying the wrong pair of coefficients.",
  "C09A-param-unique", "A quadratic condition from the determinant; two roots to keep.",
  correct=r"$k = 3$ and $k = -2$",
  distractors=[(r"$k = -3$ and $k = 2$", r"Factorises $k^2 - k - 6$ as $(k + 3)(k - 2)$."),
               (r"$k = 3$ only", r"Finds the positive root and drops the negative one."),
               (r"$k = -2$ only", r"Cross multiplies the wrong pair: $3k = 2(k - 1)$ gives $k = -2$.")],
  check=_c25, values=[FiniteSet(3, -2), FiniteSet(-3, 2), FiniteSet(3), FiniteSet(-2)], cognitive="Application", exams=CX)


def _c26():
    g, s, b = symbols('g s b')
    return _solve([Eq(g + 2 * s + 3 * b, 26), Eq(2 * g + 3 * s + b, 32), Eq(3 * g + s + 2 * b, 32)], [g, s, b])[g]
q("C09-A-026", T, "Cyclic coefficients: total first, then differences", "Medium",
  "Conceptual/application",
  r"In a sports meet, each gold medal is worth a fixed number of points, each silver a fixed number and each bronze a fixed number. Team Red won $1$ gold, $2$ silver and $3$ bronze for $26$ points; Team Blue won $2$ gold, $3$ silver and $1$ bronze for $32$ points; Team Green won $3$ gold, $1$ silver and $2$ bronze for $32$ points. How many points is a gold medal worth?",
  "MCQ",
  r"Adding all three: $6(g + s + b) = 90$, so $g + s + b = 15$. Green minus Blue gives $g - 2s + b = 0$, so $g + b = 2s$ and $3s = 15$, $s = 5$, $g + b = 10$. Blue minus Red gives $g + s - 2b = 6$, so $g - 2b = 1$; with $g + b = 10$ this gives $b = 3$, $g = 7$.",
  "Stopping at the total of the three values, or dividing the grand total by the wrong number.",
  "C09A-sum-all-three", "Uses the cyclic symmetry to get the total, then two differences.",
  correct=r"$7$",
  distractors=[(r"$15$", r"Stops at $g + s + b = 15$."),
               (r"$5$", r"Reports the silver value."),
               (r"$30$", r"Divides the total $90$ by $3$, the number of teams, instead of by $6$.")],
  check=_c26, values=[7, 15, 5, 30], cognitive="Application")


def _c27():
    best = None
    sums = [2400, 2600, 2700, 2800]
    tot = F(sum(sums), 3)
    vals = [tot - s for s in sums]
    # verify: every three of the four values give back one of the sums
    for comb in itertools.combinations(vals, 3):
        assert sum(comb) in sums
    return max(vals)
q("C09-A-027", T, "Four unknowns from the four sums of three", "Medium",
  "Multi-step word problem",
  r"Ravi, Meera, Arjun and Fatima each have some money. When the amounts of any three of them are added, leaving out one person at a time, the four totals are Rs. $2{,}400$, Rs. $2{,}600$, Rs. $2{,}700$ and Rs. $2{,}800$. What is the largest amount, in rupees, that any one of them has?",
  "TITA",
  r"Each person is left out once and counted in three totals, so the sum of the four totals is $3$ times the combined amount: $10500 = 3 \times 3500$. The person left out of the smallest total has the most: $3500 - 2400 = 1100$.",
  "Dividing the sum of the totals by $4$ instead of $3$, or subtracting from the largest total.",
  "C09A-sum-of-three-of-four", "Needs the counting idea that each person appears in three of the four totals.",
  tita_answer=1100, check=_c27,
  tita_traps=[(3500, r"Reports the combined amount of all four."),
              (225, r"Divides $10500$ by $4$ to get $2625$ and subtracts $2400$."),
              (700, r"Subtracts the largest total, which gives the smallest amount.")],
  cognitive="Analysis")


def _c28():
    k = symbols('k')
    x, y = symbols('x y')
    sol = _solve([Eq(3 * x + 2 * y, k + 3), Eq(2 * x - y, k - 5)], [x, y])
    ks = solve(Eq(sol[x], sol[y]), k)
    assert len(ks) == 1
    return ks[0]
q("C09-A-028", T, "Parameter for which the solution has equal coordinates", "Medium",
  "Inverse/parameter",
  r"For what value of $k$ does the solution $(x, y)$ of the system $3x + 2y = k + 3$, $2x - y = k - 5$ satisfy $x = y$?",
  "MCQ",
  r"Put $y = x$: the equations become $5x = k + 3$ and $x = k - 5$. So $5(k - 5) = k + 3$, $4k = 28$ and $k = 7$ (giving $x = y = 2$).",
  "Mishandling the minus sign when substituting $y = x$ in $2x - y$.",
  "C09A-param-solution-condition", "Substitute the condition, then one linear equation in $k$.",
  correct=r"$7$",
  distractors=[(r"$2$", r"Reports the common value of $x$ and $y$."),
               (r"$17$", r"Reads $2x - y$ as $3x$ after putting $y = x$: $3x = k - 5$ and $5x = k + 3$ give $k = 17$."),
               (r"$-7$", r"Imposes $y = -x$: then $x = k + 3$ and $3x = k - 5$ give $k = -7$.")],
  check=_c28, values=[7, 2, 17, -7], cognitive="Application")


def _c29():
    k = symbols('k')
    x, y = symbols('x y')
    s = _solve([Eq(2 * x + y, 7), Eq(x - y, 2)], [x, y])
    return solve(Eq(k * s[x] + 3 * s[y], 18), k)[0]
q("C09-A-029", T, "Three equations in two unknowns sharing a common solution", "Medium",
  "Conceptual/application",
  r"The three equations $2x + y = 7$, $x - y = 2$ and $kx + 3y = 18$ have a common solution. What is the value of $k$?",
  "MCQ",
  r"The first two fix the point: adding them, $3x = 9$, so $x = 3$ and $y = 1$. The third line must pass through $(3, 1)$: $3k + 3 = 18$, so $k = 5$.",
  "Mixing up $x$ and $y$ or getting the sign of $y$ wrong before substituting.",
  "C09A-three-lines-two-unknowns", "Recognising that two equations fix the point and the third must pass through it.",
  correct=r"$5$",
  distractors=[(r"$6$", r"Drops the $3y$ term: $3k = 18$."),
               (r"$9$", r"Substitutes $x = 1$, $y = 3$: $k + 9 = 18$."),
               (r"$7$", r"Subtracts the first two equations carelessly and gets $y = -1$: $3k - 3 = 18$.")],
  check=_c29, values=[5, 6, 9, 7], cognitive="Understanding")


def _c30():
    x, y, z = symbols('x y z', positive=True)
    s = solve([Eq(x + 2 * y, 3 * z), Eq(2 * x + z, y)], [x, y], dict=True)[0]
    r = (simplify(s[x] / z), simplify(s[y] / z), 1)
    g = r[0]
    return tuple(simplify(t / g) for t in r)
q("C09-A-030", T, "Ratio of three prices from two homogeneous conditions", "Medium",
  "Conceptual/application",
  r"At a florist, $1$ rose and $2$ lilies cost as much as $3$ orchids, and $2$ roses and $1$ orchid cost as much as $1$ lily. What is the ratio of the prices of a rose, a lily and an orchid?",
  "MCQ",
  r"Let the prices be $x$, $y$, $z$: $x + 2y = 3z$ and $y = 2x + z$. Substituting, $x + 4x + 2z = 3z$, so $z = 5x$ and $y = 2x + 5x = 7x$. Hence $x : y : z = 1 : 7 : 5$. (Check: $1 + 14 = 15 = 3 \times 5$ and $2 + 5 = 7$.)",
  "Sign slip when substituting, or writing the ratio in the wrong order.",
  "C09A-homogeneous-ratio", "Two homogeneous equations in three unknowns determine only a ratio.",
  correct=r"$1 : 7 : 5$",
  distractors=[(r"$1 : 5 : 7$", r"Finds the right values but writes the lily and orchid prices in the wrong places."),
               (r"$1 : 1 : 1$", r"Puts $z = 1$ and writes $y = 2x - 1$: then $x + 4x - 2 = 3$ gives $x = y = z$."),
               (r"$5 : 7 : 1$", r"Lists the prices in the order orchid, lily, rose.")],
  check=_c30, values=[(1, 7, 5), (1, 5, 7), (1, 1, 1), (5, 7, 1)], cognitive="Application")


def _c31():
    f, a, b = symbols('f a b')
    def bill(u):
        return f + a * min(u, 100) + b * max(u - 100, 0)
    s = _solve([Eq(bill(80), 520), Eq(bill(150), 1000), Eq(bill(220), 1560)], [f, a, b])
    return s[f]
q("C09-A-031", T, "Slab tariff with a fixed charge; three bills give three unknowns", "Medium",
  "Multi-step word problem",
  r"A monthly electricity bill has a fixed charge, plus Rs. $a$ per unit for each of the first $100$ units and Rs. $b$ per unit for every unit beyond $100$. Bills for $80$, $150$ and $220$ units were Rs. $520$, Rs. $1{,}000$ and Rs. $1{,}560$ respectively. What is the fixed charge, in rupees?",
  "TITA",
  r"Both the $150$ and $220$ unit bills include the full first slab, so the extra $70$ units cost $1560 - 1000 = 560$, giving $b = 8$. Then the first $100$ units plus the fixed charge cost $1000 - 50 \times 8 = 600$. Comparing with the $80$ unit bill, $20a = 600 - 520 = 80$, so $a = 4$ and the fixed charge is $520 - 80 \times 4 = 200$.",
  "Applying one rate to all units, or reporting the cost of the first slab including the fixed charge.",
  "C09A-fixed-plus-variable", "Three unknowns with two slabs; the order in which the bills are compared matters.",
  tita_answer=200, check=_c31,
  tita_traps=[(600, r"Reports the fixed charge plus the first $100$ units."),
              (8, r"Reports $b$, the rate for units beyond $100$.")],
  cognitive="Analysis")


def _c32():
    t, c = symbols('t c')
    s = _solve([Eq(2 * t + 3 * c, 2700), Eq(2 * Rational(12, 10) * t + 3 * Rational(9, 10) * c, 2790)], [t, c])
    return Rational(9, 10) * s[c]
q("C09-A-032", T, "Same basket before and after two percentage price changes", "Medium",
  "Multi-step word problem",
  r"Last year $2$ kg of tea and $3$ kg of coffee cost Rs. $2{,}700$. This year the price of tea has risen by $20\%$ and the price of coffee has fallen by $10\%$, and the same $2$ kg of tea and $3$ kg of coffee now cost Rs. $2{,}790$. What is this year's price of coffee per kg?",
  "MCQ",
  r"Let last year's prices be $t$ and $c$ per kg: $2t + 3c = 2700$ and $2.4t + 2.7c = 2790$. Multiplying the first by $1.2$: $2.4t + 3.6c = 3240$; subtracting, $0.9c = 450$, so $c = 500$. This year's coffee price is $0.9 \times 500 = 450$.",
  "Reporting last year's price, or applying the change in the wrong direction.",
  "C09A-percent-change-system", "Two equations with percentage coefficients, then one more step to the new price.",
  correct=r"Rs. $450$",
  distractors=[(r"Rs. $500$", r"Reports last year's coffee price."),
               (r"Rs. $720$", r"Reports this year's tea price, $1.2 \times 600$."),
               (r"Rs. $550$", r"Raises last year's coffee price by $10\%$ instead of lowering it.")],
  check=_c32, values=[450, 500, 720, 550], cognitive="Application")


def _c33():
    c, l = symbols('c l')
    return _solve([Eq(6 * c + 4 * l, 3900), Eq(4 * c + 6 * l, 3900 - 300)], [c, l])[l]
q("C09-A-033", T, "Interchanged quantities with the bill difference given", "Medium",
  "Multi-step word problem",
  r"Sneha ordered $6$ cushions and $4$ lamps, for which the correct bill is Rs. $3{,}900$. By mistake the store billed her for $4$ cushions and $6$ lamps at the same prices, and this bill was Rs. $300$ less than the correct one. What is the price of one lamp?",
  "MCQ",
  r"Let a cushion cost $c$ and a lamp $l$: $6c + 4l = 3900$ and $4c + 6l = 3600$. Adding, $10(c + l) = 7500$, so $c + l = 750$; subtracting, $2(c - l) = 300$, so $c - l = 150$. Hence $l = \frac{750 - 150}{2} = 300$.",
  "Forgetting that the difference of the bills is twice the price difference.",
  "C09A-swapped-quantities", "Builds the second equation from the difference, then add and subtract.",
  correct=r"Rs. $300$",
  distractors=[(r"Rs. $450$", r"Solves correctly but reports the cushion price."),
               (r"Rs. $375$", r"Finds $c + l = 750$ and halves it, ignoring the difference."),
               (r"Rs. $225$", r"Takes $c - l = 300$ without halving: $l = \frac{750 - 300}{2}$.")],
  check=_c33, values=[300, 450, 375, 225], cognitive="Application")


def _c34():
    b, t = symbols('b t')
    v = _solve([Eq(120 * b + 200 * t, 64000), Eq(150 * (b + 20) + 180 * (t + 20), 76800)], [b, t])
    return (v[b] + 20) + (v[t] + 20)
q("C09-A-034", T, "Two days of ticket sales with a flat price rise; combined new price", "Medium",
  "Multi-step word problem",
  r"A theatre sells balcony and stalls tickets. On Friday it sold $120$ balcony and $200$ stalls tickets and collected Rs. $64{,}000$. On Saturday the price of each kind of ticket was raised by Rs. $20$, and it sold $150$ balcony and $180$ stalls tickets, collecting Rs. $76{,}800$. What is Saturday's price of one balcony ticket and one stalls ticket together?",
  "MCQ",
  r"Let Friday's prices be $b$ and $t$. The rise accounts for $20 \times 330 = 6600$ of Saturday's takings, so $150b + 180t = 70200$, that is $5b + 6t = 2340$. Friday gives $3b + 5t = 1600$. Then $15b + 18t = 7020$ and $15b + 25t = 8000$, so $7t = 980$, $t = 140$ and $b = 300$. Saturday's prices are $320$ and $160$, totalling $480$.",
  "Reporting Friday's prices, or adding the Rs. $20$ rise only once to the pair.",
  "C09A-price-revision-two-days", "Removing the effect of the rise before eliminating; then one more step to the new prices.",
  correct=r"Rs. $480$",
  distractors=[(r"Rs. $440$", r"Solves correctly but adds Friday's prices, $300 + 140$."),
               (r"Rs. $460$", r"Adds the Rs. $20$ rise to the pair only once: $440 + 20$."),
               (r"Rs. $320$", r"Reports Saturday's balcony price alone.")],
  check=_c34, values=[480, 440, 460, 320], cognitive="Application")


# ================================================================ DIFFICULT (11)

def _c35():
    x, y, z, k, m = symbols('x y z k m')
    M = Matrix([[1, 2, -1], [2, -1, 3], [3, 1, k]])
    ks = solve(M.det(), k)
    assert len(ks) == 1
    k0 = ks[0]
    # value of m that makes the singular system consistent
    ms = [mv for mv in range(-50, 51)
          if _kind([Eq(x + 2 * y - z, 3), Eq(2 * x - y + 3 * z, 4), Eq(3 * x + y + k0 * z, mv)], [x, y, z]) != 0]
    assert len(ms) == 1
    m0 = ms[0]
    assert _kind([Eq(x + 2 * y - z, 3), Eq(2 * x - y + 3 * z, 4), Eq(3 * x + y + k0 * z, m0)], [x, y, z]) == 2
    assert _kind([Eq(x + 2 * y - z, 3), Eq(2 * x - y + 3 * z, 4), Eq(3 * x + y + (k0 + 1) * z, m0 + 5)], [x, y, z]) == 1
    return (k0, m0, 0)
q("C09-A-035", T, "Three-variable system with two parameters: condition for no solution", "Difficult",
  "Inverse/parameter",
  r"Consider the system $x + 2y - z = 3$, $2x - y + 3z = 4$, $3x + y + kz = m$. The system has no solution exactly when",
  "MCQ",
  r"Adding the first two equations gives $3x + y + 2z = 7$. The left side of the third equation equals this when $k = 2$ (the determinant is $10 - 5k$, which is zero only then). For $k = 2$ the third equation is consistent with the others only if $m = 7$; if $m \neq 7$ it contradicts their sum, so there is no solution. For $k \neq 2$ the solution is unique, and for $k = 2$, $m = 7$ there are infinitely many.",
  "Stopping at the determinant condition without separating the consistent and inconsistent cases.",
  "C09A-three-var-param", "Requires spotting the dependency among the rows, then splitting on the constant.",
  correct=r"$k = 2$ and $m \neq 7$",
  distractors=[(r"$k = 2$ and $m = 7$", r"Finds the correct pair but this is the case of infinitely many solutions."),
               (r"$k \neq 2$", r"Reverses the logic: this is the case of a unique solution."),
               (r"$k = -2$ and $m \neq 7$", r"Sign slip in the determinant, $10 + 5k = 0$.")],
  check=_c35, values=[(2, 7, 0), (2, 7, 1), (0, 0, 2), (-2, 7, 0)], cognitive="Analysis", exams=CX)


def _c36():
    x, y, z, a, b = symbols('x y z a b')
    al, be = symbols('al be')
    s = _solve([Eq(al + 2 * be, 4), Eq(al + 3 * be, 5)], [al, be])
    av = s[al] * 1 + s[be] * (-1)
    bv = s[al] * 5 + s[be] * 4
    assert _kind([Eq(x + y + z, 5), Eq(2 * x + 3 * y - z, 4), Eq(4 * x + 5 * y + av * z, bv)], [x, y, z]) == 2
    assert _kind([Eq(x + y + z, 5), Eq(2 * x + 3 * y - z, 4), Eq(4 * x + 5 * y + av * z, bv + 1)], [x, y, z]) == 0
    assert _kind([Eq(x + y + z, 5), Eq(2 * x + 3 * y - z, 4), Eq(4 * x + 5 * y + (av + 1) * z, bv)], [x, y, z]) == 1
    return av + bv
q("C09-A-036", T, "Third equation forced to be a combination of the first two", "Difficult",
  "Inverse/parameter",
  r"The system $x + y + z = 5$, $2x + 3y - z = 4$, $4x + 5y + az = b$ has infinitely many solutions. Find the value of $a + b$.",
  "TITA",
  r"With infinitely many solutions (the first two equations being independent), the third must be a combination $\alpha(\text{first}) + \beta(\text{second})$. Matching $x$ and $y$: $\alpha + 2\beta = 4$ and $\alpha + 3\beta = 5$, so $\beta = 1$, $\alpha = 2$. Then $a = 2 \times 1 + 1 \times (-1) = 1$ and $b = 2 \times 5 + 4 = 14$, so $a + b = 15$.",
  "Trying to match the third equation to a single earlier equation, or forgetting the minus sign on $z$.",
  "C09A-three-var-param", "Needs the idea that a dependent equation is a linear combination of the others, then matching coefficients.",
  tita_answer=15, check=_c36,
  tita_traps=[(14, r"Finds $b = 14$ and types it as the answer."),
              (17, r"Ignores the minus sign on $z$: $a = 2 + 1 = 3$, so $a + b = 17$.")],
  cognitive="Analysis", exams=CX)


def _c37():
    rows = Matrix([[2, 3, 4], [3, 5, 7]])
    opts = [(1, 1, 1), (1, 0, 0), (0, 1, 1), (1, 2, 0)]
    ok = [i for i, v in enumerate(opts) if rows.col_join(Matrix([v])).rank() == rows.rank()]
    assert len(ok) == 1
    return ok[0]
q("C09-A-037", T, "Which combination of prices is fixed by two equations in three unknowns", "Difficult",
  "Conceptual/application",
  r"At a shop with fixed prices, $2$ pens, $3$ pencils and $4$ erasers cost Rs. $150$, and $3$ pens, $5$ pencils and $7$ erasers cost Rs. $235$. No other information is available. Which of the following can be found from this information alone?",
  "MCQ",
  r"A quantity $px + qy + rz$ can be found only if $(p, q, r) = \alpha(2, 3, 4) + \beta(3, 5, 7)$ for some $\alpha$, $\beta$. For $(1, 1, 1)$: $2\alpha + 3\beta = 1$ and $3\alpha + 5\beta = 1$ give $\alpha = 2$, $\beta = -1$, and the third coordinate $8 - 7 = 1$ matches; the total is $2 \times 150 - 235 = 65$. For $(1, 0, 0)$ the first two coordinates force $\alpha = 5$, $\beta = -3$, but then $20 - 21 = -1 \neq 0$; for $(0, 1, 1)$ they force $\alpha = -3$, $\beta = 2$ with $-12 + 14 = 2 \neq 1$; for $(1, 2, 0)$ they force $\alpha = -1$, $\beta = 1$ with $-4 + 7 = 3 \neq 0$.",
  "Thinking that a single price can be extracted from two equations, or that nothing at all can be found.",
  "C09A-add-equations-combination", "Needs the idea of linear combinations of equations and a test of each candidate.",
  correct=r"The total price of $1$ pen, $1$ pencil and $1$ eraser",
  distractors=[(r"The price of $1$ pen", r"Assumes subtracting suitable multiples always isolates one price."),
               (r"The total price of $1$ pencil and $1$ eraser", r"Matches the pencil coefficient but does not check the eraser coefficient."),
               (r"The total price of $1$ pen and $2$ pencils", r"Subtracts the first bill from the second, gets $1$ pen, $2$ pencils and $3$ erasers, and drops the erasers.")],
  check=_c37, values=[0, 1, 2, 3], cognitive="Analysis", exams=CX)


def _c38():
    a, b, c = symbols('a b c')
    s = _solve([Eq(20 * a - 5 * b - 5 * c, 65), Eq(18 * a - 10 * b - 2 * c, 50), Eq(25 * a - 2 * b - 3 * c, 93)], [a, b, c])
    return 22 * s[a] - 6 * s[b] - 2 * s[c]
q("C09-A-038", T, "Unknown marking scheme recovered from three candidates' results", "Difficult",
  "Multi-step word problem",
  r"In a $30$ question test, every correct answer earns $a$ marks, every wrong answer loses $b$ marks and every unattempted question loses $c$ marks, where $a$, $b$, $c$ are fixed. Hari had $20$ correct, $5$ wrong and $5$ unattempted and scored $65$. Lata had $18$ correct, $10$ wrong and $2$ unattempted and scored $50$. Neel had $25$ correct, $2$ wrong and $3$ unattempted and scored $93$. Ishaan had $22$ correct, $6$ wrong and $2$ unattempted. What was Ishaan's score, in marks?",
  "TITA",
  r"The equations are $20a - 5b - 5c = 65$, $18a - 10b - 2c = 50$, $25a - 2b - 3c = 93$. From the first, $4a - b - c = 13$, so $c = 4a - b - 13$. Substituting: $10a - 8b = 24$, that is $5a - 4b = 12$, and $13a + b = 54$. Then $b = 54 - 13a$ and $5a - 216 + 52a = 12$, so $a = 4$, $b = 2$, $c = 1$. Ishaan scored $88 - 12 - 2 = 74$.",
  "Ignoring the penalty for unattempted questions, or slips in the three-variable elimination.",
  "C09A-unknown-marking-scheme", "A full $3 \\times 3$ elimination with negative coefficients, then an evaluation.",
  tita_answer=74, check=_c38,
  tita_traps=[(88, r"Finds $a = 4$ and ignores both penalties."),
              (76, r"Forgets the penalty for the unattempted questions: $88 - 12$.")],
  cognitive="Application", exams=CX)


def _c39():
    x, y, z = symbols('x y z', positive=True)
    s = solve([Eq(5 * x * y, 6 * (x + y)), Eq(y * z, 2 * (y + z)), Eq(2 * z * x, 3 * (z + x))], [x, y, z], dict=True)
    s = [d for d in s if all(v.is_positive for v in d.values())]
    assert len(s) == 1
    return s[0][x] + s[0][y] + s[0][z]
q("C09-A-039", T, "Product-over-sum conditions turned into a linear system in reciprocals", "Difficult",
  "Conceptual/application",
  r"Positive real numbers $x$, $y$, $z$ satisfy $5xy = 6(x + y)$, $yz = 2(y + z)$ and $2zx = 3(z + x)$. What is the value of $x + y + z$?",
  "TITA",
  r"Divide each equation by the product: $\frac{1}{x} + \frac{1}{y} = \frac{5}{6}$, $\frac{1}{y} + \frac{1}{z} = \frac{1}{2}$, $\frac{1}{z} + \frac{1}{x} = \frac{2}{3}$. Adding, $2\left(\frac{1}{x} + \frac{1}{y} + \frac{1}{z}\right) = 2$, so the sum of reciprocals is $1$. Then $\frac{1}{z} = 1 - \frac{5}{6} = \frac{1}{6}$, $\frac{1}{x} = 1 - \frac{1}{2} = \frac{1}{2}$, $\frac{1}{y} = 1 - \frac{2}{3} = \frac{1}{3}$. So $x + y + z = 2 + 3 + 6 = 11$.",
  "Treating the equations as nonlinear and getting lost, or forgetting to invert at the end.",
  "C09A-reciprocal-substitution", "Needs the reciprocal substitution, then the pairwise-sum trick, then inversion.",
  tita_answer=11, check=_c39,
  tita_traps=[(1, r"Stops at the sum of the reciprocals."),
              (6, r"Reports only $z = 6$, the value found first.")],
  cognitive="Analysis", exams=CX)


def _c40():
    p, n = symbols('p n')
    recs = [(2, 3, 145), (3, 2, 135), (5, 4, 249), (1, 1, 57)]
    answers = set()
    for bad in range(4):
        rest = [r for i, r in enumerate(recs) if i != bad]
        sol = solve([Eq(a * p + b * n, c) for a, b, c in rest], [p, n], dict=True)
        if sol:
            answers.add(sol[0][n])
    assert len(answers) == 1
    return answers.pop()
q("C09-A-040", T, "Four records of two prices with exactly one record wrong", "Difficult",
  "Casework/optimisation",
  r"A shopkeeper's ledger has four records of purchases of pens and notebooks at fixed prices: (i) $2$ pens and $3$ notebooks for Rs. $145$; (ii) $3$ pens and $2$ notebooks for Rs. $135$; (iii) $5$ pens and $4$ notebooks for Rs. $249$; (iv) $1$ pen and $1$ notebook for Rs. $57$. Exactly one of the four records is wrong. What is the price of one notebook?",
  "MCQ",
  r"Records (i) and (ii) give $5(p + n) = 280$ and $p - n = -10$, so $p = 23$, $n = 33$; but then (iv) would read $56$, not $57$, so one of (i), (ii) is wrong and (iii), (iv) are right. From (iii) and (iv): $p = 249 - 4 \times 57 = 21$ and $n = 36$. These fit (ii), since $63 + 72 = 135$, but not (i), since $42 + 108 = 150 \neq 145$. So (i) is the wrong record; trusting any set of three that includes (i) leads to a contradiction. A notebook costs Rs. $36$.",
  "Solving the first pair of records and accepting the result without testing the remaining records.",
  "C09A-faulty-record", "Casework over which record is faulty with a consistency test in each case.",
  correct=r"Rs. $36$",
  distractors=[(r"Rs. $33$", r"Trusts records (i) and (ii), the first pair, and does not test the others: $p = 23$, $n = 33$."),
               (r"Rs. $31$", r"Trusts records (i) and (iv): $2 \times 57 + n = 145$ gives $n = 31$, $p = 26$."),
               (r"Rs. $21$", r"Identifies the wrong record but reports the price of a pen.")],
  check=_c40, values=[36, 33, 31, 21], cognitive="Analysis", exams=CX)


def _c41():
    x, y = symbols('x y')
    cnt = 0
    for k in range(-10, 11):
        s = solve([Eq(k * x + 2 * y, 8), Eq(3 * x + y, 6)], [x, y], dict=True)
        if len(s) == 1 and s[0][x] > 0 and s[0][y] > 0:
            cnt += 1
    return cnt
q("C09-A-041", T, "Counting parameter values that give a solution in the first quadrant", "Difficult",
  "Casework/optimisation",
  r"For how many integers $k$ with $-10 \le k \le 10$ does the system $kx + 2y = 8$, $3x + y = 6$ have a unique solution in which both $x$ and $y$ are positive?",
  "TITA",
  r"From the second equation $y = 6 - 3x$; substituting, $kx + 12 - 6x = 8$, so $x = \frac{4}{6 - k}$ (for $k \neq 6$) and $y = 6 - \frac{12}{6 - k} = \frac{24 - 6k}{6 - k}$. $x > 0$ needs $k < 6$; then $y > 0$ needs $24 - 6k > 0$, that is $k < 4$. So $k = -10, -9, \ldots, 3$: $14$ values.",
  "Including the boundary value where $y = 0$, or counting every $k$ that gives a unique solution.",
  "C09A-param-positive-solution", "Solve in terms of $k$, then two sign conditions and a careful count of integers.",
  tita_answer=14, check=_c41,
  tita_traps=[(15, r"Includes $k = 4$, where $y = 0$."),
              (20, r"Counts every $k$ except $6$, that is every $k$ with a unique solution."),
              (16, r"Uses only $x > 0$ and stops at $k \le 5$.")],
  cognitive="Analysis", exams=CX)


def _c42():
    a, c, s = symbols('a c s')
    v = _solve([Eq(3 * a + 2 * c + s, 1250), Eq(2 * a + 3 * c + 2 * s, 1350), Eq(a + c + 3 * s, 1000)], [a, c, s])
    return v[a] + 2 * v[c] + v[s]
q("C09-A-042", T, "Three ticket prices from three group bookings; price of a new group", "Difficult",
  "Multi-step word problem",
  r"A museum has fixed ticket prices for adults, children and seniors. A group of $3$ adults, $2$ children and $1$ senior paid Rs. $1{,}250$; a group of $2$ adults, $3$ children and $2$ seniors paid Rs. $1{,}350$; and a group of $1$ adult, $1$ child and $3$ seniors paid Rs. $1{,}000$. How much will a group of $1$ adult, $2$ children and $1$ senior pay?",
  "MCQ",
  r"Adding the three groups gives $6$ of each ticket for $3600$, so one adult, one child and one senior cost $600$. The second group is two of each plus one extra child, so a child's ticket costs $1350 - 1200 = 150$. The required group is one of each plus one child: $600 + 150 = 750$. (The full solution is adult $250$, child $150$, senior $200$.)",
  "Adding the wrong extra ticket after finding the cost of one of each.",
  "C09A-sum-all-three", "A $3 \\times 3$ system whose fast route needs two combinations to be spotted.",
  correct=r"Rs. $750$",
  distractors=[(r"Rs. $600$", r"Stops at the cost of one ticket of each kind."),
               (r"Rs. $800$", r"Adds a senior's ticket ($200$) to $600$ instead of a child's."),
               (r"Rs. $850$", r"Adds an adult's ticket ($250$) to $600$ instead of a child's.")],
  check=_c42, values=[750, 600, 800, 850], cognitive="Analysis", exams=CX)


def _c43():
    k = symbols('k')
    x, y, z = symbols('x y z')
    M = Matrix([[k, 1, 1], [1, k, 1], [1, 1, k]])
    roots = solve(M.det(), k)
    bad = [r for r in set(roots)
           if _kind([Eq(r * x + y + z, 1), Eq(x + r * y + z, 1), Eq(x + y + r * z, 4)], [x, y, z]) == 0]
    return FiniteSet(*bad)
q("C09-A-043", T, "Symmetric three-variable system: which singular values give no solution", "Difficult",
  "Casework/optimisation",
  r"For which value or values of $k$ does the system $kx + y + z = 1$, $x + ky + z = 1$, $x + y + kz = 4$ have no solution?",
  "MCQ",
  r"The determinant is $(k - 1)^2(k + 2)$, so a unique solution exists unless $k = 1$ or $k = -2$. For $k = 1$ the equations read $x + y + z = 1$ and $x + y + z = 4$: inconsistent. For $k = -2$, adding all three gives $0 = 6$: inconsistent. So there is no solution for both $k = 1$ and $k = -2$.",
  "Assuming, as in the version with equal right sides, that $k = 1$ makes the equations identical.",
  "C09A-three-var-param", "Needs the determinant and a separate check of each singular value against unequal constants.",
  correct=r"$k = 1$ and $k = -2$",
  distractors=[(r"$k = -2$ only", r"Assumes $k = 1$ makes all three equations the same plane and so gives infinitely many solutions."),
               (r"$k = 1$ only", r"Checks $k = 1$ but misses the root $k = -2$ of the determinant."),
               (r"$k = -1$ and $k = 2$", r"Sign slip in the factors: writes the determinant as $(k + 1)^2(k - 2)$.")],
  check=_c43, values=[FiniteSet(1, -2), FiniteSet(-2), FiniteSet(1), FiniteSet(-1, 2)], cognitive="Analysis", exams=CX)


def _c44():
    k = symbols('k')
    x, y = symbols('x y')
    good = []
    # generic case: solve the first two, impose the third
    s = solve([Eq(x + k * y, 2), Eq(k * x + y, 2)], [x, y], dict=True)[0]
    for r in solve(Eq(s[x] + s[y], 2 * k), k):
        good.append(r)
    # special values where the first two are not independent
    for r in solve(Eq(1 - k * k, 0), k):
        sol = linsolve([Eq(x + r * y, 2), Eq(r * x + y, 2), Eq(x + y, 2 * r)], [x, y])
        if sol != S.EmptySet:
            good.append(r)
    return FiniteSet(*good)
q("C09-A-044", T, "Values of a parameter for which three lines have a common point", "Difficult",
  "Casework/optimisation",
  r"For which values of $k$ do the three equations $x + ky = 2$, $kx + y = 2$ and $x + y = 2k$ have at least one common solution?",
  "MCQ",
  r"Subtracting the first two, $(1 - k)(x - y) = 0$. If $k \neq 1$ then $x = y$, so $x(1 + k) = 2$; for $k \neq -1$, $x = y = \frac{2}{1 + k}$ and the third gives $\frac{4}{1 + k} = 2k$, so $k^2 + k - 2 = 0$, $k = -2$ (as $k \neq 1$ here). For $k = -1$ the first two equations become $x - y = 2$ and $x - y = -2$, which is impossible. For $k = 1$ all three equations are $x + y = 2$, so every point on that line works. Hence $k = 1$ and $k = -2$.",
  "Dividing by $1 - k$ and losing the case $k = 1$.",
  "C09A-three-lines-two-unknowns", "Casework on the parameter, including the cases lost by division.",
  correct=r"$k = 1$ and $k = -2$",
  distractors=[(r"$k = -2$ only", r"Divides by $1 - k$ and so never examines $k = 1$."),
               (r"$k = 1$ only", r"Notices that $k = 1$ makes the equations identical and stops."),
               (r"$k = -1$ and $k = 2$", r"Solves $k^2 + k - 2 = 0$ with the signs reversed.")],
  check=_c44, values=[FiniteSet(1, -2), FiniteSet(-2), FiniteSet(1), FiniteSet(-1, 2)], cognitive="Analysis", exams=CX)


def _c45():
    x, y, z = symbols('x y z')
    sol = linsolve([Eq(x + y + z, 500), Eq(100 * x + 200 * y + 400 * z, 100000)], [x, y, z])
    (X, Y, Z) = list(sol)[0]
    exprs = [X - 2 * Z, Y - 2 * Z, X - Y, X - Z]
    ok = [i for i, e in enumerate(exprs) if simplify(e) == 0]
    assert len(ok) == 1
    return ok[0]
q("C09-A-045", T, "Relation that must hold although the individual counts are not determined", "Difficult",
  "Conceptual/application",
  r"A theatre sold $500$ tickets in three classes priced at Rs. $100$, Rs. $200$ and Rs. $400$, collecting Rs. $1{,}00{,}000$ in all. Let $x$, $y$ and $z$ be the numbers of Rs. $100$, Rs. $200$ and Rs. $400$ tickets sold. Which of the following must be true?",
  "MCQ",
  r"We have $x + y + z = 500$ and, dividing the collection by $100$, $x + 2y + 4z = 1000$. Subtracting, $y + 3z = 500$, so $y = 500 - 3z$ and $x = 500 - y - z = 2z$. Thus $x = 2z$ always, while $y = 2z$ and $x = y$ hold only when $z = 100$, and $x = z$ only when $z = 0$.",
  "Assuming two equations in three unknowns give no definite relation at all, or testing a single sample split.",
  "C09A-determinable-combination", "The individual counts are not fixed; the candidate must eliminate the right unknown to find the invariant.",
  correct=r"$x = 2z$",
  distractors=[(r"$y = 2z$", r"Tests the single split $z = 100$, $y = 200$, $x = 200$, where this happens to hold."),
               (r"$x = y$", r"Tests the same split $x = y = 200$ and generalises it."),
               (r"$x = z$", r"Slip in subtracting: writes $4z - z = 2z$, so $y + 2z = 500$ and then $x = 500 - y - z = z$.")],
  check=_c45, values=[0, 1, 2, 3], cognitive="Analysis", exams=CX)
