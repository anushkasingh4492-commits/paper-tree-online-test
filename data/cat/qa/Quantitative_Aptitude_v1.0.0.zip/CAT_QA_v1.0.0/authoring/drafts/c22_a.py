import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Remainders"
TWO = ("CAT", "XAT")


def _single(s):
    s = set(s)
    assert len(s) == 1, s
    return s.pop()


# ---------------------------------------------------------------- EASY

def _c1():
    return _single((n * m) % 9 for n in range(7, 300, 9) for m in range(5, 300, 9))
q("C22-A-001", T, "Remainder of a product from the remainders of its factors", "Easy",
  "Single-step computation",
  r"When a positive integer $N$ is divided by $9$, the remainder is $7$. When another positive integer $M$ is divided by $9$, the remainder is $5$. What is the remainder when the product $NM$ is divided by $9$?",
  "MCQ",
  r"Write $N = 9a + 7$ and $M = 9b + 5$. Every term of the product except $7 \times 5$ is a multiple of $9$, so $NM$ leaves the same remainder as $35$. Since $35 = 3 \times 9 + 8$, the remainder is $8$.",
  "Combining the remainders by addition or subtraction, or reducing the product modulo 10 instead of 9.",
  "C22A-product-of-remainders", "One idea: multiply the remainders and reduce once.",
  correct=r"$8$",
  distractors=[(r"$3$", r"Adds the remainders: $7 + 5 = 12$, which leaves $3$ on division by $9$."),
               (r"$2$", r"Subtracts the remainders: $7 - 5 = 2$."),
               (r"$5$", r"Multiplies the remainders to get $35$ but reports its units digit, effectively dividing by $10$.")],
  check=_c1, values=[8, 3, 2, 5], cognitive="Understanding")


def _c2():
    return _single(n % 8 for n in range(45, 5000, 56))
q("C22-A-002", T, "Remainder by a factor of the original divisor", "Easy",
  "Single-step computation",
  r"Priya picks a positive integer which, when divided by $56$, leaves a remainder of $45$. What is the remainder when the same integer is divided by $8$?",
  "TITA",
  r"The integer is $56k + 45$. Since $8$ divides $56$, the term $56k$ leaves no remainder, so the answer is the remainder of $45$ on division by $8$. As $45 = 5 \times 8 + 5$, the remainder is $5$.",
  "Dividing the old remainder by the wrong factor of 56, or reporting the old remainder unchanged.",
  "C22A-divisor-of-divisor", "One step once the student sees that 8 divides 56.",
  tita_answer=5, check=_c2,
  tita_traps=[(3, r"Divides $45$ by $7$ (the other factor of $56$): $45 = 6 \times 7 + 3$."),
              (45, r"Reports the remainder for $56$ without reducing it modulo $8$.")],
  cognitive="Understanding")


def _c3():
    return pow(5, 43, 13)
q("C22-A-003", T, "Cyclic remainders of powers of 5 modulo 13", "Easy",
  "Single-step computation",
  r"What is the remainder when $5^{43}$ is divided by $13$?",
  "MCQ",
  r"The remainders of $5^1, 5^2, 5^3, 5^4$ on division by $13$ are $5, 12, 8, 1$ (since $25 = 13 + 12$, $5 \times 12 = 60 = 52 + 8$, $5 \times 8 = 40 = 39 + 1$). The pattern repeats every $4$ powers. As $43 = 4 \times 10 + 3$, $5^{43}$ leaves the same remainder as $5^3$, which is $8$.",
  "Picking the wrong position in the cycle, or assuming a cycle length that belongs to a different divisor.",
  "C22A-cyclic-power-remainders", "List a cycle of length 4 and index into it once.",
  correct=r"$8$",
  distractors=[(r"$12$", r"Off by one in the cycle: takes the second term $5^2$ instead of the third."),
               (r"$1$", r"Off by one the other way: takes the fourth term, as if $43$ were a multiple of $4$."),
               (r"$5$", r"Assumes a cycle of length $6$ (as for powers of $5$ modulo $7$); $43 = 6 \times 7 + 1$ gives $5^1 = 5$.")],
  check=_c3, values=[8, 12, 1, 5], cognitive="Application")


def _c4():
    out = set()
    for n in range(1, 2000):
        if n % 4 == 3 and (n // 4) % 5 == 2:
            out.add(n % 20)
    return _single(out)
q("C22-A-004", T, "Successive division by 4 and 5, remainder by 20", "Easy",
  "Multi-step word problem",
  r"When a positive integer is divided by $4$, the remainder is $3$. When the quotient so obtained is divided by $5$, the remainder is $2$. What is the remainder when the original integer is divided by $20$?",
  "TITA",
  r"Let the first quotient be $q = 5k + 2$. Then the integer is $4q + 3 = 4(5k + 2) + 3 = 20k + 11$. Hence the remainder on division by $20$ is $11$.",
  "Rebuilding the number in the wrong order, or adding the two remainders.",
  "C22A-successive-division", "Two-line reconstruction of the number from successive remainders.",
  tita_answer=11, check=_c4,
  tita_traps=[(17, r"Builds the number in the reverse order: $5(4k + 3) + 2 = 20k + 17$."),
              (5, r"Adds the two remainders: $3 + 2 = 5$.")],
  cognitive="Application")


def _c5():
    out = set()
    for a in range(6, 200, 11):
        for b in range(8, 200, 11):
            for c in range(9, 200, 11):
                out.add((a + b + c) % 11)
    return _single(out)
q("C22-A-005", T, "Remainder of a pooled total from the individual remainders", "Easy",
  "Multi-step word problem",
  r"Ravi, Meera and Kabir each count their own marbles in groups of $11$, making as many full groups as possible. Ravi has $6$ marbles left over, Meera has $8$ left over and Kabir has $9$ left over. They now put all their marbles together and again make as many full groups of $11$ as possible. How many marbles are left over?",
  "MCQ",
  r"Each person's count is a multiple of $11$ plus the leftover, so the total is a multiple of $11$ plus $6 + 8 + 9 = 23$. The leftovers themselves form $2$ more full groups, since $23 = 2 \times 11 + 1$. So exactly $1$ marble is left over.",
  "Multiplying the remainders, confusing the quotient with the remainder, or computing how many more are needed to complete a group.",
  "C22A-sum-of-remainders", "One idea: add the remainders and reduce once.",
  correct=r"$1$",
  distractors=[(r"$3$", r"Multiplies the remainders instead of adding them: $6 \times 8 \times 9 = 432 = 39 \times 11 + 3$."),
               (r"$2$", r"Adds the leftovers to get $23 = 2 \times 11 + 1$ and reports the number of extra groups $2$ instead of the remainder."),
               (r"$10$", r"Finds how many more marbles would complete the next group: $33 - 23 = 10$.")],
  check=_c5, values=[1, 3, 2, 10], cognitive="Understanding")


def _c6():
    seat = 1
    for _ in range(100):
        seat += 5
        if seat > 12:
            seat -= 12
    return seat
q("C22-A-006", T, "Position after repeated equal steps around a circle", "Easy",
  "Conceptual/application",
  r"Twelve friends sit around a round table in seats numbered $1$ to $12$ in clockwise order. A ball starts with the friend in seat $1$. Each pass sends the ball $5$ seats clockwise, so the first pass takes it to seat $6$. After exactly $100$ passes, which seat number holds the ball?",
  "MCQ",
  r"After $100$ passes the ball has moved $100 \times 5 = 500$ seats clockwise from seat $1$. Only the remainder on division by $12$ matters: $500 = 41 \times 12 + 8$. Moving $8$ seats on from seat $1$ gives seat $9$.",
  "Forgetting the starting seat, reducing the number of passes instead of the distance moved, or an off-by-one in the number of passes.",
  "C22A-cyclic-position", "One reduction modulo 12 with a starting-point offset.",
  correct=r"Seat $9$",
  distractors=[(r"Seat $8$", r"Takes the remainder $8$ of $500$ as the seat number, forgetting that the ball started at seat $1$, not seat $0$."),
               (r"Seat $5$", r"Reduces the number of passes instead of the distance: $100 = 8 \times 12 + 4$, then $1 + 4 = 5$."),
               (r"Seat $4$", r"Counts $99$ moves instead of $100$: $99 \times 5 = 495 = 41 \times 12 + 3$, then $1 + 3 = 4$.")],
  check=_c6, values=[9, 8, 5, 4], cognitive="Understanding")


def _c7():
    pencils = 13 * 18 + 11
    left = pencils
    while left >= 17:
        left -= 17
    return left
q("C22-A-007", T, "Rebuilding the dividend to change the divisor", "Easy",
  "Single-step computation",
  r"Fatima packs pencils into boxes of $13$. She fills exactly $18$ boxes and has $11$ pencils left over. She then unpacks everything and repacks the same pencils into boxes of $17$, filling as many boxes as possible. How many pencils are left over now?",
  "TITA",
  r"The number of pencils is $13 \times 18 + 11 = 234 + 11 = 245$. Since $17 \times 14 = 238$, repacking in boxes of $17$ leaves $245 - 238 = 7$ pencils.",
  "Carrying the old remainder over to the new divisor, or reporting the number of full boxes.",
  "C22A-rebuild-dividend", "One reconstruction of the dividend and one division.",
  tita_answer=7, check=_c7,
  tita_traps=[(11, r"Assumes the leftover does not change when the box size changes."),
              (14, r"Reports the number of full boxes of $17$ instead of the pencils left over.")],
  cognitive="Application")


def _c8():
    return (pow(26, 19, 9) + 19) % 9
q("C22-A-008", T, "Base one less than a multiple of the divisor", "Easy",
  "Single-step computation",
  r"What is the remainder when $26^{19} + 19$ is divided by $9$?",
  "MCQ",
  r"Since $26 = 27 - 1$, $26$ leaves remainder $-1$ on division by $9$, so $26^{19}$ behaves like $(-1)^{19} = -1$. Also $19 = 18 + 1$ behaves like $1$. The sum behaves like $-1 + 1 = 0$, so $26^{19} + 19$ is divisible by $9$ and the remainder is $0$.",
  "Mishandling the sign of an odd power of a negative remainder.",
  "C22A-binomial-near-multiple", "Single idea: write the base as a multiple of 9 minus 1.",
  correct=r"$0$",
  distractors=[(r"$2$", r"Treats $(-1)^{19}$ as $+1$, so gets $1 + 1 = 2$."),
               (r"$8$", r"Finds $26^{19}$ leaves $8$ but leaves out the $+19$ term."),
               (r"$7$", r"Replaces $26^{19}$ by its units digit $6$, then $6 + 19 = 25$ leaves $7$.")],
  check=_c8, values=[0, 2, 8, 7], cognitive="Application")


def _c9():
    return sum(1 for n in range(100, 301) if n % 7 == 4)
q("C22-A-009", T, "Counting integers in a range with a given remainder", "Easy",
  "Single-step computation",
  r"How many integers from $100$ to $300$ (both inclusive) leave a remainder of $4$ when divided by $7$?",
  "TITA",
  r"The integers are of the form $7k + 4$. The smallest in range is $102 = 7 \times 14 + 4$ and the largest is $298 = 7 \times 42 + 4$. So $k$ runs from $14$ to $42$, giving $42 - 14 + 1 = 29$ integers.",
  "Off-by-one in counting the terms of an arithmetic progression.",
  "C22A-count-with-given-remainder", "Single AP count with one off-by-one trap.",
  tita_answer=29, check=_c9,
  tita_traps=[(28, r"Computes $(298 - 102) \div 7 = 28$ and forgets to add $1$ for the first term.")],
  cognitive="Application")


def _c10():
    return _single((n * n + 3 * n + 1) % 7 for n in range(4, 500, 7))
q("C22-A-010", T, "Remainder of a quadratic expression in N", "Easy",
  "Single-step computation",
  r"A positive integer $N$ leaves a remainder of $4$ when divided by $7$. What is the remainder when $N^2 + 3N + 1$ is divided by $7$?",
  "MCQ",
  r"Replace $N$ by its remainder $4$: $4^2 + 3 \times 4 + 1 = 16 + 12 + 1 = 29$. Since $29 = 4 \times 7 + 1$, the remainder is $1$.",
  "Dropping a term or treating the square as a doubling.",
  "C22A-polynomial-in-N", "Direct substitution of the remainder into a short expression.",
  correct=r"$1$",
  distractors=[(r"$3$", r"Drops the $3N$ term: $16 + 1 = 17$ leaves $3$."),
               (r"$6$", r"Drops the $N^2$ term: $12 + 1 = 13$ leaves $6$."),
               (r"$0$", r"Treats $N^2$ as $2N$: $8 + 12 + 1 = 21$ leaves $0$.")],
  check=_c10, values=[1, 3, 6, 0], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM

def _c11():
    return _single((n ** 3 + 2 * n) % 13 for n in range(11, 600, 13))
q("C22-A-011", T, "Cubic expression in N using a negative remainder", "Medium",
  "Multi-step word problem",
  r"A positive integer $N$ leaves a remainder of $11$ when divided by $13$. What is the remainder when $N^3 + 2N$ is divided by $13$?",
  "TITA",
  r"A remainder of $11$ is the same as $-2$ modulo $13$. Then $N^3 + 2N$ behaves like $(-2)^3 + 2(-2) = -8 - 4 = -12$, and $-12 + 13 = 1$. So the remainder is $1$.",
  "Leaving a negative result unconverted, or forgetting a term.",
  "C22A-polynomial-in-N", "Needs the negative-remainder trick and a sign conversion at the end.",
  tita_answer=1, check=_c11,
  tita_traps=[(12, r"Reaches $-12$ and reports $12$, dropping the sign instead of adding $13$."),
              (5, r"Computes only $N^3$: $11^3 = 1331$ leaves $5$, and forgets the $2N$ term.")],
  cognitive="Application")


def _c12():
    return (pow(2, 100, 7) + pow(3, 100, 7)) % 7
q("C22-A-012", T, "Sum of two powers with different cycle lengths modulo 7", "Medium",
  "Multi-step word problem",
  r"What is the remainder when $2^{100} + 3^{100}$ is divided by $7$?",
  "MCQ",
  r"Powers of $2$ leave $2, 4, 1$ on division by $7$ (cycle $3$); $100 = 3 \times 33 + 1$, so $2^{100}$ leaves $2$. Powers of $3$ leave $3, 2, 6, 4, 5, 1$ (cycle $6$); $100 = 6 \times 16 + 4$, so $3^{100}$ leaves $4$. The sum leaves $2 + 4 = 6$.",
  "Using one cycle length for both bases, or indexing the longer cycle off by one.",
  "C22A-cyclic-power-remainders", "Two different cycles must be found and indexed separately.",
  correct=r"$6$",
  distractors=[(r"$1$", r"Off by one in the cycle of $3$: takes $3^3$, which leaves $6$, so $2 + 6 = 8$ leaves $1$."),
               (r"$5$", r"Uses the cycle length $3$ of base $2$ for base $3$ too: $3^{100}$ treated as $3^1$, so $2 + 3 = 5$."),
               (r"$2$", r"Adds the bases first and works out $5^{100}$: cycle $5, 4, 6, 2, 3, 1$, position $4$ gives $2$.")],
  check=_c12, values=[6, 1, 5, 2], cognitive="Application")


def _c13():
    out = set()
    for n in range(1, 5000):
        if n % 6 == 4 and (n // 6) % 7 == 5:
            out.add(10 * (n % 7) + (n // 7) % 6)
    return _single(out)
q("C22-A-013", T, "Successive division with the order of divisors reversed", "Medium",
  "Multi-step word problem",
  r"When a positive integer is divided by $6$, the remainder is $4$; when the quotient so obtained is divided by $7$, the remainder is $5$. If instead the same integer is divided by $7$ and the resulting quotient is then divided by $6$, what are the two remainders, in that order?",
  "MCQ",
  r"The integer is $6(7k + 5) + 4 = 42k + 34$. Now $42k + 34 = 7(6k + 4) + 6$, so the first remainder is $6$ and the quotient is $6k + 4$. Dividing $6k + 4$ by $6$ leaves $4$. The remainders are $6$ and $4$.",
  "Assuming the remainders simply swap or stay the same when the order of division is reversed.",
  "C22A-successive-division", "Must rebuild the number and redo the division; the obvious guesses fail.",
  correct=r"$6$ and $4$",
  distractors=[(r"$5$ and $4$", r"Assumes the two remainders just swap places when the divisors swap."),
               (r"$4$ and $5$", r"Assumes the remainders stay the same whatever the order of division."),
               (r"$1$ and $4$", r"Builds the number in the wrong order as $6 \times 4 + 5 = 29$, which gives $29 = 7 \times 4 + 1$ and then $4$.")],
  check=_c13, values=[64, 54, 45, 14], cognitive="Analysis")


def _c14():
    return sum(1 for n in range(1, 500) if n % 5 == 3 and n % 7 == 4)
q("C22-A-014", T, "Counting numbers satisfying two different remainder conditions", "Medium",
  "Multi-step word problem",
  r"How many positive integers less than $500$ leave a remainder of $3$ when divided by $5$ and a remainder of $4$ when divided by $7$?",
  "TITA",
  r"Numbers leaving $4$ on division by $7$ are $4, 11, 18, \ldots$; the first that also leaves $3$ on division by $5$ is $18$. All such numbers are $18 + 35k$ since the LCM is $35$. The largest below $500$ is $18 + 35 \times 13 = 473$, so $k = 0, 1, \ldots, 13$, giving $14$ numbers.",
  "Treating different remainders as if they were a common remainder, or an off-by-one in the count.",
  "C22A-two-different-remainders", "Find the first common value by listing, then count an AP.",
  tita_answer=14, check=_c14,
  tita_traps=[(13, r"Counts $(473 - 18) \div 35 = 13$ and forgets the first term."),
              (15, r"Writes the numbers as $35k + 3$, using one remainder as if it were common, and counts $3, 38, \ldots, 493$.")],
  cognitive="Application")


def _c15():
    ds = [d for d in range(38, 200) if (23 + 37) % d == 15]
    d = _single(ds)
    return (23 * 37) % d
q("C22-A-015", T, "Finding an unknown divisor from the remainder of a sum", "Medium",
  "Inverse/parameter",
  r"Two positive integers leave remainders $23$ and $37$ respectively when divided by the same positive integer $d$. Their sum leaves a remainder of $15$ when divided by $d$. What is the remainder when the product of the two integers is divided by $d$?",
  "MCQ",
  r"The sum leaves the same remainder as $23 + 37 = 60$, so $60 - 15 = 45$ is a multiple of $d$. As $d > 37$ (a remainder of $37$ occurs), $d = 45$. The product leaves the same remainder as $23 \times 37 = 851$, and $851 = 18 \times 45 + 41$. The remainder is $41$.",
  "Taking the divisor as the sum of the remainders, or assuming the product behaves like the sum.",
  "C22A-unknown-divisor", "Two stages: infer the divisor from a reduction, then use it for the product.",
  correct=r"$41$",
  distractors=[(r"$11$", r"Takes $d = 23 + 37 = 60$; then $851 = 14 \times 60 + 11$."),
               (r"$26$", r"Takes $d = 60 + 15 = 75$; then $851 = 11 \times 75 + 26$."),
               (r"$15$", r"Assumes the product leaves the same remainder as the sum.")],
  check=_c15, values=[41, 11, 26, 15], cognitive="Analysis", exams=TWO)


def _c16():
    return pow(7, 85, 48)
q("C22-A-016", T, "Power whose square is one more than the divisor", "Medium",
  "Single-step computation",
  r"What is the remainder when $7^{85}$ is divided by $48$?",
  "MCQ",
  r"Since $7^2 = 49 = 48 + 1$, every even power of $7$ leaves remainder $1$ on division by $48$. Write $7^{85} = (7^2)^{42} \times 7$; this leaves $1^{42} \times 7 = 7$. The remainder is $7$.",
  "Mishandling the leftover odd factor, or a sign slip.",
  "C22A-binomial-near-multiple", "Must spot $49 = 48 + 1$ and handle the odd exponent.",
  correct=r"$7$",
  distractors=[(r"$1$", r"Treats $7^{85}$ as an even power of $7$ and drops the leftover factor $7$."),
               (r"$47$", r"Treats $7$ itself as $-1$ modulo $48$, so $(-1)^{85} = -1$, that is $47$."),
               (r"$41$", r"Takes $(7^2)^{42}$ as $-1$ (a sign slip), getting $-7$, that is $48 - 7 = 41$.")],
  check=_c16, values=[7, 1, 47, 41], cognitive="Application")


def _c17():
    return sum(1 for n in range(1, 501) if n % 4 == n % 6 == n % 9)
q("C22-A-017", T, "Counting numbers with equal remainders for three divisors, remainder not given", "Difficult",
  "Casework/optimisation",
  r"For how many integers $n$ from $1$ to $500$ (both inclusive) are the three remainders obtained on dividing $n$ by $4$, by $6$ and by $9$ all equal to one another?",
  "TITA",
  r"Let the common remainder be $r$. A remainder on division by $4$ is at most $3$, so $r \in \{0, 1, 2, 3\}$. For each such $r$, $n - r$ is divisible by $4$, $6$ and $9$, hence by their LCM $36$, so $n = 36k + r$. Since $500 = 13 \times 36 + 32$: for $r = 0$ the values are $36, 72, \ldots, 468$ ($13$ of them, as $n = 0$ is excluded); for $r = 1, 2, 3$ the values run from $r$ to $468 + r$, giving $14$ each. Total $13 + 3 \times 14 = 55$.",
  "Letting the common remainder go up to the largest divisor, dropping the remainder 0 case, or counting n = 0.",
  "C22A-equal-remainders-count", "The remainder is unknown: bound it by the smallest divisor, convert to classes modulo the LCM, then count each class with boundary care.",
  tita_answer=55, check=_c17,
  tita_traps=[(125, r"Lets the common remainder run from $0$ to $8$ (bounded by the largest divisor $9$): $13 + 8 \times 14 = 125$."),
              (42, r"Ignores the case of remainder $0$ and counts only $r = 1, 2, 3$: $3 \times 14 = 42$."),
              (56, r"Gives every class, including $r = 0$, $14$ members, effectively counting $n = 0$.")],
  cognitive="Analysis", exams=TWO)


def _c18():
    return int("47" * 30) % 99
q("C22-A-018", T, "Repeated two-digit block divided by 99", "Medium",
  "Conceptual/application",
  r"The $60$-digit number $4747\ldots47$ is formed by writing the two-digit block $47$ thirty times in a row. What is the remainder when this number is divided by $99$?",
  "MCQ",
  r"Since $100$ leaves remainder $1$ on division by $99$, a number written in two-digit blocks leaves the same remainder as the sum of its blocks. Here that sum is $30 \times 47 = 1410$, and $1410 = 14 \times 99 + 24$. The remainder is $24$.",
  "Treating division by 99 like division by 9 or by 100.",
  "C22A-block-sum-mod-99", "Requires the insight that 100 leaves remainder 1 on division by 99.",
  correct=r"$24$",
  distractors=[(r"$47$", r"Uses only one block, as if the remainder of a repeated block were the block itself."),
               (r"$6$", r"Divides by $9$ instead of $99$: digit sum $30 \times 11 = 330$ leaves $6$."),
               (r"$10$", r"Finds the block sum $1410$ but then reduces it modulo $100$ instead of $99$.")],
  check=_c18, values=[24, 47, 6, 10], cognitive="Understanding")


def _c19():
    out = set()
    for n in range(1, 3000):
        q1 = n // 3
        q2 = q1 // 4
        if n % 3 == 2 and q1 % 4 == 1 and q2 % 5 == 4:
            out.add(n % 12)
    return _single(out)
q("C22-A-019", T, "Successive division by 3, 4, 5 and remainder by 12", "Medium",
  "Conceptual/application",
  r"A positive integer is divided by $3$, the quotient is divided by $4$, and that quotient is divided by $5$. The three remainders are $2$, $1$ and $4$ respectively. What is the remainder when the original integer is divided by $12$?",
  "MCQ",
  r"Only the first two steps matter for $12 = 3 \times 4$. If the first quotient is $4m + 1$, the integer is $3(4m + 1) + 2 = 12m + 5$. So the remainder on division by $12$ is $5$. (The full form $60k + 53$ agrees, since $53 = 4 \times 12 + 5$.)",
  "Adding the remainders or rebuilding the number in the wrong order.",
  "C22A-successive-division", "Insight that only the first two divisors matter; otherwise a three-level rebuild.",
  correct=r"$5$",
  distractors=[(r"$7$", r"Adds the three remainders: $2 + 1 + 4 = 7$."),
               (r"$1$", r"Rebuilds the number from the last divisor outward, $5(4(3k + 2) + 1) + 4 = 60k + 49$, and $49$ leaves $1$."),
               (r"$9$", r"Combines the first two remainders in the wrong order: $1 + 4 \times 2 = 9$.")],
  check=_c19, values=[5, 7, 1, 9], cognitive="Analysis")


def _c20():
    lo, hi = 1000, 9999
    best = max(n for n in range(lo, hi + 1) if n % 12 == 7 and n % 18 == 7 and n % 30 == 7)
    return best
q("C22-A-020", T, "Largest four-digit number with a common remainder", "Medium",
  "Multi-step word problem",
  r"What is the largest four-digit number that leaves a remainder of $7$ when divided by each of $12$, $18$ and $30$?",
  "MCQ",
  r"The LCM of $12$, $18$ and $30$ is $180$, so the number is $180k + 7$. Since $9999 = 55 \times 180 + 99$, the largest multiple of $180$ not exceeding $9999$ is $9900$, and $9900 + 7 = 9907$ is still four-digit. The answer is $9907$.",
  "Using a wrong LCM or subtracting the remainder.",
  "C22A-common-remainder-lcm", "LCM, a largest-multiple step and a boundary check.",
  correct=r"$9907$",
  distractors=[(r"$6487$", r"Uses the product $12 \times 18 \times 30 = 6480$ in place of the LCM, then adds $7$."),
               (r"$9893$", r"Subtracts the remainder from the multiple: $9900 - 7$."),
               (r"$9727$", r"Takes the LCM as $360$; the largest multiple of $360$ below $9999$ is $9720$, plus $7$.")],
  check=_c20, values=[9907, 6487, 9893, 9727], cognitive="Application")


def _c21():
    return sum(k ** 3 for k in range(1, 26)) % 7
q("C22-A-021", T, "Remainder of a sum of cubes using the closed form", "Medium",
  "Conceptual/application",
  r"What is the remainder when $1^3 + 2^3 + 3^3 + \cdots + 25^3$ is divided by $7$?",
  "MCQ",
  r"The sum equals $\left(\frac{25 \times 26}{2}\right)^2 = 325^2$. Since $325 = 46 \times 7 + 3$, the square leaves the same remainder as $3^2 = 9$, which is $2$. The remainder is $2$.",
  "Misremembering the sum-of-cubes formula as the plain triangular number, or dropping the halving.",
  "C22A-sum-of-cubes-formula", "Recognise the closed form, then reduce before squaring.",
  correct=r"$2$",
  distractors=[(r"$3$", r"Uses $\frac{n(n+1)}{2} = 325$ without squaring it."),
               (r"$6$", r"Uses $n(n+1) = 650$, with neither halving nor squaring; $650$ leaves $6$."),
               (r"$1$", r"Squares $n(n+1) = 650$ but forgets to halve it first; $6^2 = 36$ leaves $1$.")],
  check=_c21, values=[2, 3, 6, 1], cognitive="Application")


def _c22():
    out = set()
    for n in range(87, 391 * 40, 391):
        out.add((3 * n + 2) % 23)
    return _single(out)
q("C22-A-022", T, "Linear expression in N by a factor of the original divisor", "Medium",
  "Multi-step word problem",
  r"A positive integer $N$ leaves a remainder of $87$ when divided by $391$. What is the remainder when $3N + 2$ is divided by $23$?",
  "TITA",
  r"Note that $391 = 17 \times 23$, so $N = 391k + 87$ leaves the same remainder on division by $23$ as $87 = 3 \times 23 + 18$, namely $18$. Then $3N + 2$ behaves like $3 \times 18 + 2 = 56 = 2 \times 23 + 10$. The remainder is $10$.",
  "Not noticing that 23 divides 391, or not reducing the final value.",
  "C22A-divisor-of-divisor", "Must factorise 391 and then reduce a linear expression.",
  tita_answer=10, check=_c22,
  tita_traps=[(18, r"Finds the remainder of $N$ itself and forgets to form $3N + 2$."),
              (56, r"Computes $3 \times 18 + 2 = 56$ and does not reduce it modulo $23$."),
              (263, r"Forms $3 \times 87 + 2 = 263$ and stops, never dividing by $23$.")],
  cognitive="Application")


def _c23():
    return sum(1 for d in range(1, 200) if 90 % d == 6)
q("C22-A-023", T, "Number of divisors leaving a prescribed remainder", "Medium",
  "Inverse/parameter",
  r"For how many positive integers $d$ does $90$ leave a remainder of $6$ when divided by $d$?",
  "MCQ",
  r"We need $d$ to divide $90 - 6 = 84$ and also $d > 6$, because a remainder must be smaller than the divisor. The divisors of $84$ are $1, 2, 3, 4, 6, 7, 12, 14, 21, 28, 42, 84$; those greater than $6$ are $7, 12, 14, 21, 28, 42, 84$. So there are $7$ values.",
  "Forgetting that the divisor must exceed the remainder.",
  "C22A-divisors-giving-remainder", "Reverse the division, then apply the divisor-greater-than-remainder condition.",
  correct=r"$7$",
  distractors=[(r"$12$", r"Counts all divisors of $84$, ignoring that $d$ must exceed $6$."),
               (r"$8$", r"Allows $d = 6$ as well, writing the condition as $d \geq 6$."),
               (r"$6$", r"Excludes $d = 84$, thinking the divisor must be smaller than $90 - 6$.")],
  check=_c23, values=[7, 12, 8, 6], cognitive="Analysis")


def _c24():
    n = 1000
    while not (n % 8 == 5 and n % 10 == 7 and n % 12 == 9):
        n += 1
    return n
q("C22-A-024", T, "Smallest four-digit number with a constant shortfall", "Medium",
  "Multi-step word problem",
  r"What is the smallest four-digit number that leaves remainders $5$, $7$ and $9$ when divided by $8$, $10$ and $12$ respectively?",
  "MCQ",
  r"Each remainder is $3$ less than its divisor, so the number plus $3$ is a multiple of the LCM of $8$, $10$, $12$, which is $120$. The number is $120k - 3$. The smallest multiple of $120$ for which this is at least $1000$ is $1080$, giving $1077$.",
  "Adding the shortfall, or using the product of the divisors.",
  "C22A-constant-deficit-lcm", "Spot the constant shortfall, then handle a lower bound.",
  correct=r"$1077$",
  distractors=[(r"$1083$", r"Adds the shortfall: $1080 + 3$."),
               (r"$1917$", r"Uses the product $8 \times 10 \times 12 = 960$ in place of the LCM; the first suitable multiple is $1920$, minus $3$."),
               (r"$1085$", r"Treats $5$ as a common remainder and adds it to the multiple $1080$.")],
  check=_c24, values=[1077, 1083, 1917, 1085], cognitive="Application")


def _c25():
    best = 0
    for d in range(1, 101):
        left = 250
        while left >= d:
            left -= d
        best = max(best, left)
    return best
q("C22-A-025", T, "Largest possible remainder for a fixed dividend with a capped divisor", "Difficult",
  "Casework/optimisation",
  r"Meera has $250$ sweets. She chooses a whole number $d$ from $1$ to $100$, packs the sweets into boxes of exactly $d$ sweets each, filling as many boxes as possible, and keeps the sweets that are left over. What is the largest number of sweets she can keep?",
  "TITA",
  r"Since $d \leq 100$, at least $2$ boxes are filled. If exactly $2$ boxes are filled, then $3d > 250$, so $d \geq 84$, and the leftover $250 - 2d$ is largest at $d = 84$: $250 - 168 = 82$. If exactly $3$ boxes are filled, then $4d > 250$ forces $d \geq 63$, so the leftover $250 - 3d$ is at most $61$. If $4$ or more boxes are filled, then $d \leq 62$ and the leftover is smaller than $d$. The maximum is $82$.",
  "Assuming the largest leftover comes from the largest box size, or that it can reach d - 1 for the largest d.",
  "C22A-max-remainder-fixed-dividend", "Casework on the quotient band of the divisor; the obvious choices (largest divisor, or remainder d - 1) both fail.",
  tita_answer=82, check=_c25,
  tita_traps=[(99, r"Assumes the remainder can be one less than the largest allowed divisor $100$."),
              (50, r"Takes the largest box size $100$, which leaves $250 - 200 = 50$."),
              (124, r"Ignores the cap of $100$ and uses $d = 126$, leaving $124$.")],
  cognitive="Analysis", exams=TWO)


def _c26():
    return sum(3 ** k for k in range(1, 201)) % 13
q("C22-A-026", T, "Geometric sum of powers with a cyclic remainder pattern", "Medium",
  "Conceptual/application",
  r"What is the remainder when $3 + 3^2 + 3^3 + \cdots + 3^{200}$ is divided by $13$?",
  "MCQ",
  r"Powers of $3$ leave $3, 9, 1$ on division by $13$ (as $27 = 2 \times 13 + 1$), and each block of three consecutive powers leaves $3 + 9 + 1 = 13$, that is $0$. Now $200 = 3 \times 66 + 2$, so the first $198$ terms contribute $0$ and the last two terms $3^{199}$ and $3^{200}$ behave like $3$ and $9$. The remainder is $12$.",
  "Assuming the sum ends on a complete block, or keeping only one leftover term.",
  "C22A-geometric-sum-cyclic", "Insight that each full cycle sums to a multiple of 13, plus leftover terms.",
  correct=r"$12$",
  distractors=[(r"$0$", r"Assumes the $200$ terms split into complete blocks of three."),
               (r"$3$", r"Notes two leftover terms but keeps only $3^{199}$."),
               (r"$9$", r"Notes two leftover terms but keeps only $3^{200}$.")],
  check=_c26, values=[12, 0, 3, 9], cognitive="Analysis")


# ---------------------------------------------------------------- DIFFICULT

def _c27():
    return sum(math.factorial(k) for k in range(1, 101)) % 112
q("C22-A-027", T, "Remainder of a sum of factorials: locating the first vanishing term", "Difficult",
  "Conceptual/application",
  r"What is the remainder when $1! + 2! + 3! + \cdots + 100!$ is divided by $112$?",
  "MCQ",
  r"Since $112 = 2^4 \times 7$, a factorial is a multiple of $112$ only if it contains the factor $7$ and at least four factors of $2$. $6! = 720 = 2^4 \times 45$ has no factor $7$, but $7! = 5040 = 45 \times 112$, so every term from $7!$ on is a multiple of $112$. The remainder therefore comes from $1! + 2! + \cdots + 6! = 1 + 2 + 6 + 24 + 120 + 720 = 873$, and $873 = 7 \times 112 + 89$. The remainder is $89$.",
  "Cutting the sum off too early, by assuming a factorial larger than the divisor is a multiple of it.",
  "C22A-factorial-sum", "Must factorise the divisor and test which factorial first contains it; 6! is a strong trap because it exceeds 112 and contains 2^4.",
  correct=r"$89$",
  distractors=[(r"$41$", r"Assumes $6! = 720$ is already a multiple of $112$ (it contains $2^4$ but not $7$) and keeps only $1! + \cdots + 5! = 153 = 112 + 41$."),
               (r"$33$", r"Assumes every factorial larger than $112$, starting with $5! = 120$, is a multiple of $112$, keeping $1 + 2 + 6 + 24 = 33$."),
               (r"$9$", r"Reduces $873$ modulo $16$ only (the power of $2$ in $112$) and forgets the factor $7$: $873 = 54 \times 16 + 9$.")],
  check=_c27, values=[89, 41, 33, 9], cognitive="Analysis", exams=TWO)


def _c28():
    return _single(n for n in range(301, 400) if n % 4 == 3 and n % 5 == 4 and n % 7 == 2)
q("C22-A-028", T, "Mixed remainder conditions with a range constraint", "Medium",
  "Multi-step word problem",
  r"The number of students in a school is more than $300$ and less than $400$. When they stand in rows of $4$, $3$ students are left over; in rows of $5$, $4$ are left over; and in rows of $7$, $2$ are left over. How many students are there in the school?",
  "TITA",
  r"The first two conditions say the number is $1$ less than a multiple of $20$: $19, 39, 59, 79, \ldots$. Testing division by $7$: $19, 39, 59$ leave $5, 4, 3$, and $79 = 11 \times 7 + 2$ works. So the number is $79 + 140k$ (LCM of $20$ and $7$ is $140$): $79, 219, 359, 499$. The only one between $300$ and $400$ is $359$.",
  "Satisfying only the uniform-shortfall conditions and ignoring the third one.",
  "C22A-two-different-remainders", "Spot the uniform shortfall for two divisors, test one more condition by listing, then place the value in a range.",
  tita_answer=359, check=_c28,
  tita_traps=[(399, r"Uses only the rows of $4$ and $5$ (one less than a multiple of $20$) and picks the largest value below $400$."),
              (79, r"Finds the first number satisfying all three conditions and ignores the range $300$ to $400$.")],
  cognitive="Analysis")


def _c29():
    return int("".join(str(k) for k in range(10, 100))) % 99
q("C22-A-029", T, "Concatenation of all two-digit numbers divided by 99", "Difficult",
  "Conceptual/application",
  r"The number $N = 101112131415\ldots9899$ is formed by writing all the two-digit numbers from $10$ to $99$ in increasing order. What is the remainder when $N$ is divided by $99$?",
  "MCQ",
  r"As $100$ leaves remainder $1$ on division by $99$, $N$ leaves the same remainder as the sum of its two-digit blocks, which is $10 + 11 + \cdots + 99 = \frac{90 \times 109}{2} = 4905$. Since $4905 = 49 \times 99 + 54$, the remainder is $54$.",
  "Applying a digit-sum rule (valid for 9) to the divisor 99.",
  "C22A-block-sum-mod-99", "Needs the block-sum insight on a large concatenated number and an AP sum.",
  correct=r"$54$",
  distractors=[(r"$63$", r"Adds single digits instead of two-digit blocks: digit sum $450 + 405 = 855$, which leaves $63$ on division by $99$."),
               (r"$0$", r"Uses the digit sum $855$ and divides by $9$ instead of $99$, getting $0$."),
               (r"$5$", r"Finds the block sum $4905$ but reduces it modulo $100$ instead of $99$.")],
  check=_c29, values=[54, 63, 0, 5], cognitive="Analysis", exams=TWO)


def _c30():
    ds = [d for d in range(1, 500) if d > 19 and (3 * 19 - 7) % d == 0]
    # confirm by realising N and 3N for each d
    for d in ds:
        for n in range(19, 2000, d):
            assert n % d == 19 and (3 * n) % d == 7
    return sum(ds)
q("C22-A-030", T, "All divisors consistent with remainders of N and 3N", "Medium",
  "Inverse/parameter",
  r"A positive integer $N$ leaves a remainder of $19$ when divided by a positive integer $d$, and $3N$ leaves a remainder of $7$ when divided by the same $d$. What is the sum of all possible values of $d$?",
  "MCQ",
  r"$3N$ leaves the same remainder as $3 \times 19 = 57$, so $57 - 7 = 50$ must be a multiple of $d$. Also $d > 19$, since $19$ is a remainder. The divisors of $50$ are $1, 2, 5, 10, 25, 50$, and only $25$ and $50$ exceed $19$. Both work, so the sum is $25 + 50 = 75$.",
  "Missing a valid divisor, or ignoring that the divisor must exceed the remainder.",
  "C22A-divisors-giving-remainder", "Reduce to a multiple of d, list the divisors and apply the divisor-exceeds-remainder bound.",
  correct=r"$75$",
  distractors=[(r"$50$", r"Takes only the largest candidate $d = 50 = 57 - 7$ and misses $25$."),
               (r"$25$", r"Keeps only $25$, thinking $d = 50$ is too large."),
               (r"$93$", r"Adds all divisors of $50$, ignoring the condition $d > 19$.")],
  check=_c30, values=[75, 50, 25, 93], cognitive="Analysis", exams=TWO)


def _c31():
    total = 0
    for x in (-1, 1):
        total += sum(math.comb(37, k) * 20 ** k * x ** (37 - k) for k in range(38))
    assert total == 19 ** 37 + 21 ** 37
    return total % 400
q("C22-A-031", T, "Sum of odd powers of 20 - 1 and 20 + 1 modulo 400 via the second binomial term", "Difficult",
  "Conceptual/application",
  r"What is the remainder when $19^{37} + 21^{37}$ is divided by $400$? Type the remainder.",
  "TITA",
  r"Write $19 = 20 - 1$ and $21 = 20 + 1$. Expanding, $(20 + 1)^{37} + (20 - 1)^{37}$ keeps only the terms with an odd power of $20$, each doubled: $2\left[\binom{37}{1} \cdot 20 + \binom{37}{3} \cdot 20^3 + \cdots\right]$. Every term from $20^3$ on is a multiple of $400$ (as $20^2 = 400$), so the sum leaves the same remainder as $2 \times 37 \times 20 = 1480 = 3 \times 400 + 280$. The remainder is $280$.",
  "Stopping at divisibility by 19 + 21 = 40, or dropping the factor 2 when the two expansions are added.",
  "C22A-binomial-near-multiple", "Divisibility by 40 is immediate, but 400 needs the second-order binomial term and correct cancellation of the constant terms.",
  tita_answer=280, check=_c31,
  tita_traps=[(0, r"Knows that $a^{n} + b^{n}$ is divisible by $a + b = 40$ for odd $n$ and assumes the sum is then divisible by $400$ as well."),
              (340, r"Keeps only one copy of the linear term: $37 \times 20 = 740$, which leaves $340$."),
              (2, r"Uses the pattern for an even exponent, keeping the constant and the even powers of $20$ (doubled) instead of the odd powers, so the sum looks like $2 + 2\binom{37}{2} \cdot 20^2 + \cdots$ and leaves $2$.")],
  cognitive="Analysis", exams=TWO)


def _c32():
    return sum(1 for d in range(1, 1501) if 1000 % d == 10 and 1500 % d == 15)
q("C22-A-032", T, "Divisors leaving given remainders for two numbers", "Difficult",
  "Casework/optimisation",
  r"For how many positive integers $d$ does $1000$ leave a remainder of $10$ and $1500$ leave a remainder of $15$ when each is divided by $d$?",
  "MCQ",
  r"$d$ must divide both $990$ and $1485$, so $d$ divides their HCF. Since $990 = 2 \cdot 3^2 \cdot 5 \cdot 11$ and $1485 = 3^3 \cdot 5 \cdot 11$, the HCF is $3^2 \cdot 5 \cdot 11 = 495$. Its divisors are $1, 3, 5, 9, 11, 15, 33, 45, 55, 99, 165, 495$. Also $d > 15$ (the larger remainder), leaving $33, 45, 55, 99, 165, 495$: $6$ values.",
  "Forgetting that the divisor must exceed both remainders, or an HCF slip.",
  "C22A-divisors-giving-remainder", "HCF of two reduced numbers, full divisor list, and a strict lower bound.",
  correct=r"$6$",
  distractors=[(r"$12$", r"Counts every divisor of $495$, ignoring that $d$ must exceed the remainders."),
               (r"$7$", r"Allows $d = 15$, writing the condition as $d \geq 15$."),
               (r"$3$", r"Takes the HCF as $165$ (using $3$ instead of $3^2$); its divisors above $15$ are $33, 55, 165$.")],
  check=_c32, values=[6, 12, 7, 3], cognitive="Analysis", exams=TWO)


def _c33():
    return int("1" * 102) % 41
q("C22-A-033", T, "Cyclic remainders of repunits modulo 41", "Difficult",
  "Conceptual/application",
  r"The number $N$ is written using the digit $1$ exactly $102$ times, that is $N = 111\ldots1$ with $102$ ones. What is the remainder when $N$ is divided by $41$?",
  "TITA",
  r"Since $11111 = 41 \times 271$, a block of five ones is divisible by $41$. The number with $102$ ones equals the number with $100$ ones (twenty blocks of five, times powers of $10$) followed by $11$, that is $N = (111\ldots1 \text{ with } 100 \text{ ones}) \times 100 + 11$. The first part is divisible by $41$, so $N$ leaves the same remainder as $11$, which is $11$.",
  "Indexing the cycle of length 5 off by one.",
  "C22A-repunit-cycle", "Needs the discovery that 11111 is a multiple of 41, then a split into blocks.",
  tita_answer=11, check=_c33,
  tita_traps=[(29, r"Off by one in the cycle: takes the remainder of $111$, which is $29$."),
              (1, r"Off by one the other way: takes the remainder of a single $1$.")],
  cognitive="Analysis", exams=TWO)


def _c34():
    reach = {(x + y) % 48 for x in range(5, 2000, 8) for y in range(7, 2000, 12)}
    return len(reach)
q("C22-A-034", T, "Number of possible remainders of a sum when the divisors differ", "Difficult",
  "Casework/optimisation",
  r"A positive integer $x$ leaves a remainder of $5$ when divided by $8$, and a positive integer $y$ leaves a remainder of $7$ when divided by $12$. Considering all such pairs $x$, $y$, how many different values can the remainder take when $x + y$ is divided by $48$?",
  "MCQ",
  r"Modulo $48$, $x$ can leave $5, 13, 21, 29, 37, 45$ and $y$ can leave $7, 19, 31, 43$. Every $x + y$ is a multiple of $4$, since $x \equiv 1$ and $y \equiv 3 \pmod 4$. Conversely, fixing $y \equiv 7$, the six values of $x$ give $x + y \equiv 12, 20, 28, 36, 44, 52 \equiv 4$, that is all multiples of $4$ that leave $4$ on division by $8$; fixing $y \equiv 19$ instead shifts these by $12$ and gives $0, 8, 16, 24, 32, 40$. So all $12$ multiples of $4$ below $48$ occur, and the answer is $12$.",
  "Assuming different pairs always give different sums, or working modulo the LCM 24 instead of 48.",
  "C22A-possible-remainders-casework", "Must see that the 24 pairs collapse onto the multiples of 4 and verify that every such residue modulo 48 is reached.",
  correct=r"$12$",
  distractors=[(r"$24$", r"Multiplies the $6$ classes of $x$ by the $4$ classes of $y$, assuming all $24$ pair sums are different modulo $48$."),
               (r"$6$", r"Works modulo $\mathrm{LCM}(8, 12) = 24$ instead of $48$: the multiples of $4$ below $24$ are $0, 4, 8, 12, 16, 20$."),
               (r"$2$", r"Adds the remainders to get $12$ and assumes $x + y$ always leaves $12$ on division by $\mathrm{LCM}(8, 12) = 24$, giving only $12$ and $36$ modulo $48$.")],
  check=_c34, values=[12, 24, 6, 2], cognitive="Analysis", exams=TWO)


def _c35():
    return sum(1 for n in range(100, 1000) if n % 3 == 2 and (n * n) % 5 == 4 and (n * n) % 8 == 1)
q("C22-A-035", T, "Counting numbers with a condition on N and two conditions on N squared", "Difficult",
  "Casework/optimisation",
  r"How many three-digit numbers $N$ satisfy all three of the following: $N$ leaves a remainder of $2$ when divided by $3$; $N^2$ leaves a remainder of $4$ when divided by $5$; and $N^2$ leaves a remainder of $1$ when divided by $8$?",
  "MCQ",
  r"$N^2$ leaves $4$ on division by $5$ exactly when $N$ leaves $2$ or $3$ (squares of $0, 1, 2, 3, 4$ leave $0, 1, 4, 4, 1$). $N^2$ leaves $1$ on division by $8$ exactly when $N$ is odd (every odd square is $1$ more than a multiple of $8$; even squares leave $0$ or $4$). Combining $N \equiv 2 \pmod 3$ with $N \equiv 2$ or $3 \pmod 5$ gives $N \equiv 2$ or $8 \pmod{15}$, and adding oddness gives $N \equiv 17$ or $23 \pmod{30}$. Each class has $900 \div 30 = 30$ three-digit members, so the total is $60$.",
  "Missing the second square root of 4 modulo 5, not recognising that every odd square leaves 1 modulo 8, or dropping a condition.",
  "C22A-square-remainder-casework", "Two square-root analyses (modulo 5 and modulo 8) combined with a third condition, then a count over classes modulo 30.",
  correct=r"$60$",
  distractors=[(r"$120$", r"Ignores the condition modulo $8$, counting $N \equiv 2$ or $8 \pmod{15}$: $2 \times 60 = 120$."),
               (r"$180$", r"Ignores the condition on division by $3$: odd $N$ with $N \equiv 2$ or $3 \pmod 5$ means $N \equiv 3$ or $7 \pmod{10}$, which is $180$ three-digit numbers."),
               (r"$150$", r"Ignores the condition modulo $5$: odd $N$ leaving $2$ on division by $3$ means $N \equiv 5 \pmod 6$, which is $150$ three-digit numbers.")],
  check=_c35, values=[60, 120, 180, 150], cognitive="Analysis", exams=TWO)
