import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Unit and last digits"
HEAVY = ("CAT", "XAT")


def _last(n, k=1):
    """Last k digits of a non-negative integer n, by repeated division."""
    return n % (10 ** k)


def _pow_mod_sim(a, n, m):
    """Multiply step by step, keeping only the residue, to simulate a^n mod m."""
    r = 1 % m
    for _ in range(n):
        r = (r * a) % m
    return r


# 001 ---------------------------------------------------------------
def _c1():
    return _pow_mod_sim(3, 2038, 10)
q("C23-A-001", T, "Unit digit of a single power using the cycle of 3", "Easy",
  "Single-step computation",
  r"What is the unit digit of $3^{2038}$?",
  "MCQ",
  r"The unit digits of powers of $3$ repeat in the cycle $3, 9, 7, 1$ of length $4$. Divide the exponent by $4$: $2038 = 4 \times 509 + 2$, so the remainder is $2$ (look at the last two digits, $38 = 4 \times 9 + 2$). Hence $3^{2038}$ ends like $3^2 = 9$, and the unit digit is $9$.",
  "Reducing the exponent using only its last digit, or using the wrong cycle length.",
  "C23A-single-power-cyclicity", "One cycle and one remainder; the trap is reducing the exponent by its last digit only.",
  correct=r"$9$",
  distractors=[(r"$1$", "Reduces the exponent by its last digit $8$, which is a multiple of $4$, so takes $3^4$, ending in $1$."),
               (r"$3$", "Uses a cycle of length $3$: $2038$ leaves remainder $1$ on division by $3$, giving $3^1$."),
               (r"$7$", "Assigns the cycle entries $3, 9, 7, 1$ to remainders $0, 1, 2, 3$ in that order, so remainder $2$ gives $7$.")],
  check=_c1, values=[9, 1, 3, 7], cognitive="Application")

# 002 ---------------------------------------------------------------
def _c2():
    cells = 1
    for hour in range(75):
        cells *= 2
    return _last(cells)
q("C23-A-002", T, "Unit digit of a power of 2 in a doubling context", "Easy",
  "Multi-step word problem",
  r"A laboratory culture starts with a single cell. Every hour, each cell present splits into exactly two cells, and no cell dies. What is the unit digit of the number of cells after exactly $75$ such hourly splits? Type the digit.",
  "TITA",
  r"After $75$ splits the culture has $2^{75}$ cells. Powers of $2$ end in the cycle $2, 4, 8, 6$. Since $75 = 4 \times 18 + 3$, the remainder is $3$ and $2^{75}$ ends like $2^3 = 8$. The unit digit is $8$.",
  "Counting the starting cell as a split, which shifts the exponent by one.",
  "C23A-single-power-cyclicity", "A one-line model ($2^{75}$) followed by a cycle of length $4$.",
  tita_answer=8, check=_c2,
  tita_traps=[(6, "Counts $76$ doublings by treating the start as a split, and $2^{76}$ ends in $6$."),
              (4, "Counts only $74$ doublings, and $2^{74}$ ends in $4$.")],
  cognitive="Application")

# 003 ---------------------------------------------------------------
def _c3():
    return _last(13 ** 43 * 27 ** 44 * 32 ** 45)
q("C23-A-003", T, "Unit digit of a product of three powers", "Easy",
  "Single-step computation",
  r"What is the unit digit of $13^{43} \times 27^{44} \times 32^{45}$?",
  "MCQ",
  r"Only unit digits matter. $3^{43}$: $43 = 4 \times 10 + 3$, so it ends like $3^3 = 27$, in $7$. $7^{44}$: $44$ is a multiple of $4$, so it ends like $7^4 = 2401$, in $1$. $2^{45}$: $45 = 4 \times 11 + 1$, so it ends in $2$. The product ends like $7 \times 1 \times 2 = 14$, so the unit digit is $4$.",
  "Combining the unit digits by addition, or ignoring the exponents.",
  "C23A-product-of-powers", "Three separate cycles and a product; each step is routine.",
  correct=r"$4$",
  distractors=[(r"$2$", "Multiplies the unit digits of the bases, $3 \\times 7 \\times 2 = 42$, without using the exponents."),
               (r"$0$", "Adds the three unit digits $7 + 1 + 2 = 10$ rather than multiplying them."),
               (r"$8$", "Reads each cycle one step late (remainder $3$ taken as $3^4$, remainder $0$ as $7^1$, remainder $1$ as $2^2$), getting $1 \\times 7 \\times 4 = 28$.")],
  check=_c3, values=[4, 2, 0, 8], cognitive="Application")

# 004 ---------------------------------------------------------------
def _c4():
    return _pow_mod_sim(41, 57, 100)
q("C23-A-004", T, "Last two digits of a power of a number ending in 1", "Easy",
  "Single-step computation",
  r"What are the last two digits of $41^{57}$?",
  "MCQ",
  r"Write $41 = 1 + 40$. By the binomial theorem, $(1 + 40)^{57} \equiv 1 + 57 \times 40 \pmod{100}$, because every later term contains $40^2 = 1600$. Now $57 \times 40 = 2280$, which ends in $80$. So $41^{57}$ ends in $81$. (Quick rule: the tens digit is the unit digit of $4 \times 7 = 28$, the unit digit is $1$.)",
  "Using the wrong digit of the exponent in the tens-digit rule, or adding instead of multiplying.",
  "C23A-base-ending-1-binomial", "Direct application of the rule for bases ending in $1$.",
  correct=r"$81$",
  distractors=[(r"$41$", "Assumes every power of $41$ ends in $41$, as powers of $76$ end in $76$."),
               (r"$01$", "Multiplies $4$ by the tens digit $5$ of the exponent: $4 \\times 5 = 20$ gives tens digit $0$."),
               (r"$11$", "Adds $4 + 7 = 11$ in the tens-digit rule, giving tens digit $1$.")],
  check=_c4, values=[81, 41, 1, 11], cognitive="Application")

# 005 ---------------------------------------------------------------
def _c5():
    return _last(17 ** 45 - 13 ** 22)
q("C23-A-005", T, "Unit digit of a difference of two powers with borrowing", "Easy",
  "Multi-step word problem",
  r"What is the unit digit of $17^{45} - 13^{22}$?",
  "MCQ",
  r"$17^{45}$: $45 = 4 \times 11 + 1$, so it ends like $7^1$, in $7$. $13^{22}$: $22 = 4 \times 5 + 2$, so it ends like $3^2$, in $9$. Since $17^{45}$ is far larger than $13^{22}$, the difference is positive and its unit digit is that of $17 - 9$ (a borrow is needed), which is $8$.",
  "Subtracting the smaller digit from the larger digit without borrowing.",
  "C23A-difference-borrow", "Two cycles and a subtraction; the trap is the borrow.",
  correct=r"$8$",
  distractors=[(r"$2$", "Computes $9 - 7 = 2$, subtracting the unit digits in the reverse order to avoid a borrow."),
               (r"$6$", "Adds the unit digits, $7 + 9 = 16$."),
               (r"$4$", "Ignores the exponents and uses $7 - 3 = 4$ from the bases.")],
  check=_c5, values=[8, 2, 6, 4], cognitive="Application")

# 006 ---------------------------------------------------------------
def _c6():
    p = 1
    for k in range(1, 50, 2):
        p *= k
    return _last(p)
q("C23-A-006", T, "Unit digit of the product of consecutive odd numbers", "Easy",
  "Conceptual/application",
  r"What is the unit digit of the product $1 \times 3 \times 5 \times 7 \times \dots \times 49$ of all odd numbers from $1$ to $49$? Type the digit.",
  "TITA",
  r"The product contains the factor $5$ and every factor is odd, so the product is an odd multiple of $5$. An odd multiple of $5$ always ends in $5$. The unit digit is $5$.",
  "Believing that any product containing $5$ ends in $0$.",
  "C23A-product-sequence", "One idea: an odd multiple of $5$ ends in $5$.",
  tita_answer=5, check=_c6,
  tita_traps=[(0, "Assumes a factor of $5$ always makes the product end in $0$, overlooking that no factor is even.")],
  cognitive="Understanding")

# 007 ---------------------------------------------------------------
def _c7():
    return sum(1 for n in range(1, 51) if pow(n, 4) % 10 == 1)
q("C23-A-007", T, "Counting integers whose fourth power ends in 1", "Easy",
  "Conceptual/application",
  r"How many integers $n$ with $1 \le n \le 50$ have the property that $n^4$ ends in the digit $1$?",
  "TITA",
  r"The unit digit of $n^4$ depends only on the unit digit of $n$. Checking digits: $1^4, 3^4 = 81, 7^4 = 2401, 9^4 = 6561$ end in $1$, while even digits give even fourth powers and $5$ gives $5$. So $n^4$ ends in $1$ exactly when $n$ ends in $1, 3, 7$ or $9$. From $1$ to $50$ there are $5$ such numbers in each block of ten, $4 \times 5 = 20$.",
  "Counting all odd numbers, forgetting that multiples of $5$ end in $5$.",
  "C23A-fourth-power-digits", "Small digit check followed by a simple count.",
  tita_answer=20, check=_c7,
  tita_traps=[(25, "Counts all odd numbers up to $50$, including those ending in $5$."),
              (4, "Reports the number of possible unit digits rather than the number of integers.")],
  cognitive="Understanding")

# 008 ---------------------------------------------------------------
def _c8():
    opts = [2047, 2042, 2045, 2053]
    good = [n for n in opts if pow(7, n, 10) == 3]
    assert len(good) == 1
    return good[0]
q("C23-A-008", T, "Finding a possible exponent from the unit digit of a power of 7", "Easy",
  "Inverse/parameter",
  r"For a positive integer $n$, the number $7^n$ ends in the digit $3$. Which of the following could be the value of $n$?",
  "MCQ",
  r"Powers of $7$ end in the cycle $7, 9, 3, 1$, so $7^n$ ends in $3$ exactly when $n$ leaves remainder $3$ on division by $4$. Using the last two digits: $47 = 4 \times 11 + 3$ gives remainder $3$, while $42$ gives $2$, $45$ gives $1$ and $53$ gives $1$. Only $n = 2047$ works.",
  "Mixing up the cycles of $3$ and $7$, or reducing $n$ by its last digit only.",
  "C23A-inverse-exponent-from-digit", "Reverse use of a single cycle.",
  correct=r"$2047$",
  distractors=[(r"$2042$", "Assigns the cycle entries $7, 9, 3, 1$ to remainders $0, 1, 2, 3$ in that order, so wants remainder $2$."),
               (r"$2045$", "Uses the cycle of $3$ ($3, 9, 7, 1$), where $3$ appears at remainder $1$."),
               (r"$2053$", "Reduces $n$ by its last digit only: $3$ looks like remainder $3$, but $53$ leaves remainder $1$.")],
  check=_c8, values=[2047, 2042, 2045, 2053], cognitive="Application")

# 009 ---------------------------------------------------------------
def _c9():
    x = 1
    for press in range(50):
        x = x * 7
    return _last(x)
q("C23-A-009", T, "Unit digit after repeated multiplication by 7", "Easy",
  "Multi-step word problem",
  r"Kabir writes the number $1$ and then multiplies the number he has by $7$, again and again, carrying out exactly $50$ multiplications in all. What is the unit digit of his final number?",
  "MCQ",
  r"After $50$ multiplications the number is $7^{50}$. Powers of $7$ end in $7, 9, 3, 1$. Since $50 = 4 \times 12 + 2$, the remainder is $2$ and $7^{50}$ ends like $7^2 = 49$. The unit digit is $9$.",
  "Off-by-one in the exponent, or reducing $50$ by its last digit.",
  "C23A-single-power-cyclicity", "Model as $7^{50}$, then one cycle step.",
  correct=r"$9$",
  distractors=[(r"$3$", "Counts the starting $1$ as a multiplication and evaluates $7^{51}$."),
               (r"$7$", "Counts only $49$ multiplications and evaluates $7^{49}$."),
               (r"$1$", "Reduces the exponent by its last digit $0$, treating $50$ as a multiple of $4$.")],
  check=_c9, values=[9, 3, 7, 1], cognitive="Application")

# 010 ---------------------------------------------------------------
def _c10():
    return _last(22 ** 80 + 33 ** 41 + 44 ** 63 + 77 ** 58)
q("C23-A-010", T, "Unit digit of a sum of four powers with different exponents", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $22^{80} + 33^{41} + 44^{63} + 77^{58}$?",
  "MCQ",
  r"Only unit digits matter, and each term needs its own cycle lookup. $2^{80}$: $80$ is a multiple of $4$, so it ends like $2^4 = 16$, in $6$. $3^{41}$: $41 = 4 \times 10 + 1$, so it ends in $3$. $4^{63}$: powers of $4$ end in $4$ for odd exponents, so it ends in $4$. $7^{58}$: $58 = 4 \times 14 + 2$, so it ends like $7^2 = 49$, in $9$. The sum ends like $6 + 3 + 4 + 9 = 22$, so the unit digit is $2$.",
  "Reducing an exponent by its last digit, or misplacing a remainder in a cycle.",
  "C23A-sum-mixed-exponents", "Four separate lookups with remainders $0, 1, 3, 2$ and cycle lengths $4$ and $2$, then a sum.",
  correct=r"$2$",
  distractors=[(r"$4$", "Tests $58$ for divisibility by $4$ using only its last digit $8$, so takes $7^{58}$ as ending like $7^4$, in $1$: $6 + 3 + 4 + 1 = 14$."),
               (r"$0$", r"Reads each cycle one step late, using $2^1$, $3^2$, an even power of $4$ and $7^3$: $2 + 9 + 6 + 3 = 20$."),
               (r"$6$", "Ignores the exponents and adds the unit digits of the bases: $2 + 3 + 4 + 7 = 16$.")],
  check=_c10, values=[2, 4, 0, 6], cognitive="Application")

# 011 ---------------------------------------------------------------
def _c11():
    return _last(sum(k ** 5 for k in range(1, 48)))
q("C23-A-011", T, "Fifth powers keep the unit digit: sum of k^5", "Medium",
  "Conceptual/application",
  r"What is the unit digit of $1^5 + 2^5 + 3^5 + \dots + 47^5$? Type the digit.",
  "TITA",
  r"Every cycle of unit digits has length $1, 2$ or $4$, all dividing $4$, so $k^5$ ends in the same digit as $k^1$. Hence the sum has the same unit digit as $1 + 2 + \dots + 47 = \frac{47 \times 48}{2} = 1128$. The unit digit is $8$.",
  "Not seeing that $k^5$ and $k$ always share the unit digit, and losing track over many terms.",
  "C23A-fifth-power-unit", r"Needs the insight that $k^5 \equiv k \pmod{10}$; brute force is slow.",
  tita_answer=8, check=_c11,
  tita_traps=[(0, "Keeps only the four complete blocks $1$ to $40$, whose sum $820$ ends in $0$, and drops $41$ to $47$."),
              (1, "Sums only up to $46$: $1 + 2 + \\dots + 46 = 1081$.")],
  cognitive="Analysis")

# 012 ---------------------------------------------------------------
def _c12():
    e = pow(14, 15, 4)          # exponent mod 4
    e = e if e != 0 else 4
    return pow(13, e, 10)
q("C23-A-012", T, "Unit digit of a power tower", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $13^{14^{15}}$? (The exponent is $14^{15}$.)",
  "MCQ",
  r"The unit digit follows $3, 9, 7, 1$, so we need $14^{15}$ modulo $4$. Since $14 = 2 \times 7$, $14^{15}$ is divisible by $2^{15}$, hence by $4$. A remainder of $0$ means the last entry of the cycle, as in $3^4 = 81$. The unit digit is $1$.",
  "Reducing only part of the tower, or treating remainder $0$ as the first entry of the cycle.",
  "C23A-power-tower-unit", "Requires reducing a tower exponent modulo $4$.",
  correct=r"$1$",
  distractors=[(r"$9$", "Reduces $14$ modulo $4$ to $2$ and stops, using $3^2$ while ignoring the outer exponent $15$."),
               (r"$7$", "Applies the cycle to the top exponent: $15$ leaves remainder $3$, giving $3^3$."),
               (r"$3$", "Finds remainder $0$ but takes it as the first entry of the cycle.")],
  check=_c12, values=[1, 9, 7, 3], cognitive="Application")

# 013 ---------------------------------------------------------------
def _c13():
    return _pow_mod_sim(29, 46, 100)
q("C23-A-013", T, "Last two digits by converting to a base ending in 1", "Medium",
  "Multi-step word problem",
  r"What number is formed by the last two digits of $29^{46}$? Type it as a two-digit number.",
  "TITA",
  r"Square first: $29^2 = 841$, so $29^{46} = (29^2)^{23}$ ends like $41^{23}$. For a base ending in $1$, $41^{23} = (1 + 40)^{23} \equiv 1 + 23 \times 40 = 921 \pmod{100}$. So the last two digits are $21$.",
  "Applying the base-ending-in-1 rule to the original exponent, or using the wrong digit of the exponent.",
  "C23A-base-ending-1-binomial", "Two steps: reduce to a base ending in $1$, then the binomial rule.",
  tita_answer=21, check=_c13,
  tita_traps=[(41, "Uses exponent $46$ with base $41$: $4 \\times 6 = 24$ gives $41$."),
              (81, "Multiplies $4$ by the tens digit $2$ of $23$, giving tens digit $8$.")],
  cognitive="Application")

# 014 ---------------------------------------------------------------
def _c14():
    return _pow_mod_sim(7, 2030, 100)
q("C23-A-014", T, "Last two digits of a power of 7 using 7^4 = 2401", "Medium",
  "Conceptual/application",
  r"What are the last two digits of $7^{2030}$?",
  "MCQ",
  r"Since $7^4 = 2401$ ends in $01$, the last two digits of powers of $7$ repeat with period $4$: $07, 49, 43, 01$. Now $2030 = 4 \times 507 + 2$, so $7^{2030}$ ends like $7^2 = 49$. The last two digits are $49$.",
  "Reducing the exponent by its last digit, or stopping at the unit digit.",
  "C23A-last-two-cycle-4", r"Needs the observation $7^4 \equiv 1 \pmod{100}$.",
  correct=r"$49$",
  distractors=[(r"$01$", "Reduces the exponent by its last digit $0$, treating $2030$ as a multiple of $4$."),
               (r"$43$", "Reads the cycle one step late and uses $7^3 = 343$."),
               (r"$09$", "Finds the unit digit $9$ correctly and takes the tens digit as $0$.")],
  check=_c14, values=[49, 1, 43, 9], cognitive="Application")

# 015 ---------------------------------------------------------------
def _c15():
    return _pow_mod_sim(3, 2026, 100)
q("C23-A-015", T, "Last two digits of a power of 3 with period 20", "Medium",
  "Multi-step word problem",
  r"What number is formed by the last two digits of $3^{2026}$? Type it as a two-digit number.",
  "TITA",
  r"$3^4 = 81$, $3^5$ ends in $43$, $3^{10}$ ends like $43^2 = 1849$, in $49$, and $3^{20}$ ends like $49^2 = 2401$, in $01$. So the last two digits repeat every $20$ powers. $2026 = 20 \times 101 + 6$, so $3^{2026}$ ends like $3^6 = 729$. The last two digits are $29$.",
  "Using the period $4$ of unit digits for the last two digits.",
  "C23A-last-two-cycle-20", "Must establish the period $20$ modulo $100$.",
  tita_answer=29, check=_c15,
  tita_traps=[(9, "Uses the period $4$ of unit digits: $2026$ leaves remainder $2$, giving $3^2 = 09$."),
              (87, "Reads the period-20 cycle one step late and uses $3^7 = 2187$.")],
  cognitive="Analysis", exams=HEAVY)

# 016 ---------------------------------------------------------------
def _c16():
    n = 1
    while pow(2, n, 100) != 76:
        n += 1
    return n
q("C23-A-016", T, "Smallest exponent for which a power of 2 ends in 76", "Medium",
  "Inverse/parameter",
  r"What is the smallest positive integer $n$ for which $2^n$ ends in the digits $76$?",
  "TITA",
  r"For $2^n$ to end in $6$ we need $n$ to be a multiple of $4$. Check these in order: $2^4 = 16$, $2^8 = 256$, $2^{12} = 4096$, $2^{16} = 65536$, $2^{20} = 1048576$. The first one ending in $76$ is $2^{20}$, so $n = 20$.",
  "Guessing a period such as $10$ or $40$ without checking.",
  "C23A-even-base-76", "Restrict by the unit digit, then test a few candidates.",
  tita_answer=20, check=_c16,
  tita_traps=[(40, "Assumes the answer must be $40$, the count of integers below $100$ coprime to $100$."),
              (10, "Assumes powers of $2$ repeat their last two digits every $10$ steps, but $2^{10}$ ends in $24$.")],
  cognitive="Application")

# 017 ---------------------------------------------------------------
def _c17():
    return sum(1 for n in range(1, 151) if (7 ** n + 3 ** n) % 10 == 8)
q("C23-A-017", T, "Counting exponents for which a sum of powers ends in 8", "Medium",
  "Casework/optimisation",
  r"For how many integers $n$ with $1 \le n \le 150$ does $7^n + 3^n$ end in the digit $8$?",
  "TITA",
  r"Work by the remainder of $n$ on division by $4$. Remainder $1$: $7 + 3 = 10$, ends in $0$. Remainder $2$: $9 + 9 = 18$, ends in $8$. Remainder $3$: $3 + 7 = 10$, ends in $0$. Remainder $0$: $1 + 1 = 2$. So we need $n \equiv 2 \pmod 4$: $n = 2, 6, 10, \dots, 150$, which is $\frac{150 - 2}{4} + 1 = 38$ values.",
  "Off-by-one in counting the arithmetic progression, or accepting every even $n$.",
  "C23A-count-exponents", "Four-case table plus an AP count.",
  tita_answer=38, check=_c17,
  tita_traps=[(37, "Counts $\\frac{150 - 2}{4} = 37$ and omits the $+1$."),
              (75, "Accepts every even $n$, overlooking that multiples of $4$ give a sum ending in $2$.")],
  cognitive="Analysis")

# 018 ---------------------------------------------------------------
def _c18():
    p = 1
    for k in range(1, 74):
        if k % 2 and k % 5:
            p *= k
    return _last(p)
q("C23-A-018", T, "Unit digit of the product of integers coprime to 10", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of the product of all integers from $1$ to $73$ that are divisible by neither $2$ nor $5$?",
  "MCQ",
  r"The factors end in $1, 3, 7, 9$. Each complete block of ten ($1$ to $10$, ..., $61$ to $70$) contributes four factors ending in $1, 3, 7, 9$, and $1 \times 3 \times 7 \times 9 = 189$ ends in $9$. Seven blocks give $9^7$, which ends in $9$ (odd power). The remaining factors $71$ and $73$ contribute $1 \times 3 = 3$. The product ends like $9 \times 3 = 27$, so the unit digit is $7$.",
  "Mishandling the partial block or the block product.",
  "C23A-product-sequence", "Group into blocks, use the cycle of $9$, then the partial block.",
  correct=r"$7$",
  distractors=[(r"$9$", "Stops at $70$ and leaves out the factors $71$ and $73$."),
               (r"$3$", "Takes each block product $1 \\times 3 \\times 7 \\times 9$ as ending in $1$, leaving only $71 \\times 73$."),
               (r"$1$", "Rounds up to eight complete blocks of ten, $9^8$, ending in $1$.")],
  check=_c18, values=[7, 9, 3, 1], cognitive="Application")

# 019 ---------------------------------------------------------------
def _c19():
    p = 1
    t = 3
    while t <= 983:
        p *= t
        t += 10
    return _last(p)
q("C23-A-019", T, "Unit digit of a product of terms of an arithmetic progression", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $3 \times 13 \times 23 \times 33 \times \dots \times 983$, the product of all positive integers up to $983$ that end in $3$?",
  "MCQ",
  r"The number of factors is $\frac{983 - 3}{10} + 1 = 99$. Each ends in $3$, so the product ends like $3^{99}$. Since $99 = 4 \times 24 + 3$, $3^{99}$ ends like $3^3 = 27$. The unit digit is $7$.",
  "Miscounting the factors by one, or misplacing the remainder in the cycle.",
  "C23A-product-sequence", "Count terms of an AP, then a cycle of length $4$.",
  correct=r"$7$",
  distractors=[(r"$9$", "Counts $\\frac{983 - 3}{10} = 98$ factors and omits the $+1$, giving $3^{98}$."),
               (r"$1$", "Reads the cycle one step late, so remainder $3$ gives $3^4$."),
               (r"$3$", "Assumes every odd power of $3$ ends in $3$, by analogy with odd powers of $9$ ending in $9$.")],
  check=_c19, values=[7, 9, 1, 3], cognitive="Application")

# 020 ---------------------------------------------------------------
def _c20():
    opts = [76, 54, 39, 26]
    sq = {(n * n) % 100 for n in range(100)}
    good = [x for x in opts if x in sq]
    assert len(good) == 1
    return good[0]
q("C23-A-020", T, "Which two-digit ending is possible for a perfect square", "Medium",
  "Conceptual/application",
  r"A positive integer $N$ is a perfect square. Which of the following could be the number formed by the last two digits of $N$?",
  "MCQ",
  r"Write the square root as $10a + b$. Then $(10a + b)^2 = 100a^2 + 20ab + b^2$, so the tens digit of the square is the tens digit of $b^2$ plus an even number, modulo $10$. For unit digit $6$, $b = 4$ or $6$ with $b^2 = 16$ or $36$, so the tens digit is odd; $24^2 = 576$ ends in $76$. For unit digit $4$ ($b^2 = 4$ or $64$) and unit digit $9$ ($b^2 = 9$ or $49$) the tens digit is even, ruling out $54$ and $39$; and $26$ has unit digit $6$ with an even tens digit. Only $76$ is possible.",
  "Checking only that the unit digit is a possible square ending.",
  "C23A-squares-last-two", "Needs the tens-digit parity argument for squares.",
  correct=r"$76$",
  distractors=[(r"$54$", "Checks only the unit digit $4$, which is possible for a square, and misses that the tens digit must then be even."),
               (r"$39$", "Checks only the unit digit $9$, which is possible for a square, and misses that the tens digit must then be even."),
               (r"$26$", "Checks only the unit digit $6$, and misses that the tens digit must then be odd.")],
  check=_c20, values=[76, 54, 39, 26], cognitive="Analysis")

# 021 ---------------------------------------------------------------
def _c21():
    return _last(sum(3 ** k for k in range(1, 2027)))
q("C23-A-021", T, "Unit digit of a geometric sum of powers of 3", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $3 + 3^2 + 3^3 + \dots + 3^{2026}$?",
  "MCQ",
  r"The unit digits of the terms run $3, 9, 7, 1$ repeatedly, and each full cycle sums to $20$, ending in $0$. There are $2026 = 4 \times 506 + 2$ terms, so $506$ full cycles contribute a unit digit of $0$, and the last two terms end in $3$ and $9$. The sum ends like $3 + 9 = 12$, so the unit digit is $2$.",
  "Halving a unit digit, or ignoring the leftover terms after full cycles.",
  "C23A-geometric-sum-unit", "Group the sum into cycles and handle the remainder.",
  correct=r"$2$",
  distractors=[(r"$0$", "Treats all $2026$ terms as complete cycles of four, ignoring the two leftover terms."),
               (r"$7$", "Uses $\\frac{3^{2027} - 3}{2}$; the numerator ends in $4$, and halves it as $14 \\div 2 = 7$, though halving a unit digit is ambiguous."),
               (r"$9$", "Reports the unit digit of the last term $3^{2026}$ alone.")],
  check=_c21, values=[2, 0, 7, 9], cognitive="Application")

# 022 ---------------------------------------------------------------
def _c22():
    return _last(sum(pow(k, 2030, 10) for k in range(1, 2029)))
q("C23-A-022", T, "Unit digit of 1^n + 2^n + ... + N^n with a partial block", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $1^{2030} + 2^{2030} + 3^{2030} + \dots + 2028^{2030}$?",
  "MCQ",
  r"$2030 = 4 \times 507 + 2$, so each $k^{2030}$ ends like $k^2$. Over a complete block of ten consecutive integers the unit digits of the squares are $0, 1, 4, 9, 6, 5, 6, 9, 4, 1$, summing to $45$. The terms $1$ to $2020$ form $202$ blocks, contributing $202 \times 45 = 9090$, ending in $0$. The remaining terms $2021$ to $2028$ end like $1 + 4 + 9 + 6 + 5 + 6 + 9 + 4 = 44$. The unit digit is $4$.",
  "Ignoring the partial block, or reducing the exponent by its last digit.",
  "C23A-sum-same-exponent", "Block sums plus a partial block over $2028$ terms.",
  correct=r"$4$",
  distractors=[(r"$0$", "Counts only the $202$ complete blocks and leaves out $2021$ to $2028$."),
               (r"$6$", "Ignores the exponent and uses $1 + 2 + \\dots + 2028 = 2057406$."),
               (r"$8$", "Reduces the exponent by its last digit $0$ and uses fourth powers: $202 \\times 33$ ends in $6$ and the partial block gives $32$.")],
  check=_c22, values=[4, 0, 6, 8], cognitive="Application", exams=HEAVY)

# 023 ---------------------------------------------------------------
def _c23():
    a, b = 456 ** 78, 123 ** 45 * 789 ** 11
    assert a > b
    return _last(a - b)
q("C23-A-023", T, "Unit digit of a power minus a product of powers, with a borrow", "Medium",
  "Multi-step word problem",
  r"What is the unit digit of $456^{78} - 123^{45} \times 789^{11}$?",
  "MCQ",
  r"First the sign: $123^{45} \times 789^{11} < 1000^{56} = 10^{168}$, while $456^{78} > 400^{78} > 10^{200}$, so the difference is positive. Every power of a number ending in $6$ ends in $6$. $3^{45}$: $45 = 4 \times 11 + 1$, so it ends in $3$; $9^{11}$ has an odd exponent, so it ends in $9$; the product ends like $3 \times 9 = 27$, in $7$. The difference ends like $16 - 7 = 9$ (a borrow is needed), so the unit digit is $9$.",
  "Subtracting the unit digits without a borrow, or mishandling the length-2 cycle of $9$.",
  "C23A-difference-borrow", "Three cycle lengths ($1$, $4$, $2$), a product, then a subtraction that needs a sign check and a borrow.",
  correct=r"$9$",
  distractors=[(r"$1$", "Subtracts the unit digits in the reverse order, $7 - 6 = 1$, to avoid a borrow."),
               (r"$3$", "Takes $789^{11}$ as ending in $1$, so the product ends in $3$ and $6 - 3 = 3$."),
               (r"$5$", r"Reads the cycle of $3$ one step late, taking $3^{45}$ as ending in $9$: $9 \times 9 = 81$ and $6 - 1 = 5$.")],
  check=_c23, values=[9, 1, 3, 5], cognitive="Application")

# 024 ---------------------------------------------------------------
def _c24():
    # direct modular exponentiation with the full exponent 17^19
    return pow(13, 17 ** 19, 100)
q("C23-A-024", T, "Last two digits of a power tower", "Difficult",
  "Multi-step word problem",
  r"What number is formed by the last two digits of $13^{17^{19}}$ (the exponent is $17^{19}$)? Type it as a two-digit number.",
  "TITA",
  r"First, $13^2$ ends in $69$, $13^4$ ends like $69^2 = 4761$, in $61$, $13^5$ ends like $61 \times 13 = 793$, in $93$, $13^{10}$ ends like $93^2 = 8649$, in $49$, and $13^{20}$ ends like $49^2 = 2401$, in $01$. So we need $17^{19}$ modulo $20$. Since $17 \equiv -3$ and $3^4 = 81 \equiv 1 \pmod{20}$, $17^{19} \equiv -3^{19} = -3^{16} \cdot 3^3 \equiv -27 \equiv 13 \pmod{20}$. Hence the number ends like $13^{13} = 13^{10} \cdot 13^3$, that is $49 \times 97 = 4753$, ending in $53$.",
  "Reducing the tower exponent modulo $4$, or not reducing it at all.",
  "C23A-power-tower-last-two", "Needs the period $20$ modulo $100$ and a second reduction modulo $20$.",
  tita_answer=53, check=_c24,
  tita_traps=[(13, "Reduces the exponent modulo $4$ (valid only for unit digits): $17^{19} \\equiv 1 \\pmod 4$ gives $13^1$."),
              (33, "Assumes $17^{19} \\equiv 17 \\pmod{20}$ and computes $13^{17}$, ending in $33$.")],
  cognitive="Analysis", exams=HEAVY)

# 025 ---------------------------------------------------------------
def _c25():
    return _pow_mod_sim(14, 541, 100)
q("C23-A-025", T, "Last two digits of a power of 14 using 2^20 ending in 76 and the period of 7", "Difficult",
  "Conceptual/application",
  r"What are the last two digits of $14^{541}$?",
  "MCQ",
  r"Split $14^{541} = 2^{541} \times 7^{541}$. For the even part, $2^{10} = 1024$ ends in $24$ and $24^2 = 576$ ends in $76$; since $76^2 = 5776$ ends in $76$, every $2^{20k}$ ($k \ge 1$) ends in $76$, so $2^{541} = (2^{20})^{27} \times 2$ ends like $76 \times 2 = 152$, in $52$. For the odd part, $7^4 = 2401$ ends in $01$ and $541 = 4 \times 135 + 1$, so $7^{541}$ ends in $07$. The product ends like $52 \times 7 = 364$, so the last two digits are $64$.",
  "Assuming a power of an even base can end in $01$, as happens for odd bases.",
  "C23A-even-base-76", "Two stages: the $76$ behaviour of powers of $2$ (they never end in $01$) and the period $4$ of $7$ modulo $100$, then a product.",
  correct=r"$64$",
  distractors=[(r"$14$", "Assumes $14^{20}$ ends in $01$, as for odd bases, and reduces $14^{541}$ to $14^1$."),
               (r"$76$", "Finds that $14^{540}$ ends in $76$ and does not multiply by the remaining factor $14$."),
               (r"$52$", "Handles $2^{541}$ correctly but treats $7^{541}$ as ending in $01$, overlooking the remainder $1$.")],
  check=_c25, values=[64, 14, 76, 52], cognitive="Analysis", exams=HEAVY)

# 026 ---------------------------------------------------------------
def _c26():
    return sum(1 for m in range(1, 31) for n in range(1, 26) if (2 ** m + 9 ** n) % 10 == 5)
q("C23-A-026", T, "Counting ordered pairs of exponents for which 2^m + 9^n ends in 5 (cycles of length 4 and 2)", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs $(m, n)$ of integers with $1 \le m \le 30$ and $1 \le n \le 25$ make $2^m + 9^n$ end in the digit $5$?",
  "TITA",
  r"Unit digits of $2^m$ by remainder of $m$ modulo $4$ (remainders $1, 2, 3, 0$): $2, 4, 8, 6$. Unit digits of $9^n$: $9$ for odd $n$, $1$ for even $n$. A sum ending in $5$ needs $6 + 9$ or $4 + 1$, that is ($m \equiv 0 \pmod 4$, $n$ odd) or ($m \equiv 2 \pmod 4$, $n$ even). From $1$ to $30$ there are $7$ multiples of $4$ and $8$ values with remainder $2$; from $1$ to $25$ there are $13$ odd and $12$ even values. Total $7 \times 13 + 8 \times 12 = 91 + 96 = 187$.",
  "Overlooking one of the two digit combinations, or assuming equal class sizes.",
  "C23A-pairs-casework", "Two cycles of different lengths, two matching cases and unequal class sizes in both ranges.",
  tita_answer=187, check=_c26,
  tita_traps=[(175, "Assumes every power of $9$ ends in $9$, so only $m \\equiv 0 \\pmod 4$ works: $7 \\times 25$."),
              (188, "Swaps the parity rule for $9$ (odd powers ending in $1$): $7 \\times 12 + 8 \\times 13$."),
              (200, "Assumes each remainder class of $m$ has $8$ members: $8 \\times 13 + 8 \\times 12$.")],
  cognitive="Analysis", exams=HEAVY)

# 027 ---------------------------------------------------------------
def _c27():
    return _last(sum(k ** k for k in range(1, 36)))
q("C23-A-027", T, "Unit digit of the sum of self powers k^k", "Difficult",
  "Casework/optimisation",
  r"What is the unit digit of $1^1 + 2^2 + 3^3 + \dots + 35^{35}$?",
  "MCQ",
  r"The unit digit of $k^k$ depends on the unit digit of $k$ and on $k$ modulo $4$, so it repeats with period $20$. For $k = 1$ to $20$ the unit digits are $1, 4, 7, 6, 5, 6, 3, 6, 9, 0, 1, 6, 3, 6, 5, 6, 7, 4, 9, 0$, summing to $94$, ending in $4$. Terms $21$ to $35$ repeat the first $15$ of these, whose sum is $1+4+7+6+5+6+3+6+9+0+1+6+3+6+5 = 68$, ending in $8$. The total ends like $4 + 8 = 12$, so the unit digit is $2$.",
  "Assuming the pattern of $k^k$ repeats every $10$ terms.",
  "C23A-self-powers-sum", "The period is $20$, not $10$; requires a careful table of $20$ values.",
  correct=r"$2$",
  distractors=[(r"$4$", "Assumes period $10$, treating $21^{21}$ like $1^1$ and $32^{32}$ like $2^2$: three blocks summing to $47$ each plus $1+4+7+6+5$."),
               (r"$8$", "Assumes a full period of $20$ terms sums to a multiple of $10$ and keeps only terms $21$ to $35$."),
               (r"$0$", "Ignores the exponents and adds $1 + 2 + \\dots + 35 = 630$.")],
  check=_c27, values=[2, 4, 8, 0], cognitive="Analysis", exams=HEAVY)

# 028 ---------------------------------------------------------------
def _c28():
    return len({(n * n) % 100 for n in range(1, 1001)})
q("C23-A-028", T, "Number of possible last-two-digit endings of perfect squares", "Difficult",
  "Casework/optimisation",
  r"As $n$ runs over all positive integers, the last two digits of $n^2$ form a number from $0$ to $99$ (for example, $12^2 = 144$ gives $44$ and $10^2 = 100$ gives $0$). How many different such numbers occur?",
  "TITA",
  r"The ending depends only on $n$ modulo $100$, and $(50 \pm r)^2 = 2500 \pm 100r + r^2$ and $(100 - r)^2$ both end like $r^2$, so only $r = 0, 1, \dots, 25$ matter. Their squares end in $00, 01, 04, 09, 16, 25, 36, 49, 64, 81, 00, 21, 44, 69, 96, 25, 56, 89, 24, 61, 00, 41, 84, 29, 76, 25$. Removing repeats ($00$ appears three times, $25$ three times), there are $26 - 4 = 22$ different endings.",
  "Counting the $26$ residues without removing repeated endings.",
  "C23A-squares-last-two", "Requires reducing to $0$ to $25$ by symmetry and then checking for repeats.",
  tita_answer=22, check=_c28,
  tita_traps=[(26, "Lists $r = 0$ to $25$ and does not remove the repeated endings $00$ and $25$."),
              (6, "Counts only the possible unit digits $0, 1, 4, 5, 6, 9$.")],
  cognitive="Analysis", exams=HEAVY)

# 029 ---------------------------------------------------------------
def _c29():
    good = [x for x in range(100) if pow(x, 3, 100) == 11]
    assert len(good) == 1
    return good[0]
q("C23-A-029", T, "Recovering the last two digits of a number from those of its cube", "Difficult",
  "Inverse/parameter",
  r"A positive integer $x$ is such that $x^3$ ends in the digits $11$. What are the last two digits of $x$?",
  "MCQ",
  r"Cubes of $0$ to $9$ end in $0, 1, 8, 7, 4, 5, 6, 3, 2, 9$, all different, so $x^3$ ends in $1$ only if $x$ ends in $1$. Write $x = 10t + 1$. Then $x^3 = 1000t^3 + 300t^2 + 30t + 1 \equiv 30t + 1 \pmod{100}$. We need the tens digit of $30t$ to be $1$, that is $3t \equiv 1 \pmod{10}$, so $t \equiv 7$. Check: $71^3 = 357911$. The last two digits of $x$ are $71$.",
  r"Solving $3t \equiv 1 \pmod{10}$ carelessly, or dropping the factor $3$.",
  "C23A-cube-last-two-inverse", "Reverse problem: a binomial expansion plus a modular inverse.",
  correct=r"$71$",
  distractors=[(r"$31$", "Slips the sign and solves $3t \\equiv -1 \\equiv 9 \\pmod{10}$, getting $t = 3$."),
               (r"$11$", "Drops the factor $3$ in $30t$ and solves $t \\equiv 1$."),
               (r"$91$", "Drops the factor $3$ and slips the sign, solving $t \\equiv -1 \\equiv 9$.")],
  check=_c29, values=[71, 31, 11, 91], cognitive="Analysis", exams=HEAVY)

# 030 ---------------------------------------------------------------
def _c30():
    return (_pow_mod_sim(7, 93, 100) + _pow_mod_sim(3, 93, 100)) % 100
q("C23-A-030", T, "Last two digits of a sum of powers with different periods", "Difficult",
  "Multi-step word problem",
  r"What are the last two digits of $7^{93} + 3^{93}$?",
  "MCQ",
  r"$7^4 = 2401$ ends in $01$, so powers of $7$ repeat their last two digits with period $4$; $93 = 4 \times 23 + 1$, so $7^{93}$ ends in $07$. For $3$, $3^{10}$ ends in $49$ and $49^2 = 2401$, so $3^{20}$ ends in $01$ and the period is $20$; $93 = 20 \times 4 + 13$, so $3^{93}$ ends like $3^{13} = 3^{10} \times 3^3$, that is like $49 \times 27 = 1323$, in $23$. The sum ends like $07 + 23 = 30$.",
  "Applying the period $4$ of $7$ to the powers of $3$ as well.",
  "C23A-last-two-sum-mixed-cycles", "Two different periods modulo $100$ ($4$ and $20$) in one expression.",
  correct=r"$30$",
  distractors=[(r"$10$", "Uses period $4$ for powers of $3$ as well, taking $3^{93}$ as ending like $3^1 = 03$."),
               (r"$70$", "Assumes the last two digits of every power repeat with period $10$, so reduces $93$ to $3$ for both bases: $7^3 + 3^3 = 343 + 27 = 370$."),
               (r"$50$", "Writes $3^{93} = 81^{23} \\times 3$ and assumes every power of $81$ ends in $81$, so $3^{93}$ ends like $81 \\times 3 = 243$, in $43$: $07 + 43 = 50$.")],
  check=_c30, values=[30, 10, 70, 50], cognitive="Analysis", exams=HEAVY)
