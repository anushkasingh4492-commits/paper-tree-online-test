import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

from itertools import combinations, product, permutations

T = "Conditional and compound probability"
CX = ("CAT", "XAT")
F = Fraction


def _indep(ps):
    """All success/failure patterns of independent trials with success probabilities ps."""
    out = []
    for pat in product((1, 0), repeat=len(ps)):
        pr = F(1)
        for s, p in zip(pat, ps):
            pr *= p if s else 1 - p
        out.append((pat, pr))
    return out


DICE = list(product(range(1, 7), repeat=2))

# ================================================================ EASY (12)

def _e1():
    ps = [F(2, 3), F(3, 4), F(4, 5)]
    return sum(pr for pat, pr in _indep(ps) if 0 in pat)
q("C26-B-001", T, "At least one of three independent flights delayed, via the complement", "Easy",
  "Single-step computation",
  r"Three flights leave Pune for different cities on the same morning. Independently of one another, they depart on time with probabilities $\frac{2}{3}$, $\frac{3}{4}$ and $\frac{4}{5}$ respectively. What is the probability that at least one of the three flights is delayed?",
  "MCQ",
  r"All three are on time with probability $\frac{2}{3} \times \frac{3}{4} \times \frac{4}{5} = \frac{2}{5}$. At least one is delayed is the complement, so the probability is $1 - \frac{2}{5} = \frac{3}{5}$.",
  "Adding the individual delay probabilities, or stopping at the probability that all are on time.",
  "C26B-at-least-one-complement", "One product and one complement; the trap is adding the delay probabilities.",
  correct=r"$\frac{3}{5}$",
  distractors=[(r"$\frac{2}{5}$", r"Stops at the probability that all three are on time, $\frac{2}{3} \cdot \frac{3}{4} \cdot \frac{4}{5}$."),
               (r"$\frac{47}{60}$", r"Adds the delay probabilities: $\frac{1}{3} + \frac{1}{4} + \frac{1}{5} = \frac{47}{60}$."),
               (r"$\frac{1}{60}$", r"Computes the probability that all three are delayed: $\frac{1}{3} \cdot \frac{1}{4} \cdot \frac{1}{5}$.")],
  check=_e1, values=[F(3, 5), F(2, 5), F(47, 60), F(1, 60)], cognitive="Application")


def _e2():
    ps = [F(1, 2), F(1, 3), F(1, 4)]
    return 100 * sum(pr for pat, pr in _indep(ps) if 1 in pat)
q("C26-B-002", T, "Puzzle solved by at least one of three independent solvers, 100p", "Easy",
  "Single-step computation",
  r"Ravi, Meera and Kabir try to solve a puzzle independently of one another. Their probabilities of solving it are $\frac{1}{2}$, $\frac{1}{3}$ and $\frac{1}{4}$ respectively. If $p$ is the probability that the puzzle gets solved (by at least one of them), what is the value of $100p$?",
  "TITA",
  r"The puzzle stays unsolved only if all three fail: $\frac{1}{2} \times \frac{2}{3} \times \frac{3}{4} = \frac{1}{4}$. So $p = 1 - \frac{1}{4} = \frac{3}{4}$ and $100p = 75$.",
  "Adding the three probabilities (which exceeds $1$) or reporting the probability that nobody solves it.",
  "C26B-at-least-one-complement", "Single complement of a product of three failure probabilities.",
  tita_answer=75, check=_e2,
  tita_traps=[(25, r"Reports the probability that nobody solves it, $\frac{1}{4}$."),
              ],
  cognitive="Application")


def _e3():
    ps = [F(2, 5), F(1, 2), F(3, 4)]
    return sum(pr for pat, pr in _indep(ps) if sum(pat) == 1)
q("C26-B-003", T, "Exactly one of three independent solvers succeeds", "Easy",
  "Multi-step word problem",
  r"Priya, Joseph and Fatima each attempt a hard aptitude question independently. They answer it correctly with probabilities $\frac{2}{5}$, $\frac{1}{2}$ and $\frac{3}{4}$ respectively. What is the probability that exactly one of the three answers it correctly?",
  "MCQ",
  r"Add the three ways in which exactly one succeeds: $\frac{2}{5} \cdot \frac{1}{2} \cdot \frac{1}{4} + \frac{3}{5} \cdot \frac{1}{2} \cdot \frac{1}{4} + \frac{3}{5} \cdot \frac{1}{2} \cdot \frac{3}{4} = \frac{2 + 3 + 9}{40} = \frac{14}{40} = \frac{7}{20}$.",
  "Treating 'exactly one' as 'at least one', or computing only one of the three cases.",
  "C26B-exactly-k-independent", "Three disjoint cases, each a product of three factors.",
  correct=r"$\frac{7}{20}$",
  distractors=[(r"$\frac{17}{40}$", r"Computes exactly two correct: $\frac{2 + 6 + 9}{40}$."),
               (r"$\frac{37}{40}$", r"Computes at least one correct: $1 - \frac{3}{5} \cdot \frac{1}{2} \cdot \frac{1}{4} = \frac{37}{40}$."),
               (r"$\frac{1}{20}$", r"Takes only the case where Priya alone is correct: $\frac{2}{5} \cdot \frac{1}{2} \cdot \frac{1}{4} = \frac{1}{20}$.")],
  check=_e3, values=[F(7, 20), F(17, 40), F(37, 40), F(1, 20)], cognitive="Application")


def _e4():
    ps = [F(4, 5), F(3, 4)]
    return 100 * sum(pr for pat, pr in _indep(ps) if sum(pat) == 1)
q("C26-B-004", T, "Exactly one of two independent commuters on time, 100p", "Easy",
  "Single-step computation",
  r"Arjun and Sneha travel to office by different routes. On any day, independently, Arjun reaches on time with probability $\frac{4}{5}$ and Sneha with probability $\frac{3}{4}$. If $p$ is the probability that on a given day exactly one of them reaches on time, what is the value of $100p$?",
  "TITA",
  r"Either Arjun is on time and Sneha is late, $\frac{4}{5} \cdot \frac{1}{4} = \frac{1}{5}$, or Sneha is on time and Arjun is late, $\frac{1}{5} \cdot \frac{3}{4} = \frac{3}{20}$. So $p = \frac{4}{20} + \frac{3}{20} = \frac{7}{20}$ and $100p = 35$.",
  "Answering 'both on time' or 'at least one on time' instead of exactly one.",
  "C26B-exactly-k-independent", "Two disjoint cases of a product of two factors.",
  tita_answer=35, check=_e4,
  tita_traps=[(60, r"Computes both on time, $\frac{4}{5} \cdot \frac{3}{4} = \frac{3}{5}$."),
              (95, r"Computes at least one on time, $1 - \frac{1}{5} \cdot \frac{1}{4} = \frac{19}{20}$.")],
  cognitive="Application")


def _e5():
    ps = [F(2, 3)] * 5
    return sum(pr for pat, pr in _indep(ps) if sum(pat) == 3)
q("C26-B-005", T, "Exactly 3 successes in 5 independent trials with p = 2/3", "Easy",
  "Single-step computation",
  r"A delivery rider completes each order on time with probability $\frac{2}{3}$, independently of the other orders. On a particular evening he has $5$ orders. What is the probability that exactly $3$ of the $5$ orders are delivered on time?",
  "MCQ",
  r"Choose which $3$ orders are on time in $\binom{5}{3} = 10$ ways; each such pattern has probability $\left(\frac{2}{3}\right)^3 \left(\frac{1}{3}\right)^2 = \frac{8}{243}$. The probability is $10 \times \frac{8}{243} = \frac{80}{243}$.",
  r"Forgetting the factor $\binom{5}{3}$ for the positions of the on-time orders.",
  "C26B-binomial-repeated-trials", "Direct binomial count; one trap (the arrangement factor).",
  correct=r"$\frac{80}{243}$",
  distractors=[(r"$\frac{8}{243}$", r"Omits $\binom{5}{3}$ and uses one fixed pattern: $\left(\frac{2}{3}\right)^3 \left(\frac{1}{3}\right)^2$."),
               (r"$\frac{5}{16}$", r"Treats each order as on time with probability $\frac{1}{2}$: $\binom{5}{3} / 2^5 = \frac{10}{32}$."),
               (r"$\frac{64}{81}$", r"Computes at least $3$ on time: $\frac{80 + 80 + 32}{243} = \frac{192}{243}$.")],
  check=_e5, values=[F(80, 243), F(8, 243), F(5, 16), F(64, 81)], cognitive="Application")


def _e6():
    pens = ["R"] * 6 + ["B"] * 4
    seqs = list(permutations(range(10), 2))
    good = sum(1 for i, j in seqs if pens[i] == "R" and pens[j] == "B")
    return F(good, len(seqs))
q("C26-B-006", T, "Specified colour order in two draws without replacement", "Easy",
  "Single-step computation",
  r"A box contains $6$ red pens and $4$ blue pens. Ananya takes out two pens one after the other at random, without putting the first one back. What is the probability that the first pen is red and the second pen is blue?",
  "MCQ",
  r"First red: $\frac{6}{10}$. After that, $9$ pens remain of which $4$ are blue, so second blue: $\frac{4}{9}$. The probability is $\frac{6}{10} \times \frac{4}{9} = \frac{24}{90} = \frac{4}{15}$.",
  "Ignoring the order asked for, or treating the draws as with replacement.",
  "C26B-sequential-draw-no-replacement", "Two-step product with a changed denominator; the order trap.",
  correct=r"$\frac{4}{15}$",
  distractors=[(r"$\frac{8}{15}$", r"Counts one red and one blue in either order: $2 \times \frac{4}{15}$."),
               (r"$\frac{6}{25}$", r"Replaces the first pen: $\frac{6}{10} \times \frac{4}{10}$."),
               (r"$\frac{1}{3}$", r"Computes both red: $\frac{6}{10} \times \frac{5}{9} = \frac{30}{90}$.")],
  check=_e6, values=[F(4, 15), F(8, 15), F(6, 25), F(1, 3)], cognitive="Application")


def _e7():
    bulbs = ["D", "D", "G", "G", "G"]
    perms = list(permutations(range(5)))
    good = 0
    for p in perms:
        first_def = next(k for k, i in enumerate(p) if bulbs[i] == "D") + 1
        good += first_def == 3
    return 100 * F(good, len(perms))
q("C26-B-007", T, "Test number at which the first defective is found, 100p", "Easy",
  "Multi-step word problem",
  r"A carton has $5$ bulbs, of which exactly $2$ are defective. An inspector tests the bulbs one at a time, chosen at random and without replacement, and stops as soon as she finds a defective bulb. If $p$ is the probability that she stops exactly at the third test, what is the value of $100p$?",
  "TITA",
  r"She needs good, good, defective: $\frac{3}{5} \times \frac{2}{4} \times \frac{2}{3} = \frac{12}{60} = \frac{1}{5}$. So $100p = 20$.",
  "Computing only that the first two are good, or not reducing the denominator at the third draw.",
  "C26B-sequential-draw-no-replacement", "Three-factor product with shrinking denominators.",
  tita_answer=20, check=_e7,
  tita_traps=[(30, r"Computes only that the first two bulbs are good, $\frac{3}{5} \cdot \frac{2}{4}$, which means more than two tests."),
              (12, r"Keeps the denominator $5$ at the third test: $\frac{3}{5} \cdot \frac{2}{4} \cdot \frac{2}{5} = \frac{12}{100}$.")],
  cognitive="Application")


def _e8():
    fee = 20
    prize = {6: 60, 5: 30}
    exp_net = sum(F(prize.get(f, 0) - fee, 6) for f in range(1, 7))
    return -exp_net
q("C26-B-008", T, "Expected loss per play of a dice stall game", "Easy",
  "Single-step computation",
  r"At a fair, a stall charges Rs. $20$ per play. The player rolls a fair die once. If it shows $6$ the player receives Rs. $60$, if it shows $5$ the player receives Rs. $30$, and otherwise the player receives nothing. The Rs. $20$ is not returned in any case. What is the player's expected loss per play, in rupees?",
  "TITA",
  r"Expected amount received $= \frac{1}{6}(60) + \frac{1}{6}(30) = 10 + 5 = 15$ rupees. The player pays Rs. $20$, so the expected loss per play is $20 - 15 = 5$ rupees.",
  "Reporting the expected prize instead of subtracting it from the fee.",
  "C26B-expected-value-fair-game", "One expectation and one subtraction.",
  tita_answer=5, check=_e8,
  tita_traps=[(15, "Reports the expected amount received instead of the expected loss.")],
  cognitive="Application")


def _e9():
    space = [d for d in DICE if sum(d) == 8]
    fav = [d for d in space if 3 in d]
    return F(len(fav), len(space))
q("C26-B-009", T, "Two dice: a face value given the sum", "Easy",
  "Conceptual/application",
  r"Kabir rolls two fair dice, one red and one green, and tells you only that the sum of the two numbers is $8$. Given this, what is the probability that one of the dice shows $3$?",
  "MCQ",
  r"The ordered outcomes with sum $8$ are $(2,6), (3,5), (4,4), (5,3), (6,2)$: five equally likely cases. Two of them contain a $3$. The probability is $\frac{2}{5}$.",
  "Using unordered pairs as equally likely, or not restricting to the sum-8 outcomes.",
  "C26B-conditional-reduced-space", "Reduced sample space of five outcomes; trap of unordered pairs.",
  correct=r"$\frac{2}{5}$",
  distractors=[(r"$\frac{1}{3}$", r"Treats the unordered pairs $\{2,6\}, \{3,5\}, \{4,4\}$ as equally likely."),
               (r"$\frac{1}{18}$", r"Computes the joint probability of sum $8$ with a $3$ showing: $\frac{2}{36}$."),
               (r"$\frac{11}{36}$", r"Ignores the condition and computes the probability that at least one die shows $3$.")],
  check=_e9, values=[F(2, 5), F(1, 3), F(1, 18), F(11, 36)], cognitive="Understanding")


def _e10():
    M, Ph, both = F(60, 100), F(40, 100), F(25, 100)
    return both / Ph
q("C26-B-010", T, "Conditional probability from overlapping percentages", "Easy",
  "Single-step computation",
  r"In a junior college, $60\%$ of the students take Mathematics, $40\%$ take Physics and $25\%$ take both. A student chosen at random is found to take Physics. What is the probability that this student also takes Mathematics?",
  "MCQ",
  r"Restrict to the Physics students. $P(\text{Maths} \mid \text{Physics}) = \frac{P(\text{both})}{P(\text{Physics})} = \frac{25}{40} = \frac{5}{8}$.",
  "Dividing by the wrong marginal, or ignoring the given information.",
  r"C26B-conditional-reduced-space", r"Direct use of $P(A \cap B)/P(B)$.",
  correct=r"$\frac{5}{8}$",
  distractors=[(r"$\frac{5}{12}$", r"Divides by the Mathematics share: $\frac{25}{60}$, which is $P(\text{Physics} \mid \text{Maths})$."),
               (r"$\frac{3}{5}$", r"Ignores the condition and gives the share taking Mathematics."),
               (r"$\frac{1}{4}$", r"Reports the unconditional share taking both subjects.")],
  check=_e10, values=[F(5, 8), F(5, 12), F(3, 5), F(1, 4)], cognitive="Understanding")


def _e11():
    pats = _indep([F(1, 3), F(1, 3)])
    cond = sum(pr for pat, pr in pats if sum(pat) >= 1)
    both = sum(pr for pat, pr in pats if sum(pat) == 2)
    return both / cond
q("C26-B-011", T, "Both events given at least one, two independent machines", "Easy",
  "Conceptual/application",
  r"An office has two printers. On any day, each printer jams with probability $\frac{1}{3}$, independently of the other. At the end of a day the manager learns that at least one printer jammed that day. What is the probability that both printers jammed?",
  "MCQ",
  r"$P(\text{at least one}) = 1 - \left(\frac{2}{3}\right)^2 = \frac{5}{9}$ and $P(\text{both}) = \frac{1}{9}$. Hence $P(\text{both} \mid \text{at least one}) = \frac{1/9}{5/9} = \frac{1}{5}$.",
  r"Thinking the information concerns one particular printer, so that the other jams with probability $\frac{1}{3}$.",
  "C26B-conditional-at-least-one-given", "Simple ratio once the conditioning event is computed; trap of fixing one printer.",
  correct=r"$\frac{1}{5}$",
  distractors=[(r"$\frac{1}{3}$", r"Assumes a particular printer is known to have jammed and asks only about the other."),
               (r"$\frac{1}{9}$", r"Ignores the condition: $\left(\frac{1}{3}\right)^2$."),
               (r"$\frac{1}{4}$", r"Divides by the probability of exactly one jam, $\frac{4}{9}$, instead of at least one.")],
  check=_e11, values=[F(1, 5), F(1, 3), F(1, 9), F(1, 4)], cognitive="Understanding")


def _e12():
    bags = {"P": ["W"] * 3 + ["K"] * 2, "Q": ["W"] * 2 + ["K"] * 4}
    tot = F(0)
    for coin in ("H", "T"):
        b = bags["P" if coin == "H" else "Q"]
        tot += F(1, 2) * F(b.count("W"), len(b))
    return tot
q("C26-B-012", T, "Total probability over a coin-selected bag", "Easy",
  "Multi-step word problem",
  r"Bag P contains $3$ white and $2$ black balls; bag Q contains $2$ white and $4$ black balls. Harpreet tosses a fair coin: on heads she draws one ball at random from bag P, on tails one ball at random from bag Q. What is the probability that the ball she draws is white?",
  "MCQ",
  r"By total probability, $P(\text{white}) = \frac{1}{2} \cdot \frac{3}{5} + \frac{1}{2} \cdot \frac{2}{6} = \frac{3}{10} + \frac{1}{6} = \frac{9 + 5}{30} = \frac{7}{15}$.",
  "Pooling the two bags into one, which ignores that each bag is equally likely to be chosen.",
  "C26B-total-probability-two-urns", "Two-branch total probability.",
  correct=r"$\frac{7}{15}$",
  distractors=[(r"$\frac{5}{11}$", r"Pools both bags: $\frac{3 + 2}{5 + 6}$."),
               (r"$\frac{14}{15}$", r"Adds $\frac{3}{5} + \frac{1}{3}$ without the coin factor $\frac{1}{2}$."),
               (r"$\frac{1}{5}$", r"Multiplies the two white probabilities, $\frac{3}{5} \cdot \frac{1}{3}$.")],
  check=_e12, values=[F(7, 15), F(5, 11), F(14, 15), F(1, 5)], cognitive="Application")

# ================================================================ MEDIUM (18)

def _m1():
    p, n = F(1, 3), 1
    while not (1 - (1 - p) ** n > F(9, 10)):
        n += 1
    return n
q("C26-B-013", T, "Least number of shots for P(at least one hit) above a threshold", "Medium",
  "Inverse/parameter",
  r"A trainee archer hits the bullseye with probability $\frac{1}{3}$ on each shot, independently of other shots. What is the least number of shots she must take so that the probability of hitting the bullseye at least once is more than $\frac{9}{10}$?",
  "TITA",
  r"We need $1 - \left(\frac{2}{3}\right)^n > \frac{9}{10}$, that is $\left(\frac{2}{3}\right)^n < \frac{1}{10}$. Now $\left(\frac{2}{3}\right)^5 = \frac{32}{243} \approx 0.132$ and $\left(\frac{2}{3}\right)^6 = \frac{64}{729} \approx 0.088$. The least $n$ is $6$.",
  r"Using the expected number of hits, $\frac{n}{3}$, instead of the complement.",
  "C26B-min-trials-threshold", "Inequality on a power solved by trying successive values.",
  tita_answer=6, check=_m1,
  tita_traps=[(3, r"Requires the expected hits $\frac{n}{3}$ to reach $0.9$."),
              ],
  cognitive="Application")


def _m2():
    p = symbols('p', positive=True)
    sols = [s for s in solve(Eq(1 - (1 - p) ** 4, F(65, 81)), p) if s.is_real and 0 < s < 1]
    return sols[0]
q("C26-B-014", T, "Find single-trial probability from P(at least one) over 4 trials", "Medium",
  "Inverse/parameter",
  r"Joseph takes $4$ free throws in a basketball practice. Each throw scores with the same probability, independently of the others. The probability that he scores at least once in the $4$ throws is $\frac{65}{81}$. What is the probability that a single throw scores?",
  "MCQ",
  r"$P(\text{no score in } 4) = 1 - \frac{65}{81} = \frac{16}{81} = \left(\frac{2}{3}\right)^4$. So a single throw misses with probability $\frac{2}{3}$ and scores with probability $\frac{1}{3}$.",
  "Reporting the miss probability, or dividing the at-least-one probability by the number of throws.",
  "C26B-min-trials-threshold", "Reverse use of the complement rule with a fourth root.",
  correct=r"$\frac{1}{3}$",
  distractors=[(r"$\frac{2}{3}$", r"Reports the probability of missing a single throw."),
               (r"$\frac{65}{324}$", r"Divides $\frac{65}{81}$ by $4$, as if the four throws were mutually exclusive."),
               (r"$\frac{16}{81}$", r"Reports the probability of no score in all four throws.")],
  check=_m2, values=[F(1, 3), F(2, 3), F(65, 324), F(16, 81)], cognitive="Application")


def _m3():
    ps = [F(3, 5), F(1, 2), F(4, 5)]
    return 100 * sum(pr for pat, pr in _indep(ps) if sum(pat) >= 2)
q("C26-B-015", T, "Majority approval by three independent judges, 100p", "Medium",
  "Multi-step word problem",
  r"A candidate is interviewed by three panelists who decide independently. They approve the candidate with probabilities $\frac{3}{5}$, $\frac{1}{2}$ and $\frac{4}{5}$ respectively. The candidate is selected if at least two of the three panelists approve. If $p$ is the probability that the candidate is selected, what is the value of $100p$?",
  "TITA",
  r"All three approve: $\frac{3}{5} \cdot \frac{1}{2} \cdot \frac{4}{5} = \frac{12}{50}$. Exactly two approve: $\frac{3}{5} \cdot \frac{1}{2} \cdot \frac{1}{5} + \frac{3}{5} \cdot \frac{1}{2} \cdot \frac{4}{5} + \frac{2}{5} \cdot \frac{1}{2} \cdot \frac{4}{5} = \frac{3 + 12 + 8}{50} = \frac{23}{50}$. So $p = \frac{35}{50} = \frac{7}{10}$ and $100p = 70$.",
  "Counting only the exactly-two cases, or only the all-three case.",
  "C26B-exactly-k-independent", "Four disjoint cases combined; easy to miss one.",
  tita_answer=70, check=_m3,
  tita_traps=[(46, r"Counts only exactly two approvals, $\frac{23}{50}$."),
              (24, r"Counts only all three approving, $\frac{12}{50}$.")],
  cognitive="Application")


def _m4():
    balls = ["R"] * 4 + ["G"] * 7
    seqs = list(permutations(range(11), 3))
    return F(sum(1 for s in seqs if balls[s[2]] == "R"), len(seqs))
q("C26-B-016", T, "Probability that the k-th draw is a given colour, by symmetry", "Medium",
  "Conceptual/application",
  r"A jar holds $4$ red and $7$ green marbles. Fatima draws three marbles one after another at random, without replacement, and keeps the first two in her fist without looking at them. What is the probability that the third marble she draws is red?",
  "MCQ",
  r"Before any colour is seen, every position in the drawing order is equally likely to hold any of the $11$ marbles, so the third marble is red with the same probability as the first: $\frac{4}{11}$. Directly: summing over the colour patterns of the first two draws, $\frac{4 \cdot 3 \cdot 2 + 2 \cdot 4 \cdot 7 \cdot 3 + 7 \cdot 6 \cdot 4}{11 \cdot 10 \cdot 9} = \frac{360}{990} = \frac{4}{11}$.",
  "Assuming something about the unseen first two marbles, or computing the probability that the third is the first red.",
  "C26B-symmetry-kth-draw", "Requires seeing that unseen earlier draws do not change the marginal probability.",
  correct=r"$\frac{4}{11}$",
  distractors=[(r"$\frac{4}{9}$", "Assumes the first two marbles were both green."),
               (r"$\frac{2}{9}$", "Assumes the first two marbles were both red."),
               (r"$\frac{28}{165}$", r"Computes green, green, red: $\frac{7}{11} \cdot \frac{6}{10} \cdot \frac{4}{9}$.")],
  check=_m4, values=[F(4, 11), F(4, 9), F(2, 9), F(28, 165)], cognitive="Analysis")


def _m5():
    balls = "RRRRBBBGG"
    arr = set(permutations(balls))
    good = 0
    for a in arr:
        firstB = a.index("B"); firstG = a.index("G")
        good += firstB < firstG
    return F(good, len(arr))
q("C26-B-017", T, "One colour appearing before another, ignoring a third colour", "Medium",
  "Conceptual/application",
  r"A bag has $4$ red, $3$ blue and $2$ green balls. Sneha draws the balls one at a time at random, without replacement, until the bag is empty. What is the probability that the first blue ball appears before the first green ball?",
  "MCQ",
  r"Red balls do not affect which of blue and green comes first. Look only at the $5$ blue and green balls: their relative order is a random arrangement, so the earliest of them is blue with probability $\frac{3}{5}$.",
  "Letting the red balls enter the calculation, or treating the two colours as equally likely.",
  "C26B-symmetry-kth-draw", "Needs the insight that the irrelevant colour can be ignored.",
  correct=r"$\frac{3}{5}$",
  distractors=[(r"$\frac{1}{3}$", r"Computes the probability that the very first ball is blue, $\frac{3}{9}$."),
               (r"$\frac{2}{5}$", "Reports the complementary event, the first green ball appearing before the first blue ball."),
               (r"$\frac{1}{2}$", "Treats blue first and green first as equally likely outcomes.")],
  check=_m5, values=[F(3, 5), F(1, 3), F(2, 5), F(1, 2)], cognitive="Analysis")


def _m6():
    car, two, both = F(70, 100), F(50, 100), F(30, 100)
    either = car + two - both
    return both / either
q("C26-B-018", T, "Both given at least one, from survey percentages", "Medium",
  "Multi-step word problem",
  r"In a housing society, $70\%$ of the households own a car, $50\%$ own a two-wheeler and $30\%$ own both. A household chosen at random is found to own at least one of the two kinds of vehicle. What is the probability that it owns both?",
  "MCQ",
  r"$P(\text{at least one}) = 70\% + 50\% - 30\% = 90\%$. Hence $P(\text{both} \mid \text{at least one}) = \frac{30}{90} = \frac{1}{3}$.",
  "Conditioning on only one of the two kinds of vehicle, or ignoring the condition.",
  "C26B-conditional-reduced-space", "Needs inclusion-exclusion for the conditioning event first.",
  correct=r"$\frac{1}{3}$",
  distractors=[(r"$\frac{3}{7}$", r"Conditions on owning a car: $\frac{30}{70}$."),
               (r"$\frac{3}{5}$", r"Conditions on owning a two-wheeler: $\frac{30}{50}$."),
               (r"$\frac{3}{10}$", "Ignores the condition and gives the share owning both.")],
  check=_m6, values=[F(1, 3), F(3, 7), F(3, 5), F(3, 10)], cognitive="Application")


def _m7():
    space = [d for d in DICE if 5 in d]
    fav = [d for d in space if sum(d) >= 10]
    return F(len(fav), len(space))
q("C26-B-019", T, "Two dice: sum condition given at least one specific face", "Medium",
  "Conceptual/application",
  r"Meera rolls two fair dice. Her friend checks whether at least one die shows a $5$ and says that one does. Given this, what is the probability that the sum of the two numbers is $10$ or more?",
  "MCQ",
  r"Outcomes with at least one $5$: $6 + 6 - 1 = 11$ ordered pairs. Among them, the sum is at least $10$ for $(5,5), (5,6), (6,5)$. The probability is $\frac{3}{11}$.",
  "Counting $(5,5)$ twice, using unordered pairs, or ignoring the information.",
  "C26B-conditional-at-least-one-given", "Requires counting the conditioning set correctly (11, not 12).",
  correct=r"$\frac{3}{11}$",
  distractors=[(r"$\frac{1}{3}$", r"Counts $12$ outcomes with $(5,5)$ twice and $4$ favourable ones, or uses $6$ unordered pairs with $2$ favourable."),
               (r"$\frac{1}{6}$", r"Ignores the information: $\frac{6}{36}$ outcomes have sum at least $10$."),
               (r"$\frac{1}{12}$", r"Gives the joint probability $\frac{3}{36}$ instead of conditioning.")],
  check=_m7, values=[F(3, 11), F(1, 3), F(1, 6), F(1, 12)], cognitive="Analysis")


def _m8():
    urns = {"P": (4, 1), "Q": (2, 3)}
    joint = {}
    for face in range(1, 7):
        u = "P" if face <= 2 else "Q"
        r, b = urns[u]
        joint[u] = joint.get(u, 0) + F(1, 6) * F(r, r + b)
    return joint["P"] / (joint["P"] + joint["Q"])
q("C26-B-020", T, "Reverse probability of the source urn given the colour drawn", "Medium",
  "Conceptual/application",
  r"Urn P has $4$ red and $1$ blue ball; urn Q has $2$ red and $3$ blue balls. Kabir rolls a fair die: if it shows $1$ or $2$ he draws a ball at random from urn P, otherwise from urn Q. The ball drawn is red. What is the probability that it came from urn P?",
  "MCQ",
  r"$P(\text{P and red}) = \frac{1}{3} \cdot \frac{4}{5} = \frac{4}{15}$ and $P(\text{Q and red}) = \frac{2}{3} \cdot \frac{2}{5} = \frac{4}{15}$. The two routes to red are equally likely, so the required probability is $\frac{4/15}{8/15} = \frac{1}{2}$.",
  "Using only the prior (the die) or only the red share of urn P.",
  "C26B-total-probability-two-urns", "Bayes in two branches; the prior and the likelihood pull in opposite directions.",
  correct=r"$\frac{1}{2}$",
  distractors=[(r"$\frac{1}{3}$", "Gives the prior probability of choosing urn P and ignores the colour."),
               (r"$\frac{4}{5}$", "Gives the probability of red from urn P, the reverse conditional."),
               (r"$\frac{2}{3}$", r"Ignores the die and pools the red balls: $\frac{4}{4 + 2}$.")],
  check=_m8, values=[F(1, 2), F(1, 3), F(4, 5), F(2, 3)], cognitive="Analysis")


def _m9():
    share = [F(50, 100), F(30, 100), F(20, 100)]
    rate = [F(2, 100), F(3, 100), F(4, 100)]
    joint = [s * r for s, r in zip(share, rate)]
    return joint[2] / sum(joint)
q("C26-B-021", T, "Which machine produced a defective item", "Medium",
  "Multi-step word problem",
  r"A factory makes $50\%$, $30\%$ and $20\%$ of its bolts on machines X, Y and Z respectively. The percentages of defective bolts from these machines are $2\%$, $3\%$ and $4\%$ respectively. A bolt picked at random from the day's output is defective. What is the probability that it was made on machine Z?",
  "MCQ",
  r"Per $10{,}000$ bolts: X gives $5000 \times 0.02 = 100$ defectives, Y gives $3000 \times 0.03 = 90$ and Z gives $2000 \times 0.04 = 80$. Of $270$ defectives, $80$ are from Z, so the probability is $\frac{80}{270} = \frac{8}{27}$.",
  "Using the production share or the defect rate alone instead of the share of defectives.",
  "C26B-bayes-defect-test", "Three-branch Bayes with small numbers.",
  correct=r"$\frac{8}{27}$",
  distractors=[(r"$\frac{4}{9}$", r"Ignores the production shares and compares the defect rates alone: $\frac{4}{2 + 3 + 4}$."),
               (r"$\frac{1}{5}$", "Gives machine Z's share of total production."),
               (r"$\frac{1}{25}$", "Gives machine Z's defect rate, the reverse conditional.")],
  check=_m9, values=[F(8, 27), F(4, 9), F(1, 5), F(1, 25)], cognitive="Application")


def _m10():
    prior, sens, fpr = F(1, 4), F(9, 10), F(1, 10)
    flag = prior * sens + (1 - prior) * fpr
    return 100 * prior * sens / flag
q("C26-B-022", T, "Posterior probability for a filter flag, 100p", "Medium",
  "Multi-step word problem",
  r"Of all the emails reaching an office inbox, $25\%$ are spam. A filter flags $90\%$ of spam emails and also wrongly flags $10\%$ of genuine emails. An email is flagged. If $p$ is the probability that it is actually spam, what is the value of $100p$?",
  "TITA",
  r"Per $100$ emails: $25$ spam, of which $22.5$ are flagged; $75$ genuine, of which $7.5$ are flagged. So $30$ are flagged and $p = \frac{22.5}{30} = \frac{3}{4}$. Hence $100p = 75$.",
  r"Confusing $P(\text{flag} \mid \text{spam})$ with $P(\text{spam} \mid \text{flag})$.",
  "C26B-bayes-defect-test", "Two-branch Bayes; the trap is reporting the detection rate.",
  tita_answer=75, check=_m10,
  tita_traps=[(90, "Reports the filter's detection rate for spam, the reverse conditional."),
              (30, "Reports the overall share of emails that are flagged."),
              (25, "Reports the prior share of spam and ignores the flag.")],
  cognitive="Application")


def _m11():
    p = F(1, 3)
    P = symbols('P')
    # first player wins now, or both fail and the game restarts
    return solve(Eq(P, p + (1 - p) ** 2 * P), P)[0]
q("C26-B-023", T, "Alternate turns, same success probability, first mover advantage", "Medium",
  "Multi-step word problem",
  r"Ravi and Meera take turns rolling a fair die, Ravi first, then Meera, then Ravi, and so on. The first person to roll a number greater than $4$ wins and the game stops. What is the probability that Ravi wins?",
  "MCQ",
  r"Each roll succeeds with probability $\frac{1}{3}$. If $P$ is Ravi's winning chance, then $P = \frac{1}{3} + \frac{2}{3} \cdot \frac{2}{3} P$, so $\frac{5}{9} P = \frac{1}{3}$ and $P = \frac{3}{5}$.",
  "Assuming the game is fair because both have the same chance on each roll.",
  "C26B-alternate-turns-geometric", "Infinite alternating game reduced to one equation.",
  correct=r"$\frac{3}{5}$",
  distractors=[(r"$\frac{1}{2}$", "Ignores the advantage of rolling first."),
               (r"$\frac{2}{5}$", "Gives Meera's winning probability."),
               (r"$\frac{1}{3}$", "Counts only Ravi's first roll.")],
  check=_m11, values=[F(3, 5), F(1, 2), F(2, 5), F(1, 3)], cognitive="Application")


def _m12():
    p1, p2 = F(1, 5), F(3, 8)
    # simulate many rounds exactly by summing the series symbolically
    k = symbols('k', integer=True, nonnegative=True)
    r = (1 - p1) * (1 - p2)
    joseph = summation((1 - p1) * p2 * r ** k, (k, 0, oo))
    return 100 * joseph
q("C26-B-024", T, "Alternate shots with different probabilities, second player wins, 100p", "Medium",
  "Multi-step word problem",
  r"Fatima and Joseph take turns shooting at a target, Fatima first. Fatima hits with probability $\frac{1}{5}$ on each of her shots and Joseph with probability $\frac{3}{8}$ on each of his, all shots independent. The first to hit wins and shooting stops. If $p$ is the probability that Joseph wins, what is the value of $100p$?",
  "TITA",
  r"A full round with no hit has probability $\frac{4}{5} \cdot \frac{5}{8} = \frac{1}{2}$. Joseph wins in a given round with probability $\frac{4}{5} \cdot \frac{3}{8} = \frac{3}{10}$, so $p = \frac{3}{10}(1 + \frac{1}{2} + \frac{1}{4} + \dots) = \frac{3}{10} \cdot 2 = \frac{3}{5}$ and $100p = 60$.",
  "Counting only the first round, or reporting the first shooter's chance.",
  "C26B-alternate-turns-geometric", "Geometric series with unequal probabilities.",
  tita_answer=60, check=_m12,
  tita_traps=[(40, "Reports Fatima's winning probability."),
              (30, r"Counts only Joseph's first shot: $\frac{4}{5} \cdot \frac{3}{8}$.")],
  cognitive="Application")


def _m13():
    p = F(2, 3)
    from functools import lru_cache
    @lru_cache(None)
    def win(a, b):
        if a == 3:
            return F(1)
        if b == 3:
            return F(0)
        return p * win(a + 1, b) + (1 - p) * win(a, b + 1)
    return win(0, 0)
q("C26-B-025", T, "Winning a first-to-3 series", "Medium",
  "Casework/optimisation",
  r"In a chess match the winner is the first player to win $3$ games; there are no drawn games. Arjun wins each game against Kabir with probability $\frac{2}{3}$, independently of other games. What is the probability that Arjun wins the match?",
  "MCQ",
  r"Arjun wins in $3$, $4$ or $5$ games, his last win coming in the final game: $\left(\frac{2}{3}\right)^3 \left[1 + \binom{3}{1}\frac{1}{3} + \binom{4}{2}\frac{1}{9}\right] = \frac{8}{27} \left[1 + 1 + \frac{2}{3}\right] = \frac{8}{27} \cdot \frac{8}{3} = \frac{64}{81}$.",
  "Omitting the arrangement counts of the earlier losses, or using a single game's probability.",
  "C26B-series-first-to-n", "Three cases by match length with arrangement factors.",
  correct=r"$\frac{64}{81}$",
  distractors=[(r"$\frac{104}{243}$", r"Leaves out the arrangement factors: $\frac{8}{27}\left(1 + \frac{1}{3} + \frac{1}{9}\right)$."),
               (r"$\frac{80}{243}$", r"Computes exactly $3$ wins in $5$ games, $\binom{5}{3}\left(\frac{2}{3}\right)^3\left(\frac{1}{3}\right)^2$."),
               (r"$\frac{8}{27}$", "Counts only a $3$-game sweep.")],
  check=_m13, values=[F(64, 81), F(104, 243), F(80, 243), F(8, 27)], cognitive="Application")


def _m14():
    cnt = 0
    for seq in product((0, 1), repeat=7):
        a = b = 0
        for g, w in enumerate(seq, 1):
            a += w; b += 1 - w
            if a == 4 or b == 4:
                cnt += g == 6
                break
    # each full 7-game sequence has probability 1/128; a series ending at game 6 appears once per extra game outcome
    return F(cnt, 128)
q("C26-B-026", T, "Length of a best-of-seven series between equal teams", "Medium",
  "Casework/optimisation",
  r"Two evenly matched teams play a best-of-seven series: the first team to win $4$ games wins the series and no further games are played. Each game is won by either team with probability $\frac{1}{2}$, independently, and there are no draws. What is the probability that the series lasts exactly $6$ games?",
  "MCQ",
  r"For a given team to win in exactly $6$ games it must win game $6$ and exactly $3$ of the first $5$: $\binom{5}{3}\left(\frac{1}{2}\right)^6 = \frac{10}{64}$. Either team can do this, so the probability is $\frac{20}{64} = \frac{5}{16}$.",
  "Forgetting that either team can win, or not requiring the last game to be won by the series winner.",
  "C26B-series-first-to-n", "Needs the last-game condition and the two-team doubling.",
  correct=r"$\frac{5}{16}$",
  distractors=[(r"$\frac{5}{32}$", r"Counts only one team winning in six games: $\frac{10}{64}$."),
               (r"$\frac{15}{32}$", r"Counts any $4$ wins out of $6$ for either team, $2\binom{6}{4}/64$, without requiring game $6$ to be the clincher."),
               (r"$\frac{1}{4}$", r"Treats the four possible lengths $4, 5, 6, 7$ as equally likely.")],
  check=_m14, values=[F(5, 16), F(5, 32), F(15, 32), F(1, 4)], cognitive="Analysis")


def _m15():
    P = ["R"] * 3 + ["G"] * 2
    Q = ["R"] * 2 + ["G"] * 4
    tot = F(0)
    for i in range(len(P)):
        Q2 = Q + [P[i]]
        tot += F(1, len(P)) * F(Q2.count("R"), len(Q2))
    return tot
q("C26-B-027", T, "Draw after transferring one ball between bags", "Medium",
  "Multi-step word problem",
  r"Bag P has $3$ red and $2$ green balls; bag Q has $2$ red and $4$ green balls. One ball is drawn at random from bag P and put into bag Q without its colour being noted. A ball is then drawn at random from bag Q. What is the probability that this ball is red?",
  "MCQ",
  r"If the transferred ball is red (probability $\frac{3}{5}$), bag Q has $3$ red out of $7$; if green (probability $\frac{2}{5}$), $2$ red out of $7$. So $P(\text{red}) = \frac{3}{5} \cdot \frac{3}{7} + \frac{2}{5} \cdot \frac{2}{7} = \frac{9 + 4}{35} = \frac{13}{35}$.",
  "Ignoring the transfer, or assuming the more likely colour was transferred.",
  "C26B-transfer-between-bags", "Two-branch total probability with a changed second bag.",
  correct=r"$\frac{13}{35}$",
  distractors=[(r"$\frac{1}{3}$", r"Ignores the transfer and uses bag Q as it was: $\frac{2}{6}$."),
               (r"$\frac{3}{7}$", "Assumes the transferred ball was red."),
               (r"$\frac{2}{7}$", "Assumes the transferred ball was green.")],
  check=_m15, values=[F(13, 35), F(1, 3), F(3, 7), F(2, 7)], cognitive="Application")


def _m16():
    x, y = symbols('x y', positive=True)
    sols = solve([Eq(x * y, F(3, 20)), Eq((1 - x) * (1 - y), F(3, 10))], [x, y], dict=True)
    best = max(max(s[x], s[y]) for s in sols)
    return 100 * best
q("C26-B-028", T, "Recover two independent probabilities from P(both) and P(neither), 100p", "Medium",
  "Inverse/parameter",
  r"Ravi and Meera appear for different entrance tests, and their results are independent. The probability that both of them qualify is $\frac{3}{20}$ and the probability that neither qualifies is $\frac{3}{10}$. Ravi is more likely to qualify than Meera. If $p$ is the probability that Ravi qualifies, what is the value of $100p$?",
  "TITA",
  r"Let the two probabilities be $x$ and $y$. Then $xy = \frac{3}{20}$ and $(1-x)(1-y) = 1 - (x + y) + xy = \frac{3}{10}$, so $x + y = \frac{17}{20}$. Thus $x, y$ are roots of $20t^2 - 17t + 3 = 0$, that is $(5t - 3)(4t - 1) = 0$, giving $\frac{3}{5}$ and $\frac{1}{4}$. Ravi's is $\frac{3}{5}$, so $100p = 60$.",
  "Reporting the sum of the two probabilities, or the smaller root.",
  "C26B-independence-solve-parameter", "Sum and product of two probabilities lead to a quadratic.",
  tita_answer=60, check=_m16,
  tita_traps=[(85, r"Reports $x + y = \frac{17}{20}$."),
              (25, "Reports Meera's probability, the smaller root.")],
  cognitive="Application")


def _m17():
    t1, t2 = F(3, 4), F(4, 5)
    agree = F(0); both_true = F(0)
    for (a, b), pr in _indep([t1, t2]):
        if a == b:
            agree += pr
            if a == 1:
                both_true += pr
    return both_true / agree
q("C26-B-029", T, "Two independent witnesses agree; probability both truthful", "Medium",
  "Conceptual/application",
  r"Ananya speaks the truth in $3$ out of $4$ cases and Harpreet in $4$ out of $5$ cases, independently. Each is asked the same question, which has only two possible answers, yes or no, and they give the same answer. What is the probability that both of them are telling the truth?",
  "MCQ",
  r"With only two possible answers, they agree exactly when both tell the truth ($\frac{3}{4} \cdot \frac{4}{5} = \frac{12}{20}$) or both lie ($\frac{1}{4} \cdot \frac{1}{5} = \frac{1}{20}$). So the required probability is $\frac{12/20}{13/20} = \frac{12}{13}$.",
  "Forgetting that two liars also agree, or not conditioning on agreement.",
  "C26B-truthful-reports", "Requires seeing both-lie as the only other way to agree, then conditioning.",
  correct=r"$\frac{12}{13}$",
  distractors=[(r"$\frac{3}{5}$", r"Does not condition on agreement: $\frac{3}{4} \cdot \frac{4}{5}$."),
               (r"$\frac{13}{20}$", "Reports the probability that they agree."),
               (r"$\frac{19}{20}$", r"Computes the probability that at least one tells the truth, $1 - \frac{1}{4} \cdot \frac{1}{5}$.")],
  check=_m17, values=[F(12, 13), F(3, 5), F(13, 20), F(19, 20)], cognitive="Analysis")


def _m18():
    g1, g2, sw = F(3, 5), F(1, 2), F(9, 10)
    tot = F(0)
    for (a, b, s), pr in _indep([g1, g2, sw]):
        if (a or b) and s:
            tot += pr
    return 100 * tot
q("C26-B-030", T, "Reliability of a parallel pair in series with one component, 100p", "Medium",
  "Multi-step word problem",
  r"A hospital's backup power has two generators connected so that power is available if at least one generator starts, but it also needs a changeover switch to work. In a power cut, the generators start with probabilities $\frac{3}{5}$ and $\frac{1}{2}$, and the switch works with probability $\frac{9}{10}$, all independently. If $p$ is the probability that backup power is available, what is the value of $100p$?",
  "TITA",
  r"Both generators fail with probability $\frac{2}{5} \cdot \frac{1}{2} = \frac{1}{5}$, so at least one starts with probability $\frac{4}{5}$. The switch must also work: $p = \frac{4}{5} \cdot \frac{9}{10} = \frac{18}{25}$, and $100p = 72$.",
  "Requiring all three components to work, or forgetting the switch.",
  "C26B-reliability-system", "Parallel block (complement) combined with a series factor.",
  tita_answer=72, check=_m18,
  tita_traps=[(27, r"Requires both generators and the switch: $\frac{3}{5} \cdot \frac{1}{2} \cdot \frac{9}{10}$."),
              (80, "Forgets the switch and reports only the generator block.")],
  cognitive="Application")

# ================================================================ DIFFICULT (10)

def _d1():
    p = F(1, 4); n = 1
    while True:
        p_le1 = sum(pr for pat, pr in _indep([p] * n) if sum(pat) <= 1)
        if 1 - p_le1 > F(1, 2):
            return n
        n += 1
q("C26-B-031", T, "Least number of trials for P(at least two successes) above one half", "Difficult",
  "Inverse/parameter",
  r"A salesperson converts each cold call into a sale with probability $\frac{1}{4}$, independently of other calls. What is the least number of calls she must make so that the probability of making at least $2$ sales is more than $\frac{1}{2}$?",
  "TITA",
  r"$P(\text{at most } 1) = \left(\frac{3}{4}\right)^n + n \cdot \frac{1}{4}\left(\frac{3}{4}\right)^{n-1} = \left(\frac{3}{4}\right)^{n-1}\frac{n + 3}{4}$. For $n = 6$: $\frac{243}{1024} \cdot \frac{9}{4} = \frac{2187}{4096} \approx 0.534$, so at least $2$ sales has probability about $0.466$. For $n = 7$: $\frac{729}{4096} \cdot \frac{10}{4} = \frac{7290}{16384} \approx 0.445$, giving about $0.555$. The least number is $7$.",
  "Using the at-least-one condition, or setting the expected number of sales equal to $2$.",
  "C26B-min-trials-threshold", "Complement now has two terms; needs careful evaluation of two neighbouring n.",
  tita_answer=7, check=_d1,
  tita_traps=[(3, r"Solves for at least one sale: $\left(\frac{3}{4}\right)^n < \frac{1}{2}$ first holds at $n = 3$."),
              (8, r"Sets the expected sales $\frac{n}{4}$ equal to $2$.")],
  exams=CX, cognitive="Analysis")


def _d2():
    balls = "RRRWWWW"
    good = tot = 0
    for reds in combinations(range(7), 3):
        tot += 1
        good += sorted(reds)[1] == 3   # second red at position 4 (index 3)
    return F(good, tot)
q("C26-B-032", T, "Draw number at which the second success occurs, without replacement", "Difficult",
  "Casework/optimisation",
  r"A tray has $3$ ripe and $4$ unripe mangoes that look alike. Joseph picks mangoes one at a time at random, without replacement, and stops as soon as he has picked $2$ ripe ones. What is the probability that he stops exactly at the fourth pick?",
  "MCQ",
  r"The first three picks must contain exactly one ripe mango: $\frac{\binom{3}{1}\binom{4}{2}}{\binom{7}{3}} = \frac{18}{35}$. Then $4$ mangoes remain, $2$ of them ripe, so the fourth pick is ripe with probability $\frac{2}{4}$. The probability is $\frac{18}{35} \cdot \frac{1}{2} = \frac{9}{35}$.",
  "Stopping at 'one ripe in three', fixing a single order, or treating the picks as with replacement.",
  "C26B-sequential-draw-no-replacement", "Combines a hypergeometric stage with a final conditional draw; three tempting partial answers.",
  correct=r"$\frac{9}{35}$",
  distractors=[(r"$\frac{18}{35}$", r"Computes only that the first three picks hold exactly one ripe mango, and forgets the fourth pick."),
               (r"$\frac{3}{35}$", r"Uses one fixed order, unripe, unripe, ripe, ripe: $\frac{4}{7} \cdot \frac{3}{6} \cdot \frac{3}{5} \cdot \frac{2}{4}$."),
               (r"$\frac{432}{2401}$", r"Treats the picks as with replacement: $\binom{3}{1}\left(\frac{3}{7}\right)^2\left(\frac{4}{7}\right)^2$.")],
  check=_d2, values=[F(9, 35), F(18, 35), F(3, 35), F(432, 2401)], exams=CX, cognitive="Analysis")


def _d3():
    balls = "RRRRRRBBB"
    vals = []
    for blues in combinations(range(9), 3):
        vals.append(min(blues))   # reds before the first blue = index of first blue
    return 10 * F(sum(vals), len(vals))
q("C26-B-033", T, "Fair fee for a game paying per success before the first failure", "Difficult",
  "Conceptual/application",
  r"A bag contains $6$ red and $3$ blue balls. In a game, Priya draws balls one at a time at random, without replacement, and stops as soon as she draws a blue ball. She is paid Rs. $10$ for every red ball drawn before that blue ball. What entry fee, in rupees, makes the game fair, that is, equal to her expected payment?",
  "TITA",
  r"The $3$ blue balls cut the $6$ red balls into $4$ gaps (before the first blue, between blues, after the last blue). By symmetry each red ball is equally likely to fall in any gap, so it lies before the first blue with probability $\frac{1}{4}$. Expected reds before the first blue $= \frac{6}{4} = 1.5$, and the fair fee is $10 \times 1.5 = 15$ rupees.",
  r"Using red-to-blue ratio $\frac{6}{3}$ for the expected run of reds.",
  "C26B-expected-value-fair-game", "Needs the gaps symmetry or a long expectation sum.",
  tita_answer=15, check=_d3,
  tita_traps=[(20, r"Uses $\frac{6}{3} = 2$ reds expected before the first blue."),
              (60, "Assumes all six reds are paid for.")],
  exams=CX, cognitive="Analysis")


def _d4():
    # brute force over every stopping rule at both decision points
    faces = range(1, 7)
    rules = [{f for f in faces if m >> (f - 1) & 1} for m in range(64)]
    best = F(0)
    for r2 in rules:            # rule after the second roll (one re-roll left)
        v2 = sum(F(1, 6) * (F(7, 2) if f in r2 else f) for f in faces)
        for r1 in rules:        # rule after the first roll (two re-rolls left)
            v1 = sum(F(1, 6) * (v2 if f in r1 else f) for f in faces)
            best = max(best, v1)
    return 12 * best
q("C26-B-034", T, "Optimal stopping with up to two optional re-rolls", "Difficult",
  "Casework/optimisation",
  r"In a game Kabir rolls a fair die. After seeing the result he may stop or roll again; each new result replaces the previous one. He may roll at most three times in all, and after the third roll he must stop. He receives Rs. $12$ times the final number shown. If he plays to maximise his expected receipt, what is that expected receipt, in rupees?",
  "TITA",
  r"Work backwards. With one roll left, the value is $3.5$. With two rolls left, re-roll only when the result is below $3.5$: value $= \frac{3}{6}(3.5) + \frac{4 + 5 + 6}{6} = 4.25$. On the first roll, re-roll only when the result is below $4.25$, that is on $1$ to $4$: value $= \frac{4}{6}(4.25) + \frac{5 + 6}{6} = \frac{17}{6} + \frac{11}{6} = \frac{14}{3}$. Expected receipt $= 12 \times \frac{14}{3} = 56$ rupees.",
  "Using the same threshold at every stage instead of working backwards, or ignoring the extra re-roll.",
  "C26B-expected-value-fair-game", "Optimal rule must be found at two stages by backward induction, with different thresholds.",
  tita_answer=56, check=_d4,
  tita_traps=[(51, r"Uses only one re-roll: $12 \times 4.25$."),
              (42, r"Never re-rolls: $12 \times 3.5$."),
              ],
  exams=CX, cognitive="Analysis")


def _d5():
    coins = [F(1, 2), F(1), F(1, 4)]
    lik = [c ** 2 for c in coins]
    return lik[1] / sum(lik)
q("C26-B-035", T, "Posterior for a two-headed coin after repeated heads", "Difficult",
  "Multi-step word problem",
  r"A drawer has three coins that look alike: a fair coin, a coin with heads on both sides, and a biased coin that shows heads with probability $\frac{1}{4}$. Sneha picks one coin at random and tosses it twice; both tosses show heads. What is the probability that she picked the coin with heads on both sides?",
  "MCQ",
  r"Probabilities of two heads: fair $\frac{1}{4}$, double-headed $1$, biased $\frac{1}{16}$. Each coin has prior $\frac{1}{3}$, which cancels. Posterior $= \frac{1}{\frac{1}{4} + 1 + \frac{1}{16}} = \frac{1}{21/16} = \frac{16}{21}$.",
  "Using a single toss's likelihood, ignoring the evidence, or reporting the probability of the evidence.",
  "C26B-total-probability-two-urns", "Three-branch Bayes with squared likelihoods.",
  correct=r"$\frac{16}{21}$",
  distractors=[(r"$\frac{4}{7}$", r"Uses the likelihoods of a single head: $\frac{1}{\frac{1}{2} + 1 + \frac{1}{4}}$."),
               (r"$\frac{1}{3}$", "Gives the prior and ignores the two heads."),
               (r"$\frac{7}{16}$", r"Reports the probability of two heads, $\frac{1}{3}\left(\frac{1}{4} + 1 + \frac{1}{16}\right)$.")],
  check=_d5, values=[F(16, 21), F(4, 7), F(1, 3), F(7, 16)], exams=CX, cognitive="Analysis")


def _d6():
    prior, sens, fpr = F(2, 100), F(9, 10), F(1, 10)
    sick = prior * sens * sens
    well = (1 - prior) * fpr * fpr
    return sick / (sick + well)
q("C26-B-036", T, "Posterior after two independent positive test results", "Difficult",
  "Multi-step word problem",
  r"A condition affects $2\%$ of a population. A screening test gives a positive result for $90\%$ of people who have the condition and for $10\%$ of people who do not. A person chosen at random is tested twice; given the person's true status, the two results are independent. Both results are positive. What is the probability that the person has the condition?",
  "MCQ",
  r"$P(\text{has, two positives}) = 0.02 \times 0.9^2 = 0.0162$. $P(\text{does not, two positives}) = 0.98 \times 0.1^2 = 0.0098$. The probability is $\frac{0.0162}{0.0162 + 0.0098} = \frac{162}{260} = \frac{81}{130}$.",
  "Using a single test, squaring only one branch, or reporting the chance of two positives for an affected person.",
  "C26B-bayes-defect-test", "Bayes with repeated evidence; the low base rate makes intuition fail.",
  correct=r"$\frac{81}{130}$",
  distractors=[(r"$\frac{9}{58}$", r"Uses only one positive result: $\frac{0.018}{0.018 + 0.098}$."),
               (r"$\frac{81}{571}$", r"Squares the detection rate but uses the false positive rate only once: $\frac{0.0162}{0.0162 + 0.098}$."),
               (r"$\frac{81}{100}$", r"Reports $P(\text{two positives} \mid \text{has the condition}) = 0.9^2$.")],
  check=_d6, values=[F(81, 130), F(9, 58), F(81, 571), F(81, 100)], exams=CX, cognitive="Analysis")


def _d7():
    p = F(1, 3)
    # simulate rounds: state = whose turn (0,1,2); exact by solving linear equations
    a, b, c = symbols('a b c')
    # a = P(Kabir eventually wins | Ravi to roll), b = ... | Meera to roll, c = ... | Kabir to roll
    sol = solve([Eq(a, (1 - p) * b), Eq(b, (1 - p) * c), Eq(c, p + (1 - p) * a)], [a, b, c])
    return sol[a]
q("C26-B-037", T, "Three players rolling in turn; chance of the third player", "Difficult",
  "Multi-step word problem",
  r"Ravi, Meera and Kabir take turns rolling a fair die in that order, round after round. The first person to roll a number greater than $4$ wins and the game stops. What is the probability that Kabir wins?",
  "MCQ",
  r"Each roll succeeds with probability $\frac{1}{3}$. Kabir wins in the first round with probability $\left(\frac{2}{3}\right)^2 \frac{1}{3} = \frac{4}{27}$, and each full round without a winner has probability $\left(\frac{2}{3}\right)^3 = \frac{8}{27}$. So $P = \frac{4/27}{1 - 8/27} = \frac{4}{19}$. (Ravi and Meera have $\frac{9}{19}$ and $\frac{6}{19}$.)",
  "Assuming equal chances, or stopping after the first round.",
  "C26B-alternate-turns-geometric", "Three-player cycle; needs the round-repeat ratio, not the two-player formula.",
  correct=r"$\frac{4}{19}$",
  distractors=[(r"$\frac{1}{3}$", "Assumes the three players have equal chances."),
               (r"$\frac{9}{19}$", "Gives Ravi's winning probability."),
               (r"$\frac{4}{27}$", "Counts only Kabir's first roll.")],
  check=_d7, values=[F(4, 19), F(1, 3), F(9, 19), F(4, 27)], exams=CX, cognitive="Analysis")


def _d8():
    pA = F(sum(1 for d in DICE if sum(d) == 9), 36)
    pF = F(sum(1 for d in DICE if d[0] == d[1]), 36)
    order = ["A", "F", "A", "F"]
    alive, fat = F(1), F(0)
    for who in order:
        p = pA if who == "A" else pF
        if who == "F":
            fat += alive * p
        alive *= 1 - p
    return fat
q("C26-B-038", T, "Alternate turns with a cap on the number of turns", "Difficult",
  "Casework/optimisation",
  r"Arjun and Fatima take turns rolling a pair of fair dice, Arjun first. Arjun wins if on his turn the two dice add up to $9$; Fatima wins if on her turn the two dice show the same number. The game stops as soon as someone wins, and each player gets at most $2$ turns, so if nobody has won after $4$ turns the game ends with no winner. What is the probability that Fatima wins?",
  "MCQ",
  r"$P(\text{sum } 9) = \frac{4}{36} = \frac{1}{9}$ and $P(\text{doublet}) = \frac{6}{36} = \frac{1}{6}$. Fatima wins on her first turn with probability $\frac{8}{9} \cdot \frac{1}{6} = \frac{4}{27}$, or on her second with probability $\frac{8}{9} \cdot \frac{5}{6} \cdot \frac{8}{9} \cdot \frac{1}{6} = \frac{80}{729}$. Total: $\frac{108 + 80}{729} = \frac{188}{729}$.",
  "Using the unlimited-game formula, counting only her first turn, or reporting Arjun's chance.",
  "C26B-turns-limited-rounds", "Two counting sub-results plus a finite turn sequence; the infinite-game formula is a trap.",
  correct=r"$\frac{188}{729}$",
  distractors=[(r"$\frac{4}{7}$", r"Uses the unlimited game: $\frac{(8/9)(1/6)}{1 - (8/9)(5/6)}$."),
               (r"$\frac{4}{27}$", "Counts only Fatima's first turn."),
               (r"$\frac{47}{243}$", r"Gives Arjun's chance, $\frac{1}{9} + \frac{8}{9} \cdot \frac{5}{6} \cdot \frac{1}{9} = \frac{141}{729}$.")],
  check=_d8, values=[F(188, 729), F(4, 7), F(4, 27), F(47, 243)], exams=CX, cognitive="Analysis")


def _d9():
    P = ["W"] * 4 + ["K"] * 3
    joint_ww = F(0); white = F(0)
    pairs = list(combinations(range(7), 2))
    for pr in pairs:
        moved = [P[i] for i in pr]
        Q = ["W"] * 3 + ["K"] * 5 + moved
        pw = F(1, len(pairs)) * F(Q.count("W"), len(Q))
        white += pw
        if moved.count("W") == 2:
            joint_ww += pw
    return joint_ww / white
q("C26-B-039", T, "Reverse probability of the transferred pair given the later draw", "Difficult",
  "Multi-step word problem",
  r"Bag P has $4$ white and $3$ black balls; bag Q has $3$ white and $5$ black balls. Two balls are drawn at random from bag P together and put into bag Q without their colours being seen. Then one ball is drawn at random from bag Q and it is white. What is the probability that both balls moved from bag P were white?",
  "MCQ",
  r"Transfer cases: two white $\frac{6}{21} = \frac{2}{7}$, one each $\frac{12}{21} = \frac{4}{7}$, two black $\frac{3}{21} = \frac{1}{7}$. Bag Q then has $10$ balls with $5$, $4$ or $3$ white. Joint probabilities with a white draw: $\frac{2}{7} \cdot \frac{5}{10} = \frac{10}{70}$, $\frac{4}{7} \cdot \frac{4}{10} = \frac{16}{70}$, $\frac{1}{7} \cdot \frac{3}{10} = \frac{3}{70}$. The required probability is $\frac{10}{10 + 16 + 3} = \frac{10}{29}$.",
  "Reporting the prior chance of moving two whites, or the most likely transfer case.",
  "C26B-transfer-between-bags", "Three transfer cases, total probability and then Bayes.",
  correct=r"$\frac{10}{29}$",
  distractors=[(r"$\frac{16}{29}$", "Gives the posterior for the one white, one black transfer."),
               (r"$\frac{2}{7}$", "Gives the prior probability of moving two whites and ignores the draw."),
               (r"$\frac{1}{2}$", "Gives the chance of a white draw from bag Q when two whites were moved.")],
  check=_d9, values=[F(10, 29), F(16, 29), F(2, 7), F(1, 2)], exams=CX, cognitive="Analysis")


def _d10():
    pa, pb, v = F(2, 3), F(1, 2), F(3, 5)
    fail = F(0); valve_bad = F(0)
    for (a, b, s), pr in _indep([pa, pb, v]):
        works = (a or b) and s
        if not works:
            fail += pr
            if not s:
                valve_bad += pr
    return 100 * valve_bad / fail
q("C26-B-040", T, "Cause of a system failure given the failure, 100p", "Difficult",
  "Conceptual/application",
  r"Water reaches a building's tank if at least one of two pumps works and an old valve on the common pipe also works. On a given day the pumps work with probabilities $\frac{2}{3}$ and $\frac{1}{2}$ and the valve works with probability $\frac{3}{5}$, all independently. One day the tank receives no water. If $p$ is the probability that the valve failed that day, what is the value of $100p$?",
  "TITA",
  r"Both pumps fail with probability $\frac{1}{3} \cdot \frac{1}{2} = \frac{1}{6}$, so the system works with probability $\frac{5}{6} \cdot \frac{3}{5} = \frac{1}{2}$ and fails with probability $\frac{1}{2}$. A failed valve always means no water, so $P(\text{valve failed and no water}) = \frac{2}{5}$. Hence $p = \frac{2/5}{1/2} = \frac{4}{5}$ and $100p = 80$.",
  "Reporting the unconditional failure probability of the valve.",
  "C26B-reliability-system", "Reliability computation followed by conditioning on the failure.",
  tita_answer=80, check=_d10,
  tita_traps=[(40, r"Reports the unconditional valve failure probability $\frac{2}{5}$."),
              (50, r"Reports the probability that the tank receives no water, $\frac{1}{2}$.")],
  exams=CX, cognitive="Analysis")
