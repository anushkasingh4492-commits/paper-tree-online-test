import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Inequality-based optimisation"
HARD = ("CAT", "XAT")


def _argmin_real(f, x, lo=None):
    """Minimise f over x > 0 (or x > lo) using the stationary points of f."""
    crit = [s for s in solve(diff(f, x), x) if s.is_real and s > (0 if lo is None else lo)]
    return min(f.subs(x, s) for s in crit)


# ---------------------------------------------------------------- 001
def _c001():
    x = symbols('x', positive=True)
    f = x * (Rational(140, 2) - x)
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 70]
    return max(f.subs(x, s) for s in crit)
q("C11-C-001", TOPIC, "Largest rectangular area enclosed by a fixed length of fencing", "Easy",
  "Conceptual/application",
  r"Harpreet has $140$ m of fencing and wants to enclose a rectangular kitchen garden, fencing all four sides and using the entire length. What is the largest area, in m$^2$, that the garden can have?",
  "TITA",
  r"If the sides are $x$ and $y$, then $2(x + y) = 140$, so $x + y = 70$. For a fixed sum, the product $xy$ is largest when $x = y$, since $xy \le \left(\frac{x+y}{2}\right)^2 = 35^2$. The largest area is $35 \times 35 = 1225$ m$^2$.",
  "Taking half the perimeter, $70$ m, as the side of the square.",
  "C11C-fixed-perimeter-max-area", "One application of the fixed-sum, maximum-product principle.",
  tita_answer=1225, check=_c001, values=[1225],
  tita_traps=[(4900, "Uses the half perimeter $70$ m as the side of the square: $70^2$."),
              (1200, "Picks the convenient but unequal sides $30$ m and $40$ m.")],
  cognitive="Understanding")

# ---------------------------------------------------------------- 002
def _c002():
    x = symbols('x', positive=True)   # side perpendicular to the wall
    f = x * (120 - 2 * x)
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 60]
    return max(f.subs(x, s) for s in crit)
q("C11-C-002", TOPIC, "Maximum area of a rectangle fenced on three sides against a wall", "Medium",
  "Multi-step word problem",
  r"A farmer wants to fence a rectangular paddock that lies along a long straight wall. The wall forms one side of the paddock and needs no fencing; the other three sides use exactly $120$ m of fencing. What is the largest possible area of the paddock?",
  "MCQ",
  r"Let each side perpendicular to the wall be $x$ m; the side parallel to the wall is then $120 - 2x$ m. The area is $x(120 - 2x) = \frac{1}{2}(2x)(120 - 2x)$, and $(2x)(120 - 2x)$ has a fixed sum $120$, so it is largest when $2x = 60$. Thus $x = 30$, the parallel side is $60$ m and the area is $30 \times 60 = 1800$ m$^2$.",
  "Making the three fenced sides equal, as if the best shape were always a square.",
  "C11C-fixed-perimeter-max-area", "Requires rewriting the area so that the two factors have a fixed sum; the equal-sides instinct is a trap.",
  correct=r"$1800$ m$^2$",
  distractors=[(r"$1600$ m$^2$", r"Makes all three fenced sides equal, $40$ m each, giving $40 \times 40$."),
               (r"$900$ m$^2$", "Ignores the wall and fences a square on all four sides: side $30$ m."),
               (r"$3600$ m$^2$", "Counts only one perpendicular side: maximises $x(120 - x)$ at $x = 60$.")],
  check=_c002, values=[1800, 1600, 900, 3600], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    W = symbols('W', positive=True)
    L = (360 - 4 * W) / 2           # 2 lengths + 4 widths (2 boundary, 2 internal)
    f = L * W
    crit = [s for s in solve(diff(f, W), W) if 0 < s < 90]
    return max(f.subs(W, s) for s in crit)
q("C11-C-003", TOPIC, "Maximum area of a field split into three pens with internal fences", "Medium",
  "Multi-step word problem",
  r"A rectangular field is to be fenced along its whole boundary and also divided into three pens by two straight fences, each running across the field parallel to one pair of its sides. Exactly $360$ m of fencing is used in all. What is the largest possible area of the field, in m$^2$?",
  "TITA",
  r"Let the internal fences be parallel to the sides of length $w$, and let the other dimension be $l$. The fencing used is $2l + 4w = 360$. The area $lw = \frac{1}{8}(2l)(4w)$, and $(2l) + (4w) = 360$ is fixed, so the product is largest when $2l = 4w = 180$. Then $l = 90$, $w = 45$ and the area is $90 \times 45 = 4050$ m$^2$.",
  "Ignoring the two internal fences, or making every fence segment equal.",
  "C11C-fixed-perimeter-max-area", "The fencing equation has unequal weights, so the equal-sides answer is wrong; needs a weighted split.",
  tita_answer=4050, check=_c003, values=[4050],
  tita_traps=[(8100, "Ignores the internal fences and encloses a square of side $90$ m."),
              (3600, r"Makes all six fence segments equal, $60$ m each, giving a $60 \times 60$ field.")],
  cognitive="Application")

# ---------------------------------------------------------------- 004
def _c004():
    x = symbols('x', positive=True)
    return 12 * _argmin_real(2 * (x + 625 / x), x)
q("C11-C-004", TOPIC, "Least fencing cost for a rectangle of given area", "Easy",
  "Single-step computation",
  r"Sneha needs a rectangular plot of area $625$ m$^2$, fenced on all four sides. Fencing costs Rs. $12$ per metre. What is the least possible cost of fencing the plot?",
  "MCQ",
  r"For sides $x$ and $\frac{625}{x}$, the perimeter is $2\left(x + \frac{625}{x}\right) \ge 2 \times 2\sqrt{625} = 100$ m, with equality for the square of side $25$ m. The least cost is $100 \times 12 = $ Rs. $1{,}200$.",
  "Using the half perimeter, or one side, instead of the full perimeter.",
  "C11C-weighted-cost-fixed-area", "Direct use of the fixed-product, minimum-sum principle.",
  correct=r"Rs. $1{,}200$",
  distractors=[(r"Rs. $600$", "Uses the half perimeter $x + \\frac{625}{x} = 50$ m as the fencing length."),
               (r"Rs. $300$", "Prices only one side of $25$ m."),
               (r"Rs. $7{,}500$", "Multiplies the area $625$ by the rate $12$.")],
  check=_c004, values=[1200, 600, 300, 7500], cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    L, W = symbols('L W', positive=True)   # L = front/back side, W = other sides
    cost = 30 * L + 10 * L + 10 * 2 * W
    c = cost.subs(W, 1250 / L)
    return _argmin_real(c, L)
q("C11-C-005", TOPIC, "Least fencing cost when one side costs more", "Medium",
  "Multi-step word problem",
  r"A rectangular storage yard of area $1250$ m$^2$ is to be fenced on all four sides. The front side, facing the road, uses fencing that costs Rs. $30$ per metre; the back side and the two remaining sides use fencing that costs Rs. $10$ per metre. What is the least possible cost of fencing the yard?",
  "MCQ",
  r"Let the front (and back) side be $l$ m and each other side $w$ m, with $lw = 1250$. Cost $= 30l + 10l + 2 \times 10w = 40l + 20w \ge 2\sqrt{40l \times 20w} = 2\sqrt{800 \times 1250} = 2000$. Equality needs $40l = 20w = 1000$, that is $l = 25$, $w = 50$, which does give area $1250$. The least cost is Rs. $2{,}000$.",
  "Putting the expensive fencing on the longer side, or pricing every side at the cheaper rate.",
  "C11C-weighted-cost-fixed-area", "Unequal costs per side, so the square is not optimal; needs AM-GM on weighted terms.",
  correct=r"Rs. $2{,}000$",
  distractors=[(r"Rs. $1{,}000$", "Stops at one of the two equal terms, $40l = 1000$, and reports it as the cost."),
               (r"Rs. $2{,}500$", "Swaps the dimensions: front $50$ m and sides $25$ m give $40 \\times 50 + 20 \\times 25$."),
               (r"Rs. $1{,}500$", "Prices the front at Rs. $10$ per metre too: $10 \\times 2(25 + 50)$.")],
  check=_c005, values=[2000, 1000, 2500, 1500], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    x = symbols('x', positive=True)
    return _argmin_real(4 * x + 100 / x, x)
q("C11-C-006", TOPIC, "Least total of a cost rising with x and a cost falling with x", "Easy",
  "Single-step computation",
  r"A store orders its stock in equal batches. If each batch has $x$ hundred units, the monthly storage cost is Rs. $4x$ thousand and the monthly ordering cost is Rs. $\frac{100}{x}$ thousand, where $x$ can be any positive number. What is the least possible total of these two monthly costs?",
  "MCQ",
  r"By AM-GM, $4x + \frac{100}{x} \ge 2\sqrt{4x \cdot \frac{100}{x}} = 2\sqrt{400} = 40$, with equality when $4x = \frac{100}{x}$, that is $x = 5$. The least total is Rs. $40$ thousand.",
  "Dropping the factor 2 in AM-GM, or choosing $x$ by an irrelevant rule.",
  "C11C-reciprocal-pair-cost", "One AM-GM step on two terms with a fixed product.",
  correct=r"Rs. $40$ thousand",
  distractors=[(r"Rs. $20$ thousand", "Uses $\\sqrt{ab}$ in place of $2\\sqrt{ab}$: $\\sqrt{400} = 20$."),
               (r"Rs. $50$ thousand", "Takes $x = \\sqrt{100} = 10$, ignoring the coefficient $4$: $40 + 10$."),
               (r"Rs. $104$ thousand", "Sets $4x = 100$, giving $x = 25$: $100 + 4$.")],
  check=_c006, values=[40, 20, 50, 104], cognitive="Application")

# ---------------------------------------------------------------- 007
def _c007():
    v = symbols('v', positive=True)
    total = (500 / v) * (v**2 / 20 + 180)
    return _argmin_real(total, v)
q("C11-C-007", TOPIC, "Speed that minimises trip cost with fuel and hourly charges", "Medium",
  "Multi-step word problem",
  r"A truck makes a $500$ km trip at a constant speed of $v$ km/h. While it is moving, fuel costs Rs. $\frac{v^2}{20}$ per hour, and the driver's wages and other charges come to Rs. $180$ per hour. What is the least possible total cost of the trip, in rupees?",
  "TITA",
  r"The trip takes $\frac{500}{v}$ hours, so the cost is $\frac{500}{v}\left(\frac{v^2}{20} + 180\right) = 25v + \frac{90000}{v}$. By AM-GM this is at least $2\sqrt{25 \times 90000} = 2 \times 1500 = 3000$, with equality when $25v = \frac{90000}{v}$, that is $v = 60$ km/h. The least cost is Rs. $3{,}000$.",
  "Minimising the cost per hour instead of the cost of the whole trip.",
  "C11C-reciprocal-pair-cost", "Must build the trip cost from per-hour rates before AM-GM applies.",
  tita_answer=3000, check=_c007, values=[3000],
  tita_traps=[(1500, "Counts only the fuel part, or only the wages part, of the optimum cost."),
              (360, "Reports the cost per hour at $60$ km/h, $180 + 180$, as the trip cost.")],
  cognitive="Application")

# ---------------------------------------------------------------- 008
def _c008():
    best = None
    for n in range(1, 11):     # at most 10 workers on site
        days = Fraction(720, n)
        cost = 600 * n * days + 15000 * n + 3000 * days
        best = cost if best is None or cost < best else best
    return best
q("C11-C-008", TOPIC, "Cost-minimising workforce when the AM-GM optimum is not allowed", "Difficult",
  "Casework/optimisation",
  r"A job needs $720$ worker-days of labour. A contractor hires $n$ workers, all of whom work every day until the job is done. Each worker is paid Rs. $600$ per day worked, each worker hired costs a one-time Rs. $15{,}000$ for training and equipment, and the site costs Rs. $3{,}000$ for each day the job runs. At most $10$ workers can be on the site. What is the least possible total cost of the job?",
  "MCQ",
  r"The job takes $\frac{720}{n}$ days, so wages are $600 \times 720 = $ Rs. $4{,}32{,}000$ whatever $n$ is. The rest is $15000n + \frac{2160000}{n}$, which by AM-GM is least at $n^2 = 144$, $n = 12$; but $n \le 10$. Since $15000n + \frac{2160000}{n}$ decreases for $n < 12$, the best allowed choice is $n = 10$: $150000 + 216000 = 366000$. The total is $432000 + 366000 = $ Rs. $7{,}98{,}000$.",
  "Using the unconstrained AM-GM optimum when it violates the site limit.",
  "C11C-reciprocal-pair-cost", "The AM-GM equality point is infeasible, so the candidate must spot the boundary optimum and also see that wages are fixed.",
  correct=r"Rs. $7{,}98{,}000$",
  distractors=[(r"Rs. $7{,}92{,}000$", "Uses $n = 12$ from AM-GM, ignoring the limit of $10$ workers: $432000 + 360000$."),
               (r"Rs. $3{,}66{,}000$", "Leaves out the wages of Rs. $4{,}32{,}000$."),
               (r"Rs. $4{,}09{,}200$", "Takes the wage bill as Rs. $600$ per day for the whole crew: $600 \\times 72 = 43200$, plus $366000$.")],
  check=_c008, values=[798000, 792000, 366000, 409200], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 009
def _c009():
    x = symbols('x', positive=True)
    f = x**2 * (120 - 4 * x)
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 30]
    return max(f.subs(x, s) for s in crit)
q("C11-C-009", TOPIC, "Largest parcel volume under a length-plus-girth limit", "Medium",
  "Conceptual/application",
  r"A courier accepts a cuboidal parcel with a square cross-section only if its length plus its girth (the perimeter of the square cross-section) is at most $120$ cm. What is the largest possible volume of such a parcel?",
  "MCQ",
  r"Let the square side be $x$ and the length $l$, with $l + 4x \le 120$. Write the volume as $x^2 l = \frac{1}{4}(2x)(2x)(l)$; the three factors $2x, 2x, l$ have sum at most $120$, so their product is at most $40^3$, with equality when $2x = l = 40$. Then $x = 20$, $l = 40$ and the volume is $20^2 \times 40 = 16{,}000$ cm$^3$.",
  "Making the parcel a cube, or splitting the allowance equally between length and girth.",
  "C11C-weighted-amgm", "Needs the split $2x, 2x, l$ so that the AM-GM terms have a fixed sum.",
  correct=r"$16{,}000$ cm$^3$",
  distractors=[(r"$13{,}824$ cm$^3$", "Makes the parcel a cube: $5x = 120$, $x = 24$, volume $24^3$."),
               (r"$13{,}500$ cm$^3$", "Splits $120$ equally: length $60$ and girth $60$, so $x = 15$ and volume $225 \\times 60$."),
               (r"$64{,}000$ cm$^3$", "Takes the girth as $2x$: $x + x + l = 120$ gives $x = l = 40$ and $40^3$.")],
  check=_c009, values=[16000, 13824, 13500, 64000], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    x = symbols('x', positive=True)
    f = x**2 * (10 - x)**3
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 10]
    return max(f.subs(x, s) for s in crit)
q("C11-C-010", TOPIC, "Maximum of a product of powers when the sum is fixed", "Medium",
  "Conceptual/application",
  r"If $x$ and $y$ are positive real numbers with $x + y = 10$, then the greatest possible value of $x^2 y^3$ is",
  "MCQ",
  r"Split $x$ into two equal parts and $y$ into three: $\frac{x}{2} + \frac{x}{2} + \frac{y}{3} + \frac{y}{3} + \frac{y}{3} = 10$. By AM-GM, $\left(\frac{x}{2}\right)^2 \left(\frac{y}{3}\right)^3 \le 2^5 = 32$, so $x^2 y^3 \le 32 \times 4 \times 27 = 3456$, with equality when $\frac{x}{2} = \frac{y}{3} = 2$, that is $x = 4$, $y = 6$.",
  "Setting $x = y$, or splitting the sum in the wrong ratio.",
  "C11C-weighted-amgm", "Weighted AM-GM: the sum must be split in the ratio of the exponents.",
  correct=r"$3456$",
  distractors=[(r"$3125$", "Takes $x = y = 5$, giving $5^5$."),
               (r"$2304$", "Splits $10$ in the ratio $3 : 2$, taking $x = 6$, $y = 4$: $36 \\times 64$."),
               (r"$32$", "Stops at the bound $\\left(\\frac{x}{2}\\right)^2\\left(\\frac{y}{3}\\right)^3 \\le 32$ without multiplying by $4 \\times 27$.")],
  check=_c010, values=[3456, 3125, 2304, 32], cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    from sympy.utilities.iterables import partitions
    best = 0
    for p in partitions(20):
        prod = 1
        for part, mult in p.items():
            prod *= part ** mult
        best = max(best, prod)
    return best
q("C11-C-011", TOPIC, "Maximum product of positive integers with a fixed sum", "Medium",
  "Conceptual/application",
  r"A coach splits $20$ players into groups, each with at least one player and of any sizes she likes, and then picks one captain from each group. The number of possible ways of choosing the captains is the product of the group sizes. What is the greatest possible number of ways?",
  "MCQ",
  r"A part of size $4$ or more can be split without lowering the product ($k \ge 4$ gives $2(k-2) \ge k$), and parts of size $1$ waste the sum, so use only $2$s and $3$s, with at most two $2$s since $2+2+2$ is worse than $3+3$. Now $20 = 3 \times 6 + 2$, so the best product is $3^6 \times 2 = 1458$.",
  "Using only 2s, or dropping the leftover after taking 3s.",
  "C11C-integer-split-max-product", "Needs the principle that parts should be 3s with a 2 for the remainder.",
  correct=r"$1458$",
  distractors=[(r"$1024$", "Uses ten groups of $2$: $2^{10}$."),
               (r"$729$", "Takes six groups of $3$ and ignores the two leftover players: $3^6$."),
               (r"$1215$", "Takes five groups of $3$ and puts the remaining $5$ in one group: $3^5 \\times 5$.")],
  check=_c011, values=[1458, 1024, 729, 1215], cognitive="Understanding")

# ---------------------------------------------------------------- 012
def _c012():
    from sympy.utilities.iterables import partitions
    best = 0
    for p in partitions(30):
        if any(m > 1 for m in p.values()):
            continue
        prod = 1
        for part in p:
            prod *= part
        best = max(best, prod)
    return best
q("C11-C-012", TOPIC, "Maximum product of distinct positive integers with a fixed sum", "Difficult",
  "Casework/optimisation",
  r"Ananya writes $30$ as a sum of positive integers that are all different from one another, and then multiplies these integers together. What is the greatest product she can obtain?",
  "MCQ",
  r"Avoid $1$, which adds to the sum but not the product, and use as many small distinct parts as possible: $2 + 3 + 4 + 5 + 6 + 7 = 27$ leaves $3$ over. Spreading this $3$ as $1$ each on the three largest parts keeps them distinct and as balanced as possible: $2, 3, 4, 6, 7, 8$ (sum $30$). The product is $2 \times 3 \times 4 \times 6 \times 7 \times 8 = 8064$; checking the alternatives confirms nothing larger.",
  "Adding the leftover to a single part, or including 1 as a part.",
  "C11C-integer-split-max-product", "Distinctness changes the 3s rule; the leftover must be spread across the largest parts, with several close alternatives to rule out.",
  correct=r"$8064$",
  distractors=[(r"$7200$", "Adds the leftover $3$ to the largest part only: $2 \\times 3 \\times 4 \\times 5 \\times 6 \\times 10$."),
               (r"$6720$", "Uses five consecutive parts $4 + 5 + 6 + 7 + 8 = 30$."),
               (r"$6480$", "Starts from $1$: $1 + 2 + \\dots + 7 = 28$, adds the leftover $2$ to $7$, giving $1 \\times 2 \\times 3 \\times 4 \\times 5 \\times 6 \\times 9$.")],
  check=_c012, values=[8064, 7200, 6720, 6480], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 013
def _c013():
    best = 0
    for t in itertools.product(range(1, 21), repeat=3):
        r = 23 - sum(t)
        if r >= 1:
            best = max(best, t[0] * t[1] * t[2] * r)
    return best
q("C11-C-013", TOPIC, "Maximum product of a fixed number of positive integer parts", "Easy",
  "Casework/optimisation",
  r"A teacher shares $23$ different picture cards among $4$ children so that each child gets at least one card. She will then pick one card from each child's share, so the number of possible picks is the product of the numbers of cards in the four shares. What is the greatest possible number of picks?",
  "MCQ",
  r"For a fixed sum, the product is largest when the shares are as equal as possible. Since $23 = 4 \times 5 + 3$, the shares are $6, 6, 6, 5$, and the product is $6 \times 6 \times 6 \times 5 = 1080$.",
  "Giving the leftover cards to one child instead of spreading them evenly.",
  "C11C-integer-split-max-product", "One idea: equal-as-possible integer shares.",
  correct=r"$1080$",
  distractors=[(r"$1000$", "Gives $5$ to each child and all $3$ leftover cards to one child: $5 \\times 5 \\times 5 \\times 8$."),
               (r"$1050$", "Gives $5$ to each child, then $2$ of the leftover cards to one child and $1$ to another: $7 \\times 6 \\times 5 \\times 5$."),
               (r"$625$", "Gives $5$ to each child and ignores the $3$ leftover cards: $5^4$.")],
  check=_c013, values=[1080, 1000, 1050, 625], cognitive="Application")

# ---------------------------------------------------------------- 014
def _c014():
    x = symbols('x', positive=True)
    f = (x / 4)**2 + ((80 - x) / 4)**2
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 80]
    return min(f.subs(x, s) for s in crit)
q("C11-C-014", TOPIC, "Least total area of two squares made from one wire", "Easy",
  "Multi-step word problem",
  r"A wire of length $80$ cm is cut into two pieces, and each piece is bent into a square. What is the least possible total area of the two squares?",
  "MCQ",
  r"If the pieces are $x$ and $80 - x$ cm, the total area is $\frac{x^2 + (80 - x)^2}{16}$. For a fixed sum, a sum of squares is least when the two numbers are equal, so $x = 40$: each square has side $10$ cm and the total area is $2 \times 100 = 200$ cm$^2$.",
  "Confusing the least total area with the greatest, or using half the piece as the side.",
  "C11C-sum-of-squares-min", "One idea: for a fixed sum, the sum of squares is least at equal parts.",
  correct=r"$200$ cm$^2$",
  distractors=[(r"$400$ cm$^2$", "Uses the whole wire for one square of side $20$ cm, which approaches the greatest total, not the least."),
               (r"$100$ cm$^2$", "Counts the area of only one of the two equal squares."),
               (r"$800$ cm$^2$", "Takes the side as half of each $40$ cm piece: $2 \\times 20^2$.")],
  check=_c014, values=[200, 400, 100, 800], cognitive="Application")

# ---------------------------------------------------------------- 015
def _c015():
    y, z = symbols('y z', real=True)
    x = 18 - 2 * y - 2 * z
    f = x**2 + y**2 + z**2
    sol = solve([diff(f, y), diff(f, z)], [y, z], dict=True)[0]
    return simplify(f.subs(sol))
q("C11-C-015", TOPIC, "Least sum of squares under a weighted linear constraint", "Medium",
  "Conceptual/application",
  r"Real numbers $x$, $y$ and $z$ satisfy $x + 2y + 2z = 18$. What is the least possible value of $x^2 + y^2 + z^2$?",
  "TITA",
  r"By the Cauchy-Schwarz inequality, $(x + 2y + 2z)^2 \le (1^2 + 2^2 + 2^2)(x^2 + y^2 + z^2)$, so $x^2 + y^2 + z^2 \ge \frac{324}{9} = 36$. Equality holds when $x : y : z = 1 : 2 : 2$, that is $x = 2$, $y = z = 4$, which satisfies $2 + 8 + 8 = 18$. The least value is $36$.",
  "Treating all coefficients as 1, or putting the whole sum on one variable.",
  "C11C-sum-of-squares-min", "Needs Cauchy-Schwarz (or a weighted equal-ratio insight) rather than plain equal values.",
  tita_answer=36, check=_c015, values=[36],
  tita_traps=[(108, "Divides $18^2$ by $3$ as if all three coefficients were $1$."),
              (324, "Puts everything on one variable: $x = 18$, $y = z = 0$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    c = symbols('c', real=True)
    # a + b = 9 - c and a^2 + b^2 = 33 - c^2 have a real solution iff 2(a^2+b^2) >= (a+b)^2
    sol = solve_univariate_inequality(2 * (33 - c**2) - (9 - c)**2 >= 0, c, relational=False)
    return sol.sup
q("C11-C-016", TOPIC, "Greatest value of one variable given its sum and sum of squares with others", "Medium",
  "Conceptual/application",
  r"Real numbers $a$, $b$ and $c$ satisfy $a + b + c = 9$ and $a^2 + b^2 + c^2 = 33$. What is the greatest possible value of $c$?",
  "TITA",
  r"We need $a + b = 9 - c$ and $a^2 + b^2 = 33 - c^2$. Since $a^2 + b^2 \ge \frac{(a+b)^2}{2}$, we get $2(33 - c^2) \ge (9 - c)^2$, that is $3c^2 - 18c + 15 \le 0$, or $(c - 1)(c - 5) \le 0$. So $c \le 5$, attained at $a = b = 2$: $2 + 2 + 5 = 9$ and $4 + 4 + 25 = 33$. The greatest value is $5$.",
  "Assuming all three numbers are equal, or reporting the least value.",
  "C11C-range-from-symmetric-constraints", "Needs the QM-AM bound on the other two variables to produce a quadratic condition on $c$.",
  tita_answer=5, check=_c016, values=[5],
  tita_traps=[(3, "Assumes $a = b = c = 3$, which does not even satisfy the second condition."),
              (1, "Reports the smaller root of $(c - 1)(c - 5) = 0$.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 017
def _c017():
    z = symbols('z', real=True)
    # x + y = 7 - z, xy = 11 - z(7 - z); real x, y iff (x+y)^2 >= 4xy
    sol = solve_univariate_inequality((7 - z)**2 - 4 * (11 - z * (7 - z)) >= 0, z, relational=False)
    return sol.inf
q("C11-C-017", TOPIC, "Least value of one variable given its sum and pairwise products with others", "Difficult",
  "Conceptual/application",
  r"Real numbers $x$, $y$ and $z$ satisfy $x + y + z = 7$ and $xy + yz + zx = 11$. The least possible value of $z$ is",
  "MCQ",
  r"Here $x + y = 7 - z$ and $xy = 11 - z(x + y) = 11 - 7z + z^2$. For $x, y$ to be real, $(x + y)^2 \ge 4xy$: $(7 - z)^2 \ge 4(11 - 7z + z^2)$, which simplifies to $3z^2 - 14z - 5 \le 0$, that is $(3z + 1)(z - 5) \le 0$. So $-\frac{1}{3} \le z \le 5$, and $z = -\frac{1}{3}$ is attained with $x = y = \frac{11}{3}$. The least value is $-\frac{1}{3}$.",
  "Assuming equal values, or slipping on the sign or the factor 2 when solving the quadratic.",
  "C11C-range-from-symmetric-constraints", "Must convert the symmetric conditions into a real-roots condition and handle a negative bound.",
  correct=r"$-\frac{1}{3}$",
  distractors=[(r"$\frac{1}{3}$", "Solves $(3z + 1)(z - 5) = 0$ but drops the sign of the root."),
               (r"$\frac{7}{3}$", "Assumes $x = y = z = \\frac{7}{3}$, though then $xy + yz + zx = \\frac{49}{3}$, not $11$."),
               (r"$-5$", "Factorises $3z^2 - 14z - 5$ as $(3z - 1)(z + 5)$, flipping the sign of the middle term, and takes the smaller root.")],
  check=_c017, values=[Rational(-1, 3), Rational(1, 3), Rational(7, 3), -5], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 018
def _c018():
    x = symbols('x', positive=True)
    f = 1 / x + 4 / (2 - x)
    crit = [s for s in solve(diff(f, x), x) if 0 < s < 2]
    return min(f.subs(x, s) for s in crit)
q("C11-C-018", TOPIC, "Least value of a weighted sum of reciprocals with a fixed sum", "Medium",
  "Conceptual/application",
  r"If $x$ and $y$ are positive real numbers with $x + y = 2$, then the least possible value of $\frac{1}{x} + \frac{4}{y}$ is",
  "MCQ",
  r"By Cauchy-Schwarz, $(x + y)\left(\frac{1}{x} + \frac{4}{y}\right) \ge (1 + 2)^2 = 9$, so $\frac{1}{x} + \frac{4}{y} \ge \frac{9}{2} = 4.5$. Equality needs $y = 2x$, so $x = \frac{2}{3}$, $y = \frac{4}{3}$, giving $\frac{3}{2} + 3 = 4.5$.",
  "Applying AM-GM twice with incompatible equality conditions, or setting x = y.",
  "C11C-reciprocal-sum-cauchy", "The obvious double AM-GM gives an unattainable bound; needs the Cauchy-Schwarz form.",
  correct=r"$4.5$",
  distractors=[(r"$4$", "Writes $\\frac{1}{x} + \\frac{4}{y} \\ge \\frac{4}{\\sqrt{xy}}$ and $xy \\le 1$; the two equalities cannot hold together."),
               (r"$5$", "Takes $x = y = 1$: $1 + 4$."),
               (r"$2.5$", "Divides the sum of the numerators, $5$, by $x + y = 2$.")],
  check=_c018, values=[Rational(9, 2), 4, 5, Rational(5, 2)], cognitive="Analysis")

# ---------------------------------------------------------------- 019
def _c019():
    x, y, z, lam = symbols('x y z lam', positive=True)
    f = 1 / x + 4 / y + 9 / z
    eqs = [diff(f, v) + lam for v in (x, y, z)] + [x + y + z - 6]
    sol = solve(eqs, [x, y, z, lam], dict=True)
    return min(f.subs(s) for s in sol)
q("C11-C-019", TOPIC, "Least value of a three-term weighted reciprocal sum", "Difficult",
  "Conceptual/application",
  r"Positive real numbers $x$, $y$ and $z$ satisfy $x + y + z = 6$. What is the least possible value of $\frac{1}{x} + \frac{4}{y} + \frac{9}{z}$?",
  "TITA",
  r"By Cauchy-Schwarz, $(x + y + z)\left(\frac{1}{x} + \frac{4}{y} + \frac{9}{z}\right) \ge (1 + 2 + 3)^2 = 36$, so the expression is at least $\frac{36}{6} = 6$. Equality needs $x : y : z = 1 : 2 : 3$, that is $x = 1$, $y = 2$, $z = 3$, giving $1 + 2 + 3 = 6$. The least value is $6$.",
  "Setting x = y = z, or forgetting to divide by the fixed sum.",
  "C11C-reciprocal-sum-cauchy", "Three weighted terms; equal values give the wrong answer and AM-GM alone does not close.",
  tita_answer=6, check=_c019, values=[6],
  tita_traps=[(7, "Takes $x = y = z = 2$: $\\frac{1}{2} + 2 + \\frac{9}{2}$."),
              (36, "Stops at $(1 + 2 + 3)^2$ without dividing by $x + y + z = 6$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 020
def _c020():
    best = 0
    for nb in range(4, 500 // 35 + 1):
        for pen in range(0, 500 // 12 + 1):
            if 35 * nb + 12 * pen <= 500:
                best = max(best, nb + pen)
    return best
q("C11-C-020", TOPIC, "Most items within a budget with a minimum purchase of the costlier item", "Easy",
  "Casework/optimisation",
  r"Joseph has Rs. $500$ to buy pens at Rs. $12$ each and notebooks at Rs. $35$ each. He must buy at least $4$ notebooks and need not spend all the money. What is the greatest total number of items (pens and notebooks together) he can buy?",
  "TITA",
  r"Each notebook costs more than a pen, so to maximise the count he buys only the required $4$ notebooks, costing Rs. $140$. The remaining Rs. $360$ buys $\frac{360}{12} = 30$ pens. The total is $4 + 30 = 34$ items; a fifth notebook would leave Rs. $325$, enough for only $27$ pens.",
  "Ignoring the notebook requirement, or forgetting to add the notebooks.",
  "C11C-integer-programming", "One insight: buy the minimum of the costlier item.",
  tita_answer=34, check=_c020, values=[34],
  tita_traps=[(41, "Ignores the notebooks and divides $500$ by $12$."),
              (30, "Counts only the pens.")],
  cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    best = 0
    for a in range(0, 41):
        for b in range(0, 51):
            if 2 * a + b <= 40 and a + 2 * b <= 50:
                best = max(best, 400 * a + 300 * b)
    return best
q("C11-C-021", TOPIC, "Maximum profit under two resource limits", "Medium",
  "Casework/optimisation",
  r"A caterer prepares two kinds of party trays. A snack tray needs $2$ kg of flour and $1$ kg of paneer; a sweet tray needs $1$ kg of flour and $2$ kg of paneer. She has $40$ kg of flour and $50$ kg of paneer, and earns a profit of Rs. $400$ per snack tray and Rs. $300$ per sweet tray. Only complete trays can be sold. What is the greatest profit she can make?",
  "MCQ",
  r"With $s$ snack trays and $t$ sweet trays: $2s + t \le 40$ and $s + 2t \le 50$. The best point is a corner of this region: $(20, 0)$ gives Rs. $8{,}000$, $(0, 25)$ gives Rs. $7{,}500$, and the intersection of $2s + t = 40$ and $s + 2t = 50$ is $s = 10$, $t = 20$, giving $4000 + 6000 = $ Rs. $10{,}000$. Since this corner has whole numbers, the greatest profit is Rs. $10{,}000$.",
  "Checking only the axis corners, or combining two corners that cannot hold together.",
  "C11C-integer-programming", "Two constraints; the optimum is at the intersection corner, not at an axis.",
  correct=r"Rs. $10{,}000$",
  distractors=[(r"Rs. $8{,}000$", "Makes only snack trays, the more profitable item: $20 \\times 400$."),
               (r"Rs. $7{,}500$", "Makes only sweet trays: $25 \\times 300$."),
               (r"Rs. $15{,}500$", "Takes $20$ snack trays from the flour limit and $25$ sweet trays from the paneer limit together, which exceeds both supplies.")],
  check=_c021, values=[10000, 8000, 7500, 15500], cognitive="Application")

# ---------------------------------------------------------------- 022
def _c022():
    best = 0
    for d in range(0, 21):
        for s in range(0, 21):
            if 3 * d + 2 * s <= 20 and d + 2 * s <= 14:
                best = max(best, 700 * d + 500 * s)
    return best
q("C11-C-022", TOPIC, "Integer optimum that is not a rounded corner point", "Difficult",
  "Casework/optimisation",
  r"A small workshop makes desks and shelves. A desk needs $3$ hours of carpentry and $1$ hour of painting; a shelf needs $2$ hours of carpentry and $2$ hours of painting. Each week at most $20$ hours of carpentry and $14$ hours of painting are available. The profit is Rs. $700$ per desk and Rs. $500$ per shelf, and only complete items count. What is the greatest weekly profit, in rupees?",
  "TITA",
  r"With $d$ desks and $s$ shelves: $3d + 2s \le 20$ and $d + 2s \le 14$. The corner $3d + 2s = 20$, $d + 2s = 14$ is $d = 3$, $s = 5.5$, not whole. So check each $d$ with the most shelves it allows: $d = 0, 1, 2, 3, 4, 5, 6$ allow $s = 7, 6, 6, 5, 4, 2, 1$, giving profits $3500, 3700, 4400, 4600, 4800, 4500, 4700$. Rounding the corner down to $(3, 5)$ gives only $4600$, while $(4, 4)$ uses $20$ and $12$ hours and gives $2800 + 2000 = 4800$. The greatest weekly profit is Rs. $4{,}800$.",
  "Rounding the fractional corner down instead of searching nearby whole-number points.",
  "C11C-integer-programming", "The LP corner is fractional and rounding it is not optimal; needs a short search of integer points.",
  tita_answer=4800, check=_c022, values=[4800],
  tita_traps=[(4600, "Rounds the corner $d = 3$, $s = 5.5$ down to $(3, 5)$."),
              (4200, "Makes only desks, the more profitable item: $6 \\times 700$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 023
def _c023():
    grid_x = [Fraction(-3) + Fraction(k, 4) for k in range(0, 21)]   # -3 .. 2
    grid_y = [Fraction(-4) + Fraction(k, 4) for k in range(0, 37)]   # -4 .. 5
    return max(a * b for a in grid_x for b in grid_y)
q("C11-C-023", TOPIC, "Greatest product of two variables given their ranges", "Easy",
  "Casework/optimisation",
  r"Real numbers $x$ and $y$ satisfy $-3 \le x \le 2$ and $-4 \le y \le 5$. What is the greatest possible value of $xy$?",
  "MCQ",
  r"For a fixed $y$, $xy$ is linear in $x$, so the extremes occur at the corners. The four corner products are $(-3)(-4) = 12$, $(-3)(5) = -15$, $(2)(-4) = -8$ and $(2)(5) = 10$. The greatest is $12$.",
  "Multiplying the two upper ends, or ignoring signs.",
  "C11C-interval-bounds", "Single idea, check the four corners; the trap is multiplying the upper ends.",
  correct=r"$12$",
  distractors=[(r"$10$", "Multiplies the two upper ends: $2 \\times 5$."),
               (r"$15$", "Ignores the sign in $(-3) \\times 5$."),
               (r"$8$", "Ignores the sign in $2 \\times (-4)$.")],
  check=_c023, values=[12, 10, 15, 8], cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    A = [Fraction(2) + Fraction(k, 6) for k in range(0, 19)]   # 2 .. 5
    B = [Fraction(1) + Fraction(k, 6) for k in range(0, 19)]   # 1 .. 4
    return max((a - b) / (a + b) for a in A for b in B)
q("C11-C-024", TOPIC, "Greatest value of a ratio expression given variable ranges", "Medium",
  "Casework/optimisation",
  r"Real numbers $a$ and $b$ satisfy $2 \le a \le 5$ and $1 \le b \le 4$. The greatest possible value of $\frac{a - b}{a + b}$ is",
  "MCQ",
  r"Write $\frac{a - b}{a + b} = 1 - \frac{2b}{a + b} = 1 - \frac{2}{\frac{a}{b} + 1}$, which increases as $\frac{a}{b}$ increases. The largest $\frac{a}{b}$ is $\frac{5}{1}$, so the greatest value is $\frac{5 - 1}{5 + 1} = \frac{2}{3}$.",
  "Maximising the numerator and minimising the denominator separately.",
  "C11C-interval-bounds", "The numerator and denominator share variables, so they cannot be optimised separately; needs the monotone rewrite.",
  correct=r"$\frac{2}{3}$",
  distractors=[(r"$\frac{4}{3}$", "Takes the largest numerator $5 - 1$ over the smallest denominator $2 + 1$, using different values of $a$."),
               (r"$\frac{1}{3}$", "Uses the lower ends $a = 2$, $b = 1$."),
               (r"$\frac{1}{9}$", "Uses the upper ends $a = 5$, $b = 4$.")],
  check=_c024, values=[Rational(2, 3), Rational(4, 3), Rational(1, 3), Rational(1, 9)], cognitive="Analysis")

# ---------------------------------------------------------------- 025
def _c025():
    best = None
    for r in range(1, 511):
        if 510 % r == 0:
            per = 2 * (r + 510 // r)
            best = per if best is None or per < best else best
    return best
q("C11-C-025", TOPIC, "Least perimeter of a rectangle with whole-number sides and fixed area", "Easy",
  "Casework/optimisation",
  r"Shirin arranges all of $510$ identical square tiles, each of side $1$ m, into one solid rectangle with no gaps or overlaps. She then runs a border tape once around the outside edge of the rectangle. What is the least possible length of the tape, in metres?",
  "TITA",
  r"The sides are whole numbers $r$ and $c$ with $rc = 510$, and the tape length is $2(r + c)$. For a fixed product, $r + c$ is smallest when $r$ and $c$ are as close as possible to $\sqrt{510} \approx 22.6$. The factor pairs of $510$ near that are $17 \times 30$ (sum $47$) and $15 \times 34$ (sum $49$), so the best is $17 \times 30$ and the tape is $2 \times 47 = 94$ m.",
  r"Treating the sides as real numbers and rounding the bound $4\sqrt{510}$, or stopping at a factor pair that is not the closest.",
  "C11C-integer-near-equal-factors", "One idea: the AM-GM square is not available with whole sides, so pick the closest factor pair.",
  tita_answer=94, check=_c025, values=[94],
  tita_traps=[(91, r"Uses the square bound $4\sqrt{510} \approx 90.3$ and rounds up, though no rectangle of whole tiles has that perimeter."),
              (98, r"Takes the factor pair $15 \times 34$: $2(15 + 34)$."),
              (47, r"Reports the half perimeter $17 + 30$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 026
def _c026():
    best = 0
    for x in range(1, 43):
        for y in range(1, 43):
            if 2 * x + 3 * y == 42:
                best = max(best, x * y)
    return best
q("C11-C-026", TOPIC, "Greatest product of positive integers under a weighted linear condition", "Easy",
  "Conceptual/application",
  r"Positive integers $x$ and $y$ satisfy $2x + 3y = 42$. What is the greatest possible value of $xy$?",
  "TITA",
  r"Write $xy = \frac{1}{6}(2x)(3y)$; with $2x + 3y = 42$ fixed, the product is largest when $2x = 3y = 21$, giving the real bound $\frac{441}{6} = 73.5$. But $2x = 42 - 3y$ forces $y$ to be even, so try the even $y$ next to $7$: $y = 6$, $x = 12$ gives $72$, and $y = 8$, $x = 9$ gives $72$. The greatest value is $72$.",
  "Rounding the real optimum instead of checking the whole-number solutions nearby.",
  "C11C-weighted-amgm", "One weighted AM-GM step plus a quick check of the nearest integer solutions.",
  tita_answer=72, check=_c026, values=[72],
  tita_traps=[(73, r"Rounds the real bound $73.5$ down without checking that it is reached by integers."),
              (70, r"Rounds $x = 10.5$ down to $10$ and keeps $y = 7$, though $2 \times 10 + 3 \times 7 = 41$, not $42$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 027
def _c027():
    best = None
    tops = list(itertools.combinations(range(91, 101), 3))
    tsum = set(sum(t) for t in tops)
    for a in range(0, 90):
        for b in range(a + 1, 90):
            for c in range(b + 1, 90):
                if 595 - 90 - a - b - c in tsum:
                    best = b if best is None else min(best, b)
    return best
q("C11-C-027", TOPIC, "Least second-lowest score given average, median and a maximum mark", "Difficult",
  "Casework/optimisation",
  r"Seven students took a test marked out of $100$, and every student scored a whole number of marks. No two students scored the same. The average score was $85$ and the median score was $90$. What is the least possible score of the student with the second-lowest score, in marks?",
  "TITA",
  r"The total is $7 \times 85 = 595$ and the fourth score is $90$. The top three are at most $100 + 99 + 98 = 297$, so the three lowest scores $s_1 < s_2 < s_3$ total at least $595 - 90 - 297 = 208$. To keep $s_2$ small, push the third-lowest up to $s_3 = 89$ and the lowest up to $s_1 = s_2 - 1$: then $(s_2 - 1) + s_2 + 89 \ge 208$, so $s_2 \ge 60$. The scores $59, 60, 89, 90, 98, 99, 100$ total $595$, so the answer is $60$.",
  "Pushing the lowest score down, as when minimising the lowest score, instead of pushing it up against the second-lowest; or ignoring that the scores are distinct.",
  "C11C-extremes-of-distinct-integers", "The other scores must be pushed in opposite directions (top three and third-lowest up to their caps, the lowest up to just below the target), using the cap, distinctness and the median together.",
  tita_answer=60, check=_c027, values=[60],
  tita_traps=[(31, r"Minimises the lowest score instead: $595 - 297 - 90 - 89 - 88 = 31$."),
              (58, r"Ignores distinctness: top three at $100$, third-lowest at $90$, and $s_1 = s_2$, so $2s_2 \ge 115$ and $s_2 = 58$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 028
def _c028():
    return max(p * (200 - 4 * (p - 40)) for p in range(1, 91))
q("C11-C-028", TOPIC, "Revenue-maximising price with linear demand", "Medium",
  "Multi-step word problem",
  r"A juice stall sells $200$ glasses a day at Rs. $40$ per glass. For every Rs. $1$ increase in price it sells $4$ fewer glasses a day, and for every Rs. $1$ decrease it sells $4$ more. The price is always a whole number of rupees. What is the greatest possible daily revenue, in rupees?",
  "TITA",
  r"At price $p$, sales are $200 - 4(p - 40) = 360 - 4p$, so revenue is $p(360 - 4p) = \frac{1}{4}(4p)(360 - 4p)$. The factors $4p$ and $360 - 4p$ have a fixed sum, so revenue is largest when $4p = 180$, that is $p = 45$. Revenue is $45 \times 180 = 8100$ rupees.",
  "Assuming the current price is already best, or taking the midpoint of the wrong range.",
  "C11C-price-demand-revenue", "Two steps: build the demand and revenue expressions from a two-sided price change, then use the fixed-sum maximum and check the price is whole.",
  tita_answer=8100, check=_c028, values=[8100],
  tita_traps=[(8000, "Keeps the price at Rs. $40$: $40 \\times 200$."),
              (6500, "Raises the price by $25$, half of the $50$ rupee rise that would bring sales to zero: $65 \\times 100$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 029
def _c029():
    x = symbols('x', real=True)
    p = 50 + x
    profit = (p - 30) * (300 - 5 * x)
    s = solve(diff(profit, x), x)[0]
    return p.subs(x, s)
q("C11-C-029", TOPIC, "Profit-maximising price with a unit cost and linear demand", "Medium",
  "Multi-step word problem",
  r"A shopkeeper buys a gadget at Rs. $30$ each. At a selling price of Rs. $50$ he sells $300$ gadgets a month, and for every Rs. $1$ change in price his monthly sales change by $5$ in the opposite direction. The price can be set to any amount. At what selling price is his monthly profit the greatest?",
  "MCQ",
  r"At price $p$, sales are $300 - 5(p - 50) = 550 - 5p$, and profit is $(p - 30)(550 - 5p) = 5(p - 30)(110 - p)$. The factors $p - 30$ and $110 - p$ have a fixed sum $80$, so the product is largest when they are equal: $p - 30 = 110 - p$, giving $p = 70$. The best price is Rs. $70$.",
  "Maximising revenue instead of profit, or ignoring the existing margin.",
  "C11C-price-demand-revenue", "Profit, not revenue, must be maximised; the symmetric-factor insight gives the price directly.",
  correct=r"Rs. $70$",
  distractors=[(r"Rs. $55$", "Maximises revenue $p(550 - 5p)$ instead of profit."),
               (r"Rs. $80$", "Maximises $x(300 - 5x)$ for the rise $x$, ignoring the existing margin of Rs. $20$."),
               (r"Rs. $60$", "Assumes the best price doubles the cost price.")],
  check=_c029, values=[70, 55, 80, 60], cognitive="Application")

# ---------------------------------------------------------------- 030
def _c030():
    x, y = symbols('x y', positive=True)
    f = 4 * (x + y + 216 / (x * y))
    sol = solve([diff(f, x), diff(f, y)], [x, y], dict=True)
    return min(f.subs(s) for s in sol)
q("C11-C-030", TOPIC, "Least total edge length of a cuboid with fixed volume", "Easy",
  "Single-step computation",
  r"A wire frame in the shape of a cuboid is made by bending wire along all $12$ edges of the cuboid. The cuboid must have a volume of $216$ cm$^3$. What is the least possible total length of wire?",
  "MCQ",
  r"The total edge length is $4(l + w + h)$. By AM-GM, $l + w + h \ge 3\sqrt[3]{lwh} = 3\sqrt[3]{216} = 18$, with equality for a cube of side $6$ cm. The least wire length is $4 \times 18 = 72$ cm.",
  "Counting each dimension once instead of four times.",
  "C11C-box-amgm-three-terms", "Direct three-term AM-GM with a fixed product.",
  correct=r"$72$ cm",
  distractors=[(r"$18$ cm", "Stops at $l + w + h = 18$, counting each dimension once."),
               (r"$36$ cm", "Counts each dimension twice: $2 \\times 18$."),
               (r"$24$ cm", "Uses the perimeter of one square face: $4 \\times 6$.")],
  check=_c030, values=[72, 18, 36, 24], cognitive="Application")

# ---------------------------------------------------------------- 031
def _c031():
    x = symbols('x', positive=True)
    h = 4000 / x**2
    return _argmin_real(x**2 + 4 * x * h, x)
q("C11-C-031", TOPIC, "Least sheet area for an open box with a square base", "Medium",
  "Multi-step word problem",
  r"An open-top box with a square base must hold exactly $4000$ cm$^3$. Ignoring the thickness of the sheet and any overlaps, what is the least total area of sheet needed for the base and the four walls?",
  "MCQ",
  r"With base side $x$ and height $h = \frac{4000}{x^2}$, the area is $x^2 + 4xh = x^2 + \frac{16000}{x} = x^2 + \frac{8000}{x} + \frac{8000}{x}$. By AM-GM on these three terms, the area is at least $3\sqrt[3]{x^2 \cdot \frac{8000}{x} \cdot \frac{8000}{x}} = 3\sqrt[3]{64 \times 10^6} = 3 \times 400 = 1200$, with equality when $x^2 = \frac{8000}{x}$, that is $x = 20$ and $h = 10$. The least area is $1200$ cm$^2$.",
  "Adding a lid, or swapping the base side and the height.",
  "C11C-box-amgm-three-terms", "Needs the split of $\\frac{16000}{x}$ into two equal terms so the AM-GM product is constant.",
  correct=r"$1200$ cm$^2$",
  distractors=[(r"$1600$ cm$^2$", "Includes a lid: $2x^2 + 4xh$ at $x = 20$, $h = 10$."),
               (r"$800$ cm$^2$", "Counts only the four walls, $4xh$, at the optimum."),
               (r"$1700$ cm$^2$", "Swaps the base side and the height: $x = 10$, $h = 40$ gives $100 + 1600$.")],
  check=_c031, values=[1200, 1600, 800, 1700], cognitive="Application")

# ---------------------------------------------------------------- 032
def _c032():
    best = None
    for s1 in range(0, 11):
        for s2 in range(0, 11):
            rest = 100 - s1 - s2
            if rest < 0:
                continue
            m = max(s1, s2, -(-rest // 5))
            best = m if best is None or m < best else best
    return best
q("C11-C-032", TOPIC, "Least possible largest load with capacity limits on some bins", "Easy",
  "Casework/optimisation",
  r"A librarian puts $100$ books on $7$ shelves. Two of the shelves are small and can hold at most $10$ books each; the other five shelves have no limit. What is the least possible number of books on the fullest shelf?",
  "MCQ",
  r"The two small shelves take at most $20$ books, so at least $80$ books go on the five large shelves, and one of them must hold at least $\frac{80}{5} = 16$. Putting $10$ on each small shelf and $16$ on each large shelf achieves this. The answer is $16$.",
  "Spreading the books evenly over all seven shelves, ignoring the small shelves' limit.",
  "C11C-min-of-max-distribution", "Pigeonhole bound combined with a capacity limit.",
  correct=r"$16$",
  distractors=[(r"$15$", "Ignores the limit: $\\lceil 100 \\div 7 \\rceil = 15$."),
               (r"$14$", "Rounds $100 \\div 7$ down."),
               (r"$20$", "Leaves the small shelves empty and spreads $100$ over five shelves.")],
  check=_c032, values=[16, 15, 14, 20], cognitive="Application")

# ---------------------------------------------------------------- 033
def _c033():
    for m in range(1, 51):
        for c in itertools.combinations(range(1, m), 7):
            if sum(c) + m == 50:
                return m
    return None
q("C11-C-033", TOPIC, "Least possible maximum when all shares must be different", "Medium",
  "Casework/optimisation",
  r"A manager assigns $50$ identical tasks to $8$ teams. Every team gets at least one task, and no two teams get the same number of tasks. What is the least possible number of tasks given to the busiest team?",
  "MCQ",
  r"If the busiest team gets $m$ tasks, the eight different counts are at most $m, m - 1, \dots, m - 7$, with total $8m - 28$. We need $8m - 28 \ge 50$, so $m \ge 9.75$, that is $m \ge 10$. The counts $10, 9, 8, 7, 6, 5, 3, 2$ total $50$, so $10$ is achievable.",
  "Ignoring that the counts must be different, or making an off-by-one slip in the consecutive sum.",
  "C11C-min-of-max-distribution", "Distinctness changes the pigeonhole bound; needs the consecutive-block sum.",
  correct=r"$10$",
  distractors=[(r"$7$", "Ignores distinctness: $\\lceil 50 \\div 8 \\rceil = 7$."),
               (r"$9$", "Rounds $m \\ge 9.75$ down."),
               (r"$11$", "Writes the eight counts as $m, m - 1, \\dots, m - 8$, total $8m - 36 \\ge 50$, so $m \\ge 10.75$.")],
  check=_c033, values=[10, 7, 9, 11], cognitive="Application")

# ---------------------------------------------------------------- 034
def _c034():
    jobs = [3, 8, 5, 2, 6]
    best = None
    for perm in itertools.permutations(jobs):
        t = 0; total = 0
        for j in perm:
            t += j; total += t
        best = total if best is None or total < best else best
    return best
q("C11-C-034", TOPIC, "Order of jobs that minimises total waiting time", "Medium",
  "Conceptual/application",
  r"A tailor has five orders that need $3$, $8$, $5$, $2$ and $6$ hours of work. She works on one order at a time, without breaks, starting at $9{:}00$ am, and finishes each order before starting the next. Each customer waits from $9{:}00$ am until his or her order is finished. What is the least possible total of the five waiting times, in hours?",
  "TITA",
  r"A job done in position $k$ (from the start) adds its time to the waits of itself and every later customer, so longer jobs should go last. Order them $2, 3, 5, 6, 8$: finish times are $2, 5, 10, 16, 24$, total $57$ hours. Swapping any adjacent pair where the longer job comes first lowers the total, so $57$ is least.",
  "Keeping the given order, or doing the longest jobs first.",
  "C11C-scheduling-order", "Needs the exchange argument: shortest job first.",
  tita_answer=57, check=_c034, values=[57],
  tita_traps=[(72, "Keeps the given order $3, 8, 5, 2, 6$: $3 + 11 + 16 + 18 + 24$."),
              (24, "Reports only the time at which the last order is finished.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 035
def _c035():
    jobs = [10, 9, 8, 7, 6, 5, 4]
    best = None
    for assign in itertools.product(range(3), repeat=len(jobs)):
        loads = [0, 0, 0]
        for j, m in zip(jobs, assign):
            loads[m] += j
        mk = max(loads)
        best = mk if best is None or mk < best else best
    return best
q("C11-C-035", TOPIC, "Least finishing time when splitting jobs among three workers", "Difficult",
  "Casework/optimisation",
  r"Seven jobs take $10$, $9$, $8$, $7$, $6$, $5$ and $4$ hours. Three workers start together, each job must be done entirely by one worker, and a worker does one job at a time without breaks. What is the least number of hours after the start by which all seven jobs can be finished?",
  "TITA",
  r"The total work is $49$ hours, so some worker needs at least $\frac{49}{3} > 16$ hours, that is at least $17$ hours (all job times are whole numbers). The split $10 + 7 = 17$, $9 + 8 = 17$, $6 + 5 + 4 = 15$ finishes in $17$ hours. Giving each next-longest job to the least-loaded worker gives $19$ hours instead, so a careful split matters. The answer is $17$.",
  "Trusting a greedy assignment, or rounding the average load down.",
  "C11C-scheduling-order", "Lower bound by averaging plus a matching construction; the natural greedy rule fails.",
  tita_answer=17, check=_c035, values=[17],
  tita_traps=[(19, "Gives each next-longest job to the least-loaded worker: loads $15, 15, 19$."),
              (16, "Rounds $49 \\div 3 \\approx 16.3$ down.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    x = symbols('x', real=True)
    f = expand((x - 1) * (x - 3) * (x - 4) * (x - 6))
    crit = [s for s in solve(diff(f, x), x) if s.is_real]
    return simplify(min(f.subs(x, s) for s in crit))
q("C11-C-036", TOPIC, "Least value of a product of four linear factors by pairing", "Medium",
  "Conceptual/application",
  r"The least value of $(x - 1)(x - 3)(x - 4)(x - 6)$, as $x$ varies over all real numbers, is",
  "MCQ",
  r"Pair the outer and inner factors: $(x - 1)(x - 6) = x^2 - 7x + 6$ and $(x - 3)(x - 4) = x^2 - 7x + 12$. With $t = x^2 - 7x + 9$, the product is $(t - 3)(t + 3) = t^2 - 9 \ge -9$. Equality needs $t = 0$, that is $x^2 - 7x + 9 = 0$, which has real roots since $49 - 36 > 0$. The least value is $-9$.",
  "Assuming the minimum occurs at a root or at the midpoint of the roots.",
  "C11C-min-by-completing-square", "Needs the pairing substitution that turns a quartic into a square minus a constant.",
  correct=r"$-9$",
  distractors=[(r"$0$", "Assumes the least value occurs at a root of the product."),
               (r"$-6.25$", "Minimises only $(x - 1)(x - 6) = x^2 - 7x + 6$, whose least value is $6 - 12.25$."),
               (r"$1.5625$", "Evaluates at the midpoint $x = 3.5$: $(2.5)(0.5)(-0.5)(-2.5)$.")],
  check=_c036, values=[-9, 0, Rational(-25, 4), Rational(25, 16)], cognitive="Analysis")

# ---------------------------------------------------------------- 037
def _c037():
    x, y = symbols('x y', real=True)
    f = x**2 + y**2 - 6 * x + 8 * y + 40
    sol = solve([diff(f, x), diff(f, y)], [x, y], dict=True)[0]
    return f.subs(sol)
q("C11-C-037", TOPIC, "Least value of a two-variable quadratic by completing squares", "Easy",
  "Single-step computation",
  r"The least value of $x^2 + y^2 - 6x + 8y + 40$, as $x$ and $y$ vary over all real numbers, is",
  "MCQ",
  r"Complete the squares: $x^2 - 6x = (x - 3)^2 - 9$ and $y^2 + 8y = (y + 4)^2 - 16$. The expression is $(x - 3)^2 + (y + 4)^2 + 40 - 25 = (x - 3)^2 + (y + 4)^2 + 15 \ge 15$, with equality at $x = 3$, $y = -4$. The least value is $15$.",
  "Adding the completing-square constants instead of subtracting them.",
  "C11C-min-by-completing-square", "One technique applied twice.",
  correct=r"$15$",
  distractors=[(r"$40$", "Takes $x = y = 0$, reading off the constant term."),
               (r"$65$", "Adds $9$ and $16$ to $40$ instead of subtracting them."),
               (r"$25$", "Reports the total subtracted, $9 + 16$.")],
  check=_c037, values=[15, 40, 65, 25], cognitive="Application")

# ---------------------------------------------------------------- 038
def _c038():
    best = None
    for l in range(1, 361):
        if 360 % l: continue
        for w in range(l, 361):
            if (360 // l) % w: continue
            h = 360 // (l * w)
            if h < w: continue
            s = 2 * (l * w + w * h + h * l)
            best = s if best is None or s < best else best
    return best
q("C11-C-038", TOPIC, "Least surface area of a cuboid with integer edges and fixed volume", "Difficult",
  "Casework/optimisation",
  r"A carton in the shape of a cuboid has edges whose lengths are whole numbers of centimetres, and its volume is $360$ cm$^3$. What is the least possible total surface area of the carton?",
  "MCQ",
  r"The edges should be as close to $\sqrt[3]{360} \approx 7.1$ as possible, but $7$ does not divide $360$. Candidates near equal are $6 \times 6 \times 10$, with surface $2(36 + 60 + 60) = 312$; $5 \times 8 \times 9$, with $2(40 + 72 + 45) = 314$; $5 \times 6 \times 12$, with $2(30 + 72 + 60) = 324$; and $4 \times 9 \times 10$, with $2(36 + 90 + 40) = 332$. Every other factorisation is more spread out and gives more. The least surface area is $312$ cm$^2$.",
  "Picking the triple with the closest-looking edges without computing the surface area.",
  "C11C-integer-near-equal-factors", "AM-GM gives the direction but not the answer; two close candidates must be compared exactly.",
  correct=r"$312$ cm$^2$",
  distractors=[(r"$314$ cm$^2$", r"Chooses $5 \times 8 \times 9$ because its edges have the smallest total distance from $\sqrt[3]{360} \approx 7.1$ ($4.9$ against $5.1$ for $6, 6, 10$), without computing surface areas."),
               (r"$324$ cm$^2$", "Starts from the factor $6$, then splits $60$ as $5 \\times 12$."),
               (r"$332$ cm$^2$", "Chooses $4 \\times 9 \\times 10$ after pairing $9$ and $10$ as the edges nearest $\\sqrt{90}$.")],
  check=_c038, values=[312, 314, 324, 332], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 039
def _c039():
    import random
    rnd = random.Random(11)
    ok = [True, True, True]
    for _ in range(20000):
        a = Fraction(rnd.randint(1, 400), rnd.randint(1, 60))
        b = Fraction(rnd.randint(1, 400), rnd.randint(1, 60))
        c = Fraction(8) / (a * b)
        if not (a + b + c >= 6): ok[0] = False
        if not ((1 + a) * (1 + b) * (1 + c) >= 27): ok[1] = False
        if not (a * b + b * c + c * a >= a + b + c): ok[2] = False
    # explicit counterexample to III: a = b = 1/2, c = 32
    a = b = Fraction(1, 2); c = Fraction(8) / (a * b)
    assert a * b * c == 8 and a * b + b * c + c * a < a + b + c
    ok[2] = False
    return ok[0] * 1 + ok[1] * 2 + ok[2] * 4
q("C11-C-039", TOPIC, "Which inequalities hold for three positives with a fixed product", "Difficult",
  "Conceptual/application",
  r"Positive real numbers $a$, $b$ and $c$ satisfy $abc = 8$. Consider the statements: I. $a + b + c \ge 6$; II. $(1 + a)(1 + b)(1 + c) \ge 27$; III. $ab + bc + ca \ge a + b + c$. Which of these statements must be true?",
  "MCQ",
  r"By AM-GM, $a + b + c \ge 3\sqrt[3]{abc} = 6$ and $ab + bc + ca \ge 3\sqrt[3]{(abc)^2} = 12$, so I holds. Expanding, $(1 + a)(1 + b)(1 + c) = 1 + (a + b + c) + (ab + bc + ca) + abc \ge 1 + 6 + 12 + 8 = 27$, so II holds. Statement III holds at $a = b = c = 2$ ($12 \ge 6$), but take $a = b = \frac{1}{2}$, $c = 32$: then $ab + bc + ca = \frac{1}{4} + 16 + 16 = 32.25$ while $a + b + c = 33$, so III fails. Only I and II must be true.",
  "Accepting a statement because it holds at the equal-value point, without testing a lopsided triple.",
  "C11C-amgm-consequences", "II needs expansion and two AM-GM bounds combined; III looks true at every balanced triple and must be broken by a lopsided counterexample.",
  correct=r"I and II only",
  distractors=[(r"I, II and III", r"Tests III only at balanced triples such as $(2, 2, 2)$ and $(1, 2, 4)$, where it holds, and accepts it."),
               (r"I only", r"Doubts II because one factor $1 + a$ can be close to $1$, and does not expand the product; also rejects III."),
               (r"I and III only", r"Expands II without the pairwise term, getting only $1 + 6 + 8 = 15$, so rejects II; accepts III from the balanced case.")],
  check=_c039, values=[3, 7, 1, 5], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 040
def _c040():
    best = 0
    for k in range(0, 40):
        fare = 200 - 5 * k
        riders = min(60 + 3 * k, 80)
        best = max(best, fare * riders)
    return best
q("C11-C-040", TOPIC, "Revenue-maximising discount with a seating limit", "Difficult",
  "Casework/optimisation",
  r"A tour bus has $80$ seats. At a fare of Rs. $200$, $60$ passengers book. For every Rs. $5$ cut in the fare, $3$ more passengers want to book; the fare can only be cut in steps of Rs. $5$, and no more than $80$ passengers can travel. What is the greatest possible fare revenue for one trip?",
  "MCQ",
  r"After $k$ cuts, the fare is $200 - 5k$ and demand is $60 + 3k$. Without the seat limit, $(200 - 5k)(60 + 3k) = 15(40 - k)(20 + k)$ is largest when $40 - k = 20 + k$, at $k = 10$, but that needs $90$ seats. Demand stays within $80$ only for $k \le 6$, where revenue is still rising, so $k = 6$ gives $170 \times 78 = 13260$. At $k = 7$ only $80$ can travel at Rs. $165$, giving $13200$, and further cuts only lower revenue. The greatest revenue is Rs. $13{,}260$.",
  "Ignoring the seat limit, or assuming a full bus is always best.",
  "C11C-price-demand-revenue", "The unconstrained optimum is infeasible; must compare the boundary step with the full-bus step.",
  correct=r"Rs. $13{,}260$",
  distractors=[(r"Rs. $13{,}500$", "Ignores the seat limit and uses $k = 10$: $150 \\times 90$."),
               (r"Rs. $13{,}200$", "Cuts the fare until the bus is full: $k = 7$, $80$ passengers at Rs. $165$."),
               (r"Rs. $12{,}000$", "Keeps the original fare: $200 \\times 60$.")],
  check=_c040, values=[13260, 13500, 13200, 12000], cognitive="Analysis", exams=HARD)
