import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig

T = "Chords, tangents and angles"
CX = ("CAT", "XAT")
x, y, r, a, b, d, s, t = symbols('x y r a b d s t', real=True)


# ---------------------------------------------------------------- geometry helpers (floats)
def _P(deg, rad=1.0, c=(0.0, 0.0)):
    return (c[0] + rad * math.cos(math.radians(deg)), c[1] + rad * math.sin(math.radians(deg)))


def _ang(A, V, B):
    ax, ay = A[0] - V[0], A[1] - V[1]
    bx, by = B[0] - V[0], B[1] - V[1]
    return math.degrees(math.atan2(abs(ax * by - ay * bx), ax * bx + ay * by))


def _dist(A, B):
    return math.hypot(A[0] - B[0], A[1] - B[1])


def _meet(P1, P2, P3, P4):
    x1, y1 = P1; x2, y2 = P2; x3, y3 = P3; x4, y4 = P4
    den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
    py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
    return (px, py)


def _bisect(f, lo, hi, n=200):
    flo = f(lo)
    for _ in range(n):
        mid = (lo + hi) / 2
        fm = f(mid)
        if (fm > 0) == (flo > 0):
            lo, flo = mid, fm
        else:
            hi = mid
    return (lo + hi) / 2


def _tangent_pts(X, rad=1.0):
    # tangent points from external point X to circle centred at origin
    dd = math.hypot(*X)
    base = math.atan2(X[1], X[0])
    half = math.acos(rad / dd)
    return (rad * math.cos(base + half), rad * math.sin(base + half)), (rad * math.cos(base - half), rad * math.sin(base - half))


def _chord_through(Xp, theta, rad):
    # endpoints parameters of the chord through interior point Xp in direction theta
    ux, uy = math.cos(theta), math.sin(theta)
    bb = Xp[0] * ux + Xp[1] * uy
    cc = Xp[0] ** 2 + Xp[1] ** 2 - rad * rad
    disc = math.sqrt(bb * bb - cc)
    return -bb + disc, -bb - disc


# ---------------------------------------------------------------- 001
def _c001():
    sol = solve(Eq(x**2 + 8**2, 17**2), x)
    return max(sol) - min(sol)
f = Fig()
O = f.pt("O", 0, 0); P = f.pt("P", -15, -8); Q = f.pt("Q", 15, -8); M = f.pt("M", 0, -8, offset=(0, -1))
f.circle((0, 0), 17); f.seg(P, Q); f.seg(O, M, dashed=True); f.seg(O, Q)
f.right_angle(O, M, Q); f.label_seg(O, M, "8 m", side=-1); f.label_seg(O, Q, "17 m")
_alt = "Circle with centre O and radius OQ = 17 m. A chord PQ lies below O, and the perpendicular OM from O to the chord has length 8 m."
q("C16-A-001", T, "Length of a chord from the radius and its distance from the centre", "Easy",
  "Single-step computation",
  r"A straight footpath runs across a circular lawn of radius $17$ m. The perpendicular distance of the footpath from the centre of the lawn is $8$ m. What is the length, in metres, of the part of the footpath that lies inside the lawn?",
  "TITA",
  r"The perpendicular from the centre bisects the chord. If the half-length is $h$, then $h^2 + 8^2 = 17^2$, so $h^2 = 289 - 64 = 225$ and $h = 15$ m. The full chord is $2 \times 15 = 30$ m.",
  "Reporting the half-chord found from the right triangle instead of the full chord.",
  "C16A-chord-distance-centre", "One right triangle (radius, distance, half-chord) and one doubling.",
  tita_answer=30, check=_c001, cognitive="Application",
  tita_traps=[(15, "Stops at the half-chord $\\sqrt{17^2 - 8^2}$."),
              (18, "Takes the chord as $2(17 - 8)$, subtracting instead of using Pythagoras.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 002
def _c002():
    sol = [v for v in solve(Eq(21**2 + d**2, 29**2), d) if v > 0][0]
    # bar is the line y = -sol below the centre; the top of the window is at y = +29
    return 29 - (-sol)
q("C16-A-002", T, "Height of the top of a circle above a chord below the centre", "Easy",
  "Multi-step word problem",
  r"A circular window has radius $29$ cm. A straight horizontal bar of length $42$ cm is fixed across the window with both its ends on the frame, and the bar lies below the centre of the window. How high is the topmost point of the window above the bar?",
  "MCQ",
  r"The bar is a chord of length $42$ cm, so its half-length is $21$ cm. Its distance from the centre is $\sqrt{29^2 - 21^2} = \sqrt{841 - 441} = 20$ cm. The bar is $20$ cm below the centre and the top of the window is $29$ cm above it, so the height is $20 + 29 = 49$ cm.",
  "Measuring from the bar to the nearer part of the circle (radius minus distance) instead of across the centre to the top.",
  "C16A-chord-distance-centre", "Half-chord and distance from the centre, then one more step across the centre.",
  correct=r"$49$ cm",
  distractors=[(r"$9$ cm", r"Computes $29 - 20$, the depth of the window below the bar, instead of the height above it."),
               (r"$29$ cm", r"Takes the height above the bar as the radius, as if the bar passed through the centre."),
               (r"$41$ cm", r"Adds the half-length $21$ of the bar to the distance $20$ of the bar from the centre.")],
  check=_c002, values=[49, 9, 29, 41], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    sol = solve(Eq((r - 8)**2 + 24**2, r**2), r)
    return [v for v in sol if v > 8][0]
q("C16-A-003", T, "Radius of a circular arch from its span and rise", "Medium",
  "Multi-step word problem",
  r"The arch of a bridge is an arc of a circle. The two ends of the arch are at water level and $48$ m apart, and the highest point of the arch is $8$ m above the water level. What is the radius, in metres, of the circle of which the arch is a part?",
  "TITA",
  r"The span is a chord of length $48$ m and the rise of $8$ m is measured along the perpendicular bisector of that chord, which passes through the centre. The centre is therefore $r - 8$ below the chord, and $(r - 8)^2 + 24^2 = r^2$. This gives $-16r + 64 + 576 = 0$, so $r = 40$ m.",
  "Using the full span instead of the half-span, or forgetting to halve when solving $16r = 640$.",
  "C16A-arch-rise-radius", "The centre lies below the chord at an unknown distance, so a linear equation in $r$ must be set up.",
  tita_answer=40, check=_c003, cognitive="Application",
  tita_traps=[(80, "Solves $8r = 24^2 + 8^2$, dropping the factor $2$ in $2 \\times 8 \\times r$."),
              (24, "Takes the radius as the half-span."),
              (36, "Computes only $\\frac{24^2}{2 \\times 8}$ and forgets to add half the rise.")])

# ---------------------------------------------------------------- 004
def _c004():
    sol = solve([Eq(r**2, 15**2 + a**2), Eq(r**2, 24**2 + (27 - a)**2)], [r, a], dict=True)
    return [z[r] for z in sol if z[r] > 0 and 0 <= z[a] <= 27][0]
f = Fig()
O = f.pt("O", 0, 0, offset=(1, 0))
P = f.pt("P", -15, 20); Q = f.pt("Q", 15, 20); R = f.pt("R", -24, -7); S = f.pt("S", 24, -7)
f.circle((0, 0), 25); f.seg(P, Q); f.seg(R, S); f.seg((0, 20), (0, -7), dashed=True)
f.label_seg(P, Q, "30 cm"); f.label_seg(R, S, "48 cm"); f.text((5.5, 8), "27 cm")
_alt = "Circle with centre O. Chord PQ of length 30 cm lies above O and chord RS of length 48 cm lies below O, parallel to PQ. A dashed perpendicular segment of length 27 cm joins the two chords."
q("C16-A-004", T, "Radius from two parallel chords on opposite sides of the centre", "Medium",
  "Multi-step word problem",
  r"Two parallel chords of a circle have lengths $30$ cm and $48$ cm, and they lie on opposite sides of the centre. The distance between the two chords is $27$ cm. What is the radius of the circle, in cm?",
  "TITA",
  r"Let the chords be at distances $p$ and $27 - p$ from the centre. Then $r^2 = 15^2 + p^2 = 24^2 + (27 - p)^2$. So $p^2 - (27 - p)^2 = 576 - 225 = 351$, that is $27(2p - 27) = 351$, giving $2p - 27 = 13$ and $p = 20$. Hence $r^2 = 225 + 400 = 625$ and $r = 25$ cm.",
  "Reporting a distance of a chord from the centre as the radius.",
  "C16A-parallel-chords", "Two right triangles sharing the radius, linked by the gap between the chords.",
  tita_answer=25, check=_c004, cognitive="Application",
  tita_traps=[(20, "Reports the distance of the shorter chord from the centre."),
              (39, "Adds the half-chords $15 + 24$.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 005
def _c005():
    found = set()
    p, qq = symbols('p qq', nonnegative=True)
    # p = distance of the 120 cm chord, qq = distance of the 104 cm chord
    for rel in (Eq(p + qq, 14), Eq(qq - p, 14), Eq(p - qq, 14)):
        for z in solve([Eq(60**2 + p**2, 52**2 + qq**2), rel], [p, qq], dict=True):
            if z[p] >= 0 and z[qq] >= 0:
                found.add(z[p])
    assert len(found) == 1
    return found.pop()
q("C16-A-005", T, "Distance of a chord from the centre when two parallel chords are close together", "Medium",
  "Casework/optimisation",
  r"Two parallel chords of a circle have lengths $120$ cm and $104$ cm, and the distance between them is $14$ cm. How far is the longer chord from the centre of the circle?",
  "MCQ",
  r"Let the $120$ cm chord be at distance $p$ and the $104$ cm chord at distance $q$ from the centre. Then $60^2 + p^2 = 52^2 + q^2$, so $q^2 - p^2 = 896$. If the chords were on opposite sides, $p + q = 14$ would force $q - p = 64 > 14$, which is impossible. So they are on the same side with $q - p = 14$, which gives $q + p = 64$, so $q = 39$ and $p = 25$ cm.",
  "Assuming the centre lies between the chords, or reporting the distance of the shorter chord.",
  "C16A-parallel-chords", "Must decide which side of the centre the chords lie on; the opposite-side case fails.",
  correct=r"$25$ cm",
  distractors=[(r"$39$ cm", r"Reports the distance $q$ of the shorter chord from the centre."),
               (r"$32$ cm", r"Halves $p + q = 64$, as if the two distances were equal."),
               (r"$7$ cm", r"Assumes the centre lies midway between the chords, at $\frac{14}{2}$ from each.")],
  check=_c005, values=[25, 39, 32, 7], cognitive="Analysis")

# ---------------------------------------------------------------- 006
def _c006():
    dists = set()
    y1 = sqrt(25**2 - 7**2); y2 = sqrt(25**2 - 24**2)
    for s1 in (1, -1):
        for s2 in (1, -1):
            dists.add(abs(s1 * y1 - s2 * y2))
    return sum(dists)
q("C16-A-006", T, "Both possible gaps between two parallel chords of given lengths", "Medium",
  "Casework/optimisation",
  r"Two parallel chords of a circle of radius $25$ cm have lengths $14$ cm and $48$ cm. Find the sum, in cm, of all the possible values of the distance between the two chords.",
  "TITA",
  r"The $14$ cm chord is at distance $\sqrt{625 - 49} = 24$ cm from the centre and the $48$ cm chord at $\sqrt{625 - 576} = 7$ cm. If both lie on the same side of the centre the gap is $24 - 7 = 17$ cm; on opposite sides it is $24 + 7 = 31$ cm. Both are possible, and the sum is $17 + 31 = 48$.",
  "Considering only one of the two arrangements of the chords.",
  "C16A-parallel-chords", "Two direct Pythagoras steps plus the same-side and opposite-side observation; a typical two-idea item.",
  tita_answer=48, check=_c006, cognitive="Analysis",
  tita_traps=[(17, "Considers only chords on the same side of the centre."),
              (31, "Considers only chords on opposite sides of the centre.")])

# ---------------------------------------------------------------- 007
def _c007():
    # radius from the longest chord (a diameter through X); find OX so that the
    # shortest chord through X (found by scanning directions) is 48
    R0 = 52 / 2.0
    def shortest(D):
        Xp = (D, 0.0)
        best = None
        for i in range(3600):
            t1, t2 = _chord_through(Xp, math.pi * i / 3600, R0)
            v = t1 - t2
            best = v if best is None or v < best else best
        return best
    D = _bisect(lambda u: shortest(u) - 48.0, 0.0, R0 - 1e-6, n=60)
    return round(D, 6)
q("C16-A-007", T, "Distance of an interior point from the centre, given the longest and shortest chords through it", "Easy",
  "Conceptual/application",
  r"Through a point X inside a circle, the longest chord that can be drawn has length $52$ cm and the shortest chord that can be drawn has length $48$ cm. How far is X from the centre of the circle?",
  "MCQ",
  r"The longest chord through X is the diameter, so the radius is $26$ cm. The shortest chord through X is the one perpendicular to the line joining X to the centre, and X is its midpoint, so its half-length $24$ cm and the distance $d$ of X from the centre satisfy $d^2 + 24^2 = 26^2$. Hence $d = \sqrt{676 - 576} = 10$ cm.",
  "Treating the two given chords as unrelated lengths and subtracting them, instead of recognising the diameter and the chord perpendicular to OX.",
  "C16A-chord-through-point", "One insight (longest is the diameter, shortest is perpendicular to OX) and one right triangle.",
  correct=r"$10$ cm",
  distractors=[(r"$4$ cm", r"Subtracts the two chords, $52 - 48$."),
               (r"$2$ cm", r"Subtracts the half-lengths, $26 - 24$, instead of using Pythagoras."),
               (r"$24$ cm", r"Reports the half-length of the shortest chord.")],
  check=_c007, values=[10, 4, 2, 24], cognitive="Understanding")

# ---------------------------------------------------------------- 008
def _c008():
    R0, D0, N = 17.0, 15.0, 72000
    Xp = (D0, 0.0)
    Ls = []
    for i in range(N):
        th = math.pi * i / N
        t1, t2 = _chord_through(Xp, th, R0)
        Ls.append(t1 - t2)
    total = 0
    for m in range(1, 35):
        cnt = sum(1 for v in Ls if abs(v - m) < 1e-9)
        for i in range(N):
            u, w = Ls[i] - m, Ls[(i + 1) % N] - m
            if abs(u) < 1e-9 or abs(w) < 1e-9:
                continue
            if (u > 0) != (w > 0):
                cnt += 1
        total += cnt
    return total
q("C16-A-008", T, "Counting chords of integer length through an interior point", "Difficult",
  "Casework/optimisation",
  r"A point X lies inside a circle of radius $17$ cm at a distance of $15$ cm from the centre. How many chords of the circle passing through X have a length that is a whole number of centimetres?",
  "TITA",
  r"The shortest chord through X is perpendicular to the line joining X to the centre, with length $2\sqrt{17^2 - 15^2} = 16$ cm, and the longest is the diameter, $34$ cm. As the chord turns about X, every length strictly between $16$ and $34$ occurs for exactly two chords (mirror images in the diameter through X), while $16$ and $34$ occur once each. The integer lengths $17, 18, \ldots, 33$ number $17$, giving $2 \times 17 = 34$ chords, plus $2$ more for $16$ and $34$: $36$ chords.",
  "Counting each integer length once, or counting the shortest chord and the diameter twice.",
  "C16A-chord-through-point", "Requires the range of chord lengths and a symmetry count with two exceptional lengths.",
  tita_answer=36, check=_c008, cognitive="Analysis", exams=CX,
  tita_traps=[(19, "Counts the distinct integer lengths $16$ to $34$ instead of the chords."),
              (38, "Counts every integer length twice, including the unique shortest chord and the diameter.")])

# ---------------------------------------------------------------- 009
def _c009():
    Xp = (7.0, 0.0)
    def g(th):
        t1, t2 = _chord_through(Xp, th, 13.0)
        return (t1 - t2) - 23.0
    th = _bisect(g, 0.0, math.pi / 2)
    t1, t2 = _chord_through(Xp, th, 13.0)
    return round(max(abs(t1), abs(t2)), 9)
q("C16-A-009", T, "Segments of a chord through an interior point at a known distance from the centre", "Medium",
  "Multi-step word problem",
  r"A point X lies inside a circle of radius $13$ cm at a distance of $7$ cm from the centre. A chord PQ of length $23$ cm passes through X. What is the length, in cm, of the longer of the two segments PX and XQ?",
  "TITA",
  r"Extend the line through X and the centre to a diameter; X divides it into $13 + 7 = 20$ and $13 - 7 = 6$. By the intersecting chords theorem, $PX \cdot XQ = 20 \times 6 = 120$. With $PX + XQ = 23$, the segments are the roots of $t^2 - 23t + 120 = 0$, that is $8$ and $15$. The longer segment is $15$ cm.",
  "Not seeing that the product of the segments is fixed by the diameter through X.",
  "C16A-intersecting-chords-power", "Needs the diameter through X as an auxiliary chord, then a sum-product quadratic.",
  tita_answer=15, check=_c009, cognitive="Application",
  tita_traps=[(8, "Reports the shorter segment."),
              (20, "Reports the longer part of the diameter through X instead of the chord's segment.")])

# ---------------------------------------------------------------- 010
def _c010():
    sol = solve(Eq(6 * 8, x * (16 - x)), x)
    return max(sol)
q("C16-A-010", T, "Splitting a chord when its total length and the other chord's segments are known", "Medium",
  "Multi-step word problem",
  r"Two chords PQ and RS of a circle intersect at X. PX $= 6$ cm, XQ $= 8$ cm and the chord RS has length $16$ cm, with RX shorter than XS. What is the length of XS?",
  "MCQ",
  r"By the intersecting chords theorem, $RX \cdot XS = PX \cdot XQ = 48$. With $RX + XS = 16$, the two parts are roots of $t^2 - 16t + 48 = 0$, that is $(t - 4)(t - 12) = 0$. Since RX is the shorter part, XS $= 12$ cm.",
  "Reporting the shorter part, or assuming X bisects RS.",
  "C16A-intersecting-chords-power", "Product from one chord and sum from the other give a quadratic.",
  correct=r"$12$ cm",
  distractors=[(r"$4$ cm", r"Reports RX, the shorter part, instead of XS."),
               (r"$8$ cm", r"Assumes X is the midpoint of RS and halves $16$."),
               (r"$10$ cm", r"Assumes RX equals PX $= 6$, so XS $= 16 - 6$.")],
  check=_c010, values=[12, 4, 8, 10], cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    import sympy as _sp
    C = _sp.Circle(_sp.Point(-13, 0), _sp.Point(27, 0), _sp.Point(0, -9))
    return C.radius
q("C16-A-011", T, "Radius from the segments of two perpendicular chords", "Difficult",
  "Multi-step word problem",
  r"Two chords PQ and RS of a circle intersect at right angles at a point X inside the circle. If PX $= 13$ cm, XQ $= 27$ cm and RX $= 9$ cm, what is the radius of the circle?",
  "MCQ",
  r"First, $XS = \frac{13 \times 27}{9} = 39$ cm. The perpendicular from the centre to PQ meets it at its midpoint, which is $20 - 13 = 7$ cm from X; the perpendicular to RS meets it at its midpoint, $24 - 9 = 15$ cm from X. So the centre is $15$ cm from chord PQ (whose half-length is $20$) and $r^2 = 20^2 + 15^2 = 625$. Check: $24^2 + 7^2 = 625$ as well. The radius is $25$ cm.",
  "Treating one of the chords as a diameter.",
  "C16A-perpendicular-chords-radius", "Needs the missing segment, then locating the centre from both chord midpoints; a non-obvious model.",
  correct=r"$25$ cm",
  distractors=[(r"$20$ cm", r"Assumes PQ (length $40$) is a diameter."),
               (r"$24$ cm", r"Finds RS $= 48$ and assumes it is a diameter."),
               (r"$22$ cm", r"Averages the two half-chord lengths $20$ and $24$.")],
  check=_c011, values=[25, 20, 24, 22], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 012
def _c012():
    Pp, Qp, Rp = _P(0), _P(130), _P(245)
    assert abs(_ang(Pp, (0, 0), Qp) - 130) < 1e-9
    return _ang(Pp, Rp, Qp)
f = Fig()
O = f.pt("O", 0, 0, offset=(0, 1)); P = f.pt("P", *_P(205)); Q = f.pt("Q", *_P(335)); R = f.pt("R", *_P(90))
f.circle((0, 0), 1); f.seg(O, P); f.seg(O, Q); f.seg(R, P); f.seg(R, Q)
f.angle_mark(P, O, Q, "130^\\circ", r=0.18)
_alt = "Circle with centre O. Radii OP and OQ make an angle of 130 degrees at O. Point R lies on the major arc PQ and is joined to P and Q."
q("C16-A-012", T, "Inscribed angle on the major arc from the central angle", "Easy",
  "Conceptual/application",
  r"P and Q are points on a circle with centre O such that $\angle POQ = 130^\circ$. R is a point on the major arc PQ. What is $\angle PRQ$?",
  "MCQ",
  r"The angle subtended by an arc at the centre is twice the angle it subtends at any point on the remaining part of the circle. The minor arc PQ subtends $130^\circ$ at O and R lies on the major arc, so $\angle PRQ = \frac{130^\circ}{2} = 65^\circ$.",
  "Taking the inscribed angle equal to the central angle, or using the supplement meant for the other arc.",
  "C16A-inscribed-vs-central", "Direct use of the central angle theorem; trap is the arc on which R lies.",
  correct=r"$65^\circ$",
  distractors=[(r"$130^\circ$", r"Takes the inscribed angle equal to the central angle."),
               (r"$115^\circ$", r"Uses $180^\circ - 65^\circ$, the angle for a point on the minor arc."),
               (r"$50^\circ$", r"Uses $180^\circ - 130^\circ$.")],
  check=_c012, values=[65, 130, 115, 50], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 013
def _c013():
    Pp = _P(0)
    tq = _bisect(lambda u: _ang((0, 0), Pp, _P(u)) - 28, 1.0, 179.0)
    Qp = _P(tq)
    Rp = _P(tq + (360 - tq) / 2)
    return _ang(Pp, Rp, Qp)
q("C16-A-013", T, "Inscribed angle from a base angle of the isosceles triangle formed by two radii", "Easy",
  "Multi-step word problem",
  r"PQ is a chord of a circle with centre O, and $\angle OPQ = 28^\circ$. R is a point on the major arc PQ. What is $\angle PRQ$?",
  "MCQ",
  r"Since OP $=$ OQ, triangle OPQ is isosceles and $\angle OQP = 28^\circ$, so $\angle POQ = 180^\circ - 56^\circ = 124^\circ$. R lies on the major arc, so $\angle PRQ = \frac{124^\circ}{2} = 62^\circ$. (Equivalently, $\angle PRQ = 90^\circ - 28^\circ$.)",
  "Stopping at the central angle, or equating the inscribed angle with the base angle.",
  "C16A-inscribed-vs-central", "Two short steps: isosceles triangle of radii, then halve the central angle.",
  correct=r"$62^\circ$",
  distractors=[(r"$124^\circ$", r"Stops at the central angle POQ."),
               (r"$28^\circ$", r"Assumes $\angle PRQ$ equals the given base angle."),
               (r"$56^\circ$", r"Doubles the base angle instead of using the angle sum.")],
  check=_c013, values=[62, 124, 28, 56], cognitive="Application")

# ---------------------------------------------------------------- 014
def _c014():
    Pp = _P(0)
    tq = _bisect(lambda u: _dist(Pp, _P(u)) - 1.0, 1.0, 179.0)
    Rp = _P(tq / 2)
    return _ang(Pp, Rp, _P(tq))
q("C16-A-014", T, "Angle in the minor segment of a chord equal to the radius", "Easy",
  "Conceptual/application",
  r"A chord PQ of a circle is equal in length to the radius of the circle. R is a point on the minor arc PQ. What is $\angle PRQ$?",
  "MCQ",
  r"With the centre O, triangle OPQ has all sides equal to the radius, so $\angle POQ = 60^\circ$. A point on the major arc sees PQ at $30^\circ$. R lies on the minor arc, and a point on the major arc together with P, R, Q forms a cyclic quadrilateral, so $\angle PRQ = 180^\circ - 30^\circ = 150^\circ$.",
  "Using the angle for a point on the major arc instead of the minor arc.",
  "C16A-inscribed-vs-central", "One fact (equilateral triangle of radii) and the angle in the minor segment.",
  correct=r"$150^\circ$",
  distractors=[(r"$30^\circ$", r"Gives the angle at a point on the major arc."),
               (r"$60^\circ$", r"Gives the central angle POQ."),
               (r"$120^\circ$", r"Uses $180^\circ - 60^\circ$, the supplement of the central angle.")],
  check=_c014, values=[150, 30, 60, 120], cognitive="Understanding")

# ---------------------------------------------------------------- 015
def _c015():
    w = [1, 2, 3, 4]
    tot = sum(w); pos = [0]
    for k in w[:-1]:
        pos.append(pos[-1] + 360 * k / tot)
    pts = [_P(z) for z in pos]
    angs = [_ang(pts[i - 1], pts[i], pts[(i + 1) % 4]) for i in range(4)]
    return max(angs)
q("C16-A-015", T, "Angles of a cyclic quadrilateral from the ratio of the arcs cut off by its vertices", "Medium",
  "Multi-step word problem",
  r"Four points P, Q, R and S lie in that order on a circle and divide it into arcs PQ, QR, RS and SP whose lengths are in the ratio $1 : 2 : 3 : 4$. What is the largest angle of the quadrilateral PQRS?",
  "MCQ",
  r"The arcs measure $36^\circ, 72^\circ, 108^\circ$ and $144^\circ$. Each angle of the quadrilateral is half the arc opposite it (the arc not containing that vertex). The angle at Q stands on arc RSP $= 108^\circ + 144^\circ = 252^\circ$, so $\angle Q = 126^\circ$; similarly $\angle P = 90^\circ$, $\angle R = 90^\circ$ and $\angle S = 54^\circ$. The largest angle is $126^\circ$.",
  "Assuming the angles of the quadrilateral are in the same ratio as the arcs.",
  "C16A-arc-ratio-angles", "Requires matching each vertex to the correct intercepted arc and comparing four angles.",
  correct=r"$126^\circ$",
  distractors=[(r"$144^\circ$", r"Takes the angles in the same ratio $1 : 2 : 3 : 4$ as the arcs, so the largest is $\frac{4}{10} \times 360^\circ$."),
               (r"$72^\circ$", r"Takes half the largest arc, $\frac{144^\circ}{2}$, as the largest angle."),
               (r"$90^\circ$", r"Computes the angle at P, an end of the longest arc, assuming it is the largest.")],
  check=_c015, values=[126, 144, 72, 90], cognitive="Application")

# ---------------------------------------------------------------- 016
def _c016():
    def pts(xx):
        return [_P(k * xx) for k in range(5)]
    xx = _bisect(lambda u: _ang(pts(u)[0], pts(u)[1], pts(u)[2]) - 140, 5.0, 85.0)
    Pp, Qp, Rp, Sp, Tp = pts(xx)
    return _ang(Tp, Pp, Qp)
q("C16-A-016", T, "Equal chords give equal arcs; recover the arc from one angle", "Difficult",
  "Inverse/parameter",
  r"P, Q, R, S and T are five points, in that order, on a circle such that the chords PQ, QR, RS and ST are all equal. If $\angle PQR = 140^\circ$, what is $\angle TPQ$?",
  "MCQ",
  r"Equal chords cut off equal arcs; let each of arcs PQ, QR, RS, ST be $x$. $\angle PQR$ stands on the arc PR not containing Q, which is $360^\circ - 2x$, so $180^\circ - x = 140^\circ$ and $x = 40^\circ$. $\angle TPQ$ stands on the arc TSRQ $= 3x = 120^\circ$, so $\angle TPQ = 60^\circ$.",
  "Assuming the pentagon is regular, or using the wrong intercepted arc.",
  "C16A-equal-chords-arcs", "Must translate equal chords into equal arcs, recover the arc from one angle, and identify the arc for another vertex.",
  correct=r"$60^\circ$",
  distractors=[(r"$100^\circ$", r"Uses half the remaining arc TP $= 360^\circ - 160^\circ = 200^\circ$ instead of arc TSRQ."),
               (r"$108^\circ$", r"Assumes PQRST is a regular pentagon."),
               (r"$120^\circ$", r"Finds arc TSRQ $= 120^\circ$ correctly but takes the angle equal to the arc, without halving.")],
  check=_c016, values=[60, 100, 108, 120], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 017
def _c017():
    # arcs PQ, QR, RS, ST, TP = a, b, c, dd, e (degrees); each angle of the pentagon is half the
    # arc made of the three sides not meeting that vertex
    a_, b_, c_, d_, e_ = symbols('a_ b_ c_ d_ e_', positive=True)
    z = solve([Eq(a_ + b_ + c_ + d_ + e_, 360), Eq((b_ + c_ + d_) / 2, 100), Eq((d_ + e_ + a_) / 2, 115)],
              [d_, c_, e_], dict=True)[0]
    arcST = simplify(z[d_])
    assert arcST.free_symbols == set()
    # numeric confirmation on two different pentagons with these two angles
    for bb, aa in ((60, 70), (40, 100)):
        cc = 130 - bb; ee = 160 - aa
        arcs = [aa, bb, cc, float(arcST), ee]
        pos = [0]
        for k in arcs[:-1]:
            pos.append(pos[-1] + k)
        Pp, Qp, Rp, Sp, Tp = [_P(u) for u in pos]
        assert abs(_ang(Tp, Pp, Qp) - 100) < 1e-9 and abs(_ang(Qp, Rp, Sp) - 115) < 1e-9
        assert abs(_ang(Sp, (0, 0), Tp) - float(arcST)) < 1e-9
    return arcST
q("C16-A-017", T, "Central angle of a side of a cyclic pentagon from two of its angles", "Difficult",
  "Conceptual/application",
  r"PQRST is a convex pentagon whose five vertices lie on a circle with centre O. If $\angle TPQ = 100^\circ$ and $\angle QRS = 115^\circ$, what is $\angle SOT$?",
  "MCQ",
  r"Let the arcs PQ, QR, RS, ST, TP (each not containing the other vertices) be $a, b, c, d, e$, with total $360^\circ$. The angle at P stands on the arc QRST, so $\angle P = \frac{b + c + d}{2}$; the angle at R stands on the arc STPQ, so $\angle R = \frac{d + e + a}{2}$. Adding, $\angle P + \angle R = \frac{360^\circ + d}{2}$, so $d = 2(215^\circ) - 360^\circ = 70^\circ$. Hence $\angle SOT = 70^\circ$.",
  r"Carrying the cyclic-quadrilateral rule (opposite angles add to $180^\circ$) over to a pentagon, or assuming the pentagon is regular.",
  "C16A-cyclic-pentagon-arcs", "Non-obvious model: each angle must be written as half a three-arc sum, and only the sum of the two given angles is determined; the individual arcs are not.",
  correct=r"$70^\circ$",
  distractors=[(r"$35^\circ$", r"Imitates the cyclic-quadrilateral rule: $100^\circ + 115^\circ - 180^\circ$, which is the inscribed angle on ST, not the central angle."),
               (r"$72^\circ$", r"Assumes the pentagon is regular, so each side subtends $\frac{360^\circ}{5}$ at O."),
               (r"$145^\circ$", r"Assumes $\angle TPQ$, $\angle QRS$ and $\angle SOT$ add up to $360^\circ$, as the angles round a point, giving $360^\circ - 100^\circ - 115^\circ$.")],
  check=_c017, values=[70, 35, 72, 145], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 018
def _c018():
    # arcs PQ, QR, RS, SP = a, b, c, dd (degrees)
    a_, b_, c_, d_ = symbols('a_ b_ c_ d_', positive=True)
    z = solve([Eq(a_ + b_ + c_ + d_, 360), Eq((c_ + d_) / 2, 100), Eq((d_ + a_) / 2, 95), Eq((a_ + c_) / 2, 65)],
              [a_, b_, c_, d_], dict=True)
    assert len(z) == 1
    z = z[0]
    # build the quadrilateral and confirm every given angle, then measure angle PSQ
    pos = [0, z[a_], z[a_] + z[b_], z[a_] + z[b_] + z[c_]]
    Pp, Qp, Rp, Sp = [_P(float(u)) for u in pos]
    Xp = _meet(Pp, Rp, Qp, Sp)
    assert abs(_ang(Pp, Qp, Rp) - 100) < 1e-9 and abs(_ang(Qp, Rp, Sp) - 95) < 1e-9
    assert abs(_ang(Pp, Xp, Qp) - 65) < 1e-9
    return round(_ang(Pp, Sp, Qp), 9)
q("C16-A-018", T, "Inscribed angle recovered from two angles of a cyclic quadrilateral and the angle between its diagonals", "Difficult",
  "Inverse/parameter",
  r"PQRS is a cyclic quadrilateral whose diagonals PR and QS meet at X. If $\angle PQR = 100^\circ$, $\angle QRS = 95^\circ$ and $\angle PXQ = 65^\circ$, what is $\angle PSQ$?",
  "MCQ",
  r"Let the arcs PQ, QR, RS, SP (each not containing the other vertices) be $a, b, c, d$. Then $\angle PQR = \frac{c + d}{2}$ gives $c + d = 200^\circ$, and $\angle QRS = \frac{d + a}{2}$ gives $d + a = 190^\circ$, so $c - a = 10^\circ$. The angle between two chords is half the sum of the arcs they cut off, so $\angle PXQ = \frac{a + c}{2}$ gives $a + c = 130^\circ$. Hence $a = 60^\circ$, and $\angle PSQ$, which stands on arc PQ, is $30^\circ$.",
  "Not halving the arc, or solving for the arc RS instead of the arc PQ.",
  "C16A-angle-chords-inside", "Three angle conditions must be turned into a linear system in the arcs, including the half-sum rule for the diagonals.",
  correct=r"$30^\circ$",
  distractors=[(r"$60^\circ$", r"Solves for arc PQ $= 60^\circ$ and reports the arc instead of the inscribed angle on it."),
               (r"$35^\circ$", r"Gets the sign wrong when subtracting, taking $a - c = 10^\circ$, so arc PQ $= 70^\circ$ and the angle comes out as $35^\circ$."),
               (r"$50^\circ$", r"Reports $\angle QPR$, the inscribed angle on arc QR $= 100^\circ$.")],
  check=_c018, values=[30, 60, 35, 50], cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 019
def _c019():
    sol = solve([Eq(x**2 + y**2, r**2), Eq((x + r)**2 + y**2, 16**2), Eq((x - r)**2 + y**2, 30**2)], [x, y, r], dict=True)
    return [z[r] for z in sol if z[r] > 0][0]
q("C16-A-019", T, "Radius from the two chords joining a point to the ends of a diameter", "Easy",
  "Single-step computation",
  r"PQ is a diameter of a circle and R is a point on the circle such that PR $= 16$ cm and QR $= 30$ cm. What is the radius of the circle?",
  "MCQ",
  r"The angle in a semicircle is a right angle, so $\angle PRQ = 90^\circ$ and $PQ^2 = 16^2 + 30^2 = 256 + 900 = 1156$. So PQ $= 34$ cm and the radius is $17$ cm.",
  "Reporting the diameter instead of the radius.",
  "C16A-angle-in-semicircle", "One fact (right angle in a semicircle) and one Pythagoras step.",
  correct=r"$17$ cm",
  distractors=[(r"$34$ cm", r"Reports the diameter PQ instead of the radius."),
               (r"$23$ cm", r"Averages the two chords, $\frac{16 + 30}{2}$."),
               (r"$15$ cm", r"Takes half of the longer chord QR as the radius.")],
  check=_c019, values=[17, 34, 23, 15], cognitive="Recall")

# ---------------------------------------------------------------- 020
def _c020():
    Pp, Qp = _P(180), _P(0)
    tr = _bisect(lambda u: _ang(_P(u), Pp, Qp) - 34, 1.0, 179.0)
    Rp = _P(tr); Sp = _P(250)
    return _ang(Pp, Sp, Rp)
f = Fig()
P = f.pt("P", *_P(180)); Q = f.pt("Q", *_P(0)); R = f.pt("R", *_P(68)); S = f.pt("S", *_P(250))
f.circle((0, 0), 1); f.seg(P, Q); f.seg(P, R); f.seg(S, P); f.seg(S, R)
f.angle_mark(R, P, Q, "34^\\circ", r=0.32)
_alt = "Circle with diameter PQ. Point R is on the upper arc and point S on the lower arc. Chords PR, SP and SR are drawn, and the angle RPQ is marked 34 degrees."
q("C16-A-020", T, "Angle at a point across a diameter using the right angle in a semicircle", "Medium",
  "Conceptual/application",
  r"PQ is a diameter of a circle. R and S are points on the circle on opposite sides of PQ, and $\angle RPQ = 34^\circ$. What is $\angle PSR$, in degrees?",
  "TITA",
  r"$\angle PRQ = 90^\circ$ (angle in a semicircle), so $\angle PQR = 90^\circ - 34^\circ = 56^\circ$. Chord PR splits the circle into a short arc lying on R's side of PQ and a long arc through Q. S is on the other side of PQ, so S lies on the long arc together with Q, that is, in the same segment of chord PR. Angles in the same segment are equal, so $\angle PSR = \angle PQR = 56^\circ$.",
  "Equating angle PSR with the given angle at P, or using the supplementary segment.",
  "C16A-angle-in-semicircle", "Two linked facts: right angle in a semicircle, then angles in the same segment.",
  tita_answer=56, check=_c020, cognitive="Application",
  tita_traps=[(34, "Takes $\\angle PSR$ equal to the given $\\angle RPQ$."),
              (124, "Uses $180^\\circ - 56^\\circ$, as if S were in the other segment of PR.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 021
def _c021():
    V = [_P(360 * k / 16) for k in range(16)]
    cnt = 0
    for i, j, k in itertools.combinations(range(16), 3):
        A, B, C = V[i], V[j], V[k]
        for U, W, Z in ((A, B, C), (B, C, A), (C, A, B)):
            dot = (W[0] - U[0]) * (Z[0] - U[0]) + (W[1] - U[1]) * (Z[1] - U[1])
            if abs(dot) < 1e-9:
                cnt += 1
                break
    return cnt
q("C16-A-021", T, "Counting right triangles among the vertices of a regular polygon", "Difficult",
  "Casework/optimisation",
  r"Three of the $16$ vertices of a regular $16$-sided polygon are chosen to form a triangle. How many of the triangles so formed are right-angled?",
  "TITA",
  r"All vertices lie on the circumcircle. An inscribed triangle has a right angle exactly when one of its sides is a diameter. The $16$ vertices form $8$ diametrically opposite pairs, and each diameter can be completed by any of the other $14$ vertices. No triangle contains two diameters, so there are $8 \times 14 = 112$ right-angled triangles.",
  "Counting each diameter twice by pairing every vertex with its opposite.",
  "C16A-angle-in-semicircle", "Needs the converse of the angle in a semicircle to turn geometry into a clean count.",
  tita_answer=112, check=_c021, cognitive="Analysis", exams=CX,
  tita_traps=[(224, "Counts $16 \\times 14$, so every diameter is counted twice."),
              (120, "Uses $8 \\times 15$, letting the third vertex be any of the other $15$ vertices.")])

# ---------------------------------------------------------------- 022
def _c022():
    Qp = _P(90)
    u = _bisect(lambda z: _ang((0, 0), _P(90 + z), Qp) - 22, 1.0, 179.0)
    v = _bisect(lambda z: _ang((0, 0), _P(90 - z), Qp) - 38, 1.0, 179.0)
    Pp, Rp = _P(90 + u), _P(90 - v)
    return _ang(Pp, Rp, Qp)
f = Fig()
O = f.pt("O", 0, 0, offset=(0.9, -0.5)); Q = f.pt("Q", *_P(90)); P = f.pt("P", *_P(226)); R = f.pt("R", *_P(-14))
f.circle((0, 0), 1); f.poly(P, Q, R); f.seg(O, P); f.seg(O, Q); f.seg(O, R)
f.angle_mark(O, P, Q, "22^\\circ", r=0.28); f.angle_mark(O, R, Q, "38^\\circ", r=0.28)
_alt = "Triangle PQR inscribed in a circle with centre O inside the triangle. Radii OP, OQ and OR are drawn. Angle OPQ is marked 22 degrees and angle ORQ is marked 38 degrees."
q("C16-A-022", T, "Angle chasing with radii to find an angle of an inscribed triangle", "Medium",
  "Multi-step word problem",
  r"O is the centre of the circle passing through P, Q and R, and O lies inside triangle PQR. If $\angle OPQ = 22^\circ$ and $\angle ORQ = 38^\circ$, what is $\angle PRQ$?",
  "MCQ",
  r"Triangle OPQ is isosceles (OP $=$ OQ), so $\angle POQ = 180^\circ - 2 \times 22^\circ = 136^\circ$. $\angle PRQ$ stands on chord PQ with R on the major arc, so $\angle PRQ = \frac{136^\circ}{2} = 68^\circ$. The value $38^\circ$ is needed only for the other angles of the triangle.",
  "Picking the angle subtended by the wrong chord, or stopping at the central angle.",
  "C16A-centre-angle-chase", "Must pick the right isosceles triangle among three and halve the central angle.",
  correct=r"$68^\circ$",
  distractors=[(r"$136^\circ$", r"Stops at the central angle POQ."),
               (r"$52^\circ$", r"Uses the triangle OQR, finding $\angle QPR = \frac{104^\circ}{2}$, the angle subtended by QR instead of PQ."),
               (r"$60^\circ$", r"Adds $22^\circ + 38^\circ$, which is $\angle PQR$, not $\angle PRQ$.")],
  check=_c022, values=[68, 136, 52, 60], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 023
def _c023():
    Pa, Qa, Ra, Sa = symbols('Pa Qa Ra Sa')
    z = solve([Eq(Pa + Ra, 180), Eq(Qa + Sa, 180), Eq(Pa - Ra, 36), Eq(Qa, 2 * Sa)], [Pa, Qa, Ra, Sa], dict=True)[0]
    return z[Pa] + z[Qa]
q("C16-A-023", T, "Angles of a cyclic quadrilateral from two relations between opposite angles", "Easy",
  "Inverse/parameter",
  r"In a cyclic quadrilateral PQRS, $\angle P$ exceeds $\angle R$ by $36^\circ$, and $\angle Q$ is twice $\angle S$. What is $\angle P + \angle Q$, in degrees?",
  "TITA",
  r"Opposite angles of a cyclic quadrilateral are supplementary. $\angle P + \angle R = 180^\circ$ and $\angle P - \angle R = 36^\circ$ give $\angle P = 108^\circ$. $\angle Q + \angle S = 180^\circ$ and $\angle Q = 2\angle S$ give $\angle S = 60^\circ$ and $\angle Q = 120^\circ$. So $\angle P + \angle Q = 228^\circ$.",
  "Treating adjacent angles of a cyclic quadrilateral as supplementary.",
  "C16A-cyclic-quad-opposite", "Two pairs of opposite angles, each a two-equation system.",
  tita_answer=228, check=_c023, cognitive="Application",
  tita_traps=[(180, "Assumes adjacent angles P and Q are supplementary.")])

# ---------------------------------------------------------------- 024
def _c024():
    def cfg(aa):
        Sp = _P(90); Pp = _P(90 + aa); Rp = _P(90 - aa); Qp = _P(270)
        Tp = (Qp[0] + 0.5 * (Qp[0] - Pp[0]), Qp[1] + 0.5 * (Qp[1] - Pp[1]))
        return Sp, Pp, Rp, Qp, Tp
    def g(aa):
        Sp, Pp, Rp, Qp, Tp = cfg(aa)
        return _ang(Rp, Qp, Tp) - 76
    aa = _bisect(g, 1.0, 179.0)
    Sp, Pp, Rp, Qp, Tp = cfg(aa)
    return _ang(Sp, Rp, Pp)
f = Fig()
S = f.pt("S", *_P(90)); P = f.pt("P", *_P(194)); R = f.pt("R", *_P(346)); Q = f.pt("Q", *_P(300))
_Tq = (_P(300)[0] + 0.55 * (_P(300)[0] - _P(194)[0]), _P(300)[1] + 0.55 * (_P(300)[1] - _P(194)[1]))
Tt = f.pt("T", *_Tq)
f.circle((0, 0), 1); f.poly(P, Q, R, S); f.seg(Q, Tt)
f.angle_mark(R, Q, Tt, "76^\\circ", r=0.22)
_alt = "Cyclic quadrilateral PQRS with S at the top. Side PQ is extended beyond Q to a point T, and the angle RQT is marked 76 degrees."
q("C16-A-024", T, "Exterior angle of a cyclic quadrilateral combined with an isosceles triangle", "Medium",
  "Multi-step word problem",
  r"PQRS is a cyclic quadrilateral in which SP $=$ SR. The side PQ is produced beyond Q to a point T, and $\angle RQT = 76^\circ$. What is $\angle SRP$?",
  "MCQ",
  r"An exterior angle of a cyclic quadrilateral equals the interior opposite angle, so $\angle PSR = \angle RQT = 76^\circ$. In triangle PSR, SP $=$ SR, so $\angle SRP = \angle SPR = \frac{180^\circ - 76^\circ}{2} = 52^\circ$.",
  "Taking the angle at S as the supplement of the exterior angle.",
  "C16A-cyclic-quad-opposite", "Exterior-angle property followed by an isosceles triangle.",
  correct=r"$52^\circ$",
  distractors=[(r"$38^\circ$", r"Takes $\angle PSR = 180^\circ - 76^\circ = 104^\circ$, then halves $180^\circ - 104^\circ$."),
               (r"$76^\circ$", r"Reports $\angle PSR$ itself."),
               (r"$104^\circ$", r"Reports the interior angle PQR.")],
  check=_c024, values=[52, 38, 76, 104], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 025
def _c025():
    import sympy as _sp
    Pp, Rp = _sp.Point(-Rational(65, 2), 0), _sp.Point(Rational(65, 2), 0)
    big = _sp.Circle(_sp.Point(0, 0), Rational(65, 2))
    Qs = [z for z in big.intersection(_sp.Circle(Pp, 25)) if z.y > 0][0]
    Ss = [z for z in big.intersection(_sp.Circle(Pp, 39)) if z.y < 0][0]
    return _sp.sqrt((Qs.x - Ss.x)**2 + (Qs.y - Ss.y)**2)
_A = math.atan2(12, 5); _B = math.atan2(4, 3)
_Pq = (-32.5, 0.0); _Rq = (32.5, 0.0)
_Qq = (-32.5 + 25 * math.cos(_A), 25 * math.sin(_A)); _Sq = (-32.5 + 39 * math.cos(_B), -39 * math.sin(_B))
f = Fig()
P = f.pt("P", *_Pq); Q = f.pt("Q", *_Qq); R = f.pt("R", *_Rq); S = f.pt("S", *_Sq)
f.circle((0, 0), 32.5); f.poly(P, Q, R, S); f.seg(P, R)
f.label_seg(P, Q, "25 cm"); f.text((-15.5, -12.5), "39 cm"); f.text((8, 2.5), "65 cm")
_alt = "Cyclic quadrilateral PQRS with diagonal PR of length 65 cm drawn as a diameter of the circle. Q lies above PR with PQ = 25 cm and S lies below PR with PS = 39 cm."
q("C16-A-025", T, "Second diagonal of a cyclic quadrilateral whose first diagonal is a diameter", "Difficult",
  "Multi-step word problem",
  r"PQRS is a cyclic quadrilateral whose diagonal PR is a diameter of the circle, with PR $= 65$ cm. If PQ $= 25$ cm and PS $= 39$ cm, what is the length of the diagonal QS?",
  "MCQ",
  r"Angles PQR and PSR are right angles, so QR $= \sqrt{65^2 - 25^2} = 60$ and RS $= \sqrt{65^2 - 39^2} = 52$. By Ptolemy's theorem, $QS \cdot PR = PQ \cdot RS + QR \cdot PS$, so $65 \cdot QS = 25 \times 52 + 60 \times 39 = 1300 + 2340 = 3640$, giving QS $= 56$ cm.",
  "Pairing the sides wrongly in Ptolemy's theorem, or placing Q and S on the same side of PR.",
  "C16A-cyclic-quad-ptolemy", "Two right angles from the diameter, then Ptolemy (or a compound-angle step); several traps.",
  correct=r"$56$ cm",
  distractors=[(r"$63$ cm", r"Pairs adjacent sides in Ptolemy: $\frac{25 \times 39 + 60 \times 52}{65} = 63$."),
               (r"$16$ cm", r"Places Q and S on the same side of PR, giving $\frac{60 \times 39 - 25 \times 52}{65} = 16$."),
               (r"$65$ cm", r"Assumes QS is also a diameter.")],
  check=_c025, values=[56, 63, 16, 65], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 026
def _c026():
    Pp = (0.0, -1.0); Tp = (2.0, -1.0)
    tq = _bisect(lambda u: _ang(Tp, Pp, _P(u)) - 58, -89.0, 89.0)
    Qp = _P(tq)
    # major arc PQ: midpoint of the arc from Q counter-clockwise to P (270 degrees)
    Rp = _P((tq + 270) / 2)
    assert _dist(Pp, Qp) > 0
    return _ang(Pp, Rp, Qp)
f = Fig()
P = f.pt("P", 0, -1); Q = f.pt("Q", *_P(26)); R = f.pt("R", *_P(148)); Tt = f.pt("T", 1.4, -1)
f.circle((0, 0), 1); f.seg((-1.3, -1), Tt); f.seg(P, Q); f.seg(R, P); f.seg(R, Q)
f.angle_mark(Tt, P, Q, "58^\\circ", r=0.3)
_alt = "Circle with a tangent line touching it at P, with point T on the tangent. Chord PQ makes an angle of 58 degrees with PT. Point R on the major arc is joined to P and Q."
q("C16-A-026", T, "Tangent-chord angle equals the angle in the alternate segment", "Easy",
  "Conceptual/application",
  r"PT is a tangent to a circle at P, and PQ is a chord of the circle such that $\angle QPT = 58^\circ$. R is a point on the major arc PQ. What is $\angle PRQ$?",
  "MCQ",
  r"The angle between a tangent and a chord through the point of contact equals the angle in the alternate segment. The minor arc PQ lies inside $\angle QPT$, so the alternate segment is the major arc, where R lies. Hence $\angle PRQ = 58^\circ$.",
  "Using the supplement (the angle in the other segment) or the complement of the tangent-chord angle.",
  "C16A-alternate-segment", "Direct use of the alternate segment theorem; the trap is the segment containing R.",
  correct=r"$58^\circ$",
  distractors=[(r"$122^\circ$", r"Gives $180^\circ - 58^\circ$, the angle for a point on the minor arc."),
               (r"$32^\circ$", r"Gives $90^\circ - 58^\circ$, the angle between the chord and the radius OP."),
               (r"$116^\circ$", r"Gives the central angle $2 \times 58^\circ$.")],
  check=_c026, values=[58, 122, 32, 116], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 027
def _c027():
    Tp = (0.0, -1.0); Xp = (-2.0, -1.0)
    phi = _bisect(lambda u: _ang(Xp, Tp, _P(u)) - 50, 91.0, 269.0)
    Pp = _P(phi); Qp = (-Pp[0], Pp[1])
    return _ang(Pp, Tp, Qp)
q("C16-A-027", T, "Chord parallel to a tangent with the alternate segment theorem", "Medium",
  "Multi-step word problem",
  r"A line XY touches a circle at T. PQ is a chord of the circle parallel to XY, with P nearer to X than Q is. If $\angle XTP = 50^\circ$, what is $\angle PTQ$, in degrees?",
  "TITA",
  r"By the alternate segment theorem, $\angle TQP = \angle XTP = 50^\circ$. Since PQ is parallel to XY, the alternate angles give $\angle TPQ = \angle XTP = 50^\circ$. So in triangle TPQ, $\angle PTQ = 180^\circ - 50^\circ - 50^\circ = 80^\circ$.",
  "Using only one of the two angle facts and assuming the triangle is equilateral or right-angled.",
  "C16A-alternate-segment", "Combines the alternate segment theorem with parallel-line angles in one triangle.",
  tita_answer=80, check=_c027, cognitive="Application",
  tita_traps=[(50, "Reports $\\angle TQP$ or $\\angle TPQ$ instead of $\\angle PTQ$."),
              (100, "Doubles $50^\\circ$, treating $\\angle PTQ$ as a central angle.")])

# ---------------------------------------------------------------- 028
def _c028():
    def cfg(aa):
        Rp = _P(90); Pp = _P(90 + aa); Qp = _P(90 - aa)
        tdir = (-Pp[1], Pp[0])
        Tp = _meet(Pp, (Pp[0] + tdir[0], Pp[1] + tdir[1]), Rp, Qp)
        return Rp, Pp, Qp, Tp
    def g(aa):
        Rp, Pp, Qp, Tp = cfg(aa)
        return _ang(Pp, Tp, Qp) - 30
    aa = _bisect(g, 100.0, 175.0)
    Rp, Pp, Qp, Tp = cfg(aa)
    # T must lie on RQ produced beyond Q
    assert _dist(Rp, Tp) > _dist(Rp, Qp) and abs(_dist(Rp, Tp) - _dist(Rp, Qp) - _dist(Qp, Tp)) < 1e-9
    return _ang(Qp, Pp, Rp)
def _cfg028(aa):
    Rp = _P(90); Pp = _P(90 + aa); Qp = _P(90 - aa)
    tdir = (-Pp[1], Pp[0])
    return Rp, Pp, Qp, _meet(Pp, (Pp[0] + tdir[0], Pp[1] + tdir[1]), Rp, Qp)
_R8, _P8, _Q8, _T8 = _cfg028(140.0)
f = Fig()
R = f.pt("R", *_R8); P = f.pt("P", *_P8); Q = f.pt("Q", *_Q8); Tt = f.pt("T", *_T8)
f.circle((0, 0), 1); f.poly(P, Q, R); f.seg(Q, Tt); f.seg(P, Tt)
f.angle_mark(P, Tt, Q, "30^\\circ", r=0.4)
_alt = "Triangle PQR inscribed in a circle, with R at the top. The tangent at P meets the line RQ, extended beyond Q, at T. The angle PTQ is marked 30 degrees."
q("C16-A-028", T, "Tangent meeting a produced side, with an isosceles inscribed triangle", "Difficult",
  "Inverse/parameter",
  r"PQR is a triangle inscribed in a circle, with RP $=$ RQ. The tangent to the circle at P meets RQ produced beyond Q at T. If $\angle PTQ = 30^\circ$, what is $\angle QPR$?",
  "MCQ",
  r"Let $\angle PRQ = x$. By the alternate segment theorem, $\angle TPQ = x$. In triangle TPQ, the exterior angle at Q is $\angle PQR = 30^\circ + x$. Since RP $=$ RQ, $\angle QPR = \angle PQR = 30^\circ + x$. The angle sum of triangle PQR gives $x + 2(30^\circ + x) = 180^\circ$, so $x = 40^\circ$ and $\angle QPR = 70^\circ$.",
  "Stopping at the alternate segment angle, or confusing the exterior and interior angles at Q.",
  "C16A-alternate-segment", "Requires setting up an unknown and combining three angle facts.",
  correct=r"$70^\circ$",
  distractors=[(r"$40^\circ$", r"Reports $x = \angle PRQ = \angle TPQ$ instead of $\angle QPR$."),
               (r"$80^\circ$", r"Reports $2x$, the angle subtended by PQ at the centre."),
               (r"$110^\circ$", r"Reports $\angle PQT = 180^\circ - 70^\circ$, the angle at Q in triangle TPQ.")],
  check=_c028, values=[70, 40, 80, 110], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 029
def _c029():
    res = []
    for xq in (60.0, 90.0, 140.0):
        Pp, Qp = _P(0), _P(100)
        Rp, Sp = _P(100 + xq), _P(160 + xq)
        Xp = _meet(Pp, Rp, Qp, Sp)
        res.append(_ang(Pp, Xp, Qp))
    assert max(res) - min(res) < 1e-9
    return res[0]
f = Fig()
P = f.pt("P", *_P(0)); Q = f.pt("Q", *_P(100)); R = f.pt("R", *_P(190)); S = f.pt("S", *_P(250))
_X9 = _meet(_P(0), _P(190), _P(100), _P(250)); Xx = f.pt("X", *_X9, offset=(0.2, 1))
f.circle((0, 0), 1); f.seg(P, R); f.seg(Q, S)
f.text(_P(50, 1.18), "100^\\circ"); f.text(_P(220, 1.2), "60^\\circ")
_alt = "Circle with chords PR and QS intersecting at X inside it. The arc PQ not containing R and S is marked 100 degrees and the arc RS not containing P and Q is marked 60 degrees."
q("C16-A-029", T, "Angle between two chords from the intercepted arcs", "Medium",
  "Conceptual/application",
  r"Chords PR and QS of a circle intersect at a point X inside the circle. The arc PQ that does not contain R and S measures $100^\circ$, and the arc RS that does not contain P and Q measures $60^\circ$. What is $\angle PXQ$?",
  "MCQ",
  r"Join QR. $\angle PXQ$ is an exterior angle of triangle XQR, so $\angle PXQ = \angle XRQ + \angle XQR = \angle PRQ + \angle SQR = \frac{100^\circ}{2} + \frac{60^\circ}{2} = 80^\circ$. This is the rule: the angle between two chords equals half the sum of the intercepted arcs.",
  "Using half the difference of the arcs, or forgetting to halve.",
  "C16A-angle-chords-inside", "Uses the half-sum rule (or an exterior angle with two inscribed angles).",
  correct=r"$80^\circ$",
  distractors=[(r"$160^\circ$", r"Adds the arcs without halving."),
               (r"$20^\circ$", r"Uses half the difference, the rule for lines meeting outside the circle."),
               (r"$100^\circ$", r"Gives the adjacent angle PXS $= 180^\circ - 80^\circ$.")],
  check=_c029, values=[80, 160, 20, 100], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 030
def _c030():
    w = [5, 2, 4, 7]
    pos = [0]
    for k in w[:-1]:
        pos.append(pos[-1] + 360 * k / sum(w))
    Pp, Qp, Rp, Sp = [_P(z) for z in pos]
    Yp = _meet(Pp, Qp, Rp, Sp)
    return _ang(Pp, Yp, Sp)
q("C16-A-030", T, "Angle between two produced sides of a cyclic quadrilateral from arc ratios", "Medium",
  "Multi-step word problem",
  r"Four points P, Q, R and S lie in that order on a circle and divide it into arcs PQ, QR, RS and SP whose lengths are in the ratio $5 : 2 : 4 : 7$. The lines PQ and SR, when produced, meet at a point Y outside the circle. What is the angle between these two lines at Y?",
  "MCQ",
  r"The arcs are $100^\circ, 40^\circ, 80^\circ$ and $140^\circ$. Lines PQ and SR meet beyond Q and R, and the arcs they cut off between them are QR $= 40^\circ$ (near Y) and SP $= 140^\circ$ (far from Y). For two secants meeting outside a circle the angle is half the difference of these arcs: $\frac{140^\circ - 40^\circ}{2} = 50^\circ$.",
  "Using half the sum (the rule for chords meeting inside), or picking arcs PQ and RS which lie on the lines themselves.",
  "C16A-angle-secants-outside", "Two steps: convert a ratio to arcs, then one application of the half-difference rule to the correct pair of arcs.",
  correct=r"$50^\circ$",
  distractors=[(r"$90^\circ$", r"Uses half the sum $\frac{140^\circ + 40^\circ}{2}$, the rule for chords meeting inside."),
               (r"$100^\circ$", r"Takes the full difference $140^\circ - 40^\circ$ without halving."),
               (r"$70^\circ$", r"Uses only the far arc SP, taking $\frac{140^\circ}{2}$ as an inscribed angle.")],
  check=_c030, values=[50, 90, 100, 70], cognitive="Application")

# ---------------------------------------------------------------- 031
def _c031():
    def cfg(sv):
        Pp, Rp = _P(90 - 17), _P(90 + 17)
        Qp, Sp = _P(270 + sv / 2), _P(270 - sv / 2)
        Yp = _meet(Pp, Qp, Rp, Sp)
        return Pp, Qp, Rp, Sp, Yp
    def g(sv):
        Pp, Qp, Rp, Sp, Yp = cfg(sv)
        return _ang(Qp, Yp, Sp) - 28
    sv = _bisect(g, 40.0, 300.0)
    return sv
_c = (lambda sv: (_P(73), _P(270 + sv / 2), _P(107), _P(270 - sv / 2)))(90.0)
_Y1 = _meet(_c[0], _c[1], _c[2], _c[3])
f = Fig()
P = f.pt("P", *_c[0], offset=(1, 0.3)); Q = f.pt("Q", *_c[1]); R = f.pt("R", *_c[2], offset=(-1, 0.3)); S = f.pt("S", *_c[3]); Yy = f.pt("Y", *_Y1)
f.circle((0, 0), 1); f.seg(Yy, Q); f.seg(Yy, S)
f.angle_mark(Q, Yy, S, "28^\\circ", r=0.35); f.text(_P(90, 0.82), "34^\\circ")
_alt = "Two secants from an outside point Y: one passes through P then Q, the other through R then S. The angle at Y is marked 28 degrees, and the arc PR between the secants nearer to Y is marked 34 degrees."
q("C16-A-031", T, "Far arc between two secants from the external angle and the near arc", "Medium",
  "Inverse/parameter",
  r"From a point Y outside a circle, two secants are drawn: one meets the circle at P and then Q, and the other meets it at R and then S. The angle between the secants at Y is $28^\circ$, and the arc PR lying between the secants nearer to Y measures $34^\circ$. What is the measure of the arc QS lying between the secants farther from Y?",
  "MCQ",
  r"For two secants from an external point, the angle equals half the difference of the intercepted arcs: $28^\circ = \frac{QS - 34^\circ}{2}$. So arc QS $= 56^\circ + 34^\circ = 90^\circ$.",
  "Forgetting the factor of one half, or subtracting the near arc instead of adding it.",
  "C16A-angle-secants-outside", "Reverse use of the external-angle rule.",
  correct=r"$90^\circ$",
  distractors=[(r"$62^\circ$", r"Uses angle $=$ arc QS $-$ arc PR, without the factor $\frac{1}{2}$."),
               (r"$22^\circ$", r"Subtracts the near arc: $2 \times 28^\circ - 34^\circ$."),
               (r"$56^\circ$", r"Doubles the angle and ignores the near arc.")],
  check=_c031, values=[90, 62, 22, 56], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 032
def _c032():
    Tp, _ = _tangent_pts((29.0, 0.0), 20.0)
    return round(_dist(Tp, (29.0, 0.0)), 9)
q("C16-A-032", T, "Tangent length from an external point", "Easy",
  "Single-step computation",
  r"Kabir stands at a point $29$ m from the centre of a circular pond of radius $20$ m. He walks in a straight line along a tangent to the edge of the pond until he reaches the point where his path touches the edge. How far, in metres, does he walk?",
  "TITA",
  r"The radius to the point of contact is perpendicular to the tangent, so the tangent length is $\sqrt{29^2 - 20^2} = \sqrt{841 - 400} = \sqrt{441} = 21$ m.",
  "Using the straight-line gap to the pond instead of the tangent length.",
  "C16A-tangent-length-pythagoras", "One right triangle with the radius perpendicular to the tangent.",
  tita_answer=21, check=_c032, cognitive="Recall",
  tita_traps=[(9, "Computes $29 - 20$, the shortest distance to the edge."),
              (49, "Adds $29 + 20$.")])

# ---------------------------------------------------------------- 033
def _c033():
    Pp, Qp = _tangent_pts((25.0, 0.0), 15.0)
    return round(_dist(Pp, Qp), 9)
f = Fig()
O = f.pt("O", 0, 0); Xx = f.pt("X", 25, 0); P = f.pt("P", 9, 12); Q = f.pt("Q", 9, -12)
f.circle((0, 0), 15); f.seg(Xx, P); f.seg(Xx, Q); f.seg(O, P); f.seg(O, Xx, dashed=True)
f.right_angle(O, P, Xx); f.label_seg(O, P, "15 cm"); f.text((17, -1.6), "25 cm")
_alt = "Circle with centre O and radius OP = 15 cm. From a point X with OX = 25 cm, tangents XP and XQ touch the circle at P and Q."
q("C16-A-033", T, "Length of the chord joining the points of contact of two tangents", "Medium",
  "Multi-step word problem",
  r"From a point X at a distance of $25$ cm from the centre O of a circle of radius $15$ cm, two tangents XP and XQ are drawn to the circle. What is the length of the chord PQ?",
  "MCQ",
  r"Tangent length XP $= \sqrt{25^2 - 15^2} = 20$ cm. OX is the perpendicular bisector of PQ, and the half-chord is the altitude from P in the right triangle OPX: $\frac{OP \cdot XP}{OX} = \frac{15 \times 20}{25} = 12$ cm. So PQ $= 24$ cm.",
  "Stopping at the half-chord or at the tangent length.",
  "C16A-tangents-chord-of-contact", "Tangent length, then the altitude of the right triangle to the hypotenuse.",
  correct=r"$24$ cm",
  distractors=[(r"$12$ cm", r"Stops at the half-chord, the altitude of triangle OPX."),
               (r"$20$ cm", r"Gives the tangent length XP."),
               (r"$30$ cm", r"Assumes PQ is a diameter.")],
  check=_c033, values=[24, 12, 20, 30], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 034
def _c034():
    dd = [v for v in solve(Eq(36**2 + d**2, 45**2), d) if v > 0][0]
    Py = -dd
    # tangent at P = (-36, Py) to x^2 + y^2 = 45^2 is -36 X + Py Y = 2025; it meets the axis X = 0 at Y = 2025 / Py
    Xp = (0, Rational(2025) / Py)
    return sqrt((Xp[0] + 36)**2 + (Xp[1] - Py)**2)
q("C16-A-034", T, "Tangent length when the tangents at the ends of a chord meet", "Difficult",
  "Multi-step word problem",
  r"A chord PQ of length $72$ cm is drawn in a circle of radius $45$ cm. The tangents to the circle at P and Q meet at X. What is the length XP, in cm?",
  "TITA",
  r"Let O be the centre and M the midpoint of PQ. Then PM $= 36$ and OM $= \sqrt{45^2 - 36^2} = 27$. Triangles OMP and OPX are similar (both right-angled, sharing the angle at O), so $\frac{XP}{OP} = \frac{PM}{OM}$, giving XP $= \frac{45 \times 36}{27} = 60$ cm. (Check: OX $= \frac{45^2}{27} = 75$ and $45^2 + 60^2 = 75^2$.)",
  "Reporting OX, or the half-chord, instead of the tangent length.",
  "C16A-tangents-chord-of-contact", "Needs similar right triangles about the centre; not a direct Pythagoras step.",
  tita_answer=60, check=_c034, cognitive="Analysis", exams=CX,
  tita_traps=[(75, "Reports OX, the distance from the centre to X."),
              (36, "Reports the half-chord PM.")])

# ---------------------------------------------------------------- 035
def _c035():
    dd = _bisect(lambda u: _ang(*(lambda pq: (pq[0], (u, 0.0), pq[1]))(_tangent_pts((u, 0.0)))) - 64, 1.01, 50.0)
    Pp, Qp = _tangent_pts((dd, 0.0))
    return _ang(Pp, (0.0, 0.0), Qp)
q("C16-A-035", T, "Central angle between the radii to the points of contact of two tangents", "Easy",
  "Conceptual/application",
  r"From a point X outside a circle with centre O, tangents XP and XQ are drawn to the circle. If $\angle PXQ = 64^\circ$, what is $\angle POQ$?",
  "MCQ",
  r"In quadrilateral OPXQ, the angles at P and Q are $90^\circ$ each (radius perpendicular to tangent). So $\angle POQ = 360^\circ - 90^\circ - 90^\circ - 64^\circ = 116^\circ$.",
  "Treating the central angle as twice the angle at X, or using the base angle of triangle XPQ.",
  "C16A-two-tangents-angle", "One quadrilateral angle sum with two right angles.",
  correct=r"$116^\circ$",
  distractors=[(r"$64^\circ$", r"Takes $\angle POQ$ equal to $\angle PXQ$."),
               (r"$128^\circ$", r"Doubles $\angle PXQ$ as if X were on the circle."),
               (r"$58^\circ$", r"Gives the base angle XPQ $= \frac{180^\circ - 64^\circ}{2}$.")],
  check=_c035, values=[116, 64, 128, 58], cognitive="Understanding")

# ---------------------------------------------------------------- 036
def _c036():
    dd = _bisect(lambda u: _ang(*(lambda pq: (pq[0], (u, 0.0), pq[1]))(_tangent_pts((u, 0.0)))) - 50, 1.01, 50.0)
    Pp, Qp = _tangent_pts((dd, 0.0))
    Sp = (1.0, 0.0)  # a point of the minor arc PQ (the arc facing X)
    return _ang(Pp, Sp, Qp)
_d6 = 1 / math.sin(math.radians(25))
_P6, _Q6 = _tangent_pts((_d6, 0.0))
f = Fig()
P = f.pt("P", *_P6); Q = f.pt("Q", *_Q6); Xx = f.pt("X", _d6, 0); S = f.pt("S", *_P(8), offset=(-1, 0.2))
f.circle((0, 0), 1); f.seg(Xx, P); f.seg(Xx, Q); f.seg(S, P); f.seg(S, Q)
f.angle_mark(P, Xx, Q, "50^\\circ", r=0.45)
_alt = "Tangents XP and XQ drawn from an outside point X to a circle, with angle PXQ marked 50 degrees. Point S lies on the minor arc PQ, the arc facing X, and is joined to P and Q."
q("C16-A-036", T, "Angle at a point of the minor arc between the points of contact of two tangents", "Medium",
  "Conceptual/application",
  r"From a point X outside a circle, tangents XP and XQ are drawn, and $\angle PXQ = 50^\circ$. S is a point on the minor arc PQ (the arc facing X). What is $\angle PSQ$?",
  "MCQ",
  r"With centre O, $\angle POQ = 180^\circ - 50^\circ = 130^\circ$, which is the measure of the minor arc PQ. A point on the major arc would see PQ at $65^\circ$; S is on the minor arc, so $\angle PSQ = 180^\circ - 65^\circ = 115^\circ$. (Alternatively, $\angle PSQ = 90^\circ + \frac{50^\circ}{2}$.)",
  "Using the angle for a point on the major arc instead of the minor arc.",
  "C16A-two-tangents-angle", "Two steps (central angle, then the angle in the minor segment) with a strong segment trap.",
  correct=r"$115^\circ$",
  distractors=[(r"$65^\circ$", r"Gives the angle at a point on the major arc."),
               (r"$130^\circ$", r"Gives the central angle POQ."),
               (r"$25^\circ$", r"Halves $\angle PXQ$.")],
  check=_c036, values=[115, 65, 130, 25], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 037
def _c037():
    Xp = (41.0, 0.0)
    Pp, Qp = _tangent_pts(Xp, 9.0)
    lim = math.degrees(math.acos(9 / 41))
    res = []
    for deg in (-0.6 * lim, 0.0, 0.3 * lim, 0.8 * lim):
        Rp = _P(deg, 9.0)
        tdir = (-Rp[1], Rp[0])
        R2 = (Rp[0] + tdir[0], Rp[1] + tdir[1])
        Mp = _meet(Rp, R2, Xp, Pp); Np = _meet(Rp, R2, Xp, Qp)
        res.append(_dist(Xp, Mp) + _dist(Mp, Np) + _dist(Np, Xp))
    assert max(res) - min(res) < 1e-9
    return round(res[0], 9)
_lim7 = math.degrees(math.acos(9 / 41))
_P7, _Q7 = _tangent_pts((41.0, 0.0), 9.0)
_R7 = _P(0, 9.0); _R7b = (_R7[0] - _R7[1], _R7[1] + _R7[0])
_M7 = _meet(_R7, _R7b, (41.0, 0.0), _P7); _N7 = _meet(_R7, _R7b, (41.0, 0.0), _Q7)
f = Fig()
O = f.pt("O", 0, 0); Xx = f.pt("X", 41, 0); P = f.pt("P", *_P7); Q = f.pt("Q", *_Q7)
R = f.pt("R", *_R7, offset=(-1, 0.6)); M = f.pt("M", *_M7); N = f.pt("N", *_N7)
f.circle((0, 0), 9); f.seg(Xx, P); f.seg(Xx, Q); f.seg(M, N); f.seg(O, Xx, dashed=True)
f.text((26, -2.4), "41 cm"); f.seg(O, P); f.label_seg(O, P, "9 cm")
_alt = "Circle with centre O and radius OP = 9 cm. From X, with OX = 41 cm, tangents XP and XQ are drawn. The tangent at R on the minor arc PQ cuts XP at M and XQ at N, forming triangle XMN."
q("C16-A-037", T, "Perimeter of the triangle cut off by a third tangent", "Medium",
  "Conceptual/application",
  r"From a point X outside a circle with centre O and radius $9$ cm, where OX $= 41$ cm, tangents XP and XQ are drawn. The tangent at a point R of the minor arc PQ cuts XP at M and XQ at N. What is the perimeter of triangle XMN, in cm?",
  "TITA",
  r"Tangents from an external point are equal, so MR $=$ MP and NR $=$ NQ. Hence the perimeter is $XM + MR + RN + NX = XM + MP + QN + NX = XP + XQ = 2 XP$. Now XP $= \sqrt{41^2 - 9^2} = \sqrt{1600} = 40$, so the perimeter is $80$ cm, whatever the position of R.",
  "Not seeing that MN splits into two tangent segments that complete XP and XQ.",
  "C16A-tangent-triangle-perimeter", "The key step is an insight (equal tangents), after which one Pythagoras step finishes.",
  tita_answer=80, check=_c037, cognitive="Analysis",
  tita_traps=[(40, "Gives one tangent length XP."),
              (82, "Takes the perimeter as $2 \\times OX$.")],
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 038
def _c038():
    p, qv, rv, sv = symbols('p qv rv sv', positive=True)
    z = solve([Eq(p + qv, 13), Eq(qv + rv, 17), Eq(rv + sv, 22)], [p, rv, sv], dict=True)[0]
    return simplify(z[sv] + z[p])
q("C16-A-038", T, "Fourth side of a quadrilateral whose sides all touch a circle", "Easy",
  "Single-step computation",
  r"All four sides of a quadrilateral PQRS touch a circle. If PQ $= 13$ cm, QR $= 17$ cm and RS $= 22$ cm, what is the length of SP, in cm?",
  "TITA",
  r"Tangents from each vertex are equal, and each side is the sum of the tangent lengths from its two ends. So the sums of opposite sides are equal: PQ $+$ RS $=$ QR $+$ SP, giving SP $= 13 + 22 - 17 = 18$ cm.",
  "Pairing adjacent sides instead of opposite sides.",
  "C16A-tangential-quad-pitot", "Direct use of equal opposite-side sums.",
  tita_answer=18, check=_c038, cognitive="Recall",
  tita_traps=[(26, "Uses QR $+$ RS $-$ PQ, pairing the wrong sides."),
              (8, "Uses PQ $+$ QR $-$ RS, pairing the wrong sides.")])

# ---------------------------------------------------------------- 039
def _c039():
    av = symbols('av', positive=True)
    # P(0,0), Q(18,0), S(0,12), R(av,12); circle centre (6,6), radius 6 must touch QR
    dist_expr = Abs(12 * 6 - (av - 18) * 6 - 12 * 18) / sqrt(12**2 + (av - 18)**2)
    sols = [v for v in solve(Eq((12 * 6 - (av - 18) * 6 - 12 * 18)**2, 36 * (12**2 + (av - 18)**2)), av) if 0 < v < 18]
    assert len(sols) == 1 and simplify(dist_expr.subs(av, sols[0]) - 6) == 0
    av0 = sols[0]
    return Rational(1, 2) * (18 + av0) * 12
f = Fig()
P = f.pt("P", 0, 0); Q = f.pt("Q", 18, 0); R = f.pt("R", 9, 12); S = f.pt("S", 0, 12)
f.poly(P, Q, R, S); f.circle((6, 6), 6); f.right_angle(Q, P, S); f.right_angle(P, S, R)
f.label_seg(P, Q, "18 cm")
_alt = "Right trapezium PQRS with PQ parallel to SR and PS perpendicular to both. PQ = 18 cm is the longer parallel side. A circle touches all four sides."
q("C16-A-039", T, "Area of a right trapezium circumscribing a circle", "Difficult",
  "Inverse/parameter",
  r"PQRS is a trapezium with PQ parallel to SR, and the side PS is perpendicular to both PQ and SR. A circle of radius $6$ cm touches all four sides of the trapezium. If the longer parallel side PQ is $18$ cm, what is the area of the trapezium?",
  "MCQ",
  r"PS is perpendicular to both parallel sides and both touch the circle, so PS $= 12$ cm, the diameter. Let SR $= a$. Equal tangents give PQ $+$ SR $=$ PS $+$ QR, so QR $= a + 6$. Also QR is the hypotenuse of a right triangle with legs $12$ and $18 - a$: $(a + 6)^2 = 144 + (18 - a)^2$, giving $48a = 432$ and $a = 9$. The area is $\frac{(18 + 9)}{2} \times 12 = 162$ cm$^2$.",
  r"Using the radius as the height, or assuming the slant side is at $45^\circ$.",
  "C16A-tangential-quad-pitot", "Combines the equal-sums property with Pythagoras to fix the unknown side, then the area.",
  correct=r"$162$ cm$^2$",
  distractors=[(r"$216$ cm$^2$", r"Treats the trapezium as an $18 \times 12$ rectangle."),
               (r"$81$ cm$^2$", r"Uses the radius $6$ as the height: $\frac{27}{2} \times 6$."),
               (r"$144$ cm$^2$", r"Assumes the slant side makes $45^\circ$, so SR $= 18 - 12 = 6$ and the area is $\frac{24}{2} \times 12$.")],
  check=_c039, values=[162, 216, 81, 144], cognitive="Analysis", exams=CX,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))

# ---------------------------------------------------------------- 040
def _c040():
    Qp, Rp = (0.0, 0.0), (14.0, 0.0)
    px = (10**2 - 12**2 + 14**2) / (2 * 14.0); py = math.sqrt(10**2 - px**2)
    Pp = (px, py)
    la, lb, lc = 14.0, 12.0, 10.0  # opposite P, Q, R
    Ix = (la * Pp[0] + lb * Qp[0] + lc * Rp[0]) / (la + lb + lc)
    return Ix / (14.0 - Ix)
q("C16-A-040", T, "Ratio in which the incircle's point of contact divides a side", "Medium",
  "Multi-step word problem",
  r"The incircle of triangle PQR touches the side QR at T. If PQ $= 10$ cm, QR $= 14$ cm and RP $= 12$ cm, what is QT $:$ TR?",
  "MCQ",
  r"Let the tangent lengths from P, Q, R be $p, q, r$. Then $p + q = 10$, $q + r = 14$ and $r + p = 12$, so $p + q + r = 18$ (the semi-perimeter). Hence QT $= q = 18 - 12 = 6$ and TR $= r = 18 - 10 = 8$, and QT $:$ TR $= 3 : 4$.",
  "Confusing the incircle's point of contact with the foot of the angle bisector.",
  "C16A-incircle-tangent-segments", "Three tangent-length equations solved via the semi-perimeter.",
  correct=r"$3 : 4$",
  distractors=[(r"$5 : 6$", r"Uses PQ $:$ PR, which is where the bisector of angle P meets QR, not the point of contact."),
               (r"$4 : 3$", r"Swaps the two tangent lengths."),
               (r"$1 : 1$", r"Assumes the incircle touches QR at its midpoint.")],
  check=_c040, values=[Rational(3, 4), Rational(5, 6), Rational(4, 3), 1], cognitive="Application")

# ---------------------------------------------------------------- 041
def _c041():
    # tangent length from P is u; then PQ = u + 3, PR = u + 10, QR = 13, and angle QPR = 60 degrees
    u = symbols('u', positive=True)
    sols = solve(Eq(13**2, (u + 3)**2 + (u + 10)**2 - 2 * (u + 3) * (u + 10) * cos(pi / 3)), u)
    assert len(sols) == 1
    u0 = sols[0]
    # independent confirmation: the incircle of the triangle with these sides touches QR 3 from Q
    pq, pr, qr = u0 + 3, u0 + 10, 13
    s_ = (pq + pr + qr) / 2
    assert simplify(s_ - pr - 3) == 0
    area = simplify(Rational(1, 2) * pq * pr * sin(pi / 3))
    assert simplify(area - sqrt(s_ * (s_ - pq) * (s_ - pr) * (s_ - qr))) == 0
    return area
q("C16-A-041", T, "Area of a triangle from the two segments into which its incircle divides a side, with the opposite angle known", "Difficult",
  "Multi-step word problem",
  r"The circle inscribed in triangle PQR touches the side QR at T. If QT $= 3$ cm, TR $= 10$ cm and $\angle QPR = 60^\circ$, what is the area of triangle PQR?",
  "MCQ",
  r"Tangents from a vertex are equal, so if the tangent length from P is $u$, then PQ $= u + 3$, PR $= u + 10$ and QR $= 13$. The cosine rule with $\cos 60^\circ = \frac{1}{2}$ gives $169 = (u + 3)^2 + (u + 10)^2 - (u + 3)(u + 10)$, which simplifies to $u^2 + 13u - 90 = 0$, so $u = 5$. The sides about the $60^\circ$ angle are $8$ cm and $15$ cm, and the area is $\frac{1}{2} \times 8 \times 15 \times \frac{\sqrt{3}}{2} = 30\sqrt{3}$ cm$^2$.",
  r"Taking the contact segments QT and TR as the sides that enclose the $60^\circ$ angle, or dropping the factor $\frac{1}{2}$ in the area formula.",
  "C16A-incircle-tangent-segments", "Needs an unknown tangent length from P, the cosine rule to fix it, and then the area; a non-obvious model with several steps.",
  correct=r"$30\sqrt{3}$ cm$^2$",
  distractors=[(r"$60\sqrt{3}$ cm$^2$", r"Uses $PQ \times PR \times \sin 60^\circ$, dropping the factor $\frac{1}{2}$."),
               (r"$\frac{15\sqrt{3}}{2}$ cm$^2$", r"Takes $3$ and $10$ as the sides enclosing the $60^\circ$ angle: $\frac{1}{2} \times 3 \times 10 \times \frac{\sqrt{3}}{2}$."),
               (r"$\frac{169\sqrt{3}}{4}$ cm$^2$", r"Assumes the $60^\circ$ angle makes the triangle equilateral with side QR $= 13$.")],
  check=_c041, values=[30 * sqrt(3), 60 * sqrt(3), Rational(15, 2) * sqrt(3), Rational(169, 4) * sqrt(3)],
  cognitive="Analysis", exams=CX)

# ---------------------------------------------------------------- 042
def _c042():
    # tangent from X: XT^2 = XP * XQ, with XQ = XP + PQ
    pq = symbols('pq', positive=True)
    return solve(Eq(12**2, 8 * (8 + pq)), pq)[0]
q("C16-A-042", T, "Chord cut off by a secant from the tangent length", "Easy",
  "Single-step computation",
  r"From a point X outside a circle, a tangent XT of length $12$ cm is drawn. A line through X cuts the circle at P and Q, with P between X and Q, and XP $= 8$ cm. What is the length of PQ, in cm?",
  "TITA",
  r"By the tangent-secant theorem, $XT^2 = XP \cdot XQ$, so $144 = 8 \cdot XQ$ and XQ $= 18$ cm. Then PQ $= 18 - 8 = 10$ cm.",
  "Reporting XQ instead of PQ.",
  "C16A-tangent-secant-power", "One application of the tangent-secant theorem and one subtraction.",
  tita_answer=10, check=_c042, cognitive="Recall",
  tita_traps=[(18, "Reports XQ instead of PQ."),
              (4, "Computes $12 - 8$.")])

# ---------------------------------------------------------------- 043
def _c043():
    sol = solve(Eq((r + 8)**2, r**2 + 20**2), r)
    return [v for v in sol if v > 0][0]
q("C16-A-043", T, "Radius from the tangent length and the nearest distance to the circle", "Medium",
  "Inverse/parameter",
  r"A point X is at a distance of $8$ cm from the nearest point of a circle, and the length of a tangent drawn from X to the circle is $20$ cm. What is the radius of the circle?",
  "MCQ",
  r"The nearest point lies on the line through X and the centre, so X is $r + 8$ from the centre. The radius to the point of contact is perpendicular to the tangent: $(r + 8)^2 = r^2 + 20^2$, so $16r + 64 = 400$ and $r = 21$ cm. (Equivalently $20^2 = 8(8 + 2r)$.)",
  r"Taking $\frac{20^2}{8} = 50$ as the diameter instead of as the whole secant length $8 + 2r$.",
  "C16A-tangent-secant-power", "Reverse use of the tangent length to find the radius.",
  correct=r"$21$ cm",
  distractors=[(r"$42$ cm", r"Reports the diameter $2r$."),
               (r"$25$ cm", r"Takes $\frac{400}{8} = 50$ as the diameter instead of $8 + 2r$."),
               (r"$12$ cm", r"Computes $20 - 8$.")],
  check=_c043, values=[21, 42, 25, 12], cognitive="Application")

# ---------------------------------------------------------------- 044
def _c044():
    xs = symbols('xs', positive=True)
    return solve(Eq(6 * (6 + 6), 4 * xs), xs)[0] - 4
q("C16-A-044", T, "Chord cut off by a second secant from the same external point", "Medium",
  "Multi-step word problem",
  r"From a point X outside a circle, two lines are drawn. The first meets the circle at P and Q, with P between X and Q, XP $= 6$ cm and PQ $= 6$ cm. The second meets the circle at R and S, with R between X and S, and XR $= 4$ cm. What is the length of RS?",
  "MCQ",
  r"By the secant-secant theorem, $XP \cdot XQ = XR \cdot XS$. Here XQ $= 12$, so $6 \times 12 = 4 \cdot XS$, giving XS $= 18$ cm and RS $= 18 - 4 = 14$ cm.",
  "Multiplying the outside segment by the chord instead of by the whole secant.",
  "C16A-secant-secant-power", "Product of whole secant and external part, then a subtraction.",
  correct=r"$14$ cm",
  distractors=[(r"$18$ cm", r"Reports XS instead of RS."),
               (r"$9$ cm", r"Uses $XP \cdot PQ = XR \cdot RS$, giving $\frac{36}{4}$."),
               (r"$8$ cm", r"Assumes both secants have the same total length $12$, so RS $= 12 - 4$.")],
  check=_c044, values=[14, 18, 9, 8], cognitive="Application")

# ---------------------------------------------------------------- 045
def _c045():
    # X is at distance 4 + r from the centre; power of X equals XR * XS
    sol = solve(Eq((4 + r)**2 - r**2, 6 * (6 + 10)), r)
    return [v for v in sol if v > 0][0]
q("C16-A-045", T, "Radius from a secant through the centre and a second secant", "Medium",
  "Inverse/parameter",
  r"From a point X outside a circle, a line through the centre of the circle meets it at P and Q, with P nearer to X and XP $= 4$ cm. Another line from X meets the circle at R and S, with R between X and S, XR $= 6$ cm and RS $= 10$ cm. What is the radius of the circle, in cm?",
  "TITA",
  r"By the secant-secant theorem, $XP \cdot XQ = XR \cdot XS = 6 \times 16 = 96$. So XQ $= \frac{96}{4} = 24$. PQ is a diameter, so $2r = 24 - 4 = 20$ and $r = 10$ cm.",
  "Taking XQ itself as the diameter, or reporting the diameter.",
  "C16A-secant-secant-power", "Secant-secant product, then recognising PQ as the diameter.",
  tita_answer=10, check=_c045, cognitive="Application",
  tita_traps=[(20, "Reports the diameter PQ."),
              (12, "Takes XQ $= 24$ as the diameter and halves it.")])
