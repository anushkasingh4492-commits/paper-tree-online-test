import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from figlib import Fig
from sympy import Point, Line, Segment, Triangle
import math

T = "Similarity and congruence"
EX2 = ("CAT", "XAT")


def tri_pts(qr, pr, pq):
    """Q=(0,0), R=(qr,0), P above QR with the given side lengths (exact sympy)."""
    qr, pr, pq = nsimplify(qr), nsimplify(pr), nsimplify(pq)
    x = (pq**2 - pr**2 + qr**2) / (2 * qr)
    y = sqrt(pq**2 - x**2)
    return Point(x, y), Point(0, 0), Point(qr, 0)


def area(*ps):
    return abs(Polygon(*ps).area)


def feet(p, a, b):
    return Line(a, b).projection(p)


# ---------------------------------------------------------------- EASY

def _e1():
    # triangle PQR, PQ = 10, choose any PR; ST || QR with PS = 4; PT = 6 given -> find TR
    x = symbols('x', positive=True)
    PR = solve(Eq(Rational(4, 10), 6 / x), x)[0]
    P, Q, R = tri_pts(14, PR, 10)
    S = P + (Q - P) * Rational(4, 10)
    Tt = Line(S, S + (R - Q)).intersection(Line(P, R))[0]
    assert P.distance(Tt) == 6
    return simplify(Tt.distance(R))

f = Fig()
_P = f.pt("P", 71 / 28, 9.6708); _Q = f.pt("Q", 0, 0); _R = f.pt("R", 14, 0)
_S = f.pt("S", 71 / 28 * 0.5, 9.6708 * 0.5); _Tp = f.pt("T", 71 / 28 + (14 - 71 / 28) * 0.5, 9.6708 * 0.5)
f.poly(_P, _Q, _R); f.seg(_S, _Tp)
f.text((0.6, 7.25), "4 cm"); f.text((-0.5, 2.42), "6 cm"); f.label_seg(_P, _Tp, "6 cm")
_alt = "Triangle PQR with S on PQ and T on PR, segment ST drawn parallel to QR; PS = 4 cm, SQ = 6 cm, PT = 6 cm. Figure not to scale."
q("C15-B-001", T, "Basic proportionality theorem: find a segment of the second side", "Easy",
  "Single-step computation",
  r"In triangle $PQR$, points $S$ and $T$ lie on sides $PQ$ and $PR$ respectively such that $ST$ is parallel to $QR$. If $PS = 4$ cm, $SQ = 6$ cm and $PT = 6$ cm, then the length of $TR$ is",
  "MCQ",
  r"Since $ST \parallel QR$, the basic proportionality theorem gives $\frac{PS}{SQ} = \frac{PT}{TR}$, so $\frac{4}{6} = \frac{6}{TR}$ and $TR = \frac{36}{4} = 9$ cm.",
  "Pairing the segments the wrong way round, or reporting the whole side PR.",
  "C15B-bpt-side-lengths", "Direct use of the proportionality theorem with one trap in pairing segments.",
  correct=r"$9$ cm",
  distractors=[(r"$4$ cm", r"Writes $\frac{PS}{SQ} = \frac{TR}{PT}$, so $TR = \frac{4 \times 6}{6} = 4$."),
               (r"$6$ cm", r"Assumes the parallel line cuts off equal lengths below it on both sides, so $TR = SQ = 6$."),
               (r"$8$ cm", r"Assumes equal differences: $TR - PT = SQ - PS = 2$, so $TR = 8$.")],
  check=_e1, values=[9, 4, 6, 8], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


def _e2():
    PR = symbols('PR', positive=True)
    # PS/PQ = PT/PR with PS = 24, PQ = 40, PT = PR - 12
    return solve(Eq(Rational(24, 40), (PR - 12) / PR), PR)[0]

q("C15-B-002", T, "Proportionality theorem in a field: find the full side from a parallel path", "Easy",
  "Inverse/parameter",
  r"A triangular garden $PQR$ has side $PQ = 40$ m. A straight path $ST$, parallel to $QR$, runs from $S$ on $PQ$ to $T$ on $PR$. If $PS = 24$ m and $TR = 12$ m, what is the length of side $PR$, in metres?",
  "TITA",
  r"As $ST \parallel QR$, $\frac{PS}{PQ} = \frac{PT}{PR}$, so $\frac{24}{40} = \frac{PR - 12}{PR}$. Then $0.6\,PR = PR - 12$, giving $0.4\,PR = 12$ and $PR = 30$ m.",
  "Stopping at PT, or matching PS with TR instead of with PT.",
  "C15B-bpt-side-lengths", "One proportion with the unknown on both sides.",
  tita_answer=30, check=_e2,
  tita_traps=[(18, r"Finds $PT = 18$ m and reports it as $PR$."),
              (20, r"Writes $\frac{PS}{SQ} = \frac{TR}{PT}$, so $PT = \frac{16 \times 12}{24} = 8$ and $PR = 20$.")],
  cognitive="Application")


def _e3():
    P, Q, R = Point(1, 4), Point(0, 0), Point(5, 0)
    S = P + (Q - P) * Rational(2, 5)
    Tt = P + (R - P) * Rational(2, 5)
    k = 12 / area(P, S, Tt)
    return simplify(k * area(S, Q, R, Tt))

f = Fig()
_P = f.pt("P", 1.5, 5); _Q = f.pt("Q", 0, 0); _R = f.pt("R", 6, 0)
_S = f.pt("S", 1.5 - 0.6, 5 - 2); _Tp = f.pt("T", 1.5 + 1.8, 3)
f.shade([_S, _Q, _R, _Tp]); f.poly(_P, _Q, _R); f.seg(_S, _Tp)
_alt = "Triangle PQR with segment ST parallel to QR, S on PQ and T on PR; the trapezium STRQ below ST is shaded."
q("C15-B-003", T, "Area of the trapezium cut off by a line parallel to the base", "Easy",
  "Multi-step word problem",
  r"In triangle $PQR$, $S$ is a point on $PQ$ and $T$ a point on $PR$ such that $ST \parallel QR$ and $PS : SQ = 2 : 3$. If the area of triangle $PST$ is $12$ cm$^2$, what is the area of the trapezium $STRQ$?",
  "MCQ",
  r"Triangles $PST$ and $PQR$ are similar with $\frac{PS}{PQ} = \frac{2}{5}$, so their areas are in the ratio $4 : 25$. Area of $PQR = 12 \times \frac{25}{4} = 75$ cm$^2$, and the trapezium has area $75 - 12 = 63$ cm$^2$.",
  "Using the ratio of sides for the ratio of areas, or using PS : SQ in place of PS : PQ.",
  "C15B-bpt-area-ratio", "Similarity plus squaring the ratio, then subtracting.",
  correct=r"$63$ cm$^2$",
  distractors=[(r"$18$ cm$^2$", r"Scales area linearly with $PS : SQ = 2 : 3$: $12 \times \frac{3}{2} = 18$."),
               (r"$15$ cm$^2$", r"Squares $PS : SQ$ and treats it as $PST : PQR = 4 : 9$, so $PQR = 27$ and the trapezium is $27 - 12 = 15$."),
               (r"$27$ cm$^2$", r"Squares $PS : SQ$: $12 \times \frac{9}{4} = 27$.")],
  check=_e3, values=[63, 18, 15, 27], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


def _e4():
    P, Q, R = tri_pts(20, 18, 12)
    d = (Q - P) / P.distance(Q) + (R - P) / P.distance(R)
    S = Line(P, P + d).intersection(Line(Q, R))[0]
    return simplify(Q.distance(S))

q("C15-B-004", T, "Internal angle bisector divides the opposite side in the ratio of the adjacent sides", "Easy",
  "Single-step computation",
  r"In triangle $PQR$, $PQ = 12$ cm, $PR = 18$ cm and $QR = 20$ cm. The bisector of angle $P$ meets $QR$ at $S$. What is the length of $QS$, in cm?",
  "TITA",
  r"By the angle bisector theorem, $QS : SR = PQ : PR = 12 : 18 = 2 : 3$. So $QS = \frac{2}{5} \times 20 = 8$ cm.",
  "Matching the ratio to the wrong segments or assuming the bisector meets the midpoint.",
  "C15B-bisector-internal", "One application of the angle bisector theorem.",
  tita_answer=8, check=_e4,
  tita_traps=[(12, r"Reports $SR$ by pairing $QS$ with $PR$."),
              (10, r"Assumes the bisector passes through the midpoint of $QR$.")],
  cognitive="Recall")


def _e5():
    s = symbols('s', positive=True)
    # lamp 4.5 m, man 1.5 m at 6 m; similar triangles from lamp top to tip
    return solve(Eq(Rational(3, 2) / s, Rational(9, 2) / (s + 6)), s)[0]

q("C15-B-005", T, "Shadow of a person under a street lamp", "Easy",
  "Single-step computation",
  r"A lamp is fixed at the top of a vertical pole, $4.5$ m above level ground. Ravi, who is $1.5$ m tall, stands upright $6$ m from the foot of the pole. What is the length of Ravi's shadow on the ground?",
  "MCQ",
  r"Let the shadow be $s$ m. The ray from the lamp past Ravi's head forms two similar right triangles with a common vertex at the tip of the shadow, so $\frac{1.5}{s} = \frac{4.5}{s + 6}$. Then $4.5s = 1.5s + 9$, so $s = 3$ m.",
  "Measuring the big triangle only up to Ravi's position rather than up to the shadow tip.",
  "C15B-shadow-lamp", "Similar triangles sharing the shadow tip; one equation.",
  correct=r"$3$ m",
  distractors=[(r"$2$ m", r"Writes $\frac{s}{6} = \frac{1.5}{4.5}$, comparing the shadow with the distance to the pole."),
               (r"$9$ m", r"Reports the distance $s + 6$ from the pole to the tip of the shadow."),
               (r"$18$ m", r"Inverts the ratio: $s = 6 \times \frac{4.5}{1.5}$.")],
  check=_e5, values=[3, 2, 9, 18], cognitive="Application")


def _e6():
    a = symbols('a', positive=True)
    return solve(Eq(a / 128, Rational(36, 48)**2), a)[0]

q("C15-B-006", T, "Ratio of areas of similar triangles from ratio of perimeters", "Easy",
  "Single-step computation",
  r"Two triangular cardboard pieces are similar. Their perimeters are $36$ cm and $48$ cm, and the area of the larger piece is $128$ cm$^2$. What is the area of the smaller piece?",
  "MCQ",
  r"For similar triangles, perimeters are in the ratio of corresponding sides, $36 : 48 = 3 : 4$. Areas are in the square of this ratio, $9 : 16$. So the smaller area is $128 \times \frac{9}{16} = 72$ cm$^2$.",
  "Using the ratio of perimeters directly as the ratio of areas.",
  "C15B-similar-area-ratio", "Single idea: areas scale as the square of the linear ratio.",
  correct=r"$72$ cm$^2$",
  distractors=[(r"$96$ cm$^2$", r"Scales the area linearly: $128 \times \frac{3}{4} = 96$."),
               (r"$54$ cm$^2$", r"Cubes the ratio: $128 \times \frac{27}{64} = 54$."),
               (r"$56$ cm$^2$", r"Reports the difference $128 - 72 = 56$ between the two areas.")],
  check=_e6, values=[72, 96, 54, 56], cognitive="Recall")


def _e7():
    Q, R, S = Point(0, 0), Point(25, 0), Point(5, 0)
    y = symbols('y', positive=True)
    P = Point(5, y)
    sol = solve(Eq((Q - P).dot(R - P), 0), y)
    return [v for v in sol if v > 0][0]

q("C15-B-007", T, "Altitude to the hypotenuse is the geometric mean of the two segments", "Easy",
  "Single-step computation",
  r"In triangle $PQR$, angle $P = 90^\circ$ and $PS$ is perpendicular to $QR$, with $S$ on $QR$. If $QS = 5$ cm and $SR = 20$ cm, what is the length of $PS$, in cm?",
  "TITA",
  r"Triangles $QSP$ and $PSR$ are similar (each is similar to $QPR$), so $\frac{QS}{PS} = \frac{PS}{SR}$, giving $PS^2 = 5 \times 20 = 100$ and $PS = 10$ cm.",
  "Not taking the square root, or reporting the hypotenuse.",
  "C15B-right-altitude-mean", "One similarity relation, no casework.",
  tita_answer=10, check=_e7,
  tita_traps=[(100, r"Stops at $PS^2 = 100$."), (25, r"Reports the hypotenuse $QR = 25$.")],
  cognitive="Recall")


def _e8():
    H = symbols('H', positive=True)
    return solve(Eq(H / 36, Rational(4, 3)), H)[0]

q("C15-B-008", T, "Sun shadows: equal ratio of height to shadow at the same instant", "Easy",
  "Single-step computation",
  r"At a certain moment on a sunny day, a vertical pole $4$ m tall casts a shadow $3$ m long on level ground. At the same moment, a vertical tower standing on the same level ground casts a shadow $36$ m long. What is the height of the tower?",
  "MCQ",
  r"The sun's rays are parallel, so the pole, the tower and their shadows form similar right triangles: $\frac{H}{36} = \frac{4}{3}$. Hence $H = 48$ m.",
  "Inverting the height to shadow ratio.",
  "C15B-shadow-sun", "One proportion from parallel rays.",
  correct=r"$48$ m",
  distractors=[(r"$27$ m", r"Inverts the ratio: $36 \times \frac{3}{4} = 27$."),
               (r"$37$ m", r"Reasons additively: the pole exceeds its shadow by $1$ m, so the tower is $36 + 1$."),
               (r"$64$ m", r"Squares the ratio: $36 \times \frac{16}{9} = 64$.")],
  check=_e8, values=[48, 27, 37, 64], cognitive="Application")


def _e9():
    H = symbols('H', positive=True)
    # equal angles at mirror: H/15 = 1.5/2
    return solve(Eq(H / 15, Rational(3, 2) / 2), H)[0]

q("C15-B-009", T, "Height of a tower using a mirror on the ground", "Easy",
  "Conceptual/application",
  r"To find the height of a tower, Priya places a small flat mirror on level ground $15$ m from the foot of the tower. She then stands upright $2$ m beyond the mirror, on the line joining the foot of the tower and the mirror, and sees the top of the tower reflected exactly at the centre of the mirror. Her eyes are $1.5$ m above the ground. Assuming the angle of incidence equals the angle of reflection, what is the height of the tower?",
  "MCQ",
  r"Equal angles at the mirror make the triangle formed by the tower and the mirror similar to the triangle formed by Priya and the mirror. So $\frac{H}{15} = \frac{1.5}{2}$ and $H = 11.25$ m.",
  "Pairing the tower with Priya's distance from the mirror, or using the total distance.",
  "C15B-mirror-reflection", "One pair of similar triangles from equal angles of reflection.",
  correct=r"$11.25$ m",
  distractors=[(r"$20$ m", r"Inverts the pairing: $H = \frac{2 \times 15}{1.5}$."),
               (r"$12.75$ m", r"Uses the total distance $17$ m: $H = \frac{1.5 \times 17}{2}$."),
               (r"$9.75$ m", r"Uses $15 - 2 = 13$ m as the tower's distance: $H = \frac{1.5 \times 13}{2}$.")],
  check=_e9, values=[Rational(45, 4), 20, Rational(51, 4), Rational(39, 4)], cognitive="Application")


def _e10():
    P, Q, R, S = Point(0, 0), Point(18, 0), Point(15, 7), Point(3, 7)
    O = Line(P, R).intersection(Line(Q, S))[0]
    return simplify(15 * O.distance(R) / P.distance(O))

q("C15-B-010", T, "Diagonals of a trapezium divide each other in the ratio of the parallel sides", "Easy",
  "Single-step computation",
  r"In trapezium $PQRS$, side $PQ$ is parallel to side $SR$, with $PQ = 18$ cm and $SR = 12$ cm. The diagonals $PR$ and $QS$ intersect at $O$. If $PO = 15$ cm, what is the length of $OR$, in cm?",
  "TITA",
  r"Triangles $OPQ$ and $ORS$ are similar (alternate angles), so $\frac{PO}{OR} = \frac{PQ}{SR} = \frac{18}{12}$. Hence $OR = 15 \times \frac{12}{18} = 10$ cm.",
  "Assuming the diagonals of a trapezium bisect each other.",
  "C15B-trapezium-diagonals", "One similarity pair inside the trapezium.",
  tita_answer=10, check=_e10,
  tita_traps=[(15, r"Assumes the diagonals bisect each other, as in a parallelogram."),
              (25, r"Reports the whole diagonal $PR = 15 + 10$.")],
  cognitive="Application")


def _e11():
    s = symbols('s', positive=True)
    return solve(Eq((s / 36)**2, Rational(16, 36)), s)[0]

q("C15-B-011", T, "Side of a similar triangle from the ratio of areas", "Easy",
  "Inverse/parameter",
  r"Two similar triangular plots have areas $16$ m$^2$ and $36$ m$^2$. A side of the larger plot is $36$ m long. What is the length of the corresponding side of the smaller plot?",
  "MCQ",
  r"Areas of similar triangles are in the square of the ratio of corresponding sides. So the side ratio is $\sqrt{\frac{16}{36}} = \frac{2}{3}$, and the side is $36 \times \frac{2}{3} = 24$ m.",
  "Using the ratio of areas as the ratio of sides.",
  "C15B-similar-area-ratio", "Reverse use of the square law; one step.",
  correct=r"$24$ m",
  distractors=[(r"$16$ m", r"Uses the area ratio as the side ratio: $36 \times \frac{16}{36} = 16$."),
               (r"$54$ m", r"Inverts the side ratio: $36 \times \frac{3}{2} = 54$."),
               (r"$81$ m", r"Inverts the area ratio and forgets the square root: $36 \times \frac{36}{16} = 81$.")],
  check=_e11, values=[24, 16, 54, 81], cognitive="Application")


def _e12():
    P, Q, R = Point(0, 0), Point(15, 0), Point(6, 8)
    assert area(P, Q, R) == 60
    d = (Q - P) / P.distance(Q) + (R - P) / P.distance(R)
    S = Line(P, P + d).intersection(Line(Q, R))[0]
    return simplify(area(P, Q, S))

f = Fig()
_P = f.pt("P", 0, 0); _Q = f.pt("Q", 15, 0); _R = f.pt("R", 6, 8)
_S = f.pt("S", 15 + (6 - 15) * 0.6, 8 * 0.6)
f.poly(_P, _Q, _R); f.seg(_P, _S)
f.label_seg(_P, _Q, "15 cm"); f.text((1.5, 5.1), "10 cm")
f.angle_mark(_Q, _P, _S, "", r=1.6); f.angle_mark(_S, _P, _R, "", r=2.0)
_alt = "Triangle PQR with PQ = 15 cm and PR = 10 cm; PS bisects angle P and meets QR at S."
q("C15-B-012", T, "Angle bisector splits the triangle's area in the ratio of the adjacent sides", "Easy",
  "Conceptual/application",
  r"In triangle $PQR$, $PQ = 15$ cm and $PR = 10$ cm. The bisector of angle $P$ meets $QR$ at $S$. If the area of triangle $PQR$ is $60$ cm$^2$, what is the area of triangle $PQS$?",
  "MCQ",
  r"By the angle bisector theorem, $QS : SR = PQ : PR = 3 : 2$. Triangles $PQS$ and $PSR$ share the altitude from $P$, so their areas are also $3 : 2$. Area of $PQS = 60 \times \frac{3}{5} = 36$ cm$^2$.",
  "Swapping the ratio, or assuming the bisector halves the area.",
  "C15B-bisector-internal", "Needs bisector ratio plus the equal-altitude area idea.",
  correct=r"$36$ cm$^2$",
  distractors=[(r"$24$ cm$^2$", r"Swaps the ratio and takes $\frac{2}{5}$ of $60$."),
               (r"$30$ cm$^2$", r"Assumes the bisector divides the area equally."),
               (r"$40$ cm$^2$", r"Takes area $PQS$ : area $PQR = PR : PQ = 2 : 3$.")],
  check=_e12, values=[36, 24, 30, 40], cognitive="Understanding",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


# ---------------------------------------------------------------- MEDIUM

def _m1():
    x = symbols('x', real=True)
    # PQ opposite R: PQ^2 = QR^2 + PR^2 - 2 QR PR cos R
    sols = solve(Eq(7**2, 10**2 + x**2 - 2 * 10 * x * cos(pi / 6)), x)
    return len([s for s in sols if s.is_real and s > 0])

q("C15-B-013", T, "SSA does not guarantee congruence: count possible triangles", "Medium",
  "Casework/optimisation",
  r"Kabir says that a triangle $PQR$ with $PQ = 7$ cm, $QR = 10$ cm and angle $R = 30^\circ$ is fixed uniquely. How many mutually non-congruent triangles $PQR$ actually satisfy these three conditions?",
  "TITA",
  r"Let $PR = x$. The cosine rule at $R$ gives $49 = 100 + x^2 - 2(10)(x)\cos 30^\circ$, that is $x^2 - 10\sqrt{3}\,x + 51 = 0$. The discriminant is $300 - 204 = 96 > 0$ and both roots $5\sqrt{3} \pm 2\sqrt{6}$ are positive, so there are $2$ non-congruent triangles (two sides and a non-included angle do not fix a triangle).",
  "Treating side-side-angle as a congruence criterion.",
  "C15B-congruence-ssa", "Must recognise the ambiguous case and verify both roots are valid.",
  tita_answer=2, check=_m1,
  tita_traps=[(1, r"Treats SSA as a congruence rule, so assumes a unique triangle."),
              (0, r"Assumes no triangle exists because $PQ < QR$.")],
  cognitive="Analysis")


def _m2():
    QR = symbols('QR', positive=True)
    # triangles QPS ~ QRP: QS/QP = QP/QR
    qr = solve(Eq(Rational(4, 10), 10 / QR), QR)[0]
    return Rational(4) / (qr - 4)

q("C15-B-014", T, "Common-angle similarity inside a triangle and ratio of areas", "Medium",
  "Conceptual/application",
  r"In triangle $PQR$, $S$ is a point on side $QR$ such that angle $QPS$ equals angle $PRQ$. If $PQ = 10$ cm and $QS = 4$ cm, then the ratio of the area of triangle $PQS$ to the area of triangle $PSR$ is",
  "MCQ",
  r"Triangles $QPS$ and $QRP$ share angle $Q$ and have angle $QPS = $ angle $QRP$, so they are similar and $\frac{QS}{QP} = \frac{QP}{QR}$. Thus $QR = \frac{100}{4} = 25$ cm and $SR = 21$ cm. Triangles $PQS$ and $PSR$ have the same altitude from $P$, so their areas are in the ratio $QS : SR = 4 : 21$.",
  "Comparing with the whole triangle or using the side ratio without squaring.",
  "C15B-common-angle-similarity", "Spotting the hidden similar pair, then an equal-altitude area argument.",
  correct=r"$4 : 21$",
  distractors=[(r"$4 : 25$", r"Compares triangle $PQS$ with the whole triangle $PQR$."),
               (r"$2 : 5$", r"Uses the similarity ratio $PQ : QR = 10 : 25$ of sides as the area ratio."),
               (r"$2 : 3$", r"Takes the side ratio $2 : 5$ and splits it as $2 : (5 - 2)$.")],
  check=_m2, values=[Rational(4, 21), Rational(4, 25), Rational(2, 5), Rational(2, 3)], cognitive="Analysis")


def _m3():
    # simulate positions: man at x(t) = d0 + 1.5 t, tip at X with X/6 = (X - x)/2
    t, X = symbols('t X', positive=True)
    xm = 5 + Rational(3, 2) * t
    tip = solve(Eq(X / 6, (X - xm) / 2), X)[0]
    return diff(tip, t) * 100

q("C15-B-015", T, "Speed of the tip of a moving shadow under a lamp post", "Medium",
  "Conceptual/application",
  r"A lamp hangs at the top of a vertical pole $6$ m above level ground. Arjun, who is $2$ m tall, walks in a straight line directly away from the foot of the pole at a constant $1.5$ m/s. At what speed does the tip of his shadow move along the ground, in cm per second?",
  "TITA",
  r"If Arjun is at distance $x$ and the tip at $X$, similar triangles give $\frac{X}{6} = \frac{X - x}{2}$, so $X = \frac{3}{2}x$. Hence the tip moves at $\frac{3}{2} \times 1.5 = 2.25$ m/s, that is $225$ cm per second.",
  "Finding the rate at which the shadow lengthens rather than the speed of its tip.",
  "C15B-shadow-lamp", "Needs a ratio that holds at every instant, then a rate.",
  tita_answer=225, check=_m3,
  tita_traps=[(75, r"Gives the rate of growth of the shadow's length, $\frac{1}{2}x$ changing at $0.75$ m/s."),
              (150, r"Assumes the tip moves at Arjun's own speed.")],
  cognitive="Analysis")


def _m4():
    h, d = symbols('h d', positive=True)
    sol = solve([Eq(h / (d + 3), Rational(8, 5) / 3), Eq(h / (d + 4 + 5), Rational(8, 5) / 5)], [h, d], dict=True)[0]
    return sol[h]

q("C15-B-016", T, "Height of a lamp from two shadow positions", "Medium",
  "Inverse/parameter",
  r"Meera, who is $1.6$ m tall, stands on level ground and her shadow due to a lamp at the top of a vertical pole is $3$ m long. She walks $4$ m directly away from the pole, and her shadow is now $5$ m long. What is the height of the lamp above the ground?",
  "MCQ",
  r"Let her first distance from the pole be $d$ and the lamp height $h$. Then $\frac{h}{d + 3} = \frac{1.6}{3}$ and $\frac{h}{d + 9} = \frac{1.6}{5}$. Dividing, $\frac{d + 9}{d + 3} = \frac{5}{3}$, so $d = 6$ m, and $h = \frac{1.6 \times 9}{3} = 4.8$ m.",
  "Equating the height ratio with the ratio of walk to change in shadow.",
  "C15B-shadow-lamp", "Two similar-triangle equations in two unknowns.",
  correct=r"$4.8$ m",
  distractors=[(r"$3.2$ m", r"Writes $\frac{h}{1.6} = \frac{4}{2}$, using the walk and the change in shadow."),
               (r"$6.0$ m", r"Reports her first distance $d$ from the pole."),
               (r"$4.0$ m", r"Writes $\frac{h}{1.6} = \frac{5}{2}$, using the new shadow and the change in shadow.")],
  check=_m4, values=[Rational(24, 5), Rational(16, 5), 6, 4], cognitive="Application")


def _m5():
    P, Q, R, S = Point(0, 0), Point(18, 0), Point(14, 5), Point(2, 5)
    O = Line(P, R).intersection(Line(Q, S))[0]
    k = 8 / area(O, S, R)
    return simplify(k * area(P, Q, R, S))

f = Fig()
_P = f.pt("P", 0, 0); _Q = f.pt("Q", 18, 0); _R = f.pt("R", 14, 7); _S = f.pt("S", 2, 7)
_O = f.pt("O", 8.4, 4.2, offset=(0, -1))
f.shade([_O, _S, _R]); f.poly(_P, _Q, _R, _S); f.seg(_P, _R); f.seg(_Q, _S)
f.label_seg(_P, _Q, "18 cm"); f.label_seg(_S, _R, "12 cm")
_alt = "Trapezium PQRS with PQ = 18 cm parallel to SR = 12 cm; diagonals PR and QS meet at O; triangle OSR is shaded."
q("C15-B-017", T, "Area of a trapezium from the area of one triangle formed by the diagonals", "Medium",
  "Multi-step word problem",
  r"In trapezium $PQRS$, $PQ \parallel SR$, $PQ = 18$ cm and $SR = 12$ cm. The diagonals intersect at $O$. If the area of triangle $OSR$ is $8$ cm$^2$, what is the area of the trapezium?",
  "MCQ",
  r"Triangles $OPQ$ and $ORS$ are similar with ratio $18 : 12 = 3 : 2$, so area $OPQ = 8 \times \frac{9}{4} = 18$. Also $\frac{PO}{OR} = \frac{3}{2}$, so area $OPS = \frac{3}{2} \times 8 = 12$, and similarly area $OQR = 12$. Total $= 8 + 18 + 12 + 12 = 50$ cm$^2$.",
  "Scaling areas linearly, or treating all four triangles as alike.",
  "C15B-trapezium-diagonals", "Combines a squared ratio with equal-altitude ratios for the side triangles.",
  correct=r"$50$ cm$^2$",
  distractors=[(r"$44$ cm$^2$", r"Scales $OPQ$ linearly to $12$ and takes the side triangles as $12$ each: $8 + 12 + 12 + 12$."),
               (r"$42$ cm$^2$", r"Takes the side triangles $OPS$ and $OQR$ equal to $OSR$: $8 + 18 + 8 + 8$."),
               (r"$26$ cm$^2$", r"Adds only the two similar triangles: $8 + 18$.")],
  check=_m5, values=[50, 44, 42, 26], cognitive="Application",
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


def _m6():
    a, b = symbols('a b', positive=True)
    sol = solve([Eq(a / b, Rational(6, 9)), Eq(a + b + 15, 50)], [a, b], dict=True)[0]
    P, Q, R = tri_pts(15, sol[b], sol[a])
    d = (Q - P) / P.distance(Q) + (R - P) / P.distance(R)
    S = Line(P, P + d).intersection(Line(Q, R))[0]
    assert simplify(Q.distance(S)) == 6
    return sol[b]

q("C15-B-018", T, "Angle bisector segments and perimeter give the sides", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, the bisector of angle $P$ meets $QR$ at $S$, with $QS = 6$ cm and $SR = 9$ cm. If the perimeter of triangle $PQR$ is $50$ cm, what is the length of $PR$, in cm?",
  "TITA",
  r"$QR = 15$, so $PQ + PR = 35$. By the angle bisector theorem $PQ : PR = QS : SR = 2 : 3$, so $PR = \frac{3}{5} \times 35 = 21$ cm (and $PQ = 14$ cm).",
  "Pairing PR with QS, or forgetting to remove QR from the perimeter.",
  "C15B-bisector-internal", "Two steps: subtract QR, then split in the bisector ratio.",
  tita_answer=21, check=_m6,
  tita_traps=[(14, r"Pairs $PR$ with $QS$ and reports $PQ$."),
              (30, r"Splits the whole perimeter $50$ in the ratio $2 : 3$.")],
  cognitive="Application")


def _m7():
    P, Q, R = tri_pts(5, 6, 9)
    d = (Q - P) / P.distance(Q) - (R - P) / P.distance(R)
    Tt = Line(P, P + d).intersection(Line(Q, R))[0]
    return simplify(R.distance(Tt))

q("C15-B-019", T, "External angle bisector divides the opposite side externally", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, $PQ = 9$ cm, $PR = 6$ cm and $QR = 5$ cm. The bisector of the exterior angle at $P$ meets line $QR$, extended beyond $R$, at $T$. What is the length of $RT$?",
  "MCQ",
  r"The external bisector divides $QR$ externally in the ratio $PQ : PR$: $\frac{QT}{RT} = \frac{9}{6}$. With $RT = x$ and $QT = x + 5$, $2(x + 5) = 3x$, so $x = 10$ cm.",
  "Using the internal division, or reporting QT.",
  "C15B-bisector-external", "External division set-up with an extension.",
  correct=r"$10$ cm",
  distractors=[(r"$15$ cm", r"Reports $QT = x + 5$."),
               (r"$2$ cm", r"Divides $QR$ internally in $9 : 6$ and reports the part next to $R$."),
               (r"$3$ cm", r"Divides $QR$ internally in $9 : 6$ and reports the part next to $Q$.")],
  check=_m7, values=[10, 15, 2, 3], cognitive="Application")


def _m8():
    a = symbols('a', positive=True)
    sols = solve(Eq(a * (25 - a), 144), a)
    return abs(sols[0] - sols[1])

q("C15-B-020", T, "Altitude on hypotenuse: find segments from the altitude and hypotenuse", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, angle $P = 90^\circ$ and $PS$ is the perpendicular from $P$ to $QR$. If $PS = 12$ cm and $QR = 25$ cm, by how many cm does the longer of the segments $QS$ and $SR$ exceed the shorter?",
  "TITA",
  r"Similarity of triangles $QSP$ and $PSR$ gives $QS \cdot SR = PS^2 = 144$, while $QS + SR = 25$. The numbers with sum $25$ and product $144$ are $9$ and $16$, so the difference is $16 - 9 = 7$ cm.",
  "Reporting one of the segments rather than their difference.",
  "C15B-right-altitude-mean", "Similarity gives a product; combine with the sum.",
  tita_answer=7, check=_m8,
  tita_traps=[(16, r"Reports the longer segment."), (9, r"Reports the shorter segment.")],
  cognitive="Application")


def _m9():
    P, Q, X, Y = Point(0, 0), Point(15, 0), Point(0, 6), Point(15, 12)
    O = Line(X, Q).intersection(Line(Y, P))[0]
    return O.y

q("C15-B-021", T, "Height of the crossing point of wires between two poles", "Medium",
  "Conceptual/application",
  r"Two vertical poles $PX$ and $QY$ stand on level ground with feet $P$ and $Q$, $15$ m apart; $PX = 6$ m and $QY = 12$ m. Straight wires are stretched from $X$ to $Q$ and from $Y$ to $P$, crossing at $O$. How high is $O$ above the ground?",
  "MCQ",
  r"Let $O$ be at height $h$, with foot $N$ on $PQ$. From the two pairs of similar triangles, $\frac{h}{6} = \frac{NQ}{PQ}$ and $\frac{h}{12} = \frac{PN}{PQ}$. Adding, $\frac{h}{6} + \frac{h}{12} = 1$, so $h = \frac{6 \times 12}{18} = 4$ m (the $15$ m does not matter).",
  "Averaging the two heights, or using twice the product over the sum.",
  "C15B-crossed-poles", "Key insight: the crossing height is independent of the distance.",
  correct=r"$4$ m",
  distractors=[(r"$9$ m", r"Takes the average of the two pole heights."),
               (r"$8$ m", r"Uses the harmonic mean $\frac{2 \times 6 \times 12}{18}$."),
               (r"$6$ m", r"Subtracts the pole heights, $12 - 6 = 6$, as if the crossing sat at the difference.")],
  check=_m9, values=[4, 9, 8, 6], cognitive="Understanding")


def _m10():
    h = symbols('h', positive=True)
    # crossing height for poles 12 and h, distance arbitrary (take 20): find h with crossing 4
    P, Q = Point(0, 0), Point(20, 0)
    X, Y = Point(0, 12), Point(20, h)
    O = Line(X, Q).intersection(Line(Y, P))[0]
    return solve(Eq(simplify(O.y), 4), h)[0]

q("C15-B-022", T, "Find a pole's height from the crossing height of the wires", "Medium",
  "Inverse/parameter",
  r"Two vertical poles stand on level ground. A wire from the top of each pole to the foot of the other is stretched taut, and the two wires cross at a point $4$ m above the ground. If one pole is $12$ m tall, how tall is the other pole?",
  "MCQ",
  r"If the poles are $a$ and $b$ m tall, the crossing height $h$ satisfies $\frac{1}{h} = \frac{1}{a} + \frac{1}{b}$. So $\frac{1}{b} = \frac{1}{4} - \frac{1}{12} = \frac{1}{6}$, and the other pole is $6$ m tall.",
  "Using the forward formula with the given numbers, or simple subtraction.",
  "C15B-crossed-poles", "Reversing the crossing-height relation.",
  correct=r"$6$ m",
  distractors=[(r"$3$ m", r"Applies $\frac{ab}{a + b}$ to $4$ and $12$: $\frac{48}{16} = 3$."),
               (r"$8$ m", r"Subtracts: $12 - 4 = 8$."),
               (r"$16$ m", r"Adds: $12 + 4 = 16$.")],
  check=_m10, values=[6, 3, 8, 16], cognitive="Application")


def _m11():
    s = symbols('s', positive=True)
    # base 12, height 6; top side of square at height s has width 12(6-s)/6
    return solve(Eq(s, 12 * (6 - s) / 6), s)[0]

q("C15-B-023", T, "Largest square with a side on the base of a triangle", "Medium",
  "Multi-step word problem",
  r"A triangular metal sheet has a base of $12$ cm and a height of $6$ cm on that base. A square plate is cut from it with one side lying along the base and the other two corners touching the other two sides of the triangle. What is the side of the square?",
  "MCQ",
  r"Let the side be $s$. The top edge of the square is at height $s$, where the triangle's width is $12 \times \frac{6 - s}{6}$ by similar triangles. Setting $s = 2(6 - s)$ gives $s = 4$ cm (in general $s = \frac{bh}{b + h} = \frac{72}{18}$).",
  "Using twice the product over the sum, or simply halving a dimension.",
  "C15B-inscribed-square", "Similar triangles above the square; one linear equation.",
  correct=r"$4$ cm",
  distractors=[(r"$6$ cm", r"Takes half the base."),
               (r"$3$ cm", r"Takes half the height."),
               (r"$8$ cm", r"Uses $\frac{2bh}{b + h} = \frac{144}{18}$.")],
  check=_m11, values=[4, 6, 3, 8], cognitive="Application")


def _m12():
    best = 0
    for k in range(1, 2000):
        y = Fraction(20 * k, 2000)
        A = y * 30 * (20 - y) / 20
        best = max(best, A)
    y = symbols('y', positive=True)
    A = y * 30 * (20 - y) / 20
    yc = solve(diff(A, y), y)[0]
    assert best <= A.subs(y, yc)
    return A.subs(y, yc)

q("C15-B-024", T, "Maximum area of a rectangle inscribed in a triangle", "Medium",
  "Casework/optimisation",
  r"A triangular plot has a base of $30$ m and a height of $20$ m on that base. A rectangular lawn is laid out inside it, with one side on the base and its two upper corners on the other two sides of the plot. What is the largest possible area of the lawn, in m$^2$?",
  "TITA",
  r"If the lawn has height $y$, its top side lies where the triangle's width is $30 \times \frac{20 - y}{20}$ by similar triangles. Area $= 1.5\,y(20 - y)$, which is largest at $y = 10$: $1.5 \times 10 \times 10 = 150$ m$^2$, half the plot's area.",
  "Forcing the lawn to be a square, or taking the whole triangle.",
  "C15B-inscribed-rectangle-max", "Similarity gives a quadratic to maximise.",
  tita_answer=150, check=_m12,
  tita_traps=[(144, r"Forces a square: side $\frac{30 \times 20}{50} = 12$, area $144$."),
              (300, r"Reports the area of the whole triangular plot.")],
  cognitive="Analysis", exams=EX2)


def _m13():
    P, Q, R = Point(1, 7), Point(0, 0), Point(9, 0)
    S = Q + (R - Q) * Rational(1, 3)
    Tm = (P + S) / 2
    U = Line(Q, Tm).intersection(Line(P, R))[0]
    return simplify(P.distance(U) / U.distance(R))

q("C15-B-025", T, "Ratio in which a cevian through a midpoint cuts the opposite side", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, $S$ is the point on $QR$ with $QS : SR = 1 : 2$, and $T$ is the midpoint of $PS$. The line $QT$, extended, meets $PR$ at $U$. Then $PU : UR$ equals",
  "MCQ",
  r"Draw $SV \parallel QU$ with $V$ on $PR$. In triangle $PSV$, $T$ is the midpoint of $PS$ and $TU \parallel SV$, so $PU = UV$. In triangle $RQU$, $SV \parallel QU$ gives $UV : VR = QS : SR = 1 : 2$. With $UV = k$, $PU = k$ and $VR = 2k$, so $PU : UR = k : 3k = 1 : 3$.",
  "Copying the given ratio, or setting up the auxiliary ratios backwards.",
  "C15B-cevian-ratio", "Needs an auxiliary parallel (or mass points) and two proportionality steps.",
  correct=r"$1 : 3$",
  distractors=[(r"$1 : 2$", r"Copies $QS : SR$ onto $PR$."),
               (r"$2 : 3$", r"Assigns masses $1$ at $Q$ and $2$ at $R$ in the same ratio as the segments, so $P$ gets $3$ and $PU : UR = 2 : 3$."),
               (r"$3 : 1$", r"Reverses the final ratio, measuring from $R$.")],
  check=_m13, values=[Rational(1, 3), Rational(1, 2), Rational(2, 3), 3], cognitive="Analysis", exams=EX2)


def _m14():
    H = symbols('H', positive=True)
    # ray slope 1.2/0.8; top of tower at H, ray reaches the wall 18 m away at height 6
    return solve(Eq(H - 18 * Rational(12, 8), 6), H)[0]

q("C15-B-026", T, "Sun shadow falling partly on the ground and partly on a wall", "Medium",
  "Multi-step word problem",
  r"At a certain moment, a vertical stick $1.2$ m tall casts a shadow $0.8$ m long on level ground. At the same moment, the shadow of a vertical tower runs $18$ m along the level ground to the foot of a vertical wall and then $6$ m up the wall. What is the height of the tower?",
  "MCQ",
  r"The sun's rays drop $1.2$ m for every $0.8$ m across, a ratio of $1.5$. Over the $18$ m of ground, the ray from the top of the tower drops $18 \times 1.5 = 27$ m and still strikes the wall $6$ m up. So the tower is $27 + 6 = 33$ m tall.",
  "Treating the wall part as extra ground shadow, or ignoring it.",
  "C15B-shadow-sun", "Two parts of the shadow must be handled differently.",
  correct=r"$33$ m",
  distractors=[(r"$27$ m", r"Ignores the part of the shadow on the wall."),
               (r"$36$ m", r"Treats the $6$ m on the wall as ground shadow: $(18 + 6) \times 1.5$."),
               (r"$18$ m", r"Inverts the ratio for the ground part: $18 \times \frac{0.8}{1.2} + 6$.")],
  check=_m14, values=[33, 27, 36, 18], cognitive="Application")


def _m15():
    d = symbols('d', positive=True)
    P, Q, R = Point(0, 20), Point(-15, 0), Point(10, 0)
    # line y = 20 - d cuts triangle; small triangle area must be half
    S = Line(P, Q).intersection(Line(Point(0, 20 - d), Point(1, 20 - d)))[0]
    Tt = Line(P, R).intersection(Line(Point(0, 20 - d), Point(1, 20 - d)))[0]
    eq = Eq(Rational(1, 2) * (Tt.x - S.x) * d, area(P, Q, R) / 2)
    return [v for v in solve(eq, d) if v > 0 and v < 20][0]

q("C15-B-027", T, "Line parallel to the base that halves the area of a triangle", "Medium",
  "Conceptual/application",
  r"A triangular field $PQR$ has its altitude from $P$ to $QR$ equal to $20$ m. A straight fence parallel to $QR$ divides the field into two parts of equal area. What is the perpendicular distance of the fence from $P$?",
  "MCQ",
  r"The fence cuts off a triangle similar to $PQR$ with half its area, so the ratio of corresponding lengths is $\frac{1}{\sqrt{2}}$. The distance from $P$ is $\frac{20}{\sqrt{2}} = 10\sqrt{2}$ m.",
  "Halving the altitude, or measuring from the base.",
  "C15B-parallel-equal-area", "Insight: half the area means sides in ratio 1 to root 2.",
  correct=r"$10\sqrt{2}$ m",
  distractors=[(r"$(20 - 10\sqrt{2})$ m", r"Correct ratio but gives the distance from $QR$."),
               (r"$10$ m", r"Halves the altitude, assuming areas scale linearly."),
               (r"$5$ m", r"Squares instead of taking the root: $\frac{d}{20} = \left(\frac{1}{2}\right)^2$.")],
  check=_m15, values=[10 * sqrt(2), 20 - 10 * sqrt(2), 10, 5], cognitive="Understanding")


def _m16():
    P, Q, R = Point(2, 12), Point(0, 0), Point(9, 0)
    S = P + (Q - P) * Rational(1, 6)
    U = P + (Q - P) * Rational(3, 6)
    hor = lambda X: Line(X, X + (R - Q))
    Tt = hor(S).intersection(Line(P, R))[0]
    V = hor(U).intersection(Line(P, R))[0]
    k = 5 / S.distance(Tt)
    return simplify(k * U.distance(V))

q("C15-B-028", T, "Two parallels to the base: compare their lengths", "Medium",
  "Multi-step word problem",
  r"In triangle $PQR$, points $S$ and $U$ lie on $PQ$ in the order $P, S, U, Q$ with $PS : SU : UQ = 1 : 2 : 3$. Lines through $S$ and $U$ parallel to $QR$ meet $PR$ at $T$ and $V$ respectively. If $ST = 5$ cm, what is the length of $UV$?",
  "MCQ",
  r"Triangles $PST$, $PUV$ and $PQR$ are similar, with corresponding sides proportional to $PS$, $PU$ and $PQ$, that is $1 : 3 : 6$. So $UV = 3 \times ST = 15$ cm.",
  "Using a remaining part of the side in place of the cumulative distance PU, or squaring a length ratio.",
  "C15B-bpt-side-lengths", "Must convert part ratios to cumulative distances from the vertex.",
  correct=r"$15$ cm",
  distractors=[(r"$45$ cm", r"Squares the ratio $PU : PS = 3$, as for areas: $UV = 5 \times 9$."),
               (r"$30$ cm", r"Reports $QR = 6 \times ST$."),
               (r"$25$ cm", r"Compares with the remaining part of the side: $\frac{UV}{ST} = \frac{SQ}{PS} = \frac{5}{1}$, so $UV = 25$.")],
  check=_m16, values=[15, 45, 30, 25], cognitive="Application")


def _m17():
    sides = [4, 6, 9]
    for k in range(1, 50):
        big = [k * x for x in sides]
        if max(big) - min(big) == 15:
            return sum(big)

q("C15-B-029", T, "Scale factor of similar triangles from a difference of sides", "Medium",
  "Inverse/parameter",
  r"A triangle has sides $4$ cm, $6$ cm and $9$ cm. A second triangle is similar to it, and in the second triangle the longest side exceeds the shortest side by $15$ cm. What is the perimeter of the second triangle, in cm?",
  "TITA",
  r"In the first triangle, longest minus shortest is $9 - 4 = 5$ cm. All lengths scale by the same factor, so $k = \frac{15}{5} = 3$, and the perimeter is $3 \times 19 = 57$ cm.",
  "Adding the difference to the perimeter rather than scaling.",
  "C15B-similar-scale-factor", "Scale factor from a difference, then apply to the perimeter.",
  tita_answer=57, check=_m17,
  tita_traps=[(34, r"Adds $15$ to the original perimeter $19$."),
              (95, r"Matches $15$ with $9 - 6 = 3$, giving $k = 5$ and $5 \times 19$.")],
  cognitive="Application")


def _m18():
    P, Q, R, S = Point(0, 0), Point(40, 0), Point(25, 12), Point(15, 12)
    O = Line(P, R).intersection(Line(Q, S))[0]
    h = Line(O, O + Point(1, 0))
    X = h.intersection(Line(P, S))[0]; Y = h.intersection(Line(Q, R))[0]
    return simplify(X.distance(Y))

q("C15-B-030", T, "Segment through the diagonals' intersection parallel to the bases of a trapezium", "Medium",
  "Conceptual/application",
  r"In trapezium $PQRS$, $PQ \parallel SR$ with $PQ = 40$ cm and $SR = 10$ cm. The diagonals meet at $O$. A line through $O$ parallel to $PQ$ meets the legs $PS$ and $QR$ at $X$ and $Y$. What is the length of $XY$?",
  "MCQ",
  r"$\frac{PO}{OR} = \frac{40}{10} = 4$. In triangle $PSR$, $XO \parallel SR$ gives $XO = SR \times \frac{PO}{PR} = 10 \times \frac{4}{5} = 8$; similarly $OY = 8$. So $XY = 16$ cm, the harmonic mean $\frac{2 \times 40 \times 10}{50}$.",
  "Taking the mid-line (arithmetic mean) or the geometric mean of the bases.",
  "C15B-trapezium-harmonic", "Two similarity steps; the answer is not the familiar mid-line.",
  correct=r"$16$ cm",
  distractors=[(r"$25$ cm", r"Takes the mid-line, the average of the bases."),
               (r"$34$ cm", r"Interpolates linearly between the bases but measures $O$'s position from the wrong base: $40 - 30 \times \frac{1}{5} = 34$."),
               (r"$20$ cm", r"Uses the geometric mean $\sqrt{40 \times 10}$.")],
  check=_m18, values=[16, 25, 34, 20], cognitive="Understanding")


# ---------------------------------------------------------------- DIFFICULT

def _d1():
    base = [16, 24, 36]
    best = 0
    cands = set(Fraction(x, y) for x in base for y in base)
    for k in cands:
        if k == 1:
            continue
        sc = [k * x for x in base]
        common = sum(min(sc.count(v), base.count(v)) for v in set(sc))
        if common >= 2:
            best = max(best, sum(sc))
    return best

q("C15-B-031", T, "Similar but not congruent triangles sharing two side lengths", "Difficult",
  "Casework/optimisation",
  r"Triangle $PQR$ has sides $16$ cm, $24$ cm and $36$ cm. Triangle $XYZ$ is similar to triangle $PQR$ but not congruent to it, and two of the side lengths of $XYZ$ are equal to two of the side lengths of $PQR$. What is the largest possible perimeter of triangle $XYZ$, in cm?",
  "TITA",
  r"The sides of $XYZ$ are $16k, 24k, 36k$ with $k \neq 1$. Since $16 : 24 = 24 : 36 = 2 : 3$, the matches occur for $k = \frac{3}{2}$ (sides $24, 36, 54$) or $k = \frac{2}{3}$ (sides $\frac{32}{3}, 16, 24$). No other $k$ gives two common lengths. The larger perimeter is $24 + 36 + 54 = 114$ cm.",
  "Matching only one side, or scaling by 2.",
  "C15B-five-parts-similar", "Casework on which pairs of sides can coincide; uses the geometric progression of sides.",
  tita_answer=114, check=_d1,
  tita_traps=[(76, r"Reports the perimeter of $PQR$ itself."),
              (152, r"Doubles every side of $PQR$, assuming the scale factor must be $2$.")],
  cognitive="Analysis", exams=EX2)


def _d2():
    D, x, s1, s2 = symbols('D x s1 s2', positive=True)
    # shadow from a lamp of height H when she is at distance d from its post: 2/s = H/(s + d)
    sh = lambda H, d: solve(Eq(Rational(2) * (s1 + d), H * s1), s1)[0]
    D0 = solve(Eq(sh(6, D / 2) - sh(8, D / 2), 5), D)[0]
    x0 = solve(Eq(sh(8, x), sh(6, D0 - x)), x)[0]
    assert 0 < x0 < D0
    return sh(8, x0)

q("C15-B-032", T, "Two lamps, two shadows: find the separation, then the equal shadow length", "Difficult",
  "Inverse/parameter",
  r"Two vertical lamp posts stand on level ground, with lamps at heights $8$ m and $6$ m. Sneha, who is $2$ m tall, stands on the straight line joining the feet of the posts, between them, and each lamp casts a separate shadow of her on the ground. When she stands exactly midway between the posts, one shadow is $5$ m longer than the other. She then moves along the same line to the point where her two shadows are equal in length. What is the length of each shadow then, in metres?",
  "TITA",
  r"Let the posts be $D$ m apart and her distance from the $8$ m post be $x$. For the $8$ m lamp, $\frac{s_1}{2} = \frac{s_1 + x}{8}$ gives $s_1 = \frac{x}{3}$; for the $6$ m lamp, $\frac{s_2}{2} = \frac{s_2 + D - x}{6}$ gives $s_2 = \frac{D - x}{2}$. At the midpoint the shadows are $\frac{D}{6}$ and $\frac{D}{4}$, differing by $\frac{D}{12} = 5$, so $D = 60$. Equal shadows: $\frac{x}{3} = \frac{60 - x}{2}$ gives $x = 36$, so each shadow is $\frac{36}{3} = 12$ m.",
  "Stopping at the position or the separation, or using the same shadow factor for both lamps.",
  "C15B-shadow-two-lamps", "Three stages: two different shadow relations, the separation from the midpoint condition, then the equal-shadow position.",
  tita_answer=12, check=_d2,
  tita_traps=[(36, r"Reports her distance from the $8$ m post instead of the shadow length."),
              (60, r"Reports the separation $D$ of the posts."),
              (24, r"Reports her distance $60 - 36$ from the $6$ m post.")],
  cognitive="Analysis", exams=EX2)


def _d3():
    x = symbols('x', positive=True)
    # extend legs to apex; areas proportional to squares of parallel sides
    return solve(Eq(x**2 - 8**2, 56**2 - x**2), x)[0]

f = Fig()
_P = f.pt("P", 0, 0); _Q = f.pt("Q", 56, 0); _R = f.pt("R", 32, 24); _S = f.pt("S", 24, 24)
f.poly(_P, _Q, _R, _S)
f.label_seg(_P, _Q, "56 cm"); f.label_seg(_S, _R, "8 cm")
_alt = "Trapezium PQRS with PQ = 56 cm parallel to SR = 8 cm; legs PS and QR."
q("C15-B-033", T, "Segment parallel to the bases that bisects the area of a trapezium", "Difficult",
  "Conceptual/application",
  r"In trapezium $PQRS$, $PQ \parallel SR$ with $PQ = 56$ cm and $SR = 8$ cm. A segment parallel to $PQ$, with its ends on the legs $PS$ and $QR$, divides the trapezium into two parts of equal area. What is the length of this segment?",
  "MCQ",
  r"Extend the legs to meet at $V$. Triangles cut off at $V$ by the parallel sides are similar, with areas proportional to the squares of those sides, say $8^2 k$, $x^2 k$ and $56^2 k$. Equal parts means $x^2 - 64 = 3136 - x^2$, so $x^2 = 1600$ and $x = 40$ cm.",
  "Taking the mid-line, or the segment through the diagonals' intersection.",
  "C15B-trapezium-rms", "Needs extension to a triangle and the square law; the answer is the root mean square.",
  correct=r"$40$ cm",
  distractors=[(r"$32$ cm", r"Takes the mid-line, the average of the bases."),
               (r"$14$ cm", r"Takes the segment through the intersection of the diagonals, $\frac{2 \times 56 \times 8}{64}$."),
               (r"$50$ cm", r"Divides the height in the ratio $56 : 8$ from $SR$, giving $8 + 48 \times \frac{7}{8}$.")],
  check=_d3, values=[40, 32, 14, 50], cognitive="Analysis", exams=EX2,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


def _d4():
    P, Q, R = Point(2, 9), Point(0, 0), Point(10, 0)
    S = Q + (R - Q) * Rational(2, 5)
    Tt = P + (R - P) * Rational(1, 3)
    O = Line(P, S).intersection(Line(Q, Tt))[0]
    k = 90 / area(P, Q, R)
    return simplify(k * area(O, S, R, Tt))

q("C15-B-034", T, "Area of a quadrilateral cut by two cevians", "Difficult",
  "Multi-step word problem",
  r"Triangle $PQR$ has area $90$ cm$^2$. Point $S$ lies on $QR$ with $QS : SR = 2 : 3$, and point $T$ lies on $PR$ with $PT : TR = 1 : 2$. Segments $PS$ and $QT$ intersect at $O$. What is the area of the quadrilateral $OSRT$?",
  "MCQ",
  r"Mass points: $PT : TR = 1 : 2$ gives masses $P : R = 2 : 1$, and $QS : SR = 2 : 3$ gives $Q : R = 3 : 2$; take $P = 4, Q = 3, R = 2$, so $S = 5$ and $PO : OS = 5 : 4$. Area $QTR = \frac{2}{3} \times 90 = 60$. Area $PQS = \frac{2}{5} \times 90 = 36$ and area $OQS = \frac{4}{9} \times 36 = 16$. So $OSRT = 60 - 16 = 44$ cm$^2$.",
  "Assuming O bisects PS, reversing the ratio PO : OS, or applying it to the wrong triangle.",
  "C15B-cevian-ratio", "Needs the ratio PO : OS before any area can be found; several area steps.",
  correct=r"$44$ cm$^2$",
  distractors=[(r"$40$ cm$^2$", r"Reverses the mass-point ratio to $PO : OS = 4 : 5$, so $OQS = \frac{5}{9} \times 36 = 20$ and $60 - 20 = 40$."),
               (r"$36$ cm$^2$", r"Applies $\frac{OS}{PS} = \frac{4}{9}$ to triangle $QSR$ ($54$ cm$^2$) instead of $PQS$, so $OQS$ is taken as $24$ and $60 - 24 = 36$."),
               (r"$42$ cm$^2$", r"Assumes $O$ is the midpoint of $PS$, so $OQS = 18$ and $60 - 18 = 42$.")],
  check=_d4, values=[44, 40, 36, 42], cognitive="Analysis", exams=EX2)


def _d5():
    seen = set()
    for a in range(1, 145):
        for b in range(1, 145):
            if a * b == 144:
                Q, S, R = Point(0, 0), Point(a, 0), Point(a + b, 0)
                P = Point(a, 12)
                if (Q - P).dot(R - P) == 0:
                    key = tuple(sorted([P.distance(Q), P.distance(R)], key=lambda v: float(v))) + (a + b,)
                    seen.add(key)
    return len(seen)

q("C15-B-035", T, "Counting right triangles with integer hypotenuse segments for a fixed altitude", "Difficult",
  "Casework/optimisation",
  r"In triangle $PQR$, angle $P = 90^\circ$ and the perpendicular $PS$ from $P$ to $QR$ has length $12$ cm. The lengths $QS$ and $SR$, in cm, are both positive integers. How many mutually non-congruent triangles $PQR$ are possible?",
  "TITA",
  r"Similarity of triangles $QSP$ and $PSR$ gives $QS \cdot SR = 144$. The number $144 = 2^4 \cdot 3^2$ has $15$ divisors, giving $15$ ordered pairs. Swapping $QS$ and $SR$ gives a congruent (mirror) triangle, so the unordered pairs are $\frac{15 + 1}{2} = 8$, counting $12 \times 12$ once.",
  "Counting ordered pairs, or dropping the equal case.",
  "C15B-right-altitude-mean", "Similarity to a product, then a divisor count with symmetry casework.",
  tita_answer=8, check=_d5,
  tita_traps=[(15, r"Counts ordered pairs, treating mirror images as different."),
              (7, r"Drops the isosceles case $QS = SR = 12$.")],
  cognitive="Analysis", exams=EX2)


def _d6():
    P, Q, R = tri_pts(15, 18, 12)
    d = (Q - P) / P.distance(Q) + (R - P) / P.distance(R)
    S = Line(P, P + d).intersection(Line(Q, R))[0]
    return simplify(P.distance(S))

q("C15-B-036", T, "Length of an internal angle bisector", "Difficult",
  "Multi-step word problem",
  r"In triangle $PQR$, $PQ = 12$ cm, $PR = 18$ cm and $QR = 15$ cm. The bisector of angle $P$ meets $QR$ at $S$. What is the length of $PS$?",
  "MCQ",
  r"By the angle bisector theorem, $QS : SR = 12 : 18$, so $QS = 6$ and $SR = 9$. The bisector length satisfies $PS^2 = PQ \cdot PR - QS \cdot SR = 216 - 54 = 162$ (from Stewart's theorem). So $PS = 9\sqrt{2}$ cm.",
  "Forgetting to subtract the product of the segments, adding it, or treating the bisector as an altitude.",
  "C15B-bisector-length", "Two results chained: the bisector ratio and the bisector-length relation.",
  correct=r"$9\sqrt{2}$ cm",
  distractors=[(r"$6\sqrt{6}$ cm", r"Uses $PS^2 = PQ \cdot PR = 216$ only."),
               (r"$3\sqrt{30}$ cm", r"Adds the product: $PS^2 = 216 + 54 = 270$."),
               (r"$9\sqrt{3}$ cm", r"Treats the bisector as perpendicular to $QR$ and uses triangle $PSR$: $PS^2 = 18^2 - 9^2 = 243$.")],
  check=_d6, values=[9 * sqrt(2), 6 * sqrt(6), 3 * sqrt(30), 9 * sqrt(3)], cognitive="Application", exams=EX2)


def _d7():
    # simulate the squares: legs (vertical a, horizontal b)
    a, b = Fraction(12), Fraction(24)
    total = Fraction(0)
    terms = []
    for _ in range(60):
        s = a * b / (a + b)
        terms.append(s * s)
        a, b = a - s, s
    r = terms[1] / terms[0]
    assert all(terms[i + 1] / terms[i] == r for i in range(10))
    return terms[0] / (1 - r)

q("C15-B-037", T, "Infinite sequence of squares inscribed in a right triangle", "Difficult",
  "Multi-step word problem",
  r"Right triangle $PQR$ has the right angle at $Q$, with $PQ = 12$ cm and $QR = 24$ cm. A square is drawn with one vertex at $Q$, two sides along $QP$ and $QR$, and the opposite vertex on $PR$. This leaves a smaller right triangle with vertex $P$ above the square. A second square is drawn in that triangle in the same way (a vertex at its right angle, two sides along its legs, the opposite vertex on $PR$), and the process continues without end. What is the total area of all the squares, in cm$^2$?",
  "TITA",
  r"The first square has side $\frac{12 \times 24}{12 + 24} = 8$, area $64$. The triangle above it has legs $12 - 8 = 4$ and $8$, similar to $PQR$ with ratio $\frac{4}{12} = \frac{1}{3}$, so each square's area is $\frac{1}{9}$ of the previous one. Total $= \frac{64}{1 - \frac{1}{9}} = 72$ cm$^2$.",
  "Using the linear ratio for areas in the geometric series.",
  "C15B-inscribed-square", "Similarity ratio must be found and squared, then summed as a series.",
  tita_answer=72, check=_d7,
  tita_traps=[(64, r"Counts only the first square."),
              (96, r"Uses the linear ratio $\frac{1}{3}$ for areas: $\frac{64}{1 - \frac{1}{3}}$.")],
  cognitive="Analysis", exams=EX2)


def _d8():
    # build a concrete triangle and point, compute small-triangle areas, then scale
    P, Q, R = Point(0, 0), Point(11, 0), Point(3, 7)
    # choose interior point O as weighted combination 2:4:5 of the vertex-opposite pieces
    # small triangle side ratios to the big one are 2/11, 4/11, 5/11
    wts = [Rational(2, 11), Rational(4, 11), Rational(5, 11)]
    O = P * wts[0] + Q * wts[1] + R * wts[2]
    pieces = []
    for (A, B, C) in [(P, Q, R), (Q, R, P), (R, P, Q)]:
        # small triangle on side AB: lines through O parallel to CA and CB meet AB
        X1 = Line(O, O + (A - C)).intersection(Line(A, B))[0]
        X2 = Line(O, O + (B - C)).intersection(Line(A, B))[0]
        pieces.append(area(O, X1, X2))
    pieces = sorted(pieces, key=lambda v: float(v))
    scale = 4 / pieces[0]
    sc = [simplify(scale * v) for v in pieces]
    assert sc == [4, 16, 25]
    return simplify(scale * area(P, Q, R))

q("C15-B-038", T, "Area of a triangle from three corner triangles cut by lines through an interior point", "Difficult",
  "Conceptual/application",
  r"Through a point $O$ inside triangle $PQR$, three lines are drawn parallel to the three sides. They divide triangle $PQR$ into three small triangles and three parallelograms. If the areas of the three small triangles are $4$, $16$ and $25$ cm$^2$, what is the area of triangle $PQR$?",
  "MCQ",
  r"Each small triangle is similar to $PQR$, so their sides are proportional to $\sqrt{4} : \sqrt{16} : \sqrt{25} = 2 : 4 : 5$. Along any side of $PQR$, the pieces are equal to corresponding sides of the three small triangles, so that side is $2 + 4 + 5 = 11$ units. Area of $PQR = 11^2 = 121$ cm$^2$.",
  "Adding only the triangle areas, or underestimating the parallelograms.",
  "C15B-interior-point-parallels", "Non-obvious insight that each side is the sum of corresponding sides of the small triangles.",
  correct=r"$121$ cm$^2$",
  distractors=[(r"$45$ cm$^2$", r"Adds only the three small triangles."),
               (r"$83$ cm$^2$", r"Takes each parallelogram as $\sqrt{xy}$ instead of $2\sqrt{xy}$: $45 + 8 + 10 + 20$."),
               (r"$90$ cm$^2$", r"Assumes the three parallelograms together equal the three triangles: $2 \times 45$.")],
  check=_d8, values=[121, 45, 83, 90], cognitive="Analysis", exams=EX2)


def _d9():
    Q, P, R = Point(0, 0), Point(0, 24), Point(32, 0)
    M = (P + R) / 2
    perp = Line(M, M + Point(P.y - R.y, R.x - P.x))
    hits = []
    for side in (Segment(Q, P), Segment(Q, R)):
        hits += [h for h in perp.intersection(side)]
    hits = [h for h in hits if h != M]
    assert len(hits) == 1
    return simplify(M.distance(hits[0]))

f = Fig()
_Q = f.pt("Q", 0, 0); _P = f.pt("P", 0, 24); _R = f.pt("R", 32, 0)
f.poly(_P, _Q, _R); f.right_angle(_P, _Q, _R)
f.text((3.0, 12), "24 cm"); f.label_seg(_Q, _R, "32 cm")
_alt = "Right triangle PQR with the right angle at Q, PQ = 24 cm vertical and QR = 32 cm horizontal, before folding."
q("C15-B-039", T, "Length of the crease when a vertex of a right triangle is folded onto another", "Difficult",
  "Multi-step word problem",
  r"A paper right triangle $PQR$ has the right angle at $Q$, with $PQ = 24$ cm and $QR = 32$ cm. It is folded along a straight crease so that vertex $P$ lands exactly on vertex $R$. What is the length of the crease (the part of the fold line lying on the paper)?",
  "MCQ",
  r"$PR = 40$, and the crease is the perpendicular bisector of $PR$, starting at its midpoint $M$ ($MR = 20$). Since $QR > PQ$, it meets $QR$ at a point $X$. Triangles $XMR$ and $PQR$ are right-angled and share angle $R$, so $\frac{MX}{MR} = \frac{PQ}{QR}$, giving $MX = 20 \times \frac{24}{32} = 15$ cm.",
  "Taking a mid-line of the triangle or half the hypotenuse.",
  "C15B-fold-crease", "Must identify which side the crease meets and the similar pair.",
  correct=r"$15$ cm",
  distractors=[(r"$20$ cm", r"Takes half the hypotenuse, $MR$."),
               (r"$12$ cm", r"Takes the crease as the mid-line through $M$ parallel to $PQ$."),
               (r"$16$ cm", r"Takes the crease as the mid-line through $M$ parallel to $QR$.")],
  check=_d9, values=[15, 20, 12, 16], cognitive="Analysis", exams=EX2,
  figure=dict(svg=f.svg(alt=_alt), alt=_alt, required=False))


def _d10():
    # brute force over candidate PR values: build the triangle, construct both bisector feet, measure ST
    found = []
    for k in range(1, 400):
        pr = Rational(k, 10)
        if not (pr < 12 + 10 and 12 < pr + 10 and 10 < pr + 12) or pr == 12:
            continue
        P, Q, R = tri_pts(10, pr, 12)
        u, v = (Q - P) / P.distance(Q), (R - P) / P.distance(R)
        S = Line(P, P + u + v).intersection(Line(Q, R))[0]
        Tt = Line(P, P + u - v).intersection(Line(Q, R))[0]
        if simplify(S.distance(Tt) - 24) == 0:
            found.append(pr)
    assert found == [8, 18], found
    return sum(found)

q("C15-B-040", T, "Find a side from the distance between the feet of the internal and external bisectors (two cases)", "Difficult",
  "Casework/optimisation",
  r"In triangle $PQR$, $PQ = 12$ cm and $QR = 10$ cm, and $PR$ is not equal to $PQ$. The internal bisector of angle $P$ meets $QR$ at $S$, and the external bisector of angle $P$ meets line $QR$ extended at $T$. If $ST = 24$ cm, what is the sum of all possible values of $PR$?",
  "MCQ",
  r"Let $PR = b$. Internally $SR = \frac{10b}{12 + b}$. If $b < 12$, $T$ lies beyond $R$ with $\frac{RT + 10}{RT} = \frac{12}{b}$, so $RT = \frac{10b}{12 - b}$ and $ST = \frac{10b}{12 + b} + \frac{10b}{12 - b} = \frac{240b}{144 - b^2} = 24$, giving $b^2 + 10b - 144 = 0$ and $b = 8$. If $b > 12$, $T$ lies beyond $Q$ and $ST = \frac{240b}{b^2 - 144} = 24$ gives $b^2 - 10b - 144 = 0$ and $b = 18$. Both triangles ($12, 10, 8$ and $12, 10, 18$) exist, so the sum is $8 + 18 = 26$ cm.",
  "Assuming T always lies beyond R, or taking ST as QT.",
  "C15B-bisector-external", "Must set up internal and external division in general and recognise that T can lie on either side, giving two valid triangles.",
  correct=r"$26$ cm",
  distractors=[(r"$8$ cm", r"Assumes $T$ lies beyond $R$ and finds only $PR = 8$."),
               (r"$18$ cm", r"Assumes $T$ lies beyond $Q$ and finds only $PR = 18$."),
               (r"$7$ cm", r"Takes $ST$ to be $QT = \frac{120}{12 - b}$; setting this equal to $24$ gives $PR = 7$.")],
  check=_d10, values=[26, 8, 18, 7], cognitive="Analysis", exams=EX2)
