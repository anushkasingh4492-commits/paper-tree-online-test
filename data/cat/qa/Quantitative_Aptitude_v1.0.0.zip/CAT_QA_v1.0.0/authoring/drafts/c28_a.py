import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *
from collections import Counter
import random

T = "Basic statistics"
HARD = ("CAT", "XAT")


def _mean(s):
    return sum(s, Integer(0)) / len(s) if any(isinstance(v, Basic) for v in s) else Fraction(sum(s), len(s))


def _med(s):
    s = sorted(s)
    n = len(s)
    if n % 2:
        return Fraction(s[n // 2])
    return Fraction(s[n // 2 - 1] + s[n // 2], 2)


def _pvar(s):
    if any(isinstance(v, Basic) for v in s):
        m = sum(s, Integer(0)) / len(s)
        return simplify(sum(((v - m) ** 2 for v in s), Integer(0)) / len(s))
    m = Fraction(sum(s), len(s))
    return sum((v - m) ** 2 for v in s) / len(s)


def _umode(s):
    c = Counter(s)
    top = max(c.values())
    k = [v for v in c if c[v] == top]
    return k[0] if len(k) == 1 else None


# ---------------------------------------------------------------- EASY

def _e1():
    data = [52, 61, 58, 66, 49, 63]
    r = max(data) - min(data)
    sols = [k for k in range(max(data) + 1, 400) if max(data + [k]) - min(data + [k]) == 2 * r]
    assert len(sols) == 1
    return sols[0]
q("C28-A-001", T, "Weight of a new member from the change in the range", "Easy",
  "Inverse/parameter",
  r"The weights, in kg, of $6$ friends are $52$, $61$, $58$, $66$, $49$ and $63$. Kabir, who is heavier than each of the $6$ friends, joins the group, and the range of the weights of the $7$ people becomes twice the range of the $6$ weights. What is Kabir's weight, in kg?",
  "TITA",
  r"The range of the $6$ weights is $66 - 49 = 17$ kg. Kabir is the heaviest, so the lightest is still $49$ kg and the new range is $\text{Kabir} - 49 = 2 \times 17 = 34$. Hence Kabir weighs $49 + 34 = 83$ kg.",
  "Adding the new range to the old maximum instead of to the minimum, or reporting the new range itself.",
  "C28A-range-new-member", "One idea: the newcomer becomes the new maximum while the minimum stays, so the range is measured from the old minimum.",
  tita_answer=83, check=_e1,
  tita_traps=[(100, "Adds the new range $34$ to the old maximum $66$."),
              (34, "Reports the new range instead of Kabir's weight.")],
  cognitive="Application")


def _e2():
    return Fraction(9 * 30000 - 54000, 8)
q("C28-A-002", T, "Average after one value leaves the group", "Easy",
  "Single-step computation",
  r"The average monthly salary of the $9$ employees of a small office is Rs. $30{,}000$. One employee, whose monthly salary is Rs. $54{,}000$, leaves the office and nobody joins. What is the average monthly salary of the remaining employees?",
  "MCQ",
  r"The total salary is $9 \times 30{,}000 = 2{,}70{,}000$. After the departure it is $2{,}70{,}000 - 54{,}000 = 2{,}16{,}000$ shared by $8$ employees, so the average is $\frac{2{,}16{,}000}{8} = 27{,}000$. Equivalently, the leaver was $24{,}000$ above the average, and that excess spread over $8$ people lowers the average by $3{,}000$.",
  "Dividing the new total by the old count, or moving the average in the wrong direction.",
  "C28A-mean-join-leave", "Single subtraction of one value from the total and division by the new count.",
  correct=r"Rs. $27{,}000$",
  distractors=[(r"Rs. $24{,}000$", "Divides the reduced total $2{,}16{,}000$ by $9$, the old head count."),
               (r"Rs. $33{,}000$", "Finds the correct shift of $3{,}000$ but adds it, thinking the average rises."),
               (r"Rs. $36{,}000$", "Adds the departing salary to the total: $\\frac{2{,}70{,}000 + 54{,}000}{9}$.")],
  check=_e2, values=[27000, 24000, 33000, 36000], cognitive="Application")


def _e3():
    data = [15, 25]                      # mean 20, SD 5 (population)
    f = [Fraction(9, 5) * c + 32 for c in data]
    m = _mean(f)
    sd = sqrt(Rational(_pvar(f)))
    return (m, sd)
q("C28-A-003", T, "Mean and SD after converting Celsius to Fahrenheit", "Easy",
  "Conceptual/application",
  r"The noon temperatures recorded at a hill station over a month have a mean of $20^\circ$C and a standard deviation of $5^\circ$C. Each reading is converted to Fahrenheit using $F = \frac{9}{5}C + 32$. What are the mean and the standard deviation of the converted readings?",
  "MCQ",
  r"Under $F = \frac{9}{5}C + 32$ the mean transforms the same way: $\frac{9}{5}(20) + 32 = 68$. The standard deviation is unaffected by adding $32$ and is multiplied by $\frac{9}{5}$: $\frac{9}{5}(5) = 9$. So the mean is $68^\circ$F and the SD is $9^\circ$F.",
  "Applying the additive constant to the SD, or treating the SD as unchanged by a change of units.",
  "C28A-shift-scale-spread", "Direct use of the shift and scale rules for mean and SD.",
  correct=r"Mean $68^\circ$F, SD $9^\circ$F",
  distractors=[(r"Mean $68^\circ$F, SD $41^\circ$F", "Applies the full conversion to the SD as well: $\\frac{9}{5}(5) + 32 = 41$."),
               (r"Mean $36^\circ$F, SD $9^\circ$F", "Multiplies the mean by $\\frac{9}{5}$ but omits the $+32$."),
               (r"Mean $68^\circ$F, SD $5^\circ$F", "Believes the SD does not change under a change of units.")],
  check=_e3, values=[(68, 9), (68, 41), (36, 9), (68, 5)], cognitive="Understanding")


def _e4():
    data = [10 - sqrt(6), 10 + sqrt(6)]  # variance 6
    return _pvar([3 * v - 4 for v in data])
q("C28-A-004", T, "Variance after multiplying and subtracting a constant", "Easy",
  "Single-step computation",
  r"A set of $10$ observations has variance $6$. Each observation is multiplied by $3$ and then $4$ is subtracted from the result. What is the variance of the new set of observations?",
  "TITA",
  r"Subtracting a constant does not change spread, and multiplying every value by $3$ multiplies the variance by $3^2 = 9$. The new variance is $9 \times 6 = 54$.",
  "Multiplying the variance by $3$ instead of $9$, or letting the subtraction affect it.",
  "C28A-shift-scale-spread", "One rule: variance scales by the square of the multiplier and ignores shifts.",
  tita_answer=54, check=_e4,
  tita_traps=[(18, "Multiplies the variance by $3$ instead of $3^2$."),
              (50, "Scales correctly but also subtracts $4$: $54 - 4$."),
              (14, "Applies the full transformation to the variance: $3 \\times 6 - 4$.")],
  cognitive="Understanding")


def _e5():
    return _med([43, 27, 46, 50, 34, 37, 29, 43])
q("C28-A-005", T, "Median of an even number of unsorted values", "Easy",
  "Single-step computation",
  r"The numbers of customers served at a cafe on $8$ consecutive days were $43$, $27$, $46$, $50$, $34$, $37$, $29$ and $43$. What is the median number of customers per day?",
  "MCQ",
  r"Sorted: $27, 29, 34, 37, 43, 43, 46, 50$. With $8$ values the median is the average of the $4$th and $5$th values: $\frac{37 + 43}{2} = 40$.",
  "Taking middle values without sorting, or using a single middle value for an even count.",
  "C28A-median-mode-direct", "Sort and average two middle values; the traps are skipping the sort or confusing median with mode.",
  correct=r"$40$",
  distractors=[(r"$42$", "Averages the $4$th and $5$th values of the unsorted list: $\\frac{50 + 34}{2}$."),
               (r"$43$", "Reports the mode, the only repeated value."),
               (r"$37$", "Takes only the $4$th sorted value as the median of an even-sized list.")],
  check=_e5, values=[40, 42, 43, 37], cognitive="Application")


def _e6():
    data = [12, 14, 17, 20, 23, 23, 31]
    new = [v for v in data if v != 31] + [8]
    return int(_med(new))
q("C28-A-006", T, "Median after the largest value is replaced by a small one", "Easy",
  "Single-step computation",
  r"The heights, in cm, of $7$ plants in a nursery tray are $12$, $14$, $17$, $20$, $23$, $23$ and $31$. The tallest plant dies and is replaced by a seedling $8$ cm tall; the other plants are unchanged. What is the median height of the $7$ plants now, in cm?",
  "TITA",
  r"The new heights in order are $8, 12, 14, 17, 20, 23, 23$. The median is the $4$th value, $17$ cm. The old median was $20$: the replaced value moved from above the median to below it, so the median drops to the next lower value.",
  "Believing that changing an extreme value can never move the median, or confusing the median with the mode.",
  "C28A-median-after-change", "Re-sort after one replacement; the trap is assuming the median is fixed when an extreme value changes.",
  tita_answer=17, check=_e6,
  tita_traps=[(20, "Keeps the old median, assuming a change at an extreme leaves the median unchanged."),
              (23, "Reports the mode instead of the median.")],
  cognitive="Understanding")


def _e7():
    data = [10, 0, 24, 17]
    new = [2 * (v + 5) for v in data]
    return max(new) - min(new)
q("C28-A-007", T, "Range after adding a constant and then doubling", "Easy",
  "Single-step computation",
  r"The range of the marks of a class in a test is $24$. The teacher first adds $5$ marks to every student's score and then doubles each resulting score. What is the range of the final scores?",
  "MCQ",
  r"Adding $5$ to every score moves the highest and lowest scores together, so the range stays $24$. Doubling every score doubles the gap between the highest and lowest, so the range becomes $2 \times 24 = 48$.",
  "Letting the added constant affect the range.",
  "C28A-range-linear-transform", "One-idea question on how range responds to a shift and a scale.",
  correct=r"$48$",
  distractors=[(r"$58$", "Adds $5$ to the range and then doubles: $2(24 + 5)$."),
               (r"$29$", "Adds $5$ to the range and ignores the doubling."),
               (r"$53$", "Doubles the range and then adds $5$.")],
  check=_e7, values=[48, 58, 29, 53], cognitive="Understanding")


def _e8():
    rnd = random.Random(8)
    out = set()
    for _ in range(500):
        p = [34, 81] + [rnd.randint(34, 81) for _ in range(rnd.randint(1, 30))]
        qq = [42, 92] + [rnd.randint(42, 92) for _ in range(rnd.randint(1, 30))]
        assert max(p) - min(p) == 47 and max(qq) - min(qq) == 50
        out.add(max(p + qq) - min(p + qq))
    assert len(out) == 1
    return out.pop()
q("C28-A-008", T, "Range of two sections combined", "Easy",
  "Conceptual/application",
  r"In a test, the lowest score in section P is $34$ and the range of the scores in section P is $47$. The highest score in section Q is $92$ and the range of the scores in section Q is $50$. What is the range of the scores of the two sections taken together?",
  "TITA",
  r"Section P runs from $34$ to $34 + 47 = 81$ and section Q runs from $92 - 50 = 42$ to $92$. Together the lowest score is $34$ and the highest is $92$, so the combined range is $92 - 34 = 58$.",
  "Adding the two ranges, or taking the larger of the two ranges as the combined range.",
  "C28A-combined-range", "Locate each section's extremes and take the overall extremes.",
  tita_answer=58, check=_e8,
  tita_traps=[(97, "Adds the two ranges, $47 + 50$."),
              (50, "Takes the larger of the two ranges as the combined range.")],
  cognitive="Understanding")


def _e9():
    recorded = [22, 27, 31, 38, 41, 43, 49, 53, 58]
    true = list(recorded)
    true[true.index(43)] = 34
    return _med(true)
q("C28-A-009", T, "Correcting a median after a misrecorded value", "Easy",
  "Multi-step word problem",
  r"The marks of $9$ students, as recorded, were $22$, $27$, $31$, $38$, $41$, $43$, $49$, $53$ and $58$. It was later found that one student's mark of $34$ had been recorded as $43$; every other mark was recorded correctly. What is the correct median of the $9$ marks?",
  "MCQ",
  r"The correct marks in order are $22, 27, 31, 34, 38, 41, 49, 53, 58$. The median is the $5$th value, $38$. The corrected mark moved from above the old median $41$ to below it, so the median moves down one place in the old list, from $41$ to $38$.",
  "Leaving the median unchanged, or shifting it as one would shift the mean.",
  "C28A-median-after-change", "Re-sort after a correction that crosses the median.",
  correct=r"$38$",
  distractors=[(r"$41$", "Keeps the recorded median, assuming one correction cannot change the median."),
               (r"$40$", "Lowers the median by the change in the mean, $\\frac{43 - 34}{9} = 1$."),
               (r"$32$", "Lowers the median by the full correction: $41 - 9$.")],
  check=_e9, values=[38, 41, 40, 32], cognitive="Application")


def _e10():
    for a in range(1, 200, 2):
        s = [a + 2 * i for i in range(10)]
        if _med(s) == 46:
            s.remove(sorted(s)[2])
            return _med(s)
q("C28-A-010", T, "Median of consecutive odd numbers after one is removed", "Easy",
  "Conceptual/application",
  r"The median of $10$ consecutive odd numbers is $46$. The third smallest of these numbers is removed. What is the median of the remaining $9$ numbers?",
  "MCQ",
  r"With $10$ numbers the median $46$ is the average of the $5$th and $6$th numbers, which are $45$ and $47$. The numbers are $37, 39, \ldots, 55$. Removing $41$, the third smallest, leaves $37, 39, 43, 45, 47, 49, 51, 53, 55$, whose middle ($5$th) value is $47$.",
  "Assuming the median is unchanged, or that removing a small value moves the median down.",
  "C28A-ap-consecutive-stats", "One positional insight: removing a value below the middle shifts the middle up by one place.",
  correct=r"$47$",
  distractors=[(r"$46$", "Assumes removing one number leaves the median unchanged."),
               (r"$45$", "Takes the lower of the two original middle numbers, thinking that removing a small number pulls the median down."),
               (r"$48$", "Treats the $9$ remaining numbers as an even count and averages the $5$th and $6$th values, $\\frac{47 + 49}{2}$.")],
  check=_e10, values=[47, 46, 45, 48], cognitive="Understanding")


def _e11():
    return _med([12, 15, 18, 22, 25, 31, 40, 16, 17])
q("C28-A-011", T, "Median after inserting two values", "Easy",
  "Single-step computation",
  r"The lengths, in minutes, of $7$ phone calls are $12$, $15$, $18$, $22$, $25$, $31$ and $40$. Two more calls, of lengths $16$ and $17$ minutes, are added to the list. What is the median length of the $9$ calls, in minutes?",
  "TITA",
  r"Sorted list of $9$ calls: $12, 15, 16, 17, 18, 22, 25, 31, 40$. The median is the $5$th value, $18$ minutes. Both new calls are below the old median $22$, so the median moves down one place in the old list, from $22$ to $18$.",
  "Assuming the median stays the same, or not re-sorting after appending.",
  "C28A-median-after-insertion", "Re-sort and pick the middle value.",
  tita_answer=18, check=_e11,
  tita_traps=[(22, "Keeps the median of the original $7$ calls."),
              (25, "Appends $16$ and $17$ at the end without sorting and takes the $5$th entry.")],
  cognitive="Application")


def _e12():
    data = [8, 10, 12, 14, 16, 18, 20, 22]
    assert _mean(data) == 15
    return sum(v - 12 for v in data)
q("C28-A-012", T, "Sum of deviations from a value other than the mean", "Easy",
  "Conceptual/application",
  r"The mean of the rainfall readings recorded on $8$ days is $15$ mm. What is the sum of the deviations of the $8$ readings from $12$ mm (each deviation being the reading minus $12$ mm)?",
  "MCQ",
  r"$\sum (x_i - 12) = \sum x_i - 8 \times 12 = 8 \times 15 - 96 = 24$ mm. Only deviations taken from the mean itself add up to zero.",
  "Believing every sum of deviations is zero, or not multiplying by the number of readings.",
  "C28A-sum-of-deviations", "Single application of the property of deviations, with the zero-sum trap.",
  correct=r"$24$ mm",
  distractors=[(r"$0$ mm", "Applies the zero-sum property, which holds only for deviations from the mean."),
               (r"$3$ mm", "Finds the deviation of the mean from $12$ but does not multiply by $8$."),
               (r"$-24$ mm", "Takes each deviation as $12$ minus the reading.")],
  check=_e12, values=[24, 0, 3, -24], cognitive="Understanding")


def _e13():
    data = [20000, 27000, 43000]       # mean 30000, median 27000
    assert _mean(data) == 30000 and _med(data) == 27000
    return _med([Fraction(9, 10) * (v - 2000) for v in data])
q("C28-A-013", T, "Median after a fixed deduction followed by a percentage cut", "Easy",
  "Single-step computation",
  r"In a company, the mean monthly salary is Rs. $30{,}000$ and the median monthly salary is Rs. $27{,}000$. During a slow quarter, a fixed amount of Rs. $2{,}000$ is first deducted from every employee's salary, and then every employee's reduced salary is cut by $10\%$. What is the new median monthly salary?",
  "MCQ",
  r"The change $x \mapsto 0.9(x - 2000)$ keeps the order of the salaries, so the median changes the same way: $0.9 \times (27{,}000 - 2{,}000) = 0.9 \times 25{,}000 = 22{,}500$.",
  "Applying the two operations in the wrong order, or transforming the mean instead of the median.",
  "C28A-linear-transform-centre", "One order-preserving transformation applied to the median.",
  correct=r"Rs. $22{,}500$",
  distractors=[(r"Rs. $22{,}300$", "Applies the $10\\%$ cut first and then deducts: $0.9 \\times 27{,}000 - 2{,}000$."),
               (r"Rs. $25{,}200$", "Transforms the mean, $0.9 \\times (30{,}000 - 2{,}000)$, and reports it as the median."),
               (r"Rs. $24{,}300$", "Applies the $10\\%$ cut and omits the deduction.")],
  check=_e13, values=[22500, 22300, 25200, 24300], cognitive="Application")


def _e14():
    return _pvar([3, 5, 6, 9, 12])
q("C28-A-014", T, "Variance of five values", "Easy",
  "Single-step computation",
  r"The numbers of customer complaints received by a helpline on $5$ days were $3$, $5$, $6$, $9$ and $12$. Taking variance as the mean of the squared deviations from the mean, what is the variance of these numbers?",
  "MCQ",
  r"The mean is $\frac{35}{5} = 7$. Deviations: $-4, -2, -1, 2, 5$, with squares $16, 4, 1, 4, 25$ summing to $50$. Variance $= \frac{50}{5} = 10$.",
  "Not dividing by the count, or forgetting to subtract the square of the mean.",
  "C28A-variance-direct", "Direct computation with small numbers.",
  correct=r"$10$",
  distractors=[(r"$50$", "Stops at the sum of squared deviations without dividing by $5$."),
               (r"$59$", "Takes the mean of the squares, $\\frac{295}{5}$, without subtracting $7^2$."),
               (r"$9$", "Reports the range $12 - 3$ as the measure of spread asked for.")],
  check=_e14, values=[10, 50, 59, 9], cognitive="Application")


def _e15():
    table = {4: 9, 5: 11, 6: 4, 7: 3, 8: 12, 9: 1, 10: 1}
    data = [v for v, f in table.items() for _ in range(f)]
    return _med(data)
q("C28-A-015", T, "Median from a frequency table with an odd total", "Easy",
  "Single-step computation",
  r"In a survey, $41$ students reported the number of books they read last year: $9$ students read $4$ books, $11$ read $5$, $4$ read $6$, $3$ read $7$, $12$ read $8$, $1$ read $9$ and $1$ read $10$. What is the median number of books read?",
  "MCQ",
  r"With $41$ values the median is the $21$st value in order. Cumulative frequencies: $9$ (up to $4$ books), $20$ (up to $5$), $24$ (up to $6$). The $21$st value lies in the group reading $6$ books, so the median is $6$.",
  r"Locating the median at position $\frac{n}{2}$ instead of $\frac{n+1}{2}$, or confusing median and mode.",
  "C28A-frequency-table-median", "Cumulative frequency lookup; the trap is the position of the median.",
  correct=r"$6$",
  distractors=[(r"$5$", "Uses position $\\frac{41}{2} = 20.5$, rounds down to the $20$th value, which is $5$."),
               (r"$8$", "Reports the mode, the value with the highest frequency $12$."),
               (r"$7$", "Takes the middle of the listed values $4$ to $10$, ignoring frequencies.")],
  check=_e15, values=[6, 5, 8, 7], cognitive="Application")


# ---------------------------------------------------------------- MEDIUM

def _m1():
    base = [11, 14, 17, 20]
    return sum(x for x in range(-200, 400) if _mean(base + [x]) == _med(base + [x]))
q("C28-A-016", T, "Unknown value making mean equal to median, casework", "Medium",
  "Casework/optimisation",
  r"Five numbers are $11$, $14$, $17$, $20$ and $x$, where $x$ is an integer. The mean of the five numbers equals their median. What is the sum of all possible values of $x$?",
  "TITA",
  r"The mean is $\frac{62 + x}{5}$. If $x \le 14$ the median is $14$, so $62 + x = 70$, $x = 8$, which is valid. If $14 \le x \le 17$ the median is $x$, so $62 + x = 5x$, $x = 15.5$, not an integer. If $x \ge 17$ the median is $17$, so $62 + x = 85$, $x = 23$, valid. The possible values are $8$ and $23$, with sum $31$.",
  "Assuming the unknown sits at one end and finding only one case.",
  "C28A-mean-equals-median-unknown", "Needs a three-way split on where $x$ falls, with one case rejected for integrality.",
  tita_answer=31, check=_m1,
  tita_traps=[(23, "Assumes $x$ is the largest value and finds only $x = 23$."),
              (8, "Assumes $x$ is the smallest value and finds only $x = 8$.")],
  cognitive="Analysis")


def _m2():
    p = symbols('p')
    pv = solve(Eq(40 * (1 - p) + 70 * p, 46), p)[0]          # share scoring 70
    n = 10
    data = [70] * int(pv * n) + [40] * int((1 - pv) * n)
    assert _mean(data) == 46
    return sqrt(Rational(_pvar(data)))
q("C28-A-017", T, "Standard deviation of two-valued data from the mean", "Medium",
  "Multi-step word problem",
  r"Every student in a class scored either $40$ or $70$ marks in a test, and the mean mark of the class was $46$. Taking variance as the mean of the squared deviations from the mean, what is the standard deviation of the marks?",
  "MCQ",
  r"If a fraction $p$ scored $70$, then $40 + 30p = 46$, so $p = \frac{1}{5}$. The deviations are $-6$ for the $\frac{4}{5}$ who scored $40$ and $24$ for the $\frac{1}{5}$ who scored $70$, so the variance is $\frac{4}{5}(36) + \frac{1}{5}(576) = 28.8 + 115.2 = 144$. The standard deviation is $12$. (In general it is $30\sqrt{p(1 - p)} = 30 \times \frac{2}{5}$.)",
  "Taking half the range as the standard deviation, or using the deviation of one group alone.",
  "C28A-two-valued-spread", "Recover the group shares from the mean, then weight the squared deviations.",
  correct=r"$12$",
  distractors=[(r"$15$", "Takes half the range, $\\frac{70 - 40}{2}$, as if the two scores were equally common."),
               (r"$24$", "Uses only the deviation of the $70$ scorers from the mean, $70 - 46$."),
               (r"$6$", "Uses only the deviation of the $40$ scorers from the mean, $46 - 40$.")],
  check=_m2, values=[12, 15, 24, 6], cognitive="Application")


def _m3():
    crew = [62, 78, 66, 74, 68, 72, 64, 76]           # mean 70, variance 30
    assert _mean(crew) == 70 and _pvar(crew) == 30
    rest = [v for v in crew if v not in (64, 76)]
    x = symbols('x')
    sols = solve(Eq(_pvar(rest + [x, 140 - x]), 46), x)
    pair = sorted(int(s) for s in sols)
    assert _mean(rest + pair) == 70
    return max(pair)
q("C28-A-018", T, "Weights of two replacements from the change in variance", "Medium",
  "Multi-step word problem",
  r"The $8$ rowers in a boat have a mean weight of $70$ kg and a variance of $30$ kg$^2$, taking variance as the mean of the squared deviations from the mean. Two rowers, weighing $64$ kg and $76$ kg, are replaced by two new rowers. After the change the mean weight is still $70$ kg and the variance is $46$ kg$^2$. What is the weight of the heavier new rower, in kg?",
  "TITA",
  r"The mean stays $70$, so the newcomers weigh $70 - d$ and $70 + d$ for some $d$. The sum of squared deviations from $70$ was $8 \times 30 = 240$; removing $64$ and $76$ takes away $36 + 36 = 72$, leaving $168$. It must become $8 \times 46 = 368$, so the newcomers add $2d^2 = 200$ and $d = 10$. They weigh $60$ kg and $80$ kg; the heavier weighs $80$ kg.",
  "Forgetting to remove the squared deviations of the rowers who left, or reporting the lighter newcomer.",
  "C28A-variance-replacement", "Sum-of-squares bookkeeping for a replacement with the mean held fixed.",
  tita_answer=80, check=_m3,
  tita_traps=[(78, "Lets the newcomers supply only the increase $368 - 240 = 128$, so $d = 8$, forgetting the $72$ removed with the old rowers."),
              (60, "Reports the lighter new rower.")],
  exams=HARD, cognitive="Analysis")


def _m4():
    return 25 * 40 - 20 * 38 - 4 * 45
q("C28-A-019", T, "Score needed in a final match to reach a target average", "Medium",
  "Multi-step word problem",
  r"Harpreet's average score over the first $20$ matches of a season is $38$ runs. She plays $5$ more matches and wants her average over all $25$ matches to be exactly $40$ runs. Her average over the first $4$ of these $5$ matches is $45$ runs. How many runs must she score in the $5$th of these matches?",
  "MCQ",
  r"She needs $25 \times 40 = 1000$ runs in all. She has $20 \times 38 = 760$ from the first $20$ matches and $4 \times 45 = 180$ from the next $4$. The last match must give $1000 - 760 - 180 = 60$ runs.",
  "Setting the target only over the last $5$ matches, or stopping at the required average.",
  "C28A-target-average", "Totals over three blocks; the traps are the scope of the target and reporting an intermediate.",
  correct=r"$60$",
  distractors=[(r"$20$", "Applies the target of $40$ to the last $5$ matches alone: $5 \\times 40 - 180$."),
               (r"$48$", "Reports the average needed over the last $5$ matches, $\\frac{1000 - 760}{5}$."),
               (r"$15$", "Takes the $240$ runs still needed and subtracts $5 \\times 45 = 225$, as if all $5$ remaining matches averaged $45$.")],
  check=_m4, values=[60, 20, 48, 15], cognitive="Application")


def _m5():
    poss = set()
    for s in range(1, 40):
        big = s + 12
        if not (s < 20 < big):
            continue
        for lo in itertools.combinations(range(s + 1, 20), 2):
            for hi in itertools.combinations(range(21, big), 2):
                data = [s, *lo, 20, *hi, big]
                assert _med(data) == 20 and max(data) - min(data) == 12 and len(set(data)) == 7
                poss.add(s)
    return len(poss)
q("C28-A-020", T, "Possible smallest values given the median and the range", "Medium",
  "Casework/optimisation",
  r"Seven distinct positive integers have a median of $20$ and a range of $12$. How many different values can the smallest of the seven integers take?",
  "TITA",
  r"Let the smallest be $s$; the largest is $s + 12$. Three distinct integers lie below $20$, the smallest being $s$, so $s \le 17$. Three distinct integers lie above $20$, the largest being $s + 12$, so $s + 12 \ge 23$, that is $s \ge 11$. Every $s$ from $11$ to $17$ works (for example $s, 18, 19, 20, 21, 22, s + 12$), giving $7$ values.",
  "Ignoring that three distinct values must fit on each side of the median.",
  "C28A-range-median-bounds", "Two-sided bounds from the median position and the range, with distinctness doing the work.",
  tita_answer=7, check=_m5,
  tita_traps=[(13, "Allows repeated values, so only $s \\le 20 \\le s + 12$ is needed: $s$ from $8$ to $20$."),
              (11, "Requires only $s < 20 < s + 12$, without room for three distinct values on each side: $s$ from $9$ to $19$.")],
  cognitive="Analysis")


def _m6():
    x, y = symbols('x y')
    s = solve([Eq(5 + 8 + x + y + 6, 50), Eq(0 * 5 + 1 * 8 + 2 * x + 3 * y + 4 * 6, Rational(24, 10) * 50)], [x, y])
    return s[y]
q("C28-A-021", T, "Missing frequencies from the total and the mean", "Medium",
  "Inverse/parameter",
  r"In a survey of $50$ households, the number of children per household was recorded. $5$ households had no children, $8$ had $1$ child, $6$ had $4$ children, and every other household had either $2$ or $3$ children. The mean number of children per household is $2.4$. How many households had exactly $3$ children?",
  "MCQ",
  r"Let $x$ and $y$ households have $2$ and $3$ children. Then $x + y = 50 - 19 = 31$. Total children $= 2.4 \times 50 = 120 = 8 + 2x + 3y + 24$, so $2x + 3y = 88$. Subtracting $2(x + y) = 62$ gives $y = 26$ (and $x = 5$).",
  "Reporting the other unknown, or dropping the zero-child households from the count used with the mean.",
  "C28A-missing-frequency-mean", "Two linear equations from count and total; the trap is the role of zero-child households.",
  correct=r"$26$",
  distractors=[(r"$5$", "Solves correctly but reports the number of households with $2$ children."),
               (r"$31$", "Reports $x + y$, the households with $2$ or $3$ children together."),
               (r"$14$", "Multiplies the mean by $45$ households, leaving out the $5$ with no children: $2x + 3y = 76$.")],
  check=_m6, values=[26, 5, 31, 14], cognitive="Application")


def _m7():
    n, sx, sxx = 13, 117, 1209
    return Fraction(sxx, n) - Fraction(sx, n) ** 2
q("C28-A-022", T, "Variance from the sum and the sum of squares", "Medium",
  "Single-step computation",
  r"For the numbers of daily orders received by a bakery on $13$ days, the sum of the $13$ numbers is $117$ and the sum of their squares is $1209$. Taking variance as the mean of the squared deviations from the mean, what is the variance of the daily orders?",
  "MCQ",
  r"Mean $= \frac{117}{13} = 9$. Mean of squares $= \frac{1209}{13} = 93$. Variance $= 93 - 9^2 = 12$.",
  "Subtracting the mean instead of its square, or dividing the sum of squared deviations by $n - 1$.",
  "C28A-moments-from-sums", "Uses the identity variance equals mean of squares minus square of mean.",
  correct=r"$12$",
  distractors=[(r"$13$", "Divides the sum of squared deviations $1209 - 13 \\times 81 = 156$ by $12$ instead of $13$."),
               (r"$84$", "Subtracts the mean, not its square: $93 - 9$."),
               (r"$93$", "Stops at the mean of the squares.")],
  check=_m7, values=[12, 13, 84, 93], cognitive="Application")


def _m8():
    return _pvar([30 + 2 * i for i in range(7)])
q("C28-A-023", T, "Variance of consecutive even numbers", "Medium",
  "Conceptual/application",
  r"The house numbers of $7$ adjacent houses on one side of a street are $7$ consecutive even numbers. Taking variance as the mean of the squared deviations from the mean, what is the variance of these $7$ house numbers?",
  "TITA",
  r"Variance does not depend on where the numbers start, only on their spacing. The deviations from the middle number are $-6, -4, -2, 0, 2, 4, 6$, with squares summing to $2(36 + 16 + 4) = 112$. Variance $= \frac{112}{7} = 16$. (Equivalently, $2^2$ times the variance $\frac{7^2 - 1}{12} = 4$ of $7$ consecutive integers.)",
  "Using the consecutive-integer variance without the factor $2^2$ for the spacing.",
  "C28A-ap-consecutive-stats", "The insight that variance is free of the starting value, plus the scaling by the common difference.",
  tita_answer=16, check=_m8,
  tita_traps=[(4, "Uses the variance of $7$ consecutive integers, forgetting the spacing of $2$."),
              (112, "Stops at the sum of squared deviations.")],
  cognitive="Analysis")


def _m9():
    r = sqrt(72)
    data = [r, -r, r, -r, r, -r, r, -r]     # mean 0, variance 72
    return _pvar(data + [Integer(0)])
q("C28-A-024", T, "Variance after adding a value equal to the mean", "Medium",
  "Conceptual/application",
  r"A set of $8$ values has variance $72$, taking variance as the mean of the squared deviations from the mean. A ninth value, equal to the mean of the original $8$ values, is added to the set. What is the variance of the $9$ values?",
  "MCQ",
  r"The new value equals the mean, so the mean is unchanged and the new value adds $0$ to the sum of squared deviations. That sum stays $8 \times 72 = 576$, now shared by $9$ values: $\frac{576}{9} = 64$.",
  "Assuming a value at the mean leaves variance unchanged, or scaling the variance the wrong way.",
  "C28A-variance-adding-values", "Needs the sum-of-squares view of variance rather than a formula.",
  correct=r"$64$",
  distractors=[(r"$72$", "Believes that adding a value equal to the mean cannot change the variance."),
               (r"$81$", "Scales the variance by $\\frac{9}{8}$ instead of $\\frac{8}{9}$."),
               (r"$63$", "Lowers the variance by $\\frac{72}{8} = 9$, using the old count.")],
  check=_m9, values=[64, 72, 81, 63], cognitive="Understanding")


def _m10():
    n = symbols('n', positive=True)
    return solve(Eq(Rational(83 - 38) / n, Rational(3, 2)), n)[0]
q("C28-A-025", T, "Class size from the effect of a mis-entered mark", "Medium",
  "Inverse/parameter",
  r"While a teacher was calculating the average mark of a class, Ravi's mark of $83$ was entered as $38$. Because of this, the average came out $1.5$ marks lower than the true average. How many students are there in the class?",
  "TITA",
  r"The entry error lowered the total by $83 - 38 = 45$ marks. That lowered the average by $\frac{45}{n} = 1.5$, so $n = 30$.",
  "Reporting the mark difference itself, or dividing in the wrong order.",
  "C28A-misrecorded-value-mean", "Reverse use of the correction: the class size is unknown.",
  tita_answer=30, check=_m10,
  tita_traps=[(45, "Reports the difference in marks as the answer."),
              (29, "Leaves Ravi out of the count after finding $n = 30$.")],
  cognitive="Application")


def _m11():
    then = None
    for c in itertools.combinations_with_replacement(range(1, 70), 5):
        if sum(c) == 125 and _pvar(list(c)) == 120:
            then = list(c)
            break
    now = [v + 6 for v in then] + [1]
    return _pvar(now)
q("C28-A-026", T, "Variance of a family's ages after ageing and a birth", "Medium",
  "Multi-step word problem",
  r"A census taken six years ago recorded the ages of the $5$ members of the Joseph family; these ages had a mean of $25$ years and a variance of $120$ years$^2$, taking variance as the mean of the squared deviations from the mean. Since then a daughter has been born, who is now $1$ year old, and there has been no other change in the family. What is the variance of the present ages of the $6$ members?",
  "MCQ",
  r"Ageing adds $6$ to each of the $5$ ages, so they now have mean $31$ and still variance $120$. With the daughter the mean is $\frac{155 + 1}{6} = 26$. The sum of squared deviations from $26$ is $5(120 + 5^2) + 25^2 = 725 + 625 = 1350$, so the variance is $\frac{1350}{6} = 225$ years$^2$.",
  "Forgetting that the original members have aged, or dividing by the old count.",
  "C28A-combined-variance", "Shift invariance of variance combined with a within-plus-between decomposition.",
  correct=r"$225$ years$^2$",
  distractors=[(r"$180$ years$^2$", "Does not age the original members: mean $\\frac{126}{6} = 21$ and $\\frac{5(120 + 16) + 400}{6}$."),
               (r"$270$ years$^2$", "Finds the sum of squared deviations $1350$ but divides by $5$."),
               (r"$120$ years$^2$", "Assumes the variance is unchanged because ageing does not change spread.")],
  check=_m11, values=[225, 180, 270, 120], cognitive="Application")


def _m12():
    rnd = random.Random(27)
    out = set()
    for _ in range(500):
        sal = [18000, 60000] + [rnd.randint(18000, 60000) for _ in range(rnd.randint(1, 40))]
        new = [Fraction(6, 5) * s if s < 30000 else s + 2000 for s in sal]
        out.add(max(new) - min(new))
    assert len(out) == 1
    return out.pop()
q("C28-A-027", T, "Range after different raises for two salary bands", "Medium",
  "Multi-step word problem",
  r"In an office, the lowest monthly salary is Rs. $18{,}000$ and the highest is Rs. $60{,}000$. Every employee earning less than Rs. $30{,}000$ receives a raise of $20\%$, and every employee earning Rs. $30{,}000$ or more receives a raise of Rs. $2{,}000$. What is the range of the monthly salaries after the raises?",
  "MCQ",
  r"Salaries below $30{,}000$ become at most $1.2 \times 30{,}000 = 36{,}000$, and the rest become at least $32{,}000$, so the order of the extremes is kept: the lowest becomes $1.2 \times 18{,}000 = 21{,}600$ and the highest becomes $62{,}000$. The new range is $62{,}000 - 21{,}600 = 40{,}400$.",
  "Assuming the range is unchanged, or applying one band's raise to the other band's extreme.",
  "C28A-range-piecewise-change", "Track the two extremes through different raises and confirm they stay the extremes.",
  correct=r"Rs. $40{,}400$",
  distractors=[(r"Rs. $42{,}000$", "Assumes raises cannot change the range: $60{,}000 - 18{,}000$."),
               (r"Rs. $44{,}000$", "Raises the highest salary but forgets the raise of the lowest: $62{,}000 - 18{,}000$."),
               (r"Rs. $50{,}400$", "Applies the $20\\%$ raise to the old range: $1.2 \\times 42{,}000$.")],
  check=_m12, values=[40400, 42000, 44000, 50400], cognitive="Application")


def _m13():
    best = 0
    for low in itertools.combinations(range(1, 14), 3):
        for up in itertools.combinations(range(15, 140), 2):
            g = 140 - sum(low) - 14 - sum(up)
            if g > up[-1]:
                best = max(best, up[-1])
    return best
q("C28-A-028", T, "Largest possible second-highest value given mean and median of distinct integers", "Medium",
  "Casework/optimisation",
  r"Seven distinct positive integers have a mean of $20$ and a median of $14$. What is the largest possible value of the second greatest of these integers?",
  "MCQ",
  r"The total is $7 \times 20 = 140$. Keep everything else as small as possible: the three values below the median are $1, 2, 3$, the median is $14$, and the $5$th value must exceed $14$, so it is at least $15$. The top two then add up to at most $140 - (1 + 2 + 3 + 14 + 15) = 105$. Since the greatest must exceed the second greatest, the second greatest is at most $52$, and $1, 2, 3, 14, 15, 52, 53$ achieves it.",
  "Ignoring that the value just above the median must exceed it, or that the top two must be distinct.",
  "C28A-extreme-value-optimise", "Optimisation in which the median and distinctness conditions both bind on the upper values.",
  correct=r"$52$",
  distractors=[(r"$53$", "Builds the optimal set but reports the greatest value instead of the second greatest."),
               (r"$54$", "Ignores distinctness throughout: $1, 1, 1, 14, 14$ leaves $109$ for the top two, so the second greatest is at most $54$."),
               (r"$49$", "Believes every value above the median must be at least the mean $20$, so sets the $5$th value to $20$; the top two then add up to at most $100$ and the second greatest is at most $49$.")],
  check=_m13, values=[52, 53, 54, 49], exams=HARD, cognitive="Analysis")


def _m14():
    base = [7, 9, 11, 18, 22, 25]
    return len({_med(base + [x]) for x in range(1, 500)})
q("C28-A-029", T, "Number of possible medians with one unknown value", "Medium",
  "Casework/optimisation",
  r"The numbers of runs scored by the $7$ batters of a team in a match are $7$, $9$, $11$, $18$, $22$, $25$ and $x$, where $x$ is a positive integer (it may equal one of the other numbers). The median is the middle ($4$th) value when all $7$ numbers are arranged in increasing order. How many different values can the median of the $7$ numbers take as $x$ varies?",
  "TITA",
  r"Without $x$, the six known numbers in order are $7, 9, 11, 18, 22, 25$, and the median of the seven is their $4$th value. If $x \le 11$, the $4$th value is $11$. If $11 \le x \le 18$, the $4$th value is $x$ itself. If $x \ge 18$, the $4$th value is $18$. So the median can be any integer from $11$ to $18$: $8$ values.",
  "Counting only the values strictly between $11$ and $18$, or only the two end cases.",
  "C28A-median-count-cases", "Casework on the position of the unknown relative to the middle values.",
  tita_answer=8, check=_m14,
  tita_traps=[(6, "Counts only $12$ to $17$, missing the end values $11$ and $18$."),
              (2, "Considers only $x$ very small or very large, giving medians $11$ and $18$.")],
  exams=HARD, cognitive="Analysis")


def _m15():
    base = [4, 9, 13]
    sols = {x + y for x in range(1, 150) for y in range(x, 150)
            if _umode(base + [x, y]) == 9 and _mean(base + [x, y]) == _med(base + [x, y]) + 1}
    assert len(sols) == 1
    return sols.pop()
q("C28-A-030", T, "Two unknowns from mode, median and mean conditions", "Medium",
  "Casework/optimisation",
  r"Five positive integers are $4$, $9$, $13$, $x$ and $y$. Their only mode is $9$, and their mean is $1$ more than their median. What is the value of $x + y$?",
  "MCQ",
  r"For $9$ to be the only mode, one of $x, y$ must be $9$; say $x = 9$. If $y = 9$ too, the mean is $\frac{44}{5}$ while the median is $9$, which fails. Otherwise $y \ne 4, 13$ (that would tie with $9$), and in the list $4, 9, 9, 13, y$ two $9$s sit in the middle positions whatever $y$ is, so the median is $9$. The mean must be $10$, so $35 + y = 50$ and $y = 15$. Hence $x + y = 24$.",
  "Ignoring the extra $1$, or reading the median off the unsorted list.",
  "C28A-mean-median-mode-unknowns", "Combines a mode argument with a median-mean equation.",
  correct=r"$24$",
  distractors=[(r"$19$", "Sets the mean equal to the median $9$: total $45$."),
               (r"$18$", "Makes both unknowns $9$ to secure the mode."),
               (r"$44$", "Takes the median as $13$, the middle entry of the listed numbers, so the mean is $14$ and the total $70$.")],
  check=_m15, values=[24, 19, 18, 44], exams=HARD, cognitive="Analysis")


def _m16():
    rnd = random.Random(28)
    seen = set()
    for _ in range(3000):
        pool = [v for v in range(1, 120) if v not in (33, 38, 40, 44, 51)]
        lo = rnd.sample([v for v in pool if v < 40], 7)
        hi = rnd.sample([v for v in pool if v > 40], 7)
        data = lo + [40] + hi
        assert _med(data) == 40
        seen.add(_med(data + [33, 38, 44, 51]))
    assert len(seen) == 1
    return seen.pop()
q("C28-A-031", T, "Median after adding two values on each side", "Medium",
  "Conceptual/application",
  r"The median of $15$ distinct numbers is $40$. Four new numbers, $33$, $38$, $44$ and $51$, none of which is in the original set, are added to it. What is the median of the $19$ numbers?",
  "MCQ",
  r"In the original set, $7$ numbers are below $40$ and $7$ are above. Two new numbers ($33$, $38$) are below $40$ and two ($44$, $51$) are above, so in the new set $9$ numbers are below $40$ and $9$ are above. The $10$th of the $19$ numbers is still $40$.",
  "Mixing the median of the added numbers or their mean into the answer.",
  "C28A-median-after-insertion", "Positional reasoning about the median without knowing the data.",
  correct=r"$40$",
  distractors=[(r"$41$", "Reports the median of the four added numbers, $\\frac{38 + 44}{2}$."),
               (r"$40.5$", "Averages the old median $40$ with the median $41$ of the added numbers."),
               (r"$41.5$", "Reports the mean of the four added numbers, $\\frac{166}{4}$.")],
  check=_m16, values=[40, 41, Fraction(81, 2), Fraction(83, 2)], cognitive="Understanding")


def _m17():
    a, b = symbols('a b')
    s = solve([Eq(48 * a + b, 60), Eq(12 * a, 9)], [a, b])
    return s[a] * 72 + s[b]
q("C28-A-032", T, "Rescaled score via a linear transformation", "Medium",
  "Inverse/parameter",
  r"The raw scores in an aptitude test have mean $48$ and standard deviation $12$. Each raw score $x$ is converted to a scaled score $y = ax + b$, where $a > 0$, so that the scaled scores have mean $60$ and standard deviation $9$. What is the scaled score of a candidate whose raw score is $72$?",
  "MCQ",
  r"The raw score $72$ is $\frac{72 - 48}{12} = 2$ standard deviations above the mean. A linear map with $a > 0$ preserves this, so the scaled score is $2$ new standard deviations above the new mean: $60 + 2 \times 9 = 78$. (Here $a = \frac{3}{4}$ and $b = 24$.)",
  "Rescaling with the wrong factor, or shifting the mean without rescaling.",
  "C28A-shift-scale-spread", "Finding the transformation from two moments, best done through standard scores.",
  correct=r"$78$",
  distractors=[(r"$84$", "Shifts by the difference of means only, $72 + 12$, keeping the old spread."),
               (r"$92$", "Uses the inverted factor $a = \\frac{4}{3}$: $60 + \\frac{4}{3} \\times 24$."),
               (r"$66$", "Takes $a = \\frac{3}{4}$ but $b = 60 - 48 = 12$: $\\frac{3}{4} \\times 72 + 12$.")],
  check=_m17, values=[78, 84, 92, 66], cognitive="Application")


def _m18():
    good = 0
    for f in range(0, 200):
        table = {1: 6, 2: 10, 3: f, 4: 9, 5: 5}
        data = [v for v, k in table.items() for _ in range(k)]
        if _med(data) == 3 and _umode(data) == 2:
            good += 1
    return good
q("C28-A-033", T, "Range of an unknown frequency under median and mode conditions", "Medium",
  "Casework/optimisation",
  r"In a quiz, each student needed between $1$ and $5$ attempts to solve a puzzle. $6$ students needed $1$ attempt, $10$ needed $2$, $f$ needed $3$, $9$ needed $4$ and $5$ needed $5$. The median number of attempts is $3$ and the only mode is $2$. How many values of $f$ are possible?",
  "MCQ",
  r"For $2$ to be the only mode, $f \le 9$. There are $30 + f$ students and $16$ of them needed at most $2$ attempts. For the median to be $3$, the middle position(s) must fall among positions $17$ to $16 + f$. If $f = 2$, $n = 32$ and the $16$th and $17$th values are $2$ and $3$, giving median $2.5$; if $f = 3$, $n = 33$ and the $17$th value is $3$. Larger $f$ only adds more $3$s around the middle. So $f = 3, 4, \ldots, 9$: $7$ values.",
  "Allowing a tie for the mode, or mishandling the even-total median.",
  "C28A-frequency-table-median", "Two conditions on one unknown frequency, with boundary checks at both ends.",
  correct=r"$7$",
  distractors=[(r"$8$", "Allows $f = 10$, when $2$ and $3$ would tie as modes."),
               (r"$9$", "Allows both $f = 2$ (median $2.5$) and $f = 10$ (tied mode)."),
               (r"$6$", "Places the median at position $\\frac{n}{2}$ rounded down, which rejects $f = 3$.")],
  check=_m18, values=[7, 8, 9, 6], exams=HARD, cognitive="Analysis")


def _m19():
    n, m = symbols('n m', positive=True)
    s = solve([Eq(n * (m - 25), 40), Eq(n * (m - 30), -60)], [n, m], dict=True)[0]
    return s[n]
q("C28-A-034", T, "Number of observations from sums of deviations about two values", "Medium",
  "Conceptual/application",
  r"A coach recorded a number of sprint timings. The sum of the deviations of the timings from $25$ seconds is $40$ seconds, and the sum of their deviations from $30$ seconds is $-60$ seconds (each deviation being the timing minus the reference value). How many timings were recorded?",
  "MCQ",
  r"If there are $n$ timings with sum $S$, then $S - 25n = 40$ and $S - 30n = -60$. Subtracting, $5n = 100$, so $n = 20$ (and the mean is $25 + \frac{40}{20} = 27$ seconds).",
  "Adding the two sums with their signs, or not dividing by the gap between the reference values.",
  "C28A-sum-of-deviations", "Uses the linearity of deviation sums in the reference value.",
  correct=r"$20$",
  distractors=[(r"$4$", "Drops the minus sign on the second sum and subtracts: $\\frac{60 - 40}{5}$."),
               (r"$100$", "Finds $40 - (-60) = 100$ but does not divide by $30 - 25$."),
               (r"$8$", "Divides only the first sum by the gap: $\\frac{40}{5}$.")],
  check=_m19, values=[20, 4, 100, 8], cognitive="Analysis")


def _m20():
    best = -1
    for a in range(1, 33):
        for b in range(a, 33):
            for d in range(32, 151):
                e = 150 - a - b - 32 - d
                if e < d:
                    break
                data = [a, b, 32, d, e]
                if _umode(data) == 35 and _med(data) == 32:
                    best = max(best, e - a)
    return best
q("C28-A-035", T, "Maximum range under mean, median and mode conditions", "Difficult",
  "Casework/optimisation",
  r"Five positive integers have a mean of $30$, a median of $32$, and a single mode equal to $35$. What is the largest possible range of the five integers?",
  "TITA",
  r"Since $35$ is the only mode it appears at least twice, and since it exceeds the median, it must be the $4$th and $5$th values. The total is $150$, so the two smallest values add up to $150 - 32 - 70 = 48$. Both are at most $32$; neither can equal $32$ (that would make $32$ appear twice and tie with $35$), and they cannot both be $24$. To maximise the range $35 - a$, take the second value as large as possible, $31$, so $a = 17$ and the range is $35 - 17 = 18$.",
  "Allowing the second value to equal the median, which creates a second mode.",
  "C28A-range-optimise", "Three interacting conditions: the unique mode must be placed above the median as the top two values, and then the uniqueness of the mode rules out the obvious boundary choice of repeating the median.",
  tita_answer=18, check=_m20,
  tita_traps=[(19, "Lets the second value be $32$, making $32$ a second mode: $a = 16$."),
              (34, "Ignores the median constraint on the second value and takes $a = 1$.")],
  exams=HARD, cognitive="Analysis")


def _m21():
    sets = [[3, 3, 9, 15, 15], [1, 9, 9, 9, 17], [5, 7, 9, 11, 13], [103, 106, 109, 112, 115]]
    v = [_pvar(s) for s in sets]
    assert v[0] == max(v)
    return v[0]
q("C28-A-036", T, "Comparing spreads of data sets without full computation", "Medium",
  "Conceptual/application",
  r"Which of the following data sets has the largest standard deviation?",
  "MCQ",
  r"Compare the squared deviations from each mean. For $3, 3, 9, 15, 15$ (mean $9$) they sum to $4 \times 36 = 144$. For $1, 9, 9, 9, 17$ (mean $9$) they sum to $2 \times 64 = 128$, despite the larger range. For $5, 7, 9, 11, 13$ the sum is $40$, and for $103, 106, 109, 112, 115$ it is $90$; large values do not mean large spread. All sets have $5$ values, so $3, 3, 9, 15, 15$ has the largest standard deviation.",
  "Judging spread by the range or by the size of the numbers.",
  "C28A-spread-comparison", "Requires judging spread from deviations, not from range or magnitude.",
  correct=r"$3, 3, 9, 15, 15$",
  distractors=[(r"$1, 9, 9, 9, 17$", "Chooses the set with the largest range ($16$)."),
               (r"$5, 7, 9, 11, 13$", "Chooses the evenly spread set, assuming even spacing maximises dispersion."),
               (r"$103, 106, 109, 112, 115$", "Chooses the set with the largest values.")],
  check=_m21, values=[Fraction(144, 5), Fraction(128, 5), 8, 18], cognitive="Analysis")


def _m22():
    rnd = random.Random(7)
    out = set()
    for _ in range(2000):
        s = sorted(rnd.sample(range(1, 200), 9))
        t = [s[0] - 6] + s[1:-1] + [s[-1] + 6]
        dm = _mean(t) - _mean(s)
        dv = _pvar(t) - _pvar(s)
        out.add((int(sign(dm)), int(sign(dv))))
    assert len(out) == 1
    return out.pop()
q("C28-A-037", T, "Effect on mean and SD of pushing both extremes outward", "Medium",
  "Conceptual/application",
  r"In a set of $9$ distinct numbers, the smallest number is decreased by $6$ and the largest number is increased by $6$; the other numbers are unchanged. Which statement about the new set, compared with the original set, is true?",
  "MCQ",
  r"The total is unchanged ($-6 + 6 = 0$), so the mean stays the same. The smallest value moves further below the mean and the largest further above it, so both squared deviations grow while the others are unchanged; the standard deviation increases.",
  "Treating balanced changes as leaving every measure unchanged.",
  "C28A-spread-comparison", "Separates the effect of balanced changes on location and on spread.",
  correct=r"The mean is unchanged and the standard deviation increases.",
  distractors=[(r"The mean is unchanged and the standard deviation is unchanged.", "Assumes that changes which cancel in the total also cancel in the spread."),
               (r"The mean increases and the standard deviation increases.", "Thinks the increase of the largest value dominates the mean."),
               (r"The mean is unchanged and the standard deviation decreases.", "Gets the direction of the change in spread backwards.")],
  check=_m22, values=[(0, 1), (0, 0), (1, 1), (0, -1)], cognitive="Understanding")


# ---------------------------------------------------------------- DIFFICULT

def _d1():
    r12 = sqrt(12)
    p = [20 - r12] * 5 + [20 + r12] * 5           # 10 values, mean 20, variance 12
    # 15 values, mean 30, variance 2: spread d with 14 d^2 / 15 = 2
    d = sqrt(Rational(30, 14))
    qq = [30 - d] * 7 + [30 + d] * 7 + [Integer(30)]
    assert simplify(_pvar(qq) - 2) == 0 and simplify(_pvar(p) - 12) == 0
    return simplify(_pvar(p + qq))
q("C28-A-038", T, "Combined variance of two groups", "Difficult",
  "Multi-step word problem",
  r"In a test, section P has $10$ students with mean score $20$ and variance $12$, and section Q has $15$ students with mean score $30$ and variance $2$. Taking variance as the mean of the squared deviations from the mean, what is the variance of the scores of all $25$ students taken together?",
  "MCQ",
  r"The combined mean is $\frac{10(20) + 15(30)}{25} = 26$. Each section's sum of squared deviations from $26$ is $n(\text{variance} + d^2)$, where $d$ is the distance of its mean from $26$: P gives $10(12 + 36) = 480$ and Q gives $15(2 + 16) = 270$. The combined variance is $\frac{480 + 270}{25} = 30$.",
  "Combining only the within-section variances and ignoring the spread between the section means.",
  "C28A-combined-variance", "Needs the decomposition of variance into within-group and between-group parts.",
  correct=r"$30$",
  distractors=[(r"$6$", "Takes the weighted mean of the two variances, $\\frac{10(12) + 15(2)}{25}$, ignoring the different means."),
               (r"$7$", "Takes the simple average of the variances, $\\frac{12 + 2}{2}$."),
               (r"$31$", "Adds the correct between-group part $24$ to the simple average $7$ of the variances.")],
  check=_d1, values=[30, 6, 7, 31], exams=HARD, cognitive="Analysis")


def _d2():
    n, m, v = 10, 20, 9
    sx = n * m - 15 + 25
    sxx = n * (v + m * m) - 15 ** 2 + 25 ** 2
    return Fraction(sxx, n) - Fraction(sx, n) ** 2
q("C28-A-039", T, "Correcting mean and variance after a mis-recorded value", "Difficult",
  "Multi-step word problem",
  r"The mean and variance of $10$ observations were calculated as $20$ and $9$ respectively, taking variance as the mean of the squared deviations from the mean. It was later found that one observation, $25$, had been recorded as $15$. What is the correct variance of the $10$ observations?",
  "MCQ",
  r"Recorded sums: $\sum x = 200$ and $\sum x^2 = 10(9 + 400) = 4090$. Correcting: $\sum x = 200 - 15 + 25 = 210$ and $\sum x^2 = 4090 - 225 + 625 = 4490$. The correct mean is $21$, and the correct variance is $\frac{4490}{10} - 21^2 = 449 - 441 = 8$.",
  "Correcting the sum of squares but keeping the old mean, or patching the variance with the squared difference.",
  "C28A-misrecorded-value-variance", "Requires rebuilding both raw sums, then recomputing the variance with the new mean.",
  correct=r"$8$",
  distractors=[(r"$9$", "Assumes one corrected value cannot change the variance."),
               (r"$49$", "Corrects $\\sum x^2$ to $4490$ but subtracts the old mean squared: $449 - 400$."),
               (r"$19$", "Adds the squared correction $(25 - 15)^2 = 100$ to the sum of squared deviations $90$ and divides by $10$.")],
  check=_d2, values=[8, 9, 49, 19], exams=HARD, cognitive="Analysis")


def _d3():
    return sum(1 for s in itertools.combinations(range(1, 40), 5) if sum(s) == 30 and s[2] == 5)
q("C28-A-040", T, "Counting sets of distinct integers with given mean and median", "Difficult",
  "Casework/optimisation",
  r"How many sets of $5$ distinct positive integers have a mean of $6$ and a median of $5$?",
  "TITA",
  r"Write the set as $a < b < 5 < d < e$ with $a + b + d + e = 30 - 5 = 25$. The pair $(a, b)$ comes from $\{1, 2, 3, 4\}$: sums $3, 4, 5, 5, 6, 7$ for the six pairs. Then $d + e = 25 - (a + b)$ with $6 \le d < e$: for $d + e = 22$ or $21$ there are $5$ choices of $d$ ($6$ to $10$), for $20$ or $19$ there are $4$ ($6$ to $9$), and for $18$ there are $3$. Total: $5 + 5 + 4 + 4 + 4 + 3 = 25$.",
  "Forgetting that the sum $5$ arises from two different pairs, or allowing $d = e$.",
  "C28A-count-sets-mean-median", "Systematic two-level counting under order and distinctness.",
  tita_answer=25, check=_d3,
  tita_traps=[(21, "Counts the pair sum $5$ only once, missing $4$ sets."),
              (6, "Counts only the choices for the two smallest numbers.")],
  exams=HARD, cognitive="Analysis")


def _d4():
    lower_sums = {sum(c) for c in itertools.combinations(range(0, 50), 4)}
    best_for_sum = {}
    for c in itertools.combinations(range(51, 101), 4):
        s = sum(c)
        if s not in best_for_sum or c[-1] < best_for_sum[s]:
            best_for_sum[s] = c[-1]
    best = None
    for L in lower_sums:
        U = 540 - 50 - L
        if U in best_for_sum:
            m = best_for_sum[U]
            best = m if best is None else min(best, m)
    return best
q("C28-A-041", T, "Smallest possible top score given mean and median", "Difficult",
  "Casework/optimisation",
  r"Nine students scored distinct integer marks, each between $0$ and $100$ inclusive, in a test. The mean of the nine marks is $60$ and the median is $50$. What is the smallest possible value of the highest mark?",
  "TITA",
  r"The total is $540$. Four marks are below $50$, at most $46 + 47 + 48 + 49 = 190$, so the four marks above $50$ add up to at least $540 - 50 - 190 = 300$. Four distinct integers with largest value $M$ add up to at most $M + (M - 1) + (M - 2) + (M - 3) = 4M - 6$, so $4M - 6 \ge 300$, $M \ge 76.5$, hence $M \ge 77$. The marks $46, 47, 48, 49, 50, 73, 74, 76, 77$ achieve it.",
  "Ignoring distinctness of the top four, or rounding the bound down.",
  "C28A-extreme-value-optimise", "Two-sided optimisation: push the lower half up and the upper half together, then round correctly.",
  tita_answer=77, check=_d4,
  tita_traps=[(75, "Averages the required $300$ over four marks without making them distinct."),
              (76, "Rounds the bound $76.5$ down.")],
  exams=HARD, cognitive="Analysis")


def _d5():
    best = None
    for low in itertools.combinations_with_replacement(range(1, 19), 3):
        for e in range(18, 106):
            for f in range(e, 106):
                g = 105 - sum(low) - 18 - e - f
                if g < f:
                    break
                s = list(low) + [18, e, f, g]
                if _umode(s) != 20:
                    continue
                r = max(s) - min(s)
                best = r if best is None else min(best, r)
    return best
q("C28-A-042", T, "Minimum range under mean, median and unique mode", "Difficult",
  "Casework/optimisation",
  r"Seven positive integers have a mean of $15$, a median of $18$, and a single mode equal to $20$. What is the smallest possible range of the seven integers?",
  "MCQ",
  r"The total is $105$. The mode $20$ exceeds the median, so it lies among the top three values. If $20$ appears twice, the remaining top value is at least $19$ (an $18$ would tie with $20$ as a mode) and the three lowest add up to at most $105 - 18 - 19 - 40 = 28$; no lower value may repeat, so the smallest is at most $8$ ($8, 9, 11$). If $20$ appears three times, the three lowest add up to $105 - 18 - 60 = 27$; $9, 9, 9$ would tie with $20$ as a mode, so the smallest is at most $8$ ($8, 9, 10$). In every case the smallest value is at most $8$ while the largest is at least $20$, and $8, 9, 10, 18, 20, 20, 20$ reaches range $20 - 8 = 12$.",
  "Overlooking that three equal small values would create a second mode.",
  "C28A-range-optimise", "Casework on how often the mode occurs, with the uniqueness condition cutting off the natural optimum.",
  correct=r"$12$",
  distractors=[(r"$11$", "Uses $9, 9, 9, 18, 20, 20, 20$, where $9$ and $20$ tie as modes."),
               (r"$6$", "Leaves the median out of the total: the three lowest add up to $105 - 60 = 45$, giving $14, 15, 16$ and range $20 - 14$."),
               (r"$8$", "Finds the optimal set but reports its smallest value instead of the range.")],
  check=_d5, values=[12, 11, 6, 8], exams=HARD, cognitive="Analysis")


def _d6():
    base = [4, 8, 15, 23]
    return sum(1 for x in range(1, 51) if _mean(base + [x]) > _med(base + [x]))
q("C28-A-043", T, "Counting values of an unknown for which mean exceeds median", "Difficult",
  "Casework/optimisation",
  r"Five numbers are $4$, $8$, $15$, $23$ and $x$, where $x$ is an integer from $1$ to $50$ inclusive. For how many values of $x$ is the mean of the five numbers greater than their median?",
  "TITA",
  r"The mean is $\frac{50 + x}{5}$. If $x \le 8$, the median is $8$ and we need $50 + x > 40$, true for all $x = 1$ to $8$: $8$ values. If $8 < x < 15$, the median is $x$ and we need $50 + x > 5x$, that is $x < 12.5$: $x = 9$ to $12$, $4$ values. If $x \ge 15$, the median is $15$ and we need $50 + x > 75$, that is $x > 25$: $x = 26$ to $50$, $25$ values. Total $8 + 4 + 25 = 37$.",
  "Forgetting the middle case where $x$ itself is the median.",
  "C28A-median-count-cases", "Three-way casework on the median with an inequality in each case.",
  tita_answer=37, check=_d6,
  tita_traps=[(25, "Considers only large values of $x$."),
              (33, "Misses the middle case $9 \\le x \\le 12$ where $x$ is the median.")],
  exams=HARD, cognitive="Analysis")


def _d7():
    m, v = symbols('m v')
    s = solve([Eq(v + (m - 2) ** 2, 109), Eq(v + (m - 4) ** 2, 73)], [m, v], dict=True)
    assert len(s) == 1
    data = [9] * 15 + [15] * 15                      # 30 days, mean 12, variance 9
    assert _mean([(x - 2) ** 2 for x in data]) == 109 and _mean([(x - 4) ** 2 for x in data]) == 73
    return sqrt(Rational(_pvar(data)))
q("C28-A-044", T, "Standard deviation from mean squared deviations about two reference values", "Medium",
  "Inverse/parameter",
  r"For the noon temperatures recorded at a weather station on $30$ days, the mean of the squared deviations of the temperatures from $2^\circ$C is $109$ $(^\circ\text{C})^2$, and the mean of their squared deviations from $4^\circ$C is $73$ $(^\circ\text{C})^2$. Taking variance as the mean of the squared deviations from the mean, what is the standard deviation of the temperatures?",
  "MCQ",
  r"For any value $a$, the mean of $(x - a)^2$ equals the variance $v$ plus $(m - a)^2$, where $m$ is the mean. So $v + (m - 2)^2 = 109$ and $v + (m - 4)^2 = 73$. Subtracting, $(m - 2)^2 - (m - 4)^2 = 4m - 12 = 36$, so $m = 12$. Then $v = 109 - 10^2 = 9$, and the standard deviation is $3^\circ$C.",
  "Subtracting the two given means directly, or reporting the variance or the mean instead of the standard deviation.",
  "C28A-moments-from-sums", "One identity, mean of squared deviations about $a$ equals variance plus $(m - a)^2$, written twice and solved by one subtraction: a heavy Medium.",
  correct=r"$3^\circ$C",
  distractors=[(r"$6^\circ$C", "Treats $109 - 73 = 36$ as the variance and takes its square root."),
               (r"$9^\circ$C", "Finds the variance $9$ and reports it as the standard deviation."),
               (r"$12^\circ$C", "Reports the mean temperature found on the way.")],
  check=_d7, values=[3, 6, 9, 12], exams=HARD, cognitive="Analysis")


def _d8():
    from functools import lru_cache
    import bisect

    @lru_cache(None)
    def best(state):
        k = len(state)
        if k == 9:
            return 0
        target = 18 + 2 * (k + 1)
        res = None
        for x in range(0, 101):
            s = list(state)
            bisect.insort(s, x)
            s = tuple(s)
            if _med(s) != target:
                continue
            r = best(s)
            if r is not None and (res is None or r + x < res):
                res = r + x
        return res
    return 20 + best((20,))
q("C28-A-045", T, "Least total of readings when the running median rises steadily", "Difficult",
  "Casework/optimisation",
  r"A humidity sensor logs $9$ readings one at a time, each a whole-number percentage from $0$ to $100$, and its display shows the median of all the readings logged so far. The first reading is $20$, and after each later reading the displayed median is exactly $2$ more than the median displayed just before it. What is the smallest possible sum of the $9$ readings?",
  "TITA",
  r"The displayed medians are $20, 22, 24, \ldots, 36$. After an odd number of readings the median is itself a reading, so $20$, $24$, $28$ and $32$ (the medians after $1$, $3$, $5$ and $7$ readings) are all readings. After $9$ readings the median, the $5$th value, is $36$, so these four readings are exactly the four values below it and the other five readings are each at least $36$. The sum is at least $20 + 24 + 28 + 32 + 5 \times 36 = 284$, and the order $20, 24, 28, 32, 36, 36, 36, 36, 36$ gives the medians $20, 22, \ldots, 36$, so $284$ is achieved.",
  "Adding the displayed medians, or assuming the readings themselves rise in equal steps.",
  "C28A-running-median", "Non-obvious model: odd-step medians are actual readings, which fixes the lower half and bounds the upper half.",
  tita_answer=284, check=_d8,
  tita_traps=[(252, "Adds the nine displayed medians, $20 + 22 + \\cdots + 36$."),
              (324, "Assumes the readings are $20, 24, 28, \\ldots, 52$, rising by $4$ each time.")],
  exams=HARD, cognitive="Analysis")


def _d9():
    base = [3, 5, 8, 8, 12]
    return sum(1 for x in range(1, 200) for y in range(x + 1, 200)
               if _umode(base + [x, y]) == 8 and _mean(base + [x, y]) == _med(base + [x, y]) + 1)
q("C28-A-046", T, "Counting pairs of unknowns under mode and mean-median conditions", "Difficult",
  "Casework/optimisation",
  r"Seven positive integers are $3$, $5$, $8$, $8$, $12$, $x$ and $y$, where $x < y$. The only mode of the seven integers is $8$, and their mean is $1$ more than their median. How many pairs $(x, y)$ are possible?",
  "MCQ",
  r"Since $3, 5, 8, 8$ are always among the values, the median (the $4$th value) is at most $8$. If the median is $m$, the total is $7(m + 1)$, so $x + y = 7m - 29$, which forces $5 \le m \le 8$. Case $m = 8$: $x + y = 27$ with $x \le 13$; the median is $8$ for every such pair, but $x = 3, 5, 12$ would create a second mode, leaving $13 - 3 = 10$ pairs. Case $m = 5$: $x + y = 6$; $(1, 5)$ ties $5$ with $8$, while $(2, 4)$ gives $2, 3, 4, 5, 8, 8, 12$ with median $5$ and mean $6$: valid. Cases $m = 6, 7$ need $6$ or $7$ to be the $4$th value: $(6, 7)$ gives median $7$ and $(7, 13)$ gives median $8$, so both fail. Total $10 + 1 = 11$.",
  "Missing the case with median $5$, or not excluding pairs that create a second mode.",
  "C28A-mean-median-mode-unknowns", "Two-level casework on the median, with mode uniqueness pruning each case.",
  correct=r"$11$",
  distractors=[(r"$10$", "Finds only the median $8$ case."),
               (r"$13$", "Finds only the median $8$ case and keeps the pairs that make a second mode."),
               (r"$15$", "Finds both cases but keeps every pair that creates a second mode.")],
  check=_d9, values=[11, 10, 13, 15], exams=HARD, cognitive="Analysis")


def _d10():
    data = [26] * 5 + [34] * 5           # mean 30, variance 16
    assert _mean(data) == 30 and _pvar(data) == 16
    return _pvar(data + [26, 46])
q("C28-A-047", T, "Variance after adding two values that shift the mean", "Difficult",
  "Multi-step word problem",
  r"A set of $10$ values has mean $30$ and variance $16$, taking variance as the mean of the squared deviations from the mean. Two more values, $26$ and $46$, are added to the set. What is the variance of the $12$ values?",
  "MCQ",
  r"The new mean is $\frac{300 + 26 + 46}{12} = 31$. About $31$, the original $10$ values have sum of squared deviations $10(16 + 1^2) = 170$, since their own mean is $1$ away. The new values add $5^2 + 15^2 = 250$. The total is $420$, so the variance is $\frac{420}{12} = 35$.",
  "Measuring deviations from the old mean, ignoring the shift of the original values, or dividing by the old count.",
  "C28A-variance-adding-values", "The mean moves, so the original values' squared deviations must be re-based before adding the new ones.",
  correct=r"$35$",
  distractors=[(r"$36$", "Keeps the old mean $30$ for all deviations: $\\frac{160 + 16 + 256}{12}$."),
               (r"$42$", "Finds the correct sum $420$ but divides by the old count $10$."),
               (r"$30$", "Takes the weighted mean of the old variance $16$ and the variance $100$ of the two new values, $\\frac{10(16) + 2(100)}{12}$, ignoring the gap between their means.")],
  check=_d10, values=[35, 36, 42, 30], exams=HARD, cognitive="Analysis")


def _d11():
    base = [5, 9, 14]
    return sum(x for x in range(1, 500) if _mean(base + [x, 2 * x]) == _med(base + [x, 2 * x]))
q("C28-A-048", T, "Values of an unknown appearing twice in scaled form, mean equals median", "Difficult",
  "Casework/optimisation",
  r"Five numbers are $5$, $9$, $14$, $x$ and $2x$, where $x$ is a positive integer. The mean of the five numbers equals their median. What is the sum of all possible values of $x$?",
  "TITA",
  r"The mean is $\frac{28 + 3x}{5}$, which must equal the median. The median is one of $5, 9, 14, x, 2x$, depending on the order. A median of $9$ needs $28 + 3x = 45$, which has no integer solution. Median $x$ needs $28 + 3x = 5x$, $x = 14$; then the set $5, 9, 14, 14, 28$ has median $14 = x$: valid. Median $2x$ needs $28 + 3x = 10x$, $x = 4$; the set $4, 5, 8, 9, 14$ has median $8 = 2x$: valid. Median $14$ needs $x = 14$, already found; median $5$ needs $x = -1$: invalid. The possible values are $4$ and $14$, with sum $18$.",
  "Checking only the case where $x$ is the median, or not verifying the order in each case.",
  "C28A-mean-equals-median-unknown", "Casework on which of five values is the median, with each candidate verified against the actual order.",
  tita_answer=18, check=_d11,
  tita_traps=[(14, "Finds only the case where $x$ is the median."),
              (4, "Finds only the case where $2x$ is the median.")],
  exams=HARD, cognitive="Analysis")


def _d12():
    need = 12 * 80 - 8 * 72
    best = None
    for c in itertools.combinations(range(60, 101), 4):
        if sum(c) >= need:
            best = c[0] if best is None else min(best, c[0])
    return best
q("C28-A-049", T, "Minimum lowest score of distinct remaining tests for a target average", "Difficult",
  "Casework/optimisation",
  r"Fatima has taken $8$ tests with an average of $72$ marks. She has $4$ tests left, each marked out of $100$, and her marks in these $4$ tests will be distinct integers. She wants her average over all $12$ tests to be at least $80$. What is the least possible value of her lowest mark among the $4$ remaining tests?",
  "MCQ",
  r"She needs at least $12 \times 80 = 960$ marks in all and has $8 \times 72 = 576$, so the last $4$ tests must give at least $384$. The other three tests can give at most $100 + 99 + 98 = 297$ (distinct marks), so the lowest of the four must be at least $384 - 297 = 87$, and $87, 98, 99, 100$ achieves it.",
  "Allowing three perfect scores, or stopping at the average needed.",
  "C28A-target-average", "Optimisation with a cap and a distinctness constraint on top of the target total.",
  correct=r"$87$",
  distractors=[(r"$84$", "Allows the other three tests to be $100$ each: $384 - 300$."),
               (r"$96$", "Reports the average needed over the $4$ tests, $\\frac{384}{4}$."),
               (r"$64$", "Reports the shortfall of the first $8$ tests, $8 \\times (80 - 72)$.")],
  check=_d12, values=[87, 84, 96, 64], exams=HARD, cognitive="Analysis")


def _d13():
    best = None
    for s in itertools.combinations_with_replacement(range(-20, 60), 2):
        a, b = s
        if b > 13:
            continue
        for d in range(13, 60):
            e = 50 - 13 - a - b - d
            if e < d:
                continue
            v = _pvar([a, b, 13, d, e])
            best = v if best is None else min(best, v)
    return best
q("C28-A-050", T, "Minimum variance of integers with given mean and median", "Difficult",
  "Casework/optimisation",
  r"Five integers have a mean of $10$ and a median of $13$. Taking variance as the mean of the squared deviations from the mean, what is the smallest possible variance of the five integers?",
  "MCQ",
  r"The total is $50$. The two values above the median are at least $13$, so each contributes at least $3^2 = 9$, as does the median; taking both equal to $13$ also leaves the most room below. Then the two smallest add up to $50 - 39 = 11$, and their squared deviations from $10$ are least when they are as equal as possible: $5$ and $6$, giving $25 + 16 = 41$. Raising a top value only increases its own term and forces the smaller pair further down. The minimum sum of squared deviations is $9 + 9 + 9 + 41 = 68$, so the variance is $\frac{68}{5} = 13.6$.",
  "Splitting the lower pair as $5.5$ and $5.5$ despite the integer condition, or dividing by $n - 1$.",
  "C28A-minimum-variance", "Optimising a sum of squares under order, total and integrality constraints.",
  correct=r"$13.6$",
  distractors=[(r"$13.5$", "Takes the two smallest values as $5.5$ each, ignoring that they are integers."),
               (r"$17$", "Divides the minimum sum of squared deviations $68$ by $4$ instead of $5$."),
               (r"$68$", "Stops at the sum of squared deviations.")],
  check=_d13, values=[Fraction(68, 5), Fraction(27, 2), 17, 68], exams=HARD, cognitive="Analysis")
