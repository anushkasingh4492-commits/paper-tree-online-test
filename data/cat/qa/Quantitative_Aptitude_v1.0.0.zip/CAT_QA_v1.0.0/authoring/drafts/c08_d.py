import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

CX = ("CAT", "XAT")


# helpers for checks
def _pos(L, s, v, t):
    """Position on a circular track of length L (measured in one fixed direction)."""
    return (Fraction(s) + Fraction(v) * t) % L


def _pair_times(L, s1, v1, s2, v2, tmax):
    """All t in (0, tmax] at which two runners coincide: (s1 - s2) + (v1 - v2) t = k L."""
    dv = Fraction(v1) - Fraction(v2)
    out = []
    kmax = int(abs(dv) * tmax / L) + 3
    for k in range(-kmax - 3, kmax + 4):
        t = (k * Fraction(L) - (Fraction(s1) - Fraction(s2))) / dv
        if 0 < t <= tmax:
            out.append(t)
    return sorted(out)


def _first_all(L, runners, tmax):
    """First t > 0 at which all runners (s, v) are at the same point."""
    (s1, v1), (s2, v2) = runners[0], runners[1]
    for t in _pair_times(L, s1, v1, s2, v2, tmax):
        ps = {_pos(L, s, v, t) for s, v in runners}
        if len(ps) == 1:
            return t
    return None


# ================================================================= EASY (13)

def _c1():
    # 1000 m race, Ravi finishes in 192 s, Meera 40 m short at that moment.
    vm = symbols('vm', positive=True)
    vM = solve(Eq(vm * 192, 1000 - 40), vm)[0]
    return 1000 / vM - 192
q("C08-D-001", "Races", "Beat margin given in distance converted to a beat margin in time", "Easy",
  "Multi-step word problem",
  r"In a $1{,}000$ m race, Ravi beats Meera by $40$ m. Ravi completes the race in $3$ minutes $12$ seconds. Both run at constant speeds throughout. By how many seconds does Ravi beat Meera? (Type the answer in seconds.)",
  "TITA",
  r"When Ravi finishes after $192$ s, Meera has covered $960$ m, so her speed is $\frac{960}{192} = 5$ m/s. She needs $\frac{40}{5} = 8$ s more to cover the last $40$ m. Ravi wins by $8$ seconds.",
  "Converting the distance margin into time using the winner's speed instead of the loser's speed.",
  "C08D-race-beat-convert", "One idea (the margin is run at the loser's speed) and two short steps.",
  tita_answer=8, check=_c1,
  tita_traps=[(40, "Types the distance margin of $40$ m as if it were the time margin."),
              (200, "Reports Meera's total time of $200$ s instead of the margin.")],
  cognitive="Application")


def _c2():
    k = symbols('k', positive=True)
    # Arjun at speed 1 runs 400 m in 400 time units; Kabir starts 25 m ahead and is 15 m short.
    kk = solve(Eq(25 + k * 400, 400 - 15), k)[0]
    return 1 / kk
q("C08-D-002", "Races", "Speed ratio from a head start combined with a winning margin", "Easy",
  "Single-step computation",
  r"In a $400$ m race, Arjun gives Kabir a start of $25$ m and still beats him by $15$ m. Both run at constant speeds. The ratio of Arjun's speed to Kabir's speed is",
  "MCQ",
  r"While Arjun runs $400$ m, Kabir starts at the $25$ m mark and stops $15$ m short of the finish, so he runs $400 - 25 - 15 = 360$ m in the same time. The ratio of speeds is $400 : 360 = 10 : 9$.",
  "Accounting for only one of the two adjustments (start or margin) to Kabir's distance.",
  "C08D-race-head-start-speed-ratio", "Single idea: equal times, so speeds are in the ratio of distances.",
  correct=r"$10 : 9$",
  distractors=[(r"$16 : 15$", "Subtracts only the start: Kabir's distance taken as $375$ m, giving $400 : 375$."),
               (r"$40 : 39$", "Adds the margin instead of subtracting it: $400 - 25 + 15 = 390$ m, giving $400 : 390$."),
               (r"$9 : 10$", "Correct distances but writes the ratio as Kabir to Arjun.")],
  check=_c2, values=[Fraction(10, 9), Fraction(16, 15), Fraction(40, 39), Fraction(9, 10)],
  cognitive="Application")


def _c3():
    t = symbols('t', positive=True)
    # opposite directions: combined distance equals one lap
    return solve(Eq(5 * t + 3 * t, 400), t)[0]
q("C08-D-003", "Circular tracks", "First meeting of two runners moving in opposite directions", "Easy",
  "Single-step computation",
  r"Sneha and Joseph start at the same time from the same point on a circular track of length $400$ m and run in opposite directions at constant speeds of $5$ m/s and $3$ m/s respectively. After how many seconds do they meet for the first time?",
  "MCQ",
  r"Running in opposite directions, together they close one full lap. The combined speed is $5 + 3 = 8$ m/s, so they first meet after $\frac{400}{8} = 50$ s.",
  "Using the relative speed for the same direction, or confusing the first meeting with the first meeting at the starting point.",
  "C08D-circ-first-meet-opposite", "Direct use of combined speed over one lap.",
  correct=r"$50$ seconds",
  distractors=[(r"$200$ seconds", r"Uses the same-direction relative speed: $\frac{400}{5-3} = 200$."),
               (r"$400$ seconds", r"Finds when they first meet at the starting point: LCM of lap times $80$ s and $\frac{400}{3}$ s."),
               (r"$25$ seconds", r"Assumes they meet after closing half the track: $\frac{200}{8} = 25$.")],
  check=_c3, values=[50, 200, 400, 25], cognitive="Application")


def _c4():
    # simulate in minutes; track 2 km; speeds in km per minute
    L = Fraction(2)
    vp, vh = Fraction(20, 60), Fraction(12, 60)
    t = Fraction(0)
    step = Fraction(1, 4)
    while True:
        t += step
        if (vp * t - vh * t) % L == 0:
            return t
q("C08-D-004", "Circular tracks", "First overtaking of two cyclists moving in the same direction", "Easy",
  "Single-step computation",
  r"Priya and Harpreet start cycling at the same time from the same point on a circular track of length $2$ km, in the same direction, at constant speeds of $20$ km/h and $12$ km/h respectively. After how many minutes does Priya overtake Harpreet for the first time? (Type the answer in minutes.)",
  "TITA",
  r"Priya must gain one full lap of $2$ km on Harpreet. The relative speed is $20 - 12 = 8$ km/h, so the time is $\frac{2}{8}$ h $= 15$ minutes.",
  "Finding the first meeting at the starting point (LCM of lap times) instead of the first meeting anywhere.",
  "C08D-circ-first-meet-same-dir", "One idea: the faster rider gains one lap at the relative speed.",
  tita_answer=15, check=_c4,
  tita_traps=[(30, "Takes the LCM of the lap times $6$ min and $10$ min, which is the first meeting at the starting point."),
              (6, "Reports Priya's lap time of $6$ minutes.")],
  cognitive="Application")


def _c5():
    t = 1
    while True:
        # both at the start: each has completed a whole number of laps
        if t % 72 == 0 and t % 90 == 0:
            return t
        t += 1
q("C08-D-005", "Circular tracks", "First meeting at the starting point when lap times are given", "Easy",
  "Conceptual/application",
  r"Ananya and Fatima start at the same time from the same point on a circular park track and run in opposite directions. Ananya completes a lap in $72$ seconds and Fatima in $90$ seconds, both at constant speeds. After how many seconds will they be together at the starting point for the first time?",
  "MCQ",
  r"Each is at the starting point only after a whole number of her own laps, so the required time is a common multiple of $72$ and $90$; the direction of running does not matter. $\text{LCM}(72, 90) = 360$, so they are first together at the start after $360$ s.",
  "Using the first meeting time anywhere on the track, or the HCF, in place of the LCM of lap times.",
  "C08D-circ-meet-at-start-lcm", "One idea (LCM of lap times) with a direction detail that does not matter.",
  correct=r"$360$ seconds",
  distractors=[(r"$40$ seconds", r"Finds the first meeting anywhere in opposite directions: $\frac{1}{\frac{1}{72}+\frac{1}{90}} = 40$ s."),
               (r"$18$ seconds", "Takes the HCF of $72$ and $90$."),
               (r"$162$ seconds", "Adds the two lap times.")],
  check=_c5, values=[360, 40, 18, 162], cognitive="Understanding")


def _c6():
    f = Fraction(1)
    p = f * Fraction(180, 200)
    a = p * Fraction(175, 200)
    T = Fraction(200) / f
    return 200 - a * T
q("C08-D-006", "Races", "Chain of beats over the same race length", "Easy",
  "Multi-step word problem",
  r"In a $200$ m race, Fatima beats Priya by $20$ m. In another $200$ m race, Priya beats Ananya by $25$ m. All three always run at the same constant speeds. In a $200$ m race between Fatima and Ananya, Fatima wins by",
  "MCQ",
  r"When Fatima runs $200$ m, Priya runs $180$ m. When Priya runs $200$ m, Ananya runs $175$ m, so when Priya runs $180$ m, Ananya runs $180 \times \frac{175}{200} = 157.5$ m. Fatima therefore wins by $200 - 157.5 = 42.5$ m.",
  "Adding the two margins as if they were measured over the same distance.",
  "C08D-race-chain-beats", "Two proportional steps; the trap is simply adding margins.",
  correct=r"$42.5$ m",
  distractors=[(r"$45$ m", "Adds the margins $20 + 25$."),
               (r"$22.5$ m", "Finds only the gap between Priya and Ananya when Fatima finishes ($180 - 157.5$) and stops there."),
               (r"$157.5$ m", "Reports the distance Ananya has covered when Fatima finishes.")],
  check=_c6, values=[Fraction(85, 2), 45, Fraction(45, 2), Fraction(315, 2)], cognitive="Application")


def _c7():
    L = Fraction(1)
    vk, vs = 9, 6
    tm = L / (vk + vs)
    return len({(vk * tm * k) % L for k in range(1, 200)})
q("C08-D-007", "Circular tracks", "Number of distinct meeting points, opposite directions", "Easy",
  "Conceptual/application",
  r"Kabir and Sneha start at the same time from the same point on a circular track and run in opposite directions at constant speeds of $9$ km/h and $6$ km/h respectively. If they keep running indefinitely, at how many distinct points on the track will they meet?",
  "TITA",
  r"The speeds are in the ratio $3 : 2$. They meet each time they have together covered one lap, and in that time Kabir covers $\frac{3}{5}$ of a lap. So the meeting points are $\frac{3}{5}, \frac{6}{5}, \frac{9}{5}, \dots$ of a lap from the start, which cycle through the $5$ points $\frac{0}{5}, \frac{1}{5}, \dots, \frac{4}{5}$. There are $3 + 2 = 5$ distinct meeting points.",
  "Using the same-direction rule (difference of ratio terms) or not reducing the speed ratio.",
  "C08D-circ-distinct-points", "One rule: for a reduced ratio $a : b$ in opposite directions there are $a + b$ points.",
  tita_answer=5, check=_c7,
  tita_traps=[(1, "Uses the difference $3 - 2$, the rule for the same direction."),
              (15, "Adds the speeds $9 + 6$ without reducing the ratio to $3 : 2$.")],
  cognitive="Understanding")


def _c8():
    s = symbols('s', nonnegative=True)
    # Joseph's finishing time; Kabir covers (1500 - s) in that time
    T = Fraction(1500, 6)
    return solve(Eq(s + 5 * T, 1500), s)[0]
q("C08-D-008", "Races", "Head start in metres for a dead heat", "Easy",
  "Single-step computation",
  r"Joseph and Kabir run at constant speeds of $6$ m/s and $5$ m/s respectively. How many metres of start should Joseph give Kabir in a $1{,}500$ m race so that the race ends in a dead heat?",
  "MCQ",
  r"Joseph takes $\frac{1500}{6} = 250$ s. In $250$ s Kabir covers $5 \times 250 = 1250$ m, so he needs a start of $1500 - 1250 = 250$ m.",
  "Using the slower runner's finishing time to compute the start.",
  "C08D-race-dead-heat-start", "One idea: both must finish at the faster runner's finishing time.",
  correct=r"$250$ m",
  distractors=[(r"$300$ m", "Multiplies the speed difference $1$ m/s by Kabir's time of $300$ s."),
               (r"$1{,}250$ m", "Reports the distance Kabir covers in Joseph's time."),
               (r"$50$ m", "Finds the difference in finishing times, $300 - 250 = 50$ s, and gives it as metres.")],
  check=_c8, values=[250, 300, 1250, 50], cognitive="Application")


def _c9():
    tp = 200 + 50
    vp = Fraction(1000, tp)
    return 1000 - vp * 200
q("C08-D-009", "Races", "Beat margin given in time converted to a beat margin in distance", "Easy",
  "Multi-step word problem",
  r"Meera completes a $1{,}000$ m race in $200$ seconds and beats Priya by $50$ seconds. Both run at constant speeds. By how many metres does Meera beat Priya?",
  "MCQ",
  r"Priya takes $250$ s for $1000$ m, so her speed is $4$ m/s. When Meera finishes at $200$ s, Priya has run $800$ m. Meera wins by $1000 - 800 = 200$ m, which is also $4 \times 50$.",
  "Converting the time margin into distance using the winner's speed.",
  "C08D-race-beat-convert", "Two short steps; the trap is whose speed converts the time margin.",
  correct=r"$200$ m",
  distractors=[(r"$250$ m", "Multiplies the $50$ s margin by Meera's speed of $5$ m/s."),
               (r"$225$ m", "Multiplies the $50$ s margin by the average of the two speeds, $4.5$ m/s."),
               (r"$800$ m", "Reports how far Priya has run when Meera finishes.")],
  check=_c9, values=[200, 250, 225, 800], cognitive="Application")


def _c10():
    L, va, vr, T = 400, 8, 6, 660
    # count times in (0, T] at which Arjun is exactly one more lap ahead
    return len(_pair_times(L, 0, va, 0, vr, T))
q("C08-D-010", "Circular tracks", "Counting overtakings in a fixed time, same direction", "Easy",
  "Casework/optimisation",
  r"Arjun and Ravi start together from the same point on a $400$ m circular track and run in the same direction at constant speeds of $8$ m/s and $6$ m/s respectively. How many times does Arjun overtake Ravi in the first $11$ minutes? (The moment they start together does not count as an overtaking.)",
  "MCQ",
  r"Arjun gains $2$ m every second, so he overtakes Ravi each time he gains a full $400$ m lap, that is every $200$ s. In $11$ minutes $= 660$ s the overtakings occur at $200$, $400$ and $600$ s. So Arjun overtakes Ravi $3$ times.",
  "Counting the start, or using the combined speed as for opposite directions.",
  "C08D-circ-overtake-count", "One interval computation and a floor, with an off-by-one trap.",
  correct=r"$3$",
  distractors=[(r"$4$", "Counts the start as an overtaking."),
               (r"$13$", r"Reports the number of complete laps Arjun runs: $\frac{660 \times 8}{400} = 13.2$."),
               (r"$23$", r"Uses the combined speed $14$ m/s as for opposite directions: $\frac{660 \times 14}{400} = 23.1$.")],
  check=_c10, values=[3, 4, 13, 23], cognitive="Application")


def _c11():
    # simulate with Sneha's clock; Harpreet started 40 s earlier
    t = Fraction(0)
    while 5 * t < 1000:
        t += Fraction(1, 2)
    h = 4 * (t + 40)
    return 1000 - h
q("C08-D-011", "Races", "Head start given in time instead of distance", "Easy",
  "Multi-step word problem",
  r"In a $1{,}000$ m race, Sneha runs at a constant $5$ m/s and Harpreet at a constant $4$ m/s. Harpreet starts from the start line $40$ seconds before Sneha does. When Sneha crosses the finish line, how many metres is Harpreet short of the finish line? (Type the answer in metres.)",
  "TITA",
  r"Sneha takes $\frac{1000}{5} = 200$ s. By then Harpreet has been running for $200 + 40 = 240$ s and has covered $4 \times 240 = 960$ m. She is $1000 - 960 = 40$ m short of the finish.",
  "Ignoring the time start, or subtracting it from Harpreet's running time instead of adding it.",
  "C08D-race-time-start", "Two steps; the trap is the direction of the time start.",
  tita_answer=40, check=_c11,
  tita_traps=[(200, "Ignores the time start: Harpreet runs $800$ m in $200$ s."),
              (360, "Subtracts the start: Harpreet runs for $160$ s and covers $640$ m.")],
  cognitive="Application")


def _c12():
    L = Fraction(1)
    vf, vs = 15, 10
    t = _pair_times(L, 0, vf, 0, vs, 10)[0]
    return vs * t / L
q("C08-D-012", "Circular tracks", "Rounds completed by the slower rider at the first overtaking", "Easy",
  "Conceptual/application",
  r"Two cyclists start at the same time from the same point on a circular track and ride in the same direction at constant speeds of $15$ km/h and $10$ km/h. How many complete rounds has the slower cyclist ridden at the moment the faster cyclist overtakes him for the first time?",
  "TITA",
  r"The speeds are in the ratio $3 : 2$. The first overtaking happens when the faster cyclist is exactly one round ahead. In equal times the rounds are in the ratio $3 : 2$, so the difference of one round means the faster has ridden $3$ rounds and the slower $2$ rounds.",
  "Reporting the faster rider's rounds, or the difference of the ratio terms.",
  "C08D-circ-rounds-at-meeting", "One proportionality idea, no track length needed.",
  tita_answer=2, check=_c12,
  tita_traps=[(3, "Gives the number of rounds of the faster cyclist."),
              (1, "Gives the lead of one round instead of the slower cyclist's rounds.")],
  cognitive="Understanding")


def _c13():
    L = 400
    # Kabir at 0, Joseph at 200, both in the positive direction
    return _pair_times(L, 0, 7, 200, 5, 10000)[0]
q("C08-D-013", "Circular tracks", "Same-direction catch-up from diametrically opposite starting points", "Easy",
  "Single-step computation",
  r"Kabir and Joseph start at the same time from diametrically opposite points of a circular track of length $400$ m and run in the same direction at constant speeds of $7$ m/s and $5$ m/s respectively. After how many seconds does Kabir catch up with Joseph for the first time?",
  "MCQ",
  r"Diametrically opposite points are half a lap, $200$ m, apart, and Kabir closes this gap at $7 - 5 = 2$ m/s. He catches Joseph after $\frac{200}{2} = 100$ s.",
  "Using a full lap as the initial gap, or adding the speeds.",
  "C08D-circ-different-start", "One step once the initial gap of half a lap is seen.",
  correct=r"$100$ seconds",
  distractors=[(r"$200$ seconds", "Uses a full lap of $400$ m as the gap."),
               (r"$300$ seconds", r"Adds a full lap to the half-lap gap: $\frac{600}{2}$."),
               (r"$\frac{50}{3}$ seconds", r"Uses the combined speed: $\frac{200}{12}$.")],
  check=_c13, values=[100, 200, 300, Fraction(50, 3)], cognitive="Application")


# ================================================================= MEDIUM (20)

def _c14():
    p, s = symbols('p s', positive=True)
    sol = solve([Eq(1000 / p, 950 / s), Eq(1000 / s - 1000 / p, 10)], [p, s], dict=True)
    return [1000 / d[p] for d in sol if d[p] > 0][0]
q("C08-D-014", "Races", "Winner's time when the margin is given both in metres and in seconds", "Medium",
  "Multi-step word problem",
  r"In a $1{,}000$ m race, Priya beats Sneha by $50$ m or, equivalently, by $10$ seconds. Both run at constant speeds. How long does Priya take to finish the race?",
  "MCQ",
  r"Sneha covers the last $50$ m in $10$ s, so her speed is $5$ m/s and she needs $200$ s for $1000$ m. Priya finishes $10$ s earlier, in $190$ s. (Check: in $190$ s Sneha runs $950$ m.)",
  "Treating the $50$ m and $10$ s as describing the winner rather than the loser.",
  "C08D-race-beat-dist-and-time", "Must see that both margins describe the loser, then two steps.",
  correct=r"$190$ seconds",
  distractors=[(r"$200$ seconds", "Gives Sneha's time."),
               (r"$210$ seconds", "Adds the $10$ s to Sneha's time instead of subtracting it."),
               (r"$180$ seconds", r"Takes Sneha's time as $\frac{950}{5} = 190$ s and subtracts $10$ s from that.")],
  check=_c14, values=[190, 200, 210, 180], cognitive="Application")


def _c15():
    h, a = symbols('h a', positive=True)
    # when Joseph (speed 1) finishes 1500 m: Harpreet at 1440, Ananya at 1368
    hv = solve(Eq(h * 1500, 1440), h)[0]
    av = solve(Eq(a * 1500, 1368), a)[0]
    T = 1500 / hv
    return 1500 - av * T
q("C08-D-015", "Races", "Head-to-head margin of the second and third finishers of one race", "Medium",
  "Multi-step word problem",
  r"In a $1{,}500$ m race, Joseph beats Harpreet by $60$ m and beats Ananya by $132$ m. All three run at constant speeds. If Harpreet and Ananya ran a $1{,}500$ m race against each other at the same speeds, by how many metres would Harpreet win? (Type the answer in metres.)",
  "TITA",
  r"When Joseph finishes, Harpreet has run $1440$ m and Ananya $1368$ m, so their speeds are in the ratio $1440 : 1368 = 20 : 19$. When Harpreet runs $1500$ m, Ananya runs $1500 \times \frac{19}{20} = 1425$ m. Harpreet wins by $75$ m.",
  "Subtracting the two margins as if the gap stayed fixed.",
  "C08D-race-chain-beats", "Two ideas: extract a speed ratio from one race and rescale it to a new race.",
  tita_answer=75, check=_c15,
  tita_traps=[(72, "Subtracts the margins: $132 - 60$."),
              (192, "Adds the margins: $132 + 60$.")],
  cognitive="Application")


def _c16():
    laps = [Fraction(600, v) for v in (15, 10, 8)]
    t = Fraction(1)
    while True:
        if all((t / lp).denominator == 1 for lp in laps):
            return t
        t += 1
q("C08-D-016", "Circular tracks", "Three riders first together at the starting point", "Medium",
  "Multi-step word problem",
  r"Three cyclists start at the same time from the same point on a circular track of length $600$ m and ride in the same direction at constant speeds of $15$ m/s, $10$ m/s and $8$ m/s. After how many seconds will all three be together at the starting point for the first time?",
  "MCQ",
  r"The lap times are $\frac{600}{15} = 40$ s, $\frac{600}{10} = 60$ s and $\frac{600}{8} = 75$ s. Each is at the start only at multiples of its own lap time, so the answer is $\text{LCM}(40, 60, 75) = 600$ s.",
  "Taking the LCM of only two of the lap times or combining lap times additively.",
  "C08D-circ-meet-at-start-lcm", "Two steps (lap times, then an LCM of three numbers) with partial-LCM traps.",
  correct=r"$600$ seconds",
  distractors=[(r"$120$ seconds", "Takes the LCM of only the first two lap times, $40$ and $60$."),
               (r"$300$ seconds", "Takes the LCM of only the last two lap times, $60$ and $75$."),
               (r"$175$ seconds", "Adds the three lap times.")],
  check=_c16, values=[600, 120, 300, 175], cognitive="Application")


def _c17():
    L = Fraction(1)
    vf, vs = 16, 10
    tm = L / (vf - vs)
    return len({(vf * tm * k) % L for k in range(1, 200)})
q("C08-D-017", "Circular tracks", "Number of distinct meeting points, same direction, unreduced speeds", "Medium",
  "Conceptual/application",
  r"During a warm-up session on a velodrome, Harpreet and Joseph set off together from the same point on the banked oval and ride in the same direction at constant speeds of $16$ km/h and $10$ km/h respectively. If they keep riding indefinitely, at how many distinct points on the oval does Harpreet draw level with Joseph?",
  "MCQ",
  r"The speeds reduce to the ratio $8 : 5$. They draw level each time Harpreet gains one lap, and in that interval he rides $\frac{8}{3}$ laps. The meeting points are therefore $\frac{8}{3}, \frac{16}{3}, 8, \dots$ laps from the start, which repeat the $3$ positions $\frac{2}{3}, \frac{1}{3}, 0$ of a lap. They draw level at $8 - 5 = 3$ distinct points.",
  "Applying the difference rule without first reducing the speed ratio, or using the opposite-direction rule.",
  "C08D-circ-distinct-points", "The rule works only on the reduced ratio; the unreduced speeds are the trap.",
  correct=r"$3$",
  distractors=[(r"$6$", "Uses the difference of the unreduced speeds, $16 - 10$."),
               (r"$13$", "Uses the opposite-direction rule $8 + 5$."),
               (r"$1$", "Assumes riders in the same direction draw level only at the starting point.")],
  check=_c17, values=[3, 6, 13, 1], cognitive="Analysis")


def _c18():
    # clock starts when Meera starts; Fatima has run 6 * 40 m by then (positive direction)
    L, d, T = 800, 40, 9 * 60
    return len(_pair_times(L, 6 * d, 6, 0, -4, T))
q("C08-D-018", "Circular tracks", "Counting opposite-direction meetings when one runner starts later", "Medium",
  "Casework/optimisation",
  r"Fatima starts running from point P on a circular track of length $800$ m at a constant $6$ m/s. After $40$ seconds, Meera starts from P and runs in the opposite direction at a constant $4$ m/s. How many times do Fatima and Meera meet in the first $9$ minutes after Meera starts?",
  "TITA",
  r"When Meera starts, Fatima is $6 \times 40 = 240$ m ahead, so the arc between them in Meera's direction is $800 - 240 = 560$ m. They close it at $6 + 4 = 10$ m/s, so the first meeting is $56$ s after Meera starts, and after that they meet every $\frac{800}{10} = 80$ s. The meetings fall at $56, 136, \dots, 56 + 80k$ s, and $56 + 80k \le 540$ gives $k \le 6.05$, so $k = 0, 1, \dots, 6$: $7$ meetings (the last at $536$ s).",
  "Ignoring the head start and dividing the whole time by the meeting interval.",
  "C08D-circ-delayed-start", "Head start shifts the first meeting, then a count with a tight boundary ($536$ s against $540$ s).",
  tita_answer=7, check=_c18,
  tita_traps=[(6, r"Ignores Fatima's head start and counts $\lfloor \frac{540}{80} \rfloor = 6$."),
              (1, "Uses the same-direction relative speed $2$ m/s, as if they ran the same way.")],
  cognitive="Application")


def _c19():
    r = Fraction(1)
    a = r * Fraction(180, 200)
    k = a * Fraction(270, 300)
    return 500 - k * (500 / r)
q("C08-D-019", "Races", "Chain of beats given over races of different lengths", "Medium",
  "Multi-step word problem",
  r"Ravi beats Arjun by $20$ m in a $200$ m race, and Arjun beats Kabir by $30$ m in a $300$ m race. Each runner always runs at the same constant speed. By how many metres would Ravi beat Kabir in a $500$ m race?",
  "MCQ",
  r"Arjun's speed is $\frac{180}{200} = \frac{9}{10}$ of Ravi's, and Kabir's is $\frac{270}{300} = \frac{9}{10}$ of Arjun's. So Kabir's speed is $\frac{81}{100}$ of Ravi's. In the time Ravi runs $500$ m, Kabir runs $405$ m, and Ravi wins by $95$ m.",
  "Adding margins or percentages instead of multiplying the speed ratios.",
  "C08D-race-chain-different-lengths", "Margins must be converted to ratios before chaining; two traps from adding.",
  correct=r"$95$ m",
  distractors=[(r"$100$ m", r"Adds the two $10\%$ deficits to get $20\%$ of $500$ m."),
               (r"$50$ m", "Adds the margins $20 + 30$ directly."),
               (r"$405$ m", "Reports Kabir's distance when Ravi finishes.")],
  check=_c19, values=[95, 100, 50, 405], cognitive="Application")


def _c20():
    ts = 250                     # Sneha's time for 1 km
    tf = Fraction(900, 1000) * ts  # Fatima's time: Sneha covers 900 m in it
    tp = ts + 50                 # Priya's time
    return tp - tf
q("C08-D-020", "Races", "Combining a distance handicap and a time handicap into one time handicap", "Medium",
  "Multi-step word problem",
  r"Sneha runs $1$ km in $250$ seconds. In a $1$ km race, Fatima can give Sneha a start of $100$ m and the race ends in a dead heat. In another $1$ km race, Sneha can give Priya a start of $50$ seconds and that race also ends in a dead heat. All speeds are constant. How many seconds of start can Fatima give Priya in a $1$ km race so that it ends in a dead heat? (Type the answer in seconds.)",
  "TITA",
  r"Sneha runs $900$ m in $\frac{900}{4} = 225$ s, which is Fatima's time for $1$ km. Priya's time for $1$ km is $250 + 50 = 300$ s. Fatima can give Priya $300 - 225 = 75$ s.",
  "Mixing metres and seconds, or converting the $100$ m with the wrong runner's speed.",
  "C08D-race-handicap-chain", "Must convert a distance handicap to time with the right speed, then chain.",
  tita_answer=75, check=_c20,
  tita_traps=[(150, "Adds $100$ (metres) and $50$ (seconds) as if they were the same unit."),
              (80, r"Converts the $100$ m using Priya's speed $\frac{10}{3}$ m/s ($30$ s) and adds $50$ s.")],
  cognitive="Application")


def _c21():
    return _first_all(600, [(0, 3), (0, 5), (0, 9)], 10000)
q("C08-D-021", "Circular tracks", "First meeting of three runners anywhere on the track, same direction", "Medium",
  "Conceptual/application",
  r"Meera, Joseph and Fatima start at the same time from the same point on a circular track of length $600$ m and run in the same direction at constant speeds of $3$ m/s, $5$ m/s and $9$ m/s respectively. After how many seconds are all three at the same point of the track for the first time?",
  "MCQ",
  r"Meera and Joseph are together every $\frac{600}{5-3} = 300$ s, and Joseph and Fatima every $\frac{600}{9-5} = 150$ s. All three are together at common multiples, first at $\text{LCM}(300, 150) = 300$ s. (They are first together at the starting point only at $\text{LCM}(200, 120, \frac{200}{3}) = 600$ s.)",
  "Confusing the first meeting anywhere with the first meeting at the starting point, or using only one pair.",
  "C08D-circ-three-runners", "Needs pairwise meeting intervals and the distinction from meeting at the start.",
  correct=r"$300$ seconds",
  distractors=[(r"$600$ seconds", "Finds the first time all three are at the starting point (LCM of the lap times)."),
               (r"$150$ seconds", "Uses only the pair Joseph and Fatima."),
               (r"$100$ seconds", r"Uses only the pair Meera and Fatima: $\frac{600}{9-3}$.")],
  check=_c21, values=[300, 600, 150, 100], cognitive="Analysis")


def _c22():
    # clockwise positive; Joseph at 0 moving +5, Kabir at 180 moving -4
    return _pair_times(720, 0, 5, 180, -4, 1000)[0]
q("C08-D-022", "Circular tracks", "Opposite-direction first meeting from different starting points", "Medium",
  "Multi-step word problem",
  r"On a circular track of length $720$ m, point Q is $180$ m clockwise from point P. Joseph starts from P and runs clockwise at a constant $5$ m/s. At the same moment Kabir starts from Q and runs anticlockwise at a constant $4$ m/s. After how many seconds do they meet for the first time?",
  "MCQ",
  r"Joseph runs clockwise towards Q and Kabir runs anticlockwise from Q towards P, so they approach each other across the $180$ m arc from P to Q. They close it at $5 + 4 = 9$ m/s and meet after $\frac{180}{9} = 20$ s.",
  "Choosing the wrong arc between the starting points, or using the relative speed for the same direction.",
  "C08D-circ-different-start", "Requires picking the arc they actually close; two plausible wrong arcs.",
  correct=r"$20$ seconds",
  distractors=[(r"$60$ seconds", r"Uses the other arc of $540$ m: $\frac{540}{9}$."),
               (r"$80$ seconds", r"Uses a full lap: $\frac{720}{9}$."),
               (r"$180$ seconds", "Uses the same-direction relative speed $1$ m/s on the $180$ m arc.")],
  check=_c22, values=[20, 60, 80, 180], cognitive="Application")


def _c23():
    L = 600
    t1 = _pair_times(L, 0, 6, 0, -4, 1000)[0]
    p = _pos(L, 0, 6, t1)
    # after t1 both move in Ravi's direction from the same point p
    t2 = _pair_times(L, p, 6, p, 4, 10000)[0]
    return t1 + t2
q("C08-D-023", "Circular tracks", "One runner reverses direction at the first meeting", "Medium",
  "Multi-step word problem",
  r"Ravi and Arjun start at the same time from the same point on a circular track of length $600$ m and run in opposite directions at constant speeds of $6$ m/s and $4$ m/s respectively. At the moment they first meet, Arjun turns around and from then on runs in the same direction as Ravi, still at $4$ m/s. How many seconds after the start do they meet for the second time?",
  "MCQ",
  r"They first meet after $\frac{600}{6+4} = 60$ s. From that point both run in the same direction, so Ravi must gain a full lap of $600$ m at $2$ m/s, which takes $300$ s. The second meeting is $60 + 300 = 360$ s after the start.",
  "Ignoring the change of direction or forgetting the time before the first meeting.",
  "C08D-circ-change-after-meeting", "Two stages with different relative speeds.",
  correct=r"$360$ seconds",
  distractors=[(r"$120$ seconds", r"Ignores the turn and keeps the combined speed: $2 \times 60$."),
               (r"$300$ seconds", "Finds the catch-up time but does not add the first $60$ s."),
               (r"$180$ seconds", r"Takes the gap after the turn as Arjun's $240$ m instead of a full lap: $60 + \frac{240}{2}$.")],
  check=_c23, values=[360, 120, 300, 180], cognitive="Application")


def _c24():
    # simulate on the straight path P (0) to Q (300) and back
    def pos(v, t):
        d = v * t
        return d if d <= 300 else 600 - d
    t = Fraction(0)
    step = Fraction(1, 4)
    while True:
        t += step
        if 6 * t > 300 and pos(6, t) == pos(4, t):
            return 300 - pos(6, t)
q("C08-D-024", "Races", "Out-and-back race: crossing point after the leader turns", "Medium",
  "Multi-step word problem",
  r"Ravi and Sneha start together from point P and race along a straight path to a post at Q, $300$ m away, and back to P. Ravi runs at a constant $6$ m/s and Sneha at a constant $4$ m/s, and turning at Q takes no time. How many metres from Q do they cross each other? (Type the answer in metres.)",
  "TITA",
  r"They cross when their combined distance is twice $PQ$, that is $600$ m, which happens after $\frac{600}{6+4} = 60$ s. Ravi has then run $360$ m, so he is $60$ m back from Q (and Sneha, having run $240$ m, is $60$ m short of Q).",
  "Measuring the crossing point from P instead of Q.",
  "C08D-race-out-and-back", r"Needs the insight that the combined distance at the crossing is $2 \times PQ$.",
  tita_answer=60, check=_c24,
  tita_traps=[(240, "Gives the crossing point's distance from P."),
              (100, "Gives the gap between them at the moment Ravi reaches Q, $300 - 200$.")],
  cognitive="Application")


def _c25():
    L = 800
    times = _pair_times(L, 0, 10, 0, -6, 100000)
    for i, t in enumerate(times):
        if _pos(L, 0, 10, t) == 0 and _pos(L, 0, -6, t) == 0:
            return i + 1
q("C08-D-025", "Circular tracks", "Number of meetings before the first meeting at the starting point", "Medium",
  "Conceptual/application",
  r"Harpreet and Joseph start at the same time from the same point on a circular track of length $800$ m and run in opposite directions at constant speeds of $10$ m/s and $6$ m/s respectively. Not counting the start, how many times will they have met up to and including the first time they meet at the starting point?",
  "TITA",
  r"They meet every $\frac{800}{16} = 50$ s. The lap times are $80$ s and $\frac{400}{3}$ s, whose LCM is $400$ s, so they are first together at the start after $400$ s. That is the $\frac{400}{50} = 8$th meeting. (In general, for a reduced ratio $5 : 3$ in opposite directions this count is $5 + 3$.)",
  "Excluding the meeting at the starting point, or using the same-direction rule.",
  "C08D-circ-meetings-before-start", "Combines the meeting interval with the LCM of lap times.",
  tita_answer=8, check=_c25,
  tita_traps=[(7, "Excludes the meeting that takes place at the starting point."),
              (2, "Uses the same-direction rule $5 - 3$.")],
  cognitive="Analysis")


def _c26():
    vk = Fraction(1000, 240)
    vj = Fraction(1000 - 40, 240)
    tj = 1000 / vj
    # Joseph starts 15 s earlier: finishing times on Kabir's clock
    fin_j = tj - 15
    fin_k = Fraction(240)
    return fin_k - fin_j   # positive: Joseph wins by this many seconds
q("C08-D-026", "Races", "Outcome when a dead-heat distance start is replaced by a time start", "Medium",
  "Multi-step word problem",
  r"Kabir runs $1$ km in $4$ minutes. In a $1$ km race, if Kabir gives Joseph a start of $40$ m, the race ends in a dead heat. If instead Kabir gives Joseph a start of $15$ seconds in a $1$ km race, with both running at the same constant speeds as before, what is the result?",
  "MCQ",
  r"With the $40$ m start, Joseph runs $960$ m in $240$ s, so his speed is $4$ m/s and he needs $250$ s for $1$ km. With a $15$ s start, Joseph finishes $250 - 15 = 235$ s after Kabir starts, while Kabir finishes at $240$ s. Joseph wins by $5$ seconds.",
  "Converting the $40$ m start into time with the wrong runner's speed or subtracting in the wrong order.",
  "C08D-race-dead-heat-start", "Must infer the second speed from a dead heat and then compare time starts.",
  correct=r"Joseph wins by $5$ seconds",
  distractors=[(r"Kabir wins by $5$ seconds", "Compares the finishing times the wrong way round."),
               (r"Joseph wins by $5.4$ seconds", r"Converts the $40$ m start using Kabir's speed: $\frac{40}{1000/240} = 9.6$ s and $15 - 9.6 = 5.4$."),
               (r"Joseph wins by $25$ seconds", "Adds the $10$ s equivalent of the $40$ m start to the $15$ s start.")],
  check=_c26, values=[5, -5, Fraction(27, 5), 25], cognitive="Analysis")


def _c27():
    L = Fraction(1)       # track length does not matter; take 1 km
    vp, va = 21, 15
    finish = 12 * L / vp
    times = _pair_times(L, 0, vp, 0, va, finish)
    return len([t for t in times if t < finish])
q("C08-D-027", "Circular tracks", "Overtakings during a race of a fixed number of laps", "Medium",
  "Casework/optimisation",
  r"In a $12$-lap race on a circular track, Priya and Ananya start together from the start line and run in the same direction at constant speeds of $21$ km/h and $15$ km/h respectively. How many times does Priya overtake Ananya before Priya finishes the race?",
  "TITA",
  r"The speeds are in the ratio $7 : 5$. When Priya completes $12$ laps, Ananya completes $12 \times \frac{5}{7} = 8\frac{4}{7}$ laps, so Priya is $3\frac{3}{7}$ laps ahead. She overtakes Ananya each time her lead reaches a whole lap, that is $3$ times.",
  "Rounding the lap lead up, or reporting a lap count instead of the lead.",
  "C08D-circ-overtake-count", "Converts a race length into a lap lead and counts whole laps gained.",
  tita_answer=3, check=_c27,
  tita_traps=[(4, "Rounds the lead of $3\\frac{3}{7}$ laps up."),
              (8, "Reports the number of complete laps Ananya has run.")],
  cognitive="Application")


def _c28():
    tr = 150
    ta = tr + 50
    tk = tr + 100
    vk = Fraction(1000, tk)
    return 1000 - vk * ta
q("C08-D-028", "Races", "Converting two time handicaps into a distance handicap", "Medium",
  "Multi-step word problem",
  r"Ravi runs $1$ km in $150$ seconds. In a $1$ km race he can give Arjun a start of $50$ seconds and finish in a dead heat; in another $1$ km race he can give Kabir a start of $100$ seconds and finish in a dead heat. All speeds are constant. How many metres of start can Arjun give Kabir in a $1$ km race so that it ends in a dead heat?",
  "MCQ",
  r"Arjun takes $150 + 50 = 200$ s and Kabir $150 + 100 = 250$ s for $1$ km, so Kabir's speed is $4$ m/s. In Arjun's $200$ s, Kabir covers $800$ m. Arjun can give Kabir $200$ m.",
  "Converting the time difference to distance with the wrong runner's speed.",
  "C08D-race-handicap-chain", "Time handicaps must be turned into times, then into a distance with the slower speed.",
  correct=r"$200$ m",
  distractors=[(r"$250$ m", "Converts the $50$ s difference using Arjun's speed of $5$ m/s."),
               (r"$400$ m", "Converts Kabir's whole $100$ s handicap using Kabir's speed of $4$ m/s."),
               (r"$500$ m", "Converts Kabir's whole $100$ s handicap using Arjun's speed of $5$ m/s.")],
  check=_c28, values=[200, 250, 400, 500], cognitive="Application")


def _c29():
    L = 1000
    t3 = _pair_times(L, 0, 7, 0, -3, 10000)[2]
    p = _pos(L, 0, 7, t3)
    return min(p, L - p)
q("C08-D-029", "Circular tracks", "Location of the third meeting point in opposite directions", "Medium",
  "Conceptual/application",
  r"Ravi and Sneha start at the same time from point P on a circular track of length $1{,}000$ m and run in opposite directions at constant speeds of $7$ m/s and $3$ m/s respectively. What is the shorter distance along the track between P and the point where they meet for the third time?",
  "MCQ",
  r"They meet every $\frac{1000}{10} = 100$ s, and in each interval Sneha runs $300$ m. At the third meeting she has run $900$ m from P in her direction, which is $1000 - 900 = 100$ m from P the other way. The shorter distance is $100$ m.",
  "Off-by-one in the meeting count, or reporting the first meeting point.",
  "C08D-circ-nth-meeting-point", "Needs successive meeting points and the shorter-arc reading.",
  correct=r"$100$ m",
  distractors=[(r"$300$ m", "Gives the first meeting point."),
               (r"$400$ m", "Counts the start as the first meeting and so locates the second meeting ($600$ m along Sneha's direction)."),
               (r"$200$ m", "Locates the fourth meeting ($1200$ m along Sneha's direction).")],
  check=_c29, values=[100, 300, 400, 200], cognitive="Application")


def _c30():
    L, vj = symbols('L vj', positive=True)
    sol = solve([Eq(L - vj * 141, 36), Eq(L / vj - 141, 9)], [L, vj], dict=True)
    return [d[L] for d in sol if d[L] > 0][0]
q("C08-D-030", "Races", "Race length from margins in metres and seconds", "Medium",
  "Inverse/parameter",
  r"In a race, Fatima beats Joseph by $36$ m or, equivalently, by $9$ seconds. Fatima finishes the race in $141$ seconds. Both run at constant speeds. What is the length of the race?",
  "MCQ",
  r"Joseph covers the last $36$ m in $9$ s, so his speed is $4$ m/s. He finishes in $141 + 9 = 150$ s, so the race is $4 \times 150 = 600$ m long.",
  "Using Fatima's time with Joseph's speed, or subtracting the time margin.",
  "C08D-race-beat-dist-and-time", "Inverse use of the two-margin idea.",
  correct=r"$600$ m",
  distractors=[(r"$564$ m", r"Multiplies Joseph's speed by Fatima's time: $4 \times 141$."),
               (r"$528$ m", "Takes Joseph's time as $141 - 9 = 132$ s."),
               (r"$636$ m", r"Adds the $36$ m margin to $4 \times 150$.")],
  check=_c30, values=[600, 564, 528, 636], cognitive="Application")


def _c31():
    # time measured from Priya's start; Harpreet started 30 s earlier at 5 m/s (positive direction)
    L = 900
    return _pair_times(L, 5 * 30, 5, 0, -10, 10000)[0]
q("C08-D-031", "Circular tracks", "Opposite-direction meeting when one runner starts later", "Medium",
  "Multi-step word problem",
  r"Harpreet starts running from a point on a circular track of length $900$ m at a constant $5$ m/s. After $30$ seconds, Priya starts from the same point and runs in the opposite direction at a constant $10$ m/s. How many seconds after Priya starts do they meet for the first time? (Type the answer in seconds.)",
  "TITA",
  r"In $30$ s Harpreet has run $150$ m, so the arc between them in Priya's direction is $900 - 150 = 750$ m. They close it at $5 + 10 = 15$ m/s, which takes $\frac{750}{15} = 50$ s.",
  "Ignoring Harpreet's head start, or measuring time from Harpreet's start.",
  "C08D-circ-delayed-start", "Head start shortens the arc to be closed; two steps.",
  tita_answer=50, check=_c31,
  tita_traps=[(60, "Ignores the head start: $\\frac{900}{15}$."),
              (80, "Measures the time from Harpreet's start: $30 + 50$.")],
  cognitive="Application")


def _c32():
    L = Fraction(1)
    times = _pair_times(L, 0, 14, 0, 8, 10)
    return 8 * times[2] / L
q("C08-D-032", "Circular tracks", "Rounds of the slower runner at the third overtaking", "Medium",
  "Conceptual/application",
  r"Two runners start at the same time from the same point on a circular track and run in the same direction at constant speeds of $14$ km/h and $8$ km/h. How many complete rounds has the slower runner run at the moment the faster runner overtakes him for the third time?",
  "MCQ",
  r"The speeds are in the ratio $7 : 4$, so in any time the rounds run are in the ratio $7 : 4$. The third overtaking happens when the faster runner is exactly $3$ rounds ahead: $7k - 4k = 3$ gives $k = 1$. The slower runner has run $4$ rounds.",
  "Reporting the faster runner's rounds, or scaling the per-overtaking count incorrectly.",
  "C08D-circ-rounds-at-meeting", "Needs the ratio and a lap-gain equation rather than a track length.",
  correct=r"$4$",
  distractors=[(r"$7$", "Gives the faster runner's rounds."),
               (r"$12$", "Assumes the slower runner runs $4$ rounds between successive overtakings and multiplies by $3$."),
               (r"$3$", "Gives the number of overtakings, the faster runner's lead in rounds.")],
  check=_c32, values=[4, 7, 12, 3], cognitive="Understanding")


def _c33():
    vr, va = Fraction(400, 1), Fraction(360, 1)   # distances in the same time
    t_r = Fraction(440) / vr
    a_pos = va * t_r
    return 400 - a_pos     # positive: Ravi wins by this many metres
q("C08-D-033", "Races", "Winner starts behind the line by the earlier margin", "Medium",
  "Conceptual/application",
  r"In a $400$ m race, Ravi beats Arjun by $40$ m. In a second $400$ m race, Ravi starts $40$ m behind the start line while Arjun starts on it, and both run at the same constant speeds as before. Which describes the result of the second race?",
  "MCQ",
  r"The speeds are in the ratio $400 : 360 = 10 : 9$. Ravi now runs $440$ m; in that time Arjun runs $440 \times \frac{9}{10} = 396$ m. So Ravi finishes first, with Arjun $4$ m short: Ravi wins by $4$ m.",
  "Assuming that a start equal to the old margin produces a dead heat.",
  "C08D-race-reverse-handicap", "Counter-intuitive result; requires recomputing with the ratio rather than intuition.",
  correct=r"Ravi wins by $4$ m",
  distractors=[(r"The race ends in a dead heat", "Assumes giving up exactly the old $40$ m margin makes the runners level."),
               (r"Arjun wins by $4$ m", "Gets the size of the gap but assumes the runner starting behind must lose."),
               (r"Ravi wins by $\frac{40}{9}$ m", r"Measures how far past the line Ravi would be when Arjun finishes: $\frac{400 \times 10}{9} - 440$.")],
  check=_c33, values=[4, 0, -4, Fraction(40, 9)], cognitive="Analysis")


# ================================================================= DIFFICULT (12)

def _c34():
    # clockwise positive; Ananya rides anticlockwise
    return _first_all(840, [(0, 3), (0, 9), (0, -5)], 100000)
q("C08-D-034", "Circular tracks", "Three riders with mixed directions first together anywhere", "Difficult",
  "Casework/optimisation",
  r"Meera, Sneha and Ananya start cycling at the same time from the same point on a circular track of length $840$ m. Meera and Sneha ride clockwise at constant speeds of $3$ m/s and $9$ m/s, and Ananya rides anticlockwise at a constant $5$ m/s. After how many seconds are all three at the same point of the track for the first time?",
  "MCQ",
  r"Meera and Sneha (same direction) coincide every $\frac{840}{9-3} = 140$ s. Meera and Ananya (opposite directions) coincide every $\frac{840}{3+5} = 105$ s, and Sneha and Ananya every $\frac{840}{9+5} = 60$ s. All three are together exactly when two of the pairs are, so at common multiples of $140$ and $105$; the first is $\text{LCM}(140, 105) = 420$ s (also a multiple of $60$). Then Meera has ridden $1260$ m, so all three are at the point $420$ m clockwise from the start. They are first together at the start only at $\text{LCM}(280, \frac{280}{3}, 168) = 840$ s.",
  "Taking a single pair's meeting interval, or using the starting point (LCM of lap times).",
  "C08D-circ-three-runners", "Mixed directions give three different pairwise intervals, none of which divides another, so an LCM is needed and the start-point LCM is a trap.",
  correct=r"$420$ seconds",
  distractors=[(r"$840$ seconds", r"Finds when all three are first together at the starting point (LCM of lap times $280$, $\frac{280}{3}$ and $168$ s)."),
               (r"$140$ seconds", "Uses only the same-direction pair Meera and Sneha."),
               (r"$105$ seconds", "Uses only the pair Meera and Ananya.")],
  check=_c34, values=[420, 840, 140, 105], exams=CX, cognitive="Analysis")


def _c35():
    L = 600
    t1 = _pair_times(L, 0, 5, 0, -3, 1000)[0]
    p = _pos(L, 0, 5, t1)
    # Meera now runs clockwise at 8 m/s from the same point as Ravi
    t2 = _pair_times(L, p, 8, p, 5, 10000)[0]
    return int(_pos(L, p, 5, t2))
q("C08-D-035", "Circular tracks", "Location of the second meeting after a reversal and a speed change", "Difficult",
  "Multi-step word problem",
  r"Ravi and Meera start at the same time from point P on a circular track of length $600$ m. Ravi runs clockwise at a constant $5$ m/s and Meera runs anticlockwise at a constant $3$ m/s. At the moment they first meet, Meera turns around and runs clockwise at a constant $8$ m/s; Ravi carries on unchanged. How many metres clockwise from P is the point where they meet for the second time? (Give the distance measured clockwise from P, between $0$ and $600$ m.)",
  "TITA",
  r"They first meet after $\frac{600}{8} = 75$ s, at $375$ m clockwise from P. Now both run clockwise from the same point and Meera must gain a full lap at $8 - 5 = 3$ m/s, which takes $200$ s. In that time Ravi runs $1000$ m, so the second meeting is at $375 + 1000 = 1375$ m, that is $1375 - 1200 = 175$ m clockwise from P.",
  "Measuring the second leg from P instead of from the first meeting point, or ignoring the change.",
  "C08D-circ-change-after-meeting", "Two stages, a lap gain from a non-start point, and reduction modulo the lap.",
  tita_answer=175, check=_c35,
  tita_traps=[(400, "Measures Ravi's $1000$ m of the second stage from P instead of from the first meeting point."),
              (150, "Ignores the change: second meeting after $150$ s with Ravi at $750$ m, that is $150$ m."),
              (375, "Gives the first meeting point.")],
  exams=CX, cognitive="Analysis")


def _c36():
    a, b = symbols('a b', positive=True)
    # a, b: times of Ravi and Kabir for 1 km
    sol = solve([Eq(b * Rational(900, 1000) - a, 25),
                 Eq(a * Rational(950, 1000), b - 60)], [a, b], dict=True)
    return sol[0][a]
q("C08-D-036", "Races", "Two handicap scenarios determine the runners' times", "Difficult",
  "Inverse/parameter",
  r"Ravi and Kabir run $1$ km races at their own constant speeds. When Ravi gives Kabir a start of $100$ m, Ravi wins by $25$ seconds. When Ravi instead gives Kabir a start of $60$ seconds, Kabir wins by $50$ m. How many seconds does Ravi take to run $1$ km? (Type the answer in seconds.)",
  "TITA",
  r"Let Ravi and Kabir take $a$ and $b$ seconds for $1$ km. First race: Kabir runs $900$ m in $0.9b$ s, so $0.9b - a = 25$. Second race: Kabir finishes $b - 60$ s after Ravi starts, when Ravi has run $950$ m, so $0.95a = b - 60$. Substituting $b = 0.95a + 60$: $0.855a + 54 - a = 25$, so $0.145a = 29$ and $a = 200$. (Then $b = 250$: check $225 - 200 = 25$ and Ravi's $950$ m in $190$ s.)",
  "Setting up the second scenario on the wrong clock or attaching the margins to the wrong runner.",
  "C08D-race-two-scenarios", "Two simultaneous conditions with mixed time and distance handicaps; easy to misplace a clock.",
  tita_answer=200, check=_c36,
  tita_traps=[(250, "Solves correctly but reports Kabir's time."),
              (190, "Reports the moment in the second race when Kabir finishes on Ravi's clock.")],
  exams=CX, cognitive="Analysis")


def _c37():
    tr, ta, t = symbols('tr ta t', positive=True)
    # lap 1; tr, ta lap times; first meeting at t; after it Ravi needs 50 s, Arjun 128 s to reach P
    sol = solve([Eq(t * (1 / tr + 1 / ta), 1), Eq(tr - t, 50), Eq(ta - t, 128)], [tr, ta, t], dict=True)
    s = sol[0]
    Tr, Ta, tm = Fraction(int(s[tr])), Fraction(int(s[ta])), Fraction(int(s[t]))
    # first time both are at P again
    k = 1
    while (k * Tr) % Ta != 0:
        k += 1
    T = k * Tr
    return len(_pair_times(1, 0, 1 / Tr, 0, -1 / Ta, T))
q("C08-D-037", "Circular tracks", "Meetings until first together at the start, from post-meeting times", "Difficult",
  "Conceptual/application",
  r"Ravi and Arjun start at the same time from point P on a circular track and run in opposite directions at constant speeds. After they meet for the first time, Ravi takes $50$ seconds more to reach P and Arjun takes $2$ minutes $8$ seconds more to reach P. Not counting the start, how many times will they have met up to and including the first time they are together at P again?",
  "MCQ",
  r"Let the first meeting be after $t$ s. After it, each runs the arc the other has already run, so $\frac{v_R}{v_A} = \frac{t}{50} = \frac{128}{t}$, giving $t^2 = 6400$ and $t = 80$ s. The lap times are $80 + 50 = 130$ s and $80 + 128 = 208$ s, so the speeds are in the ratio $208 : 130 = 8 : 5$. They are first together at P after $\text{LCM}(130, 208) = 1040$ s, and they meet every $80$ s, so that is the $\frac{1040}{80} = 13$th meeting (in general $8 + 5$ for a reduced ratio $8 : 5$ in opposite directions).",
  "Leaving out the meeting at P itself, or using the same-direction rule for the count.",
  "C08D-circ-meetings-before-start", "Two stages: the relation $t^2 = t_1 t_2$ to get the speed ratio, then the meeting count up to the first meeting at the start.",
  correct=r"$13$",
  distractors=[(r"$12$", "Excludes the meeting that takes place at P."),
               (r"$3$", r"Uses the same-direction rule, the difference of the ratio terms $8 - 5$."),
               (r"$8$", r"Counts Ravi's laps up to $1040$ s, $\frac{1040}{130}$, instead of the meetings.")],
  check=_c37, values=[13, 12, 3, 8], exams=CX, cognitive="Analysis")


def _c38():
    L, T = 600, 32 * 60
    meets = _pair_times(L, 0, 7, 0, -5, T)
    return len([t for t in meets if _pos(L, 0, 7, t) != 0])
q("C08-D-038", "Circular tracks", "Meetings away from the starting point within a fixed time", "Difficult",
  "Casework/optimisation",
  r"Fatima and Kabir start at the same time from the same point on a circular track of length $600$ m and run in opposite directions at constant speeds of $7$ m/s and $5$ m/s respectively. In the first $32$ minutes, how many times do they meet at a point other than the starting point? (The moment they start together is not a meeting.)",
  "TITA",
  r"They meet every $\frac{600}{12} = 50$ s, so in $1920$ s there are $\lfloor \frac{1920}{50} \rfloor = 38$ meetings. Fatima is at the start every $\frac{600}{7}$ s and Kabir every $120$ s, so both are there together every $\text{LCM}(\frac{600}{7}, 120) = 600$ s; in $1920$ s that happens at $600$, $1200$ and $1800$ s, which are $3$ of the meetings. Meetings elsewhere: $38 - 3 = 35$.",
  "Forgetting to remove the meetings at the starting point, or counting the start.",
  "C08D-circ-meetings-at-start-count", "Two separate counts (all meetings and those at the start) and their difference, with boundary care.",
  tita_answer=35, check=_c38,
  tita_traps=[(38, "Counts all meetings without removing those at the starting point."),
              (34, "Also removes the start as if it were a meeting at the starting point.")],
  exams=CX, cognitive="Analysis")


def _c39():
    vp, rest = 5, 40
    t_q = Fraction(900, vp)                 # Priya reaches Q
    t_meet = t_q + rest + Fraction(100, vp) # she has come back 100 m
    va = solve(Eq(symbols('a') * t_meet, 900 - 100), symbols('a'))[0]
    return 900 - va * t_q
q("C08-D-039", "Races", "Winning margin inferred from a turnaround meeting after a rest", "Difficult",
  "Multi-step word problem",
  r"Priya and Ananya start together from P and race $900$ m along a straight track to Q, each at her own constant speed; Priya runs at $5$ m/s. As soon as Priya reaches Q she rests for $40$ seconds, then runs back towards P at $5$ m/s and meets Ananya, who is still running towards Q, $100$ m from Q. By how many metres did Priya beat Ananya in the $900$ m race?",
  "MCQ",
  r"Priya reaches Q after $\frac{900}{5} = 180$ s, leaves at $220$ s and runs $100$ m back in $20$ s, so the meeting is at $240$ s. Ananya has run $800$ m in $240$ s, so her speed is $\frac{10}{3}$ m/s. When Priya finished at $180$ s, Ananya had run $180 \times \frac{10}{3} = 600$ m, so Priya won by $300$ m.",
  "Reading the speed ratio straight off the distances $1000 : 800$ and ignoring the rest.",
  "C08D-race-out-and-back", "The rest breaks the usual distance-ratio shortcut, so the meeting must be timed through three phases before the speed can be found.",
  correct=r"$300$ m",
  distractors=[(r"$180$ m", r"Ignores the rest and takes the speed ratio as $1000 : 800 = 5 : 4$: $900 - 720$."),
               (r"$600$ m", "Reports Ananya's distance when Priya finishes instead of the margin."),
               (r"$200$ m", r"Doubles the $100$ m, taking the meeting point as halfway between Q and Ananya's position at Priya's finish.")],
  check=_c39, values=[300, 180, 600, 200], exams=CX, cognitive="Analysis")


def _c40():
    L, vk = 1, 8
    count = 0
    for j in range(1, 8):
        t = _pair_times(L, 0, vk, 0, j, 100)[0]
        if _pos(L, 0, vk, t) == 0:
            count += 1
    return count
q("C08-D-040", "Circular tracks", "Speeds for which the first meeting is at the starting point", "Difficult",
  "Casework/optimisation",
  r"Kabir and Joseph start at the same time from the same point on a circular track and run in the same direction at constant speeds. Kabir runs at $8$ m/s, and Joseph's speed is a positive whole number of m/s less than $8$. For how many possible values of Joseph's speed is their first meeting after the start at the starting point itself?",
  "TITA",
  r"Let Joseph's speed be $j$ and the track $L$. They first meet after $\frac{L}{8-j}$, when Kabir has run $\frac{8}{8-j}$ laps. This meeting is at the start exactly when $\frac{8}{8-j}$ is a whole number, that is $8 - j$ divides $8$. With $1 \le j \le 7$, $8 - j \in \{1, 2, 4\}$, so $j = 7, 6, 4$: $3$ values.",
  "Including $j = 0$, or counting all speeds without the divisibility condition.",
  "C08D-circ-first-meet-at-start-condition", "Translate the condition into divisibility and run casework over all speeds.",
  tita_answer=3, check=_c40,
  tita_traps=[(4, "Includes the divisor $8$, which gives $j = 0$, not a positive speed."),
              (7, "Counts every whole-number speed below $8$.")],
  exams=CX, cognitive="Analysis")


def _c41():
    L = symbols('L', positive=True)
    Lv = solve(Eq((L - 47) / (L - 20), (L - 30) / L), L)[0]
    ratio = (Lv - 30) / Lv   # Kabir : Arjun
    return 400 - 400 * ratio
q("C08-D-041", "Races", "Unknown race length from three margins, then a new handicap", "Difficult",
  "Inverse/parameter",
  r"Ravi, Arjun and Kabir run a race together at constant speeds. When Ravi finishes, Arjun is $20$ m behind him and Kabir is $47$ m behind him. When Arjun finishes, Kabir is $30$ m behind him. How many metres of start should Arjun give Kabir in a $400$ m race so that it ends in a dead heat?",
  "MCQ",
  r"Let the race be $L$ m. The ratio of Kabir's speed to Arjun's is $\frac{L-47}{L-20}$ (from Ravi's finish) and also $\frac{L-30}{L}$ (from Arjun's finish). So $L(L-47) = (L-20)(L-30)$, giving $-47L = -50L + 600$ and $L = 200$. Kabir runs $170$ m while Arjun runs $200$ m, so in a $400$ m race Kabir runs $340$ m in Arjun's time and needs a start of $60$ m.",
  "Using a margin from the original race without rescaling, or chaining margins by subtraction.",
  "C08D-race-chain-solve-length", "Unknown race length must be found from a consistency equation before rescaling.",
  correct=r"$60$ m",
  distractors=[(r"$30$ m", "Uses Arjun's $30$ m margin without rescaling to $400$ m."),
               (r"$54$ m", "Takes Arjun's lead over Kabir as $47 - 20 = 27$ m and doubles it."),
               (r"$94$ m", "Doubles Ravi's $47$ m margin over Kabir.")],
  check=_c41, values=[60, 30, 54, 94], exams=CX, cognitive="Analysis")


def _c42():
    return _first_all(900, [(0, 10), (300, 8), (600, 3)], 100000)
q("C08-D-042", "Circular tracks", "Three runners from equally spaced points first together", "Difficult",
  "Casework/optimisation",
  r"Points P, Q and R divide a circular track of length $900$ m into three equal arcs, with Q $300$ m clockwise from P and R $300$ m clockwise from Q. At the same moment Arjun starts from P, Ravi from Q and Kabir from R, and all three run clockwise at constant speeds of $10$ m/s, $8$ m/s and $3$ m/s respectively. After how many seconds are all three at the same point for the first time?",
  "MCQ",
  r"Arjun is $300$ m behind Ravi and gains $2$ m/s, so they coincide at $150$ s and then every $\frac{900}{2} = 450$ s: $150, 600, 1050, \dots$. Ravi is $300$ m behind Kabir and gains $5$ m/s, so they coincide at $60$ s and then every $180$ s: $60, 240, 420, 600, \dots$. The first common time is $600$ s; then Arjun has run $6000$ m and all three are at R.",
  "Taking the first meeting of a single pair, or using the LCM of lap times as if all started together.",
  "C08D-circ-three-runners-diff-start", "Different starting points make the pairwise meeting sequences offset; needs matching two progressions.",
  correct=r"$600$ seconds",
  distractors=[(r"$150$ seconds", "Uses only the first meeting of Arjun and Ravi."),
               (r"$60$ seconds", "Uses only the first meeting of Ravi and Kabir."),
               (r"$900$ seconds", "Takes the LCM of the lap times $90$, $112.5$ and $300$ s, as if all started from one point.")],
  check=_c42, values=[600, 150, 60, 900], exams=CX, cognitive="Analysis")


def _c43():
    L, T = 400, 660
    sp = [10, 8, 5]
    total = 0
    for i in range(3):
        for j in range(i + 1, 3):
            total += len(_pair_times(L, 0, sp[i], 0, sp[j], T))
    return total
q("C08-D-043", "Circular tracks", "Total overtakings among three riders in a fixed time", "Difficult",
  "Casework/optimisation",
  r"Three cyclists start together from the same point on a $400$ m circular track and ride in the same direction at constant speeds of $10$ m/s, $8$ m/s and $5$ m/s. Each time a faster cyclist passes a slower one counts as one overtaking; if several cyclists are level at the same moment, every pair that passes counts separately, and the start does not count. How many overtakings take place in the first $11$ minutes?",
  "MCQ",
  r"For each pair, the number of overtakings in $660$ s is the number of whole laps gained: $\lfloor \frac{660 \times 2}{400} \rfloor = 3$ for $10$ and $8$, $\lfloor \frac{660 \times 5}{400} \rfloor = 8$ for $10$ and $5$, and $\lfloor \frac{660 \times 3}{400} \rfloor = 4$ for $8$ and $5$. The total is $3 + 8 + 4 = 15$. (At $400$ s all three are level, and that moment counts as one overtaking for each of the three pairs.)",
  "Rounding a lap gain up, counting the start, or merging a triple meeting into one event.",
  "C08D-circ-overtake-count", "Three pairwise counts with floors, a near-integer ($4.95$) and a simultaneous meeting.",
  correct=r"$15$",
  distractors=[(r"$16$", "Rounds $4.95$ laps gained by the $8$ m/s rider up to $5$."),
               (r"$18$", "Counts the start once for each of the three pairs."),
               (r"$13$", "Counts the moment at $400$ s, when all three are level, as a single overtaking.")],
  check=_c43, values=[15, 16, 18, 13], exams=CX, cognitive="Analysis")


def _c44():
    L = 600
    # clockwise positive; Ravi +6, Meera -2 from P; Meera changes to -4 at the second meeting
    m = _pair_times(L, 0, 6, 0, -2, 10000)
    t2 = m[1]
    p2 = _pos(L, 0, 6, t2)
    t3 = _pair_times(L, p2, 6, p2, -4, 10000)[0]
    return _pos(L, p2, 6, t3)
q("C08-D-044", "Circular tracks", "Third meeting point after one runner speeds up at the second meeting", "Difficult",
  "Multi-step word problem",
  r"Ravi and Meera start at the same time from point P on a circular track of length $600$ m. Ravi runs clockwise at a constant $6$ m/s and Meera runs anticlockwise at a constant $2$ m/s. At the moment they meet for the second time, Meera doubles her speed and keeps running anticlockwise; Ravi carries on unchanged. How far clockwise from P, measured along the track from $0$ m up to $600$ m, is the point where they meet for the third time?",
  "MCQ",
  r"At first they close a lap at $6 + 2 = 8$ m/s, meeting every $75$ s, so the second meeting is at $150$ s, when Ravi has run $900$ m and is $300$ m clockwise from P. From there they close a full lap at $6 + 4 = 10$ m/s, which takes $60$ s, during which Ravi runs $360$ m. The third meeting is at $300 + 360 = 660$ m, that is $60$ m clockwise from P.",
  "Ignoring the change, or applying it from the first meeting instead of the second.",
  "C08D-circ-speed-change-after-nth-meeting", "Three stages: locate the second meeting, switch relative speed, then reduce the position modulo the lap.",
  correct=r"$60$ m",
  distractors=[(r"$150$ m", r"Ignores the speed change: third meeting at $225$ s with Ravi at $1350$ m."),
               (r"$300$ m", "Gives the second meeting point."),
               (r"$570$ m", r"Applies the new speed from the first meeting ($450$ m at $75$ s), then adds $360$ m twice.")],
  check=_c44, values=[60, 150, 300, 570], exams=CX, cognitive="Analysis")


def _c45():
    L = 600
    speeds = [6, 5, 4]
    def sneha(t):
        d, clock = Fraction(0), Fraction(0)
        for k in range(100):
            v = speeds[min(k, 2)]
            dt = Fraction(L, v)
            if clock + dt >= t:
                return d + v * (t - clock)
            d += L
            clock += dt
    t = Fraction(0)
    step = Fraction(1, 4)
    while True:
        t += step
        if 5 * t >= sneha(t):
            assert 5 * t == sneha(t)
            return t
q("C08-D-045", "Circular tracks", "Catch-up when one runner's speed changes lap by lap", "Difficult",
  "Multi-step word problem",
  r"Sneha and Meera start together from the same point on a circular track of length $600$ m and run in the same direction. Sneha runs her first lap at $6$ m/s, her second lap at $5$ m/s, and every lap after that at $4$ m/s. Meera runs at a constant $5$ m/s throughout. After how many seconds is Meera level with Sneha for the first time after the start?",
  "MCQ",
  r"Sneha's first lap takes $100$ s, when Meera has run $500$ m, so Sneha leads by $100$ m. During Sneha's second lap ($120$ s, ending at $220$ s) both run at $5$ m/s and the lead stays $100$ m. From $220$ s Meera gains $1$ m/s and closes the $100$ m in $100$ s, at $320$ s. This is within Sneha's third lap ($150$ s long), so the answer is $320$ s.",
  "Ignoring the stretch at equal speed, or assuming the catch-up happens at a lap boundary.",
  "C08D-circ-variable-speed", "Piecewise motion with three phases; must track the lead through each phase.",
  correct=r"$320$ seconds",
  distractors=[(r"$200$ seconds", "Ignores the second lap and closes the $100$ m lead at $1$ m/s from $100$ s."),
               (r"$220$ seconds", "Assumes Meera draws level as soon as Sneha's speed drops below hers."),
               (r"$370$ seconds", "Assumes the catch-up happens at the end of Sneha's third lap, $220 + 150$.")],
  check=_c45, values=[320, 200, 220, 370], exams=CX, cognitive="Analysis")
