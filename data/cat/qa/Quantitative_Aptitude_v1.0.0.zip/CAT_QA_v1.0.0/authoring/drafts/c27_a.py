import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Two- and three-set problems"
TWO = ("CAT", "XAT")


def _solve(eqs, unknowns, expr):
    """Solve the linear system the stem gives and return expr; the value must be fully determined."""
    sol = solve(eqs, unknowns, dict=True)
    assert len(sol) == 1, sol
    v = simplify(sympify(expr).subs(sol[0]))
    assert not v.free_symbols, v
    return v


def _r2():
    # only P, only Q, both, neither
    return symbols('u_p u_q u_b u_n')


def _r3():
    # only P, only Q, only R, exactly P&Q, exactly Q&R, exactly P&R, all three, none
    return symbols('v_p v_q v_r v_pq v_qr v_pr v_t v_n')


def _pop3(p, qq, r, pq, qr, pr, t, n):
    """Explicit population: list of frozensets of the sets each person belongs to."""
    pop = []
    for cnt, s in ((p, "P"), (qq, "Q"), (r, "R"), (pq, "PQ"), (qr, "QR"), (pr, "PR"), (t, "PQR"), (n, "")):
        pop += [frozenset(s)] * int(cnt)
    return pop


# 1 ---------------------------------------------------------------------------
def _c1():
    p, qq, b, n = _r2()
    eqs = [p + qq + b + n - 120, p + b - 85, qq + b - 62, n]
    return _solve(eqs, [p, qq, b, n], b)
q("C27-A-001", TOPIC, "Two sets covering everyone: intersection from the two set sizes", "Easy",
  "Single-step computation",
  r"A housing society has $120$ families. $85$ of them subscribe to a daily newspaper, $62$ subscribe to a weekly magazine, and every family subscribes to at least one of the two. How many families subscribe to both?",
  "MCQ",
  r"Since every family takes at least one, the union is $120$. Then $85 + 62 - n(\text{both}) = 120$, so $n(\text{both}) = 147 - 120 = 27$.",
  "Subtracting the two set sizes, or reporting an 'only' region in place of the intersection.",
  "C27A-two-set-union-basic", "One application of $n(P \\cup Q) = n(P) + n(Q) - n(P \\cap Q)$ with the union equal to the total.",
  correct=r"$27$",
  distractors=[(r"$58$", "Reports the families taking only the newspaper, $85 - 27$."),
               (r"$35$", "Reports the families taking only the magazine, $62 - 27$."),
               (r"$23$", "Subtracts the two set sizes, $85 - 62$.")],
  check=_c1, values=[27, 58, 35, 23], cognitive="Application")

# 2 ---------------------------------------------------------------------------
def _c2():
    p, qq, b, n = _r2()
    eqs = [p + qq + b + n - 250, p + b - 140, qq + b - 90, b - 45]
    return _solve(eqs, [p, qq, b, n], n)
q("C27-A-002", TOPIC, "Two sets: number in neither from set sizes and overlap", "Easy",
  "Single-step computation",
  r"Of the $250$ employees of a firm, $140$ travel to work by metro, $90$ travel by bus and $45$ use both the metro and the bus. How many employees use neither the metro nor the bus? Type the number of employees.",
  "TITA",
  r"Employees using at least one of the two number $140 + 90 - 45 = 185$. Hence $250 - 185 = 65$ use neither.",
  "Forgetting to subtract the overlap, or subtracting it twice.",
  "C27A-two-set-neither", "Direct use of the two-set union formula and the complement.",
  tita_answer=65, check=_c2,
  tita_traps=[(20, "Does not subtract the overlap: $250 - (140 + 90) = 20$."),
              (110, "Subtracts the overlap twice, getting $140$ (those using exactly one) and $250 - 140 = 110$.")],
  cognitive="Application")

# 3 ---------------------------------------------------------------------------
def _c3():
    # population of 100 percent-units: build failure sets and count those in neither
    pop = [frozenset("ME")] * 14 + [frozenset("M")] * (32 - 14) + [frozenset("E")] * (26 - 14)
    pop += [frozenset()] * (100 - len(pop))
    assert sum("M" in s for s in pop) == 32 and sum("E" in s for s in pop) == 26
    return sum(1 for s in pop if not s)
q("C27-A-003", TOPIC, "Pass in both subjects from failure percentages", "Easy",
  "Single-step computation",
  r"In an examination, $32\%$ of the candidates failed in Mathematics, $26\%$ failed in English and $14\%$ failed in both subjects. What percentage of the candidates passed in both subjects?",
  "MCQ",
  r"The percentage failing in at least one subject is $32 + 26 - 14 = 44$. Passing in both means failing in neither, so the answer is $100 - 44 = 56\%$.",
  "Not adding back the candidates who failed in both, or treating only the double failures as failures.",
  "C27A-complement-counts", "Recognising that 'passed in both' is the complement of 'failed in at least one'.",
  correct=r"$56\%$",
  distractors=[(r"$42\%$", "Subtracts both failure figures from $100$ without adding back the $14\\%$ counted twice: $100 - 32 - 26$."),
               (r"$28\%$", "Subtracts the overlap as well: $100 - (32 + 26 + 14)$."),
               (r"$86\%$", "Treats only those failing in both subjects as failures: $100 - 14$.")],
  check=_c3, values=[56, 42, 28, 86], cognitive="Understanding")

# 4 ---------------------------------------------------------------------------
def _c4():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a - 40, b - 35, c - 25, pq + qr + pr - 50, t - 15, a + b + c + pq + qr + pr + t + n - 200]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], n)
q("C27-A-004", TOPIC, "Three sets: none from the disjoint regions", "Easy",
  "Single-step computation",
  r"A gym has $200$ members. Of them, $40$ attend only yoga, $35$ attend only zumba, $25$ attend only swimming, $50$ attend exactly two of these three activities and $15$ attend all three. How many members attend none of the three activities?",
  "MCQ",
  r"The groups 'only yoga', 'only zumba', 'only swimming', 'exactly two' and 'all three' do not overlap, so together they contain $40 + 35 + 25 + 50 + 15 = 165$ members. The rest, $200 - 165 = 35$, attend none.",
  "Leaving out one of the disjoint regions, or treating the regions as overlapping.",
  "C27A-three-set-region-sum", "The regions are already disjoint; the only trap is to omit or double count one.",
  correct=r"$35$",
  distractors=[(r"$50$", "Leaves out the $15$ members who attend all three: $200 - 150$."),
               (r"$65$", "Reports the members attending at least two activities, $50 + 15$."),
               (r"$5$", "Counts each all-three member once per activity, subtracting $3 \\times 15 = 45$: $200 - 100 - 50 - 45$.")],
  check=_c4, values=[35, 50, 65, 5], cognitive="Understanding")

# 5 ---------------------------------------------------------------------------
def _c5():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + pq + pr + t - 48, b + pq + qr + t - 40, c + qr + pr + t - 36,
           pq + t - 15, qr + t - 12, pr + t - 10, t - 6, n]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], a + b + c + pq + qr + pr + t + n)
q("C27-A-005", TOPIC, "Three sets: total membership by inclusion and exclusion", "Easy",
  "Single-step computation",
  r"Every member of a sports club plays at least one of chess, carrom and table tennis. $48$ members play chess, $40$ play carrom and $36$ play table tennis. $15$ play both chess and carrom, $12$ play both carrom and table tennis, $10$ play both chess and table tennis, and $6$ play all three games. How many members does the club have? Type the number of members.",
  "TITA",
  r"By inclusion and exclusion, the number playing at least one game is $48 + 40 + 36 - 15 - 12 - 10 + 6 = 124 - 37 + 6 = 93$. Since everyone plays at least one, the club has $93$ members.",
  "Forgetting to add back the members who play all three games.",
  "C27A-three-set-inclusion-exclusion", "Single use of the three-set formula; the trap is the final add-back.",
  tita_answer=93, check=_c5,
  tita_traps=[(87, "Omits the final $+6$ for the members playing all three."),
              (124, "Adds the three game totals without removing overlaps.")],
  cognitive="Application")

# 6 ---------------------------------------------------------------------------
def _c6():
    p, qq, b, n = _r2()  # P = tea, Q = coffee
    eqs = [p + qq + b + n - 60, qq + b - 35, b - 11, n - 7]
    return _solve(eqs, [p, qq, b, n], p)
q("C27-A-006", TOPIC, "Two sets: only one set from total, other set and neither", "Easy",
  "Multi-step word problem",
  r"In a class of $60$ students, each student was asked whether they like tea and whether they like coffee. $35$ students like coffee, $11$ like both tea and coffee, and $7$ like neither. How many students like tea but not coffee?",
  "MCQ",
  r"Students who like at least one drink number $60 - 7 = 53$. Of these, $35$ like coffee, so the remaining $53 - 35 = 18$ like tea but not coffee. (Tea lovers in all are $18 + 11 = 29$.)",
  "Reporting all tea lovers instead of those who like only tea, or ignoring the students who like neither.",
  "C27A-two-set-union-basic", "Two short steps, with the 'only' versus 'total' trap.",
  correct=r"$18$",
  distractors=[(r"$29$", "Reports all students who like tea, including the $11$ who also like coffee."),
               (r"$25$", "Ignores the $7$ who like neither: $60 - 35$."),
               (r"$7$", "Removes the $11$ who like both a second time: $60 - 7 - 35 - 11$.")],
  check=_c6, values=[18, 29, 25, 7], cognitive="Application")

# 7 ---------------------------------------------------------------------------
def _c7():
    # Jaipur is a subset of Agra: enumerate tourists
    tourists = [frozenset("AJ")] * 34 + [frozenset("A")] * (52 - 34)
    tourists += [frozenset()] * (80 - len(tourists))
    assert sum("A" in s for s in tourists) == 52 and sum("J" in s for s in tourists) == 34
    return sum(1 for s in tourists if len(s) == 1)
q("C27-A-007", TOPIC, "Two sets where one set lies inside the other", "Easy",
  "Conceptual/application",
  r"Of $80$ tourists in a group, $52$ visited Agra and $34$ visited Jaipur. Every tourist who visited Jaipur also visited Agra. How many tourists visited exactly one of the two cities?",
  "MCQ",
  r"All $34$ Jaipur visitors are among the Agra visitors, so $34$ visited both cities. Those who visited exactly one city visited only Agra: $52 - 34 = 18$. (The other $80 - 52 = 28$ visited neither.)",
  "Assuming that every tourist visited at least one city, which forces a wrong overlap.",
  "C27A-subset-disjoint-conditions", "Needs the insight that the subset condition fixes the overlap; one subtraction after that.",
  correct=r"$18$",
  distractors=[(r"$28$", "Reports the tourists who visited neither city, $80 - 52$."),
               (r"$74$", "Assumes all $80$ visited at least one city, so the overlap is $52 + 34 - 80 = 6$ and exactly one is $80 - 6$."),
               (r"$46$", "Counts everyone who did not visit Jaipur, $80 - 34$.")],
  check=_c7, values=[18, 28, 74, 46], cognitive="Understanding")

# 8 ---------------------------------------------------------------------------
def _c8():
    p, qq, b, n = _r2()
    eqs = [p + qq + b + n - 100, p + b - 62, qq + b - 45, n - 18]
    return _solve(eqs, [p, qq, b, n], b)
q("C27-A-008", TOPIC, "Two sets in percentages: overlap from sizes and neither", "Easy",
  "Single-step computation",
  r"In a town, $62\%$ of the adults read a Hindi newspaper, $45\%$ read an English newspaper and $18\%$ read neither. What percentage of the adults read both a Hindi and an English newspaper?",
  "MCQ",
  r"Adults reading at least one paper make up $100 - 18 = 82\%$. So $62 + 45 - x = 82$, giving $x = 25\%$.",
  "Taking the union as $100\\%$ and ignoring those who read neither.",
  "C27A-two-set-union-basic", "One equation; the trap is the 'neither' group.",
  correct=r"$25\%$",
  distractors=[(r"$7\%$", "Ignores the $18\\%$ who read neither and uses $62 + 45 - 100$."),
               (r"$37\%$", "Reports the adults who read only a Hindi paper, $62 - 25$."),
               (r"$20\%$", "Reports the adults who read only an English paper, $45 - 25$.")],
  check=_c8, values=[25, 7, 37, 20], cognitive="Application")

# 9 ---------------------------------------------------------------------------
def _c9():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [pq + t - 22, qr + t - 18, pr + t - 15, t - 7]
    return _solve(eqs, [pq, qr, pr, t], pq + qr + pr)
q("C27-A-009", TOPIC, "Exactly two from pairwise intersections and all three", "Easy",
  "Conceptual/application",
  r"In a survey of households about three streaming services P, Q and R, $22$ households subscribe to both P and Q, $18$ subscribe to both Q and R, $15$ subscribe to both P and R, and $7$ subscribe to all three. Each 'both' figure includes the households that subscribe to all three. How many households subscribe to exactly two of the three services? Type the number of households.",
  "TITA",
  r"Each pairwise figure contains the $7$ all-three households, so the exactly-two counts are $22 - 7 = 15$, $18 - 7 = 11$ and $15 - 7 = 8$. Their sum is $34$, which is also $22 + 18 + 15 - 3 \times 7$.",
  "Adding the pairwise figures directly, or removing the all-three group only once.",
  "C27A-exactly-two-from-pairwise", "Requires seeing that each pairwise count includes the triple overlap.",
  tita_answer=34, check=_c9,
  tita_traps=[(55, "Adds the three pairwise figures without removing the all-three households."),
              (48, "Removes the $7$ all-three households only once: $55 - 7$.")],
  cognitive="Understanding")

# 10 --------------------------------------------------------------------------
def _c10():
    F, H = symbols('F H')
    s = solve([F - 2 * H, F + H - 24 - (180 - 30)], [F, H], dict=True)[0]
    return s[F] - 24
q("C27-A-010", TOPIC, "Two sets linked by a ratio of set sizes", "Medium",
  "Multi-step word problem",
  r"In a college of $180$ students, $30$ play neither football nor hockey. The number of students who play football is twice the number who play hockey, and $24$ students play both games. How many students play football but not hockey?",
  "MCQ",
  r"Let $h$ students play hockey, so $2h$ play football. Those playing at least one game number $150$, so $2h + h - 24 = 150$ and $h = 58$. Football players number $116$, and those playing only football number $116 - 24 = 92$.",
  "Applying the ratio to the 'only' groups instead of the full set sizes, or ignoring the students who play neither.",
  "C27A-two-set-linked-regions", "Combines a ratio condition with the union formula, then converts a total into an 'only' count.",
  correct=r"$92$",
  distractors=[(r"$116$", "Reports all football players, including the $24$ who also play hockey."),
               (r"$112$", "Ignores the $30$ who play neither: $3h - 24 = 180$ gives $h = 68$ and $136 - 24$."),
               (r"$84$", "Applies the ratio $2 : 1$ to the 'only' groups: those split $150 - 24 = 126$ as $84$ and $42$.")],
  check=_c10, values=[92, 116, 112, 84], cognitive="Application")

# 11 --------------------------------------------------------------------------
def _c11():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + pq + pr + t - 60, b + pq + qr + t - 50, c + qr + pr + t - 45,
           pq + t - 20, qr + t - 15, pr + t - 18, t - 8]
    return _solve(eqs, [a, b, c, pq, qr, pr, t], a + b + c)
q("C27-A-011", TOPIC, "Three sets: exactly one from set sizes and pairwise overlaps", "Medium",
  "Multi-step word problem",
  r"A reading room stocks three newspapers P, Q and R. Among its members, $60$ read P, $50$ read Q and $45$ read R; $20$ read both P and Q, $15$ read both Q and R, $18$ read both P and R, and $8$ read all three. (Each 'both' figure includes those who read all three.) How many members read exactly one of the three newspapers? Type the number of members.",
  "TITA",
  r"Only P $= 60 - 20 - 18 + 8 = 30$, only Q $= 50 - 20 - 15 + 8 = 23$ and only R $= 45 - 15 - 18 + 8 = 20$. Exactly one is $30 + 23 + 20 = 73$. Equivalently, $\Sigma n - 2\Sigma n_2 + 3n_3 = 155 - 106 + 24 = 73$.",
  "Confusing 'at least one' with 'exactly one', or not adding back the triple overlap enough times.",
  "C27A-exactly-one-from-pairwise", "Three region computations, each needing the triple overlap added back once.",
  tita_answer=73, check=_c11,
  tita_traps=[(110, "Computes the number reading at least one newspaper, $155 - 53 + 8$."),
              (49, "Uses $155 - 2 \\times 53$ and forgets to add back $3 \\times 8$.")],
  cognitive="Application")

# 12 --------------------------------------------------------------------------
def _c12():
    p, qq, b, n = _r2()  # P = chess, Q = carrom
    eqs = [p + qq + b + n - 80, (qq + n) - 50, (p + n) - 45, n - 20]
    return _solve(eqs, [p, qq, b, n], b)
q("C27-A-012", TOPIC, "Two sets given through their complements", "Medium",
  "Conceptual/application",
  r"In a hostel of $80$ students, $50$ students do not play chess, $45$ do not play carrom, and $20$ play neither chess nor carrom. How many students play both chess and carrom?",
  "MCQ",
  r"Chess players number $80 - 50 = 30$ and carrom players $80 - 45 = 35$. Those playing at least one game number $80 - 20 = 60$, so both $= 30 + 35 - 60 = 5$.",
  "Working directly with the 'do not play' counts as if they were the sets themselves.",
  "C27A-complement-counts", "Data are given as complements; the student must convert before using the union formula.",
  correct=r"$5$",
  distractors=[(r"$15$", "Adds the two 'do not play' counts and subtracts the hostel size: $50 + 45 - 80$."),
               (r"$25$", "Reports the students who play chess but not carrom, $30 - 5$."),
               (r"$30$", "Reports the students who play carrom but not chess, $35 - 5$.")],
  check=_c12, values=[5, 15, 25, 30], cognitive="Analysis")

# 13 --------------------------------------------------------------------------
def _c13():
    # E1 + E2 + E3 = 50 (everyone in at least one), E1 + 2E2 + 3E3 = 25 + 20 + 22, E3 = 6
    e1, e2, e3 = symbols('e1 e2 e3')
    s = solve([e1 + e2 + e3 - 50, e1 + 2 * e2 + 3 * e3 - (25 + 20 + 22), e3 - 6], [e1, e2, e3], dict=True)[0]
    # confirm with an explicit roster consistent with the givens
    roster = _pop3(16, 10, 13, 2, 2, 1, 6, 0)
    assert len(roster) == 50 and sum("P" in x for x in roster) == 25 and sum("Q" in x for x in roster) == 20
    assert sum("R" in x for x in roster) == 22 and sum(len(x) == 3 for x in roster) == 6
    assert sum(len(x) == 1 for x in roster) == s[e1]
    return s[e1]
q("C27-A-013", TOPIC, "Exactly one from the total of set sizes and the all-three count", "Medium",
  "Conceptual/application",
  r"Each of the $50$ students in a class studies at least one of French, German and Spanish. $25$ study French, $20$ study German, $22$ study Spanish, and $6$ study all three languages. How many students study exactly one language? Type the number of students.",
  "TITA",
  r"Let $e_1, e_2, e_3$ be the numbers studying exactly one, two and three languages. Then $e_1 + e_2 + e_3 = 50$ and, counting language enrolments, $e_1 + 2e_2 + 3e_3 = 67$. Subtracting, $e_2 + 2e_3 = 17$, so $e_2 = 5$ and $e_1 = 50 - 5 - 6 = 39$.",
  "Not realising that each all-three student is counted three times in the sum of the set sizes.",
  "C27A-membership-sum-identity", "Needs the weighted-count identity rather than the usual formula, since pairwise data are absent.",
  tita_answer=39, check=_c13,
  tita_traps=[(27, "Takes $e_2 = 67 - 50 = 17$, ignoring the extra count of all-three students, then $50 - 17 - 6$."),
              (44, "Subtracts only the all-three students from the class: $50 - 6$.")],
  cognitive="Analysis")

# 14 --------------------------------------------------------------------------
def _c14():
    p, qq, b, n = _r2()
    eqs = [p + qq + b + n - 92, p - qq, b - 14, n - 10]
    return _solve(eqs, [p, qq, b, n], p + b)
q("C27-A-014", TOPIC, "Two sets with equal 'only' groups", "Medium",
  "Multi-step word problem",
  r"A club has $92$ members. $14$ members play both badminton and squash, $10$ play neither, and the number who play only badminton equals the number who play only squash. How many members play badminton?",
  "MCQ",
  r"Members playing exactly one game number $92 - 10 - 14 = 68$, split equally, so $34$ play only badminton. Badminton players in all are $34 + 14 = 48$.",
  "Reporting the 'only badminton' figure, or ignoring the members who play neither.",
  "C27A-two-set-linked-regions", "Two steps: remove the fixed groups, split the rest, then add the overlap back.",
  correct=r"$48$",
  distractors=[(r"$34$", "Reports the members who play only badminton."),
               (r"$53$", "Ignores the $10$ who play neither: $\\frac{92 - 14}{2} + 14$."),
               (r"$46$", "Splits the whole club equally between the two games, $\\frac{92}{2}$.")],
  check=_c14, values=[48, 34, 53, 46], cognitive="Application")

# 15 --------------------------------------------------------------------------
def _c15():
    a, b, c, pq, qr, pr, t = symbols('a b c pq qr pr t')
    eqs = [a - 12, b - 9, c - 15, a + pq + pr + t - 26, b + pq + qr + t - 22, c + qr + pr + t - 27, t - 3]
    return _solve(eqs, [a, b, c, pq, qr, pr, t], pq + qr + pr)
q("C27-A-015", TOPIC, "Exactly two from set sizes, 'only' counts and all three", "Medium",
  "Multi-step word problem",
  r"Employees of a company could opt for any of three benefits: a gym pass, a meal card and a transport allowance. $26$ employees opted for the gym pass, $22$ for the meal card and $27$ for the transport allowance. $12$ opted for the gym pass only, $9$ for the meal card only and $15$ for the transport allowance only, while $3$ opted for all three. How many employees opted for exactly two of the benefits? Type the number of employees.",
  "TITA",
  r"Removing the 'only' groups and the all-three group from each benefit leaves its exactly-two members: $26 - 12 - 3 = 11$, $22 - 9 - 3 = 10$ and $27 - 15 - 3 = 9$. Each exactly-two employee is counted in two of these, so the number is $\frac{11 + 10 + 9}{2} = 15$.",
  "Forgetting that each exactly-two employee appears in two of the benefit totals.",
  "C27A-only-counts-to-overlaps", "Needs the double-counting insight; the regions cannot be found one by one.",
  tita_answer=15, check=_c15,
  tita_traps=[(30, "Adds $11 + 10 + 9$ and forgets to halve."),
              (18, "Removes the all-three group once in total instead of from each benefit: $\\frac{14 + 13 + 12 - 3}{2}$.")],
  cognitive="Analysis")

# 16 --------------------------------------------------------------------------
def _c16():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + pq + pr + t - 45, b + pq + qr + t - 38, c + qr + pr + t - 30,
           pq + t - 15, qr + t - 12, pr + t - 10, t - 5, a + b + c + pq + qr + pr + t + n - 100]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], n)
q("C27-A-016", TOPIC, "Three sets in percentages: none by inclusion and exclusion", "Medium",
  "Multi-step word problem",
  r"In a city survey, $45\%$ of the households watch channel P, $38\%$ watch channel Q and $30\%$ watch channel R. $15\%$ watch both P and Q, $12\%$ watch both Q and R, $10\%$ watch both P and R, and $5\%$ watch all three. (Each 'both' figure includes those watching all three.) What percentage of the households watch none of the three channels?",
  "MCQ",
  r"Households watching at least one channel make up $45 + 38 + 30 - 15 - 12 - 10 + 5 = 113 - 37 + 5 = 81\%$. So $100 - 81 = 19\%$ watch none.",
  "Mishandling the all-three term in the inclusion and exclusion formula.",
  "C27A-three-set-inclusion-exclusion", "Full three-set formula in percentages plus the complement; sign errors are common.",
  correct=r"$19\%$",
  distractors=[(r"$24\%$", "Omits the $+5$ for all three: union $76\\%$."),
               (r"$29\%$", "Subtracts the all-three figure instead of adding it: union $71\\%$."),
               (r"$14\%$", "Adds the all-three figure back twice: union $86\\%$.")],
  check=_c16, values=[19, 24, 29, 14], cognitive="Application")

# 17 --------------------------------------------------------------------------
def _c17():
    N = symbols('N', positive=True)
    neither = N - (Rational(40, 100) * N + Rational(35, 100) * N - Rational(20, 100) * N)
    return solve(Eq(neither, 180), N)[0]
q("C27-A-017", TOPIC, "Two sets in percentages: total surveyed from the neither count", "Medium",
  "Inverse/parameter",
  r"In a survey, $40\%$ of the people questioned said they like apples, $35\%$ said they like bananas and $20\%$ said they like both. The remaining $180$ people like neither fruit. How many people were questioned? Type the number of people.",
  "TITA",
  r"People liking at least one fruit make up $40 + 35 - 20 = 55\%$, so $45\%$ like neither. Hence $0.45N = 180$ and $N = 400$.",
  "Forgetting to subtract the overlap when finding the share who like at least one.",
  "C27A-two-set-neither", "Works backwards from a count to the total through the union percentage.",
  tita_answer=400, check=_c17,
  tita_traps=[(720, "Takes the union as $75\\%$, so neither is $25\\%$ and $N = \\frac{180}{0.25}$."),
              (3600, "Subtracts the overlap as well, $100 - 40 - 35 - 20 = 5\\%$, and $N = \\frac{180}{0.05}$.")],
  cognitive="Application")

# 18 --------------------------------------------------------------------------
def _c18():
    e1, e2, e3 = symbols('e1 e2 e3')
    s = solve([e1 + e2 + e3 - 325, e1 - 2 * e2, e3 - e2 / 4], [e1, e2, e3], dict=True)[0]
    return s[e1] + 2 * s[e2] + 3 * s[e3]
q("C27-A-018", TOPIC, "Sum of set sizes from the exactly-one, two and three groups", "Medium",
  "Conceptual/application",
  r"Each of the $325$ students of a school is enrolled in at least one of three activities: music, dance and drama. The number of students enrolled in exactly one activity is twice the number enrolled in exactly two, and the number enrolled in all three is one fourth of the number enrolled in exactly two. Each activity keeps a roll of its own students. What is the total number of names on the three rolls taken together?",
  "MCQ",
  r"Let $4k$ students be in exactly two activities; then $8k$ are in exactly one and $k$ in all three, so $13k = 325$ and $k = 25$. The groups are $200$, $100$ and $25$. Names on the rolls: $200 \times 1 + 100 \times 2 + 25 \times 3 = 475$.",
  "Counting each student once regardless of how many rolls carry the name.",
  "C27A-membership-sum-identity", "Needs the weighted count of memberships after solving the ratio conditions.",
  correct=r"$475$",
  distractors=[(r"$325$", "Counts each student once, giving the number of students rather than names."),
               (r"$425$", "Counts the exactly-two students twice but the all-three students only once: $200 + 200 + 25$."),
               (r"$450$", "Counts the all-three students twice instead of three times: $200 + 200 + 50$.")],
  check=_c18, values=[475, 325, 425, 450], cognitive="Analysis")

# 19 --------------------------------------------------------------------------
def _c19():
    # P physics, Q chemistry, R biology. R inside P, R disjoint from Q, so no one in all three.
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + b + c + pq + qr + pr + t + n - 100, a + pq + pr + t - 55, b + pq + qr + t - 40,
           c + qr + pr + t - 25, c, qr, t, pq + t - 15]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], a)
q("C27-A-019", TOPIC, "Three sets with a subset and a disjointness condition", "Medium",
  "Conceptual/application",
  r"Of the $100$ students in a batch, $55$ take Physics, $40$ take Chemistry and $25$ take Biology. Every student who takes Biology also takes Physics, no student who takes Biology takes Chemistry, and $15$ students take both Physics and Chemistry. How many students take Physics but neither Chemistry nor Biology?",
  "MCQ",
  r"All $25$ Biology students are inside Physics and outside Chemistry, so nobody takes all three. Physics therefore splits into Physics with Chemistry ($15$), Physics with Biology ($25$), and Physics alone. Physics alone is $55 - 15 - 25 = 15$.",
  "Ignoring that the Biology students form a separate part of the Physics group.",
  "C27A-subset-disjoint-conditions", "Translating the subset and disjointness conditions into the region picture is the whole problem.",
  correct=r"$15$",
  distractors=[(r"$40$", "Removes only the Physics and Chemistry overlap, $55 - 15$, forgetting the Biology students inside Physics."),
               (r"$30$", "Removes only the Biology students, $55 - 25$."),
               (r"$20$", "Reports the students taking none of the three, $100 - (55 + 40 - 15)$.")],
  check=_c19, values=[15, 40, 30, 20], cognitive="Analysis")

# 20 --------------------------------------------------------------------------
def _c20():
    p, qq, b, n = _r2()
    eqs = [p + qq + b + n - 75, p + b - 48, qq + b - 39, p + qq - 45]
    return _solve(eqs, [p, qq, b, n], n)
q("C27-A-020", TOPIC, "Two sets: neither from the exactly-one count", "Medium",
  "Inverse/parameter",
  r"In a group of $75$ people, $48$ own a car and $39$ own a motorbike. Exactly $45$ people own exactly one of the two vehicles. How many people own neither a car nor a motorbike? Type the number of people.",
  "TITA",
  r"If $x$ own both, the number owning exactly one is $48 + 39 - 2x = 45$, so $x = 21$. Those owning at least one number $48 + 39 - 21 = 66$, so $75 - 66 = 9$ own neither.",
  "Treating 'exactly one' as 'at least one', which removes the overlap only once.",
  "C27A-two-set-exactly-one", "Requires the exactly-one relation $n(P) + n(Q) - 2n(P \\cap Q)$ before the complement.",
  tita_answer=9, check=_c20,
  tita_traps=[(30, "Treats the $45$ as everyone owning a vehicle, so neither is $75 - 45$."),
              (21, "Stops after finding the number who own both.")],
  cognitive="Analysis")

# 21 --------------------------------------------------------------------------
def _c21():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + b + c + pq + qr + pr + t + n - 60, n - 9, a + pq + pr + t - 22, b + pq + qr + t - 29,
           c + qr + pr + t - 22, pq - 5, qr - 7, pr - 4]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], a + b + c)
q("C27-A-021", TOPIC, "All three and exactly one from 'but not' pair counts", "Difficult",
  "Multi-step word problem",
  r"A survey of $60$ students asked which of three hobbies P, Q and R they pursue; $9$ pursue none. $22$ pursue P, $29$ pursue Q and $22$ pursue R. Further, $5$ pursue P and Q but not R, $7$ pursue Q and R but not P, and $4$ pursue P and R but not Q. How many students pursue exactly one of the three hobbies?",
  "MCQ",
  r"Exactly two pursue $5 + 7 + 4 = 16$, and at least one pursue $60 - 9 = 51$. If $t$ pursue all three, counting memberships gives $e_1 + 2(16) + 3t = 73$ and $e_1 + 16 + t = 51$. Subtracting, $16 + 2t = 22$, so $t = 3$ and $e_1 = 51 - 16 - 3 = 32$.",
  "Leaving out the all-three group, or forgetting the students who pursue none.",
  "C27A-but-not-pairs-to-all-three", "The given pair counts are exact regions, so the all-three count must be extracted first from two equations.",
  correct=r"$32$",
  distractors=[(r"$35$", "Leaves out the all-three group: $51 - 16$."),
               (r"$41$", "Finds $t = 3$ correctly but then subtracts from the survey size $60$ instead of the $51$ who pursue at least one: $60 - 16 - 3$."),
               (r"$38$", "Removes the all-three group once instead of three times from the membership total: $73 - 32 - 3$.")],
  check=_c21, values=[32, 35, 41, 38], cognitive="Analysis", exams=TWO)

# 22 --------------------------------------------------------------------------
def _c22():
    vm, vw, nm, nw = symbols('vm vw nm nw')
    s = solve([vm + vw + nm + nw - 120, vm + vw - 48, vm - vw - 6, nm - 2 * nw], [vm, vw, nm, nw], dict=True)
    assert len(s) == 1
    s = s[0]
    assert all(v >= 0 and v == int(v) for v in s.values())
    return s[vm] + s[nm]
q("C27-A-022", TOPIC, "Club split by gender crossed with diet: men from a difference and a ratio", "Medium",
  "Multi-step word problem",
  r"A club has $120$ members, each a man or a woman. $48$ members are vegetarian, and there are $6$ more vegetarian men than vegetarian women. Among the members who are not vegetarian, there are twice as many men as women. How many men does the club have?",
  "MCQ",
  r"Vegetarian men and women add to $48$ and differ by $6$, so there are $27$ vegetarian men and $21$ vegetarian women. The $120 - 48 = 72$ non-vegetarians split $2 : 1$, giving $48$ men and $24$ women. Men in all: $27 + 48 = 75$.",
  "Applying a condition stated for one part of the club to the whole club, or reporting only one part of the men.",
  "C27A-attribute-partition", "Two attributes cross to give four regions; a sum and difference fixes one pair and a ratio fixes the other, then two regions are added.",
  correct=r"$75$",
  distractors=[(r"$48$", "Reports only the men who are not vegetarian."),
               (r"$80$", "Applies the $2 : 1$ ratio of men to women to the whole club: $\\frac{2}{3} \\times 120$."),
               (r"$78$", "Takes the vegetarian men as half the vegetarians plus the difference, $24 + 6 = 30$, then $30 + 48$.")],
  check=_c22, values=[75, 48, 80, 78], cognitive="Application")

# 23 --------------------------------------------------------------------------
def _c23():
    x, P, Q = symbols('x P Q', positive=True)
    s = solve([Eq(x, Rational(40, 100) * P), Eq(x, Rational(25, 100) * Q), Eq(P + Q - x, 286)], [x, P, Q], dict=True)[0]
    return s[x]
q("C27-A-023", TOPIC, "Overlap given as a percentage of each set", "Medium",
  "Inverse/parameter",
  r"Among the readers of two magazines P and Q, $40\%$ of the readers of P also read Q, and $25\%$ of the readers of Q also read P. If $286$ people read at least one of the two magazines, how many read both?",
  "MCQ",
  r"Let $x$ read both. Then P has $\frac{x}{0.4} = 2.5x$ readers and Q has $\frac{x}{0.25} = 4x$. The union is $2.5x + 4x - x = 5.5x = 286$, so $x = 52$.",
  "Adding the two set sizes without removing the overlap.",
  "C27A-conditional-fraction-of-set", "The overlap is expressed relative to two different bases and must be converted to set sizes first.",
  correct=r"$52$",
  distractors=[(r"$44$", "Takes the union as $2.5x + 4x = 6.5x$, without removing the overlap."),
               (r"$78$", "Reports the readers of P only, $2.5x - x$."),
               (r"$130$", "Reports all readers of P, $2.5x$.")],
  check=_c23, values=[52, 44, 78, 130], cognitive="Application")

# 24 --------------------------------------------------------------------------
def _c24():
    p, qq, b = symbols('p qq b')
    s = solve([p + b - 40, b - 18, p + qq - 46], [p, qq, b], dict=True)[0]
    return s[qq] + s[b]
q("C27-A-024", TOPIC, "Two sets: second set from 'one but not both' data", "Medium",
  "Multi-step word problem",
  r"In a residents' association, $46$ members speak Hindi or Marathi but not both, and $18$ speak both languages. If $40$ members speak Hindi, how many speak Marathi?",
  "MCQ",
  r"Members who speak only Hindi number $40 - 18 = 22$. Of the $46$ who speak exactly one language, the other $46 - 22 = 24$ speak only Marathi. Marathi speakers in all number $24 + 18 = 42$.",
  "Reading 'Hindi or Marathi but not both' as 'at least one of the two'.",
  "C27A-two-set-exactly-one", "Requires splitting the exactly-one group correctly before adding the overlap.",
  correct=r"$42$",
  distractors=[(r"$24$", "Treats $46$ as the number speaking at least one language: $46 - 40 + 18$."),
               (r"$64$", "Reports the members speaking at least one language, $46 + 18$."),
               (r"$60$", "Adds the $18$ bilingual members to the Marathi total a second time: $42 + 18$.")],
  check=_c24, values=[42, 24, 64, 60], cognitive="Application")

# 25 --------------------------------------------------------------------------
def _c25():
    k, m, t = symbols('k m t')
    eqs = [4 * k + 2 * m + t - 62, 3 * k + 2 * m + t - 52, 2 * k + 2 * m + t - 42, 9 * k + 3 * m + t - 120]
    s = solve(eqs, [k, m, t], dict=True)
    assert len(s) == 1
    s = s[0]
    roster = _pop3(4 * s[k], 3 * s[k], 2 * s[k], s[m], s[m], s[m], s[t], 0)
    assert len(roster) == 120 and sum("P" in x for x in roster) == 62
    assert sum("Q" in x for x in roster) == 52 and sum("R" in x for x in roster) == 42
    return sum(1 for x in roster if len(x) == 3)
q("C27-A-025", TOPIC, "Three sets with ratio and equality conditions on regions", "Difficult",
  "Inverse/parameter",
  r"Each of the $120$ members of a library uses at least one of its three services P, Q and R. The numbers of members who use only P, only Q and only R are in the ratio $4 : 3 : 2$. The number who use exactly P and Q (and not R), the number who use exactly Q and R (and not P), and the number who use exactly P and R (and not Q) are all equal. If $62$ members use P, $52$ use Q and $42$ use R, how many members use all three services? Type the number of members.",
  "TITA",
  r"Let the 'only' groups be $4k, 3k, 2k$, each exactly-two group $m$ and all three $t$. Then P gives $4k + 2m + t = 62$ and Q gives $3k + 2m + t = 52$, so $k = 10$ and $2m + t = 22$. The total gives $9k + 3m + t = 120$, so $3m + t = 30$. Subtracting, $m = 8$ and $t = 6$.",
  "Stopping at the size of one exactly-two group, or mixing up exactly-two and all-three counts.",
  "C27A-three-set-ratio-conditions", "Three unknowns from structural conditions; the difference of two set sizes is the key first step.",
  tita_answer=6, check=_c25,
  tita_traps=[(8, "Reports the size of each exactly-two group."),
              (24, "Reports the total of the three exactly-two groups, $3m$.")],
  cognitive="Analysis", exams=TWO)

# 26 --------------------------------------------------------------------------
def _c26():
    # P = tea, Q = coffee, R = juice, in percentage units of the office
    a, b, c, pq, qr, pr, t, n = _r3()
    P = a + pq + pr + t; Q = b + pq + qr + t; R = c + qr + pr + t
    eqs = [a + b + c + pq + qr + pr + t + n - 100, P - 50,
           (pq + t) - Rational(36, 100) * P, (pq + t) - Rational(45, 100) * Q,
           (qr + t) - Rational(15, 100) * Q, (qr + t) - Rational(1, 2) * R,
           pr, t]  # no juice drinker drinks tea
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], n)
q("C27-A-026", TOPIC, "Three sets built from a chain of conditional percentages with one disjoint pair", "Difficult",
  "Multi-step word problem",
  r"In an office, $50\%$ of the employees drink tea. Of the tea drinkers, $36\%$ also drink coffee. Of the coffee drinkers, $45\%$ also drink tea and $15\%$ also drink juice. Exactly half of the juice drinkers also drink coffee, and no juice drinker drinks tea. What percentage of the employees drink none of the three?",
  "MCQ",
  r"Tea and coffee: $0.36 \times 50 = 18\%$ of the office, which is $45\%$ of the coffee drinkers, so coffee drinkers are $40\%$. Coffee and juice: $0.15 \times 40 = 6\%$, which is half the juice drinkers, so juice drinkers are $12\%$. Juice never meets tea, so the union is $50 + 40 + 12 - 18 - 6 = 78\%$ and none is $100 - 78 = 22\%$.",
  "Reading a percentage of a subgroup as a percentage of the whole office, or dropping one of the two overlaps.",
  "C27A-conditional-fraction-of-set", "Four conversions on four different bases are chained before a three-set union with one empty pairwise region can be formed.",
  correct=r"$22\%$",
  distractors=[(r"$16\%$", "Treats the juice drinkers as separate from the coffee drinkers: $100 - (50 + 40 - 18) - 12$."),
               (r"$28\%$", "Leaves out the juice drinkers who do not drink coffee: $100 - (50 + 40 - 18)$."),
               (r"$4\%$", "Does not remove the tea and coffee overlap: $100 - (50 + 40 + 12 - 6)$.")],
  check=_c26, values=[22, 16, 28, 4], cognitive="Analysis", exams=TWO)

# 27 --------------------------------------------------------------------------
def _c27():
    a, b, c, pq, qr, pr, t, n = _r3()
    tot = a + b + c + pq + qr + pr + t + n
    eqs = [tot - 100,
           (b + c + qr + n) - 45,   # not P
           (a + c + pr + n) - 50,   # not Q
           (a + b + pq + n) - 55,   # not R
           (c + n) - 20,            # neither P nor Q
           (a + n) - 25,            # neither Q nor R
           (b + n) - 22,            # neither P nor R
           n - 10]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], t)
q("C27-A-027", TOPIC, "All three from 'does not like' counts via complements", "Difficult",
  "Conceptual/application",
  r"In a survey of $100$ people about three snacks P, Q and R, $45$ people do not like P, $50$ do not like Q and $55$ do not like R. Also, $20$ like neither P nor Q, $25$ like neither Q nor R, $22$ like neither P nor R, and $10$ like none of the three. How many people like all three snacks? Type the number of people.",
  "TITA",
  r"Work with the complements $P', Q', R'$: $n(P') = 45$, $n(Q') = 50$, $n(R') = 55$, the pairwise intersections are $20, 25, 22$ and the triple intersection is $10$. So $n(P' \cup Q' \cup R') = 150 - 67 + 10 = 93$. A person outside $P' \cup Q' \cup R'$ likes all three, so the answer is $100 - 93 = 7$.",
  "Applying the formula to the complements but reporting the union of the complements, or adding the none group again.",
  "C27A-complement-counts", "Recognising that the data describe the complement sets, and that 'all three' is the complement of their union.",
  tita_answer=7, check=_c27,
  tita_traps=[(93, "Reports $n(P' \\cup Q' \\cup R')$, the people who dislike at least one snack."),
              (17, "Adds the $10$ who like none again: $100 - 93 + 10$.")],
  cognitive="Analysis", exams=TWO)

# 28 --------------------------------------------------------------------------
def _c28():
    a, b, c, pq, qr, pr, t = symbols('a b c pq qr pr t')
    P = a + pq + pr + t; Q = b + pq + qr + t; R = c + qr + pr + t
    eqs = [P - 40, Q - 35, R - 30,
           (a + b + c + pq + qr + pr + t - c) - 60,   # P union Q
           (a + b + c + pq + qr + pr + t - a) - 52,   # Q union R
           (a + b + c + pq + qr + pr + t - b) - 55,   # P union R
           (a + b + c + pq + qr + pr + t) - 72]
    return _solve(eqs, [a, b, c, pq, qr, pr, t], a + b + c)
q("C27-A-028", TOPIC, "Exactly one from set sizes and the unions of each pair", "Difficult",
  "Multi-step word problem",
  r"A shop records which of three brands P, Q and R its regular customers buy. $40$ customers buy P, $35$ buy Q and $30$ buy R. $60$ customers buy P or Q (or both), $52$ buy Q or R (or both), $55$ buy P or R (or both), and $72$ buy at least one of the three. How many customers buy exactly one of the three brands?",
  "MCQ",
  r"Pairwise intersections: $n(P \cap Q) = 75 - 60 = 15$, $n(Q \cap R) = 65 - 52 = 13$, $n(P \cap R) = 70 - 55 = 15$. Then $72 = 105 - 43 + n_3$ gives $n_3 = 10$. Exactly one $= 105 - 2(43) + 3(10) = 49$.",
  "Mishandling the multiplicity of the all-three group when converting to 'exactly one'.",
  "C27A-unions-of-pairs", "Three stages: intersections from pair unions, the triple from the full union, then the exactly-one formula.",
  correct=r"$49$",
  distractors=[(r"$29$", "Adds back the all-three group only once: $105 - 86 + 10$."),
               (r"$62$", "Reports the customers who are not in all three, $72 - 10$."),
               (r"$39$", "Adds back the all-three group twice instead of three times: $105 - 86 + 20$.")],
  check=_c28, values=[49, 29, 62, 39], cognitive="Analysis", exams=TWO)

# 29 --------------------------------------------------------------------------
def _c29():
    P, Q, N = symbols('P Q N', positive=True)
    s = solve([Eq(P - 21, Rational(1, 4) * P), Eq(Q - 21, Rational(4, 7) * Q),
               Eq(N - (P + Q - 21), Rational(1, 8) * N)], [P, Q, N], dict=True)[0]
    return s[N]
q("C27-A-029", TOPIC, "Total from 'only' fractions of each set and a neither fraction", "Difficult",
  "Inverse/parameter",
  r"In a group of students, each student either plays the guitar, plays the flute, plays both or plays neither. One fourth of the guitar players play only the guitar, and four sevenths of the flute players play only the flute. $21$ students play both instruments, and one eighth of all the students in the group play neither. How many students are in the group?",
  "MCQ",
  r"The $21$ who play both are $\frac{3}{4}$ of the guitar players, so there are $28$ guitar players; they are $\frac{3}{7}$ of the flute players, so there are $49$ flute players. At least one instrument: $28 + 49 - 21 = 56$. This is $\frac{7}{8}$ of the group, so the group has $64$ students.",
  "Using the wrong base for a fraction, or forgetting to remove the overlap.",
  "C27A-conditional-fraction-of-set", "Each fraction refers to a different base; three conversions are chained before the total appears.",
  correct=r"$64$",
  distractors=[(r"$56$", "Leaves out the students who play neither."),
               (r"$63$", "Takes the neither group as one eighth of the $56$ who play an instrument: $56 + 7$."),
               (r"$88$", "Does not remove the overlap, $28 + 49 = 77$, and then $\\frac{77}{7/8}$.")],
  check=_c29, values=[64, 56, 63, 88], cognitive="Analysis", exams=TWO)

# 30 --------------------------------------------------------------------------
def _c30():
    a, b, c, pq, qr, pr, t, n = _r3()
    eqs = [a + b + c + pq + qr + pr + t + n - 100,
           a + pq + pr + t - 40, b + pq + qr + t - 34, c + qr + pr + t - 30,
           pq + t - 14, qr + t - 12, pr + t - 13, pq + qr + pr - 21]
    return _solve(eqs, [a, b, c, pq, qr, pr, t, n], n)
q("C27-A-030", TOPIC, "Triple overlap from inclusive pairwise figures and the exactly-two count, then none", "Difficult",
  "Multi-step word problem",
  r"A township has $100$ residents and three hobby clubs P, Q and R, with $40$, $34$ and $30$ members respectively; every member is a resident. The numbers of residents who belong to both P and Q, to both Q and R, and to both P and R are $14$, $12$ and $13$ respectively, and each of these figures includes anyone who belongs to all three clubs. Exactly $21$ residents belong to exactly two of the clubs. How many residents belong to none of the three clubs?",
  "MCQ",
  r"Each all-three resident appears in all three pairwise figures, so $14 + 12 + 13 = 39 = 21 + 3n_3$, giving $n_3 = 6$. Then at least one club: $40 + 34 + 30 - 39 + 6 = 71$, and none: $100 - 71 = 29$.",
  "Counting the all-three residents only once inside the sum of the pairwise figures, or putting the exactly-two count into the inclusion and exclusion formula.",
  "C27A-exactly-two-from-pairwise", "The triple overlap is hidden: it must be extracted from the gap between the inclusive pairwise sum and the exactly-two count before the three-set formula can be used.",
  correct=r"$29$",
  distractors=[(r"$17$", "Counts the all-three residents once in the pairwise sum, $39 = 21 + n_3$, so $n_3 = 18$ and none is $100 - (104 - 39 + 18)$."),
               (r"$35$", "Finds $n_3 = 6$ but omits the final $+n_3$: $100 - (104 - 39)$."),
               (r"$11$", "Uses the exactly-two count in place of the pairwise sum: $100 - (104 - 21 + 6)$.")],
  check=_c30, values=[29, 17, 35, 11], cognitive="Analysis", exams=TWO)
