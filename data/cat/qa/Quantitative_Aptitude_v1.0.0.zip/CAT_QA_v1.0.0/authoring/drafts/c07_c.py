import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

TOPIC = "Work and wages"
HEAVY = ("CAT", "XAT")


# ---------------------------------------------------------------- 001
def _c001():
    d = symbols('d', positive=True)
    per_mh = Rational(240, 12 * 8 * 10)          # metres per mason-hour
    return solve(Eq(15 * 6 * d * per_mh, 360), d)[0]
q("C07-C-001", TOPIC, "Man-hours proportion with change in men, hours and length of wall", "Easy",
  "Multi-step word problem",
  r"A team of $12$ masons, working $8$ hours a day, builds a $240$ m long boundary wall in $10$ days. Every mason works at the same constant rate. In how many days will $15$ masons, working $6$ hours a day, build a $360$ m long wall of the same height and thickness?",
  "MCQ",
  r"Work per mason-hour is $\frac{240}{12 \times 8 \times 10} = \frac{1}{4}$ m. The new wall needs $360 \times 4 = 1440$ mason-hours, and the new team supplies $15 \times 6 = 90$ mason-hours a day. Hence it takes $\frac{1440}{90} = 16$ days.",
  "Dropping the hours factor or applying one of the ratios the wrong way round.",
  "C07C-man-hours-proportion", "Single proportion $\\frac{M_1 H_1 D_1}{W_1} = \\frac{M_2 H_2 D_2}{W_2}$ with three changes.",
  correct=r"$16$ days",
  distractors=[(r"$12$ days", "Ignores the change from $8$ to $6$ hours a day: $10 \\times \\frac{12}{15} \\times \\frac{360}{240} = 12$."),
               (r"$9$ days", "Inverts the hours ratio: $10 \\times \\frac{12}{15} \\times \\frac{6}{8} \\times \\frac{360}{240} = 9$."),
               (r"$20$ days", "Ignores the increase from $12$ to $15$ masons: $10 \\times \\frac{8}{6} \\times \\frac{360}{240} = 20$.")],
  check=_c001, values=[16, 12, 9, 20], cognitive="Application")


# ---------------------------------------------------------------- 002
def _c002():
    n = symbols('n', positive=True)
    per_km = Rational(30 * 8 * 15) / Rational(12, 10)   # worker-hours per km
    return solve(Eq(n * 10 * 18, per_km * Rational(24, 10)), n)[0]
q("C07-C-002", TOPIC, "Number of workers needed for a longer pipeline with new hours and deadline", "Easy",
  "Inverse/parameter",
  r"A crew of $30$ workers, working $8$ hours a day, lays $1.2$ km of pipeline in $15$ days. All workers work at the same constant rate. How many workers are needed to lay $2.4$ km of the same pipeline in $18$ days if each works $10$ hours a day? Enter the number of workers.",
  "TITA",
  r"Laying $1.2$ km took $30 \times 8 \times 15 = 3600$ worker-hours, so $2.4$ km needs $7200$ worker-hours. Each worker gives $10 \times 18 = 180$ hours, so $\frac{7200}{180} = 40$ workers are needed.",
  "Leaving out the change in daily hours, or forgetting that the length has doubled.",
  "C07C-man-hours-proportion", "Direct man-hours computation; one unknown.",
  tita_answer=40, check=_c002,
  tita_traps=[(50, "Ignores the hours: $30 \\times 2 \\times \\frac{15}{18} = 50$."),
              (20, "Forgets that the length doubled: $30 \\times \\frac{15}{18} \\times \\frac{8}{10} = 20$.")],
  cognitive="Application")


# ---------------------------------------------------------------- 003
def _c003():
    d = symbols('d', positive=True)
    skilled_days = 12 * 20
    trainee = Rational(3, 4)
    return solve(Eq(20 * trainee * d, skilled_days), d)[0]
q("C07-C-003", TOPIC, "Days taken by less efficient trainees for a job done by skilled workers", "Easy",
  "Multi-step word problem",
  r"A job is completed by $12$ skilled workers in $20$ days. Each trainee is $25\%$ less efficient than a skilled worker. Working the same number of hours a day, in how many days will $20$ trainees complete the same job?",
  "MCQ",
  r"The job needs $12 \times 20 = 240$ skilled worker-days. A trainee does $\frac{3}{4}$ of a skilled worker's daily work, so $20$ trainees equal $15$ skilled workers. Time $= \frac{240}{15} = 16$ days.",
  "Ignoring the efficiency, or adjusting the time by $25\\%$ instead of scaling the workforce.",
  "C07C-unequal-efficiency-equivalent", "Convert trainees to skilled-worker equivalents, then one division.",
  correct=r"$16$ days",
  distractors=[(r"$12$ days", "Treats trainees as skilled workers: $\\frac{240}{20} = 12$."),
               (r"$15$ days", "Adds $25\\%$ to the time taken by $20$ skilled workers: $12 \\times 1.25 = 15$."),
               (r"$9$ days", "Multiplies by $\\frac{3}{4}$ instead of dividing: $12 \\times \\frac{3}{4} = 9$.")],
  check=_c003, values=[16, 12, 15, 9], cognitive="Application")


# ---------------------------------------------------------------- 004
def _c004():
    n = symbols('n', positive=True)
    job = 20 * 9 * 12                         # man-hours for one job
    return solve(Eq(n * Rational(3, 4) * 8 * 18, 2 * job), n)[0]
q("C07-C-004", TOPIC, "Number of women with lower hourly output needed for double the work", "Medium",
  "Inverse/parameter",
  r"$20$ men, working $9$ hours a day, complete a job in $12$ days. In one hour a woman does $\frac{3}{4}$ of the work a man does in one hour. How many women, working $8$ hours a day, are needed to complete twice that amount of work in $18$ days? Enter the number of women.",
  "TITA",
  r"One job is $20 \times 9 \times 12 = 2160$ man-hours, so twice the work is $4320$ man-hours. Each woman supplies $8 \times 18 \times \frac{3}{4} = 108$ man-hours. Hence $\frac{4320}{108} = 40$ women are needed.",
  "Ignoring the women's lower hourly output, or forgetting to double the work.",
  "C07C-unequal-efficiency-equivalent", "Four factors change at once: workers' efficiency, hours, days and quantity of work.",
  tita_answer=40, check=_c004,
  tita_traps=[(30, "Treats a woman's output as equal to a man's: $\\frac{4320}{144} = 30$."),
              (20, "Forgets that the work is doubled: $\\frac{2160}{108} = 20$.")],
  cognitive="Application")


# ---------------------------------------------------------------- 005
def _c005():
    m, w = symbols('m w', positive=True)
    # 4 men or 6 women in 18 days; take woman's rate w = 1
    sol = solve([Eq(4 * m * 18, 6 * 1 * 18)], [m], dict=True)[0]
    W = 6 * 18
    return Rational(W) / (2 * sol[m] + 6)
q("C07-C-005", TOPIC, "Mixed team time from a men-or-women equivalence", "Easy",
  "Conceptual/application",
  r"A job can be completed either by $4$ men or by $6$ women in $18$ days. In how many days will $2$ men and $6$ women, working together, complete the job? Enter the number of days.",
  "TITA",
  r"$4$ men do what $6$ women do, so $1$ man $= 1.5$ women. Then $2$ men and $6$ women equal $9$ women. The job needs $6 \times 18 = 108$ woman-days, so the team takes $\frac{108}{9} = 12$ days.",
  "Treating a man and a woman as equally efficient, or averaging the two groups' times.",
  "C07C-men-women-equivalence", "One conversion to a common unit, then a division.",
  tita_answer=12, check=_c005,
  tita_traps=[(9, "Treats every worker as one man: $\\frac{4 \\times 18}{8} = 9$."),
              (27, "Averages the separate times $36$ and $18$ days of the two groups.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- 006
def _c006():
    r, m = Fraction(1, 12), Fraction(1, 18)
    T = 1 / (r + m)
    return 9000 * (r * T)
q("C07-C-006", TOPIC, "Wage share of one of two workers working together throughout", "Easy",
  "Conceptual/application",
  r"Ravi can finish a job alone in $12$ days and Meera can finish it alone in $18$ days. They do the job together from start to finish and receive Rs. $9{,}000$, which they share in proportion to the work each has done. How much does Ravi receive? Enter the amount in rupees.",
  "TITA",
  r"Working for the same number of days, each does work in proportion to the daily rate: $\frac{1}{12} : \frac{1}{18} = 3 : 2$. Ravi's share is $\frac{3}{5} \times 9000 = 5400$ rupees.",
  "Sharing the money in the ratio of the days taken instead of the ratio of the rates.",
  "C07C-wages-share-together", "Single ratio step once the principle is known.",
  tita_answer=5400, check=_c006,
  tita_traps=[(3600, "Shares in the ratio of days $12 : 18$, giving Ravi $\\frac{2}{5}$ of the money."),
              (4500, "Splits the money equally because they worked the same number of days.")],
  cognitive="Understanding")


# ---------------------------------------------------------------- 007
def _c007():
    af = Fraction(1, 10)
    k = Fraction(1, 6) - af
    return 15000 * k / Fraction(1, 6)
q("C07-C-007", TOPIC, "Share of a third worker whose rate is known only through team times", "Medium",
  "Conceptual/application",
  r"Arjun and Fatima together can finish a job in $10$ days. With Kabir joining them, the three together can finish it in $6$ days. The three of them do the job together from start to finish and are paid Rs. $15{,}000$, shared in proportion to the work done. What is Kabir's share?",
  "MCQ",
  r"Kabir's daily rate is $\frac{1}{6} - \frac{1}{10} = \frac{1}{15}$. All three work for the whole $6$ days, so Kabir does $\frac{6}{15} = \frac{2}{5}$ of the job. His share is $\frac{2}{5} \times 15000 = $ Rs. $6{,}000$.",
  "Comparing Kabir with the pair instead of with the whole team, or splitting the money equally.",
  "C07C-wages-share-together", "Needs the third person's rate by subtraction before the share.",
  correct=r"Rs. $6{,}000$",
  distractors=[(r"Rs. $5{,}000$", "Splits the money equally among three people."),
               (r"Rs. $9{,}000$", "Reports the combined share of Arjun and Fatima, $\\frac{3}{5}$ of the total."),
               (r"Rs. $10{,}000$", "Uses Kabir's rate over the pair's rate, $\\frac{1/15}{1/10} = \\frac{2}{3}$, as his fraction of the money.")],
  check=_c007, values=[6000, 5000, 9000, 10000], cognitive="Application")


# ---------------------------------------------------------------- 008
def _c008():
    p, j, s = symbols('p j s', positive=True)
    sol = solve([Eq(p + j, Rational(1, 12)), Eq(j + s, Rational(1, 15)), Eq(s + p, Rational(1, 20))], [p, j, s], dict=True)[0]
    # simulate day by day: Sneha stops 6 days before the end; find T with all work done
    for T in range(7, 100):
        work = T * (sol[p] + sol[j]) + (T - 6) * sol[s]
        if work == 1:
            return 18000 * (T - 6) * sol[s]
    return None
q("C07-C-008", TOPIC, "Share of a worker who leaves before the end when only pair times are known", "Difficult",
  "Multi-step word problem",
  r"Priya and Joseph together can finish a job in $12$ days, Joseph and Sneha together in $15$ days, and Sneha and Priya together in $20$ days. All three start the job together. Sneha leaves $6$ days before the job is finished, while Priya and Joseph work every day until the end. The payment of Rs. $18{,}000$ is shared in proportion to the work done. How much does Sneha receive?",
  "MCQ",
  r"Adding the pair rates, $2 \times (\text{sum of rates}) = \frac{1}{12} + \frac{1}{15} + \frac{1}{20} = \frac{1}{5}$, so the three together do $\frac{1}{10}$ a day. Sneha's rate is $\frac{1}{10} - \frac{1}{12} = \frac{1}{60}$, and Priya and Joseph together do $\frac{1}{12}$. If the job takes $T$ days, $\frac{T}{12} + \frac{T - 6}{60} = 1$, so $5T + T - 6 = 60$ and $T = 11$. Sneha works $5$ days, doing $\frac{5}{60} = \frac{1}{12}$ of the job, and receives $\frac{18000}{12} = $ Rs. $1{,}500$.",
  "Ignoring Sneha's early exit, or measuring her days from a duration found as if all three worked throughout.",
  "C07C-wages-pair-times-departure", "Pair rates must be combined and halved, then an equation for the unknown duration with an early exit, then the share.",
  correct=r"Rs. $1{,}500$",
  distractors=[(r"Rs. $3{,}000$", "Ignores her leaving: her rate $\\frac{1}{60}$ is $\\frac{1}{6}$ of the team's rate $\\frac{1}{10}$, so $\\frac{18000}{6}$."),
               (r"Rs. $1{,}200$", "Takes the duration as $10$ days (all three throughout), so Sneha works $10 - 6 = 4$ days: $\\frac{4}{60} \\times 18000$."),
               (r"Rs. $9{,}900$", "Reports Joseph's share: rate $\\frac{1}{10} - \\frac{1}{20} = \\frac{1}{20}$ for $11$ days, $\\frac{11}{20} \\times 18000$.")],
  check=_c008, values=[1500, 3000, 1200, 9900], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 009
def _c009():
    k, s = Fraction(1, 20), Fraction(1, 30)
    done_k = 6 * k
    # Sneha finishes the rest; total work 1
    assert done_k + 6 * s < 1
    return 6000 * done_k
q("C07-C-009", TOPIC, "Wage share of a worker who leaves before the job is finished", "Easy",
  "Multi-step word problem",
  r"Kabir can complete a job alone in $20$ days and Sneha alone in $30$ days. They start the job together; Kabir leaves after $6$ days and Sneha completes the rest alone. The payment of Rs. $6{,}000$ is shared in proportion to the work done. How much does Kabir get?",
  "MCQ",
  r"Kabir worked only $6$ days, doing $\frac{6}{20} = \frac{3}{10}$ of the job; Sneha did the remaining $\frac{7}{10}$. Kabir's share is $\frac{3}{10} \times 6000 = $ Rs. $1{,}800$.",
  "Sharing by efficiency ratio as if both worked throughout.",
  "C07C-wages-partial-participation", "One fraction of work, one multiplication; trap is the efficiency ratio.",
  correct=r"Rs. $1{,}800$",
  distractors=[(r"Rs. $3{,}600$", "Shares in the efficiency ratio $3 : 2$ as if both worked to the end."),
               (r"Rs. $3{,}000$", "Splits the payment equally."),
               (r"Rs. $1{,}200$", "Uses Sneha's rate for Kabir's $6$ days: $\\frac{6}{30} \\times 6000$.")],
  check=_c009, values=[1800, 3600, 3000, 1200], cognitive="Application")


# ---------------------------------------------------------------- 010
def _c010():
    m, j = Fraction(1, 15), Fraction(1, 10)
    done = 5 * m
    t = (1 - done) / (m + j)
    return 24000 * (t * j)
q("C07-C-010", TOPIC, "Wage share when one worker starts alone and the other joins later", "Medium",
  "Multi-step word problem",
  r"Meera can complete a project alone in $15$ days and Joseph alone in $10$ days. Meera works alone for the first $5$ days, after which both work together until the project is complete. The total payment of Rs. $24{,}000$ is shared in proportion to the work done. How much does Joseph receive? Enter the amount in rupees.",
  "TITA",
  r"In $5$ days Meera does $\frac{5}{15} = \frac{1}{3}$. The remaining $\frac{2}{3}$ at the combined rate $\frac{1}{15} + \frac{1}{10} = \frac{1}{6}$ takes $4$ days. Joseph works these $4$ days and does $\frac{4}{10} = \frac{2}{5}$ of the project, so he receives $\frac{2}{5} \times 24000 = 9600$ rupees.",
  "Using the efficiency ratio without accounting for Meera's solo days.",
  "C07C-wages-partial-participation", "Requires the joint phase length before the share can be found.",
  tita_answer=9600, check=_c010,
  tita_traps=[(14400, "Shares in the efficiency ratio $3 : 2$ in Joseph's favour, ignoring Meera's solo work."),
              (12000, "Splits the payment equally.")],
  cognitive="Application")


# ---------------------------------------------------------------- 011
def _c011():
    T = symbols('T', positive=True)
    Tv = solve(Eq((T - 2) / 12 + (T - 6) / 20, 1), T)[0]
    return 28000 * (Tv - 2) / 12
q("C07-C-011", TOPIC, "Wage shares when each partner is absent on different days", "Difficult",
  "Multi-step word problem",
  r"Harpreet alone can finish a job in $12$ days and Ananya alone in $20$ days. They take up the job together for Rs. $28{,}000$, to be shared in proportion to the work done. Both are scheduled to work every day until the job is finished, but Harpreet is absent on $2$ of those days and Ananya on $6$ of those days, and no day has both of them absent. How much does Harpreet receive?",
  "MCQ",
  r"Let the job take $T$ days. Harpreet works $T - 2$ days and Ananya $T - 6$ days, so $\frac{T-2}{12} + \frac{T-6}{20} = 1$, giving $5(T-2) + 3(T-6) = 60$ and $T = 11$. Harpreet works $9$ days and does $\frac{9}{12} = \frac{3}{4}$ of the job, so he receives $\frac{3}{4} \times 28000 = $ Rs. $21{,}000$.",
  "Ignoring absences and sharing in the efficiency ratio, or sharing by days worked.",
  "C07C-wages-partial-participation", "Needs an equation for the unknown duration with two different absences before sharing; two tempting shortcuts.",
  correct=r"Rs. $21{,}000$",
  distractors=[(r"Rs. $17{,}500$", "Ignores the absences and shares in the efficiency ratio $5 : 3$."),
               (r"Rs. $18{,}000$", "Shares in the ratio of days worked, $9 : 5$, ignoring the different rates."),
               (r"Rs. $14{,}000$", "Splits the payment equally.")],
  check=_c011, values=[21000, 17500, 18000, 14000], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 012
def _c012():
    s, a = Fraction(1, 15), Fraction(1, 20)
    priya = 1 - 6 * s - 6 * a
    return 12000 * priya
q("C07-C-012", TOPIC, "Share of a helper who joins two workers for the whole job", "Easy",
  "Multi-step word problem",
  r"Sneha can do a job alone in $15$ days and Arjun alone in $20$ days. With Priya's help, the three of them finish the job in $6$ days, all three working throughout. The payment of Rs. $12{,}000$ is shared in proportion to the work done. What is Priya's share?",
  "MCQ",
  r"In $6$ days Sneha does $\frac{6}{15} = \frac{2}{5}$ and Arjun does $\frac{6}{20} = \frac{3}{10}$, together $\frac{7}{10}$. Priya did the remaining $\frac{3}{10}$, so her share is $\frac{3}{10} \times 12000 = $ Rs. $3{,}600$.",
  "Splitting the payment equally among the three.",
  "C07C-wages-helper", "Two fractions of work and a subtraction.",
  correct=r"Rs. $3{,}600$",
  distractors=[(r"Rs. $4{,}000$", "Splits the payment equally among three people."),
               (r"Rs. $8{,}400$", "Reports the combined share of Sneha and Arjun."),
               (r"Rs. $4{,}800$", "Reports Sneha's share, $\\frac{2}{5}$ of the total.")],
  check=_c012, values=[3600, 4000, 8400, 4800], cognitive="Application")


# ---------------------------------------------------------------- 013
def _c013():
    j, f = Fraction(1, 24), Fraction(1, 36)
    ravi = 1 - 8 * j - 8 * f
    return 45000 * ravi
q("C07-C-013", TOPIC, "Share of a helper who joins midway and the job ends a known number of days later", "Medium",
  "Multi-step word problem",
  r"Joseph can complete a contract alone in $24$ days and Fatima alone in $36$ days. They start together. After $4$ days Ravi joins them, and the three finish the contract $4$ days after that, with Joseph and Fatima working on all $8$ days. The contract pays Rs. $45{,}000$, shared in proportion to the work done. What is Ravi's share?",
  "MCQ",
  r"Joseph and Fatima work all $8$ days: $\frac{8}{24} + \frac{8}{36} = \frac{1}{3} + \frac{2}{9} = \frac{5}{9}$. Ravi did the rest, $\frac{4}{9}$ of the work, so his share is $\frac{4}{9} \times 45000 = $ Rs. $20{,}000$.",
  "Paying by days of presence rather than by work done.",
  "C07C-wages-helper", "Insight that the late joiner's work is simply the remainder; trap of paying by person-days.",
  correct=r"Rs. $20{,}000$",
  distractors=[(r"Rs. $9{,}000$", "Shares by person-days $8 : 8 : 4$, giving Ravi $\\frac{4}{20}$ of the total."),
               (r"Rs. $15{,}000$", "Splits the payment equally among three people."),
               (r"Rs. $25{,}000$", "Reports the combined share of Joseph and Fatima.")],
  check=_c013, values=[20000, 9000, 15000, 25000], cognitive="Application")


# ---------------------------------------------------------------- 014
def _c014():
    T = symbols('T', positive=True)
    ananya_work = Rational(6000, 30000)
    return solve(Eq(T * (Rational(1, 15) + Rational(1, 30)) + ananya_work, 1), T)[0]
q("C07-C-014", TOPIC, "Completion time recovered from a helper's wage share", "Medium",
  "Inverse/parameter",
  r"Priya can complete a job alone in $15$ days and Kabir alone in $30$ days. Priya, Kabir and Ananya start the job together. Ananya leaves after $6$ days, while Priya and Kabir work every day until the job is finished. The total payment of Rs. $30{,}000$ is shared in proportion to the work done, and Ananya receives Rs. $6{,}000$. In how many days from the start is the job completed? Enter the number of days.",
  "TITA",
  r"Ananya's share is $\frac{6000}{30000} = \frac{1}{5}$, so she did $\frac{1}{5}$ of the job and Priya and Kabir did $\frac{4}{5}$. Their combined rate is $\frac{1}{15} + \frac{1}{30} = \frac{1}{10}$, so they worked $\frac{4}{5} \times 10 = 8$ days.",
  "Treating the wage fraction as a fraction of time rather than of work.",
  "C07C-wages-helper", "Reverses the usual direction: from money to work to time.",
  tita_answer=8, check=_c014,
  tita_traps=[(10, "Ignores Ananya's contribution and uses the time for Priya and Kabir alone."),
              (30, "Treats $\\frac{1}{5}$ as a fraction of time: $6$ days is $\\frac{1}{5}$ of $30$.")],
  cognitive="Analysis")


# ---------------------------------------------------------------- 015
def _c015():
    man_days = 8 * 15
    woman_days = Fraction(man_days) / Fraction(2, 3)
    return man_days * 750 - woman_days * 450
q("C07-C-015", TOPIC, "Saving from using a cheaper but less efficient workforce", "Medium",
  "Multi-step word problem",
  r"A job can be done by $8$ men in $15$ days. A woman does $\frac{2}{3}$ of the work a man does in a day. A contractor pays Rs. $750$ per day to each man and Rs. $450$ per day to each woman. How much does the contractor save on the total wage bill if he gets the job done entirely by women instead of entirely by men?",
  "MCQ",
  r"The job is $8 \times 15 = 120$ man-days, costing $120 \times 750 = $ Rs. $90{,}000$. It equals $120 \times \frac{3}{2} = 180$ woman-days, costing $180 \times 450 = $ Rs. $81{,}000$. The saving is Rs. $9{,}000$. (The bill does not depend on how many workers are hired.)",
  "Comparing daily wages without converting the work into woman-days.",
  "C07C-wage-bill-from-rates", "Must convert work units before comparing costs; several tempting shortcuts.",
  correct=r"Rs. $9{,}000$",
  distractors=[(r"Rs. $36{,}000$", "Treats a woman as equal to a man: $120 \\times (750 - 450)$."),
               (r"Rs. $54{,}000$", "Inverts the conversion, taking $120 \\times \\frac{2}{3} = 80$ woman-days costing Rs. $36{,}000$."),
               (r"Rs. $13{,}500$", "Finds the saving per man-day of work, $750 - 675 = 75$, and multiplies it by $180$ woman-days.")],
  check=_c015, values=[9000, 36000, 54000, 13500], cognitive="Analysis")


# ---------------------------------------------------------------- 016
def _c016():
    m, W = symbols('m W', positive=True)   # boy's daily rate = 1
    sol = solve([Eq(15 * (6 * m + 10), W), Eq(12 * (10 * m + 5), W)], [m, W], dict=True)[0]
    days = sol[W] / (6 * sol[m] + 17)
    return days * (6 * 500 + 17 * 200)
q("C07-C-016", TOPIC, "Wage bill for a new mix of men and boys after finding their relative rates", "Difficult",
  "Multi-step word problem",
  r"$6$ men and $10$ boys can complete a job in $15$ days, while $10$ men and $5$ boys can complete it in $12$ days. A contractor gets the job done by $6$ men and $17$ boys, paying Rs. $500$ per day to each man and Rs. $200$ per day to each boy for every day until the job is complete. What is the total wage bill? Enter the amount in rupees.",
  "TITA",
  r"$15(6m + 10b) = 12(10m + 5b)$ gives $90m + 150b = 120m + 60b$, so $m = 3b$. The job is $15 \times 28b = 420$ boy-days, and $6$ men and $17$ boys equal $35$ boys, so they take $\frac{420}{35} = 12$ days. The daily bill is $6 \times 500 + 17 \times 200 = 6400$, and the total is $12 \times 6400 = 76800$ rupees.",
  "Assuming the new team takes as long as one of the given teams, or reusing the first team's bill.",
  "C07C-wage-bill-from-rates", "Two-equation rate comparison, then duration, then cost; three linked stages.",
  tita_answer=76800, check=_c016,
  tita_traps=[(96000, "Assumes the new team also takes $15$ days: $15 \\times 6400$."),
              (75000, "Computes the bill for the first team, $15 \\times (6 \\times 500 + 10 \\times 200)$.")],
  cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 017
def _c017():
    m, w, d = symbols('m w d', positive=True)
    # woman's daily rate = 1; 3 men or 4 women in 15 days
    mv = solve(Eq(3 * m * 15, 4 * 15), m)[0]
    days = Rational(4 * 15) / (2 * mv + 4)
    return solve(Eq(days * (2 * 700 + 4 * w), 27000), w)[0]
q("C07-C-017", TOPIC, "Woman's daily wage found from the total wage bill", "Difficult",
  "Inverse/parameter",
  r"A job can be completed either by $3$ men or by $4$ women in $15$ days. A contractor employs $2$ men and $4$ women, who work together every day until the job is done. Each man is paid Rs. $700$ per day and each woman the same fixed amount per day. If the total wage bill is Rs. $27{,}000$, what is a woman's daily wage?",
  "MCQ",
  r"$3$ men $= 4$ women, so a man is $\frac{4}{3}$ women and the team equals $\frac{8}{3} + 4 = \frac{20}{3}$ women. The job is $60$ woman-days, so it takes $60 \div \frac{20}{3} = 9$ days. Then $9(1400 + 4w) = 27000$ gives $1400 + 4w = 3000$ and $w = $ Rs. $400$.",
  "Using a wrong duration, for example treating men and women as equally efficient.",
  "C07C-wage-bill-from-rates", "Rate conversion, duration and a wage equation in sequence; each step has a trap.",
  correct=r"Rs. $400$",
  distractors=[(r"Rs. $550$", "Treats men and women as equal: $\\frac{45}{6} = 7.5$ days, then $\\frac{27000/7.5 - 1400}{4}$."),
               (r"Rs. $750$", "Inverts the equivalence (a woman $= \\frac{4}{3}$ men), getting $\\frac{135}{22}$ days and a daily bill of Rs. $4{,}400$."),
               (r"Rs. $500$", "Divides the daily bill of Rs. $3{,}000$ equally among all $6$ workers, ignoring the men's fixed wage.")],
  check=_c017, values=[400, 550, 750, 500], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 018
def _c018():
    x = symbols('x', positive=True)
    total = Rational(36 * 30) / Rational(1, 2)
    return solve(Eq((36 + x) * (50 - 30), total - 36 * 30), x)[0]
q("C07-C-018", TOPIC, "Additional men required to finish a delayed contract on time", "Easy",
  "Inverse/parameter",
  r"A contractor undertakes to build a road in $50$ days and employs $36$ men. After $30$ days he finds that only half the road is built. How many additional men, working at the same rate, must he employ so that the road is completed on time?",
  "MCQ",
  r"Half the road took $36 \times 30 = 1080$ man-days, so the other half also needs $1080$ man-days in the remaining $20$ days: $\frac{1080}{20} = 54$ men. He needs $54 - 36 = 18$ additional men.",
  "Using the planned schedule instead of the actual progress to measure the work.",
  "C07C-contract-extra-men", "Standard on-time completion with one trap.",
  correct=r"$18$",
  distractors=[(r"$9$", "Uses the planned $36 \\times 50 = 1800$ man-days, so half is $900$ and $\\frac{900}{20} = 45$ men, i.e. $9$ more."),
               (r"$54$", "Reports the total workforce needed instead of the additional men."),
               (r"$45$", "Reports the total workforce from the planned-schedule calculation.")],
  check=_c018, values=[18, 9, 54, 45], cognitive="Application")


# ---------------------------------------------------------------- 019
def _c019():
    x = symbols('x', positive=True)
    done = 36 * 8 * 30
    total = Rational(done) / Rational(2, 5)
    return solve(Eq((36 + x) * 9 * (60 - 30), total - done), x)[0]
q("C07-C-019", TOPIC, "Extra men to finish on time when daily hours are also increased", "Medium",
  "Inverse/parameter",
  r"A contractor undertakes to complete a project in $60$ days and employs $36$ men working $8$ hours a day. After $30$ days only $\frac{2}{5}$ of the project is complete. From the $31$st day, everyone on the site works $9$ hours a day. How many additional men, working at the same hourly rate, must be employed from the $31$st day to finish the project on time?",
  "MCQ",
  r"$\frac{2}{5}$ of the work took $36 \times 8 \times 30 = 8640$ man-hours, so the remaining $\frac{3}{5}$ needs $12960$ man-hours. In $30$ days at $9$ hours a day each man gives $270$ hours, so $\frac{12960}{270} = 48$ men are needed: $12$ additional men.",
  "Keeping the old $8$-hour day for the remaining work, or reporting the total workforce.",
  "C07C-contract-extra-men", "Progress-based work estimate combined with a change in hours.",
  correct=r"$12$",
  distractors=[(r"$18$", "Ignores the switch to $9$ hours: $\\frac{12960}{240} = 54$ men, i.e. $18$ more."),
               (r"$48$", "Reports the total workforce instead of the additional men."),
               (r"$54$", "Ignores the switch to $9$ hours and reports the total workforce.")],
  check=_c019, values=[12, 18, 48, 54],
  cognitive="Application", exams=HEAVY)


# ---------------------------------------------------------------- 020
def _c020():
    x = symbols('x', positive=True)
    done = 36 * 20
    total = Rational(done) / Rational(3, 8)
    return solve(Eq((36 + Rational(3, 4) * x) * (45 - 5 - 20), total - done), x)[0]
q("C07-C-020", TOPIC, "Less efficient extra workers hired to finish ahead of schedule", "Difficult",
  "Inverse/parameter",
  r"A contractor agrees to finish a canal lining in $45$ days and employs $36$ men. After $20$ days only $\frac{3}{8}$ of the work is done. He now wants to finish $5$ days before the deadline, so from the $21$st day he adds new workers, each of whom does $\frac{3}{4}$ of a man's daily work, while the $36$ men continue. How many new workers must he add?",
  "MCQ",
  r"$\frac{3}{8}$ took $36 \times 20 = 720$ man-days, so the job is $1920$ man-days and $1200$ remain. They must be done in $45 - 5 - 20 = 20$ days, needing $60$ man-equivalents, i.e. $24$ more. Each new worker is $\frac{3}{4}$ of a man, so $\frac{24}{3/4} = 32$ new workers are needed.",
  "Forgetting the efficiency conversion or the earlier target date.",
  "C07C-contract-extra-men", "Three adjustments (progress, earlier deadline, efficiency) must all be applied correctly.",
  correct=r"$32$",
  distractors=[(r"$24$", "Treats each new worker as a full man."),
               (r"$18$", "Multiplies the $24$ man-equivalents by $\\frac{3}{4}$ instead of dividing."),
               (r"$16$", "Plans for the original deadline: $\\frac{1200}{25} = 48$, so $12$ man-equivalents, i.e. $16$ workers.")],
  check=_c020, values=[32, 24, 18, 16], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 021
def _c021():
    W = 50 * 30
    work, day, men = Fraction(0), 0, 50
    while work < W:
        day += 1
        if day == 11:
            men = 40
        work += men
    return day - 30
q("C07-C-021", TOPIC, "Delay caused by withdrawing part of the workforce", "Medium",
  "Multi-step word problem",
  r"A contractor employs $50$ men to complete a job in exactly $30$ days. After $10$ days of work, $10$ of the men are transferred to another site and the remaining men complete the job. By how many days is the job delayed beyond the planned $30$ days?",
  "MCQ",
  r"The job is $50 \times 30 = 1500$ man-days. In $10$ days $500$ are done, leaving $1000$ for $40$ men: $25$ more days. The job ends on day $35$, a delay of $5$ days. (Equivalently, the lost $10 \times 20 = 200$ man-days are made up by $40$ men in $5$ days.)",
  "Dividing the lost man-days by the original workforce instead of the reduced one.",
  "C07C-contract-delay", "Two-phase man-day accounting.",
  correct=r"$5$ days",
  distractors=[(r"$4$ days", "Divides the lost $200$ man-days by $50$ men instead of $40$."),
               (r"$25$ days", "Reports the number of days worked after the transfer."),
               (r"$35$ days", "Reports the total time from the start instead of the delay.")],
  check=_c021, values=[5, 4, 25, 35], cognitive="Application")


# ---------------------------------------------------------------- 022
def _c022():
    W = Fraction(40 * 45)
    work, day = Fraction(0), 0
    while work < W:
        day += 1
        if day <= 12:
            rate = Fraction(40)
        elif day <= 20:
            rate = Fraction(30)
        else:
            rate = 30 + 15 * Fraction(2, 3)
        work += rate
    assert work == W
    return day
q("C07-C-022", TOPIC, "Completion time after men leave and women join in stages", "Difficult",
  "Multi-step word problem",
  r"A contractor plans to finish a job in $45$ days with $40$ men. After $12$ days, $10$ of the men leave. After a further $8$ days, $15$ women join the remaining men, each woman doing $\frac{2}{3}$ of a man's daily work, and all of them work until the job is finished. In how many days from the start is the job completed?",
  "MCQ",
  r"The job is $40 \times 45 = 1800$ man-days. Days $1$ to $12$: $480$. Days $13$ to $20$: $30 \times 8 = 240$. The remaining $1080$ man-days are done at $30 + 15 \times \frac{2}{3} = 40$ man-days per day, taking $27$ days. Total: $12 + 8 + 27 = 47$ days.",
  "Treating the women as full men, or missing one of the stages.",
  "C07C-contract-delay", "Three stages with a change in workforce composition and efficiency.",
  correct=r"$47$ days",
  distractors=[(r"$44$ days", "Counts each woman as a full man: $\\frac{1080}{45} = 24$ days in the last stage."),
               (r"$40$ days", "Overlooks the $10$ men leaving: $1800 - 800 = 1000$ man-days at $50$ a day."),
               (r"$27$ days", "Reports only the length of the last stage.")],
  check=_c022, values=[47, 44, 40, 27], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 023
def _c023():
    x, d = symbols('x d', positive=True)
    sol = solve([Eq((x + 6) * (d - 4), x * d), Eq((x - 10) * (d + 12), x * d)], [x, d], dict=True)
    return [s[x] for s in sol if s[x] > 10][0]
q("C07-C-023", TOPIC, "Original workforce from two what-if changes in the number of men", "Medium",
  "Inverse/parameter",
  r"A group of men can complete a job in a certain number of days. If there were $6$ more men, the job would be finished $4$ days earlier; if there were $10$ fewer men, it would take $12$ days longer. How many men are in the group? Enter the number of men.",
  "TITA",
  r"With $x$ men and $d$ days, $(x+6)(d-4) = xd$ gives $6d - 4x = 24$, and $(x-10)(d+12) = xd$ gives $12x - 10d = 120$. From the first, $d = \frac{2x + 12}{3}$; substituting, $12x - \frac{20x + 120}{3} = 120$, so $16x = 480$ and $x = 30$ (with $d = 24$).",
  "Solving correctly but reporting the number of days.",
  "C07C-workforce-inverse", "Two linear conditions in two unknowns derived from constant total work.",
  tita_answer=30, check=_c023,
  tita_traps=[(24, "Reports the number of days instead of the number of men."),
              (36, "Reports the enlarged team, $x + 6$."),
              (20, "Reports the reduced team, $x - 10$.")],
  cognitive="Application")


# ---------------------------------------------------------------- 024
def _c024():
    x, d = symbols('x d', positive=True)
    sol = solve([Eq(Rational(3, 4) * x * (d + 8), x * d), Eq((x + 12) * (d - 4), x * d)], [x, d], dict=True)
    xv = sol[0][x]
    assert xv % 4 == 0
    return xv
q("C07-C-024", TOPIC, "Original workforce when a fraction is absent and when extra men join", "Medium",
  "Inverse/parameter",
  r"A contractor's team of men would complete a job in a certain number of days. If one-fourth of the men were absent throughout, the job would take $8$ more days. If instead $12$ more men joined the team from the start, the job would take $4$ days less. How many men are in the team?",
  "MCQ",
  r"With $\frac{3}{4}$ of the men the time becomes $\frac{4}{3}$ of the original, so $\frac{d}{3} = 8$ and $d = 24$. Then $(x + 12) \times 20 = 24x$ gives $4x = 240$ and $x = 60$ (one-fourth of them is $15$ men).",
  "Taking one-fourth fewer men to mean one-fourth more time.",
  "C07C-workforce-inverse", "Key insight that the first condition alone fixes the original duration, then one linear equation.",
  correct=r"$60$",
  distractors=[(r"$84$", "Takes the time to rise by one-fourth, so $\\frac{d}{4} = 8$, $d = 32$ and $(x+12) \\times 28 = 32x$."),
               (r"$72$", "Equates the extra men's work over $24$ days with $4$ days of the team: $12 \\times 24 = 4x$."),
               (r"$24$", "Finds the original number of days, $d = 24$, and reports it as the number of men.")],
  check=_c024, values=[60, 84, 72, 24], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 025
def _c025():
    m, W = symbols('m W', positive=True)   # woman's rate 1
    sol = solve([Eq(12 * (2 * m + 3), W), Eq(9 * (3 * m + 3), W)], [m, W], dict=True)[0]
    return sol[W] / (sol[m] + 3)
q("C07-C-025", TOPIC, "Time for a new team after deducing the man-woman ratio from two teams", "Medium",
  "Conceptual/application",
  r"$2$ men and $3$ women can complete a job in $12$ days, while $3$ men and $3$ women can complete it in $9$ days. In how many days will $1$ man and $3$ women complete the job? Enter the number of days.",
  "TITA",
  r"$12(2m + 3w) = 9(3m + 3w)$ gives $24m + 36w = 27m + 27w$, so $m = 3w$. The job is $12 \times 9w = 108$ woman-days, and $1$ man and $3$ women equal $6$ women, so they take $\frac{108}{6} = 18$ days.",
  "Assuming the change of one man changes the time linearly.",
  "C07C-two-teams-ratio", "Two-team comparison yields the efficiency ratio, then one division.",
  tita_answer=18, check=_c025,
  tita_traps=[(15, "Extends the pattern linearly ($9$, $12$, $15$ days for $3$, $2$, $1$ men), or treats all workers as equal: $\\frac{5 \\times 12}{4} = 15$."),
              (27, "Finds the job as $108$ woman-days but divides by $4$ workers, forgetting to convert the man: $\\frac{108}{4} = 27$.")],
  cognitive="Application")


# ---------------------------------------------------------------- 026
def _c026():
    m, w, W = symbols('m w W', positive=True)   # child's rate 1
    sol = solve([Eq(6 * (3 * m + 4 * w), W), Eq(12 * (2 * w + 6), W), Eq(10 * (2 * m + 4), W)], [m, w, W], dict=True)[0]
    return sol[W] / (2 * sol[m] + sol[w] + 5)
q("C07-C-026", TOPIC, "Men, women and children rates from three team times", "Difficult",
  "Multi-step word problem",
  r"A job can be completed by $3$ men and $4$ women in $6$ days, by $2$ women and $6$ children in $12$ days, and by $2$ men and $4$ children in $10$ days. In how many days will $2$ men, $1$ woman and $5$ children together complete the job? Enter the number of days.",
  "TITA",
  r"Take a child's daily work as $1$ unit. Equating the first two teams, $6(3m + 4w) = 12(2w + 6)$ gives $18m + 24w = 24w + 72$, so $m = 4$. The third team then gives the job as $10(8 + 4) = 120$ units, and $12(2w + 6) = 120$ gives $w = 2$. The new team does $8 + 2 + 5 = 15$ units a day, taking $\frac{120}{15} = 8$ days.",
  "Mixing up which team equation fixes which ratio.",
  "C07C-three-way-rates", "Three equations in three relative rates; must choose a convenient unit and eliminate.",
  tita_answer=8, check=_c026,
  tita_traps=[(10, "Uses $m = 4$, $w = 2$ but writes the new team as $2$ men and $4$ children only, matching the third team.")],
  cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 027
def _c027():
    # 1 man = 2 women = 3 children in daily work; child = 2 units
    man, woman, child = Fraction(6), Fraction(3), Fraction(2)
    total = 4 * man + 4 * woman + 12 * child
    return 48000 * (4 * man) / total
q("C07-C-027", TOPIC, "Group share of wages for men, women and children with a work equivalence", "Medium",
  "Conceptual/application",
  r"In one day, $1$ man does as much work as $2$ women or $3$ children. A team of $4$ men, $4$ women and $12$ children completes a job, all working throughout, and the payment of Rs. $48{,}000$ is shared in proportion to the work done. How much do the $4$ men receive in all?",
  "MCQ",
  r"Take a child's daily work as $2$ units; then a woman does $3$ and a man $6$. Daily work: men $24$, women $12$, children $24$, total $60$. The men's share is $\frac{24}{60} \times 48000 = $ Rs. $19{,}200$.",
  "Reading the equivalence $1 : 2 : 3$ as the ratio of rates rather than of headcounts.",
  "C07C-wages-group-equivalence", "A common unit must be chosen for a three-way equivalence before sharing.",
  correct=r"Rs. $19{,}200$",
  distractors=[(r"Rs. $9{,}600$", "Shares per head, $\\frac{4}{20}$ of the total."),
               (r"Rs. $4{,}000$", "Takes the rates as man $:$ woman $:$ child $= 1 : 2 : 3$, so men get $\\frac{4}{48}$."),
               (r"Rs. $18{,}000$", "Takes the rates as $3 : 2 : 1$, so men get $\\frac{12}{32}$.")],
  check=_c027, values=[19200, 9600, 4000, 18000], cognitive="Understanding")


# ---------------------------------------------------------------- 028
def _c028():
    total = Fraction(20 * 15) / Fraction(1, 3)
    rem = total - 20 * 15
    finish = 15 + rem / 30
    late = max(0, finish - 30)
    return 500000 - 10000 * late
q("C07-C-028", TOPIC, "Contract payment after a per-day penalty for late completion", "Medium",
  "Multi-step word problem",
  r"A contractor agrees to build a hall in $30$ days for Rs. $5{,}00{,}000$, with Rs. $10{,}000$ deducted for every day of delay beyond $30$ days. He employs $20$ men. After $15$ days only one-third of the work is complete, so he adds $10$ more men, equally efficient, who work with the others until the hall is finished. How much does the contractor receive?",
  "MCQ",
  r"One-third took $20 \times 15 = 300$ man-days, so the hall needs $900$ man-days and $600$ remain. With $30$ men this takes $20$ days, finishing on day $35$: $5$ days late. He receives $500000 - 5 \times 10000 = $ Rs. $4{,}50{,}000$.",
  "Measuring the delay from the wrong starting point.",
  "C07C-contract-penalty-bonus", "Progress-based estimate, new completion date, then the penalty.",
  correct=r"Rs. $4{,}50{,}000$",
  distractors=[(r"Rs. $3{,}50{,}000$", "Overlooks the $10$ added men: $\\frac{600}{20} = 30$ more days, finishing $15$ days late."),
               (r"Rs. $5{,}00{,}000$", "Reads one-third as the work remaining: $\\frac{2}{3}$ took $300$ man-days, so $150$ remain and $\\frac{150}{30} = 5$ more days, finishing well before day $30$ with no deduction."),
               (r"Rs. $3{,}00{,}000$", "Adds the $20$ extra days to the $30$-day deadline, counting $20$ days of delay.")],
  check=_c028, values=[450000, 350000, 500000, 300000], cognitive="Application")


# ---------------------------------------------------------------- 029
def _c029():
    W = Fraction(30 * 10) / Fraction(1, 5)
    work, day, mandays = Fraction(0), 0, 0
    while work < W:
        day += 1
        men = 30 if day <= 10 else 50
        work += men
        mandays += men
    early = 40 - day
    return 750000 + 5000 * early - 400 * mandays
q("C07-C-029", TOPIC, "Contractor's profit with an early-completion bonus and daily wages", "Difficult",
  "Conceptual/application",
  r"A contractor agrees to finish a job in $40$ days for Rs. $7{,}50{,}000$, with a bonus of Rs. $5{,}000$ for each day by which the job is completed ahead of the $40$-day deadline (for example, finishing at the end of day $38$ earns Rs. $10{,}000$). He employs $30$ men at Rs. $400$ per man per day. After $10$ days only one-fifth of the job is done, so from the $11$th day he employs $20$ more men at the same wage and efficiency, and all $50$ work until the job is finished. Ignoring all other costs, what is the contractor's profit? Enter the amount in rupees.",
  "TITA",
  r"One-fifth took $300$ man-days, so the job is $1500$ man-days and $1200$ remain. With $50$ men this takes $24$ days, so the job ends on day $34$, $6$ days early: receipts $750000 + 30000 = 780000$. The wage bill is $1500$ man-days $\times 400 = 600000$ (it depends only on the total work). Profit $= 780000 - 600000 = 180000$ rupees.",
  "Charging wages for all $50$ men over the whole period, or forgetting the bonus.",
  "C07C-contract-penalty-bonus", "Combines progress-based estimation, the bonus and the insight that the wage bill equals total man-days times the wage.",
  tita_answer=180000, check=_c029,
  tita_traps=[(150000, "Forgets the bonus of Rs. $30{,}000$."),
              (100000, "Pays all $50$ men for all $34$ days: $1700 \\times 400 = 680000$.")],
  cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 030
def _c030():
    b = symbols('b', positive=True)
    W = 12 * 18
    rem = W - 8 * 9
    return solve(Eq(b * Rational(1, 2) * 6, rem), b)[0]
q("C07-C-030", TOPIC, "Boys needed to replace men and finish the remaining work by a deadline", "Medium",
  "Inverse/parameter",
  r"$12$ men can finish a job in $18$ days. $8$ men work on it for $9$ days and are then replaced by boys, each of whom does half a man's daily work. How many boys are needed to finish the remaining work in $6$ days?",
  "MCQ",
  r"The job is $12 \times 18 = 216$ man-days. $8$ men in $9$ days do $72$, leaving $144$ man-days. In $6$ days that needs $24$ men, i.e. $48$ boys.",
  "Assuming half the work is done because half the time has passed.",
  "C07C-replace-workforce", "Man-day accounting followed by a conversion to boys.",
  correct=r"$48$",
  distractors=[(r"$24$", "Forgets that a boy does only half a man's work."),
               (r"$36$", "Takes the work as half done after $9$ of $18$ days: $\\frac{108}{6} = 18$ men, i.e. $36$ boys."),
               (r"$12$", "Halves instead of doubling: $\\frac{24}{2}$.")],
  check=_c030, values=[48, 24, 36, 12], cognitive="Application")


# ---------------------------------------------------------------- 031
def _c031():
    n, m = symbols('n m', positive=True)   # woman's rate 1
    mv = solve(Eq(10 * m * 24, 12 * 30), m)[0]
    W = 12 * 30
    rem = W - 8 * mv * 5
    return solve(Eq(n * (mv + 1) * 8, rem), n)[0]
q("C07-C-031", TOPIC, "Equal numbers of men and women needed to finish the remaining work", "Difficult",
  "Inverse/parameter",
  r"A job can be completed either by $10$ men in $24$ days or by $12$ women in $30$ days. $8$ men work on it for $5$ days and then stop. The rest of the job is to be finished in $8$ days by a new team with equal numbers of men and women. How many men must the new team have?",
  "MCQ",
  r"$10 \times 24 = 240$ man-days equal $12 \times 30 = 360$ woman-days, so $1$ man $= 1.5$ women and the job is $360$ woman-days. $8$ men for $5$ days do $8 \times 5 \times 1.5 = 60$, leaving $300$. With $n$ men and $n$ women, $2.5n \times 8 = 300$, so $n = 15$.",
  "Inverting the man-woman equivalence or treating them as equally efficient.",
  "C07C-replace-workforce", "Equivalence, partial progress and an unknown mixed team; several distinct traps.",
  correct=r"$15$",
  distractors=[(r"$18$", "Overlooks the work already done: $2.5n \\times 8 = 360$."),
               (r"$20$", "Treats men and women as equally efficient: $360 - 40 = 320 = 2n \\times 8$."),
               (r"$25$", "Inverts the equivalence (a man $= \\frac{2}{3}$ woman): $\\frac{1000}{3} = \\frac{5}{3} n \\times 8$.")],
  check=_c031, values=[15, 18, 20, 25], cognitive="Analysis", exams=HEAVY)


# ---------------------------------------------------------------- 032
def _c032():
    p = symbols('p')
    f_share, total = 10000, 18000
    r_share = total - f_share
    # same days worked, so work (and pay) ratio equals rate ratio: f_rate = (1 + p/100) * r_rate
    return solve(Eq(Rational(f_share, r_share), 1 + p / 100), p)[0]
q("C07-C-032", TOPIC, "Percentage efficiency difference recovered from the wage split", "Easy",
  "Inverse/parameter",
  r"Fatima and Ravi work together on a job from start to finish and receive Rs. $18{,}000$, shared in proportion to the work done. Fatima receives Rs. $10{,}000$. By what percent is Fatima more efficient than Ravi?",
  "MCQ",
  r"Both work the same number of days, so their pay is in the ratio of their daily rates: $10000 : 8000 = 5 : 4$. Fatima does $\frac{5}{4}$ of Ravi's daily work, so she is $25\%$ more efficient.",
  "Taking the difference as a percent of the larger rate, or reporting the ratio itself as the percentage.",
  "C07C-wages-efficiency-percent", "One ratio from the shares, then a percentage with the correct base.",
  correct=r"$25\%$",
  distractors=[(r"$20\%$", "Uses Fatima's pay as the base: $\\frac{2000}{10000} = 20\\%$, which is how much less efficient Ravi is."),
               (r"$125\%$", "Reports Fatima's rate as a percent of Ravi's, $\\frac{10000}{8000} = 125\\%$."),
               (r"$80\%$", "Reports Ravi's rate as a percent of Fatima's, $\\frac{8000}{10000} = 80\\%$.")],
  check=_c032, values=[25, 20, 125, 80], cognitive="Understanding")


# ---------------------------------------------------------------- 033
def _c033():
    k = Fraction(1)
    s = Fraction(3, 2) * k
    a = 2 * s
    return 99000 * s / (a + s + k)
q("C07-C-033", TOPIC, "Wage share among three workers with chained efficiency comparisons", "Medium",
  "Multi-step word problem",
  r"Arjun is twice as efficient as Sneha, and Sneha is $50\%$ more efficient than Kabir. The three work together from start to finish on a job and are paid Rs. $99{,}000$, shared in proportion to the work done. How much does Sneha receive?",
  "MCQ",
  r"Take Kabir's rate as $2$. Sneha's is $3$ and Arjun's is $6$, so the shares are $6 : 3 : 2$ with $11$ parts. Sneha gets $\frac{3}{11} \times 99000 = $ Rs. $27{,}000$.",
  "Reversing the comparison between Sneha and Kabir.",
  "C07C-wages-efficiency-percent", "Chaining two comparisons into a three-term ratio.",
  correct=r"Rs. $27{,}000$",
  distractors=[(r"Rs. $22{,}000$", "Reads Kabir as $50\\%$ more efficient than Sneha, giving $4 : 2 : 3$ and $\\frac{2}{9}$ of the total."),
               (r"Rs. $33{,}000$", "Splits the payment equally."),
               (r"Rs. $54{,}000$", "Reports Arjun's share, $\\frac{6}{11}$ of the total.")],
  check=_c033, values=[27000, 22000, 33000, 54000],
  cognitive="Application")


# ---------------------------------------------------------------- 034
def _c034():
    d = symbols('d', positive=True)
    return solve(Eq(24 * 5 + 30 * d, 480), d)[0]
q("C07-C-034", TOPIC, "Remaining days after the crew size is changed partway through", "Easy",
  "Multi-step word problem",
  r"A building repair needs $480$ man-days of work. A crew of $24$ men works on it for $5$ days, after which the crew is increased to $30$ men, all equally efficient. How many more days are needed to finish the repair?",
  "MCQ",
  r"$24 \times 5 = 120$ man-days are done, leaving $360$. With $30$ men this takes $\frac{360}{30} = 12$ more days.",
  "Ignoring the work already done.",
  "C07C-remaining-work-crew-change", "Direct man-day subtraction and division.",
  correct=r"$12$ days",
  distractors=[(r"$16$ days", "Ignores the work already done: $\\frac{480}{30}$."),
               (r"$15$ days", "Finishes with the old crew: $\\frac{360}{24}$."),
               (r"$17$ days", "Reports the total number of days from the start, $5 + 12$.")],
  check=_c034, values=[12, 16, 15, 17], cognitive="Application")


# ---------------------------------------------------------------- 035
def _c035():
    md_orig = 5 * 12
    md_new = 3 * 4
    per = Fraction(72000, md_orig + md_new)
    return per * 4
q("C07-C-035", TOPIC, "Payment per man-day for workers who join for the last few days", "Easy",
  "Single-step computation",
  r"$5$ workers work on a job for all of its $12$ days, and $3$ more workers join them for only the last $4$ days. All workers are equally efficient, and the payment of Rs. $72{,}000$ is shared in proportion to the work done. How much does each of the $3$ later workers receive? Enter the amount in rupees.",
  "TITA",
  r"Total man-days $= 5 \times 12 + 3 \times 4 = 72$, so each man-day earns Rs. $1{,}000$. Each later worker worked $4$ days and receives $4000$ rupees.",
  "Splitting the payment per head instead of per man-day.",
  "C07C-wage-per-man-day", "One total and one division.",
  tita_answer=4000, check=_c035,
  tita_traps=[(9000, "Splits the payment equally among $8$ workers."),
              (12000, "Reports the amount each original worker receives.")],
  cognitive="Application")
