import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Percentage word problems"
ALL = EXAMS
CX = ("CAT", "XAT")

# ======================= EASY =======================

def _e1():
    depts = [(120, Fraction(20, 100)), (200, Fraction(30, 100)), (80, Fraction(55, 100))]
    women = sum(n * p for n, p in depts)
    return women / sum(n for n, _ in depts) * 100
q("C01-D-001", T, "Overall percentage of women from department sizes and department percentages", "Easy",
  "Multi-step word problem",
  r"A company has three departments. Sales has $120$ employees, of whom $20\%$ are women; Operations has $200$ employees, of whom $30\%$ are women; Finance has $80$ employees, of whom $55\%$ are women. What percentage of the company's employees are women?",
  "MCQ",
  r"Women: $20\%$ of $120 = 24$, $30\%$ of $200 = 60$ and $55\%$ of $80 = 44$, a total of $128$. The company has $120 + 200 + 80 = 400$ employees, so women make up $\frac{128}{400} = 32\%$.",
  "Averaging the three department percentages without weighting them by department size.",
  "C01D-weighted-overall-percent", "A single weighted-average computation; the trap is the unweighted mean.",
  correct=r"$32\%$",
  distractors=[(r"$35\%$", r"Takes the simple average $\frac{20 + 30 + 55}{3} = 35\%$, ignoring department sizes."),
               (r"$30\%$", "Uses the percentage of the largest department, Operations, as representative of the company."),
               (r"$68\%$", r"Computes the share of men, $\frac{272}{400} = 68\%$, rather than women.")],
  check=_e1, values=[32, 35, 30, 68], cognitive="Application")


def _e2():
    n = Fraction(1200)
    senior = n * Fraction(45, 100)
    sci = senior * Fraction(40, 100)
    return sci * Fraction(25, 100)
q("C01-D-002", T, "Percentage of a percentage of a percentage within a school", "Easy",
  "Multi-step word problem",
  r"A school has $1{,}200$ students, and $45\%$ of them are in the senior section. Only senior-section students choose a stream: $40\%$ of the senior-section students have chosen Science, and $25\%$ of these Science students have taken Computer Science as an elective. No other student takes Computer Science. How many students in the school take Computer Science?",
  "TITA",
  r"Senior section: $45\%$ of $1200 = 540$. Science: $40\%$ of $540 = 216$. Computer Science: $25\%$ of $216 = 54$. Equivalently, $0.45 \times 0.40 \times 0.25 = 0.045$ and $0.045 \times 1200 = 54$.",
  "Applying a later percentage to the whole school instead of to the group it refers to.",
  "C01D-percent-of-percent-chain", "Three successive percentages of nested groups; one idea applied three times.",
  tita_answer=54, check=_e2, values=[54],
  tita_traps=[(135, r"Takes $25\%$ of the $540$ senior-section students, skipping the Science step."),
              (300, r"Takes $25\%$ of all $1200$ students.")],
  cognitive="Application")


def _e3():
    # applicants (women, men) and selection fractions (women, men) per department
    depts = [((30, 120), (Fraction(80, 100), Fraction(75, 100))),
             ((120, 30), (Fraction(25, 100), Fraction(20, 100)))]
    assert all(fw > fm for _, (fw, fm) in depts)
    sw = sum(n[0] * r[0] for n, r in depts); aw = sum(n[0] for n, _ in depts)
    sm = sum(n[1] * r[1] for n, r in depts); am = sum(n[1] for n, _ in depts)
    return (sm / am - sw / aw) * 100   # men's overall rate minus women's, in percentage points
q("C01-D-003", T, "Overall selection rates of two groups reverse the department-wise comparison", "Easy",
  "Conceptual/application",
  r"A firm recruited for two departments, P and Q, and each applicant applied to exactly one of them. In Department P, $30$ women and $120$ men applied, and $80\%$ of the women and $75\%$ of the men were selected. In Department Q, $120$ women and $30$ men applied, and $25\%$ of the women and $20\%$ of the men were selected. Which of the following is true?",
  "MCQ",
  r"Women selected: $80\%$ of $30 = 24$ and $25\%$ of $120 = 30$, so $54$ of $150$, that is $36\%$. Men selected: $75\%$ of $120 = 90$ and $20\%$ of $30 = 6$, so $96$ of $150$, that is $64\%$. Although women had the higher selection rate in each department, overall the men's rate is higher by $64 - 36 = 28$ percentage points, because most women applied to the department that selected few applicants.",
  "Assuming that a group ahead in every department must also be ahead overall, or averaging rates without weighting them by the number of applicants.",
  "C01D-simpson-reversal", "One weighted computation per group; the trap is carrying the department-wise comparison over to the totals.",
  correct=r"The overall selection rate of men was $28$ percentage points higher than that of women",
  distractors=[(r"The overall selection rate of women was $5$ percentage points higher than that of men", r"Averages the department rates without weights: women $\frac{80 + 25}{2} = 52.5\%$ and men $\frac{75 + 20}{2} = 47.5\%$."),
               (r"The overall selection rate of men was $42$ percentage points higher than that of women", r"Reads the counts selected, $96$ men and $54$ women, as percentages and subtracts them."),
               (r"The overall selection rate of women was $28$ percentage points higher than that of men", r"Compares rejection rates ($64\%$ of women and $36\%$ of men were rejected) as if they were selection rates.")],
  check=_e3, values=[28, -5, 42, -28], cognitive="Understanding")


def _e4():
    p = symbols('p', positive=True)
    total_increase = 450 - 400
    return solve(Eq(p * Rational(20, 100), Rational(60, 100) * total_increase), p)[0]
q("C01-D-004", T, "Starting size of a department from its growth rate and its share of the firm's increase", "Easy",
  "Inverse/parameter",
  r"A company's headcount grew from $400$ to $450$ over a year. Department P's headcount grew by $20\%$ over the same year, and the growth of Department P accounted for $60\%$ of the company's increase in headcount. How many employees did Department P have at the start of the year?",
  "TITA",
  r"The company grew by $50$ employees, and $60\%$ of this, that is $30$ employees, was the growth of Department P. This growth is $20\%$ of Department P's starting headcount, so Department P started with $\frac{30}{0.2} = 150$ employees.",
  "Treating the share of the increase as a share of the whole company.",
  "C01D-contribution-to-growth", "Two short steps: the department's share of the increase, then a reverse percentage.",
  tita_answer=150, check=_e4, values=[150],
  tita_traps=[(240, r"Takes Department P as $60\%$ of the $400$ starting employees."),
              (180, "Reports Department P's headcount at the end of the year."),
              (30, "Reports the growth of Department P instead of its starting size.")],
  cognitive="Application")


def _e5():
    gp = 600 * Fraction(40, 100)
    gq = gp * Fraction(120, 100)
    nq = gq / Fraction(45, 100)
    return nq - 600
q("C01-D-005", T, "Comparing two schools through their numbers of girls", "Easy",
  "Multi-step word problem",
  r"School P has $600$ students, of whom $40\%$ are girls. In School Q, $45\%$ of the students are girls, and School Q has $20\%$ more girls than School P. How many more students does School Q have than School P?",
  "MCQ",
  r"School P has $40\%$ of $600 = 240$ girls, so School Q has $1.2 \times 240 = 288$ girls. These are $45\%$ of School Q, so School Q has $\frac{288}{0.45} = 640$ students, which is $40$ more than School P.",
  r"Applying the $20\%$ comparison to the total number of students instead of to the number of girls.",
  "C01D-group-comparison-chain", "Two short steps linking a subgroup comparison to group totals.",
  correct=r"$40$",
  distractors=[(r"$120$", r"Assumes School Q has $20\%$ more students than School P: $720 - 600 = 120$."),
               (r"$30$", r"Takes the difference in girls' percentages, $5\%$, of $600$."),
               (r"$48$", "Reports the difference in the number of girls, $288 - 240$.")],
  check=_e5, values=[40, 120, 30, 48], cognitive="Application")


def _e6():
    p, w = 80, Fraction(80 * 25, 100)
    w += 20; p += 20
    return w / p * 100
q("C01-D-006", T, "New percentage of women after women transfer into a department", "Easy",
  "Multi-step word problem",
  r"Department P has $80$ employees, of whom $25\%$ are women. Then $20$ women transfer into Department P from other departments, and nobody leaves Department P. What percentage of Department P's employees are now women?",
  "MCQ",
  r"Department P had $20$ women. After the transfer it has $20 + 20 = 40$ women among $80 + 20 = 100$ employees, so women now make up $40\%$.",
  "Increasing the number of women without increasing the department total.",
  "C01D-transfer-between-groups", "One update of both numerator and denominator.",
  correct=r"$40\%$",
  distractors=[(r"$50\%$", r"Adds the $20$ women to the numerator but keeps the old total: $\frac{40}{80}$."),
               (r"$20\%$", r"Counts only the newly transferred women: $\frac{20}{100}$."),
               (r"$45\%$", r"Adds $\frac{20}{100} = 20$ percentage points to the old $25\%$.")],
  check=_e6, values=[40, 50, 20, 45], cognitive="Application")


def _e7():
    for p in range(1, 2000):
        qn = p + 30
        wp, wq = Fraction(20, 100) * p, Fraction(50, 100) * qn
        if wp.denominator == 1 and wq.denominator == 1 and wq - wp == 39:
            return p
q("C01-D-007", T, "Size of one branch from two branch percentages, a size difference and a difference in subgroup counts", "Easy",
  "Inverse/parameter",
  r"A bank has two branches, P and Q. Women make up $20\%$ of the staff of Branch P and $50\%$ of the staff of Branch Q. Branch Q has $30$ more staff than Branch P, and $39$ more women than Branch P. How many staff does Branch P have?",
  "TITA",
  r"Let Branch P have $p$ staff, so Branch Q has $p + 30$. Then $0.5(p + 30) - 0.2p = 39$, so $0.3p + 15 = 39$, $0.3p = 24$ and $p = 80$. (Check: $16$ women in P and $55$ of $110$ in Q, a difference of $39$.)",
  "Dropping the size difference and applying the percentage gap to a common base.",
  "C01D-stream-linear-system", "A single linear equation built from two percentages of different bases.",
  tita_answer=80, check=_e7, values=[80],
  tita_traps=[(130, r"Ignores the $30$ extra staff of Branch Q: $0.3p = 39$."),
              (110, "Reports the number of staff in Branch Q.")],
  cognitive="Application")


def _e8():
    s, b = Fraction(40), Fraction(60)
    s2, b2 = s * Fraction(120, 100), b * Fraction(80, 100)
    return s2 / (s2 + b2) * 100
q("C01-D-008", T, "Share of one product after unequal changes in two products' unit sales", "Easy",
  "Multi-step word problem",
  r"A store sells only two kinds of phones, basic and smart. In $2024$, smartphones made up $40\%$ of the units sold. In $2025$, the number of smartphones sold rose by $20\%$ and the number of basic phones sold fell by $20\%$. What percentage of the units sold in $2025$ were smartphones?",
  "MCQ",
  r"Take $100$ units in $2024$: $40$ smartphones and $60$ basic phones. In $2025$ there are $48$ smartphones and $48$ basic phones, a total of $96$. Smartphones are $\frac{48}{96} = 50\%$ of units.",
  "Forgetting that the total number of units also changes.",
  "C01D-sales-segment-share", "Choosing a base of $100$ and recomputing the total settles it quickly.",
  correct=r"$50\%$",
  distractors=[(r"$48\%$", "Divides the $48$ smartphones by the old total of $100$ units."),
               (r"$60\%$", r"Adds $20$ percentage points to the old share of $40\%$."),
               (r"$40\%$", r"Assumes a $20\%$ rise and a $20\%$ fall cancel, leaving the share unchanged.")],
  check=_e8, values=[50, 48, 60, 40], cognitive="Application")


def _e9():
    f, h = Fraction(60), Fraction(40)
    gf, gh = f * Fraction(15, 100), h * Fraction(40, 100)
    return gh / (gf + gh) * 100
q("C01-D-009", T, "Share of a subgroup's members within a combined category", "Easy",
  "Conceptual/application",
  r"Of a company's employees, $60\%$ work in the factory and the rest work in the head office. Among factory workers $15\%$ are graduates, and among head-office staff $40\%$ are graduates. What percentage of the company's graduates work in the head office?",
  "MCQ",
  r"Take $100$ employees: $60$ in the factory with $9$ graduates and $40$ in the head office with $16$ graduates. There are $25$ graduates, of whom $16$ are in the head office, so the share is $\frac{16}{25} = 64\%$.",
  "Answering with the percentage of head-office staff who are graduates instead of the head office's share of graduates.",
  "C01D-share-of-subgroup", "Two subgroup counts and one ratio; the trap is the direction of the percentage.",
  correct=r"$64\%$",
  distractors=[(r"$40\%$", "Gives the percentage of head-office staff who are graduates, not the head office's share of all graduates."),
               (r"$16\%$", "Gives head-office graduates as a percentage of all employees."),
               (r"$36\%$", r"Computes the factory's share of graduates, $\frac{9}{25}$.")],
  check=_e9, values=[64, 40, 16, 36], cognitive="Understanding")


def _e10():
    n = 200
    lo = math.ceil(Fraction(12, 100) * n)   # each department has at least 24 employees
    from functools import lru_cache
    @lru_cache(maxsize=None)
    def ways(k, total, smallest):
        # can `total` be split into k distinct sizes, each >= smallest?
        if k == 0:
            return total == 0
        return any(ways(k - 1, total - s, s + 1) for s in range(smallest, total + 1))
    return max(k for k in range(1, 20) if ways(k, n, lo))
q("C01-D-010", T, "Largest number of departments when each must hold a minimum share and sizes must differ", "Easy",
  "Casework/optimisation",
  r"A company has $200$ employees, each in exactly one department. Every department has at least $12\%$ of the company's employees, and no two departments have the same number of employees. What is the largest possible number of departments?",
  "TITA",
  r"Each department has at least $12\%$ of $200 = 24$ employees, and the sizes are all different, so $k$ departments need at least $24 + 25 + \cdots + (23 + k)$ employees. For $k = 7$ this is $24 + 25 + \cdots + 30 = 189 \le 200$ (the extra $11$ can go to the largest department); for $k = 8$ it is $24 + 25 + \cdots + 31 = 220 > 200$. So the largest possible number is $7$.",
  "Ignoring the condition that the department sizes are all different.",
  "C01D-max-groups-min-share", "One bound to set up; the trap is dropping the distinct-sizes condition.",
  tita_answer=7, check=_e10, values=[7],
  tita_traps=[(8, r"Ignores the distinct sizes and uses $\frac{100}{12} \approx 8.3$."),
              (9, r"Rounds $\frac{100}{12} \approx 8.3$ up instead of down.")],
  cognitive="Application")


def _e11():
    t = symbols('t', positive=True)
    s, o, f = symbols('s o f', positive=True)
    sol = solve([Eq(s, Rational(40, 100) * t), Eq(o, Rational(150, 100) * f), Eq(f, 120), Eq(s + o + f, t)],
                [s, o, f, t], dict=True)[0]
    return sol[t]
q("C01-D-011", T, "Total staff from one department's share and a percentage comparison between the other two", "Easy",
  "Multi-step word problem",
  r"A company has only three departments: Sales, Operations and Finance. Sales has $40\%$ of the company's employees, and Operations has $50\%$ more employees than Finance. Finance has $120$ employees. How many employees does the company have?",
  "MCQ",
  r"Operations and Finance together have $60\%$ of the employees, and Operations is $1.5$ times Finance, so Finance has $\frac{60\%}{2.5} = 24\%$ of the employees. Hence the company has $\frac{120}{0.24} = 500$ employees (Sales $200$, Operations $180$, Finance $120$).",
  r"Misreading '$50\%$ more than' or splitting the remaining share equally.",
  "C01D-shares-sum-ratio", "One share and one comparison fix the split of the rest; a single division gives the total.",
  correct=r"$500$",
  distractors=[(r"$400$", r"Splits the remaining $60\%$ equally, so $120$ is $30\%$ of the company."),
               (r"$600$", r"Reads it as Finance having $50\%$ fewer employees than Operations, so Operations is twice Finance and Finance is $20\%$."),
               (r"$200$", r"Treats Finance's $120$ employees as the whole remaining $60\%$.")],
  check=_e11, values=[500, 400, 600, 200], cognitive="Application")


def _e12():
    p = symbols('p', positive=True)
    qn = symbols('qn', positive=True)
    Q = solve(Eq(Rational(75, 100) * qn, Rational(150, 100) * Rational(60, 100) * p), qn)[0]
    return simplify((Rational(40, 100) * p) / (Rational(25, 100) * Q))
q("C01-D-012", T, "Ratio of the numbers of women in two offices from their percentages and a comparison of men", "Easy",
  "Multi-step word problem",
  r"Women make up $40\%$ of the staff of Office P and $25\%$ of the staff of Office Q. Office Q has $50\%$ more men than Office P. The ratio of the number of women in Office P to the number of women in Office Q is",
  "MCQ",
  r"Let Office P have $100$ staff: $40$ women and $60$ men. Office Q has $1.5 \times 60 = 90$ men, who are $75\%$ of its staff, so Office Q has $120$ staff and $30$ women. The ratio is $40 : 30 = 4 : 3$.",
  "Applying the comparison to the whole staff instead of to the men, or comparing only the percentages.",
  "C01D-group-comparison-chain", "Two short steps: a comparison of one subgroup fixes the other office's size.",
  correct=r"$4 : 3$",
  distractors=[(r"$8 : 5$", r"Takes the ratio of the percentages, $40 : 25$."),
               (r"$16 : 15$", r"Reads it as Office Q having $50\%$ more staff: $40 : (0.25 \times 150) = 40 : 37.5$."),
               (r"$3 : 4$", "Writes the ratio of women in Office Q to women in Office P.")],
  check=_e12, values=[Rational(4, 3), Rational(8, 5), Rational(16, 15), Rational(3, 4)], cognitive="Application")

# ======================= MEDIUM =======================

def _m1():
    s = symbols('s', positive=True)
    return solve(Eq(Rational(60, 100) * s + Rational(30, 100) * (1500 - s), Rational(42, 100) * 1500), s)[0]
q("C01-D-013", T, "Size of one stream from stream-wise and overall percentages of girls", "Medium",
  "Inverse/parameter",
  r"A junior college has $1{,}500$ students, each in either the Science stream or the Commerce stream. Girls make up $60\%$ of the Science students, $30\%$ of the Commerce students and $42\%$ of all the students. How many students are in the Science stream?",
  "TITA",
  r"Let $s$ students be in Science. Then $0.6s + 0.3(1500 - s) = 0.42 \times 1500 = 630$, so $0.3s = 180$ and $s = 600$. By alligation, Science : Commerce $= (42 - 30) : (60 - 42) = 2 : 3$, and $\frac{2}{5}$ of $1500$ is $600$.",
  "Pairing the alligation differences with the wrong stream.",
  "C01D-alligation-group-sizes", "Needs a weighted-average equation in an unknown group size.",
  tita_answer=600, check=_m1, values=[600],
  tita_traps=[(900, "Reports the number of Commerce students, or pairs the alligation ratio the wrong way round."),
              (630, "Reports the total number of girls.")],
  cognitive="Application")


def _m2():
    x0, y0 = symbols('x0 y0', positive=True)
    t0 = Rational(100)
    sol = solve([Eq(x0 + y0, t0), Eq(x0 * Rational(50, 100), Rational(60, 100) * Rational(25, 100) * t0)],
                [x0, y0], dict=True)[0]
    return sol[x0] / t0 * 100
q("C01-D-014", T, "Earlier share of a product from its growth rate and its share of the total increase", "Medium",
  "Conceptual/application",
  r"A company sells only two products, X and Y. From $2024$ to $2025$, the total number of units it sold rose by $25\%$, and product X accounted for $60\%$ of this increase in units. The number of units of X sold rose by $50\%$. What percentage of the units sold in $2024$ were of product X?",
  "MCQ",
  r"Take $100$ units in $2024$. The increase is $25$ units, of which X accounts for $60\%$, that is $15$ units. This is a $50\%$ rise in X, so X sold $\frac{15}{0.5} = 30$ units in $2024$, which is $30\%$ of the units sold.",
  "Confusing a product's share of the increase with its share of sales.",
  "C01D-contribution-to-growth", "The student must separate the share of the increase from the share of sales and work back through a growth rate.",
  correct=r"$30\%$",
  distractors=[(r"$60\%$", "Takes X's share of the increase as its share of the units sold in $2024$."),
               (r"$36\%$", r"Reports X's share of the units sold in $2025$, $\frac{45}{125}$."),
               (r"$50\%$", r"Reads the $60\%$ as X's share of the $2025$ units: $0.6 \times 125 = 75$, so X sold $\frac{75}{1.5} = 50$ units in $2024$.")],
  check=_m2, values=[30, 60, 36, 50], cognitive="Analysis")


def _m3():
    p, qq = symbols('p q', positive=True)
    sp_ = solve(Eq((Rational(30, 100) * p + 20) / (p + 20), Rational(40, 100)), p)[0]
    sq = solve(Eq((Rational(60, 100) * qq - 20) / (qq - 20), Rational(55, 100)), qq)[0]
    assert sp_ == 120
    return sq
q("C01-D-015", T, "Original department size from percentages before and after a transfer of women", "Medium",
  "Inverse/parameter",
  r"In a firm, $30\%$ of the employees of Department P and $60\%$ of the employees of Department Q are women. Then $20$ women move from Department Q to Department P, and there are no other changes. After the move, women make up $40\%$ of Department P and $55\%$ of Department Q. How many employees did Department Q have before the move?",
  "TITA",
  r"Let Department Q have $q$ employees before the move. After the move it has $0.6q - 20$ women among $q - 20$ employees, so $0.6q - 20 = 0.55(q - 20)$, giving $0.05q = 9$ and $q = 180$. (Check: $108 - 20 = 88$ women among $160$, which is $55\%$.)",
  r"Treating the $5$ percentage point fall as $20$ being $5\%$ of the department.",
  "C01D-transfer-between-groups", "Requires an equation in which both numerator and denominator change.",
  tita_answer=180, check=_m3, values=[180],
  tita_traps=[(120, "Solves the Department P equation instead and reports $120$."),
              (160, "Reports the size of Department Q after the move."),
              (400, r"Takes $20$ women as $5\%$ of Department Q, since the share fell by $5$ points.")],
  cognitive="Application")


def _m4():
    t = symbols('t', positive=True)
    pr, sa, su = Rational(40, 100), Rational(25, 100), Rational(35, 100)
    tt = solve(Eq(sa * Rational(60, 100) * t - su * Rational(30, 100) * t, 36), t)[0]
    return pr * Rational(20, 100) * tt
q("C01-D-016", T, "Department totals from a difference between two percentage-of-percentage groups", "Medium",
  "Multi-step word problem",
  r"In a company, $40\%$ of the employees work in Production, $25\%$ in Sales and the rest in Support. Night shifts are worked by $20\%$ of the Production staff, $60\%$ of the Sales staff and $30\%$ of the Support staff. The number of Sales staff on night shifts exceeds the number of Support staff on night shifts by $36$. How many Production staff work night shifts?",
  "MCQ",
  r"Let the company have $t$ employees. Sales night staff are $0.25 \times 0.6t = 0.15t$ and Support night staff are $0.35 \times 0.3t = 0.105t$. So $0.045t = 36$ and $t = 800$. Production night staff are $0.4 \times 0.2 \times 800 = 64$.",
  "Answering for the wrong group once the total is found.",
  "C01D-base-from-interlocking", "Two percentage-of-percentage expressions must be compared before the base can be found.",
  correct=r"$64$",
  distractors=[(r"$120$", r"Reports the number of Sales staff on night shifts, $0.15 \times 800$."),
               (r"$84$", r"Reports the number of Support staff on night shifts, $0.105 \times 800$."),
               (r"$320$", "Reports the total number of Production staff.")],
  check=_m4, values=[64, 120, 84, 320], cognitive="Application")


def _m5():
    old = {'X': Fraction(40), 'Y': Fraction(40), 'Z': Fraction(20)}
    ch = {'X': Fraction(-25, 100), 'Y': Fraction(50, 100), 'Z': Fraction(50, 100)}
    new = {k: v * (1 + ch[k]) for k, v in old.items()}
    return new['Z'] / sum(new.values()) * 100
q("C01-D-017", T, "Share of one product in total units after three different growth rates", "Medium",
  "Multi-step word problem",
  r"A company makes only three products, X, Y and Z. In $2024$, they accounted for $40\%$, $40\%$ and $20\%$ respectively of the total units sold. In $2025$, compared with $2024$, units sold of X fell by $25\%$, while units sold of Y and of Z each rose by $50\%$. What percentage of the units sold in $2025$ were of product Z?",
  "MCQ",
  r"Take $100$ units in $2024$. In $2025$, X sells $30$, Y sells $60$ and Z sells $30$, a total of $120$. Product Z's share is $\frac{30}{120} = 25\%$.",
  "Forgetting that the total also changed, or averaging the growth rates without weights.",
  "C01D-sales-segment-share", "Three segments with different growth rates; the new total must be rebuilt.",
  correct=r"$25\%$",
  distractors=[(r"$30\%$", r"Grows Z's share by $50\%$ to $30$ but divides by the old total of $100$."),
               (r"$26\%$", r"Subtracts a $20\%$ overall growth from Z's $50\%$ growth and applies $30\%$ to the old share: $20 \times 1.3$."),
               (r"$24\%$", r"Takes the overall growth as the simple average $\frac{-25 + 50 + 50}{3} = 25\%$, so $\frac{30}{125}$.")],
  check=_m5, values=[25, 30, 26, 24], cognitive="Application")


def _m6():
    for n in range(1, 5000):
        eng = Fraction(85, 100) * n
        if eng.denominator == 1 and (eng * Fraction(16, 100)).denominator == 1:
            return n
q("C01-D-018", T, "Smallest workforce for which a percentage of a percentage gives whole numbers", "Medium",
  "Casework/optimisation",
  r"In a startup, exactly $85\%$ of the employees are engineers, and exactly $16\%$ of the engineers work fully remotely. What is the smallest possible number of employees in the startup?",
  "TITA",
  r"Engineers are $\frac{17}{20}$ of the staff, so the number of engineers is $\frac{17n}{20}$ and $20$ divides $n$. Remote engineers are $\frac{4}{25} \times \frac{17n}{20} = \frac{17n}{125}$, so $125$ divides $n$. The least common multiple of $20$ and $125$ is $500$ ($425$ engineers, $68$ of them remote).",
  "Checking only the combined percentage and not the intermediate group.",
  "C01D-integrality-min-total", "Two nested whole-number conditions; the intermediate group size must also be whole.",
  tita_answer=500, check=_m6, values=[500],
  tita_traps=[(125, r"Makes only the remote engineers, $13.6\%$ of $n$, a whole number; then the number of engineers, $106.25$, is not whole."),
              (25, r"Makes $16\%$ of $n$ a whole number, applying $16\%$ to all employees."),
              (20, r"Uses only the $85\% = \frac{17}{20}$ condition.")],
  cognitive="Analysis")


def _m7():
    best = None
    sci, com = 240, 360
    girls = Fraction(45, 100) * 600
    for cg in range(0, com + 1):
        if Fraction(cg, com) >= Fraction(35, 100):
            sg = girls - cg
            if 0 <= sg <= sci:
                v = Fraction(sg, sci) * 100
                best = v if best is None or v > best else best
    return best
q("C01-D-019", T, "Maximum possible percentage of girls in one stream given an overall percentage and a floor in the other", "Medium",
  "Casework/optimisation",
  r"A junior college has $600$ students: $40\%$ are in Science and the rest in Commerce. Girls make up $45\%$ of all the students, and at least $35\%$ of the Commerce students are girls. What is the largest possible percentage of Science students who are girls?",
  "MCQ",
  r"There are $240$ Science and $360$ Commerce students, and $270$ girls in all. Commerce has at least $0.35 \times 360 = 126$ girls, so Science has at most $270 - 126 = 144$ girls. That is $\frac{144}{240} = 60\%$, and it is attained when Commerce has exactly $126$ girls.",
  "Working with percentages of different bases as if they were shares of the same whole.",
  "C01D-range-weighted-percent", "Turning a lower bound in one group into an upper bound in the other requires working with counts.",
  correct=r"$60\%$",
  distractors=[(r"$24\%$", "Divides the $144$ Science girls by all $600$ students instead of by the $240$ Science students."),
               (r"$25\%$", r"Subtracts the percentages directly, $\frac{45 - 35}{40}$, as if $35\%$ were a share of all students."),
               (r"$45\%$", "Assumes each stream must have the overall percentage of girls.")],
  check=_m7, values=[60, 24, 25, 45], cognitive="Analysis")


def _m8():
    m = symbols('m', positive=True)
    total0 = 80
    w0 = total0 * Rational(30, 100)
    sol = solve(Eq((w0 + 2 * m) / (total0 - m + 2 * m), Rational(40, 100)), m)
    assert len(sol) == 1 and sol[0].is_integer
    return sol[0]
q("C01-D-020", T, "Men leaving and twice as many women joining change the women's share", "Medium",
  "Inverse/parameter",
  r"A committee has $80$ members, of whom $30\%$ are women. Some men leave the committee and twice as many women join it. Women then make up $40\%$ of the committee. How many men left the committee?",
  "TITA",
  r"Let $m$ men leave, so $2m$ women join. Women become $24 + 2m$ out of a new total of $80 + m$. Then $24 + 2m = 0.4(80 + m) = 32 + 0.4m$, so $1.6m = 8$ and $m = 5$. Check: $34$ women out of $85$ members is $40\%$.",
  "Assuming the committee size stays $80$, so that the target share converts directly to a count of women.",
  "C01D-adjust-count-to-target-share", "Two ideas: the total changes along with the women's count, so the target share must be applied to the new total, giving a linear equation in the number who left.",
  tita_answer=5, check=_m8, values=[5],
  tita_traps=[(4, r"Keeps the total at $80$: women must reach $32$, so $8$ women joined and half as many, $4$, men left."),
              (10, "Reports the number of women who joined instead of the number of men who left.")],
  cognitive="Application")


def _m9():
    s, p, u = symbols('s p u', real=True)
    sols = solve([Eq(u, p + Rational(15, 100)),
                  Eq(s * p + (1 - s) * u, Rational(24, 100)),
                  Eq((1 - s) * u, 3 * s * p)], [s, p, u], dict=True)
    ok = [d for d in sols if all(0 < d[v] < 1 for v in (s, p, u))]
    assert len(ok) == 1
    return ok[0][s] * 100
q("C01-D-021", T, "Share of one group from interlocking conditions on two groups' rates and counts", "Difficult",
  "Inverse/parameter",
  r"Every student of a university is either an undergraduate or a postgraduate. The percentage of undergraduates who live on campus is $15$ percentage points higher than the percentage of postgraduates who live on campus. Altogether $24\%$ of the students live on campus, and the number of undergraduates living on campus is $3$ times the number of postgraduates living on campus. What percentage of the students are postgraduates?",
  "MCQ",
  r"On-campus residents are $24\%$ of the students and split $1 : 3$, so on-campus postgraduates are $6\%$ and on-campus undergraduates $18\%$ of all students. Let a fraction $s$ of the students be postgraduates and let $p$ of them live on campus; then $sp = 0.06$ and $(1 - s)(p + 0.15) = 0.18$. Substituting $s = \frac{0.06}{p}$ gives $(p - 0.06)(p + 0.15) = 0.18p$, that is $p^2 - 0.09p - 0.009 = 0$, so $(p - 0.15)(p + 0.06) = 0$ and $p = 0.15$. Hence $s = \frac{0.06}{0.15} = 40\%$ (and $30\%$ of the undergraduates live on campus).",
  "Equating a group's share of the on-campus residents with its share of all students, or reporting the wrong group.",
  "C01D-interlocking-rates", "Three interlocking conditions (a percentage point gap, an overall rate and a ratio of counts) lead to a quadratic in the unknown rate.",
  correct=r"$40\%$",
  distractors=[(r"$25\%$", r"Takes the postgraduates' share of on-campus residents, $\frac{1}{4}$, as their share of all students."),
               (r"$60\%$", "Reports the percentage of students who are undergraduates."),
               (r"$30\%$", "Reports the percentage of undergraduates who live on campus.")],
  check=_m9, values=[40, 25, 60, 30], cognitive="Analysis", exams=CX)


def _m10():
    x = symbols('x', positive=True)
    e = Rational(40, 100) * Rational(30, 100)
    return solve(Eq(e / (e + Rational(60, 100) * x), Rational(25, 100)), x)[0] * 100
q("C01-D-022", T, "Unknown subgroup percentage from one group's share of a combined category", "Medium",
  "Inverse/parameter",
  r"At a coaching centre, $40\%$ of the students are in the Engineering stream and the rest are in the Medical stream. Of the Engineering students, $30\%$ live in the centre's hostel, and only the centre's students live in the hostel. Engineering students make up $25\%$ of all hostel residents. What percentage of the Medical students live in the hostel?",
  "MCQ",
  r"Take $100$ students: $40$ Engineering, of whom $12$ are in the hostel. These $12$ are $25\%$ of the residents, so the hostel has $48$ residents, of whom $36$ are Medical students. There are $60$ Medical students, so $\frac{36}{60} = 60\%$ of them live in the hostel.",
  "Stopping at a count that is a percentage of all students rather than of the Medical stream.",
  "C01D-share-of-subgroup", "Working backwards from a share of a combined category to a within-group percentage.",
  correct=r"$60\%$",
  distractors=[(r"$48\%$", "Reports hostel residents as a percentage of all students."),
               (r"$36\%$", "Reports Medical hostel residents as a percentage of all students, without dividing by $60$."),
               (r"$90\%$", "Sets $30 : x = 25 : 75$, treating the residents' split as the ratio of the two hostel percentages.")],
  check=_m10, values=[60, 48, 36, 90], cognitive="Application")


def _m11():
    c24 = Fraction(1000)           # any starting count; the answer is a ratio
    c25 = c24 * Fraction(80, 100) / Fraction(64, 100)    # renewals = 80% of 2024 = 64% of 2025
    c26 = c25 * Fraction(90, 100) / Fraction(75, 100)    # renewals = 90% of 2025 = 75% of 2026
    return (c26 - c24) / c24 * 100
q("C01-D-023", T, "Growth in customer numbers from renewal rates and the renewing share of each year's customers", "Medium",
  "Multi-step word problem",
  r"A software firm sells one-year subscriptions, and each year's customers are either renewing customers from the previous year or new customers. Of its $2024$ customers, $80\%$ renewed for $2025$, and these renewing customers made up $64\%$ of its $2025$ customers. Of its $2025$ customers, $90\%$ renewed for $2026$, and they made up $75\%$ of its $2026$ customers. By what percent did the number of customers grow from $2024$ to $2026$?",
  "MCQ",
  r"The renewing customers link consecutive years: $0.8 \times C_{2024} = 0.64 \times C_{2025}$, so $C_{2025} = 1.25\,C_{2024}$; and $0.9 \times C_{2025} = 0.75 \times C_{2026}$, so $C_{2026} = 1.2\,C_{2025}$. Hence $C_{2026} = 1.25 \times 1.2 \times C_{2024} = 1.5\,C_{2024}$, a growth of $50\%$.",
  "Adding yearly growth rates instead of multiplying the factors, or reading percentage point gaps as growth.",
  "C01D-retention-cohort", "The same group of renewing customers is a percentage of two different years' totals, and two such links must be chained.",
  correct=r"$50\%$",
  distractors=[(r"$45\%$", r"Adds the yearly growth rates of $25\%$ and $20\%$ instead of multiplying the factors."),
               (r"$31\%$", r"Adds the percentage point gaps, $(80 - 64) + (90 - 75)$."),
               (r"$25\%$", r"Stops at the growth from $2024$ to $2025$.")],
  check=_m11, values=[50, 45, 31, 25], cognitive="Application")


def _m12():
    t = Fraction(100)
    rd = t * Fraction(20, 100)
    rd_phd = rd * Fraction(60, 100)
    phd = rd_phd / Fraction(60, 100)
    return (phd - rd_phd) / (t - rd) * 100
q("C01-D-024", T, "Percentage in the complementary group from one group's share of a category", "Medium",
  "Conceptual/application",
  r"In a technology company, $20\%$ of the employees work in Research. Of the Research employees, $60\%$ hold a doctorate, and these Research doctorate holders make up $60\%$ of all doctorate holders in the company. What percentage of the employees outside Research hold a doctorate?",
  "MCQ",
  r"Take $100$ employees: $20$ in Research, $12$ of them with a doctorate. These $12$ are $60\%$ of all doctorate holders, so there are $20$, of whom $8$ work outside Research. There are $80$ employees outside Research, so the answer is $\frac{8}{80} = 10\%$.",
  "Dividing by the whole company instead of the group the question names.",
  "C01D-share-of-subgroup", r"The same $60\%$ appears with two different bases; the student must keep them apart.",
  correct=r"$10\%$",
  distractors=[(r"$8\%$", "Reports non-Research doctorate holders as a percentage of all employees."),
               (r"$40\%$", "Gives the non-Research share of all doctorate holders."),
               (r"$20\%$", "Gives the percentage of all employees who hold a doctorate.")],
  check=_m12, values=[10, 8, 40, 20], cognitive="Analysis")


def _m13():
    x = symbols('x', positive=True)
    w0, m0 = 25, 75
    w1 = w0 * Rational(120, 100)
    m1 = solve(Eq(w1 / (w1 + x), Rational(25 + 15, 100)), x)[0]
    return (m0 - m1) / m0 * 100
q("C01-D-025", T, "Percent fall in one group given the other's growth and a percentage point change in share", "Medium",
  "Inverse/parameter",
  r"Last year, $25\%$ of the members of a club were women. This year the number of women members is $20\%$ higher than last year, and the share of women among the members is $15$ percentage points higher than last year. By what percent has the number of men members fallen?",
  "MCQ",
  r"Take $25$ women and $75$ men last year. This year there are $30$ women, and they form $25 + 15 = 40\%$ of the club, so the club has $75$ members, of whom $45$ are men. The men fell from $75$ to $45$, a fall of $40\%$.",
  "Mixing up percentage points of share with percent changes in numbers.",
  "C01D-points-versus-percent", "Requires converting a percentage point change into a new total before finding the men's change.",
  correct=r"$40\%$",
  distractors=[(r"$15\%$", "Takes the $15$ percentage point change in share as the percent change in men."),
               (r"$20\%$", "Assumes the men fell by the same percent as the women rose."),
               (r"$25\%$", "Reports the fall in total membership, from $100$ to $75$.")],
  check=_m13, values=[40, 15, 20, 25], cognitive="Application")


def _m14():
    r = symbols('r', positive=True)  # Q staff = r times P staff, 1 <= r <= 2
    f = (Rational(25, 100) + Rational(55, 100) * r) / (1 + r) * 100
    vals = [f.subs(r, v) for v in (1, 2)]
    for v in [Rational(k, 10) for k in range(10, 21)]:
        assert min(vals) <= f.subs(r, v) <= max(vals)
    return (min(vals), max(vals))
q("C01-D-026", T, "Range of the overall percentage when the relative sizes of two offices are only bounded", "Medium",
  "Casework/optimisation",
  r"A company has two offices, P and Q. Women make up $25\%$ of the staff at Office P and $55\%$ of the staff at Office Q. Office Q has at least as many staff as Office P and at most twice as many. Over all staff sizes allowed by these conditions, the smallest and the largest possible values of the percentage of women among the combined staff of the two offices are",
  "MCQ",
  r"The overall percentage is a weighted average that moves towards $55\%$ as Office Q gets relatively larger. With equal staff it is $\frac{25 + 55}{2} = 40\%$; when Office Q has twice the staff it is $\frac{25 + 2 \times 55}{3} = 45\%$. So the smallest possible value is $40\%$ and the largest is $45\%$.",
  "Ignoring the bounds on the relative sizes, or applying the weight to the wrong office.",
  "C01D-range-weighted-percent", "Requires seeing that the weighted average is monotonic in the size ratio and evaluating both ends.",
  correct=r"$40\%$ and $45\%$",
  distractors=[(r"$25\%$ and $55\%$", "Ignores the bounds on the relative sizes of the two offices."),
               (r"$35\%$ and $40\%$", "Gives the double weight to Office P instead of Office Q."),
               (r"$40\%$ and $55\%$", "Uses the lower bound on Office Q's size but not the upper bound.")],
  check=_m14, values=[(40, 45), (25, 55), (35, 40), (40, 55)], cognitive="Analysis")


def _m15():
    c = symbols('c', positive=True)
    a = Rational(75, 100) * c
    s = Rational(160, 100) * a
    cc = solve(Eq(s - c, 84), c)[0]
    return (c + a + s).subs(c, cc)
q("C01-D-027", T, "Total students from chained percentage comparisons between three streams", "Medium",
  "Multi-step word problem",
  r"In a junior college, the number of Arts students is $25\%$ less than the number of Commerce students, and the number of Science students is $60\%$ more than the number of Arts students. There are $84$ more Science students than Commerce students. Every student is in exactly one of the three streams. How many students does the college have?",
  "MCQ",
  r"Let Commerce have $c$ students. Arts has $0.75c$ and Science has $1.6 \times 0.75c = 1.2c$. Then $1.2c - c = 0.2c = 84$, so $c = 420$. The total is $420 + 315 + 504 = 1239$.",
  "Using the wrong base for a percentage comparison, or adding percentages instead of multiplying factors.",
  "C01D-group-comparison-chain", "Two chained comparisons on different bases, then a difference fixes the scale.",
  correct=r"$1{,}239$",
  distractors=[(r"$924$", r"Reads Arts as the base: Commerce $= 1.25 \times$ Arts, so $0.35a = 84$, $a = 240$ and the total is $240 + 300 + 384$."),
               (r"$469$", r"Takes Science as $60\%$ more than Commerce: $0.6c = 84$, $c = 140$, total $140 + 105 + 224$."),
               (r"$744$", "Adds the percentages to get Science $= 1.35c$: $0.35c = 84$, $c = 240$, total $240 + 180 + 324$.")],
  check=_m15, values=[1239, 924, 469, 744], cognitive="Application")


def _m16():
    x = symbols('x', positive=True)
    w, m = Rational(40), Rational(60)
    w1 = w * Rational(90, 100)
    sol = solve(Eq(w1 / (w1 + m * (1 - x / 100)), Rational(48, 100)), x)[0]
    return sol
q("C01-D-028", T, "Attrition rate of one group from the change in the other group's share", "Medium",
  "Inverse/parameter",
  r"At the start of a year, $40\%$ of a company's employees were women. During the year, $10\%$ of the women and a certain percentage of the men left the company, and nobody joined. At the end of the year, women made up $48\%$ of the employees. What percentage of the men left the company during the year? Enter the number of percent.",
  "TITA",
  r"Take $40$ women and $60$ men. At the end $36$ women remain, and they form $48\%$, so $\frac{36}{0.48} = 75$ employees remain, of whom $39$ are men. So $21$ of the $60$ men left, which is $35\%$.",
  "Working with the overall attrition or the percentage point change instead of the men's own base.",
  "C01D-leavers-change-composition", "Requires rebuilding the new total from the women before turning to the men.",
  tita_answer=35, check=_m16, values=[35],
  tita_traps=[(25, r"Reports the overall percentage of employees who left, $\frac{25}{100}$."),
              (8, "Reports the $8$ percentage point rise in the women's share.")],
  cognitive="Application")


def _m17():
    x = symbols('x')
    e, p = 20000 * Rational(30, 100), 20000 * Rational(70, 100)
    return solve(Eq(e * (1 + x / 100) + p * Rational(90, 100), 20000 * Rational(105, 100)), x)[0]
q("C01-D-029", T, "Growth needed in one segment for a target overall growth", "Medium",
  "Inverse/parameter",
  r"A publisher sold $20{,}000$ books in $2024$, of which $30\%$ were e-books and the rest print books. In $2025$, the number of print books sold fell by $10\%$, while the total number of books sold rose by $5\%$. By what percent did the number of e-books sold rise from $2024$ to $2025$?",
  "MCQ",
  r"In $2024$ there were $6000$ e-books and $14000$ print books. In $2025$ print sales were $12600$ and total sales $21000$, so e-book sales were $8400$. The rise is $\frac{2400}{6000} = 40\%$.",
  "Combining the growth rates without weighting them by the size of each segment.",
  "C01D-sales-segment-share", "Needs segment counts and a reconstruction of one segment from the total.",
  correct=r"$40\%$",
  distractors=[(r"$15\%$", r"Adds the two given percentages, $5\% + 10\%$."),
               (r"$20\%$", r"Treats overall growth as the simple average of the two segments' growth: $\frac{x - 10}{2} = 5$."),
               (r"$12\%$", "Divides the increase of $2400$ e-books by the $2024$ total of $20000$ books.")],
  check=_m17, values=[40, 15, 20, 12], cognitive="Application")


def _m18():
    s = symbols('s', positive=True)
    return solve(Eq(Rational(60, 100) * (900 - s) - Rational(40, 100) * s, 60), s)[0]
q("C01-D-030", T, "Stream sizes from stream-wise percentages and a difference in subgroup counts", "Medium",
  "Multi-step word problem",
  r"A junior college has $900$ students, each in either Science or Commerce. Girls make up $40\%$ of the Science students and $60\%$ of the Commerce students. The number of girls in Commerce exceeds the number of girls in Science by $60$. How many students are in Science?",
  "TITA",
  r"Let $s$ students be in Science. Then $0.6(900 - s) - 0.4s = 60$, so $540 - s = 60$ and $s = 480$. (Check: $192$ Science girls and $252$ Commerce girls, a difference of $60$.)",
  "Applying both percentages to the same base.",
  "C01D-stream-linear-system", "Two unknowns linked by a known total and a difference of percentage expressions.",
  tita_answer=480, check=_m18, values=[480],
  tita_traps=[(420, "Reports the number of Commerce students."),
              (300, "Applies the $20$ percentage point gap to an unknown common base: $0.2s = 60$.")],
  cognitive="Application")

# ======================= DIFFICULT =======================

def _d1():
    def hit(p, n):
        lo, hi = Fraction(2 * p - 1, 2), Fraction(2 * p + 1, 2)
        for w in range(n + 1):
            v = Fraction(100 * w, n)
            if lo <= v < hi:
                return True
        return False
    for n in range(1, 1000):
        # no exact half boundary arises for n below the answer (checked in _d1_boundary)
        if hit(29, n) and hit(16, n):
            return n

def _d1_boundary():
    for n in range(1, 31):
        for w in range(n + 1):
            v = Fraction(100 * w, n)
            assert v not in (Fraction(57, 2), Fraction(59, 2), Fraction(31, 2), Fraction(33, 2)), (n, w)
    return _d1()
q("C01-D-031", T, "Smallest group size consistent with two percentages rounded to whole numbers", "Difficult",
  "Casework/optimisation",
  r"A survey report on a startup states, after rounding each figure to the nearest whole number, that $29\%$ of its employees are women and $16\%$ of its employees work remotely. What is the smallest possible number of employees in the startup?",
  "TITA",
  r"We need $n$ with a whole number $w$ such that $28.5 \le \frac{100w}{n} < 29.5$, and another whole number $r$ with $15.5 \le \frac{100r}{n} < 16.5$. The first alone is possible from $n = 7$ ($\frac{2}{7} \approx 28.6\%$); the second is rarer: the only values of $n$ up to $31$ that work for $16\%$ are $19$ ($\frac{3}{19} \approx 15.8\%$), $25$ ($\frac{4}{25} = 16\%$) and $31$. For $n = 19$ the nearest women's figures are $\frac{5}{19} \approx 26.3\%$ and $\frac{6}{19} \approx 31.6\%$; for $n = 25$ they are $28\%$ and $32\%$; both fail. For $n = 31$ the figures are $\frac{9}{31} \approx 29.03\%$ and $\frac{5}{31} \approx 16.13\%$. So the answer is $31$.",
  "Taking the least common multiple of the individual minima, or satisfying only one condition.",
  "C01D-rounded-percent-min-size", "Rounding turns each percentage into an interval; the two interval conditions must be checked case by case.",
  tita_answer=31, check=_d1_boundary, values=[31],
  tita_traps=[(19, r"Satisfies only the $16\%$ condition."),
              (133, r"Multiplies the two individual minima, $7 \times 19$."),
              (100, "Assumes the percentages must be exact.")],
  cognitive="Analysis", exams=CX)


def _d2():
    t = symbols('t', positive=True)
    w = Rational(40, 100) * t * Rational(75, 100)
    m = Rational(60, 100) * t * Rational(90, 100) + 80
    return solve(Eq(w / (w + m), Rational(30, 100)), t)[0]
q("C01-D-032", T, "Original workforce from leavers in both groups and new hires in one group", "Difficult",
  "Inverse/parameter",
  r"At the start of a year, $40\%$ of a company's employees were women. During the year, $25\%$ of the women and $10\%$ of the men left the company, and the company hired $80$ new employees, all of them men. Nobody else joined or left. At the end of the year, women made up $30\%$ of the employees. How many employees did the company have at the start of the year?",
  "TITA",
  r"Let the start total be $t$. At the end there are $0.75 \times 0.4t = 0.3t$ women and $0.9 \times 0.6t + 80 = 0.54t + 80$ men. Women form $30\%$, so $0.3t = 0.3(0.84t + 80)$, that is $t = 0.84t + 80$, giving $0.16t = 80$ and $t = 500$. (The end total is also $500$: $150$ women and $350$ men.)",
  "Ignoring the men who left, or treating the $10$ point fall in share as $80$ people.",
  "C01D-leavers-change-composition", "Three simultaneous changes (two leaver rates and new hires) must be combined in one equation.",
  tita_answer=500, check=_d2, values=[500],
  tita_traps=[(800, "Ignores the men who left: $0.3t = 0.3(0.9t + 80)$ gives $800$; the same value comes from treating the $10$ point fall as $80$ people."),
              (350, "Reports the number of men at the end of the year.")],
  cognitive="Analysis", exams=CX)


def _d3():
    best = 0
    pct = [10, 24, 35, 64]
    for a in range(40, 61):
        for b in range(40, 61):
            for c in range(40, 61):
                d = 200 - a - b - c
                if not 40 <= d <= 60:
                    continue
                sizes = [a, b, c, d]
                if all((s * p) % 100 == 0 for s, p in zip(sizes, pct)):
                    best = max(best, sum(s * p // 100 for s, p in zip(sizes, pct)))
    return best
q("C01-D-033", T, "Maximum number of women when department sizes are bounded and every percentage must give a whole number", "Difficult",
  "Casework/optimisation",
  r"A company has $200$ employees, each in exactly one of four departments. Women make up exactly $10\%$, $24\%$, $35\%$ and $64\%$ of the employees of the four departments respectively. Each department has at least $20\%$ and at most $30\%$ of the company's employees. What is the largest possible number of women in the company?",
  "TITA",
  r"Each department has between $40$ and $60$ employees, and each percentage must give a whole number of women. $64\% = \frac{16}{25}$ and $24\% = \frac{6}{25}$, so those two departments have a multiple of $25$ employees, which forces exactly $50$ each. $35\% = \frac{7}{20}$, so that department has $40$ or $60$, and the $10\%$ department takes the rest of the $100$. Putting $60$ in the $35\%$ department and $40$ in the $10\%$ department gives $4 + 12 + 21 + 32 = 69$ women, which beats $6 + 12 + 14 + 32 = 64$ for the other split.",
  "Allocating greedily to the high-percentage departments without checking that every department's count of women is a whole number.",
  "C01D-range-weighted-percent", "Size bounds and whole-number conditions interact: the greedy allocation is infeasible and the allowed sizes must be found case by case.",
  tita_answer=69, check=_d3, values=[69],
  tita_traps=[(73, r"Allocates greedily, $60$ to the $64\%$ and $35\%$ departments and $40$ to the others: $4 + 9.6 + 21 + 38.4$, ignoring that $9.6$ and $38.4$ are not whole numbers."),
              (64, r"Puts $60$ in the $10\%$ department and $40$ in the $35\%$ department after fixing the other two at $50$."),
              (128, r"Assumes every employee can be in the $64\%$ department.")],
  cognitive="Analysis", exams=CX)


def _d4():
    for n in range(1, 10000):
        rd = Fraction(175, 1000) * n
        if rd.denominator != 1:
            continue
        rdw = rd * Fraction(24, 100)
        if rdw.denominator != 1:
            continue
        women = rdw / Fraction(30, 100)
        if women.denominator == 1:
            return women
q("C01-D-034", T, "Smallest number of women when three nested percentages must all give whole numbers", "Difficult",
  "Casework/optimisation",
  r"In a company, exactly $17.5\%$ of the employees work in Research. Exactly $24\%$ of the Research employees are women, and these women make up exactly $30\%$ of all the women in the company. What is the smallest possible number of women in the company?",
  "TITA",
  r"With $n$ employees, Research has $\frac{7n}{40}$ people, so $40$ divides $n$. Research women number $\frac{6}{25} \times \frac{7n}{40} = \frac{21n}{500}$, so $500$ divides $n$. Hence $n$ is a multiple of $1000$. For $n = 1000$: Research has $175$ people, $42$ of them women, and all women number $\frac{42}{0.3} = 140$. Since the number of women is $\frac{21n}{500} \div 0.3 = 0.14n$, the smallest value is $140$.",
  "Checking only the combined percentage and missing the condition that the Research headcount must be whole.",
  "C01D-integrality-min-total", "Three nested percentages, each imposing a divisibility condition on the base.",
  tita_answer=140, check=_d4, values=[140],
  tita_traps=[(70, r"Uses $n = 500$, which makes $\frac{21n}{500}$ whole but gives $87.5$ Research employees."),
              (42, "Reports the number of women in Research."),
              (1000, "Reports the smallest number of employees.")],
  cognitive="Analysis", exams=CX)


def _d5():
    p, qq, r, x = symbols('p q r x', positive=True)
    sol = solve([Eq(Rational(30, 100) * p, Rational(45, 100) * qq),
                 Eq(Rational(60, 100) * qq, Rational(36, 100) * r),
                 Eq(qq, 6)], [p, qq, r], dict=True)[0]
    P, Q, R = sol[p], sol[qq], sol[r]
    return solve(Eq(Rational(20, 100) * P + Rational(40, 100) * Q + x / 100 * R, Rational(34, 100) * (P + Q + R)), x)[0]
q("C01-D-035", T, "Unknown branch percentage when branch sizes are linked by equal percentage statements", "Difficult",
  "Inverse/parameter",
  r"A bank has three branches, P, Q and R. $30\%$ of the staff of Branch P equals $45\%$ of the staff of Branch Q in number, and $60\%$ of the staff of Branch Q equals $36\%$ of the staff of Branch R in number. Women make up $20\%$ of the staff of Branch P, $40\%$ of the staff of Branch Q and $34\%$ of the combined staff of the three branches. What percentage of the staff of Branch R are women?",
  "MCQ",
  r"From $0.3P = 0.45Q$, $P = 1.5Q$; from $0.6Q = 0.36R$, $R = \frac{5}{3}Q$. Take $Q = 6$: then $P = 9$, $R = 10$ and the total is $25$. Women: $0.2 \times 9 + 0.4 \times 6 + 10x = 0.34 \times 25 = 8.5$, so $10x = 4.3$ and $x = 43\%$.",
  "Inverting an equal-percentage relation, or averaging percentages without weights.",
  "C01D-equal-percent-relations", r"Two relations of the form $a\%$ of one equals $b\%$ of another must be converted to size ratios before a weighted equation can be solved.",
  correct=r"$43\%$",
  distractors=[(r"$42\%$", r"Takes the simple average: $\frac{20 + 40 + x}{3} = 34$."),
               (r"$36\%$", r"Inverts the first relation to $P = \frac{2}{3}Q$, so sizes $4, 6, 10$: $0.8 + 2.4 + 10x = 6.8$."),
               (r"$61\%$", "Omits Branch P's women: $2.4 + 10x = 8.5$.")],
  check=_d5, values=[43, 42, 36, 61], cognitive="Analysis", exams=CX)


def _d6():
    qp = symbols('qp', positive=True)  # women fraction in Q
    P, Q, R = Rational(3), Rational(6), Rational(3)
    s = solve(Eq(Rational(20, 100) * P + qp * Q + 2 * qp * R, Rational(36, 100) * (P + Q + R)), qp)[0]
    return 2 * s * 100
q("C01-D-036", T, "Department percentage from overall percentage with linked sizes and linked percentages", "Difficult",
  "Inverse/parameter",
  r"A firm has three departments, P, Q and R. Department P has one quarter of the firm's employees, and $20\%$ of them are women. Department Q has twice as many employees as Department R, while the percentage of women in Department R is twice the percentage of women in Department Q. Women make up $36\%$ of the firm's employees. What percentage of the employees of Department R are women?",
  "MCQ",
  r"Take $12$ employees: P has $3$, and the other $9$ split as Q $= 6$, R $= 3$. Women in the firm: $0.36 \times 12 = 4.32$; in P, $0.6$. If Q has a fraction $q$ of women, then $6q + 3(2q) = 12q = 4.32 - 0.6 = 3.72$, so $q = 31\%$ and Department R has $62\%$ women.",
  "Not removing Department P's women before using the remaining relations, or reporting Department Q's value.",
  "C01D-weighted-overall-percent", "Two linked relations (sizes and percentages) inside a weighted average, with one department to strip out first.",
  correct=r"$62\%$",
  distractors=[(r"$31\%$", "Reports the percentage of women in Department Q."),
               (r"$72\%$", r"Forgets to remove Department P: $12q = 4.32$ gives $q = 36\%$ and R $= 72\%$."),
               (r"$54\%$", r"Applies $36\%$ to the $9$ employees outside P, $12q = 3.24$, so $q = 27\%$ and R $= 54\%$.")],
  check=_d6, values=[62, 31, 72, 54], cognitive="Analysis", exams=CX)


def _d7():
    b0 = Fraction(100)
    y0 = b0 * Fraction(14, 100) * Fraction(25, 100)
    b1 = b0 * Fraction(105, 100)
    y1 = b1 * Fraction(14 + 2, 100) * Fraction(25 + 10, 100)
    return (y1 - y0) / y0 * 100
q("C01-D-037", T, "Percent change in a percentage of a percentage when the total and both shares change", "Medium",
  "Multi-step word problem",
  r"A state spent $14\%$ of its total budget on education, and $25\%$ of the education spending went to higher education. Next year the total budget rose by $5\%$, the share of the total budget spent on education rose by $2$ percentage points, and the share of education spending that went to higher education rose by $10$ percentage points. By what percent did spending on higher education rise?",
  "MCQ",
  r"Take a budget of $100$: higher education gets $100 \times 0.14 \times 0.25 = 3.5$. Next year it gets $105 \times 0.16 \times 0.35 = 5.88$. The rise is $\frac{5.88}{3.5} = 1.68$, that is $68\%$.",
  "Treating percentage point changes as percent changes, adding changes, or ignoring the growth of the total.",
  "C01D-percent-of-percent-chain", "Three multiplicative factors, two of which are given as percentage point changes on different bases; about two minutes once the factors are written down.",
  correct=r"$68\%$",
  distractors=[(r"$60\%$", r"Ignores the $5\%$ growth in the total budget: $\frac{16 \times 35}{14 \times 25} = 1.6$."),
               (r"$20\%$", r"Ignores the change in the higher-education share: $1.05 \times \frac{16}{14} = 1.2$."),
               (r"$17\%$", "Adds the three changes: $5 + 2 + 10$.")],
  check=_d7, values=[68, 60, 20, 17], cognitive="Application", exams=ALL)


def _d8():
    p, qq, x = symbols('p q x', positive=True)
    sol = solve([Eq(Rational(25, 100) * p + x, Rational(40, 100) * p),
                 Eq(Rational(50, 100) * qq - x, Rational(40, 100) * qq),
                 Eq(p + qq, 500)], [p, qq, x], dict=True)[0]
    return sol[x]
q("C01-D-038", T, "Equal two-way transfer that brings two departments to the same percentage", "Difficult",
  "Inverse/parameter",
  r"Two departments, P and Q, have $500$ employees in all. Women make up $25\%$ of Department P and $50\%$ of Department Q. A certain number of women move from Department Q to Department P, and the same number of men move from Department P to Department Q, so neither department changes in size. Afterwards, women make up exactly $40\%$ of each department. How many women moved?",
  "MCQ",
  r"Let $x$ women move. Department P gains $x$ women at fixed size $p$: $0.25p + x = 0.4p$, so $x = 0.15p$. Department Q loses $x$ women at fixed size $q$: $0.5q - x = 0.4q$, so $x = 0.1q$. Hence $0.15p = 0.1q$, so $p : q = 2 : 3$, giving $p = 200$, $q = 300$ and $x = 30$.",
  "Applying a department's percentage change to the wrong department or to the whole firm.",
  "C01D-transfer-between-groups", "Two simultaneous composition equations with a shared unknown; the swap keeps sizes fixed, which is the key insight.",
  correct=r"$30$",
  distractors=[(r"$20$", "Applies Department Q's $10$ point fall to Department P's $200$ employees."),
               (r"$45$", "Applies Department P's $15$ point rise to Department Q's $300$ employees."),
               (r"$75$", r"Takes $15\%$ of all $500$ employees.")],
  check=_d8, values=[30, 20, 45, 75], cognitive="Analysis", exams=CX)


def _d9():
    p, qq = symbols('p q', positive=True)
    sol = solve([Eq(Rational(40, 100) * p + Rational(60, 100) * qq, Rational(52, 100) * (p + qq)),
                 Eq(Rational(52, 100) * (p + qq), Rational(55, 100) * (p + qq - 30))], [p, qq], dict=True)[0]
    return sol[p]
q("C01-D-039", T, "Size of one merged company from the merged percentage and a later change", "Difficult",
  "Multi-step word problem",
  r"Two companies, P and Q, merged. Women made up $40\%$ of the employees of P and $60\%$ of the employees of Q, and $52\%$ of the employees of the merged company. Soon after the merger, $30$ men left and nobody joined, after which women made up $55\%$ of the employees. How many employees did company P have?",
  "MCQ",
  r"By alligation, P : Q $= (60 - 52) : (52 - 40) = 2 : 3$. If the merged company had $t$ employees, the $0.52t$ women are $55\%$ of $t - 30$: $0.52t = 0.55t - 16.5$, so $t = 550$. Company P had $\frac{2}{5} \times 550 = 220$ employees.",
  r"Treating the $3$ percentage point rise as $30$ people being $3\%$ of the company, or using the post-departure total.",
  "C01D-merger-two-stage", "Two stages: an alligation for the size ratio and a share change for the scale.",
  correct=r"$220$",
  distractors=[(r"$330$", "Reports company Q's size, or pairs the alligation ratio the wrong way round."),
               (r"$400$", r"Takes $30$ men as $3\%$ of the merged company, giving $1000$, and then $\frac{2}{5}$ of it."),
               (r"$208$", "Applies the ratio $2 : 5$ to the total after the men left, $520$.")],
  check=_d9, values=[220, 330, 400, 208], cognitive="Analysis", exams=CX)


def _d10():
    m23 = Fraction(100)
    x23 = m23 * Fraction(20, 100)
    m24 = m23 * Fraction(120, 100)
    x24 = m24 * Fraction(30, 100)
    x25 = x24 * Fraction(140, 100)
    m25 = x25 / Fraction(35, 100)
    return (m25 - m24) / m24 * 100
q("C01-D-040", T, "Market growth from a brand's sales growth and its change in market share", "Difficult",
  "Conceptual/application",
  r"Brand X had a $20\%$ share of the units sold in a market in $2023$. In $2024$ the total market grew by $20\%$ and Brand X's share rose by $10$ percentage points. In $2025$ Brand X's unit sales grew by $40\%$ over $2024$, and its share rose by a further $5$ percentage points. By what percent did the total market grow from $2024$ to $2025$?",
  "MCQ",
  r"Only the $2024$ and $2025$ figures matter. Brand X's share went from $30\%$ to $35\%$ while its sales grew by a factor of $1.4$. Since market $=$ sales $\div$ share, the market grew by a factor of $1.4 \times \frac{30}{35} = 1.2$, that is $20\%$. (With a $2023$ market of $100$: $120$ in $2024$ with Brand X selling $36$, then $50.4$ units at $35\%$ gives $144$.)",
  "Comparing with the wrong year, or ignoring the change in share.",
  "C01D-share-chain-years", "Irrelevant early data and two share changes; the student must see that market = sales / share for the relevant years.",
  correct=r"$20\%$",
  distractors=[(r"$44\%$", "Compares the $2025$ market of $144$ with the $2023$ market of $100$."),
               (r"$40\%$", "Ignores the change in share and assumes the market grew as fast as Brand X."),
               (r"$35\%$", r"Subtracts the $5$ percentage point rise in share from Brand X's $40\%$ growth.")],
  check=_d10, values=[20, 44, 40, 35], cognitive="Analysis", exams=CX)
