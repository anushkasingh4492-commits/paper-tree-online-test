import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

F = Fraction
T = "Alligation"
CX = ("CAT", "XAT")


def _pos(sol):
    return [s for s in sol if s.is_real and s > 0]


# ================================================================ EASY (11)

def _e1():
    x = symbols('x', positive=True)  # kg of costlier per 1 kg of cheaper
    return F(str(solve(Eq(96 * x + 66 * 1, 84 * (x + 1)), x)[0]))
q("C06-A-001", T, "Ratio of two rice varieties for a target cost per kg", "Easy",
  "Single-step computation",
  r"Ravi, a grocer, mixes a basmati rice costing Rs. $96$ per kg with a cheaper rice costing Rs. $66$ per kg. In what ratio (basmati : cheaper rice, by weight) must he mix them so that the mixture costs Rs. $84$ per kg?",
  "MCQ",
  r"By alligation, basmati : cheaper $= (84 - 66) : (96 - 84) = 18 : 12 = 3 : 2$. Check: $\frac{3 \times 96 + 2 \times 66}{5} = \frac{288 + 132}{5} = 84$.",
  "Attaching the alligation differences to the wrong variety.",
  "C06A-two-variety-target-price-ratio", "Direct alligation in one step; the trap is pairing each difference with the wrong variety.",
  correct=r"$3 : 2$",
  distractors=[(r"$2 : 3$", r"Pairs each difference with the wrong variety: $(96 - 84) : (84 - 66) = 12 : 18$."),
               (r"$16 : 11$", r"Reports the ratio of the two prices, $96 : 66$."),
               (r"$3 : 5$", r"Divides by the whole price range: $(84 - 66) : (96 - 66) = 18 : 30$.")],
  check=_e1, values=[F(3, 2), F(2, 3), F(16, 11), F(3, 5)], cognitive="Application")


def _e2():
    return F(2 * 420 + 3 * 300, 5)
q("C06-A-002", T, "Cost per kg of a tea blend from the mixing ratio", "Easy",
  "Single-step computation",
  r"Meera blends two teas costing Rs. $420$ per kg and Rs. $300$ per kg in the ratio $2 : 3$ by weight. What is the cost of the blend, in rupees per kg?",
  "TITA",
  r"The cost per kg is the weighted average $\frac{2 \times 420 + 3 \times 300}{5} = \frac{840 + 900}{5} = 348$. Equivalently, the blend sits $\frac{2}{5}$ of the way from $300$ to $420$: $300 + \frac{2}{5}(120) = 348$.",
  "Taking the simple average of the two prices, or applying the weights the wrong way round.",
  "C06A-weighted-mean-price", "A single weighted average; traps are the simple average and swapped weights.",
  tita_answer=348, check=_e2,
  tita_traps=[(360, r"Takes the simple average $\frac{420 + 300}{2}$."), (372, r"Swaps the weights: $\frac{3 \times 420 + 2 \times 300}{5}$.")],
  cognitive="Application")


def _e3():
    x = symbols('x', positive=True)
    return F(str(solve(Eq(F(40, 100) * 30 + F(15, 100) * x, F(25, 100) * (30 + x)), x)[0]))
q("C06-A-003", T, "Volume of a weaker solution to add to a fixed volume for a target strength", "Easy",
  "Multi-step word problem",
  r"How many litres of a $15\%$ acid solution must be added to $30$ litres of a $40\%$ acid solution to obtain a $25\%$ acid solution?",
  "MCQ",
  r"By alligation, $15\%$ solution : $40\%$ solution $= (40 - 25) : (25 - 15) = 15 : 10 = 3 : 2$. With $30$ litres of the $40\%$ solution (two parts), one part is $15$ litres, so $3 \times 15 = 45$ litres of the $15\%$ solution are needed.",
  r"Reversing the alligation ratio, or equating acid only to $25\%$ of the added volume.",
  "C06A-fixed-quantity-target-concentration", "One alligation and one scaling step, with a reversal trap.",
  correct=r"$45$ litres",
  distractors=[(r"$20$ litres", r"Reverses the ratio and takes $30 \times \frac{2}{3}$."),
               (r"$75$ litres", r"Reports the total volume of the final mixture, $30 + 45$."),
               (r"$120$ litres", r"Writes $12 + 0.15x = 0.25x$, applying $25\%$ to the added volume only, which gives $x = 120$.")],
  check=_e3, values=[45, 20, 75, 120], cognitive="Application")


def _e4():
    w = symbols('w', positive=True)
    return int(solve(Eq(F(75, 100) * 40, F(60, 100) * (40 + w)), w)[0])
q("C06-A-004", T, "Water to add to bring an alcohol solution down to a target strength", "Easy",
  "Multi-step word problem",
  r"A $40$-litre can of hand sanitiser contains $75\%$ alcohol and the rest water. How many litres of pure water must be added so that the alcohol content becomes $60\%$?",
  "TITA",
  r"The alcohol stays at $0.75 \times 40 = 30$ litres. For this to be $60\%$ of the new volume, the volume must be $\frac{30}{0.6} = 50$ litres, so $50 - 40 = 10$ litres of water are added. (Alligation with water as $0\%$: water : sanitiser $= 15 : 60 = 1 : 4$, and $\frac{40}{4} = 10$.)",
  r"Treating the drop of $15$ percentage points as $15\%$ of the original volume.",
  "C06A-dilute-or-strengthen-with-pure", "Alcohol quantity is conserved; one division and one subtraction.",
  tita_answer=10, check=_e4,
  tita_traps=[(6, r"Takes $15\%$ of $40$ litres for the fall from $75\%$ to $60\%$."), (50, r"Reports the final volume instead of the water added.")],
  cognitive="Application")


def _e5():
    a = symbols('a', positive=True)  # adults per junior
    return F(str(solve(Eq(38 * a + 14 * 1, 29 * (a + 1)), a)[0]))
q("C06-A-005", T, "Ratio of adult to junior members of a club from their average ages", "Easy",
  "Conceptual/application",
  r"A swimming club has adult members and junior members. The average age of the adult members is $38$ years and the average age of the junior members is $14$ years. The average age of all the members of the club is $29$ years. What is the ratio of the number of adult members to the number of junior members?",
  "MCQ",
  r"Alligation on averages: adults : juniors $= (29 - 14) : (38 - 29) = 15 : 9 = 5 : 3$. Check: $\frac{5 \times 38 + 3 \times 14}{8} = \frac{190 + 42}{8} = 29$.",
  "Pairing each difference with the wrong group, or comparing one difference with the whole range.",
  "C06A-averages-group-split", "One alligation on averages; the overall average lies closer to the larger group.",
  correct=r"$5 : 3$",
  distractors=[(r"$3 : 5$", r"Pairs the differences with the wrong groups: $(38 - 29) : (29 - 14) = 9 : 15$."),
               (r"$5 : 8$", r"Compares one difference with the whole range: $(29 - 14) : (38 - 14) = 15 : 24$."),
               (r"$19 : 7$", r"Reports the ratio of the two average ages, $38 : 14$.")],
  check=_e5, values=[F(5, 3), F(3, 5), F(5, 8), F(19, 7)], cognitive="Understanding")


def _e6():
    p, qq = symbols('p qq', positive=True)  # last year's revenues in Rs crore
    s = solve([Eq(p + qq, 50), Eq(F(104, 100) * p + F(110, 100) * qq, F(1076, 1000) * 50)], [p, qq], dict=True)[0]
    return s[qq]
q("C06-A-006", T, "Base sizes of two divisions from their growth rates and the overall growth", "Easy",
  "Multi-step word problem",
  r"A company has two divisions, P and Q. Last year their combined revenue was Rs. $50$ crore. This year the revenue of P grew by $4\%$ and the revenue of Q grew by $10\%$, and the combined revenue of the company grew by $7.6\%$. What was the revenue of Q last year?",
  "MCQ",
  r"The overall growth rate is the average of the two rates weighted by last year's revenues. By alligation, P : Q $= (10 - 7.6) : (7.6 - 4) = 2.4 : 3.6 = 2 : 3$. So Q's revenue last year was $\frac{3}{5} \times 50 = $ Rs. $30$ crore. Check: $20 \times 1.04 + 30 \times 1.10 = 20.8 + 33 = 53.8$, a growth of $7.6\%$.",
  "Pairing each difference with the wrong division, or weighting the growth rates by this year's revenues.",
  "C06A-percent-change-split", "Growth rates average with last year's revenues as weights; one alligation and one scaling step.",
  correct=r"Rs. $30$ crore",
  distractors=[(r"Rs. $20$ crore", r"Pairs the differences with the wrong divisions and reports $\frac{2}{5} \times 50$."),
               (r"Rs. $25$ crore", r"Assumes the two divisions were of equal size, as if the overall rate were a simple average."),
               (r"Rs. $33$ crore", r"Finds Q's revenue correctly but reports this year's figure, $30 \times 1.10$.")],
  check=_e6, values=[30, 20, 25, 33], cognitive="Application")


def _e7():
    w = symbols('w', positive=True)  # litres of water per litre of concentrate
    return F(str(solve(Eq(150 * 1 + 0 * w, 120 * (1 + w)), w)[0]))
q("C06-A-007", T, "Ratio of free water to a priced concentrate for a target cost", "Easy",
  "Single-step computation",
  r"A fruit-drink maker buys juice concentrate at Rs. $150$ per litre and dilutes it with water, which costs nothing. In what ratio (water : concentrate, by volume) must she mix them so that the drink costs her Rs. $120$ per litre?",
  "MCQ",
  r"Water costs Rs. $0$ per litre. By alligation, water : concentrate $= (150 - 120) : (120 - 0) = 30 : 120 = 1 : 4$. Check: $4$ litres of concentrate cost Rs. $600$ and make $5$ litres, which is Rs. $120$ per litre.",
  "Comparing the saving with the concentrate price instead of with the mixture price.",
  "C06A-free-water-cost-ratio", "Alligation with one ingredient at zero cost, in one step.",
  correct=r"$1 : 4$",
  distractors=[(r"$4 : 1$", r"Pairs the differences with the wrong ingredients."),
               (r"$1 : 5$", r"Writes water : concentrate as $30 : 150$, comparing the saving with the concentrate price."),
               (r"$5 : 4$", r"Reports the ratio of the two costs, $150 : 120$.")],
  check=_e7, values=[F(1, 4), F(4, 1), F(1, 5), F(5, 4)], cognitive="Application")


def _e8():
    cp = F(3 * 40 + 1 * 60, 4)
    return (F(54) - cp) / cp * 100
q("C06-A-008", T, "Profit percent on selling a mixture of two varieties", "Easy",
  "Multi-step word problem",
  r"Sneha mixes rice costing Rs. $40$ per kg with rice costing Rs. $60$ per kg in the ratio $3 : 1$ by weight, and sells the mixture at Rs. $54$ per kg. What is her profit as a percentage of her cost, in percent?",
  "TITA",
  r"The cost of the mixture is $\frac{3 \times 40 + 1 \times 60}{4} = \frac{180}{4} = 45$ rupees per kg. The profit is $54 - 45 = 9$ rupees per kg, which is $\frac{9}{45} = 20\%$.",
  "Using the simple average of the two prices as the cost of the mixture.",
  "C06A-mixture-profit-percent", "A weighted cost price followed by a profit percentage.",
  tita_answer=20, check=_e8,
  tita_traps=[(8, r"Uses the simple average Rs. $50$ as the cost: $\frac{54 - 50}{50} = 8\%$."), (9, r"Reports the profit per kg in rupees.")],
  cognitive="Application")


def _e9():
    # simulate: x litres of P per 1 litre of Q, milk : water in the jug must be 5 : 3
    x = symbols('x', positive=True)
    milk = F(4, 5) * x + F(2, 5) * 1
    water = F(1, 5) * x + F(3, 5) * 1
    return F(str(solve(Eq(3 * milk, 5 * water), x)[0]))
q("C06-A-009", T, "Ratio in which to pour two milk and water mixtures to reach a target ratio", "Easy",
  "Inverse/parameter",
  r"Can P holds a mixture of milk and water in the ratio $4 : 1$, and can Q holds a mixture of milk and water in the ratio $2 : 3$. Kabir pours some of P and some of Q into a jug so that milk and water in the jug are in the ratio $5 : 3$. In what ratio (P : Q, by volume) does he pour them?",
  "MCQ",
  r"Milk is $\frac{4}{5} = 0.8$ of P, $\frac{2}{5} = 0.4$ of Q and must be $\frac{5}{8} = 0.625$ of the jug. By alligation, P : Q $= (0.625 - 0.4) : (0.8 - 0.625) = 0.225 : 0.175 = 9 : 7$. Check: $9$ litres of P and $7$ litres of Q give milk $7.2 + 2.8 = 10$ and water $1.8 + 4.2 = 6$ litres, that is $5 : 3$.",
  "Applying alligation to the ratio terms instead of to the fraction of milk in each can.",
  "C06A-combine-or-target-component-ratio", "Each ratio must first be converted to a milk fraction; then one alligation.",
  correct=r"$9 : 7$",
  distractors=[(r"$7 : 9$", r"Pairs the differences with the wrong cans: $(0.8 - 0.625) : (0.625 - 0.4)$."),
               (r"$3 : 7$", r"Applies alligation to the milk : water values $4$, $\frac{2}{3}$ and $\frac{5}{3}$ themselves: $(\frac{5}{3} - \frac{2}{3}) : (4 - \frac{5}{3}) = 1 : \frac{7}{3}$."),
               (r"$9 : 16$", r"Compares one difference with the whole range: $(0.625 - 0.4) : (0.8 - 0.4) = 0.225 : 0.4$.")],
  check=_e9, values=[F(9, 7), F(7, 9), F(3, 7), F(9, 16)], cognitive="Application")


def _e10():
    x = symbols('x', positive=True)
    return int(solve(Eq(12 * 500 + 8 * x, 20 * 560), x)[0])
q("C06-A-010", T, "Unknown price of one variety from the mixture price", "Easy",
  "Inverse/parameter",
  r"Fatima mixes $12$ kg of a dry-fruit mix costing Rs. $500$ per kg with $8$ kg of a premium dry-fruit mix. The resulting $20$ kg costs Rs. $560$ per kg. What is the cost of the premium mix, in rupees per kg?",
  "TITA",
  r"The total cost is $20 \times 560 = 11200$ rupees, of which the first mix accounts for $12 \times 500 = 6000$. So the premium mix costs $\frac{11200 - 6000}{8} = \frac{5200}{8} = 650$ rupees per kg. (Alligation: the $60$ rupee excess on $12$ kg is balanced by $8$ kg at $90$ above $560$.)",
  "Treating the mixture price as the simple average, or swapping the two quantities.",
  "C06A-unknown-component-price", "Reverse use of the weighted average in one equation.",
  tita_answer=650, check=_e10,
  tita_traps=[(620, r"Treats Rs. $560$ as the simple average: $2 \times 560 - 500$."), (600, r"Swaps the quantities: $8 \times 500 + 12x = 11200$.")],
  cognitive="Application")


def _e11():
    t1, t2 = symbols('t1 t2', positive=True)
    s = solve([Eq(t1 + t2, 5), Eq(60 * t1 + 90 * t2, 390)], [t1, t2], dict=True)[0]
    return 90 * s[t2]
q("C06-A-011", T, "Alligation on average speed to split travel time, then find a distance", "Easy",
  "Conceptual/application",
  r"A car travels for $5$ hours in all and covers $390$ km. For part of the time it moves at a constant $60$ km/h and for the rest of the time at a constant $90$ km/h. How many kilometres does it cover at $90$ km/h?",
  "MCQ",
  r"The average speed is $\frac{390}{5} = 78$ km/h. Since the speeds are averaged over time, alligation gives time at $60$ : time at $90 = (90 - 78) : (78 - 60) = 12 : 18 = 2 : 3$, that is $2$ hours and $3$ hours. Distance at $90$ km/h $= 3 \times 90 = 270$ km.",
  "Applying the time ratio from alligation directly to the distance.",
  "C06A-speed-alligation-time-weights", "One alligation on speeds; the weights are times, not distances.",
  correct=r"$270$ km",
  distractors=[(r"$180$ km", r"Pairs the differences with the wrong speeds, taking $2$ hours at $90$ km/h."),
               (r"$234$ km", r"Applies the time ratio $2 : 3$ to the distance: $\frac{3}{5} \times 390$."),
               (r"$120$ km", r"Reports the distance covered at $60$ km/h, $2 \times 60$.")],
  check=_e11, values=[270, 180, 234, 120], cognitive="Understanding")


# ================================================================ MEDIUM (15)

def _m1():
    cp = F(54) / F(135, 100)
    w = symbols('w', positive=True)  # water per litre of milk
    return F(str(solve(Eq(48 * 1, cp * (1 + w)), w)[0]))
q("C06-A-012", T, "Water to milk ratio from the selling price and profit percent", "Medium",
  "Multi-step word problem",
  r"A milkman buys pure milk at Rs. $48$ per litre, adds some water (which costs him nothing) and sells the mixture at Rs. $54$ per litre. If his profit is $35\%$, what is the ratio of water to milk in the mixture?",
  "MCQ",
  r"The cost of one litre of mixture is $\frac{54}{1.35} = 40$ rupees. Water costs $0$ and milk $48$, so by alligation water : milk $= (48 - 40) : (40 - 0) = 8 : 40 = 1 : 5$.",
  "Treating the whole profit percentage as the share of water, ignoring that the selling price is already above the milk price.",
  "C06A-free-water-cost-ratio", "Profit gives the mixture cost, then alligation with a zero-cost ingredient.",
  correct=r"$1 : 5$",
  distractors=[(r"$5 : 1$", r"Pairs the differences with the wrong ingredients."),
               (r"$1 : 6$", r"Finds that water is $\frac{8}{48} = \frac{1}{6}$ of the mixture and writes it as water : milk."),
               (r"$7 : 20$", r"Assumes the whole $35\%$ profit comes from water, so water : milk $= 35 : 100$.")],
  check=_m1, values=[F(1, 5), F(5, 1), F(1, 6), F(7, 20)], cognitive="Application")


def _m2():
    cp = F(495) / F(110, 100)
    x = symbols('x', positive=True)  # kg of cheaper per kg of costlier
    return F(str(solve(Eq(360 * x + 480 * 1, cp * (x + 1)), x)[0]))
q("C06-A-013", T, "Mixing ratio of two coffees for a given selling price and profit", "Medium",
  "Multi-step word problem",
  r"A cafe owner mixes a coffee powder costing Rs. $360$ per kg with another costing Rs. $480$ per kg. She sells the blend at Rs. $495$ per kg and makes a profit of $10\%$. In what ratio (cheaper : costlier, by weight) are the two powders mixed?",
  "MCQ",
  r"The cost of the blend is $\frac{495}{1.1} = 450$ rupees per kg. By alligation, cheaper : costlier $= (480 - 450) : (450 - 360) = 30 : 90 = 1 : 3$.",
  r"Taking $10\%$ of the selling price off to get the cost price.",
  "C06A-profit-to-target-ratio", "Convert selling price to cost price, then alligation.",
  correct=r"$1 : 3$",
  distractors=[(r"$3 : 1$", r"Pairs the differences with the wrong varieties."),
               (r"$23 : 57$", r"Takes the cost as $0.9 \times 495 = 445.5$, giving $(480 - 445.5) : (445.5 - 360) = 34.5 : 85.5$."),
               (r"$3 : 4$", r"Reports the ratio of the two prices, $360 : 480$.")],
  check=_m2, values=[F(1, 3), F(3, 1), F(23, 57), F(3, 4)], cognitive="Application")


def _m3():
    g = symbols('g')  # percentage change of fund Q (negative for a fall)
    p_amt, q_amt = 180000, 120000
    val = solve(Eq(p_amt * F(116, 100) + q_amt * (1 + g / 100), (p_amt + q_amt) * F(106, 100)), g)[0]
    return int(-val)
q("C06-A-014", T, "Percentage fall of one investment from the gain on the other and the overall gain", "Medium",
  "Inverse/parameter",
  r"Ravi invests Rs. $1{,}80{,}000$ in fund P and Rs. $1{,}20{,}000$ in fund Q at the same time. After one year, the value of fund P has risen by $16\%$, while the value of fund Q has fallen. The total value of his two investments is then $6\%$ more than the total amount he invested. By how many percent did the value of fund Q fall?",
  "TITA",
  r"The overall change is the average of the two changes weighted by the amounts invested, P : Q $= 3 : 2$. By alligation, $(6 - q) : (16 - 6) = 3 : 2$, where $q$ is Q's percentage change, so $6 - q = 15$ and $q = -9$. Fund Q fell by $9\%$. Check: $180000 \times 1.16 + 120000 \times 0.91 = 208800 + 109200 = 318000$, which is $6\%$ above $300000$.",
  "Weighting the two percentage changes equally, or ignoring that a fall is a negative change.",
  "C06A-percent-change-split", "Alligation run in reverse to find an unknown extreme that lies below zero.",
  tita_answer=9, check=_m3,
  tita_traps=[(4, r"Weights the two funds equally: $\frac{16 + q}{2} = 6$ gives $q = -4$."), (10, r"Reports the gap between the gain on P and the overall gain, $16 - 6$.")],
  cognitive="Application")


def _m4():
    a, b = symbols('a b', positive=True)
    s = solve([Eq(a + b, 45), Eq(F(20, 100) * a + F(50, 100) * b, F(30, 100) * 45)], [a, b], dict=True)[0]
    return s[a]
q("C06-A-015", T, "Volumes of two solutions needed to make a fixed volume of a target strength", "Medium",
  "Multi-step word problem",
  r"A lab assistant has a $20\%$ saline solution and a $50\%$ saline solution. She wants to make exactly $45$ litres of a $30\%$ saline solution by mixing only these two. How many litres of the $20\%$ solution must she use?",
  "TITA",
  r"By alligation, $20\%$ : $50\%$ $= (50 - 30) : (30 - 20) = 20 : 10 = 2 : 1$. So the $20\%$ solution is $\frac{2}{3} \times 45 = 30$ litres (and $15$ litres of the $50\%$ solution).",
  "Pairing the differences with the wrong solutions.",
  "C06A-fixed-quantity-target-concentration", "Alligation then splitting a fixed total; the reversal trap is natural.",
  tita_answer=30, check=_m4,
  tita_traps=[(15, r"Pairs the differences with the wrong solutions, getting $20\%$ : $50\%$ $= 1 : 2$ and $\frac{1}{3} \times 45$."),
              (18, r"Assumes all $13.5$ litres of salt come from the $50\%$ solution, takes $\frac{13.5}{0.5} = 27$ litres of it and the remaining $45 - 27$ litres of the $20\%$ solution.")],
  cognitive="Application")


def _m5():
    x = symbols('x', positive=True)
    return int(solve(Eq(F(20, 100) * 100 + x, F(36, 100) * (100 + x)), x)[0])
q("C06-A-016", T, "Pure solute to add to raise the concentration of a solution", "Medium",
  "Multi-step word problem",
  r"A tank holds $100$ litres of a $20\%$ acid solution. How many litres of pure acid must be added to it so that the solution becomes $36\%$ acid?",
  "MCQ",
  r"Treat pure acid as $100\%$. By alligation, $20\%$ solution : pure acid $= (100 - 36) : (36 - 20) = 64 : 16 = 4 : 1$. So $\frac{100}{4} = 25$ litres of pure acid are needed. Check: $\frac{20 + 25}{125} = 36\%$.",
  "Adding only the shortfall in percentage points, forgetting that the added acid also increases the volume.",
  "C06A-dilute-or-strengthen-with-pure", r"Pure acid must be treated as $100\%$; the added volume changes the base.",
  correct=r"$25$ litres",
  distractors=[(r"$16$ litres", r"Adds $16\%$ of $100$ litres, ignoring that the volume also grows."),
               (r"$20$ litres", r"Compares the rise with the whole range: $100 \times \frac{36 - 20}{100 - 20}$."),
               (r"$125$ litres", r"Reports the final volume instead of the acid added.")],
  check=_m5, values=[25, 16, 20, 125], cognitive="Application")


def _m6():
    y = symbols('y', positive=True)  # grams of Q
    gold = F(7, 9) * 36 + F(7, 18) * y
    return int(solve(Eq(gold, (36 + y) / 2), y)[0])
q("C06-A-017", T, "Amount of a second alloy needed to reach a target component ratio", "Medium",
  "Multi-step word problem",
  r"Alloy P contains gold and copper in the ratio $7 : 2$ by weight, and alloy Q contains gold and copper in the ratio $7 : 11$ by weight. A jeweller melts $36$ g of alloy P with some alloy Q to obtain a new alloy in which the weights of gold and copper are equal. How many grams of alloy Q does he use?",
  "TITA",
  r"Gold makes up $\frac{7}{9} = \frac{14}{18}$ of P, $\frac{7}{18}$ of Q and must make up $\frac{1}{2} = \frac{9}{18}$ of the new alloy. By alligation, P : Q $= (\frac{9}{18} - \frac{7}{18}) : (\frac{14}{18} - \frac{9}{18}) = 2 : 5$. So Q $= \frac{5}{2} \times 36 = 90$ g.",
  "Using the ratio terms instead of the fractions of gold, or pairing the differences with the wrong alloys.",
  "C06A-combine-or-target-component-ratio", "Ratios must be converted to fractions with a common denominator before alligation.",
  tita_answer=90, check=_m6,
  tita_traps=[(126, r"Reports the weight of the new alloy, $36 + 90$.")],
  cognitive="Application")


def _m7():
    sols = [e for e in range(0, 121) if 300 * (120 - e) + 220 * e == 270 * 120]
    assert len(sols) == 1
    return sols[0]
q("C06-A-018", T, "Number of vehicles of one type in a fleet from the two type averages and the fleet average", "Medium",
  "Inverse/parameter",
  r"A taxi company runs $120$ cars, each of which is either a CNG car or an electric car. On a particular day the CNG cars ran an average of $300$ km each and the electric cars ran an average of $220$ km each, while the average for all $120$ cars was $270$ km. How many electric cars does the company run?",
  "MCQ",
  r"Alligation on averages: CNG : electric $= (270 - 220) : (300 - 270) = 50 : 30 = 5 : 3$. So electric cars are $\frac{3}{8}$ of the fleet: $\frac{3}{8} \times 120 = 45$. Check: $75 \times 300 + 45 \times 220 = 22500 + 9900 = 32400 = 120 \times 270$.",
  "Reading a ratio term as a share of the other term instead of a share of the whole, or pairing the differences with the wrong groups.",
  "C06A-averages-group-split", "Alligation on averages, then converting a part-to-part ratio into a share of a known total.",
  correct=r"$45$",
  distractors=[(r"$75$", r"Pairs the differences with the wrong groups and so reports the number of CNG cars."),
               (r"$72$", r"Reads the ratio $5 : 3$ as electric cars being $3$ parts out of $5$: $\frac{3}{5} \times 120$."),
               (r"$60$", r"Assumes the fleet is split equally between the two types.")],
  check=_m7, values=[45, 75, 72, 60], cognitive="Application")


def _m8():
    best = 0
    for d in range(0, 11):
        for c in range(0, 8):
            if d + c > 0 and 880 * d + 640 * c == 784 * (d + c):
                best = max(best, d + c)
    return best
q("C06-A-019", T, "Largest mixture at an exact price with limited whole-kilogram stock", "Medium",
  "Casework/optimisation",
  r"Joseph, a dry-fruit seller, has $10$ kg of walnuts costing Rs. $880$ per kg and $7$ kg of a cheaper nut mix costing Rs. $640$ per kg. He wants to make a blend that costs exactly Rs. $784$ per kg, using a whole number of kilograms of each. What is the largest weight of such a blend he can make?",
  "MCQ",
  r"By alligation, walnuts : nut mix $= (784 - 640) : (880 - 784) = 144 : 96 = 3 : 2$. So he uses $3k$ kg of walnuts and $2k$ kg of the mix, with $3k \le 10$ and $2k \le 7$ for a whole number $k$. The largest is $k = 3$, giving $9 + 6 = 15$ kg.",
  "Ignoring the whole-kilogram condition, or pairing the differences with the wrong varieties.",
  "C06A-integer-stock-limit", "Alligation plus a stock and integrality constraint to optimise.",
  correct=r"$15$ kg",
  distractors=[(r"$16$ kg", r"Uses all $10$ kg of walnuts and rounds the required $\frac{20}{3}$ kg of the mix down to $6$ kg."),
               (r"$17$ kg", r"Uses the entire stock of both, $10 + 7$."),
               (r"$10$ kg", r"Pairs the differences with the wrong varieties, so walnuts : mix $= 2 : 3$, and the largest whole multiple is $4 + 6$.")],
  check=_m8, values=[15, 16, 17, 10], cognitive="Analysis")


def _m9():
    d1, d2 = symbols('d1 d2', positive=True)  # km on congested stretch and on highway
    s = solve([Eq(d1 + d2, 100), Eq(d1 / 24 + d2 / 72, F(100, 40))], [d1, d2], dict=True)[0]
    return F(str(s[d1] / 24 * 60))
q("C06-A-020", T, "Time spent on the slower stretch from the total distance and the average speed", "Medium",
  "Conceptual/application",
  r"A bus covers a $100$ km route without stopping. It moves at a constant $24$ km/h on a congested stretch of the route and at a constant $72$ km/h on the rest, which is highway. Its average speed for the whole route is $40$ km/h. For how many minutes is the bus on the congested stretch?",
  "MCQ",
  r"The trip takes $\frac{100}{40} = 2.5$ hours $= 150$ minutes. Average speed is weighted by time, so alligation gives congested time : highway time $= (72 - 40) : (40 - 24) = 32 : 16 = 2 : 1$. The congested stretch takes $\frac{2}{3} \times 150 = 100$ minutes. Check: $24 \times \frac{5}{3} + 72 \times \frac{5}{6} = 40 + 60 = 100$ km.",
  "Treating the two stretches as equal in length, or pairing the differences with the wrong speeds.",
  "C06A-speed-alligation-time-weights", "Total time from the average speed, then alligation with time as the weight.",
  correct=r"$100$ minutes",
  distractors=[(r"$50$ minutes", r"Pairs the differences with the wrong speeds, giving the congested stretch $\frac{1}{3}$ of the time."),
               (r"$75$ minutes", r"Splits the $150$ minutes equally between the two stretches."),
               (r"$125$ minutes", r"Assumes the two stretches are each $50$ km long: $\frac{50}{24}$ hours.")],
  check=_m9, values=[100, 50, 75, 125], cognitive="Application")


def _m10():
    cp_per_kg = F(2 * 90 + 1 * 120, 3)
    eff = cp_per_kg / F(96, 100)
    return (F(125) - eff) / eff * 100
q("C06-A-021", T, "Profit percent on a mixture when part of it is lost before sale", "Medium",
  "Multi-step word problem",
  r"A trader mixes a dal costing Rs. $90$ per kg with another costing Rs. $120$ per kg in the ratio $2 : 1$ by weight. During cleaning, $4\%$ of the mixture by weight is lost. He sells all the remaining mixture at Rs. $125$ per kg. What is his profit as a percentage of his total cost, in percent?",
  "TITA",
  r"The mixture costs $\frac{2 \times 90 + 120}{3} = 100$ rupees per kg. For every $100$ kg bought (cost Rs. $10{,}000$), $96$ kg are sold for $96 \times 125 = 12000$ rupees. Profit $= \frac{2000}{10000} = 20\%$.",
  r"Ignoring the loss in weight, or subtracting the $4\%$ from the profit percentage.",
  "C06A-mixture-profit-percent", "Weighted cost plus a weight loss that changes the effective cost.",
  tita_answer=20, check=_m10,
  tita_traps=[(25, r"Ignores the $4\%$ loss: $\frac{125 - 100}{100}$."), (21, r"Subtracts $4$ percentage points from the $25\%$ found by ignoring the loss.")],
  cognitive="Application")


def _m11():
    p, r = symbols('p r', positive=True)
    s = solve([Eq(2 * p + 3 * r, 5 * 46), Eq(3 * p + 2 * r, 5 * 49)], [p, r], dict=True)[0]
    return s[p]
q("C06-A-022", T, "Concentration of one solution from two different mixing ratios", "Medium",
  "Inverse/parameter",
  r"Priya has two sugar solutions, P and Q, of unknown concentrations. Mixing P and Q in the ratio $2 : 3$ by volume gives a $46\%$ solution, while mixing them in the ratio $3 : 2$ by volume gives a $49\%$ solution. What is the concentration of solution P, in percent?",
  "TITA",
  r"Let the concentrations be $p$ and $q$. Then $2p + 3q = 230$ and $3p + 2q = 245$. Adding, $p + q = 95$; subtracting, $p - q = 15$. So $p = 55$. (Shifting $\frac{1}{5}$ of the mix from Q to P raised the strength by $3$ points, so $p - q = 15$.)",
  "Equating the $3$-point change directly to the difference in concentrations.",
  "C06A-two-unknowns-two-ratios", "Two weighted-average equations in two unknowns.",
  tita_answer=55, check=_m11,
  tita_traps=[(40, r"Reports the concentration of Q."), (49, r"Takes $p - q = 3$, the change in strength, so $p = \frac{95 + 3}{2}$.")],
  exams=CX, cognitive="Analysis")


def _m12():
    a, b = symbols('a b', positive=True)
    s = solve(Eq((3 * a + 2 * b) / 5 - (2 * a + 3 * b) / 5, 24), a)[0]
    return simplify(s - b)
q("C06-A-023", T, "Price difference of two varieties from the change when the mixing ratio is swapped", "Medium",
  "Conceptual/application",
  r"A shopkeeper mixes a costlier oil and a cheaper oil in the ratio $2 : 3$ by volume. If he instead mixes them in the ratio $3 : 2$, the cost of the mixture rises by Rs. $24$ per litre. By how many rupees per litre does the price of the costlier oil exceed that of the cheaper oil?",
  "MCQ",
  r"Let the prices differ by $d$. The mixture price is (cheaper price) $+$ (share of costlier oil) $\times d$. The share of the costlier oil rises from $\frac{2}{5}$ to $\frac{3}{5}$, a rise of $\frac{1}{5}$, so $\frac{d}{5} = 24$ and $d = 120$.",
  "Using the new share of the costlier oil instead of the change in its share.",
  "C06A-ratio-swap-insight", "Needs the insight that only the shift in share times the price gap matters.",
  correct=r"Rs. $120$",
  distractors=[(r"Rs. $60$", r"Treats the shift in the costlier oil's share as $\frac{2}{5}$: $\frac{24}{2/5}$."),
               (r"Rs. $40$", r"Treats the shift in share as $\frac{3}{5}$: $\frac{24}{3/5}$."),
               (r"Rs. $24$", r"Assumes the price gap equals the change in the mixture price.")],
  check=_m12, values=[120, 60, 40, 24], cognitive="Analysis")


def _m13():
    x = symbols('x', positive=True)  # kg of Rs 40 rice per kg of Rs 60 rice
    kg = F(str(solve(Eq(40 * x + 60, 48 * (x + 1)), x)[0]))
    return (40 * kg) / (60 * 1)
q("C06-A-024", T, "Ratio of money spent on two varieties for a target average price", "Medium",
  "Conceptual/application",
  r"Kabir buys two varieties of rice, one at Rs. $40$ per kg and the other at Rs. $60$ per kg, and mixes all of it. He wants the mixture to cost him exactly Rs. $48$ per kg. In what ratio must he divide his spending (amount spent on the Rs. $40$ variety : amount spent on the Rs. $60$ variety)?",
  "MCQ",
  r"By weight, alligation gives Rs. $40$ variety : Rs. $60$ variety $= (60 - 48) : (48 - 40) = 3 : 2$. Money spent is weight times price: $3 \times 40 : 2 \times 60 = 120 : 120 = 1 : 1$.",
  "Reporting the weight ratio from alligation as the ratio of money spent.",
  "C06A-money-weighted-alligation", "Alligation weights are quantities; converting them to spending is the insight.",
  correct=r"$1 : 1$",
  distractors=[(r"$3 : 2$", r"Reports the weight ratio as the spending ratio."),
               (r"$2 : 3$", r"Pairs the differences with the wrong varieties and reads it as spending."),
               (r"$9 : 4$", r"Multiplies the weight ratio by the prices the wrong way round: $3 \times 60 : 2 \times 40$.")],
  check=_m13, values=[F(1, 1), F(3, 2), F(2, 3), F(9, 4)], cognitive="Analysis")


def _m14():
    cp = F(56) / F(140, 100)
    w = symbols('w', positive=True)  # litres of water per litre of dairy (half milk, half toned)
    wv = F(str(solve(Eq(F(60 + 40, 2) * 1, cp * (1 + w)), w)[0]))
    return wv / (1 + wv)
q("C06-A-025", T, "Share of free water added to an equal blend of two milks, from price and profit", "Medium",
  "Multi-step word problem",
  r"A dairy mixes full-cream milk costing Rs. $60$ per litre and toned milk costing Rs. $40$ per litre in equal volumes, and then adds water, which costs nothing. The final mixture is sold at Rs. $56$ per litre at a profit of $40\%$. What fraction of the final mixture is water?",
  "MCQ",
  r"The two milks in equal volumes cost $\frac{60 + 40}{2} = 50$ rupees per litre. The final mixture costs $\frac{56}{1.4} = 40$ rupees per litre. By alligation, water : milk blend $= (50 - 40) : (40 - 0) = 1 : 4$, so water is $\frac{1}{5}$ of the mixture.",
  "Treating the profit percentage as the share of water, or reporting a ratio as a fraction.",
  "C06A-free-water-cost-ratio", "Combine two priced ingredients first, then alligation with free water after removing profit.",
  correct=r"$\frac{1}{5}$",
  distractors=[(r"$\frac{1}{4}$", r"Reports the water : milk ratio $1 : 4$ as the fraction of water."),
               (r"$\frac{2}{7}$", r"Assumes the whole $40\%$ profit comes from water, so water : milk $= 2 : 5$."),
               (r"$\frac{1}{3}$", r"Uses only the full-cream milk at Rs. $60$: water : milk $= 20 : 40$.")],
  check=_m14, values=[F(1, 5), F(1, 4), F(2, 7), F(1, 3)], cognitive="Application")


def _m15():
    x, p2 = symbols('x p2', positive=True)  # x = fraction sold at 10%
    s = solve([Eq(10 * x + p2 * (1 - x), 16), Eq(10 * (1 - x) + p2 * x, 19)], [x, p2], dict=True)
    return [t[p2] for t in s if 0 < t[x] < 1][0]
q("C06-A-026", T, "Unknown profit percent on one part from the overall profit before and after swapping quantities", "Medium",
  "Inverse/parameter",
  r"Ananya buys a stock of sugar, all at the same price per kg. She sells one part of it at a profit of $10\%$ and the other part at a higher profit percentage, making an overall profit of $16\%$. Had she instead sold the quantity of the second part at $10\%$ profit and the quantity of the first part at the second rate, her overall profit would have been $19\%$. What profit percentage did she earn on the second part?",
  "MCQ",
  r"Let the first part be a fraction $x$ and the second rate $p$. Then $10x + p(1 - x) = 16$ and $10(1 - x) + px = 19$. Adding, $10 + p = 35$, so $p = 25\%$. (Then $x = 0.6$.)",
  "Assuming one of the two sales split the stock equally.",
  "C06A-ratio-swap-insight", "Adding the two weighted averages removes the unknown split.",
  correct=r"$25\%$",
  distractors=[(r"$22\%$", r"Assumes equal parts in the actual sale: $\frac{10 + p}{2} = 16$."),
               (r"$28\%$", r"Assumes equal parts in the interchanged sale: $\frac{10 + p}{2} = 19$."),
               (r"$35\%$", r"Reports $10 + p$, the sum of the two rates, as the answer.")],
  check=_m15, values=[25, 22, 28, 35], exams=CX, cognitive="Analysis")


# ================================================================ DIFFICULT (9)

def _d1():
    # minimise 30a + 80b with 0.2a + 0.6b = 18 (acid), a + b <= 50, water = 50 - a - b >= 0
    best = None
    for b10 in range(0, 501):
        b = F(b10, 10)
        a = (18 - F(6, 10) * b) / F(2, 10)
        if a < 0 or a + b > 50:
            continue
        c = 30 * a + 80 * b
        best = c if best is None or c < best else best
    return best
q("C06-A-027", T, "Cheapest way to make a target solution from two priced solutions and free water", "Difficult",
  "Casework/optimisation",
  r"A chemist needs exactly $50$ litres of a $36\%$ acid solution. She can buy a $20\%$ acid solution at Rs. $30$ per litre and a $60\%$ acid solution at Rs. $80$ per litre, and she has unlimited water at no cost. She may use either or both solutions in any (not necessarily whole) volumes, together with any amount of water. What is the minimum cost, in rupees, of making the $50$ litres?",
  "TITA",
  r"The $50$ litres must contain $18$ litres of acid. Acid costs $\frac{30}{0.2} = 150$ rupees per litre through the $20\%$ solution but only $\frac{80}{0.6} = 133.3$ through the $60\%$ solution, and water is free to make up volume. So use only the $60\%$ solution: $\frac{18}{0.6} = 30$ litres, costing $30 \times 80 = 2400$ rupees, plus $20$ litres of water. (Mixing the two solutions without water needs $30$ and $20$ litres and costs $900 + 1600 = 2500$.)",
  "Assuming the two solutions must be mixed by alligation, ignoring the cheaper route through water.",
  "C06A-optimise-with-free-water", "Requires comparing cost per litre of acid rather than reaching for the usual alligation.",
  tita_answer=2400, check=_d1,
  tita_traps=[(2500, r"Mixes the two solutions by alligation, $30$ litres of $20\%$ and $20$ litres of $60\%$, without using water.")],
  exams=CX, cognitive="Analysis")


def _d2():
    best = F(0)
    for a2 in range(0, 25):
        for b2 in range(0, 17):
            a, b = F(a2, 2), F(b2, 2)
            acid = F(25, 100) * a + F(60, 100) * b
            vol = acid / F(30, 100)
            if vol >= a + b:  # water added must be non-negative
                best = max(best, vol)
    return best
q("C06-A-028", T, "Largest volume of a target solution from limited stocks and free water", "Difficult",
  "Casework/optimisation",
  r"Sneha has $12$ litres of a $25\%$ acid solution and $8$ litres of a $60\%$ acid solution, and unlimited water. Using some or all of each solution, together with any amount of water, she wants to prepare as much $30\%$ acid solution as possible. What is the largest volume of $30\%$ solution she can make?",
  "MCQ",
  r"The volume is $\frac{\text{acid used}}{0.3}$, so she should use as much acid as possible, provided the result can still be diluted down to $30\%$. Using everything gives $3 + 4.8 = 7.8$ litres of acid in $20$ litres, a $39\%$ solution, which water can bring down to $30\%$. So the largest volume is $\frac{7.8}{0.3} = 26$ litres (adding $6$ litres of water).",
  r"Discarding the $25\%$ solution because it is weaker than the target, or not diluting after mixing.",
  "C06A-optimise-with-free-water", "Needs the insight that even the weaker solution adds acid as long as the mix stays above target.",
  correct=r"$26$ litres",
  distractors=[(r"$14$ litres", r"Mixes the two solutions by alligation ($6 : 1$) without water: all $12$ litres of $25\%$ with $2$ litres of $60\%$."),
               (r"$16$ litres", r"Uses only the $60\%$ solution with water: $\frac{4.8}{0.3}$."),
               (r"$20$ litres", r"Combines all of both solutions and stops, without diluting the $39\%$ mixture.")],
  check=_d2, values=[26, 14, 16, 20], exams=CX, cognitive="Analysis")


def _d3():
    m, w = symbols('m w', positive=True)
    s = solve([Eq(40000 * m + 32000 * w, 37000 * (m + w)),
               Eq(40000 * m + 32000 * (w + 10), 36000 * (m + w + 10))], [m, w], dict=True)[0]
    return s[m] + s[w]
q("C06-A-029", T, "Original group size from two successive weighted averages", "Difficult",
  "Inverse/parameter",
  r"In an office, the average monthly salary of the men is Rs. $40{,}000$ and that of the women is Rs. $32{,}000$; the average for all employees is Rs. $37{,}000$. Then $10$ more women join, whose average salary is also Rs. $32{,}000$, and no one leaves. The average for all employees becomes Rs. $36{,}000$. How many employees did the office have before the new women joined?",
  "TITA",
  r"Before: men : women $= (37 - 32) : (40 - 37) = 5 : 3$, so take $5k$ men and $3k$ women. After: men : women $= (36 - 32) : (40 - 36) = 1 : 1$. Hence $3k + 10 = 5k$, $k = 5$, and the office had $8k = 40$ employees.",
  "Reporting the strength after the new women joined, or only one group.",
  "C06A-two-stage-weighted-average", "Two alligations linked by a change in one group.",
  tita_answer=40, check=_d3,
  tita_traps=[(50, r"Reports the strength after the $10$ women joined."), (25, r"Reports only the number of men, $5k$.")],
  exams=CX, cognitive="Analysis")


def _d4():
    a, b = symbols('a b', positive=True)
    c1, c2 = F(540) / F(135, 100), F(540) / F(125, 100)
    s = solve([Eq(2 * a + 3 * b, 5 * c1), Eq(3 * a + 2 * b, 5 * c2)], [a, b], dict=True)[0]
    return s[a]
q("C06-A-030", T, "Price of the costlier variety from profits at two mixing ratios", "Difficult",
  "Inverse/parameter",
  r"A trader has two varieties of cashew. When he mixes the costlier and the cheaper variety in the ratio $2 : 3$ by weight and sells the mixture at Rs. $540$ per kg, he makes a profit of $35\%$. When he mixes them in the ratio $3 : 2$ and sells at the same Rs. $540$ per kg, his profit is $25\%$. What is the cost of the costlier variety per kg?",
  "MCQ",
  r"The two mixtures cost $\frac{540}{1.35} = 400$ and $\frac{540}{1.25} = 432$ rupees per kg. So $2a + 3b = 2000$ and $3a + 2b = 2160$. Adding, $a + b = 832$; subtracting, $a - b = 160$. Hence $a = 496$ rupees per kg (and $b = 336$).",
  "Computing cost price as a percentage below the selling price.",
  "C06A-two-unknowns-two-ratios", "Profit to cost price twice, then two weighted-average equations.",
  correct=r"Rs. $496$",
  distractors=[(r"Rs. $336$", r"Reports the price of the cheaper variety."),
               (r"Rs. $513$", r"Takes cost as $0.65 \times 540$ and $0.75 \times 540$, which gives $2a + 3b = 1755$ and $3a + 2b = 2025$."),
               (r"Rs. $416$", r"Stops at $a + b = 832$ and reports half of it.")],
  check=_d4, values=[496, 336, 513, 416], exams=CX, cognitive="Analysis")


def _d5():
    vals = set()
    for a in range(1, 4):
        for b in range(1, 7):
            vals.add(F(20 * a + 50 * b, a + b))
    return len(vals)
q("C06-A-031", T, "Counting distinct concentrations from whole-litre mixes of two solutions", "Difficult",
  "Casework/optimisation",
  r"Ananya has $3$ litres of a $20\%$ salt solution and $6$ litres of a $50\%$ salt solution. She makes a single mixture using a whole number of litres of each solution, at least $1$ litre of each (and not more than she has). How many different concentrations can the mixture have?",
  "TITA",
  r"The concentration depends only on the ratio $b : a$ of litres of the $50\%$ to the $20\%$ solution, with $a \in \{1, 2, 3\}$ and $b \in \{1, \dots, 6\}$. With $a = 1$: $6$ ratios $1, 2, \dots, 6$. With $a = 2$, the new ratios are $\frac{1}{2}, \frac{3}{2}, \frac{5}{2}$: $3$ more. With $a = 3$, the new ratios are $\frac{1}{3}, \frac{2}{3}, \frac{4}{3}, \frac{5}{3}$: $4$ more. Total $6 + 3 + 4 = 13$.",
  "Counting every pair of volumes, forgetting that proportional pairs give the same concentration.",
  "C06A-distinct-concentration-count", "Casework on reduced ratios; equal ratios must be removed.",
  tita_answer=13, check=_d5,
  tita_traps=[(18, r"Counts all $3 \times 6$ pairs of volumes."), (16, r"Treats only the three pairs with $a = b$ as repeats of one another.")],
  exams=CX, cognitive="Analysis")


def _d6():
    cp = F(45) / F(125, 100)
    milk_frac = cp / 60
    x = symbols('x', positive=True)  # litres of P per litre of Q
    return F(str(solve(Eq(F(9, 10) * x + F(1, 4) * 1, milk_frac * (x + 1)), x)[0]))
q("C06-A-032", T, "Mixing ratio of two milk and water mixtures for a target profit", "Difficult",
  "Multi-step word problem",
  r"Pure milk costs a vendor Rs. $60$ per litre, and water costs nothing. He has mixture P with milk and water in the ratio $9 : 1$ and mixture Q with milk and water in the ratio $1 : 3$. He combines P and Q and sells the result at Rs. $45$ per litre, making a profit of $25\%$. In what ratio (P : Q, by volume) did he combine them?",
  "MCQ",
  r"Cost of the final mixture $= \frac{45}{1.25} = 36$ rupees per litre, so milk is $\frac{36}{60} = 0.6$ of it. Milk is $0.9$ of P and $0.25$ of Q. By alligation, P : Q $= (0.6 - 0.25) : (0.9 - 0.6) = 0.35 : 0.30 = 7 : 6$.",
  "Ignoring the profit when finding the milk content, or taking the cost as a fixed percentage below the selling price.",
  "C06A-combine-or-target-component-ratio", "Profit gives cost, cost gives milk fraction, then alligation on fractions.",
  correct=r"$7 : 6$",
  distractors=[(r"$6 : 7$", r"Pairs the differences with the wrong mixtures."),
               (r"$10 : 3$", r"Ignores the profit, so milk is $\frac{45}{60} = 0.75$: $(0.75 - 0.25) : (0.9 - 0.75)$."),
               (r"$25 : 27$", r"Takes cost as $0.75 \times 45 = 33.75$, so milk is $0.5625$: $(0.5625 - 0.25) : (0.9 - 0.5625)$.")],
  check=_d6, values=[F(7, 6), F(6, 7), F(10, 3), F(25, 27)], exams=CX, cognitive="Analysis")


def _d7():
    m, w = symbols('m w', positive=True)
    s = solve([Eq(F(60, 100) * m + F(40, 100) * w, F(52, 100) * (m + w)),
               Eq(F(60, 100) * m + F(40, 100) * w + 1000, F(56, 100) * (m + w + 1000))], [m, w], dict=True)[0]
    return s[m] + s[w]
q("C06-A-033", T, "Original population from literacy rates before and after an inflow", "Difficult",
  "Inverse/parameter",
  r"In a town, $60\%$ of the men and $40\%$ of the women are literate, and $52\%$ of the whole population is literate. Then $1{,}000$ women, all literate, move into the town and nobody leaves. Now $56\%$ of the population is literate. What was the population of the town before the women moved in?",
  "MCQ",
  r"Alligation: men : women $= (52 - 40) : (60 - 52) = 3 : 2$, so take $3k$ men and $2k$ women with $1.8k + 0.8k = 2.6k$ literates. After the move, $\frac{2.6k + 1000}{5k + 1000} = 0.56$, so $2.6k + 1000 = 2.8k + 560$, $k = 2200$. The original population was $5k = 11{,}000$.",
  "Forgetting that the newcomers also increase the population.",
  "C06A-two-stage-weighted-average", "Alligation for the split, then an equation for the changed average.",
  correct=r"$11{,}000$",
  distractors=[(r"$25{,}000$", r"Leaves the denominator as $5k$: $2.6k + 1000 = 0.56 \times 5k$ gives $k = 5000$."),
               (r"$12{,}000$", r"Reports the population after the women moved in."),
               (r"$5{,}500$", r"Pairs the differences with the wrong groups (men : women $= 2 : 3$), which gives $k = 1100$.")],
  check=_d7, values=[11000, 25000, 12000, 5500], exams=CX, cognitive="Analysis")


def _d8():
    x = symbols('x', positive=True)  # litres of cheaper pulp per litre of premium pulp
    sp_per_true_litre = F(72) / F(9, 10)
    # revenue on (1 + x) true litres equals 1.25 times their cost
    return F(str(solve(Eq(sp_per_true_litre * (1 + x), F(125, 100) * (80 * 1 + 40 * x)), x)[0]))
q("C06-A-034", T, "Ratio of a cheap and a premium pulp blended when a short measure is also used", "Difficult",
  "Multi-step word problem",
  r"A juice seller blends a premium mango pulp costing Rs. $80$ per litre with a cheaper mango pulp costing Rs. $40$ per litre. He charges Rs. $72$ per litre for the blend, but his measure actually holds only $900$ mL when he claims it is $1$ litre. If his profit on what he actually sells is $25\%$, what is the ratio of the cheaper pulp to the premium pulp in his blend?",
  "MCQ",
  r"He receives Rs. $72$ for $0.9$ litre, that is Rs. $80$ per true litre. With $25\%$ profit, a true litre of the blend costs him $\frac{80}{1.25} = 64$ rupees. By alligation, cheaper : premium $= (80 - 64) : (64 - 40) = 16 : 24 = 2 : 3$.",
  "Ignoring the short measure, or reporting the cheaper pulp as a share of the blend.",
  "C06A-short-measure-mixture-profit", "Two sources of gain combined: the short measure and the cheaper pulp; the true price per litre must be found before alligation.",
  correct=r"$2 : 3$",
  distractors=[(r"$14 : 11$", r"Ignores the short measure: cost $= \frac{72}{1.25} = 57.6$, so cheaper : premium $= (80 - 57.6) : (57.6 - 40) = 22.4 : 17.6$."),
               (r"$3 : 2$", r"Pairs the differences with the wrong pulps."),
               (r"$2 : 5$", r"Finds the cheaper pulp as $\frac{2}{5}$ of the blend and writes it as cheaper : premium.")],
  check=_d8, values=[F(2, 3), F(14, 11), F(3, 2), F(2, 5)], exams=CX, cognitive="Analysis")


def _d9():
    x, a = symbols('x a', positive=True)  # x = kg at profit per kg at loss; a = cost per kg of profit lot
    s = Rational(6, 5) * a           # same selling price per kg
    b = s / Rational(4, 5)           # cost per kg of loss lot
    return F(str(solve(Eq(s * (x + 1), Rational(104, 100) * (a * x + b * 1)), x)[0]))
q("C06-A-035", T, "Quantity ratio of two lots sold at the same price, one at a profit and one at a loss", "Difficult",
  "Conceptual/application",
  r"A trader has two lots of rice, bought at different prices per kg. He sells every kilogram of both lots at the same selling price per kg, making a profit of $20\%$ on the first lot and a loss of $20\%$ on the second. On the whole sale his profit is $4\%$. What is the ratio of the weight of the first lot to the weight of the second lot?",
  "MCQ",
  r"Profit percentages average with cost as the weight, so cost of first lot : cost of second lot $= (4 + 20) : (20 - 4) = 3 : 2$. With selling price $s$, the cost per kg is $\frac{s}{1.2}$ for the first lot and $\frac{s}{0.8}$ for the second, that is in the ratio $2 : 3$. Weights $= \frac{3}{2} : \frac{2}{3} = 9 : 4$.",
  "Reading the alligation ratio of profit percentages as a ratio of weights rather than of costs.",
  "C06A-profit-loss-parts", "The weights in profit percent are costs, and the two lots have different costs per kg.",
  correct=r"$9 : 4$",
  distractors=[(r"$3 : 2$", r"Takes the alligation ratio of the profit percentages as the weight ratio."),
               (r"$2 : 3$", r"Pairs the differences with the wrong lots and treats the result as weights."),
               (r"$1 : 1$", r"Converts the cost ratio to weights using the other lot's cost per kg: $\frac{3}{3} : \frac{2}{2}$.")],
  check=_d9, values=[F(9, 4), F(3, 2), F(2, 3), F(1, 1)], exams=CX, cognitive="Analysis")
