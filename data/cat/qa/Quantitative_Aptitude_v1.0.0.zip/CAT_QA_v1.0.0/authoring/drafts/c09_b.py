import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Ages and everyday linear problems"
HARD = ("CAT", "XAT")


def _pos(sol):
    return [s for s in sol]


# ---------------------------------------------------------------- 001
def _c001():
    x = symbols('x', positive=True)
    s = solve(Eq((4*x + 6) * 9, (3*x + 6) * 11), x)[0]
    return 3*s
q("C09-B-001", T, "Present ratio and ratio after a fixed number of years give the ages", "Easy",
  "Multi-step word problem",
  r"The present ages of Ravi and Meera are in the ratio $4 : 3$. Six years from now, the ratio of their ages will be $11 : 9$. What is Meera's present age?",
  "MCQ",
  r"Let the present ages be $4x$ and $3x$. Then $\frac{4x+6}{3x+6} = \frac{11}{9}$, so $36x + 54 = 33x + 66$, giving $x = 4$. Meera is $3x = 12$ years old (Ravi is $16$; check: $22 : 18 = 11 : 9$).",
  "Reporting Ravi's age or the age six years from now instead of Meera's present age.",
  "C09B-age-ratio-shift", "One linear equation from two ratios; a single trap about which age is asked.",
  correct=r"$12$ years",
  distractors=[(r"$16$ years", "Reports Ravi's present age $4x = 16$."),
               (r"$18$ years", "Reports Meera's age six years from now, $12 + 6 = 18$."),
               (r"$22$ years", "Reports Ravi's age six years from now, $16 + 6 = 22$.")],
  check=_c001, values=[12, 16, 18, 22], cognitive="Application")

# ---------------------------------------------------------------- 002
def _c002():
    k, f = symbols('k f')
    s = solve([Eq(f - 10, 5*(k - 10)), Eq(7*(k + 6), 3*(f + 6))], [k, f])
    return s[f] - s[k]
q("C09-B-002", T, "Two past and future ratios fix the father's age at the son's birth", "Medium",
  "Multi-step word problem",
  r"Ten years ago, the ratio of Kabir's age to his father's age was $1 : 5$. Six years from now, the ratio will be $3 : 7$. How old, in years, was Kabir's father when Kabir was born?",
  "TITA",
  r"Ten years ago let the ages be $x$ and $5x$. Six years from now they will be $x + 16$ and $5x + 16$, so $7(x + 16) = 3(5x + 16)$, which gives $8x = 64$ and $x = 8$. Kabir is $18$ and his father is $50$ now. The father's age at Kabir's birth equals the constant age gap, $50 - 18 = 32$.",
  "Reporting the father's present age, or treating the time gap from ten years ago to six years ahead as $6$ years instead of $16$.",
  "C09B-age-ratio-shift", "Two ratios at different times, a 16-year shift between them, and the age-gap insight.",
  tita_answer=32, check=_c002,
  tita_traps=[(50, "Reports the father's present age instead of the age gap."),
              (40, "Reports the father's age ten years ago, $5x = 40$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    x, t = symbols('x t', positive=True)
    tt = solve(Eq(7*x + t, 2*(2*x + t)), t)[0]
    return simplify((2*x + tt) / (7*x))
q("C09-B-003", T, "Ratio-only conclusion when absolute ages are not fixed", "Medium",
  "Conceptual/application",
  r"The present ages of a father and his son are in the ratio $7 : 2$. At some time in the future, the ratio of their ages will be $2 : 1$. At that time, what will be the ratio of the son's age then to the father's present age?",
  "MCQ",
  r"Let the ages be $7x$ and $2x$ and let the ratio become $2 : 1$ after $t$ years: $7x + t = 2(2x + t)$ gives $t = 3x$. The son will then be $2x + 3x = 5x$, and the father's present age is $7x$. The required ratio is $5 : 7$, whatever the value of $x$.",
  "Assuming the son's age doubles, or comparing the son's future age with his own present age.",
  "C09B-age-ratio-shift", "Answer must be found without knowing the actual ages; needs the elapsed time in terms of $x$.",
  correct=r"$5 : 7$",
  distractors=[(r"$10 : 7$", "Compares the father's future age $10x$ with his present age $7x$."),
               (r"$5 : 2$", "Compares the son's future age $5x$ with the son's present age $2x$."),
               (r"$4 : 7$", "Assumes the son's age simply doubles from $2x$ to $4x$.")],
  check=_c003, values=[Rational(5, 7), Rational(10, 7), Rational(5, 2), Rational(4, 7)],
  cognitive="Analysis")

# ---------------------------------------------------------------- 004
def _c004():
    p, m = symbols('p m')
    s = solve([Eq((p + 5) + (m + 5), 66), Eq(m - p, 28)], [p, m])
    return s[p]
q("C09-B-004", T, "Future sum of ages and the mother's age at birth", "Medium",
  "Multi-step word problem",
  r"Five years from now, the sum of the ages of Priya and her mother will be $66$ years. Her mother was $28$ years old when Priya was born. What is Priya's present age?",
  "MCQ",
  r"The present sum of their ages is $66 - 2 \times 5 = 56$. The mother's age at Priya's birth is the constant gap, so mother $-$ Priya $= 28$. Hence Priya's present age is $\frac{56 - 28}{2} = 14$ years.",
  "Treating the future sum $66$ as the present sum, or reporting the age gap or the mother's age instead of Priya's age.",
  "C09B-age-gap-at-birth-sum", "Sum and difference of ages, with a time shift that must be applied to both people.",
  correct=r"$14$ years",
  distractors=[(r"$19$ years", "Uses $66$ as the present sum: $\\frac{66 - 28}{2} = 19$, which is Priya's age five years from now."),
               (r"$42$ years", "Reports the mother's present age, $14 + 28 = 42$."),
               (r"$28$ years", "Reports the constant age gap, the mother's age at Priya's birth, as Priya's age.")],
  check=_c004, values=[14, 19, 42, 28], cognitive="Application")

# ---------------------------------------------------------------- 005
def _c005():
    # brute force over integer ages a >= b >= c
    res = set()
    for c in range(0, 46):
        for b in range(c, 46):
            a = 45 - b - c
            if a < b:
                continue
            if (a - c) + (b - c) == 21 and b - c >= 0:
                res.add(a + b)
    assert len(res) == 1
    return res.pop()
q("C09-B-005", T, "Sum of ages at the youngest sibling's birth", "Medium",
  "Conceptual/application",
  r"The present ages of three siblings add up to $45$ years. When the youngest of them was born, the ages of the other two added up to $21$ years. What is the sum of the present ages of the two elder siblings?",
  "MCQ",
  r"If the youngest is $c$ years old now, then $c$ years ago each elder sibling was $c$ years younger, so their combined age was $(45 - c) - 2c = 21$. This gives $3c = 24$, so $c = 8$. The two elder siblings together are $45 - 8 = 37$ years old.",
  "Subtracting the youngest's age only once from the elder siblings' combined age.",
  "C09B-age-sum-elapsed", "Needs the idea that a combined age of two people changes by twice the elapsed time.",
  correct=r"$37$ years",
  distractors=[(r"$29$ years", "Finds $c = 8$ and then adds it only once to the past total: $21 + 8 = 29$."),
               (r"$33$ years", "Writes $(45 - c) - c = 21$, getting $c = 12$ and $45 - 12 = 33$."),
               (r"$24$ years", "Takes $45 - 21 = 24$ as the answer without modelling the elapsed years.")],
  check=_c005, values=[37, 29, 33, 24], cognitive="Analysis")

# ---------------------------------------------------------------- 006
def _c006():
    r, k = symbols('r k')
    # when Ravi was k (r - k years ago), Kabir was k - (r - k)
    s = solve([Eq(r, 2*(k - (r - k))), Eq(r + k, 84)], [r, k])
    return s[k]
q("C09-B-006", T, "I am twice as old as you were when I was your age", "Medium",
  "Multi-step word problem",
  r"Ravi says to Kabir, 'I am twice as old as you were when I was as old as you are now.' The sum of their present ages is $84$ years. What is Kabir's present age?",
  "MCQ",
  r"Let Ravi be $r$ and Kabir $k$ years old. Ravi was $k$ years old $r - k$ years ago, when Kabir was $k - (r - k) = 2k - r$. So $r = 2(2k - r)$, that is $3r = 4k$. With $r + k = 84$, $k = 36$ and $r = 48$.",
  "Reporting Ravi's age or Kabir's age at the earlier time.",
  "C09B-age-when-i-was", "Translating a nested time statement into an equation; then a ratio split.",
  correct=r"$36$ years",
  distractors=[(r"$48$ years", "Reports Ravi's present age."),
               (r"$24$ years", "Reports Kabir's age at the earlier time, $2k - r = 24$."),
               (r"$42$ years", "Assumes the two are equally old and halves $84$.")],
  check=_c006, values=[36, 48, 24, 42], cognitive="Application")

# ---------------------------------------------------------------- 007
def _c007():
    s_, a = symbols('s a')
    d = s_ - a
    sol = solve([Eq(a - d, 8), Eq(s_ + d, 44)], [s_, a])
    return sol[s_]
q("C09-B-007", T, "Two 'when one was as old as the other' statements fix both ages", "Medium",
  "Conceptual/application",
  r"When Sneha was as old as Ananya is now, Ananya was $8$ years old. When Ananya becomes as old as Sneha is now, Sneha will be $44$ years old. What is Sneha's present age?",
  "MCQ",
  r"Let the age gap be $d$, so Sneha $=$ Ananya $+ d$. Going back $d$ years, Ananya was $A - d = 8$; going forward $d$ years, Sneha will be $A + 2d = 44$. Subtracting, $3d = 36$, so $d = 12$, Ananya is $20$ and Sneha is $32$. The ages $8, 20, 32, 44$ are equally spaced by the gap $12$.",
  "Taking the average of $8$ and $44$, assuming the present lies midway.",
  "C09B-age-when-i-was", "Uses the constant age gap as the step between four equally spaced ages.",
  correct=r"$32$ years",
  distractors=[(r"$26$ years", "Takes the midpoint of $8$ and $44$."),
               (r"$20$ years", "Reports Ananya's present age."),
               (r"$12$ years", "Reports the age gap $d$.")],
  check=_c007, values=[32, 26, 20, 12], cognitive="Analysis")

# ---------------------------------------------------------------- 008
def _c008():
    for J in range(1, 120):
        for M in range(1, J):
            d = J - M
            if M - d < 0:
                continue
            if J == 3 * (M - d) and (J + d) + J == 105:
                return J
q("C09-B-008", T, "Nested age statement combined with a future sum", "Difficult",
  "Multi-step word problem",
  r"Joseph is older than Meera. Joseph's present age is three times the age Meera was when Joseph was as old as Meera is now. When Meera becomes as old as Joseph is now, the sum of their ages will be $105$ years. What is Joseph's present age?",
  "MCQ",
  r"Let the ages be $J$ and $M$ with gap $d = J - M$. Joseph was $M$ years old $d$ years ago, when Meera was $M - d = 2M - J$; so $J = 3(2M - J)$, giving $J = \frac{3M}{2}$ and $d = \frac{M}{2}$. In $d$ years Meera will be $J$ and Joseph $J + d$, so $2J + d = 3M + \frac{M}{2} = 105$, giving $M = 30$ and $J = 45$.",
  "Reading the future sum $105$ as the present sum of ages.",
  "C09B-age-when-i-was", "Two nested time statements, each needing the age gap; easy to misplace the time of the sum.",
  correct=r"$45$ years",
  distractors=[(r"$30$ years", "Reports Meera's present age."),
               (r"$60$ years", "Reports Joseph's age at the future time, $J + d = 60$."),
               (r"$63$ years", "Treats $105$ as the present sum: $J + M = \\frac{5M}{2} = 105$ gives $M = 42$, $J = 63$.")],
  check=_c008, values=[45, 30, 60, 63], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 009
def _c009():
    x = symbols('x')
    return solve(Eq(x + 4, 3 * (x - 8)), x)[0]
q("C09-B-009", T, "One person's future age as a multiple of the same person's past age", "Easy",
  "Single-step computation",
  r"Four years from now, Harpreet's age will be three times what her age was eight years ago. What is Harpreet's present age?",
  "MCQ",
  r"Let her present age be $x$. Then $x + 4 = 3(x - 8) = 3x - 24$, so $2x = 28$ and $x = 14$. Check: in four years she will be $18$, and eight years ago she was $6$; $18 = 3 \times 6$. (Fast route: the $12$ years between the two times equal twice her earlier age, so she was $6$ then.)",
  "Expanding $3(x - 8)$ as $3x - 8$, or reporting her age at one of the other two times.",
  "C09B-self-reference-multiple", "One person, one equation; the only traps are the bracket and which time is asked.",
  correct=r"$14$ years",
  distractors=[(r"$18$ years", "Reports her age four years from now, $14 + 4 = 18$."),
               (r"$6$ years", "Expands $3(x - 8)$ as $3x - 8$: $x + 4 = 3x - 8$ gives $x = 6$."),
               (r"$12$ years", "Takes the $12$ year interval as three times her earlier age, so the earlier age is $4$ and $4 + 8 = 12$.")],
  check=_c009, values=[14, 18, 6, 12], cognitive="Application")

# ---------------------------------------------------------------- 010
def _c010():
    F, A, J = symbols('F A J')
    s = solve([Eq(A, F + 5), Eq(J, A - 9), Eq(A + 6, F + J)], [F, A, J])
    assert all(v > 0 for v in s.values())
    return s[J]
q("C09-B-010", T, "Three ages linked by two relative-time statements and one sum", "Medium",
  "Multi-step word problem",
  r"Arjun is now as old as Fatima will be $5$ years from now. Joseph is now as old as Arjun was $9$ years ago. Six years from now, Arjun's age will equal the sum of the present ages of Fatima and Joseph. What is Joseph's present age, in years?",
  "TITA",
  r"Let Fatima be $F$ now. Then Arjun is $F + 5$ and Joseph is $(F + 5) - 9 = F - 4$. The last condition gives $(F + 5) + 6 = F + (F - 4)$, so $F + 11 = 2F - 4$ and $F = 15$. Arjun is $20$ and Joseph is $15 - 4 = 11$ (check: $20 + 6 = 26 = 15 + 11$).",
  "Writing the first relation in the wrong direction (Arjun younger than Fatima), or reporting another person's age.",
  "C09B-age-chain-relations", "Express three ages in one variable through a chain of relative statements, then one equation with mixed times.",
  tita_answer=11, check=_c010,
  tita_traps=[(15, "Reports Fatima's present age."),
              (1, "Takes Arjun as $F - 5$: then Joseph is $F - 14$, $F + 1 = 2F - 14$ gives $F = 15$ and Joseph $1$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    sols = []
    for J in range(1, 100):
        for H in range(0, J):
            for P in range(J + 1, 120):
                if P - J == H and J - H == 4 and 3 * (P + 6) == 5 * (J + 6):
                    sols.append((P, J, H))
    assert len(sols) == 1
    P, J, H = sols[0]
    ts = [t for t in range(0, H + 1) if P - t == 3 * (H - t)]
    assert len(ts) == 1
    return ts[0]
q("C09-B-011", T, "Ages of three people from birth-time statements and a future ratio", "Difficult",
  "Multi-step word problem",
  r"When Joseph was born, Priya was as old as Harpreet is now. When Harpreet was born, Joseph was $4$ years old. Six years from now, the ratio of Priya's age to Joseph's age will be $5 : 3$. How many years ago was Priya exactly three times as old as Harpreet?",
  "MCQ",
  r"Let the present ages be $P$, $J$ and $H$. Priya's age at Joseph's birth is $P - J$, so $P - J = H$; Joseph's age at Harpreet's birth is $J - H = 4$. Hence $H = J - 4$ and $P = J + H = 2J - 4$. Then $3(2J + 2) = 5(J + 6)$ gives $J = 24$, so $H = 20$ and $P = 44$. Finally $44 - t = 3(20 - t)$ gives $2t = 16$, $t = 8$ (ages $36$ and $12$ then).",
  "Applying the $5 : 3$ ratio to the present ages instead of the ages six years from now, or reporting an age instead of the time.",
  "C09B-age-chain-relations", "Three people, two birth-time statements to translate, a future ratio, and a final condition in the past.",
  correct=r"$8$ years",
  distractors=[(r"$2$ years", "Applies $5 : 3$ to the present ages: $3(2J - 4) = 5J$ gives $J = 12$, $H = 8$, $P = 20$, and $20 - t = 3(8 - t)$ gives $t = 2$."),
               (r"$12$ years", "Solves correctly but reports Harpreet's age at that time, $20 - 8 = 12$."),
               (r"$36$ years", "Solves correctly but reports Priya's age at that time, $44 - 8 = 36$.")],
  check=_c011, values=[8, 2, 12, 36], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 012
def _c012():
    t = symbols('t')
    return solve(Eq(42 + t, 2 * (12 + t)), t)[0]
q("C09-B-012", T, "Years until the father is twice as old as his son", "Easy",
  "Inverse/parameter",
  r"Arjun is $42$ years old and his son is $12$ years old. After how many years will Arjun's age be exactly twice his son's age? Give the answer in years.",
  "TITA",
  r"After $t$ years, $42 + t = 2(12 + t)$, so $t = 42 - 24 = 18$. Check: $60 = 2 \times 30$. (Equivalently, the gap of $30$ years must equal the son's age, so the son must be $30$.)",
  "Forgetting that both ages increase by the same number of years.",
  "C09B-age-multiple-over-time", "One equation; the only trap is aging just one person.",
  tita_answer=18, check=_c012,
  tita_traps=[(30, "Reports the age gap, which is the son's age at that time."),
              (9, "Ages only the son: $42 = 2(12 + t)$ gives $t = 9$.")],
  cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    f, m, t = symbols('f m t')
    s = solve([Eq(m - 10, 4*(f - 10)), Eq(m + 10, 2*(f + 10))], [f, m])
    return solve(Eq(s[m] - t, 7*(s[f] - t)), t)[0]
q("C09-B-013", T, "Find ages from two multiples, then locate a third multiple", "Medium",
  "Inverse/parameter",
  r"Ten years ago, Fatima's mother was $4$ times as old as Fatima. Ten years from now, her mother will be twice as old as Fatima. How many years ago was her mother exactly $7$ times as old as Fatima? Give the answer in years.",
  "TITA",
  r"With present ages $f$ and $m$: $m - 10 = 4(f - 10)$ and $m + 10 = 2(f + 10)$. From the first, $m = 4f - 30$; substituting in the second, $4f - 20 = 2f + 20$, so $f = 20$ and $m = 50$. Then $50 - t = 7(20 - t)$ gives $6t = 90$, so $t = 15$ (ages $35$ and $5$).",
  "Reporting one of the ages at that time instead of the number of years ago.",
  "C09B-age-multiple-over-time", "Two equations for the ages, then a third condition to invert.",
  tita_answer=15, check=_c013,
  tita_traps=[(5, "Reports Fatima's age at that time."),
              (35, "Reports her mother's age at that time.")],
  cognitive="Application")

# ---------------------------------------------------------------- 014
def _c014():
    yr = None
    for S in range(1, 60):
        F = 3 * S
        M = F - 4
        if M + 10 == 2 * (S + 10):
            for t in range(-S, 60):
                if F + t == (S + t) + (M + t):
                    yr = 2015 + t
    return yr
q("C09-B-014", T, "Calendar-year age conditions for three family members", "Difficult",
  "Multi-step word problem",
  r"In $2015$, Sneha's father was $3$ times as old as Sneha. Her mother is $4$ years younger than her father. In $2025$, her mother was twice as old as Sneha. In which year was her father's age equal to the sum of the ages of Sneha and her mother? Treat all ages as measured on the same date each year, and type the year as a four-digit number.",
  "TITA",
  r"Let Sneha be $s$ in $2015$; then her father is $3s$ and her mother $3s - 4$. In $2025$: $3s + 6 = 2(s + 10)$, so $s = 14$, father $42$, mother $38$ (in $2015$). At $2015 + t$: $42 + t = (14 + t) + (38 + t)$ gives $t = -10$. The year is $2005$, when the ages were $32$, $4$ and $28$.",
  "Getting the sign of $t$ wrong and moving forward in time instead of back.",
  "C09B-age-multiple-over-time", "Three people, two anchor years, and a final condition that lies in the past.",
  tita_answer=2005, check=_c014,
  tita_traps=[(2025, "Sign slip: solves to $t = +10$ and moves forward from $2015$."),
              (2015, "Finds $t = -10$ but applies it to $2025$ instead of $2015$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 015
def _c015():
    # ages 5x and 3x (take x = 1 by scaling); ratio r occurs t years from now with t > 0
    x, t = symbols('x t', positive=True)
    opts = [Rational(4, 3), Rational(7, 4), Rational(2, 1), Rational(1, 1)]
    possible = []
    for r in opts:
        sol = solve(Eq(5*x + t, r*(3*x + t)), t)
        if sol and all(s.subs(x, 1) > 0 for s in sol):
            possible.append(r)
    assert len(possible) == 1
    return possible[0]
q("C09-B-015", T, "Ratio of two ages decreases towards 1 over time", "Medium",
  "Conceptual/application",
  r"The present ages of two siblings are in the ratio $5 : 3$. Which of the following can be the ratio of the elder sibling's age to the younger sibling's age at some time in the future?",
  "MCQ",
  r"The age gap is fixed while both ages grow, so the ratio of the elder's age to the younger's keeps falling from $\frac{5}{3} \approx 1.67$ towards $1$, without ever reaching $1$. A future ratio must lie strictly between $1$ and $\frac{5}{3}$. Of the options only $\frac{4}{3}$ does: with ages $5x$ and $3x$, $\frac{5x + t}{3x + t} = \frac{4}{3}$ gives $t = 3x$ years from now.",
  "Believing that the ratio of ages can rise as time passes, confusing past ratios with future ones, or thinking the two ages can become equal.",
  "C09B-age-ratio-trend", "Needs the principle that the ratio moves monotonically towards 1, not computation.",
  correct=r"$4 : 3$",
  distractors=[(r"$7 : 4$", "Believes the ratio of ages rises as the elder sibling pulls further ahead, and picks a ratio just above $5 : 3$."),
               (r"$2 : 1$", "Confuses past with future: the ratio was $2 : 1$ exactly $x$ years ago, when the ages were $4x$ and $2x$."),
               (r"$1 : 1$", "Thinks the younger sibling eventually catches up, so the ratio reaches $1$; the fixed gap means the ages are never equal.")],
  check=_c015, values=[Rational(4, 3), Rational(7, 4), Rational(2, 1), Rational(1, 1)], cognitive="Understanding")

# ---------------------------------------------------------------- 016
def _c016():
    for c2 in range(0, 60):
        c1 = c2 + 4
        m = c1 + 27
        if m + c1 + c2 == 89:
            return c1
q("C09-B-016", T, "Mother's ages at two births and the present sum of three ages", "Easy",
  "Multi-step word problem",
  r"A mother was $27$ years old when her first child was born and $31$ years old when her second child was born. The present ages of the mother and her two children add up to $89$ years. What is the present age of the first child, in years?",
  "TITA",
  r"If the second child is $y$, the first child is $y + 4$ and the mother is $y + 31$. Then $3y + 35 = 89$ gives $y = 18$. The first child is $18 + 4 = 22$ years old (mother $49$).",
  "Reporting the second child's age, which is the variable solved for.",
  "C09B-age-gap-at-birth-sum", "Express all ages in one variable from the birth gaps; one equation.",
  tita_answer=22, check=_c016,
  tita_traps=[(18, "Reports the second child's age."),
              (49, "Reports the mother's present age.")],
  cognitive="Application")

# ---------------------------------------------------------------- 017
def _c017():
    F = symbols('F')
    mother = F - 4
    joseph = F - 31
    priya = mother - 26
    return simplify(joseph - priya)   # positive means Joseph older
q("C09-B-017", T, "Comparing siblings' ages from parents' ages at their births", "Medium",
  "Conceptual/application",
  r"Joseph and Priya are brother and sister. Joseph was born when their father was $31$ years old, and Priya was born when their mother was $26$ years old. Their father is $4$ years older than their mother. How do the ages of Joseph and Priya compare?",
  "MCQ",
  r"If the father is $F$ now, the mother is $F - 4$. Joseph is $F - 31$ and Priya is $(F - 4) - 26 = F - 30$. So Priya is older than Joseph by $1$ year.",
  "Comparing $31$ and $26$ directly and ignoring the age gap between the parents.",
  "C09B-age-gap-at-birth-sum", "Must measure both children against the same parent; answer independent of the actual ages.",
  correct=r"Priya is older by $1$ year",
  distractors=[(r"Joseph is older by $1$ year", "Gets the difference $1$ but the sign wrong."),
               (r"Priya is older by $9$ years", "Takes the mother as $4$ years older than the father: Priya $= F + 4 - 26$."),
               (r"Priya is older by $5$ years", "Treats the parents as the same age and compares $31$ with $26$ directly.")],
  check=_c017, values=[-1, 1, -9, -5], cognitive="Analysis")

# ---------------------------------------------------------------- 018
def _c018():
    k = symbols('k')
    kk = solve(Eq(1*5*k + 2*3*k + 5*2*k, 210), k)[0]
    return 3*kk
q("C09-B-018", T, "Coins in a given ratio with a known total value", "Easy",
  "Single-step computation",
  r"A purse contains only Rs. $1$, Rs. $2$ and Rs. $5$ coins, and the numbers of these coins are in the ratio $5 : 3 : 2$. The total value of the coins is Rs. $210$. How many Rs. $2$ coins are in the purse?",
  "MCQ",
  r"Take $5k$, $3k$ and $2k$ coins. Their value is $5k + 6k + 10k = 21k = 210$, so $k = 10$. There are $3k = 30$ Rs. $2$ coins.",
  "Splitting the total value, rather than the number of coins, in the given ratio.",
  "C09B-coins-ratio-value", "One equation once the value of one set of coins is found.",
  correct=r"$30$",
  distractors=[(r"$63$", "Splits Rs. $210$ in the ratio $5 : 3 : 2$ by value and reports the Rs. $63$ share as a count."),
               (r"$20$", "Reports the number of Rs. $5$ coins, $2k = 20$."),
               (r"$10$", "Reports $k = 10$ itself.")],
  check=_c018, values=[30, 63, 20, 10], cognitive="Application")

# ---------------------------------------------------------------- 019
def _c019():
    for k in range(1, 200):
        two, five = 3 * k, 2 * k
        if five >= 6 and (two + 4) == 2 * (five - 6):
            return 2 * two + 5 * five
q("C09-B-019", T, "Coin counts in a ratio that changes after some coins are moved", "Medium",
  "Multi-step word problem",
  r"A money box contains only Rs. $2$ coins and Rs. $5$ coins, and the numbers of these coins are in the ratio $3 : 2$. Kabir takes out $6$ of the Rs. $5$ coins and puts in $4$ more Rs. $2$ coins. The numbers of Rs. $2$ coins and Rs. $5$ coins are now in the ratio $2 : 1$. What was the total value of the coins in the box before Kabir made the change?",
  "MCQ",
  r"Let there be $3k$ Rs. $2$ coins and $2k$ Rs. $5$ coins at first. Afterwards $3k + 4 = 2(2k - 6)$, so $k = 16$: there were $48$ Rs. $2$ coins and $32$ Rs. $5$ coins. Their value was $96 + 160 =$ Rs. $256$ (afterwards $52$ and $26$ coins, ratio $2 : 1$).",
  "Leaving out one of the two changes, or valuing the box after the change.",
  "C09B-coins-ratio-change", "Ratio before and after a change gives the multiplier; then convert counts to value.",
  correct=r"Rs. $256$",
  distractors=[(r"Rs. $234$", "Finds the counts but values the box after the change: $52 \\times 2 + 26 \\times 5 = 234$."),
               (r"Rs. $192$", "Ignores the $4$ Rs. $2$ coins put in: $3k = 2(2k - 6)$ gives $k = 12$, value $72 + 120 = 192$."),
               (r"Rs. $160$", "Reports the value of the Rs. $5$ coins only, $32 \\times 5 = 160$.")],
  check=_c019, values=[256, 234, 192, 160], cognitive="Application")

# ---------------------------------------------------------------- 020
def _c020():
    for f in range(0, 21):
        t = 20 - f
        if 500*f + 200*t == 7600:
            return 200*f + 500*t
q("C09-B-020", T, "ATM notes: value after interchanging the counts", "Medium",
  "Multi-step word problem",
  r"Meera withdrew Rs. $7{,}600$ from an ATM and received $20$ notes, each of Rs. $200$ or Rs. $500$. Had the numbers of the two kinds of notes been interchanged, how much money would she have received?",
  "MCQ",
  r"If all $20$ notes were Rs. $200$, she would get Rs. $4{,}000$; each Rs. $500$ note adds Rs. $300$, so there are $\frac{3600}{300} = 12$ Rs. $500$ notes and $8$ Rs. $200$ notes. After interchanging she would have $12$ notes of Rs. $200$ and $8$ of Rs. $500$: Rs. $2{,}400 + 4{,}000 =$ Rs. $6{,}400$.",
  "Adding instead of subtracting the change, or valuing the change at one denomination only.",
  "C09B-two-denomination-swap", "Find the split first, then evaluate the swapped collection.",
  correct=r"Rs. $6{,}400$",
  distractors=[(r"Rs. $8{,}800$", "Finds the change $(12 - 8) \\times 300 = 1{,}200$ but adds it."),
               (r"Rs. $5{,}600$", "Values the change at Rs. $500$ per note: $7{,}600 - 4 \\times 500 = 5{,}600$."),
               (r"Rs. $6{,}800$", "Values the change at Rs. $200$ per note: $7{,}600 - 4 \\times 200 = 6{,}800$.")],
  check=_c020, values=[6400, 8800, 5600, 6800], cognitive="Application")

# ---------------------------------------------------------------- 021
def _c021():
    for n in range(1, 500):
        for k in range(0, n + 1):
            v = Fraction(1, 2) * (n - k) + 2 * k
            if v == Fraction(11, 10) * n and v + 20 == Fraction(5, 4) * (n + 10):
                return k
q("C09-B-021", T, "Average value of a coin before and after adding coins", "Difficult",
  "Multi-step word problem",
  r"A bag contains only $50$ paise coins and Rs. $2$ coins, and the average value of a coin in the bag is Rs. $1.10$. After $10$ more Rs. $2$ coins are put into the bag, the average value of a coin becomes Rs. $1.25$. How many Rs. $2$ coins were in the bag originally?",
  "MCQ",
  r"Let there be $n$ coins at first, worth $1.1n$ rupees. After adding Rs. $20$ in $10$ coins, $1.1n + 20 = 1.25(n + 10)$, so $0.15n = 7.5$ and $n = 50$, worth Rs. $55$. If $k$ of them are Rs. $2$ coins, $0.5(50 - k) + 2k = 55$, so $1.5k = 30$ and $k = 20$.",
  "Using the new average for the original bag, or reporting the count after the addition.",
  "C09B-coins-average-value", "Two stages: total count from the change in average, then the split from the original average.",
  correct=r"$20$",
  distractors=[(r"$50$", "Reports the total number of coins originally in the bag."),
               (r"$30$", "Reports the number of Rs. $2$ coins after the $10$ were added."),
               (r"$25$", "Finds $n = 50$ but uses the new average: $0.5(50 - k) + 2k = 1.25 \\times 50$ gives $k = 25$.")],
  check=_c021, values=[20, 50, 30, 25], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 022
def _c022():
    r, s = symbols('r s')
    sol = solve([Eq(r - 30, s + 30), Eq(r + 20, 3*(s - 20))], [r, s])
    return sol[r]
q("C09-B-022", T, "Two hypothetical money transfers between two people", "Easy",
  "Multi-step word problem",
  r"If Ravi gives Rs. $30$ to Sneha, they will have equal amounts. If instead Sneha gives Rs. $20$ to Ravi, Ravi will have three times as much as Sneha. How much money does Ravi have?",
  "MCQ",
  r"Equal after a transfer of Rs. $30$ means Ravi has Rs. $60$ more: $r = s + 60$. The second condition gives $s + 80 = 3(s - 20)$, so $2s = 140$ and $s = 70$. Ravi has Rs. $130$.",
  "Taking the difference to be Rs. $30$ instead of twice the amount transferred.",
  "C09B-transfer-equalise", "Two short conditions; the key trap is the doubled difference.",
  correct=r"Rs. $130$",
  distractors=[(r"Rs. $70$", "Reports Sneha's amount."),
               (r"Rs. $85$", "Takes $r = s + 30$: then $s + 50 = 3(s - 20)$ gives $s = 55$ and $r = 85$."),
               (r"Rs. $100$", "Reports the equal amount each would have, $\\frac{130 + 70}{2}$.")],
  check=_c022, values=[130, 70, 85, 100], cognitive="Application")

# ---------------------------------------------------------------- 023
def _c023():
    for p in range(91):
        for k in range(91 - p):
            j = 90 - p - k
            P, K, J = p - 5, k + 5, j
            K, J = K - 8, J + 8
            if P == K == J:
                return k
q("C09-B-023", T, "Marbles passed along until all three are equal", "Easy",
  "Multi-step word problem",
  r"Priya, Kabir and Joseph together have $90$ marbles. Priya gives $5$ marbles to Kabir, and then Kabir gives $8$ marbles to Joseph. After these two transfers all three have the same number of marbles. How many marbles did Kabir have at the start?",
  "TITA",
  r"At the end each has $\frac{90}{3} = 30$. Kabir received $5$ and gave away $8$, a net loss of $3$, so he started with $30 + 3 = 33$.",
  "Getting the sign of Kabir's net change wrong.",
  "C09B-transfer-equalise", "Work back from the equal final shares; one sign to watch.",
  tita_answer=33, check=_c023,
  tita_traps=[(27, "Treats Kabir's net change as a gain of $3$."),
              (30, "Reports the final equal share.")],
  cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    m, f = symbols('m f')
    s = solve([Eq(m + f/3, 3*(f - f/3)), Eq(f + 120, (m - 120) + 40)], [m, f])
    return s[m] + s[f]
q("C09-B-024", T, "Two conditional statements about sharing money", "Difficult",
  "Multi-step word problem",
  r"Meera says to Fatima, 'If you give me one-third of your money, I will have three times as much as you will have left.' Fatima replies, 'If instead you give me Rs. $120$, I will have Rs. $40$ more than you will have.' How much money do the two of them have together?",
  "MCQ",
  r"Let Meera have $m$ and Fatima $f$. First condition: $m + \frac{f}{3} = 3 \times \frac{2f}{3} = 2f$, so $m = \frac{5f}{3}$. Second: $f + 120 = (m - 120) + 40$, so $m = f + 200$. Then $\frac{2f}{3} = 200$, $f = 300$, $m = 500$, and together they have Rs. $800$.",
  "Comparing with Meera's original amount instead of her amount after giving, or not reducing Fatima's money in the first condition.",
  "C09B-transfer-equalise", "Fractional transfer plus a fixed transfer; both conditions are easy to misread.",
  correct=r"Rs. $800$",
  distractors=[(r"Rs. $320$", "Writes $f + 120 = m + 40$ (Meera's amount not reduced): $m = f + 80$, giving $f = 120$, $m = 200$."),
               (r"Rs. $440$", "Does not reduce Fatima's money in the first condition: $m + \\frac{f}{3} = 3f$ gives $m = \\frac{8f}{3}$, so $f = 120$, $m = 320$."),
               (r"Rs. $500$", "Reports Meera's amount only.")],
  check=_c024, values=[800, 320, 440, 500], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 025
def _sim_double(start, order):
    cur = dict(start)
    for loser in order:
        for p in cur:
            if p != loser:
                cur[loser] -= cur[p]
                cur[p] *= 2
    return cur


def _c025():
    tot = 160 + 200 + 240
    for r in range(tot + 1):
        for m in range(tot + 1 - r):
            a = tot - r - m
            end = _sim_double({'R': r, 'M': m, 'A': a}, ['R', 'M', 'A'])
            if end == {'R': 160, 'M': 200, 'A': 240}:
                return a
q("C09-B-025", T, "Working back through three rounds of a doubling game", "Medium",
  "Multi-step word problem",
  r"Ravi, Meera and Arjun play three rounds of a game. In each round exactly one player loses, and the loser pays each of the other two players an amount equal to the money that player holds at that moment. Ravi loses the first round, Meera the second and Arjun the third. No other money changes hands. At the end Ravi has Rs. $160$, Meera Rs. $200$ and Arjun Rs. $240$. How much money, in rupees, did Arjun have at the start?",
  "TITA",
  r"Work backwards, halving the two winners and giving the total back to the loser. Before round $3$ (Arjun lost): Ravi $80$, Meera $100$, Arjun $240 + 180 = 420$. Before round $2$ (Meera lost): Ravi $40$, Arjun $210$, Meera $100 + 250 = 350$. Before round $1$ (Ravi lost): Meera $175$, Arjun $105$, Ravi $40 + 280 = 320$. Arjun started with Rs. $105$ (total $600$ checks).",
  "Stopping the backward process one or two rounds early.",
  "C09B-backwards-doubling-game", "Three backward steps with bookkeeping for three people.",
  tita_answer=105, check=_c025,
  tita_traps=[(420, "Undoes only the last round."),
              (210, "Undoes only the last two rounds.")],
  cognitive="Application")

# ---------------------------------------------------------------- 026
def _c026():
    # backward then verify by forward simulation
    names = ['R', 'M', 'A', 'F']
    cur = {p: Fraction(160) for p in names}
    for loser in reversed(names):
        gain = 0
        for p in names:
            if p != loser:
                half = cur[p] / 2
                gain += half
                cur[p] = half
        cur[loser] += gain
    assert _sim_double(cur, names) == {p: 160 for p in names}
    return cur['M']
q("C09-B-026", T, "Four-player doubling game worked backwards", "Difficult",
  "Multi-step word problem",
  r"Ravi, Meera, Arjun and Fatima play four rounds of a game. In each round exactly one player loses, and the loser pays each of the other three players an amount equal to the money that player holds at that moment. Ravi loses the first round, Meera the second, Arjun the third and Fatima the fourth. No other money changes hands, and at the end each of the four has Rs. $160$. How much money did Meera have at the start?",
  "MCQ",
  r"Work backwards from $(160, 160, 160, 160)$ in the order Ravi, Meera, Arjun, Fatima. Undo round $4$: $(80, 80, 80, 400)$. Undo round $3$: $(40, 40, 360, 200)$. Undo round $2$: $(20, 340, 180, 100)$. Undo round $1$: $(330, 170, 90, 50)$. Meera started with Rs. $170$.",
  "Stopping one step early, or halving a player in the round that player lost.",
  "C09B-backwards-doubling-game", "Four backward stages for four players; heavy bookkeeping where one slip propagates.",
  correct=r"Rs. $170$",
  distractors=[(r"Rs. $340$", "Stops after undoing rounds $4$, $3$ and $2$, reporting Meera's amount before round $2$."),
               (r"Rs. $330$", "Reports Ravi's starting amount."),
               (r"Rs. $85$", "Halves Meera's amount one extra time, undoing her round $1$ doubling twice: $\\frac{170}{2}$.")],
  check=_c026, values=[170, 340, 330, 85], cognitive="Application", exams=HARD)

# ---------------------------------------------------------------- 027
def _c027():
    x = symbols('x')
    return solve(Eq(2*(2*(2*x - 80) - 80) - 80, 0), x)[0]
q("C09-B-027", T, "Money doubled then a fixed fee paid, three times, ending at zero", "Medium",
  "Inverse/parameter",
  r"In a game, each time Sneha crosses a checkpoint, the money she holds is doubled, and immediately afterwards she pays a fee of Rs. $80$. After paying the fee at the third checkpoint she has no money left. How much money did she start with?",
  "MCQ",
  r"Work backwards: after the third fee she has $0$, so before it she had $80$ and before doubling $40$. Before the second fee: $40 + 80 = 120$, before doubling $60$. Before the first fee: $60 + 80 = 140$, before doubling $70$. She started with Rs. $70$.",
  "Undoing the steps in the wrong order (halving before adding the fee back).",
  "C09B-backwards-repeated-step", "Three backward steps, each with two operations to undo in the right order.",
  correct=r"Rs. $70$",
  distractors=[(r"Rs. $30$", "Writes $8x = 3 \\times 80$, as if the earlier fees were not affected by later doublings."),
               (r"Rs. $140$", "Undoes the steps in the wrong order: halves first and then adds $80$ each time ($0 \\to 80 \\to 120 \\to 140$)."),
               (r"Rs. $60$", "Undoes only the last two checkpoints, reporting the amount she had on reaching the second checkpoint.")],
  check=_c027, values=[70, 30, 140, 60], cognitive="Application")

# ---------------------------------------------------------------- 028
def _c028():
    for x in range(1, 2000):
        m = Fraction(x)
        for _ in range(3):
            m = m - (m / 2 + 10)
        if m == 20:
            return x
q("C09-B-028", T, "Spending half plus a fixed amount at each of three shops", "Easy",
  "Multi-step word problem",
  r"Kabir visits three shops one after another. At each shop he spends half of the money he has on entering that shop, and then Rs. $10$ more. He leaves the third shop with Rs. $20$. How much money did he have at first?",
  "MCQ",
  r"At each shop, money on leaving $= \frac{\text{money on entering}}{2} - 10$, so money on entering $= 2(\text{money on leaving} + 10)$. Going back: $2(20 + 10) = 60$, $2(60 + 10) = 140$, $2(140 + 10) = 300$. He had Rs. $300$.",
  "Doubling first and then adding Rs. $10$ when working backwards.",
  "C09B-backwards-repeated-step", "Three identical backward steps; one order-of-operations trap.",
  correct=r"Rs. $300$",
  distractors=[(r"Rs. $230$", "Undoes in the wrong order, doubling then adding $10$: $50, 110, 230$."),
               (r"Rs. $140$", "Stops after undoing only two shops."),
               (r"Rs. $160$", "Ignores the extra Rs. $10$ and just doubles three times: $20 \\times 8$.")],
  check=_c028, values=[300, 230, 140, 160], cognitive="Application")

# ---------------------------------------------------------------- 029
def _c029():
    for x in range(1, 2000):
        m = Fraction(x)
        ok = True
        for _ in range(3):
            if (m / 3).denominator != 1:
                ok = False
                break
            m = m - (m / 3 + 4)
        if ok and m == 12:
            return x
q("C09-B-029", T, "Giving one-third plus a fixed number to each of three friends", "Medium",
  "Multi-step word problem",
  r"Fatima has a box of sweets. She meets three friends one after another and gives each friend one-third of the sweets she has at that moment, plus $4$ more. After meeting the third friend she has $12$ sweets left. How many sweets did she have at the start?",
  "TITA",
  r"If she has $r$ before a friend, she has $\frac{2r}{3} - 4$ after, so $r = \frac{3}{2}(\text{after} + 4)$. Going back: $\frac{3}{2}(16) = 24$, $\frac{3}{2}(28) = 42$, $\frac{3}{2}(46) = 69$. She started with $69$ sweets (check: $69 \to 42 \to 24 \to 12$).",
  r"Stopping one step early, or multiplying by $3$ instead of $\frac{3}{2}$.",
  "C09B-backwards-repeated-step", "Three backward steps with a fraction to invert correctly.",
  tita_answer=69, check=_c029,
  tita_traps=[(42, "Undoes only two of the three gifts."),
              (24, "Undoes only the last gift.")],
  cognitive="Application")

# ---------------------------------------------------------------- 030
def _c030():
    for N in range(1, 1000):
        n = Fraction(N)
        r1 = n - (n / 5 + 4)
        r2 = r1 - (r1 / 4 + 3)
        kab = r2 / 3 + 2
        left = r2 - kab
        if all(v.denominator == 1 for v in (n / 5, r1 / 4, r2 / 3)) and left == kab + 4 and left >= 0:
            return N
q("C09-B-030", T, "Successive fractional shares with a final comparison condition", "Difficult",
  "Inverse/parameter",
  r"A jar of toffees is shared as follows. Ravi takes one-fifth of the toffees and $4$ more. Sneha then takes one-fourth of the toffees remaining and $3$ more. Kabir then takes one-third of the toffees remaining after that and $2$ more. The number of toffees left in the jar is $4$ more than the number Kabir took. How many toffees were in the jar at the start?",
  "TITA",
  r"With $N$ toffees, after Ravi $\frac{4N}{5} - 4$ remain, and after Sneha $\frac{3}{4}\left(\frac{4N}{5} - 4\right) - 3 = \frac{3N}{5} - 6$ remain. Kabir takes $\frac{1}{3}\left(\frac{3N}{5} - 6\right) + 2 = \frac{N}{5}$, leaving $\frac{2N}{5} - 6$. So $\frac{2N}{5} - 6 = \frac{N}{5} + 4$, giving $N = 50$ (shares $14$, $12$, $10$, with $14$ left).",
  "Reporting the number left at the end, or an intermediate remainder.",
  "C09B-successive-shares-compare", "The final amount is not given; three fractional stages must be carried symbolically before using the comparison.",
  tita_answer=50, check=_c030,
  tita_traps=[(14, "Reports the number of toffees left at the end."),
              (36, "Reports the number remaining after Ravi's share.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 031
def _c031():
    for w in range(31):
        if 400*w - 100*(30 - w) == 9500:
            return 30 - w
q("C09-B-031", T, "Daily wage with a fine for each day of absence", "Easy",
  "Single-step computation",
  r"A worker is hired for $30$ days. For every day he works he earns Rs. $400$, and for every day he is absent he is fined Rs. $100$. At the end of the $30$ days he receives Rs. $9{,}500$ in all. On how many days was he absent?",
  "TITA",
  r"Had he worked all $30$ days he would get Rs. $12{,}000$. Each day of absence costs him $400 + 100 = 500$ rupees. The shortfall is Rs. $2{,}500$, so he was absent on $\frac{2500}{500} = 5$ days.",
  "Reporting the number of days worked.",
  "C09B-reward-penalty", "One equation; the swing per absent day is the only idea.",
  tita_answer=5, check=_c031,
  tita_traps=[(25, "Reports the number of days worked, or divides the shortfall by the Rs. $100$ fine alone.")],
  cognitive="Application")

# ---------------------------------------------------------------- 032
def _c032():
    sols = []
    for b in range(1, 50):
        for g in range(1, 50):
            if g == 2 * (b - 1) and b == (g - 1) - 3:
                sols.append(b + g)
    assert len(sols) == 1
    return sols[0]
q("C09-B-032", T, "Brothers and sisters counted from each child's point of view", "Medium",
  "Conceptual/application",
  r"In a family, each son has twice as many sisters as brothers, and each daughter has $3$ fewer brothers than sisters. How many children are there in the family?",
  "MCQ",
  r"Let there be $b$ sons and $g$ daughters. A son's brothers exclude himself, so $g = 2(b - 1)$. A daughter's sisters exclude herself, so $b = (g - 1) - 3 = g - 4$. Then $g = 2(g - 5)$, so $g = 10$ and $b = 6$: $16$ children. Check: a son has $5$ brothers and $10$ sisters; a daughter has $9$ sisters and $6$ brothers.",
  "Forgetting that a child does not count himself or herself among the brothers or sisters.",
  "C09B-siblings-perspective", "Two equations whose only difficulty is excluding the child who is speaking, in each of two viewpoints.",
  correct=r"$16$",
  distractors=[(r"$9$", "Counts the speaking child among his or her own siblings in both statements: $g = 2b$ and $b = g - 3$ give $g = 6$, $b = 3$."),
               (r"$13$", "Excludes the son but not the daughter: $g = 2(b - 1)$ and $b = g - 3$ give $g = 8$, $b = 5$."),
               (r"$12$", "Excludes the daughter but not the son: $g = 2b$ and $b = g - 4$ give $g = 8$, $b = 4$.")],
  check=_c032, values=[16, 9, 13, 12], cognitive="Analysis")

# ---------------------------------------------------------------- 033
def _c033():
    n, L = symbols('n L')
    ravi = 60*(n - L) - 40*L
    kab = 60*((n + 10) - 3*L) - 40*(3*L)
    sol = solve([Eq(ravi - kab, 1800), Eq(ravi + kab, 4200)], [n, L], dict=True)
    assert len(sol) == 1
    nn, LL = sol[0][n], sol[0][L]
    assert nn > 3 * LL and LL > 0
    return (nn + 10) - 3 * LL
q("C09-B-033", T, "Two couriers with pay per on-time parcel and penalty per late parcel", "Difficult",
  "Multi-step word problem",
  r"A courier company pays Rs. $60$ for each parcel delivered on time, pays nothing for a parcel delivered late and also charges a penalty of Rs. $40$ for each late parcel. Last month Kabir handled $10$ more parcels than Ravi, and every parcel each of them handled was delivered, either on time or late. Kabir delivered three times as many parcels late as Ravi did. Ravi earned Rs. $1{,}800$ more than Kabir, and the two together earned Rs. $4{,}200$. How many parcels did Kabir deliver on time?",
  "TITA",
  r"If Ravi handled $n$ parcels with $L$ late, he earned $60(n - L) - 40L = 60n - 100L$. Kabir earned $60(n + 10) - 100 \times 3L = 60n + 600 - 300L$. The difference is $200L - 600 = 1800$, so $L = 12$; the unknown $n$ cancels here. The total is $120n + 600 - 400L = 120n - 4200 = 4200$, so $n = 70$. Kabir handled $80$ parcels with $36$ late, so he delivered $80 - 36 = 44$ on time.",
  "Ignoring Kabir's $10$ extra parcels, or treating a late parcel as costing only the Rs. $40$ penalty.",
  "C09B-reward-penalty", "Two stages: the difference equation (where the unknown total cancels, with a Rs. $100$ swing per late parcel) gives the late count, then the combined earnings give the parcel totals, and the question asks for a third derived quantity.",
  tita_answer=44, check=_c033,
  tita_traps=[(58, r"Solves correctly ($L = 12$, $n = 70$) but reports Ravi's on-time parcels, $70 - 12 = 58$."),
              (36, r"Solves correctly but reports Kabir's late parcels, $3 \times 12 = 36$, instead of his on-time parcels."),
              (68, r"Solves correctly but subtracts Ravi's late count from Kabir's total: $80 - 12 = 68$.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 034
def _c034():
    x = symbols('x')
    return solve(Eq(x + 12, 3 * (x - 10)), x)[0]
q("C09-B-034", T, "One person's hypothetical gain and loss compared as a multiple", "Easy",
  "Single-step computation",
  r"Arjun collects stamps. If he got $12$ more stamps, he would have three times as many as he would have left after giving away $10$ stamps. How many stamps does Arjun have?",
  "MCQ",
  r"With $x$ stamps, $x + 12 = 3(x - 10) = 3x - 30$, so $2x = 42$ and $x = 21$. Check: $33 = 3 \times 11$.",
  "Expanding $3(x - 10)$ as $3x - 10$, or ignoring one of the two hypothetical changes.",
  "C09B-self-reference-multiple", "One quantity compared with itself under two changes; one equation.",
  correct=r"$21$",
  distractors=[(r"$33$", "Reports the number he would have after getting $12$ more."),
               (r"$11$", "Expands $3(x - 10)$ as $3x - 10$: $x + 12 = 3x - 10$ gives $x = 11$."),
               (r"$6$", "Ignores the $10$ stamps given away: $x + 12 = 3x$ gives $x = 6$.")],
  check=_c034, values=[21, 33, 11, 6], cognitive="Application")

# ---------------------------------------------------------------- 035
def _c035():
    found = []
    for T_ in range(300, 50001):
        rem = Fraction(T_)
        shares = []
        k = 1
        while rem > 0 and k < 100:
            fixed = 300 * k
            if fixed > rem:
                break
            sh = fixed + (rem - fixed) / 6
            shares.append(sh)
            rem -= sh
            k += 1
        if rem == 0 and len(shares) >= 2 and len(set(shares)) == 1:
            found.append(T_)
    assert len(found) == 1
    return found[0]
q("C09-B-035", T, "Successive shares of a fixed part plus a fraction of the rest, all equal", "Difficult",
  "Conceptual/application",
  r"Harpreet divides a sum of money among his children in turn. The first child receives Rs. $300$ and then one-sixth of the money that remains after that. The second child then receives Rs. $600$ and one-sixth of the money that remains after that, the third child Rs. $900$ and one-sixth of what then remains, and so on, the fixed part rising by Rs. $300$ for each child. The money is used up exactly, and all the children receive equal amounts. What was the total sum of money, in rupees?",
  "TITA",
  r"Let the total be $S$. The first child gets $300 + \frac{S - 300}{6} = \frac{S + 1500}{6}$. The second gets $600 + \frac{1}{6}\left(S - \frac{S + 1500}{6} - 600\right)$. Equating the two shares and multiplying by $36$: $6S + 9000 = 21600 + 5S - 1500 - 3600$, so $S = 7500$. Each share is $\frac{9000}{6} = 1500$, so there are $5$ children; the fifth gets exactly the remaining $1500$.",
  "Reporting the number of children or the size of one share instead of the total.",
  "C09B-equal-shares-rule", "Equal shares must be used through the first two children to set up one equation; the bookkeeping of the remainder is easy to slip on.",
  tita_answer=7500, check=_c035,
  tita_traps=[(1500, "Reports the share of each child."),
              (5, "Reports the number of children.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 036
def _c036():
    def P(u): return 500 + Fraction(3, 2) * u
    def Q(u): return 200 + 3 * max(0, u - 40)
    def R(u): return 800
    best = None
    for m in range(0, 1000):
        if all(R(u) < P(u) and R(u) < Q(u) for u in range(m + 1, 2000)):
            best = m
            break
    return best
q("C09-B-036", T, "Three phone plans: threshold above which the flat plan is cheapest", "Difficult",
  "Casework/optimisation",
  r"A mobile operator offers three monthly plans. Plan P: Rs. $500$ rental plus Rs. $1.50$ per minute of calls. Plan Q: Rs. $200$ rental, the first $40$ minutes free, and Rs. $3$ per minute for every minute beyond $40$. Plan R: Rs. $800$ flat, with unlimited calls. Calls are billed in whole minutes. What is the least number $m$ such that plan R is strictly cheaper than each of the other two plans for every monthly usage of more than $m$ minutes?",
  "MCQ",
  r"Plan R beats plan P when $500 + 1.5u > 800$, that is $u > 200$. Plan R beats plan Q when $200 + 3(u - 40) > 800$, that is $u > 240$ (at $u = 240$ the bills of Q and R are equal). Both must hold, so R is strictly cheapest exactly for usage above $240$ minutes, and $m = 240$.",
  "Comparing plan R with only one of the other plans, or handling the free minutes with the wrong sign.",
  "C09B-fixed-plus-variable", "Piecewise charges and two separate comparisons that must both hold.",
  correct=r"$240$ minutes",
  distractors=[(r"$200$ minutes", "Compares plan R with plan P only."),
               (r"$280$ minutes", "Finds where plans P and Q cost the same: $500 + 1.5u = 200 + 3(u - 40)$."),
               (r"$160$ minutes", "Adds the free minutes instead of subtracting them: $200 + 3(u + 40) = 800$.")],
  check=_c036, values=[240, 200, 280, 160], cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 037
def _c037():
    j, o = symbols('j o')
    s = solve([Eq(j + o, Rational(32, 10)), Eq(j + Rational(3, 5)*o, Rational(22, 10))], [j, o])
    return s[j] * 1000
q("C09-B-037", T, "Jar weight from full and partly filled weights", "Medium",
  "Multi-step word problem",
  r"A jar completely filled with oil weighs $3.2$ kg. When it is filled to three-fifths of its capacity with the same oil, it weighs $2.2$ kg. What is the weight of the empty jar?",
  "MCQ",
  r"The two weights differ by two-fifths of the oil: $\frac{2}{5}$ of the oil weighs $1$ kg, so a full jar's oil weighs $2.5$ kg. The empty jar weighs $3.2 - 2.5 = 0.7$ kg, that is $700$ g.",
  "Treating three-fifths as half, or taking three-fifths of the full weight including the jar.",
  "C09B-container-weight", "Difference of two fillings isolates the oil; two plausible fraction traps.",
  correct=r"$700$ g",
  distractors=[(r"$1{,}200$ g", "Treats three-fifths as half: half the oil weighs $1$ kg, so the oil is $2$ kg and the jar $1.2$ kg."),
               (r"$1{,}000$ g", "Reports the $1$ kg difference itself as the jar's weight."),
               (r"$280$ g", "Takes three-fifths of the full weight including the jar: $2.2 - 0.6 \\times 3.2 = 0.28$ kg.")],
  check=_c037, values=[700, 1200, 1000, 280], cognitive="Application")

# ---------------------------------------------------------------- 038
def _c038():
    r, m, k = symbols('r m k')
    s = solve([Eq(r + m + k, 2400), Eq(r, (m + k)/2), Eq(m, (r + k)/3)], [r, m, k])
    return s[k]
q("C09-B-038", T, "Shares defined relative to the others' combined shares", "Medium",
  "Conceptual/application",
  r"Rs. $2{,}400$ is divided among Ravi, Meera and Kabir. Ravi's share is half of the combined shares of Meera and Kabir, and Meera's share is one-third of the combined shares of Ravi and Kabir. What is Kabir's share?",
  "MCQ",
  r"Ravi gets half of the rest, so he gets $\frac{1}{3}$ of the total: Rs. $800$. Meera gets one-third of the rest, so she gets $\frac{1}{4}$ of the total: Rs. $600$. Kabir gets $2400 - 800 - 600 =$ Rs. $1{,}000$.",
  "Reading 'half of the combined shares of the others' as half of the total.",
  "C09B-sharing-relations", "Turning 'a fraction of the others' into a fraction of the total is the key insight.",
  correct=r"Rs. $1{,}000$",
  distractors=[(r"Rs. $600$", "Takes Ravi's share as half of the total (Rs. $1{,}200$) with Meera correct at Rs. $600$."),
               (r"Rs. $800$", "Takes Meera's share as one-third of the total (Rs. $800$) with Ravi correct at Rs. $800$."),
               (r"Rs. $400$", "Takes Ravi's share as half and Meera's as one-third of the total: $2400 - 1200 - 800$.")],
  check=_c038, values=[1000, 600, 800, 400], cognitive="Analysis")

# ---------------------------------------------------------------- 039
def _c039():
    e, m, y = symbols('e m y')
    s = solve([Eq(e + m + y, 3000), Eq(e, 2*m), Eq(m, y + 200)], [e, m, y])
    return s[y]
q("C09-B-039", T, "Dividing money among three brothers with linked shares", "Easy",
  "Single-step computation",
  r"Rs. $3{,}000$ is divided among three brothers. The eldest gets twice as much as the middle one, and the middle one gets Rs. $200$ more than the youngest. How much does the youngest get?",
  "MCQ",
  r"Let the middle brother get $m$. The eldest gets $2m$ and the youngest $m - 200$, so $4m - 200 = 3000$ and $m = 800$. The youngest gets Rs. $600$.",
  "Reversing the 'Rs. 200 more' relation.",
  "C09B-sharing-relations", "One variable, one equation; the direction of the difference is the trap.",
  correct=r"Rs. $600$",
  distractors=[(r"Rs. $800$", "Reports the middle brother's share."),
               (r"Rs. $1{,}000$", "Divides Rs. $3{,}000$ equally among the three."),
               (r"Rs. $900$", "Reverses the relation, youngest $= m + 200$: $4m + 200 = 3000$ gives $m = 700$ and youngest $900$.")],
  check=_c039, values=[600, 800, 1000, 900], cognitive="Application")

# ---------------------------------------------------------------- 040
def _c040():
    for b in range(3, 200):
        s = 6*b + 4
        if s == 7*(b - 2):
            return b
q("C09-B-040", T, "Benches and students: two seating arrangements", "Easy",
  "Multi-step word problem",
  r"If $6$ students sit on each bench in a classroom, $4$ students are left without a seat. If instead $7$ students sit on each bench, $2$ benches remain completely empty and every other bench has exactly $7$ students. How many benches are there in the classroom?",
  "TITA",
  r"With $b$ benches, the number of students is $6b + 4$ and also $7(b - 2)$. So $6b + 4 = 7b - 14$, giving $b = 18$ (and $112$ students).",
  "Treating the 2 empty benches as 2 missing students.",
  "C09B-seating-leftover", "One equation from two counts of the same students.",
  tita_answer=18, check=_c040,
  tita_traps=[(6, "Writes $6b + 4 = 7b - 2$, treating 2 empty benches as 2 students."),
              (112, "Reports the number of students instead of benches.")],
  cognitive="Application")

# ---------------------------------------------------------------- 041
def _c041():
    for c in range(3, 200):
        n = 6*c + 15
        if n == 9*(c - 2) + 3:
            return n
q("C09-B-041", T, "Distributing chocolates: leftover in one plan, shortfall in another", "Medium",
  "Multi-step word problem",
  r"A teacher has some chocolates for the children in her class. If she gives $6$ chocolates to each child, $15$ chocolates are left over. If she tries to give $9$ chocolates to each child, she can give $9$ each to all but two of the children; of those two, one gets only $3$ and the other gets none. How many chocolates does she have?",
  "MCQ",
  r"With $c$ children, the count is $6c + 15$ and also $9(c - 2) + 3 = 9c - 15$. So $3c = 30$, $c = 10$, and she has $6 \times 10 + 15 = 75$ chocolates (check: $8 \times 9 + 3 = 75$).",
  "Miscounting the children who get the full $9$.",
  "C09B-seating-leftover", "Two descriptions of the same total with a partial share to model carefully.",
  correct=r"$75$",
  distractors=[(r"$57$", "Takes $9(c - 1) + 3$, forgetting the child who gets none: $c = 7$."),
               (r"$81$", "Takes $9(c - 2)$, dropping the child who gets $3$: $c = 11$."),
               (r"$90$", "Finds $c = 10$ and then gives $9$ to every child.")],
  check=_c041, values=[75, 57, 81, 90], cognitive="Application")

# ---------------------------------------------------------------- 042
def _c042():
    p, r = symbols('p r')
    s = solve([Eq((r - 4)*(p + 3), r*p), Eq((r + 4)*(p - 2), r*p)], [p, r], dict=True)
    s = [t for t in s if t[p] > 0 and t[r] > 0][0]
    return s[p] * s[r]
q("C09-B-042", T, "Rows and seats per row under two rearrangements", "Difficult",
  "Multi-step word problem",
  r"The people in an auditorium are seated in rows, with the same number of people in every row and no empty seats. If $3$ more people sat in each row, $4$ fewer rows would be needed; if $2$ fewer people sat in each row, $4$ more rows would be needed. In each arrangement every row used is completely full. How many people are in the auditorium?",
  "TITA",
  r"Let there be $r$ rows of $p$. From $(r - 4)(p + 3) = rp$: $3r - 4p = 12$. From $(r + 4)(p - 2) = rp$: $4p - 2r = 8$. Adding, $r = 20$, then $p = 12$, so there are $240$ people (check: $16 \times 15 = 24 \times 10 = 240$).",
  "Reporting the number of rows or the number per row.",
  "C09B-rate-change-schedule", "Products expand to a linear system; the cancellation of $rp$ is the insight.",
  tita_answer=240, check=_c042,
  tita_traps=[(20, "Reports the number of rows."),
              (12, "Reports the number of people per row.")],
  cognitive="Analysis", exams=HARD)

# ---------------------------------------------------------------- 043
def _c043():
    for n in range(1, 2000):
        if n % 24 == 0 and n % 32 == 0 and n // 24 - n // 32 == 3:
            return n
q("C09-B-043", T, "Pages of a book from two reading rates and the days saved", "Easy",
  "Single-step computation",
  r"Meera planned to read a novel at $24$ pages per day. By reading $32$ pages per day instead, she finished it $3$ days earlier than planned. How many pages does the novel have?",
  "MCQ",
  r"If she planned $d$ days, $24d = 32(d - 3)$, so $8d = 96$ and $d = 12$. The novel has $24 \times 12 = 288$ pages (and $32 \times 9 = 288$).",
  "Multiplying the faster rate by the planned days, or the slower rate by the actual days.",
  "C09B-rate-change-schedule", "One equation; the trap is pairing the rate with the wrong number of days.",
  correct=r"$288$",
  distractors=[(r"$96$", "Reports $8d = 96$, or $32 \\times 3$, as the page count."),
               (r"$384$", "Multiplies the faster rate by the planned $12$ days."),
               (r"$216$", "Multiplies the slower rate by the actual $9$ days.")],
  check=_c043, values=[288, 96, 384, 216], cognitive="Application")

# ---------------------------------------------------------------- 044
def _c044():
    sols = set()
    for y in range(0, 120):
        for others in range(0, 400):
            # 5 members now total 120; youngest y, others total `others`
            if others + y != 120:
                continue
            if y >= 6:
                then = 120 - 5 * 6          # all five alive six years ago
            else:
                then = others - 4 * 6       # youngest not yet born
            if then == 92:
                sols.add(y)
    assert len(sols) == 1
    return sols.pop()
q("C09-B-044", T, "Sum of ages over six years reveals a recent birth", "Medium",
  "Conceptual/application",
  r"The present ages of the $5$ members of a family add up to $120$ years. Six years ago, the ages of the people who were members of the family at that time added up to $92$ years. Since then nobody has left the family, and at most one member has joined it, by birth. What is the present age of the youngest member, in years?",
  "TITA",
  r"If all five had been members six years ago, their ages then would total $120 - 5 \times 6 = 90$, not $92$. So the youngest was born within the last six years, and the other four then totalled $(120 - y) - 4 \times 6 = 96 - y$. Setting $96 - y = 92$ gives $y = 4$.",
  "Assuming all five members aged six years, or reading the mismatch $92 - 90 = 2$ as the age.",
  "C09B-age-sum-elapsed", "Two short steps: compare $92$ with $120 - 5 \\times 6 = 90$ to see that a member joined, then recount with only four members aging.",
  tita_answer=4, check=_c044,
  tita_traps=[(2, "Takes the mismatch $92 - 90$ as the youngest's age."),
              (28, "Takes $120 - 92 = 28$ as the youngest's age.")],
  cognitive="Analysis")

# ---------------------------------------------------------------- 045
def _c045():
    total, t = 98, 0
    members = 4
    while total < 158:
        t += 1
        total += members
        if t == 5:
            members = 5   # baby born exactly 5 years from now, age 0
    assert total == 158
    return t
q("C09-B-045", T, "Growth of a family's total age with a birth on the way", "Easy",
  "Multi-step word problem",
  r"The present ages of the $4$ members of a family add up to $98$ years. A baby will be born into the family exactly $5$ years from now, and nobody will leave the family. How many years from now will the ages of all the members add up to $158$ years?",
  "MCQ",
  r"For the next $5$ years the total grows by $4$ a year, reaching $98 + 20 = 118$ when the baby is born. After that it grows by $5$ a year, so it needs $\frac{158 - 118}{5} = 8$ more years. The answer is $5 + 8 = 13$ years.",
  "Using a single growth rate for the whole period.",
  "C09B-age-sum-elapsed", "Two growth rates for the total age; short arithmetic.",
  correct=r"$13$ years",
  distractors=[(r"$8$ years", "Counts only the years after the baby's birth."),
               (r"$15$ years", "Ignores the baby: $\\frac{158 - 98}{4} = 15$."),
               (r"$12$ years", "Uses $5$ members throughout: $\\frac{158 - 98}{5} = 12$.")],
  check=_c045, values=[13, 8, 15, 12], cognitive="Application")
