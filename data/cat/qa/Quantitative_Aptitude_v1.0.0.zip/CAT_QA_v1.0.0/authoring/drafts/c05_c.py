import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Averages puzzles"
TOUGH = ("CAT", "XAT")


def _feasible_distinct(k, total, lo, hi):
    """True if k distinct integers in [lo, hi] can sum to total."""
    if k == 0:
        return total == 0
    if hi - lo + 1 < k:
        return False
    mn = sum(range(lo, lo + k))
    mx = sum(range(hi - k + 1, hi + 1))
    return mn <= total <= mx


# 001
def _c001():
    n, avg = 6, 15
    S = n * avg
    best = None
    for L in range(S, 0, -1):
        if _feasible_distinct(n - 1, S - L, 1, L - 1):
            best = L
            break
    return best
q("C05-C-001", T, "Greatest possible value of the largest of six distinct positive integers with a given average", "Easy",
  "Casework/optimisation",
  r"A gift shop sells six items, each at a different price that is a whole number of rupees (at least Rs. $1$). The average price of the six items is Rs. $15$. What is the highest possible price, in rupees, of the costliest item?",
  "TITA",
  r"The six prices add up to $6 \times 15 = 90$. To make the costliest price as large as possible, the other five must be as small as possible while remaining different whole numbers, that is $1, 2, 3, 4, 5$, with sum $15$. So the costliest item can cost $90 - 15 = 75$ rupees.",
  "Ignoring that the five cheaper prices must all be different.",
  "C05C-max-largest-distinct", "One idea (pack the others at the bottom) with the distinctness trap.",
  tita_answer=75, check=_c001, values=[75],
  tita_traps=[(85, "Takes the other five prices as Rs. $1$ each, ignoring that the prices are all different: $90 - 5 = 85$."),
              (80, "Allows a price of Rs. $0$ and uses $0, 1, 2, 3, 4$: $90 - 10 = 80$.")],
  cognitive="Application")


# 002
def _c002():
    S = 7 * 20
    best = None
    for H in range(S, 8, -1):
        # lightest is 8, five middle distinct in [9, H-1]
        if _feasible_distinct(5, S - 8 - H, 9, H - 1):
            best = H
            break
    return best
q("C05-C-002", T, "Greatest possible largest member of seven distinct integers when the smallest is fixed", "Medium",
  "Casework/optimisation",
  r"Seven parcels have different weights, each a whole number of kilograms. Their average weight is $20$ kg and the lightest parcel weighs $8$ kg. What is the greatest possible weight of the heaviest parcel?",
  "MCQ",
  r"The total weight is $7 \times 20 = 140$ kg. Apart from the lightest ($8$ kg) and the heaviest, the five middle parcels must be different whole numbers greater than $8$, so they weigh at least $9 + 10 + 11 + 12 + 13 = 55$ kg. Hence the heaviest is at most $140 - 8 - 55 = 77$ kg, which is attained by $8, 9, 10, 11, 12, 13, 77$.",
  "Not using both constraints: distinct weights and a fixed lightest weight of 8 kg.",
  "C05C-max-largest-distinct", "Two constraints (distinctness and a fixed minimum) must both be applied while packing.",
  correct=r"$77$ kg",
  distractors=[(r"$92$ kg", "Ignores distinctness and takes the six non-heaviest parcels as $8$ kg each: $140 - 48 = 92$."),
               (r"$119$ kg", "Ignores the given lightest weight and packs the other six as $1, 2, \\ldots, 6$: $140 - 21 = 119$."),
               (r"$71$ kg", "Takes the six non-heaviest parcels as $9, 10, \\ldots, 14$, leaving out the $8$ kg parcel itself: $140 - 69 = 71$.")],
  check=_c002, values=[77, 92, 119, 71], cognitive="Application")


# 003
def _c003():
    total = 9 * 50
    low_sum = 4 * 30
    best = 0
    for combo in itertools.combinations(range(1, low_sum), 4):
        if sum(combo) != low_sum:
            continue
        m = max(combo)
        # top five distinct, all > m, sum total - low_sum; maximise the largest
        rest = total - low_sum
        others = sum(range(m + 1, m + 5))
        L = rest - others
        if L > m + 4:
            best = max(best, L)
    return best
q("C05-C-003", T, "Greatest possible largest of nine distinct integers given the overall average and the average of the four smallest", "Difficult",
  "Casework/optimisation",
  r"Nine sacks have different weights, each a whole number of kilograms. The average weight of all nine sacks is $50$ kg, and the average weight of the four lightest sacks is $30$ kg. What is the greatest possible weight, in kg, of the heaviest sack?",
  "TITA",
  r"The total is $450$ kg and the four lightest total $120$ kg, so the five heaviest total $330$ kg. To make the heaviest large, the other four of these five must be small, but each must exceed the fourth lightest sack. Four different whole numbers with sum $120$ have largest member at least $32$ (since $28 + 29 + 30 + 31 = 118 < 120$, while $27 + 30 + 31 + 32 = 120$ works). So the next four sacks weigh at least $33 + 34 + 35 + 36 = 138$ kg, and the heaviest is at most $330 - 138 = 192$ kg, attained by $27, 30, 31, 32, 33, 34, 35, 36, 192$.",
  "Treating the four lightest as all equal to 30, or forgetting that the heavier sacks must exceed the fourth lightest.",
  "C05C-max-largest-distinct", "Needs the non-obvious step of minimising the largest of the four lightest before packing the rest.",
  tita_answer=192, check=_c003, values=[192],
  tita_traps=[(200, "Takes the four lightest as $30$ kg each (not distinct), so the next four are $31$ to $34$: $330 - 130 = 200$."),
              (414, "Ignores the condition on the four lightest and packs the other eight as $1$ to $8$: $450 - 36 = 414$."),
              (196, "Takes the four lightest as $28, 29, 30, 31$ without checking that they total only $118$, so the next four are $32$ to $35$: $330 - 134 = 196$.")],
  exams=TOUGH, cognitive="Analysis")


# 004
def _c004():
    n, S = 6, 120
    for M in range(1, S):
        # other five counts are distinct whole numbers in [0, M-1]
        if _feasible_distinct(n - 1, S - M, 0, M - 1):
            return M
q("C05-C-004", T, "Least possible largest member of six distinct non-negative integers with a given average", "Medium",
  "Casework/optimisation",
  r"Six workers in a workshop each made a different whole number of toys in a day. The average number of toys made per worker was $20$. What is the least possible number of toys made by the most productive worker?",
  "MCQ",
  r"The total is $6 \times 20 = 120$. If the most productive worker made $M$ toys, the other five made at most $(M-1) + (M-2) + \cdots + (M-5)$, so $120 \le 6M - 15$, giving $M \ge 22.5$, that is $M \ge 23$. With $M = 23$ the counts $23, 22, 21, 20, 19, 15$ add up to $120$, so the least possible value is $23$.",
  "Assuming six consecutive integers centred on 20 must add up to 120, or rounding 22.5 down.",
  "C05C-extreme-distinct-packing", "Packing the counts just below the maximum gives a half-integer bound that must be rounded the right way.",
  correct=r"$23$",
  distractors=[(r"$22$", "Rounds the bound $M \\ge 22.5$ down, or takes $17, 18, \\ldots, 22$ without checking that their sum is only $117$."),
               (r"$20$", "Assumes the counts can all equal the average, ignoring that they are different."),
               (r"$25$", "Takes the counts as $20, 21, \\ldots, 25$, treating the average as the smallest count.")],
  check=_c004, values=[23, 22, 20, 25], cognitive="Analysis")


# 005
def _c005():
    S = 8 * 25
    best = None
    for s in range(1, 40):
        # s smallest, 40 largest, six others distinct in [s+1, 39]
        if _feasible_distinct(6, S - 40 - s, s + 1, 39):
            best = s
    return best
q("C05-C-005", T, "Greatest possible smallest member of eight distinct integers with fixed largest and average", "Medium",
  "Casework/optimisation",
  r"Eight students scored different whole-number marks in a quiz. The average of their marks is $25$ and the highest mark is $40$. What is the greatest possible value of the lowest mark? (Enter the mark as an integer.)",
  "TITA",
  r"The total is $8 \times 25 = 200$, so the other seven marks add up to $160$. If the lowest is $s$, the six marks between it and $40$ are at least $s+1, s+2, \ldots, s+6$, so $s + (6s + 21) \le 160$, giving $7s \le 139$ and $s \le 19$. With $s = 19$ the marks $19, 20, 21, 22, 23, 24, 31, 40$ add up to $200$, so the answer is $19$.",
  "Rounding 139/7 up, or not using the fixed highest mark.",
  "C05C-extreme-distinct-packing", "Reverse packing (others pushed down onto the smallest) with a fixed top value.",
  tita_answer=19, check=_c005, values=[19],
  tita_traps=[(20, "Rounds $\\frac{139}{7} \\approx 19.86$ up instead of down."),
              (21, "Ignores that the highest mark is fixed at $40$ and solves $8s + 28 \\le 200$, getting $s \\le 21.5$.")],
  cognitive="Analysis")


# 006
def _c006():
    S = 7 * 30
    best = 0
    for y in range(1, S):
        # second largest y, largest at least y+1, five smallest distinct in [1, y-1]
        rest = S - y
        # largest L >= y+1 and five others distinct in [1, y-1]
        for L in range(y + 1, rest + 1):
            if _feasible_distinct(5, rest - L, 1, y - 1):
                best = max(best, y)
                break
    return best
q("C05-C-006", T, "Greatest possible second-largest of seven distinct integers with a given average", "Medium",
  "Casework/optimisation",
  r"Seven donors each gave a different whole number of thousand rupees to a charity, every donor giving at least Rs. $1$ thousand. The average donation was Rs. $30$ thousand. What is the greatest possible donation, in thousand rupees, of the donor who gave the second-highest amount?",
  "MCQ",
  r"The total is $7 \times 30 = 210$ thousand. To push the second-highest amount $y$ up, the five smallest must be $1, 2, 3, 4, 5$ (sum $15$) and the highest must be as small as allowed, $y + 1$. Then $15 + y + (y + 1) = 210$, so $y = 97$. The donations $1, 2, 3, 4, 5, 97, 98$ confirm this.",
  "Reporting the largest donation, or rounding 97.5 up.",
  "C05C-max-second-largest", "Two-sided squeeze: the top donor must stay above the second while the rest are packed low.",
  correct=r"$97$",
  distractors=[(r"$98$", "Lets the top donor equal the second ($15 + 2y = 210$, so $y = 97.5$) and rounds up, or reports the highest donation in the extreme case."),
               (r"$189$", "Maximises the highest donation instead: $210 - (1 + 2 + \\cdots + 6) = 189$."),
               (r"$102$", "Ignores distinctness for the five smallest, taking them as $1$ each: $2y + 1 = 205$, so $y = 102$.")],
  check=_c006, values=[97, 98, 189, 102], cognitive="Analysis")


# 007
def _c007():
    n, rise = 25, Fraction(36, 5)
    found = [x for x in range(1, 10000) if Fraction(10 * x - x, n) == rise]
    assert len(found) == 1
    return found[0]
q("C05-C-007", T, "True value of an entry recorded with an extra zero, from the rise in the average", "Easy",
  "Inverse/parameter",
  r"A shop recorded the number of units it sold on each of $25$ days. While entering one day's figure, the clerk typed an extra zero at the end (so a sale of $x$ units was entered as $10x$ units). Because of this slip, the computed average was $7.2$ units more than the true average. How many units were actually sold on that day?",
  "TITA",
  r"Entering $10x$ instead of $x$ raises the total by $9x$, and the total rose by $25 \times 7.2 = 180$. So $9x = 180$ and $x = 20$ units (entered as $200$).",
  "Taking the error in the total as 10x instead of 10x minus x.",
  "C05C-correction-misrecorded", "One idea: the slip adds 9x to the total, matched to the rise in total.",
  tita_answer=20, check=_c007, values=[20],
  tita_traps=[(18, "Takes the error in the total as $10x$ instead of $9x$: $10x = 180$."),
              (200, "Reports the wrongly entered value $10x$ instead of the true sale."),
              (180, "Reports the rise in the total, $25 \\times 7.2$, as the day's sale.")],
  cognitive="Application")


# 008
def _c008():
    entries, avg = 21, 60
    S = entries * avg
    S -= 63            # duplicate entry removed
    S += 87 - 45       # wrong entry corrected
    return Fraction(S, entries - 1)
q("C05-C-008", T, "Correct average after removing a duplicate entry and fixing a wrong entry", "Medium",
  "Multi-step word problem",
  r"A teacher entered marks into a spreadsheet and found the average of the $21$ entries to be $60$. She then discovered two slips: one student's mark of $63$ had been entered twice, and a different student's mark of $87$ had been entered as $45$. What is the correct average mark of the students?",
  "MCQ",
  r"The entries total $21 \times 60 = 1260$. Deleting the duplicate removes $63$ and leaves $20$ students; fixing the wrong entry adds $87 - 45 = 42$. The correct total is $1260 - 63 + 42 = 1239$, so the correct average is $\frac{1239}{20} = 61.95$.",
  "Fixing only one of the two slips, or dividing by the wrong number of students.",
  "C05C-correction-misrecorded", "Two different kinds of correction, one of which changes the count.",
  correct=r"$61.95$",
  distractors=[(r"$59.85$", "Removes the duplicate but does not fix the wrong entry: $\\frac{1197}{20}$."),
               (r"$57.75$", "Applies the fix in the wrong direction: $\\frac{1260 - 63 - 42}{20} = \\frac{1155}{20}$."),
               (r"$65.10$", "Fixes the wrong entry and divides by $20$ but leaves the duplicate $63$ in the total: $\\frac{1302}{20}$.")],
  check=_c008, values=[Fraction(1239, 20), Fraction(1197, 20), Fraction(1155, 20), Fraction(1302, 20)],
  cognitive="Application")


# 009
def _c009():
    # simulate: n entries recorded (one parcel entered twice), then fix
    for n in range(2, 10000):
        rec_total = 48 * n
        true_total = rec_total - 72 + 98
        true_count = (n - 1) + 1
        if Fraction(true_total, true_count) == Fraction(97, 2):
            return true_count
q("C05-C-009", T, "Finding the number of items from the change in average after removing a duplicate entry and adding an omitted one", "Medium",
  "Inverse/parameter",
  r"A clerk entered the weights of some parcels into a register and found the average of the entries to be $48$ kg. It was later discovered that one parcel weighing $72$ kg had been entered twice, and that another parcel weighing $98$ kg had not been entered at all. After the extra entry was deleted and the missing parcel was entered, the average weight became $48.5$ kg. How many parcels are there in all?",
  "TITA",
  r"Let the register first have $n$ entries, with total $48n$. Deleting the repeated entry and adding the missing parcel leaves the number of entries at $n$ and changes the total to $48n - 72 + 98 = 48n + 26$. So $48n + 26 = 48.5n$, giving $0.5n = 26$ and $n = 52$. There are $52$ parcels in all.",
  "Changing the count for the omitted parcel without also removing the duplicate entry.",
  "C05C-correction-misrecorded", "One linear equation after two corrections, one of which offsets the change in count of the other.",
  tita_answer=52, check=_c009, values=[52],
  tita_traps=[(100, "Ignores the duplicate entry and only adds the missing parcel: $48n + 98 = 48.5(n + 1)$ gives $n = 99$, so $100$ parcels."),
              (53, "Solves $48n + 26 = 48.5n$ correctly but then adds $1$ for the missing parcel, not seeing that the deleted duplicate cancels it."),
              (51, "Solves $48n + 26 = 48.5n$ correctly but then subtracts $1$ for the duplicate entry, forgetting that the missing parcel was added.")],
  cognitive="Analysis")


# 010
def _c010():
    n, rise = 30, Fraction(6, 5)
    cnt = 0
    for true in range(10, 100):
        a, b = divmod(true, 10)
        rec = 10 * b + a
        if b == 0:
            continue  # recorded value would not be two-digit
        if Fraction(rec - true, n) == rise:
            cnt += 1
    return cnt
q("C05-C-010", T, "Counting possible true values when a two-digit entry was recorded with digits reversed", "Medium",
  "Casework/optimisation",
  r"While computing the average mark of $30$ students, a clerk entered one student's mark, a two-digit number, with its two digits interchanged, and the entered value was also a two-digit number. Because of this, the computed average was $1.2$ more than the correct average. How many values are possible for that student's correct mark?",
  "TITA",
  r"If the correct mark is $10a + b$, the entered value is $10b + a$, and the total went up by $9(b - a) = 30 \times 1.2 = 36$, so $b - a = 4$. The tens digit $a$ is at least $1$, so the pairs are $(1, 5), (2, 6), (3, 7), (4, 8), (5, 9)$, giving correct marks $15, 26, 37, 48, 59$: $5$ values.",
  "Counting the digit difference itself, or allowing 0 as the tens digit.",
  "C05C-digit-reversal-entry", "Combines the 9 times digit difference fact with a short count.",
  tita_answer=5, check=_c010, values=[5],
  tita_traps=[(4, "Reports the digit difference $b - a = 4$ instead of counting marks."),
              (6, "Also counts $04$, which is not a two-digit mark.")],
  cognitive="Application")


# 011
def _c011():
    n, S = 12, 12 * 84
    best = None
    for k in range(0, n + 1):
        # k students on 100, the other n - k each a whole number from 40 to 99
        rest = S - 100 * k
        if 40 * (n - k) <= rest <= 99 * (n - k):
            best = k
    return best
q("C05-C-011", T, "Greatest possible number of full scores given the average and a floor on every mark", "Easy",
  "Casework/optimisation",
  r"Twelve students took a test marked out of $100$, and every mark was a whole number. Every student scored at least $40$, and the average mark was $84$. What is the greatest possible number of students who scored full marks?",
  "TITA",
  r"The total is $12 \times 84 = 1008$. If $k$ students scored $100$, the other $12 - k$ scored at least $40$ each, so $100k + 40(12 - k) \le 1008$, giving $60k \le 528$ and $k \le 8.8$. So at most $8$ students scored full marks; for example eight scores of $100$ and four of $52$ total $1008$.",
  "Ignoring the floor of 40 for the other students, or rounding 8.8 up.",
  "C05C-threshold-count", "One extreme configuration and one inequality; the trap is rounding the bound.",
  tita_answer=8, check=_c011, values=[8],
  tita_traps=[(9, "Rounds the bound $k \\le 8.8$ up."),
              (10, "Ignores the floor of $40$ and lets the others score $0$: $100k \\le 1008$ gives $k \\le 10$.")],
  cognitive="Application")


# 012
def _c012():
    # n runs, distinct whole km, shortest 3, longest 25, average 9
    def ok(n):
        if n < 2:
            return False
        if n == 2:
            return 3 + 25 == 9 * n
        return _feasible_distinct(n - 2, 9 * n - 28, 4, 24)
    possible = [n for n in range(2, 30) if ok(n)]
    # sanity: explicit witness for the maximum
    assert sum([3, 4, 5, 6, 7, 8, 9, 10, 13, 25]) == 90
    return max(possible)
q("C05-C-012", T, "Greatest possible number of distinct integer values with fixed smallest, largest and average", "Difficult",
  "Casework/optimisation",
  r"Over a month, Harpreet went on several runs, each a different whole number of kilometres. Her shortest run was $3$ km, her longest run was $25$ km, and the average length of her runs was $9$ km. What is the greatest possible number of runs she went on?",
  "MCQ",
  r"With $n$ runs the total is $9n$, so the $n - 2$ runs other than the shortest and longest total $9n - 28$. They are different whole numbers from $4$ upwards, so they total at least $4 + 5 + \cdots + (n + 1) = \frac{(n - 2)(n + 5)}{2}$. Hence $(n - 2)(n + 5) \le 18n - 56$, that is $n^2 - 15n + 46 \le 0$, whose larger root is about $10.7$, so $n \le 10$. Ten runs work: $3, 4, 5, 6, 7, 8, 9, 10, 13, 25$ total $90$. The answer is $10$.",
  "Ignoring the fixed shortest run when packing the others, or rounding the root up.",
  "C05C-max-count-distinct", "The count itself is the unknown, so the packing bound becomes a quadratic inequality in n with both ends fixed, followed by a construction.",
  correct=r"$10$",
  distractors=[(r"$11$", "Rounds the root $10.7$ of $n^2 - 15n + 46 = 0$ up instead of down."),
               (r"$15$", "Ignores that the shortest run is $3$ km and packs the others from $1$: $25 + \\frac{(n - 1)n}{2} \\le 9n$ gives $n^2 - 19n + 50 \\le 0$, so $n \\le 15$."),
               (r"$5$", "Finds the least possible number of runs instead of the greatest.")],
  check=_c012, values=[10, 11, 15, 5], exams=TOUGH, cognitive="Analysis")


# 013
def _c013():
    m = symbols('m', positive=True)
    # Tue..Sat total minus Mon..Fri total = Sat - Mon
    sol = solve(Eq(Rational(7, 5) * m - m, 5 * 128 - 5 * 120), m)
    return Rational(7, 5) * sol[0]
q("C05-C-013", T, "Difference of end members from two sliding-window averages", "Easy",
  "Conceptual/application",
  r"A bakery's average daily sale from Monday to Friday of a week was $120$ loaves, and its average daily sale from Tuesday to Saturday of the same week was $128$ loaves. It sold $1.4$ times as many loaves on Saturday as on Monday. How many loaves did it sell on Saturday?",
  "MCQ",
  r"The two five-day windows share Tuesday to Friday, so Saturday minus Monday is $5 \times 128 - 5 \times 120 = 40$. If Monday's sale is $m$, then $1.4m - m = 40$, so $m = 100$ and Saturday's sale is $140$ loaves.",
  "Using the difference of the averages (8) as the difference of the two days.",
  "C05C-sliding-window", "One window-shift idea plus a simple ratio.",
  correct=r"$140$",
  distractors=[(r"$100$", "Reports Monday's sale."),
               (r"$28$", "Takes Saturday minus Monday as $128 - 120 = 8$, so $0.4m = 8$, $m = 20$ and Saturday is $28$."),
               (r"$40$", "Reports the difference between Saturday's and Monday's sales.")],
  check=_c013, values=[140, 100, 28, 40], cognitive="Understanding")


# 014
def _c014():
    d = symbols('d1:8')
    eqs = [Eq(sum(d[0:5]), 5 * 60), Eq(sum(d[1:6]), 5 * 62), Eq(sum(d[2:7]), 5 * 65), Eq(d[0], 50), Eq(d[1], 56)]
    sol = solve(eqs, [d[0], d[1], d[4], d[5], d[6]], dict=True)[0]
    val = sol[d[6]]
    assert not val.free_symbols  # day 7 is determined even though days 3 and 4 are not
    return val
q("C05-C-014", T, "End value from three consecutive five-day window averages", "Easy",
  "Conceptual/application",
  r"A factory recorded its output on seven consecutive days. The average output was $60$ units per day over days $1$ to $5$, $62$ units over days $2$ to $6$, and $65$ units over days $3$ to $7$. The output was $50$ units on day $1$ and $56$ units on day $2$. What was the output on day $7$?",
  "MCQ",
  r"The windows for days $2$ to $6$ and days $3$ to $7$ share days $3$ to $6$, so day $7$ minus day $2$ equals $5 \times 65 - 5 \times 62 = 15$. Hence day $7$ had $56 + 15 = 71$ units.",
  "Pairing day 7 with day 1 instead of day 2, or using the difference of averages without multiplying by 5.",
  "C05C-sliding-window", "Choosing the right pair of windows; a distracting extra given.",
  correct=r"$71$ units",
  distractors=[(r"$65$ units", "Pairs day $7$ with day $1$: $50 + 15 = 65$."),
               (r"$59$ units", "Uses the difference of the averages, $3$, instead of $5 \\times 3$: $56 + 3$."),
               (r"$66$ units", "Uses the first pair of windows, whose difference $10$ belongs to day $6$ minus day $1$: $56 + 10$.")],
  check=_c014, values=[71, 65, 59, 66], cognitive="Understanding")


# 015
def _c015():
    p, k, r = symbols('p k r')
    sol = solve([Eq(p + k, 60), Eq(k + r, 70), Eq(p + r, 80)], [p, k, r])
    return max(sol.values())
q("C05-C-015", T, "Finding individual values from averages of pairs", "Easy",
  "Multi-step word problem",
  r"The average age of Pooja and Kabir is $30$ years, the average age of Kabir and Rehana is $35$ years, and the average age of Pooja and Rehana is $40$ years. What is the age of the oldest of the three?",
  "MCQ",
  r"The pair sums are $60$, $70$ and $80$. Adding them counts each person twice, so the three ages total $\frac{210}{2} = 105$. Rehana is missing from the first pair, so she is $105 - 60 = 45$; the others are Pooja $35$ and Kabir $25$. The oldest is $45$ years.",
  "Reporting the largest pair average, or the overall average.",
  "C05C-leave-out-sums", "Two quick steps once the pair sums are added.",
  correct=r"$45$ years",
  distractors=[(r"$40$ years", "Reports the largest pair average as an individual age."),
               (r"$35$ years", "Reports the overall average $\\frac{105}{3}$ (which happens also to be Pooja's age)."),
               (r"$25$ years", "Subtracts the largest pair sum, getting the youngest age $105 - 80$.")],
  check=_c015, values=[45, 40, 35, 25], cognitive="Application")


# 016
def _c016():
    avgs = [29, 30, 32, 33, 36]
    a = symbols('a1:6')
    eqs = [Eq((sum(a) - a[i]) / 4, avgs[i]) for i in range(5)]
    sol = solve(eqs, a)
    vals = [sol[s] for s in a]
    return max(vals) - min(vals)
q("C05-C-016", T, "Difference of extreme members from leave-one-out averages", "Medium",
  "Conceptual/application",
  r"Five friends compare ages. Leaving out one friend at a time, the average age of the other four is found to be $29$, $30$, $32$, $33$ and $36$ years for the five choices. By how many years does the age of the oldest friend exceed that of the youngest?",
  "TITA",
  r"Leaving out the oldest gives the lowest average and leaving out the youngest gives the highest. If $T$ is the total, the oldest is $T - 4 \times 29$ and the youngest is $T - 4 \times 36$, so the difference is $4 \times (36 - 29) = 28$ years. (Indeed $T = 29 + 30 + 32 + 33 + 36 = 160$ and the ages are $44, 40, 32, 28, 16$.)",
  "Taking the difference of the averages without scaling by 4.",
  "C05C-leave-out-sums", "Requires matching the lowest leave-out average to the oldest person and scaling by the group size.",
  tita_answer=28, check=_c016, values=[28],
  tita_traps=[(7, "Takes the difference of the averages, $36 - 29$, without multiplying by $4$."),
              (44, "Reports the oldest friend's age instead of the difference.")],
  cognitive="Analysis")


# 017
def _c017():
    # maximise the class average: middle four <= min(top3), >= max(bottom3)
    best = Fraction(0)
    tops = [t for t in itertools.combinations_with_replacement(range(0, 51), 3) if sum(t) == 135]
    bots = [b for b in itertools.combinations_with_replacement(range(0, 51), 3) if sum(b) == 36]
    maxbot_min = min(max(b) for b in bots)
    for t in tops:
        mid_hi = min(t)
        if mid_hi < maxbot_min:
            continue
        best = max(best, Fraction(135 + 36 + 4 * mid_hi, 10))
    return best
q("C05-C-017", T, "Greatest possible class average given averages of the top and bottom groups and a mark cap", "Difficult",
  "Casework/optimisation",
  r"Ten students took a test marked out of $50$, and every mark was a whole number. The average of the three highest marks was $45$ and the average of the three lowest marks was $12$. What is the greatest possible average mark of all ten students?",
  "MCQ",
  r"The top three total $135$ and the bottom three total $36$. Each of the four remaining marks is at most the smallest of the top three marks, and that smallest mark is at most $45$ because the three average $45$. So the middle four total at most $4 \times 45 = 180$, attained when the top three are all $45$. The greatest class total is $135 + 180 + 36 = 351$, so the greatest average is $35.1$.",
  "Letting the middle marks reach the cap of 50, or using the smallest possible top mark instead of the largest possible.",
  "C05C-bounds-from-group-averages", "The binding constraint is the ordering (middle marks cannot exceed the top group), not the mark cap.",
  correct=r"$35.1$",
  distractors=[(r"$37.1$", "Lets the four middle marks be $50$ each, ignoring that they cannot exceed the three highest marks: $\\frac{135 + 200 + 36}{10}$."),
               (r"$31.1$", "Caps the middle marks at $35$, the least possible value of the smallest top mark when the other two are $50$: $\\frac{135 + 140 + 36}{10}$."),
               (r"$28.5$", "Sets the middle marks at the mean of $45$ and $12$, that is $28.5$, giving a class average of $28.5$.")],
  check=_c017, values=[Fraction(351, 10), Fraction(371, 10), Fraction(311, 10), Fraction(57, 2)],
  exams=TOUGH, cognitive="Analysis")


# 018
def _c018():
    S, cap = 6 * 72, 80
    for low in range(0, cap + 1):
        if S - low <= 5 * cap:
            return low
q("C05-C-018", T, "Least possible lowest value given the average and an upper cap", "Easy",
  "Casework/optimisation",
  r"Six students wrote a test marked out of $80$. Their average mark was $72$. What is the lowest possible mark that any one of them could have scored?",
  "MCQ",
  r"The total is $6 \times 72 = 432$. The lowest mark is smallest when the other five score the maximum of $80$ each, that is $400$. So the lowest possible mark is $432 - 400 = 32$.",
  "Assuming the marks must be spread symmetrically about the average.",
  "C05C-min-member-with-cap", "One idea (max out the others) with a symmetry trap.",
  correct=r"$32$",
  distractors=[(r"$64$", "Assumes the lowest mark is as far below $72$ as the cap is above it: $72 - 8$."),
               (r"$48$", "Reports the shortfall $6 \\times 80 - 432$ as the mark."),
               (r"$72$", "Assumes every student scored the average.")],
  check=_c018, values=[32, 64, 48, 72], cognitive="Application")


# 019
def _c019():
    n, S = 30, 30 * 70
    best = 0
    for k in range(0, n + 1):
        lo_total = 0 * k            # least these k can total
        hi_total = 39 * k + 100 * (n - k)
        if lo_total <= S <= hi_total:
            best = k
    return best
q("C05-C-019", T, "Greatest number of members below a threshold given the average and a cap", "Medium",
  "Casework/optimisation",
  r"In a class of $30$ students, a test was marked out of $100$ and every mark was a whole number. The class average was $70$. What is the greatest possible number of students who scored less than $40$?",
  "TITA",
  r"The total is $2100$. If $k$ students scored below $40$, each scored at most $39$ and the others at most $100$, so $39k + 100(30 - k) \ge 2100$, giving $61k \le 900$ and $k \le 14$. With $14$ students at $39$ and $16$ at $100$ the total is $2146$, and lowering some marks reaches exactly $2100$, so $14$ is possible.",
  "Treating 'less than 40' as 40, or putting the low scorers at 0.",
  "C05C-threshold-count", "Requires setting up the extreme configuration and an inequality, with a strict-threshold trap.",
  tita_answer=14, check=_c019, values=[14],
  tita_traps=[(15, "Lets the low scorers have $40$: $60k \\le 900$, or rounds $\\frac{900}{61} \\approx 14.75$ up."),
              (9, "Puts the low scorers at $0$ instead of $39$: $100(30 - k) \\ge 2100$.")],
  cognitive="Analysis")


# 020
def _c020():
    n, S = 25, 25 * 30
    best = 0
    for k in range(0, n + 1):
        # k students at >= 41, others at >= 10; all at most 50
        lo = 41 * k + 10 * (n - k)
        hi = 50 * k + 40 * (n - k)
        if lo <= S <= hi:
            best = k
    return best
q("C05-C-020", T, "Greatest number of members above a threshold given the average and a floor", "Medium",
  "Casework/optimisation",
  r"In a test marked out of $50$, each of $25$ candidates scored a whole number of marks, and every candidate scored at least $10$. The average mark was $30$. What is the greatest possible number of candidates who scored more than $40$?",
  "MCQ",
  r"The total is $750$. If $k$ candidates scored more than $40$, each scored at least $41$ and every other candidate at least $10$, so $41k + 10(25 - k) \le 750$, giving $31k \le 500$ and $k \le 16$. With $16$ candidates at $41$ ($656$) the other $9$ total $94$, for example eight at $10$ and one at $14$, so $16$ works.",
  "Ignoring the floor of 10 marks, or placing the high scorers at full marks.",
  "C05C-threshold-count", "Uses a floor rather than a cap, with a strict threshold.",
  correct=r"$16$",
  distractors=[(r"$17$", "Rounds $\\frac{500}{31} \\approx 16.1$ up."),
               (r"$18$", "Ignores the floor of $10$ marks for the others: $41k \\le 750$ gives $k \\le 18$."),
               (r"$12$", "Places the high scorers at full marks: $50k + 10(25 - k) \\le 750$ gives $k \\le 12$.")],
  check=_c020, values=[16, 17, 18, 12], cognitive="Analysis")


# 021
def _c021():
    n = symbols('n', positive=True)
    N = solve(Eq(72 * n + 96, 74 * (n + 1)), n)[0]
    total = 72 * N
    k = 0
    while Rational(total + 100 * k, N + k) < 80:
        k += 1
    return k
q("C05-C-021", T, "Least number of further maximum scores needed to lift an average", "Difficult",
  "Inverse/parameter",
  r"Riya has written some tests so far, each marked out of $100$, and her average is $72$. She works out that if she scores $96$ in her next test, her average will become $74$. Counting from now, what is the least number of further tests, each marked out of $100$, she must write so that her average over all her tests can reach $80$ or more?",
  "TITA",
  r"If she has written $n$ tests, $72n + 96 = 74(n + 1)$, so $2n = 22$, $n = 11$ and her total so far is $792$. Writing $k$ more tests with at most $100$ each, she needs $792 + 100k \ge 80(11 + k)$, that is $20k \ge 88$, so $k \ge 4.4$ and the least number is $5$.",
  "Rounding 4.4 down, or assuming she keeps scoring 96.",
  "C05C-further-tests-needed", "Two stages: recover the count from a hypothetical, then an inequality with the score cap.",
  tita_answer=5, check=_c021, values=[5],
  tita_traps=[(4, "Rounds $4.4$ down."),
              (6, "Assumes each further test scores $96$, as in the hypothetical: $16k \\ge 88$ gives $k \\ge 5.5$."),
              (9, "Takes the count as $22$ from $2n = 22$: $1584 + 100k \\ge 80(22 + k)$ gives $20k \\ge 176$, so $k \\ge 8.8$.")],
  exams=TOUGH, cognitive="Analysis")


# 022
def _c022():
    vals = set()
    for c in itertools.combinations(range(1, 20), 4):
        if sum(c) + 20 == 50:
            vals.add(max(c))
    return len(vals)
q("C05-C-022", T, "Counting possible values of the second-largest of distinct integers with fixed average and largest", "Difficult",
  "Casework/optimisation",
  r"Five friends have savings that are different whole numbers of thousand rupees, each at least Rs. $1$ thousand. Their average saving is Rs. $10$ thousand and the largest saving is Rs. $20$ thousand. How many different values are possible for the second-largest saving?",
  "TITA",
  r"The total is $50$, so the other four savings $a < b < c < d < 20$ add up to $30$. For a given $d$, the three smaller savings must add up to $30 - d$ and be different numbers below $d$, which needs $6 \le 30 - d \le (d - 1) + (d - 2) + (d - 3)$. The right inequality gives $d \ge 9$ (as in $6, 7, 8, 9$) and the cap gives $d \le 19$ (as in $1, 2, 8, 19$). Every value from $9$ to $19$ works, so there are $11$ values.",
  "Fence-post slip when counting from 9 to 19, or missing the lower bound for d.",
  "C05C-count-feasible-values", "Both ends of the range need separate arguments and the count is a fence-post trap.",
  tita_answer=11, check=_c022, values=[11],
  tita_traps=[(10, "Computes $19 - 9$ instead of $19 - 9 + 1$."),
              (12, "Takes the lower bound as $d \\ge 8$, rounding $\\frac{30}{4} = 7.5$ up to get $8$.")],
  exams=TOUGH, cognitive="Analysis")


# 023
def _c023():
    cnt = 0
    for t in itertools.combinations(range(1, 16), 3):
        if sum(t) == 36:
            cnt += 1
    return cnt
q("C05-C-023", T, "Counting sets of distinct integer ages with a given average and an upper limit", "Medium",
  "Casework/optimisation",
  r"Three siblings have different ages, each a whole number of years. Their average age is $12$ years, and the eldest is at most $15$ years old. How many different sets of ages are possible for the three siblings?",
  "MCQ",
  r"The ages $a < b < c$ add up to $36$ with $c \le 15$. If $c = 15$, then $a + b = 21$ with $b \le 14$: $(7, 14), (8, 13), (9, 12), (10, 11)$, which is $4$ sets. If $c = 14$, then $a + b = 22$ with $b \le 13$: $(9, 13), (10, 12)$, which is $2$ sets. If $c = 13$, then $a + b = 23$ with $b \le 12$: $(11, 12)$, which is $1$ set. For $c \le 12$ the total is at most $12 + 11 + 10 = 33 < 36$. So there are $7$ sets.",
  "Stopping after the case of the eldest being exactly 15, or allowing equal ages.",
  "C05C-count-feasible-values", "Short casework on the largest member with distinctness.",
  correct=r"$7$",
  distractors=[(r"$12$", "Allows two siblings to share an age (for example $11, 11, 14$ or $12, 12, 12$)."),
               (r"$3$", "Reads 'at most $15$' as 'less than $15$' and counts only $c = 14$ and $c = 13$."),
               (r"$4$", "Counts only the case where the eldest is exactly $15$.")],
  check=_c023, values=[7, 12, 3, 4], cognitive="Application")


# 024
def _c024():
    # simulate: average after k tests = 49 + k
    scores, total = [], 0
    for k in range(1, 11):
        new_total = k * (49 + k)
        scores.append(new_total - total)
        total = new_total
    return scores[9]
q("C05-C-024", T, "Score in a particular test from a steadily rising running average", "Medium",
  "Conceptual/application",
  r"Meera's average after her first test was $50$. After each later test her average went up by exactly $1$ mark, so it was $51$ after two tests, $52$ after three tests, and so on. What did she score in her tenth test?",
  "MCQ",
  r"After $k$ tests her average is $49 + k$, so her total is $k(49 + k)$. The tenth score is $10 \times 59 - 9 \times 58 = 590 - 522 = 68$. (In general the $k$th score is $2k + 48$: each score is $2$ more than the previous one.)",
  "Confusing the score in a test with the average after it.",
  "C05C-running-average", "Needs to convert running averages to totals and difference them.",
  correct=r"$68$",
  distractors=[(r"$59$", "Reports her average after ten tests."),
               (r"$70$", "Sees that scores rise by $2$ per test but adds $2 \\times 10$ to $50$ instead of $2 \\times 9$."),
               (r"$69$", "Takes the average after $k$ tests as $50 + k$: $10 \\times 60 - 9 \\times 59 = 69$.")],
  check=_c024, values=[68, 59, 70, 69], cognitive="Analysis")


# 025
def _c025():
    x = symbols('x')
    def tenth(xv):
        seq = [xv, 40]
        while len(seq) < 10:
            seq.append(sum(seq) / len(seq))
        return seq[9]
    return solve(Eq(tenth(x), 31), x)[0]
q("C05-C-025", T, "First term of a list in which each later term is the average of all earlier terms", "Easy",
  "Conceptual/application",
  r"In a list of numbers, the second number is $40$, and every number from the third onwards equals the average of all the numbers before it. The tenth number in the list is $31$. What is the first number?",
  "MCQ",
  r"The third number is the average of the first two. Adding a number equal to the current average does not change the average, so every later number equals that same value. Hence $\frac{x + 40}{2} = 31$, giving $x = 22$.",
  "Not seeing that the average stays fixed from the third term on.",
  "C05C-running-average", "One insight: appending the average leaves the average unchanged.",
  correct=r"$22$",
  distractors=[(r"$31$", "Assumes the list is constant from the start."),
               (r"$102$", "Writes the third term as $\\frac{x - 40}{2} = 31$."),
               (r"$9$", "Reports the drop $40 - 31$ from the second to the tenth number.")],
  check=_c025, values=[22, 31, 102, 9], cognitive="Understanding")


# 026
def _c026():
    total, top5 = 12 * 60, 5 * 70
    rest = total - top5
    best = None
    for L in range(0, rest + 1):
        # seven weights >= L summing to rest, each <= min of the top five (top five can all be 70)
        if 7 * L <= rest and rest <= 7 * 70:
            best = L
    return best
q("C05-C-026", T, "Greatest possible smallest member when the rest of the group must share a fixed total", "Medium",
  "Casework/optimisation",
  r"A group of $12$ people has an average weight of $60$ kg, and every weight is a whole number of kilograms. The average weight of the $5$ heaviest people is $70$ kg. What is the greatest possible weight of the lightest person?",
  "MCQ",
  r"The total is $720$ kg and the five heaviest total $350$ kg, so the other seven total $370$ kg. The lightest of these seven is at most their average, $\frac{370}{7} \approx 52.9$, so at most $52$ kg. Weights $52$ and six of $53$ kg total $370$, and the five heaviest can each weigh $70$ kg, so $52$ kg is possible.",
  "Rounding 52.9 up, or using the overall average.",
  "C05C-equalise-remaining", "Recognising that the remaining group should be made as equal as possible, with integer rounding.",
  correct=r"$52$ kg",
  distractors=[(r"$53$ kg", "Rounds $\\frac{370}{7} \\approx 52.9$ up."),
               (r"$60$ kg", "Takes the overall average as the greatest possible lightest weight."),
               (r"$50$ kg", "Mirrors the heavy group about the average: $60 - (70 - 60)$.")],
  check=_c026, values=[52, 53, 60, 50], cognitive="Application")


# 027
def _c027():
    n, S = 20, 20 * Fraction(36, 5)
    rest_total = 18 * Fraction(15, 2)
    for h in range(0, 11):
        l = S - rest_total - h
        if l.denominator != 1 or l < 0 or l > h:
            continue
        if 18 * l <= rest_total <= 18 * h:
            return h
q("C05-C-027", T, "Least possible highest value after dropping the extremes changes the average", "Difficult",
  "Casework/optimisation",
  r"Twenty judges each give a whole-number score from $0$ to $10$. The average of all $20$ scores is $7.2$. When one highest score and one lowest score are removed, the average of the remaining $18$ scores is $7.5$. What is the least possible value of the highest score?",
  "MCQ",
  r"The total is $144$ and the remaining $18$ total $135$, so the highest $h$ and the lowest $l$ add up to $9$. Every remaining score is at most $h$, so $18h \ge 135$, giving $h \ge 7.5$, that is $h \ge 8$. With $h = 8$ and $l = 1$, nine scores of $8$ and nine of $7$ total $135$, so the least possible highest score is $8$.",
  "Using only h + l = 9 with l at most h, or rounding 7.5 down.",
  "C05C-trimmed-average", "The binding constraint is hidden: the remaining scores cannot exceed the highest.",
  correct=r"$8$",
  distractors=[(r"$5$", "Uses only $h + l = 9$ with $l \\le h$, giving $h \\ge 4.5$."),
               (r"$7$", "Rounds the bound $h \\ge 7.5$ down."),
               (r"$9$", "Finds the greatest possible highest score ($l = 0$) instead of the least.")],
  check=_c027, values=[8, 5, 7, 9], exams=TOUGH, cognitive="Analysis")


# 028
def _c028():
    full, rest = 9 * Fraction(41, 5), 7 * Fraction(42, 5)
    # scan the lowest score l in steps of 0.1; highest h = full - rest - l
    for t in range(0, 101):
        l = Fraction(t, 10)
        h = full - rest - l
        if 0 <= l <= h <= 10 and 7 * l <= rest <= 7 * h:
            return l
q("C05-C-028", T, "Least possible lowest score from the full and trimmed averages with a score cap", "Easy",
  "Casework/optimisation",
  r"Nine judges scored a performance, each giving a score from $0$ to $10$ (decimals allowed). The average of the nine scores was $8.2$. When the highest and the lowest scores were dropped, the average of the remaining seven scores was $8.4$. What is the least possible value of the lowest score?",
  "MCQ",
  r"The nine scores total $9 \times 8.2 = 73.8$ and the seven remaining total $7 \times 8.4 = 58.8$, so the highest and lowest scores add up to $15$. The lowest is least when the highest is as large as allowed, $10$, giving $15 - 10 = 5.0$. This is possible: $5$, seven scores of $8.4$ and $10$.",
  "Assuming the two dropped scores average one of the given averages, or splitting their total equally.",
  "C05C-trimmed-average", "One idea: push the highest score to the cap after converting averages to totals.",
  correct=r"$5.0$",
  distractors=[(r"$6.4$", "Takes the highest as $10$ but assumes the two dropped scores average $8.2$: $16.4 - 10$."),
               (r"$7.5$", "Splits the dropped total of $15$ equally between the highest and the lowest."),
               (r"$6.6$", "Finds the greatest possible lowest score (highest equal to $8.4$) instead of the least: $15 - 8.4$.")],
  check=_c028, values=[5, Fraction(32, 5), Fraction(15, 2), Fraction(33, 5)],
  cognitive="Application")


# 029
def _c029():
    n = symbols('n', positive=True)
    N = solve(Eq(15 * n - 45, 13 * (n - 1)), n)[0]
    rest_total, k = 15 * N - 45, N - 1
    best = None
    for s in range(1, 45):
        # s smallest, k - 1 others distinct in [s+1, 44]
        if _feasible_distinct(int(k) - 1, int(rest_total) - s, s + 1, 44):
            best = s
    return best
q("C05-C-029", T, "Greatest possible smallest of distinct integers after finding the count from a removal", "Difficult",
  "Multi-step word problem",
  r"A box contains cards, each with a different positive integer written on it. The average of all the numbers is $15$. The largest number is $45$, and when that card is removed the average of the numbers on the remaining cards is $13$. What is the greatest possible value of the smallest number in the box?",
  "MCQ",
  r"With $n$ cards, $15n - 45 = 13(n - 1)$, so $n = 16$. The other $15$ cards total $240 - 45 = 195$. If the smallest is $s$, those $15$ cards total at least $s + (s + 1) + \cdots + (s + 14) = 15s + 105$, so $15s + 105 \le 195$ and $s \le 6$. The cards $6, 7, \ldots, 20$ total exactly $195$, so the answer is $6$.",
  "Ignoring distinctness, or including the card 45 in the consecutive packing.",
  "C05C-extreme-distinct-packing", "Two stages: recover the count from the removal, then pack distinct values.",
  correct=r"$6$",
  distractors=[(r"$13$", "Ignores that the numbers are different and sets all $15$ remaining cards equal: $\\frac{195}{15}$."),
               (r"$7$", "Packs all $16$ cards, including the $45$, as consecutive numbers from $s$: $16s + 120 \\le 240$."),
               (r"$4$", "Counts $16$ cards besides the $45$: $16s + 120 \\le 195$.")],
  check=_c029, values=[6, 13, 7, 4], exams=TOUGH, cognitive="Analysis")


# 030
def _c030():
    lo, hi = Fraction(7455, 1000), Fraction(7465, 1000)
    for n in range(1, 1000):
        for k in range(7 * n, 8 * n + 1):
            if lo <= Fraction(k, n) < hi:
                return n
q("C05-C-030", T, "Least number of whole-number values whose average rounds to a given two-decimal value", "Difficult",
  "Casework/optimisation",
  r"A teacher added up the marks of her students, each a whole number, and divided by the number of students. Rounded to two decimal places, the average came to $7.46$. What is the least possible number of students?",
  "MCQ",
  r"The average is $\frac{k}{n}$ for a whole number $k$, and it must lie in $[7.455, 7.465)$, so its fractional part lies in $[0.455, 0.465)$. Checking small $n$: $\frac{5}{11} = 0.4545\ldots$ is just below $0.455$, and no fraction with denominator up to $12$ falls in the interval, but $\frac{6}{13} = 0.4615\ldots$ does. So $13$ students with total $97$ give $7.4615\ldots$, which rounds to $7.46$, and the least number is $13$.",
  "Double rounding 7.4545 to 7.46, or taking 7.46 as exact.",
  "C05C-rounded-average-count", "Needs an interval for the true average and a search over small denominators.",
  correct=r"$13$",
  distractors=[(r"$11$", "Rounds $\\frac{82}{11} = 7.4545\\ldots$ in two steps, first to $7.455$ and then to $7.46$."),
               (r"$24$", "Finds a valid count, $\\frac{179}{24} = 7.458\\ldots$, but not the least one."),
               (r"$50$", "Treats $7.46$ as exact: $7.46 = \\frac{373}{50}$.")],
  check=_c030, values=[13, 11, 24, 50], exams=TOUGH, cognitive="Analysis")
