import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

T = "Integer-constrained linear problems"
HEAVY = ("CAT", "XAT")


def _pairs(a, b, N, lo=1):
    """All (x, y) with x, y >= lo and a x + b y = N."""
    return [(x, (N - a * x) // b) for x in range(lo, N // a + 1)
            if N - a * x >= lo * b and (N - a * x) % b == 0]


# ---------------------------------------------------------------- 001
def _c001():
    return len(_pairs(12, 20, 200))
q("C09-C-001", T, "Number of ways to spend an exact amount on two items, at least one of each", "Easy",
  "Casework/optimisation",
  r"Meera spends exactly Rs. $200$ on pens costing Rs. $12$ each and notebooks costing Rs. $20$ each. She buys at least one pen and at least one notebook. In how many different ways (different combinations of numbers of pens and notebooks) can she do this?",
  "TITA",
  r"Let $p$ pens and $n$ notebooks be bought: $12p + 20n = 200$, so $3p + 5n = 50$. Then $50 - 5n$ must be a multiple of $3$, which happens for $n = 1, 4, 7, 10$, giving $p = 15, 10, 5, 0$. Since $p \geq 1$, the case $n = 10$ is out, leaving $3$ ways.",
  "Counting the case with zero pens, which the stem rules out.",
  "C09C-count-exact-purchase", "One congruence step and a short list; the only trap is the zero case.",
  tita_answer=3, check=_c001, cognitive="Application",
  tita_traps=[(4, "Includes $n = 10$, $p = 0$ although at least one pen is required.")])

# ---------------------------------------------------------------- 002
def _c002():
    return len(_pairs(270, 40, 5000))
q("C09-C-002", T, "Counting purchases when one price is much larger than the other", "Medium",
  "Casework/optimisation",
  r"A school spends exactly Rs. $5{,}000$ on cricket bats costing Rs. $270$ each and cricket balls costing Rs. $40$ each, buying at least one bat and at least one ball. How many different combinations of numbers of bats and balls are possible?",
  "MCQ",
  r"With $x$ bats and $y$ balls, $270x + 40y = 5000$, that is $27x + 4y = 500$. So $27x \equiv 500 \equiv 0 \pmod 4$, which forces $x$ to be a multiple of $4$. With $x \geq 1$ and $27x < 500$: $x = 4, 8, 12, 16$ give $y = 98, 71, 44, 17$. Hence $4$ combinations.",
  "Requiring only that $500 - 27x$ be even (divisible by $2$) rather than divisible by $4$.",
  "C09C-count-exact-purchase", "Needs a mod 4 condition on the dearer item and the range check.",
  correct=r"$4$",
  distractors=[(r"$5$", "Also counts $x = 0$, $y = 125$, ignoring that at least one bat is bought."),
               (r"$9$", "Only demands that $500 - 27x$ be even, so takes every even $x$ from $2$ to $18$: nine values."),
               (r"$18$", "Counts every $x$ with $27x < 500$, that is $x = 1$ to $18$, without any divisibility check.")],
  check=_c002, values=[4, 5, 9, 18], cognitive="Application")

# ---------------------------------------------------------------- 003
def _c003():
    return sum(1 for a, b in _pairs(6, 15, 300) if a > b)
q("C09-C-003", T, "Counting pack combinations with an extra inequality between the counts", "Medium",
  "Casework/optimisation",
  r"Biscuits are sold only in packs of $6$ and packs of $15$. Fatima buys exactly $300$ biscuits, with at least one pack of each size, and she buys more packs of $6$ than packs of $15$. How many different combinations of numbers of packs are possible?",
  "TITA",
  r"With $a$ packs of $6$ and $b$ packs of $15$: $6a + 15b = 300$, so $2a + 5b = 100$ and $b$ must be even. Then $a = \frac{100 - 5b}{2}$. The condition $a > b$ gives $100 - 5b > 2b$, so $b < \frac{100}{7} \approx 14.3$. Hence $b = 2, 4, \ldots, 14$: $7$ combinations (for example $b = 14$ gives $a = 15$).",
  "Dropping the condition that the packs of $6$ outnumber the packs of $15$.",
  "C09C-count-exact-purchase", "Parity condition plus a linear inequality between the two unknowns.",
  tita_answer=7, check=_c003, cognitive="Application",
  tita_traps=[(9, "Ignores the condition $a > b$ and counts $b = 2, 4, \\ldots, 18$."),
              (8, "Also counts $b = 0$, $a = 50$, though at least one pack of $15$ is required.")])

# ---------------------------------------------------------------- 004
def _c004():
    sols = [(m, w, c) for m in range(1, 21) for w in range(1, 21) for c in range(1, 21)
            if m + w + c == 20 and 600 * m + 400 * w + 250 * c == 9000 and w > c]
    assert len(sols) == 1
    return sols[0][0]
q("C09-C-004", T, "Three wage rates, total headcount and total wage; an inequality fixes the solution", "Medium",
  "Multi-step word problem",
  r"A contractor employs $20$ workers for a day: men at Rs. $600$ each, women at Rs. $400$ each and children at Rs. $250$ each. At least one worker of each kind is employed, there are more women than children, and the total wage bill is exactly Rs. $9{,}000$. How many men are employed?",
  "MCQ",
  r"Let the numbers be $m, w, c$. Dividing the wage equation by $50$: $12m + 8w + 5c = 180$. Subtracting $5(m + w + c) = 100$ gives $7m + 3w = 80$, so $m \equiv 2 \pmod 3$. The values $m \equiv 2 \pmod 3$ with $w = \frac{80 - 7m}{3} \geq 0$ are $m = 2, 5, 8, 11$, giving $w = 22, 15, 8, 1$ and $c = -4, 0, 4, 8$. Only $(8, 8, 4)$ and $(11, 1, 8)$ have all counts positive, and only the first has more women than children. Hence $8$ men.",
  "Stopping at the first value that satisfies the congruence or ignoring one of the side conditions.",
  "C09C-three-types-unique", "Eliminating one variable, a congruence, then filtering cases by two conditions.",
  correct=r"$8$",
  distractors=[(r"$11$", "Takes $(11, 1, 8)$, which ignores the condition of more women than children."),
               (r"$5$", "Takes $(5, 15, 0)$, which has no children although at least one is required."),
               (r"$2$", "Takes the smallest $m$ with $m \\equiv 2 \\pmod 3$ without checking that $c = -4$ is impossible.")],
  check=_c004, values=[8, 11, 5, 2], cognitive="Analysis")

# ---------------------------------------------------------------- 005
def _c005():
    return sum(1 for x in range(1, 41) for y in range(1, 41) for z in range(1, 41)
               if x + y + z == 40 and x + 2 * y + 5 * z == 100)
q("C09-C-005", T, "Number of coin combinations with fixed count and fixed value, three denominations", "Medium",
  "Casework/optimisation",
  r"A bag holds exactly $40$ coins made up of Rs. $1$, Rs. $2$ and Rs. $5$ coins, with at least one coin of each kind. The total value of the coins is Rs. $100$. How many different combinations of numbers of the three coins are possible?",
  "MCQ",
  r"Let there be $x, y, z$ coins of Rs. $1$, $2$, $5$. Then $x + y + z = 40$ and $x + 2y + 5z = 100$. Subtracting, $y + 4z = 60$, so $y = 60 - 4z$ and $x = 40 - y - z = 3z - 20$. We need $x \geq 1$, so $z \geq 7$, and $y \geq 1$, so $z \leq 14$. Thus $z = 7, 8, \ldots, 14$: $8$ combinations.",
  "Getting the range of the Rs. $5$ coins wrong at one end.",
  "C09C-three-types-count", "Two equations in three unknowns reduce to a range for one variable.",
  correct=r"$8$",
  distractors=[(r"$9$", "Allows $z = 15$, which gives $y = 0$; at least one Rs. $2$ coin is required."),
               (r"$7$", "Counts the range $7 \\le z \\le 14$ as $14 - 7 = 7$ values."),
               (r"$15$", "Uses only $y = 60 - 4z \\ge 0$, taking $z = 1$ to $15$, and ignores $x = 3z - 20 \\ge 1$.")],
  check=_c005, values=[8, 9, 7, 15], cognitive="Application")

# ---------------------------------------------------------------- 006
def _c006():
    best = None
    for a in range(1, 61):
        for s in range(1, 61):
            c = 60 - a - s
            if c >= 1 and 160 * a + 100 * s + 50 * c == 6420:
                best = s if best is None else max(best, s)
    return best
q("C09-C-006", T, "Maximum of one count in a three-type system with total count and total value", "Difficult",
  "Casework/optimisation",
  r"A theatre sold exactly $60$ tickets for a show: adult tickets at Rs. $160$, senior citizen tickets at Rs. $100$ and child tickets at Rs. $50$. The total collection was Rs. $6{,}420$, and at least one ticket of each kind was sold. What is the maximum possible number of senior citizen tickets sold?",
  "MCQ",
  r"Let $a, s, c$ be the numbers of adult, senior and child tickets. Then $16a + 10s + 5c = 642$ and $a + s + c = 60$. Subtracting $5$ times the second, $11a + 5s = 342$, so $11a \equiv 342 \pmod 5$, that is $a \equiv 2 \pmod 5$, and $s = \frac{342 - 11a}{5}$. To make $s$ large make $a$ small: $a = 2$ gives $s = 64$ (more than $60$ tickets), $a = 7$ gives $s = 53$, $c = 0$ (not allowed), and $a = 12$ gives $s = 42$, $c = 6$. Hence the maximum is $42$.",
  "Maximising $s$ from $11a + 5s = 342$ alone and forgetting that the child count must stay positive.",
  "C09C-three-types-unique", "Elimination to $11a + 5s = 342$, a congruence modulo $5$ and two boundary cases that must be rejected before the answer appears.",
  correct=r"$42$",
  distractors=[(r"$53$", "Takes $a = 7$, $s = 53$, which leaves no child tickets although at least one was sold."),
               (r"$9$", "Lists the valid cases $a = 12, 17, 22, 27$ with $s = 42, 31, 20, 9$ correctly but reports the smallest senior count, $9$ at $a = 27$, instead of the largest."),
               (r"$58$", "Uses only the head count: $60$ minus one adult and one child, ignoring the collection.")],
  check=_c006, values=[42, 53, 9, 58], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 007
def _c007():
    n = 0
    for b in range(1, 81):
        for s in range(1, 81):
            f = 80 - b - s
            if f >= 1 and 250 * b + 150 * s + 100 * f == 13000 and s > f:
                n += 1
    return n
q("C09-C-007", T, "Counting three-type ticket sales with an inequality between two counts", "Difficult",
  "Casework/optimisation",
  r"A hall sold exactly $80$ tickets: balcony tickets at Rs. $250$, stall tickets at Rs. $150$ and front-row tickets at Rs. $100$, with at least one ticket of each kind. The total collection was Rs. $13{,}000$, and more stall tickets than front-row tickets were sold. How many different combinations of numbers of the three kinds of tickets are possible?",
  "TITA",
  r"Let $b, s, f$ be the numbers sold. Then $5b + 3s + 2f = 260$ and $b + s + f = 80$. Subtracting twice the second, $3b + s = 100$, so $s = 100 - 3b$ and $f = 80 - b - s = 2b - 20$. Conditions: $f \geq 1$ gives $b \geq 11$; $s > f$ gives $100 - 3b > 2b - 20$, so $b < 24$; and $s \geq 1$ is then automatic. So $b = 11, 12, \ldots, 23$: $13$ combinations.",
  "Missing one of the three side conditions when fixing the range of $b$.",
  "C09C-three-types-count", "Elimination followed by three simultaneous bounds on one variable.",
  tita_answer=13, check=_c007, cognitive="Analysis", exams=HEAVY,
  tita_traps=[(23, "Ignores the condition $s > f$ and counts $b = 11$ to $33$."),
              (14, "Allows $b = 10$, which gives $f = 0$ front-row tickets."),
              (12, "Counts $11 \\le b \\le 23$ as $23 - 11 = 12$ values.")])

# ---------------------------------------------------------------- 008
def _c008():
    return sum(1 for g in range(1, 40) for h in range(1, 70) if 2 * h + 4 * g == 68 and g >= 5 and h >= 5)
q("C09-C-008", T, "Possible numbers of one animal given the total number of legs and minimum counts", "Easy",
  "Casework/optimisation",
  r"A farm has only hens and goats, with at least $5$ of each. Together they have $68$ legs. How many different values are possible for the number of goats?",
  "TITA",
  r"With $h$ hens and $g$ goats, $2h + 4g = 68$, so $h = 34 - 2g$. Then $g \geq 5$, and $h \geq 5$ gives $2g \leq 29$, so $g \leq 14$. Hence $g = 5, 6, \ldots, 14$: $10$ values.",
  "Applying the minimum of $5$ to only one of the two animals.",
  "C09C-legs-range", "One equation, two simple bounds; the trap is the lower limit on hens.",
  tita_answer=10, check=_c008, cognitive="Application",
  tita_traps=[(12, "Uses $g \\ge 5$ but only $h \\ge 1$, giving $g = 5$ to $16$."),
              (16, "Ignores the minimum of $5$ and takes $g = 1$ to $16$.")])

# ---------------------------------------------------------------- 009
def _c009():
    best = 0
    for b in range(1, 31):
        for t in range(1, 31):
            c = 30 - b - t
            if c >= 1 and 2 * b + 3 * t + 4 * c == 86:
                best = max(best, b)
    return best
q("C09-C-009", T, "Maximum count of one vehicle type from vehicle and wheel totals", "Medium",
  "Casework/optimisation",
  r"A parking area holds exactly $30$ vehicles: bicycles ($2$ wheels), tricycles ($3$ wheels) and cars ($4$ wheels), with at least one vehicle of each type. The vehicles have $86$ wheels in all. What is the maximum possible number of bicycles?",
  "MCQ",
  r"Let the numbers be $b, t, c$. From $b + t + c = 30$ and $2b + 3t + 4c = 86$, subtracting twice the first gives $t + 2c = 26$, and then $b = 30 - t - c = 4 + c$. So $b$ is largest when $c$ is largest. Since $t = 26 - 2c \geq 1$, $c \leq 12$, giving $t = 2$ and $b = 16$.",
  "Allowing the number of tricycles to drop to zero, or finding the minimum instead.",
  "C09C-three-types-unique", "Recognising that $b$ rises with $c$ and finding the binding constraint.",
  correct=r"$16$",
  distractors=[(r"$17$", "Takes $c = 13$, which leaves $t = 0$ tricycles."),
               (r"$5$", "Takes $c = 1$, giving the minimum number of bicycles, not the maximum."),
               (r"$28$", "Uses only the vehicle count: $30$ minus one tricycle and one car.")],
  check=_c009, values=[16, 17, 5, 28], cognitive="Analysis")

# ---------------------------------------------------------------- 010
def _c010():
    return max(x for x, y in _pairs(15, 35, 500))
q("C09-C-010", T, "Maximum number of the cheaper item when the whole amount is spent", "Easy",
  "Casework/optimisation",
  r"Joseph spends exactly Rs. $500$ on apples at Rs. $15$ each and mangoes at Rs. $35$ each, buying at least one of each fruit. What is the maximum number of apples he could have bought?",
  "MCQ",
  r"With $x$ apples and $y$ mangoes, $15x + 35y = 500$, so $3x + 7y = 100$. For $x$ to be an integer, $100 - 7y$ must be divisible by $3$, so $y \equiv 1 \pmod 3$. The smallest such $y$ is $1$, giving $x = 31$.",
  "Ignoring the mango or the exactness of the amount.",
  "C09C-max-min-one-unknown", "One congruence and a choice of the smallest valid value.",
  correct=r"$31$",
  distractors=[(r"$33$", "Divides Rs. $500$ by Rs. $15$ and takes the whole part, ignoring the mango and the exact total."),
               (r"$24$", "Takes $y = 4$, the second value with $y \\equiv 1 \\pmod 3$."),
               (r"$3$", "Takes the largest $y = 13$, which gives the minimum number of apples.")],
  check=_c010, values=[31, 33, 24, 3], cognitive="Application")

# ---------------------------------------------------------------- 011
def _c011():
    return max(x for x, y in _pairs(45, 35, 1000))
q("C09-C-011", T, "Maximum number of the dearer item when the whole amount is spent", "Medium",
  "Casework/optimisation",
  r"Priya spends exactly Rs. $1{,}000$ on registers at Rs. $45$ each and files at Rs. $35$ each, buying at least one of each. What is the maximum number of registers she could have bought?",
  "TITA",
  r"With $x$ registers and $y$ files, $45x + 35y = 1000$, so $9x + 7y = 200$. Modulo $7$: $2x \equiv 4$, so $x \equiv 2 \pmod 7$. The candidates are $x = 2, 9, 16, 23$; $x = 23$ needs $9 \times 23 = 207 > 200$. For $x = 16$, $y = \frac{200 - 144}{7} = 8$. Hence the maximum is $16$.",
  "Dividing the money by the register price and ignoring the files and exactness.",
  "C09C-max-min-one-unknown", "Needs the congruence $x \\equiv 2 \\pmod 7$ and a boundary check.",
  tita_answer=16, check=_c011, cognitive="Application",
  tita_traps=[(22, "Takes the whole part of $1000 / 45$, ignoring the files and the exact total."),
              (2, "Reports the minimum number of registers.")])

# ---------------------------------------------------------------- 012
def _c012():
    s = [(x, y) for x, y in _pairs(17, 6, 250) if x >= 5 and y >= 5]
    assert len(s) == 1
    return sum(s[0])
q("C09-C-012", T, "A minimum count condition selects the unique purchase", "Medium",
  "Multi-step word problem",
  r"Ananya spends exactly Rs. $250$ on chocolates at Rs. $17$ each and candies at Rs. $6$ each, buying at least $5$ of each. How many items does she buy in all?",
  "MCQ",
  r"With $x$ chocolates and $y$ candies, $17x + 6y = 250$. Modulo $6$: $5x \equiv 4$, so $x \equiv 2 \pmod 6$. The candidates $x = 2, 8, 14$ give $y = 36, 19, 2$. Only $(8, 19)$ has at least $5$ of each, so she buys $27$ items.",
  "Picking a solution without applying the minimum of $5$ to both items.",
  "C09C-condition-selects-solution", "Three integer solutions; the stated minimum picks one.",
  correct=r"$27$",
  distractors=[(r"$38$", "Takes $(2, 36)$, which has only $2$ chocolates."),
               (r"$16$", "Takes $(14, 2)$, which has only $2$ candies."),
               (r"$41$", "Spends all the money on candies and takes the whole part of $250 / 6$.")],
  check=_c012, values=[27, 38, 16, 41], cognitive="Application")

# ---------------------------------------------------------------- 013
def _c013():
    s = _pairs(130, 80, 5000)
    d = min(abs(x - y) for x, y in s)
    best = [x + y for x, y in s if abs(x - y) == d]
    assert len(best) == 1
    return best[0]
q("C09-C-013", T, "Choosing the solution where the two counts are closest", "Difficult",
  "Casework/optimisation",
  r"A hostel warden spends exactly Rs. $5{,}000$ on bedsheets at Rs. $130$ each and pillow covers at Rs. $80$ each, buying at least one of each. She wants the number of bedsheets and the number of pillow covers to be as close to each other as possible. How many items does she buy in all?",
  "MCQ",
  r"With $x$ bedsheets and $y$ pillow covers, $13x + 8y = 500$. Modulo $8$: $5x \equiv 4$, so $x \equiv 4 \pmod 8$. The solutions are $(4, 56), (12, 43), (20, 30), (28, 17), (36, 4)$ with differences $52, 31, 10, 11, 32$. The smallest difference is $10$ at $(20, 30)$, so she buys $50$ items.",
  "Choosing the near miss with difference $11$ or estimating from equal counts.",
  "C09C-max-min-one-unknown", "Full list of five solutions with a close call between differences $10$ and $11$.",
  correct=r"$50$",
  distractors=[(r"$45$", "Takes $(28, 17)$, whose difference $11$ is a close but not the smallest gap."),
               (r"$48$", "Assumes equal counts, $21x = 500$, rounds $x \\approx 23.8$ to $24$ and doubles it, without checking the exact total."),
               (r"$40$", "Takes $(36, 4)$, the solution with the most bedsheets.")],
  check=_c013, values=[50, 45, 48, 40], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 014
def _c014():
    return min(x + y for x, y in _pairs(2, 5, 63, lo=0))
q("C09-C-014", T, "Fewest coins of two denominations to pay an exact odd amount", "Easy",
  "Casework/optimisation",
  r"Kabir has plenty of Rs. $2$ coins and Rs. $5$ coins and must pay exactly Rs. $63$ using only these coins, with no change returned. What is the least number of coins he can use?",
  "TITA",
  r"With $x$ coins of Rs. $2$ and $y$ of Rs. $5$, $2x + 5y = 63$. Since $63$ is odd, $y$ must be odd. To use few coins, use as many Rs. $5$ coins as possible: $y = 11$ gives $2x = 8$, $x = 4$ ($y = 12$ is even). So the least number is $11 + 4 = 15$.",
  "Rounding $63 / 5$ up without checking that the remainder can be paid in Rs. $2$ coins.",
  "C09C-min-total-items", "Parity of the larger coin count is the only idea.",
  tita_answer=15, check=_c014, cognitive="Application",
  tita_traps=[(13, "Rounds $63 / 5 = 12.6$ up to $13$ coins."),
              (12, "Takes $12$ coins of Rs. $5$ and ignores the remaining Rs. $3$.")])

# ---------------------------------------------------------------- 015
def _c015():
    return min(x + y for x, y in _pairs(7, 12, 250, lo=0))
q("C09-C-015", T, "Fewest boxes of two weights to make an exact load", "Medium",
  "Casework/optimisation",
  r"A courier loads boxes weighing $7$ kg and $12$ kg into a van so that the total load is exactly $250$ kg. What is the least number of boxes that can make up this load?",
  "TITA",
  r"With $x$ boxes of $7$ kg and $y$ of $12$ kg, $7x + 12y = 250$. Modulo $7$: $5y \equiv 5$, so $y \equiv 1 \pmod 7$, giving $y = 1, 8, 15$ and $x = 34, 22, 10$. The totals are $35, 30, 25$, so the least number of boxes is $25$.",
  "Dividing the load by the heavier box weight and rounding up.",
  "C09C-min-total-items", "Congruence modulo $7$ and comparison of three totals.",
  tita_answer=25, check=_c015, cognitive="Application",
  tita_traps=[(21, "Rounds $250 / 12 \\approx 20.8$ up to $21$, ignoring exactness."),
              (35, "Takes $y = 1$, the first solution, which gives the most boxes.")])

# ---------------------------------------------------------------- 016
def _c016():
    return len(set(x + y for x, y in _pairs(2, 3, 50)))
q("C09-C-016", T, "Number of possible values of the total count of strides", "Medium",
  "Conceptual/application",
  r"Ravi climbs a staircase of exactly $50$ steps using only strides of $2$ steps and strides of $3$ steps, and he uses each kind of stride at least once. How many different values are possible for the total number of strides he takes?",
  "MCQ",
  r"With $a$ two-step and $b$ three-step strides, $2a + 3b = 50$, so $b$ is even and $a = 25 - \frac{3b}{2}$. The total is $a + b = 25 - \frac{b}{2}$. With $b \geq 2$ and $a \geq 1$ (so $b \leq 16$), $b = 2, 4, \ldots, 16$ gives totals $24, 23, \ldots, 17$: $8$ values.",
  "Including the stride-free case or confusing the spread of the totals with their count.",
  "C09C-range-of-total", "Seeing that each solution changes the total by exactly one.",
  correct=r"$8$",
  distractors=[(r"$9$", "Also counts $b = 0$, $a = 25$, although three-step strides must be used."),
               (r"$7$", "Gives the difference $24 - 17$ instead of the number of values."),
               (r"$16$", "Counts every $b$ from $1$ to $16$, ignoring that $b$ must be even.")],
  check=_c016, values=[8, 9, 7, 16], cognitive="Understanding")

# ---------------------------------------------------------------- 017
def _c017():
    return len(set(a + b + c for a in range(1, 41) for b in range(1, 17) for c in range(1, 9)
                   if 2 * a + 5 * b + 10 * c == 80))
q("C09-C-017", T, "Distinct possible coin counts for an exact payment with three denominations", "Difficult",
  "Casework/optimisation",
  r"Sneha pays exactly Rs. $80$ using Rs. $2$, Rs. $5$ and Rs. $10$ coins, with at least one coin of each kind. How many different values are possible for the total number of coins she uses?",
  "TITA",
  r"With $a, b, c$ coins of Rs. $2$, $5$, $10$: $2a + 5b + 10c = 80$, so $b$ is even; write $b = 2k$. Then $a = 40 - 5k - 5c$ and the total is $a + b + c = 40 - (3k + 4c)$, with $k, c \geq 1$ and $k + c \leq 7$ (so that $a \geq 1$). The values of $3k + 4c$ are: $c = 1$: $7, 10, 13, 16, 19, 22$; $c = 2$: $11, 14, 17, 20, 23$; $c = 3$: $15, 18, 21, 24$; $c = 4$: $19, 22, 25$; $c = 5$: $23, 26$; $c = 6$: $27$. The distinct values are $7, 10, 11$ and every integer from $13$ to $27$, that is $18$ values, so $18$ totals are possible.",
  "Counting the $21$ ways of paying, or the whole range from $13$ to $33$, instead of the distinct totals.",
  "C09C-range-of-total", "Reduction to the values of $3k + 4c$ and careful handling of repeats and gaps.",
  tita_answer=18, check=_c017, cognitive="Analysis", exams=HEAVY,
  tita_traps=[(21, "Counts the $21$ ways of paying (equally, every integer from $13$ to $33$), though some totals repeat and some are missing."),
              (20, "Gives the difference $33 - 13$ between the largest and smallest totals.")])

# ---------------------------------------------------------------- 018
def _c018():
    ok = set()
    for x in range(0, 30):
        for y in range(0, 30):
            ok.add(5 * x + 8 * y)
    return max(n for n in range(1, 200) if n not in ok)
q("C09-C-018", T, "Largest quantity that cannot be bought with two pack sizes", "Medium",
  "Conceptual/application",
  r"A fair sells ride tickets only in packs of $5$ and packs of $8$. What is the largest number of tickets that cannot be bought exactly as a combination of these packs (using any number of each pack, including none)?",
  "TITA",
  r"Since $\gcd(5, 8) = 1$, every large number is reachable, and the largest unreachable one is $5 \times 8 - 5 - 8 = 27$. Check: $27 - 8y$ for $y = 0, 1, 2, 3$ gives $27, 19, 11, 3$, none a multiple of $5$; and $28 = 20 + 8$, $29 = 5 + 24$, $30 = 30$, $31 = 15 + 16$, $32 = 32$ are five consecutive reachable numbers, so everything above is reachable.",
  "Using the product of the pack sizes instead of the Frobenius number.",
  "C09C-unattainable-amounts", "Needs the idea of five consecutive reachable values or the formula $ab - a - b$.",
  tita_answer=27, check=_c018, cognitive="Understanding",
  tita_traps=[(40, "Uses the product $5 \\times 8$."), (39, "Uses $5 \\times 8 - 1$.")])

# ---------------------------------------------------------------- 019
def _c019():
    ok = set(4 * x + 9 * y for x in range(0, 30) for y in range(0, 15))
    return sum(1 for n in range(1, 100) if n not in ok)
q("C09-C-019", T, "Number of quantities that cannot be bought with two pack sizes", "Difficult",
  "Conceptual/application",
  r"Greeting cards are sold only in boxes of $4$ and boxes of $9$. For how many positive integers $n$ is it impossible to buy exactly $n$ cards using these boxes (any number of each box, including none)?",
  "MCQ",
  r"Since $\gcd(4, 9) = 1$, the numbers that cannot be formed are finite in number; there are $\frac{(4 - 1)(9 - 1)}{2} = 12$ of them. Listing them: $1, 2, 3, 5, 6, 7, 10, 11, 14, 15, 19, 23$. From $24$ onwards ($24, 25, 26, 27$ are all reachable) every number can be formed, so the count is $12$.",
  "Confusing the largest unreachable number with the count, or forgetting to halve.",
  "C09C-unattainable-amounts", "Needs the counting formula or a careful residue-by-residue listing.",
  correct=r"$12$",
  distractors=[(r"$23$", "Gives the largest unreachable number $4 \\times 9 - 4 - 9$ instead of how many there are."),
               (r"$24$", "Uses $(4 - 1)(9 - 1)$ and does not halve."),
               (r"$6$", "Checks only the numbers below $9$, finding $1, 2, 3, 5, 6, 7$.")],
  check=_c019, values=[12, 23, 24, 6], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 020
def _c020():
    opts = [47, 43, 46, 39]
    good = [n for n in opts if any((n - 7 * k) % 10 == 0 for k in range(0, n // 7 + 1))]
    assert len(good) == 1
    return good[0]
q("C09-C-020", T, "Which amount can be paid exactly with two note values", "Easy",
  "Conceptual/application",
  r"A shopkeeper accepts payment only in Rs. $7$ vouchers and Rs. $10$ notes and gives no change. Which of the following amounts can be paid exactly?",
  "MCQ",
  r"An amount $n$ is payable if $n - 7k$ is a multiple of $10$ for some $k \geq 0$ with $7k \leq n$. For Rs. $47$: $47 - 7 = 40$, so one voucher and four notes. For Rs. $43$ the needed $k$ is $9$ ($63 > 43$); for Rs. $46$ it is $8$ ($56 > 46$); for Rs. $39$ it is $7$ ($49 > 39$). So only Rs. $47$ works.",
  "Assuming an amount is payable because it is close to a multiple of $10$ or is even.",
  "C09C-unattainable-amounts", "Direct check of a few residues.",
  correct=r"Rs. $47$",
  distractors=[(r"Rs. $43$", "Looks like $40 + 3$; the student assumes the extra Rs. $3$ can be adjusted with vouchers, but $43 - 7k$ is never a multiple of $10$ for $7k \\le 43$."),
               (r"Rs. $46$", "Even, so the student pairs it with the Rs. $10$ notes; but $46 - 7k$ is never a multiple of $10$ for $7k \\le 46$."),
               (r"Rs. $39$", "Close to $40$; the student treats it as four notes less one rupee, but $39 - 7k$ is never a multiple of $10$ for $7k \\le 39$.")],
  check=_c020, values=[47, 43, 46, 39], cognitive="Understanding")

# ---------------------------------------------------------------- 021
def _c021():
    ok = set(9 * x + 15 * y for x in range(0, 20) for y in range(0, 12))
    return min(n for n in range(100, 200) if n in ok)
q("C09-C-021", T, "Smallest payable amount above a bill when the two values share a common factor", "Easy",
  "Conceptual/application",
  r"A canteen accepts only meal coupons worth Rs. $9$ and Rs. $15$ and gives no change. Arjun wants to pay an amount of at least Rs. $100$, as small as possible, using any number of each coupon. What amount does he pay?",
  "MCQ",
  r"Every payable amount is $9x + 15y = 3(3x + 5y)$, a multiple of $3$. The smallest multiple of $3$ that is at least $100$ is $102$, and $102 = 9 \times 3 + 15 \times 5$ is payable. So he pays Rs. $102$.",
  "Using only one kind of coupon, or assuming any amount is payable.",
  "C09C-gcd-feasibility", "The common factor $3$ settles it in one step.",
  correct=r"Rs. $102$",
  distractors=[(r"Rs. $105$", "Uses only Rs. $15$ coupons: $7 \\times 15$."),
               (r"Rs. $108$", "Uses only Rs. $9$ coupons: $12 \\times 9$."),
               (r"Rs. $100$", "Assumes any amount can be made from two coupon values, ignoring the common factor $3$.")],
  check=_c021, values=[102, 105, 108, 100], cognitive="Understanding")

# ---------------------------------------------------------------- 022
def _c022():
    opts = [2730, 2750, 2740, 3780]
    good = [n for n in opts if any(20 * (75 - y) + 50 * y == n for y in range(0, 76))]
    assert len(good) == 1
    return good[0]
q("C09-C-022", T, "Possible totals when the number of notes is fixed", "Medium",
  "Conceptual/application",
  r"A cash box contains exactly $75$ notes, each a Rs. $20$ note or a Rs. $50$ note. Which of the following could be the total amount in the box?",
  "MCQ",
  r"If $y$ notes are of Rs. $50$, the total is $20(75 - y) + 50y = 1500 + 30y$ with $0 \leq y \leq 75$. So the total is $1500$ plus a multiple of $30$, and at most $3750$. Rs. $2{,}730 = 1500 + 30 \times 41$ fits. Rs. $2{,}750$ and Rs. $2{,}740$ differ from $1500$ by $1250$ and $1240$, not multiples of $30$; Rs. $3{,}780$ needs $y = 76$.",
  "Checking only that the amount is a multiple of $10$ or of $50$, or ignoring the upper limit.",
  "C09C-fixed-count-totals", "Rewriting the total as $1500 + 30y$ is the key step.",
  correct=r"Rs. $2{,}730$",
  distractors=[(r"Rs. $2{,}750$", "A multiple of $50$, so it seems makeable; but it needs $30y = 1250$, which has no integer solution."),
               (r"Rs. $2{,}740$", "A multiple of $20$ and $10$, so it seems makeable; but it needs $30y = 1240$."),
               (r"Rs. $3{,}780$", "Has the right form $1500 + 30y$ but needs $y = 76$ notes of Rs. $50$, more than $75$.")],
  check=_c022, values=[2730, 2750, 2740, 3780], cognitive="Understanding")

# ---------------------------------------------------------------- 023
def _c023():
    return len(set(20 * x + 50 * y for x in range(10, 76) for y in range(10, 76) if x + y == 75))
q("C09-C-023", T, "Number of possible totals with a fixed number of notes and minimum counts", "Easy",
  "Single-step computation",
  r"A wallet holds exactly $75$ notes, each a Rs. $20$ or a Rs. $50$ note, with at least $10$ notes of each kind. How many different values are possible for the total amount in the wallet?",
  "MCQ",
  r"With $y$ notes of Rs. $50$, the total is $1500 + 30y$, which is different for each $y$. Since $y \geq 10$ and $75 - y \geq 10$, $y$ runs from $10$ to $65$, giving $65 - 10 + 1 = 56$ totals.",
  "Off-by-one in counting, or applying the minimum to one kind only.",
  "C09C-fixed-count-totals", "One observation (totals are distinct) and an inclusive count.",
  correct=r"$56$",
  distractors=[(r"$76$", "Ignores the minimum of $10$ and lets $y$ run from $0$ to $75$."),
               (r"$55$", "Counts $10 \\le y \\le 65$ as $65 - 10$ values."),
               (r"$66$", "Applies the minimum only to the Rs. $50$ notes, taking $y = 10$ to $75$.")],
  check=_c023, values=[56, 76, 55, 66], cognitive="Application")

# ---------------------------------------------------------------- 024
def _c024():
    return max(20 - c - w for c in range(21) for w in range(21 - c) if 4 * c - w == 47)
q("C09-C-024", T, "Marking scheme with negative marks: maximum unattempted questions for a given score", "Medium",
  "Casework/optimisation",
  r"A test has $20$ questions. Each correct answer earns $4$ marks, each wrong answer loses $1$ mark and an unattempted question earns $0$. Priya scored exactly $47$. What is the maximum number of questions she could have left unattempted?",
  "TITA",
  r"With $c$ correct and $w$ wrong, $4c - w = 47$, so $w = 4c - 47 \geq 0$ gives $c \geq 12$. The unattempted count is $20 - c - w = 67 - 5c \geq 0$, so $c \leq 13$. For $c = 12$: $w = 1$ and $7$ unattempted; for $c = 13$: $w = 5$ and $2$ unattempted. The maximum is $7$.",
  "Forgetting the wrong answers when counting unattempted questions.",
  "C09C-test-scoring", "Two bounds on the number correct, then a comparison.",
  tita_answer=7, check=_c024, cognitive="Application",
  tita_traps=[(8, "Takes $c = 12$ and computes $20 - 12$, forgetting the one wrong answer."),
              (2, "Takes $c = 13$, which gives the minimum unattempted count.")])

# ---------------------------------------------------------------- 025
def _c025():
    return len(set(4 * c - w for c in range(26) for w in range(26 - c)))
q("C09-C-025", T, "Number of distinct achievable scores under a negative marking scheme", "Difficult",
  "Casework/optimisation",
  r"A test has $25$ questions. Each correct answer earns $4$ marks, each wrong answer loses $1$ mark and an unattempted question earns $0$. How many different total scores (including negative scores) are possible?",
  "TITA",
  r"With $c$ correct, the score can be any integer from $4c - (25 - c) = 5c - 25$ up to $4c$. The overall range is $-25$ to $100$, that is $126$ integers. Near the top the ranges leave gaps: $c = 25$ gives only $100$; $c = 24$ gives $95$ to $96$; $c = 23$ gives $90$ to $92$; $c = 22$ gives $85$ to $88$; $c = 21$ gives $80$ to $84$, and from there down the ranges overlap. Missing: $97, 98, 99, 93, 94, 89$, six values. Hence $126 - 6 = 120$ scores.",
  "Assuming every integer between the lowest and highest score is achievable.",
  "C09C-test-scoring", "Needs the interval picture for each value of $c$ and a careful count of the gaps.",
  tita_answer=120, check=_c025, cognitive="Analysis", exams=HEAVY,
  tita_traps=[(126, "Counts every integer from $-25$ to $100$, missing the gaps near the top."),
              (95, "Counts only scores from $0$ to $100$ and then removes the six gaps, ignoring negative scores.")])

# ---------------------------------------------------------------- 026
def _c026():
    opts = [37, 36, 35, 30]
    bad = [s for s in opts if not any(4 * c - w == s for c in range(11) for w in range(11 - c))]
    assert len(bad) == 1
    return bad[0]
q("C09-C-026", T, "Identifying an impossible score under a negative marking scheme", "Easy",
  "Conceptual/application",
  r"A quiz has $10$ questions. Each correct answer earns $4$ marks, each wrong answer loses $1$ mark and an unattempted question earns $0$. Which of the following scores is impossible?",
  "MCQ",
  r"With $10$ correct the score is $40$. With $9$ correct, at most $1$ question is wrong, so the score is $36$ or $35$. With $8$ or fewer correct the score is at most $32$. So $37$ cannot occur, while $36 = 9 \times 4$, $35 = 36 - 1$ and $30 = 32 - 2$ (eight correct, two wrong) are possible.",
  "Assuming every score up to the maximum is reachable, or forgetting that wrong answers use up questions.",
  "C09C-test-scoring", "Checking the top few cases by number correct.",
  correct=r"$37$",
  distractors=[(r"$36$", "The student thinks $9$ correct must come with at least one wrong answer; but $9$ correct and $1$ unattempted gives $36$."),
               (r"$35$", "The student thinks scores ending in $5$ need an odd number of wrong answers that will not fit; but $9$ correct, $1$ wrong gives $35$."),
               (r"$30$", "The student checks only $7$ correct ($28$ marks at most) and concludes $30$ is out of reach; but $8$ correct and $2$ wrong gives $30$.")],
  check=_c026, values=[37, 36, 35, 30], cognitive="Understanding")

# ---------------------------------------------------------------- 027
def _c027():
    s = [(w, d, 15 - w - d) for w in range(16) for d in range(16 - w)
         if 3 * w + d == 30 and 15 - w - d <= 2]
    assert len(s) == 1
    return s[0][1]
q("C09-C-027", T, "League points: wins, draws and losses with a cap on losses", "Medium",
  "Multi-step word problem",
  r"In a league, a win earns $3$ points, a draw $1$ point and a loss $0$ points. A team played $15$ matches, lost at most $2$ of them, and finished with exactly $30$ points. How many of its matches were draws?",
  "MCQ",
  r"With $w$ wins and $d$ draws, $3w + d = 30$, so $d = 30 - 3w$ and the losses are $15 - w - d = 2w - 15$. Losses $\geq 0$ gives $w \geq 8$; losses $\leq 2$ gives $w \leq 8$. So $w = 8$, $d = 6$ and $1$ loss. Hence $6$ draws.",
  "Ignoring either the match total or the cap on losses.",
  "C09C-league-points", "Two bounds that squeeze the number of wins to one value.",
  correct=r"$6$",
  distractors=[(r"$9$", "Takes $w = 7$, $d = 9$, which needs $16$ matches; the $15$ match total is ignored."),
               (r"$3$", "Takes $w = 9$, $d = 3$, which means $3$ losses; the cap of $2$ losses is ignored."),
               (r"$0$", "Assumes the team won as many as possible: $w = 10$, $d = 0$, with $5$ losses.")],
  check=_c027, values=[6, 9, 3, 0], cognitive="Application")

# ---------------------------------------------------------------- 028
def _c028():
    return sum(1 for w in range(21) for d in range(21 - w) if 3 * w + d == 34)
q("C09-C-028", T, "Number of possible win-draw-loss records for a given points total", "Medium",
  "Casework/optimisation",
  r"In a league, a win earns $3$ points, a draw $1$ point and a loss $0$ points. A team played $20$ matches and finished with exactly $34$ points. How many different combinations of numbers of wins, draws and losses are possible?",
  "MCQ",
  r"With $w$ wins and $d$ draws, $d = 34 - 3w \geq 0$, so $w \leq 11$. The losses $20 - w - d = 2w - 14$ must be non-negative, so $w \geq 7$. Hence $w = 7, 8, 9, 10, 11$: $5$ combinations (from $7$ wins, $13$ draws, $0$ losses to $11$ wins, $1$ draw, $8$ losses).",
  "Forgetting the $20$ match limit or an off-by-one in the range of wins.",
  "C09C-league-points", "Two bounds on wins and an inclusive count.",
  correct=r"$5$",
  distractors=[(r"$12$", "Uses only $d = 34 - 3w \\ge 0$, so $w = 0$ to $11$, ignoring the $20$ match limit."),
               (r"$4$", "Counts $7 \\le w \\le 11$ as $11 - 7$ values."),
               (r"$7$", "Finds $7 \\le w \\le 11$ but reports the smallest number of wins instead of the number of combinations.")],
  check=_c028, values=[5, 12, 4, 7], cognitive="Application")

# ---------------------------------------------------------------- 029
def _c029():
    s = [(w, d, 18 - w - d) for w in range(19) for d in range(19 - w)
         if 3 * w + d == 31 and w > d > 18 - w - d]
    assert len(s) == 1
    return 18 - s[0][0]
q("C09-C-029", T, "League record fixed by an ordering of wins, draws and losses", "Difficult",
  "Casework/optimisation",
  r"In a league, a win earns $3$ points, a draw $1$ point and a loss $0$ points. A team played $18$ matches and scored exactly $31$ points. It won more matches than it drew, and drew more matches than it lost. In how many of its matches did the team not win?",
  "MCQ",
  r"With $w$ wins, $d = 31 - 3w$ draws and $\ell = 18 - w - d = 2w - 13$ losses. Non-negativity gives $7 \leq w \leq 10$. The cases are $(7, 10, 1)$, $(8, 7, 3)$, $(9, 4, 5)$, $(10, 1, 7)$. Only $(8, 7, 3)$ has $w > d > \ell$. So the team did not win $7 + 3 = 10$ matches.",
  "Applying only one half of the ordering, or reporting the draws alone.",
  "C09C-league-points", "Four cases to generate and a double inequality to test.",
  correct=r"$10$",
  distractors=[(r"$11$", "Takes $(7, 10, 1)$, which satisfies draws more than losses but not wins more than draws."),
               (r"$9$", "Takes $(9, 4, 5)$, which satisfies wins more than draws but not draws more than losses."),
               (r"$7$", "Finds $(8, 7, 3)$ but reports only the $7$ draws as the matches not won.")],
  check=_c029, values=[10, 11, 9, 7], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 030
def _c030():
    best = None
    for a in range(0, 40):
        for b in range(0, 40):
            if abs(14 * a - 9 * b) == 1:
                best = a + b if best is None else min(best, a + b)
    return best
q("C09-C-030", T, "Measuring a small quantity with weights on both pans", "Medium",
  "Conceptual/application",
  r"Sneha has a two-pan balance and plenty of $9$ g and $14$ g weights. She may place weights on either pan, together with the substance being weighed. What is the least number of weights she must place on the pans to weigh out exactly $1$ g of a powder in a single weighing?",
  "TITA",
  r"If $a$ weights of $14$ g and $b$ of $9$ g end up on opposite pans, then $14a - 9b = \pm 1$. For $14a - 9b = 1$: $14a \equiv 1 \pmod 9$, so $5a \equiv 1$, $a = 2$, $b = 3$ ($28 - 27 = 1$), using $5$ weights. For $9b - 14a = 1$ the smallest solution is $b = 11$, $a = 7$, using $18$ weights. So the least number is $5$: two $14$ g weights on one pan, three $9$ g weights and the powder on the other.",
  "Considering only one arrangement of the weights.",
  "C09C-difference-equation", "Recognising a difference equation and comparing both signs.",
  tita_answer=5, check=_c030, cognitive="Analysis",
  tita_traps=[(18, "Solves only $9b - 14a = 1$, getting $b = 11$, $a = 7$.")])

# ---------------------------------------------------------------- 031
def _c031():
    for a in range(1, 50):
        r = 10 * a - 23
        if r >= 0 and r % 3 == 0:
            return r // 3
q("C09-C-031", T, "Paying with notes and receiving change in coins of another value", "Easy",
  "Inverse/parameter",
  r"Harpreet must pay exactly Rs. $23$ at a stall. She has only Rs. $10$ notes, and the stall can give change only in Rs. $3$ coins. If she hands over as few notes as possible, how many Rs. $3$ coins does she receive as change?",
  "MCQ",
  r"She pays $10a$ and receives $3b$ back, so $10a - 3b = 23$. We need $10a \geq 23$ and $10a - 23$ divisible by $3$. $a = 3$ leaves $7$, $a = 4$ leaves $17$, $a = 5$ leaves $27 = 3 \times 9$. So she pays Rs. $50$ and receives $9$ coins.",
  "Handling the sign of the change or reporting a later solution.",
  "C09C-difference-equation", "A short trial over the number of notes.",
  correct=r"$9$",
  distractors=[(r"$5$", "Finds that she hands over $5$ notes (Rs. $50$) but reports the number of notes instead of the number of coins."),
               (r"$19$", "Uses $a = 8$, the next solution, which hands over more notes than needed."),
               (r"$14$", "Counts the $5$ notes and $9$ coins together.")],
  check=_c031, values=[9, 5, 19, 14], cognitive="Application")

# ---------------------------------------------------------------- 032
def _c032():
    best = None
    for a in range(0, 60):
        for b in range(0, 60):
            if 11 * a - 7 * b == 100:
                best = a + b if best is None else min(best, a + b)
    return best
q("C09-C-032", T, "Forward and backward moves of fixed lengths reaching an exact position", "Medium",
  "Inverse/parameter",
  r"A toy robot moves along a straight line. Each move is either $11$ cm forward or $7$ cm backward, in any order. After its last move it is exactly $100$ cm ahead of its starting point. What is the least number of moves it can have made?",
  "MCQ",
  r"With $a$ forward and $b$ backward moves, $11a - 7b = 100$. The total is $a + b = a + \frac{11a - 100}{7}$, which grows with $a$, so take the smallest valid $a$. Modulo $7$: $4a \equiv 2$, so $a \equiv 4 \pmod 7$, and $11a \geq 100$ needs $a \geq 10$. So $a = 11$, $b = \frac{121 - 100}{7} = 3$, and the least number of moves is $14$.",
  "Ignoring the backward moves or not taking the smallest valid solution.",
  "C09C-difference-equation", "Congruence plus a lower bound on the forward moves.",
  correct=r"$14$",
  distractors=[(r"$10$", "Rounds $100 / 11 \\approx 9.1$ up to $10$ forward moves, which overshoot to $110$ cm."),
               (r"$11$", "Counts only the $11$ forward moves and leaves out the $3$ backward ones."),
               (r"$32$", "Takes the next solution $a = 18$, $b = 14$.")],
  check=_c032, values=[14, 10, 11, 32], cognitive="Application")

# ---------------------------------------------------------------- 033
def _c033():
    return max(200 * x + 350 * y for x, y in _pairs(3, 5, 60))
q("C09-C-033", T, "Maximising profit over integer production plans that use all hours", "Medium",
  "Casework/optimisation",
  r"A workshop makes chairs and tables. A chair takes $3$ hours and earns a profit of Rs. $200$; a table takes $5$ hours and earns Rs. $350$. This week exactly $60$ hours must be used, and at least one chair and one table must be made. What is the maximum profit?",
  "MCQ",
  r"With $x$ chairs and $y$ tables, $3x + 5y = 60$, so $x$ is a multiple of $5$. With both positive: $(15, 3), (10, 6), (5, 9)$. The profits are Rs. $4{,}050$, $4{,}100$ and $4{,}150$; a table earns more per hour ($70$ against about $66.7$), so the most tables wins. The maximum is Rs. $4{,}150$.",
  "Dropping the condition of at least one chair, or maximising the number of items.",
  "C09C-maximise-linear-objective", "List the integer plans and compare profit per hour.",
  correct=r"Rs. $4{,}150$",
  distractors=[(r"Rs. $4{,}200$", "Makes $12$ tables and no chairs, ignoring that at least one chair is required."),
               (r"Rs. $4{,}050$", "Maximises the number of items, $15$ chairs and $3$ tables."),
               (r"Rs. $4{,}000$", "Makes $20$ chairs and no tables, ignoring that at least one table is required.")],
  check=_c033, values=[4150, 4200, 4050, 4000], cognitive="Application")

# ---------------------------------------------------------------- 034
def _c034():
    return max(500 * x + 400 * y for x in range(0, 20) for y in range(0, 20)
               if 5 * x + 3 * y <= 60 and 2 * x + 4 * y <= 36)
q("C09-C-034", T, "Integer production plan under two resource limits", "Difficult",
  "Casework/optimisation",
  r"A carpenter makes stools and benches. A stool needs $5$ hours of work and $2$ kg of wood and earns a profit of Rs. $500$; a bench needs $3$ hours and $4$ kg of wood and earns Rs. $400$. He has at most $60$ hours and at most $36$ kg of wood, and makes only whole items. What is the maximum profit he can earn?",
  "MCQ",
  r"With $x$ stools and $y$ benches: $5x + 3y \leq 60$, $2x + 4y \leq 36$; maximise $100(5x + 4y)$. For each $y$ take the largest $x$: $y = 0$: $x = 12$, $5x + 4y = 60$; $y = 1$: $x = 11$, $59$; $y = 2$: $x = 10$, $58$; $y = 3$: $x = 10$, $62$; $y = 4$: $x = 9$, $61$; $y = 5$: $x = 8$, $60$; $y = 6$: $x = 6$, $54$, and it keeps falling. The best is $62$ at $(10, 3)$, which uses $59$ hours and $32$ kg. Maximum profit Rs. $6{,}200$.",
  "Rounding the fractional corner point of the two limits instead of checking nearby integer plans.",
  "C09C-maximise-linear-objective", "The fractional optimum $(\\frac{66}{7}, \\frac{30}{7})$ misleads; integer plans must be scanned.",
  correct=r"Rs. $6{,}200$",
  distractors=[(r"Rs. $6{,}100$", "Solves the two limits as equations, gets $x = \\frac{66}{7}$, $y = \\frac{30}{7}$, and rounds both down to $(9, 4)$."),
               (r"Rs. $6{,}400$", "Evaluates the fractional corner point, Rs. $6{,}428.57$, and rounds the profit down to the nearest hundred."),
               (r"Rs. $6{,}000$", "Makes only stools, $12$ of them, because a stool earns more per item.")],
  check=_c034, values=[6200, 6100, 6400, 6000], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 035
def _c035():
    return min(90 * x + 240 * y for x, y in _pairs(1, 3, 10, lo=0))
q("C09-C-035", T, "Cheapest way to buy an exact quantity from two pack sizes", "Easy",
  "Casework/optimisation",
  r"Juice is sold in $1$-litre packs at Rs. $90$ each and $3$-litre packs at Rs. $240$ each. Fatima needs exactly $10$ litres. What is the least amount she must spend?",
  "MCQ",
  r"The $3$-litre pack costs Rs. $80$ per litre, cheaper than Rs. $90$, so use as many as possible. With $y$ large packs and $10 - 3y$ small ones, $y \leq 3$. For $y = 3$: $3 \times 240 + 1 \times 90 = 810$. So Rs. $810$.",
  "Treating the quantity as divisible or using the wrong pack mix.",
  "C09C-maximise-linear-objective", "One comparison of unit prices and the exact quantity.",
  correct=r"Rs. $810$",
  distractors=[(r"Rs. $800$", "Uses Rs. $80$ per litre for all $10$ litres, as if $\\frac{10}{3}$ large packs could be bought."),
               (r"Rs. $900$", "Buys ten $1$-litre packs."),
               (r"Rs. $840$", "Buys two large packs and four small ones.")],
  check=_c035, values=[810, 800, 900, 840], cognitive="Application")

# ---------------------------------------------------------------- 036
def _c036():
    s = [(p, n) for p, n in _pairs(13, 8, 300) if p < n < 2 * p]
    assert len(s) == 1
    return s[0][1]
q("C09-C-036", T, "Whole-rupee prices fixed by a price bound", "Medium",
  "Inverse/parameter",
  r"A pen and a notebook each cost a whole number of rupees. $13$ pens and $8$ notebooks together cost Rs. $300$. A notebook costs more than a pen but less than twice a pen. What is the price of a notebook?",
  "MCQ",
  r"With pen price $p$ and notebook price $n$: $13p + 8n = 300$. Modulo $8$: $5p \equiv 4$, so $p \equiv 4 \pmod 8$. The possible pairs are $(p, n) = (4, 31), (12, 18), (20, 5)$. Only $(12, 18)$ has $p < n < 2p$. So a notebook costs Rs. $18$.",
  "Applying only one half of the price bound or reporting the pen price.",
  "C09C-integer-prices", "Congruence for the price, then a two-sided bound.",
  correct=r"Rs. $18$",
  distractors=[(r"Rs. $31$", "Takes $(4, 31)$, which ignores that a notebook costs less than twice a pen."),
               (r"Rs. $5$", "Takes $(20, 5)$, which ignores that a notebook costs more than a pen."),
               (r"Rs. $12$", "Finds $(12, 18)$ but reports the pen price.")],
  check=_c036, values=[18, 31, 5, 12], cognitive="Application")

# ---------------------------------------------------------------- 037
def _c037():
    s = [(c, p) for c, p in _pairs(7, 4, 100) if c < p < 15]
    assert len(s) == 1
    return s[0][0]
q("C09-C-037", T, "Whole-rupee prices of cups and plates with simple bounds", "Easy",
  "Inverse/parameter",
  r"A cup and a plate each cost a whole number of rupees. $7$ cups and $4$ plates together cost Rs. $100$. A plate costs more than a cup but less than Rs. $15$. What is the price of a cup, in rupees?",
  "TITA",
  r"With cup price $c$ and plate price $p$: $7c + 4p = 100$, so $7c$ is a multiple of $4$ and $c$ is a multiple of $4$. The possible pairs are $(4, 18), (8, 11), (12, 4)$. Only $(8, 11)$ has $c < p < 15$. A cup costs Rs. $8$.",
  "Applying only one of the two price conditions, or reporting the plate price.",
  "C09C-integer-prices", "Three candidate pairs, two simple conditions.",
  tita_answer=8, check=_c037, cognitive="Application",
  tita_traps=[(4, "Takes $(4, 18)$, ignoring that a plate costs less than Rs. $15$."),
              (11, "Finds $(8, 11)$ but enters the plate price.")])

# ---------------------------------------------------------------- 038
def _c038():
    s = []
    for p, n in _pairs(11, 7, 250):
        if n > p and (140 - 4 * p) > 0 and (140 - 4 * p) % n == 0:
            s.append((140 - 4 * p) // n)
    assert len(s) == 1
    return s[0]
q("C09-C-038", T, "Two purchases with whole-number prices and counts", "Difficult",
  "Multi-step word problem",
  r"Pens and diaries each cost a whole number of rupees, and a diary costs more than a pen. Ravi bought $11$ pens and $7$ diaries for exactly Rs. $250$. Meera bought $4$ pens and some diaries for exactly Rs. $140$. How many diaries did Meera buy?",
  "MCQ",
  r"With pen price $p$ and diary price $n$: $11p + 7n = 250$. Modulo $7$: $4p \equiv 5$, so $p \equiv 3 \pmod 7$, giving $(p, n) = (3, 31), (10, 20), (17, 9)$. A diary costs more than a pen, which rules out $(17, 9)$. Meera spends $140 - 4p$ on diaries: for $p = 3$ that is $128$, not a multiple of $31$; for $p = 10$ it is $100 = 5 \times 20$. So she bought $5$ diaries.",
  "Using only one of the two integer conditions to fix the prices.",
  "C09C-integer-prices", "Two separate integrality conditions must be combined with a price inequality.",
  correct=r"$5$",
  distractors=[(r"$8$", "Uses $(17, 9)$: $72 / 9 = 8$, ignoring that a diary costs more than a pen."),
               (r"$4$", "Uses $(3, 31)$ and rounds $128 / 31 \\approx 4.1$ down to $4$."),
               (r"$10$", "Finds the right prices but reports the pen price, $10$.")],
  check=_c038, values=[5, 8, 4, 10], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 039
def _c039():
    return sum(1 for x in range(1, 10) for y in range(1, 15) if 15 * x + 10 * y <= 100)
q("C09-C-039", T, "Counting purchases within a budget (not necessarily spending all of it)", "Medium",
  "Casework/optimisation",
  r"Arjun has Rs. $100$. Chocolates cost Rs. $15$ each and biscuit packets cost Rs. $10$ each. He buys at least one of each and need not spend all his money. How many different combinations of numbers of chocolates and biscuit packets can he buy?",
  "TITA",
  r"With $x$ chocolates and $y$ packets, $15x + 10y \leq 100$, so $3x + 2y \leq 20$ and $y \leq \frac{20 - 3x}{2}$. For $x = 1, 2, 3, 4, 5, 6$ the largest $y$ is $8, 7, 5, 4, 2, 1$. Adding: $8 + 7 + 5 + 4 + 2 + 1 = 27$ combinations.",
  "Treating the budget as an exact amount, or allowing zero of an item.",
  "C09C-budget-count", "Counting lattice points column by column.",
  tita_answer=27, check=_c039, cognitive="Application",
  tita_traps=[(3, "Requires the whole Rs. $100$ to be spent: only $(2, 7), (4, 4), (6, 1)$."),
              (44, "Allows zero chocolates or zero packets, counting from $x = 0$ and $y = 0$.")])

# ---------------------------------------------------------------- 040
def _c040():
    return sum(1 for x in range(1, 20) for y in range(1, 20) if 250 <= 20 * x + 35 * y <= 300)
q("C09-C-040", T, "Counting purchases whose cost lies in a band", "Difficult",
  "Casework/optimisation",
  r"Meera buys notebooks at Rs. $20$ each and files at Rs. $35$ each, at least one of each. Her total bill is at least Rs. $250$ and at most Rs. $300$. How many different combinations of numbers of notebooks and files are possible?",
  "MCQ",
  r"With $x$ notebooks and $y$ files, $250 \leq 20x + 35y \leq 300$, so $50 \leq 4x + 7y \leq 60$. For each $y$, $4x$ lies in $[50 - 7y, 60 - 7y]$: $y = 1$: $x = 11, 12, 13$; $y = 2$: $9, 10, 11$; $y = 3$: $8, 9$; $y = 4$: $6, 7, 8$; $y = 5$: $4, 5, 6$; $y = 6$: $2, 3, 4$; $y = 7$: $1, 2$; $y = 8$: $1$. Total $3 + 3 + 2 + 3 + 3 + 3 + 2 + 1 = 20$.",
  "Misreading the band as strict, as an exact amount, or allowing zero of an item.",
  "C09C-budget-count", "Eight rows of interval counting with uneven row sizes.",
  correct=r"$20$",
  distractors=[(r"$24$", "Also counts $y = 0$ ($x = 13, 14, 15$) and $x = 0$ ($y = 8$)."),
               (r"$18$", "Reads at least Rs. $250$ as more than Rs. $250$ and drops the two bills of exactly Rs. $250$, $(9, 2)$ and $(2, 6)$."),
               (r"$2$", "Counts only bills of exactly Rs. $300$: $(8, 4)$ and $(1, 8)$.")],
  check=_c040, values=[20, 24, 18, 2], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 041
def _c041():
    return sum(1 for a in range(31) for b in range(7) for c in range(4) if a + 5 * b + 10 * c == 30)
q("C09-C-041", T, "Number of ways to give change with three coin values", "Medium",
  "Casework/optimisation",
  r"A vending machine must return exactly Rs. $30$ in change using Rs. $1$, Rs. $5$ and Rs. $10$ coins. Any coin value may be absent. In how many different ways (different combinations of numbers of coins) can it do this?",
  "MCQ",
  r"With $a, b, c$ coins of Rs. $1$, $5$, $10$: $a + 5b + 10c = 30$, and once $b$ and $c$ are chosen with $5b + 10c \leq 30$, the Rs. $1$ coins make up the rest. $c = 0$: $b = 0$ to $6$, $7$ ways. $c = 1$: $b = 0$ to $4$, $5$ ways. $c = 2$: $b = 0$ to $2$, $3$ ways. $c = 3$: $1$ way. Total $7 + 5 + 3 + 1 = 16$.",
  "Requiring every coin to appear or leaving out the case without Rs. $10$ coins.",
  "C09C-three-coin-count", "Casework on the largest coin, with the zero cases in every row.",
  correct=r"$16$",
  distractors=[(r"$9$", "Counts only the ways with at least one Rs. $10$ coin: $5 + 3 + 1$."),
               (r"$7$", "Counts only the ways without a Rs. $10$ coin, the case $c = 0$."),
               (r"$4$", "Requires at least one coin of every value: $(15, 1, 1), (10, 2, 1), (5, 3, 1), (5, 1, 2)$.")],
  check=_c041, values=[16, 9, 7, 4], cognitive="Application")

# ---------------------------------------------------------------- 042
def _c042():
    return sum(1 for x in range(1, 34) for y in range(1, 20) for z in range(1, 15) if 3 * x + 5 * y + 7 * z == 100)
q("C09-C-042", T, "Counting positive solutions of a three-variable linear equation in context", "Difficult",
  "Casework/optimisation",
  r"A stationery shop sells erasers at Rs. $3$, sharpeners at Rs. $5$ and rulers at Rs. $7$ each. Kabir spends exactly Rs. $100$ and buys at least one of each item. How many different combinations of numbers of the three items are possible?",
  "TITA",
  r"With $x, y, z$ of the three items, $3x + 5y = 100 - 7z$ with $x, y \geq 1$. For a target $m$, the solutions in $y$ form a run with step $3$. Going through $z = 1$ to $12$, $m = 93, 86, 79, 72, 65, 58, 51, 44, 37, 30, 23, 16$ and the numbers of positive solutions are $6, 6, 5, 4, 4, 4, 3, 3, 2, 1, 2, 1$ ($z = 13$ gives $m = 9$, no positive solution). For example $m = 93$: $y \equiv 0 \pmod 3$, $y = 3, \ldots, 18$, six values. The total is $6 + 6 + 5 + 4 + 4 + 4 + 3 + 3 + 2 + 1 + 2 + 1 = 41$.",
  "Allowing an item to be absent, or a slip in one of the rows.",
  "C09C-three-coin-count", "Twelve rows of residue counting; no shortcut avoids the casework.",
  tita_answer=41, check=_c042, cognitive="Analysis", exams=HEAVY,
  tita_traps=[(55, "Counts solutions with some items absent (non-negative counts).")])

# ---------------------------------------------------------------- 043
def _c043():
    for N in range(1, 500):
        if len(_pairs(4, 7, N)) == 3:
            return N
q("C09-C-043", T, "Smallest total for which there are exactly three ways to buy", "Difficult",
  "Inverse/parameter",
  r"Balloons are sold only in packs of $4$ and packs of $7$. Ananya wants to buy exactly $N$ balloons using at least one pack of each size. What is the smallest $N$ for which she has exactly $3$ different ways (different combinations of numbers of packs) to do this?",
  "TITA",
  r"If $(x, y)$ solves $4x + 7y = N$, the other solutions are $(x - 7t, y + 4t)$. Three positive solutions need $y$, $y + 4$, $y + 8$ with $x - 14 \geq 1$, so $N = 4x + 7y \geq 4 \times 15 + 7 \times 1 = 67$. And $N = 67$ works: $(15, 1), (8, 5), (1, 9)$. A fourth solution would need $x \geq 22$, so there are exactly $3$. Hence $N = 67$.",
  "Allowing zero packs of one size, or simply tripling $4 \\times 7$.",
  "C09C-solution-count-parameter", "Reversing the usual question: building the smallest total from the step pattern of solutions.",
  tita_answer=67, check=_c043, cognitive="Analysis", exams=HEAVY,
  tita_traps=[(56, "Allows zero packs: $(14, 0), (7, 4), (0, 8)$ for $N = 56$."),
              (84, "Takes $3 \\times 4 \\times 7$, assuming one new way every $28$ balloons starting from zero.")])

# ---------------------------------------------------------------- 044
def _c044():
    return max(N for N in range(1, 600) if len(_pairs(5, 8, N)) == 1)
q("C09-C-044", T, "Largest amount payable in exactly one way with at least one coin of each kind", "Difficult",
  "Inverse/parameter",
  r"Tokens worth $5$ points and $8$ points are used at a game stall. A prize must be paid with at least one token of each kind and exactly matching its point value. What is the largest point value that can be paid in exactly one way?",
  "MCQ",
  r"Solutions of $5x + 8y = N$ come in steps $(x - 8, y + 5)$. Let $y_0$ be the smallest positive $y$ that works; $y_0$ is one of $1, \ldots, 5$ and is fixed by $N \bmod 5$. A second way needs $y = y_0 + 5$ with $x \geq 1$, that is $N \geq 8(y_0 + 5) + 5 = 8y_0 + 45$. So $N$ has exactly one way when $8y_0 + 5 \leq N \leq 8y_0 + 44$. This is largest for $y_0 = 5$, which needs $N \equiv 0 \pmod 5$ and $N \leq 84$: $N = 80$, paid only as $(8, 5)$. Hence $80$.",
  "Using the non-negative version of the problem or the Frobenius number.",
  "C09C-solution-count-parameter", "Requires seeing how solutions shift by $(8, 5)$ and that $2 \\times 5 \\times 8$ is the cut-off.",
  correct=r"$80$",
  distractors=[(r"$67$", "Solves the version with zero tokens allowed, where the largest one-way value is $2 \\times 40 - 5 - 8 = 67$."),
               (r"$40$", "Takes $5 \\times 8$; but $40$ cannot be paid at all with at least one token of each kind."),
               (r"$27$", "Gives the largest value that cannot be paid with tokens, $5 \\times 8 - 5 - 8$.")],
  check=_c044, values=[80, 67, 40, 27], cognitive="Analysis", exams=HEAVY)

# ---------------------------------------------------------------- 045
def _c045():
    return max(x + y for x in range(1, 20) for y in range(1, 20) if 12 * x == 18 * y and 12 * x < 200)
q("C09-C-045", T, "Equal spending at two prices forces proportional whole-number counts", "Easy",
  "Conceptual/application",
  r"Arjun buys mangoes at Rs. $12$ each and Kabir buys oranges at Rs. $18$ each. Each buys at least one fruit, they spend exactly the same amount, and each spends less than Rs. $200$. What is the maximum total number of fruits the two of them can buy together?",
  "TITA",
  r"Equal spending means $12x = 18y$, so $2x = 3y$, $x = 3k$, $y = 2k$, and each spends $36k$. From $36k < 200$, $k \leq 5$. The total is $5k = 25$.",
  "Maximising each count separately without keeping the spending equal.",
  "C09C-equal-spend", "Equal spending gives counts in a fixed ratio; one bound.",
  tita_answer=25, check=_c045, cognitive="Application",
  tita_traps=[(27, "Takes $16$ mangoes (Rs. $192$) and $11$ oranges (Rs. $198$) separately, which are unequal amounts.")])

# ---------------------------------------------------------------- 046
def _c046():
    s = []
    for S in range(1, 1000):
        if S % 6 == 0 and S % 10 == 0 and S % 15 == 0:
            a, b, c = S // 6, S // 10, S // 15
            if a + b + c < 75 and a > 30:
                s.append(a - c)
    assert len(s) == 1
    return s[0]
q("C09-C-046", T, "Three people spend equal amounts at three prices; bounds fix the amount", "Medium",
  "Multi-step word problem",
  r"Kabir buys pens at Rs. $6$ each, Sneha buys diaries at Rs. $10$ each and Priya buys files at Rs. $15$ each. All three spend the same whole number of rupees and each buys at least one item. Together they buy fewer than $75$ items, and Kabir buys more than $30$ pens. How many more items does Kabir buy than Priya?",
  "MCQ",
  r"The common amount $S$ must be a multiple of $6$, $10$ and $15$, so $S = 30k$. Then Kabir, Sneha and Priya buy $5k$, $3k$, $2k$ items, $10k$ in all. Fewer than $75$ items gives $k \leq 7$; more than $30$ pens gives $k \geq 7$. So $k = 7$ and Kabir buys $35 - 14 = 21$ more than Priya.",
  "Using only one of the two bounds, or reporting Kabir's own count.",
  "C09C-equal-spend", "LCM step and two opposing bounds.",
  correct=r"$21$",
  distractors=[(r"$18$", "Takes $k = 6$, where Kabir buys exactly $30$ pens, not more than $30$."),
               (r"$24$", "Takes $k = 8$, which gives $80$ items, ignoring the limit of fewer than $75$."),
               (r"$35$", "Reports the number of pens Kabir buys.")],
  check=_c046, values=[21, 18, 24, 35], cognitive="Application", exams=HEAVY)

# ---------------------------------------------------------------- 047
def _c047():
    return max(x for x in range(1, 40) for y in range(1, 80) if 495 < 13 * x + 7 * y <= 500)
q("C09-C-047", T, "Maximum of one item when the leftover money must be small", "Medium",
  "Casework/optimisation",
  r"Harpreet has Rs. $500$. She buys pens at Rs. $13$ each and pencils at Rs. $7$ each, at least one of each, and is left with less than Rs. $5$. What is the maximum number of pens she could have bought?",
  "MCQ",
  r"The bill $13x + 7y$ must lie in $496$ to $500$. For $x = 38$, even one pencil gives $501$. For $x = 37$ ($481$), $7y$ must lie in $15$ to $19$: impossible. For $x = 36$ ($468$), $7y$ must lie in $28$ to $32$: $y = 4$ works, bill $496$. So the maximum is $36$.",
  "Ignoring the pencils, allowing exactly Rs. $5$ left, or insisting on spending all Rs. $500$.",
  "C09C-spend-band-max", "Working down from the top with a narrow window for the remainder.",
  correct=r"$36$",
  distractors=[(r"$38$", "Divides Rs. $500$ by Rs. $13$ and ignores the pencils."),
               (r"$37$", "Uses $37$ pens and $2$ pencils, leaving exactly Rs. $5$, which is not less than Rs. $5$."),
               (r"$32$", "Insists on spending exactly Rs. $500$: $13 \\times 32 + 7 \\times 12 = 500$.")],
  check=_c047, values=[36, 38, 37, 32], cognitive="Application")

# ---------------------------------------------------------------- 048
def _c048():
    s = _pairs(45, 12, 300)
    assert len(s) == 1
    return sum(s[0])
q("C09-C-048", T, "Filling buses and vans exactly", "Easy",
  "Multi-step word problem",
  r"$300$ students go on a trip in buses that seat $45$ and vans that seat $12$. Every vehicle used is completely full, and at least one bus and one van are used. How many vehicles are used in all?",
  "MCQ",
  r"With $b$ buses and $v$ vans, $45b + 12v = 300$, so $15b + 4v = 100$ and $b$ must be a multiple of $4$. With $b \geq 1$ and $45b < 300$, $b = 4$, giving $v = 10$. So $14$ vehicles.",
  "Using only one kind of vehicle or reporting just the vans.",
  "C09C-full-vehicles", "One divisibility condition gives a single case.",
  correct=r"$14$",
  distractors=[(r"$25$", "Uses only vans: $300 / 12 = 25$."),
               (r"$7$", "Rounds $300 / 45 \\approx 6.7$ up to $7$ buses."),
               (r"$10$", "Finds $b = 4$, $v = 10$ but reports only the vans.")],
  check=_c048, values=[14, 25, 7, 10], cognitive="Application")

# ---------------------------------------------------------------- 049
def _c049():
    return min(a + b for a, b in _pairs(18, 24, 600))
q("C09-C-049", T, "Fewest rows of two sizes to seat an exact number", "Easy",
  "Casework/optimisation",
  r"An auditorium has exactly $600$ seats arranged in rows of $18$ seats and rows of $24$ seats, with at least one row of each size. What is the least possible number of rows?",
  "MCQ",
  r"With $a$ rows of $18$ and $b$ of $24$: $18a + 24b = 600$, so $3a + 4b = 100$ and $a$ is a multiple of $4$. Fewest rows means as many long rows as possible, so the smallest $a = 4$ gives $b = 22$: $26$ rows.",
  "Ignoring the short rows, or finding the maximum instead.",
  "C09C-min-total-items", "One divisibility condition and the idea of maximising the larger rows.",
  correct=r"$26$",
  distractors=[(r"$25$", "Uses only rows of $24$: $600 / 24 = 25$."),
               (r"$33$", "Takes $a = 32$, $b = 1$, the largest number of rows."),
               (r"$34$", "Rounds $600 / 18 \\approx 33.3$ up, using only rows of $18$.")],
  check=_c049, values=[26, 25, 33, 34], cognitive="Application")

# ---------------------------------------------------------------- 050
def _c050():
    s = [(x, y) for x, y in _pairs(8, 5, 71) if y > x]
    assert len(s) == 1
    return sum(s[0])
q("C09-C-050", T, "Stamps of two values for an exact postage, with more of one kind", "Easy",
  "Multi-step word problem",
  r"Joseph pays exactly Rs. $71$ in postage using Rs. $8$ stamps and Rs. $5$ stamps, with at least one of each. He uses more Rs. $5$ stamps than Rs. $8$ stamps. How many stamps does he use in all?",
  "MCQ",
  r"With $x$ stamps of Rs. $8$ and $y$ of Rs. $5$: $8x + 5y = 71$. Modulo $5$: $3x \equiv 1$, so $x \equiv 2 \pmod 5$, giving $(2, 11)$ and $(7, 3)$. Only $(2, 11)$ has more Rs. $5$ stamps, so he uses $13$ stamps.",
  "Picking the other solution or estimating from one stamp value.",
  "C09C-condition-selects-solution", "Two solutions; the stated condition picks one.",
  correct=r"$13$",
  distractors=[(r"$10$", "Takes $(7, 3)$, which has more Rs. $8$ stamps."),
               (r"$15$", "Rounds $71 / 5 = 14.2$ up to $15$ Rs. $5$ stamps."),
               (r"$9$", "Rounds $71 / 8 \\approx 8.9$ up to $9$ Rs. $8$ stamps.")],
  check=_c050, values=[13, 10, 15, 9], cognitive="Application")
