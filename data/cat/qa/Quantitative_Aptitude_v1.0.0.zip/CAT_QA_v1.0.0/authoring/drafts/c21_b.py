import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qlib import *

from math import gcd as _g
from functools import reduce as _red


def _G(*xs):
    return _red(_g, xs)


def _L(*xs):
    return _red(lambda a, b: a * b // _g(a, b), xs)


T = "HCF and LCM"
ALL = EXAMS
CX = ("CAT", "XAT")

# ---------------------------------------------------------------- EASY (13)

def _c1():
    # lights blink every 12, 20, 45 s from 7:00 pm; count joint blinks in [0, 3600] s
    return sum(1 for t in range(0, 3601) if t % 12 == 0 and t % 20 == 0 and t % 45 == 0)
q("C21-B-001", T, "Counting simultaneous events in a closed time window using the LCM", "Easy",
  "Multi-step word problem",
  r"Three signal lights on a hill blink at regular intervals of $12$ seconds, $20$ seconds and $45$ seconds respectively. They blink together at exactly $7{:}00$ pm. How many times do all three blink together from $7{:}00$ pm to $8{:}00$ pm, counting both the blink at $7{:}00$ pm and any blink at exactly $8{:}00$ pm?",
  "TITA",
  r"They blink together every $\mathrm{LCM}(12, 20, 45) = 2^2 \times 3^2 \times 5 = 180$ seconds, that is every $3$ minutes. In $60$ minutes there are $\frac{60}{3} = 20$ gaps, so the joint blinks occur at $7{:}00$, $7{:}03$, ..., $8{:}00$ pm: $20 + 1 = 21$ times.",
  "Counting the gaps between joint blinks instead of the blinks themselves, which drops one end of the window.",
  "C21B-simultaneous-events-lcm", "One LCM followed by a fencepost count with both ends included.",
  tita_answer=21, check=_c1,
  tita_traps=[(20, "Divides $60$ by $3$ and does not add the blink at $7{:}00$ pm."),
              (19, "Excludes both the $7{:}00$ pm and the $8{:}00$ pm blinks.")],
  cognitive="Application", exams=ALL)


def _c2():
    # buses every 15, 18, 24 minutes, together at 6:10 am; minutes until next joint departure
    t = 1
    while not (t % 15 == 0 and t % 18 == 0 and t % 24 == 0):
        t += 1
    return 6 * 60 + 10 + t  # minutes after midnight
q("C21-B-002", T, "Next simultaneous departure of three bus routes", "Easy",
  "Single-step computation",
  r"From a city depot, buses on three routes leave every $15$ minutes, every $18$ minutes and every $24$ minutes respectively, round the clock. One bus of each route left together at $6{:}10$ am. At what time will buses of all three routes next leave the depot together?",
  "MCQ",
  r"The departures coincide every $\mathrm{LCM}(15, 18, 24)$ minutes. With $15 = 3 \times 5$, $18 = 2 \times 3^2$, $24 = 2^3 \times 3$, the LCM is $2^3 \times 3^2 \times 5 = 360$ minutes $= 6$ hours. So the next joint departure is at $6{:}10 + 6$ hours $= 12{:}10$ pm.",
  "Taking the LCM of only two of the three intervals, or using the HCF.",
  "C21B-simultaneous-events-lcm", "A single LCM of three numbers converted to clock time.",
  correct=r"$12{:}10$ pm",
  distractors=[(r"$7{:}40$ am", "Uses $\\mathrm{LCM}(15, 18) = 90$ minutes and ignores the $24$-minute route."),
               (r"$7{:}22$ am", "Uses $\\mathrm{LCM}(18, 24) = 72$ minutes and ignores the $15$-minute route."),
               (r"$6{:}13$ am", "Adds the HCF $3$ minutes, mixing up HCF and LCM.")],
  check=_c2, values=[12 * 60 + 10, 7 * 60 + 40, 7 * 60 + 22, 6 * 60 + 13], cognitive="Application", exams=ALL)


def _c3():
    rods = [168, 252, 378]
    best = max(d for d in range(1, 379) if all(r % d == 0 for r in rods))
    return sum(r // best for r in rods)
q("C21-B-003", T, "Fewest equal pieces from three rods (HCF, then count)", "Easy",
  "Multi-step word problem",
  r"A fabricator has three iron rods of lengths $168$ cm, $252$ cm and $378$ cm. He cuts all of them into pieces of the same length, using every centimetre of every rod, and wants the pieces to be as long as possible. How many pieces does he get in all?",
  "TITA",
  r"The piece length must divide all three lengths, and the longest such length is $\mathrm{HCF}(168, 252, 378)$. Since $168 = 2^3 \times 3 \times 7$, $252 = 2^2 \times 3^2 \times 7$ and $378 = 2 \times 3^3 \times 7$, the HCF is $2 \times 3 \times 7 = 42$ cm. The number of pieces is $\frac{168}{42} + \frac{252}{42} + \frac{378}{42} = 4 + 6 + 9 = 19$.",
  "Reporting the piece length (the HCF) when the question asks for the number of pieces.",
  "C21B-equal-groups-hcf", "Needs the HCF and then a division step; the trap is stopping at the HCF.",
  tita_answer=19, check=_c3,
  tita_traps=[(42, "Reports the length of each piece instead of the number of pieces."),
              (38, "Uses $21$ cm, a common factor that is not the highest: $8 + 12 + 18 = 38$.")],
  cognitive="Application", exams=ALL)


def _c4():
    x = symbols('x', positive=True, integer=True)
    other = solve(Eq(72 * x, 12 * 504), x)[0]
    assert _g(72, int(other)) == 12 and _L(72, int(other)) == 504
    return other
q("C21-B-004", T, "Other number from HCF, LCM and one number", "Easy",
  "Single-step computation",
  r"The HCF of two numbers is $12$ and their LCM is $504$. If one of the numbers is $72$, the other number is",
  "MCQ",
  r"For two numbers, product $=$ HCF $\times$ LCM. So the other number is $\frac{12 \times 504}{72} = \frac{6048}{72} = 84$. Check: $\mathrm{HCF}(72, 84) = 12$ and $\mathrm{LCM}(72, 84) = 504$.",
  "Dividing the LCM by the HCF or by the given number instead of using product = HCF x LCM.",
  "C21B-product-equals-hcf-times-lcm", "Direct use of one standard identity.",
  correct=r"$84$",
  distractors=[(r"$42$", "Computes LCM $\\div$ HCF $= 504 \\div 12$."),
               (r"$504$", "Takes the LCM itself as the other number."),
               (r"$864$", "Computes HCF $\\times$ given number $= 12 \\times 72$.")],
  check=_c4, values=[84, 42, 504, 864], cognitive="Recall", exams=ALL)


def _c5():
    n = 1000
    while not all(n % d == 3 for d in (6, 10, 14)):
        n += 1
    return n
q("C21-B-005", T, "Smallest four-digit number leaving a fixed remainder", "Easy",
  "Multi-step word problem",
  r"Meera packs a stock of soap bars into cartons. Whether she packs $6$, $10$ or $14$ bars to a carton, exactly $3$ bars are always left over. If the stock has at least $1{,}000$ bars, what is the smallest possible number of bars in it?",
  "MCQ",
  r"The stock is $3$ more than a common multiple of $6$, $10$ and $14$, that is $210k + 3$ since $\mathrm{LCM}(6, 10, 14) = 2 \times 3 \times 5 \times 7 = 210$. The smallest such number that is at least $1{,}000$ uses $k = 5$: $1050 + 3 = 1053$.",
  "Not adding the remainder, or using the product of the divisors as the LCM.",
  "C21B-lcm-plus-fixed-remainder", "One LCM and a short search for the right multiple.",
  correct=r"$1{,}053$",
  distractors=[(r"$1{,}050$", "Finds the right multiple of $210$ but does not add the $3$ left-over bars."),
               (r"$1{,}047$", "Subtracts the remainder $3$ from $1050$ rather than adding it."),
               (r"$1{,}683$", "Takes the product $6 \\times 10 \\times 14 = 840$ as the LCM and gets $2 \\times 840 + 3$.")],
  check=_c5, values=[1053, 1050, 1047, 1683], cognitive="Application", exams=ALL)


def _c6():
    L, W = 672, 432
    s = max(d for d in range(1, W + 1) if L % d == 0 and W % d == 0)
    return (L // s) * (W // s)
q("C21-B-006", T, "Number of largest square tiles for a rectangular floor", "Easy",
  "Multi-step word problem",
  r"The floor of a hall is a rectangle $6$ m $72$ cm long and $4$ m $32$ cm wide. It is to be covered completely with identical square tiles, without cutting any tile, using the largest tiles possible whose side is a whole number of centimetres. How many tiles are needed?",
  "TITA",
  r"The tile side is $\mathrm{HCF}(672, 432)$ cm. Since $672 = 2^5 \times 3 \times 7$ and $432 = 2^4 \times 3^3$, the HCF is $2^4 \times 3 = 48$ cm. Along the length there are $\frac{672}{48} = 14$ tiles and along the width $\frac{432}{48} = 9$, so $14 \times 9 = 126$ tiles are needed.",
  "Adding the tile counts along the two sides instead of multiplying, or reporting the tile side.",
  "C21B-square-tiles-hcf", "HCF of two lengths after a unit conversion, then a product.",
  tita_answer=126, check=_c6,
  tita_traps=[(48, "Reports the side of the tile in cm."),
              (23, "Adds $14 + 9$ instead of multiplying.")],
  cognitive="Application", exams=ALL)


def _c7():
    fr = [Rational(4, 9), Rational(10, 21), Rational(8, 15)]
    # smallest positive rational that is an integer multiple of each
    base = Rational(1, _L(*[f.q for f in fr]))
    k = 1
    while not all((k * base / f).is_integer for f in fr):
        k += 1
    return k * base
q("C21-B-007", T, "LCM of three fractions", "Easy",
  "Single-step computation",
  r"The LCM of the fractions $\frac{4}{9}$, $\frac{10}{21}$ and $\frac{8}{15}$ (the smallest positive number that is a whole-number multiple of each of them) is",
  "MCQ",
  r"For fractions in lowest terms, LCM $= \frac{\mathrm{LCM}\text{ of numerators}}{\mathrm{HCF}\text{ of denominators}} = \frac{\mathrm{LCM}(4, 10, 8)}{\mathrm{HCF}(9, 21, 15)} = \frac{40}{3}$. Check: $\frac{40}{3} \div \frac{4}{9} = 30$, $\frac{40}{3} \div \frac{10}{21} = 28$ and $\frac{40}{3} \div \frac{8}{15} = 25$, all whole numbers.",
  "Using the LCM of the denominators in the LCM formula, or computing the HCF of the fractions.",
  "C21B-hcf-lcm-of-fractions", "Direct use of the fraction LCM rule.",
  correct=r"$\frac{40}{3}$",
  distractors=[(r"$\frac{8}{63}$", "Divides the LCM of numerators by the LCM of denominators: $\\frac{40}{315}$."),
               (r"$\frac{2}{3}$", "Divides the HCF of numerators by the HCF of denominators."),
               (r"$\frac{2}{315}$", "Computes the HCF of the fractions, $\\frac{\\mathrm{HCF}(4, 10, 8)}{\\mathrm{LCM}(9, 21, 15)}$.")],
  check=_c7, values=[Rational(40, 3), Rational(8, 63), Rational(2, 3), Rational(2, 315)], cognitive="Recall", exams=ALL)


def _c8():
    return sum(1 for n in range(1, 1000) if _L(n, 24) == 120)
q("C21-B-008", T, "Counting integers with a prescribed LCM with a fixed number", "Medium",
  "Conceptual/application",
  r"How many positive integers $n$ satisfy $\mathrm{LCM}(n, 24) = 120$?",
  "MCQ",
  r"Here $120 = 2^3 \times 3 \times 5$ and $24 = 2^3 \times 3$. The integer $n$ must divide $120$ and must supply the factor $5$, since $24$ does not. The powers of $2$ and $3$ in $n$ are free, because $24$ already has $2^3$ and $3^1$: $4$ choices for the power of $2$ ($2^0$ to $2^3$) and $2$ for the power of $3$. So there are $4 \times 2 = 8$ values.",
  "Counting all divisors of 120, or fixing powers that are actually free.",
  "C21B-lcm-with-fixed-number", "Prime-power casework: decide which exponents are forced and which are free, then multiply the choices.",
  correct=r"$8$",
  distractors=[(r"$16$", "Counts every divisor of $120$, without requiring the factor $5$."),
               (r"$4$", "Counts only the choices for the power of $2$, fixing the power of $3$."),
               (r"$2$", "Counts only the choices for the power of $3$, fixing the power of $2$.")],
  check=_c8, values=[8, 16, 4, 2], cognitive="Understanding", exams=ALL)


def _c9():
    m = _L(16, 24, 36)
    return max(n for n in range(1000, 10000) if n % m == 0)
q("C21-B-009", T, "Largest four-digit common multiple", "Easy",
  "Single-step computation",
  r"Joseph is choosing a four-digit PIN for a puzzle box. The PIN, read as a number, must be divisible by each of $16$, $24$ and $36$, and he wants the largest such four-digit number. What PIN does he choose?",
  "TITA",
  r"A number divisible by $16$, $24$ and $36$ is a multiple of $\mathrm{LCM}(16, 24, 36) = 2^4 \times 3^2 = 144$. Dividing, $9999 = 144 \times 69 + 63$, so the largest four-digit multiple is $9999 - 63 = 9936$.",
  "Using the LCM of only two of the divisors.",
  "C21B-largest-n-digit-common-multiple", "One LCM and one division with remainder.",
  tita_answer=9936, check=_c9,
  tita_traps=[(9984, "Uses $\\mathrm{LCM}(16, 24) = 48$; $9984$ is not divisible by $36$."),
              (6912, "Takes $\\frac{16 \\times 24 \\times 36}{4} = 3456$ as the LCM and doubles it.")],
  cognitive="Application", exams=ALL)


def _c10():
    cand = [(12, 12), (15, 375), (16, 360), (21, 441)]
    bad = []
    for h, l in cand:
        ok = any(_g(a, b) == h and _L(a, b) == l for a in range(1, l + 1) if l % a == 0 for b in range(a, l + 1) if l % b == 0)
        if not ok:
            bad.append((h, l))
    assert len(bad) == 1
    return bad[0][1] * 1000 + bad[0][0]
q("C21-B-010", T, "Feasibility of a given HCF and LCM pair", "Easy",
  "Conceptual/application",
  r"Which of the following cannot be the HCF and the LCM, in that order, of some pair of positive integers?",
  "MCQ",
  r"The HCF of two numbers always divides their LCM. Here $360 \div 16 = 22.5$ is not a whole number, so HCF $16$ with LCM $360$ is impossible. Each other pair works: $12$ and $12$ (both numbers $12$), $15$ and $375$ (the numbers $15, 375$), $21$ and $441$ (the numbers $21, 441$).",
  "Believing the HCF and LCM must differ, or that LCM / HCF must split into two coprime factors both greater than 1.",
  "C21B-hcf-lcm-feasibility", "Single property check, with tempting but valid special cases.",
  correct=r"HCF $16$, LCM $360$",
  distractors=[(r"HCF $12$, LCM $12$", "Assumes the HCF and LCM of two numbers can never be equal; they are equal when the numbers are equal."),
               (r"HCF $15$, LCM $375$", "Sees $375 \\div 15 = 25 = 5^2$ cannot be split into two coprime parts greater than $1$ and overlooks the split $1 \\times 25$."),
               (r"HCF $21$, LCM $441$", "Notices $441 = 21^2$ and wrongly concludes the LCM cannot be a square of the HCF.")],
  check=_c10, values=[360016, 12012, 375015, 441021], cognitive="Understanding", exams=ALL)


def _c11():
    # gears 36 and 84 teeth; count revolutions of the 84-teeth gear until marks meet again
    t = 1
    while not (t % 36 == 0 and t % 84 == 0):
        t += 1
    return Fraction(t, 84)
q("C21-B-011", T, "Meshing gears returning to the starting contact", "Easy",
  "Conceptual/application",
  r"Two meshing gear wheels have $36$ teeth and $84$ teeth. A tooth on each wheel is marked, and at the start the two marked teeth are in contact. The wheels turn together without slipping. How many complete turns does the larger wheel make before the two marked teeth are first in contact again?",
  "MCQ",
  r"Each time one tooth of a wheel passes the contact point, so does one tooth of the other. The marks meet again after $\mathrm{LCM}(36, 84) = 252$ teeth have passed. The larger wheel then turns $\frac{252}{84} = 3$ times (and the smaller $\frac{252}{36} = 7$ times).",
  "Reporting the smaller wheel's turns, or dividing by the HCF.",
  "C21B-gears-lcm-of-teeth", "One LCM with a clear physical meaning.",
  correct=r"$3$",
  distractors=[(r"$7$", "Gives the number of turns of the smaller wheel."),
               (r"$12$", "Gives $\\mathrm{HCF}(36, 84) = 12$."),
               (r"$21$", "Divides the LCM $252$ by the HCF $12$.")],
  check=_c11, values=[3, 7, 12, 21], cognitive="Application", exams=ALL)


def _c12():
    b, gl = 336, 240
    best = None
    for size in range(1, 337):
        if b % size == 0 and gl % size == 0:
            rows = b // size + gl // size
            best = rows if best is None or rows < best else best
    return best
q("C21-B-012", T, "Minimum number of single-group rows of equal size", "Easy",
  "Multi-step word problem",
  r"For an assembly, $336$ boys and $240$ girls are to stand in rows. Every row must have the same number of students, and no row may contain both boys and girls. What is the least number of rows needed?",
  "MCQ",
  r"The row size must divide both $336$ and $240$; the fewest rows come from the largest row size, $\mathrm{HCF}(336, 240) = 48$. Then there are $\frac{336}{48} = 7$ rows of boys and $\frac{240}{48} = 5$ rows of girls, $12$ rows in all.",
  "Reporting the row size, or multiplying the two row counts.",
  "C21B-equal-groups-hcf", "HCF followed by a sum.",
  correct=r"$12$",
  distractors=[(r"$48$", "Reports the number of students in each row."),
               (r"$35$", "Multiplies the row counts $7 \\times 5$ instead of adding."),
               (r"$24$", "Uses $24$ as the HCF, a common factor that is not the highest, giving $14 + 10$.")],
  check=_c12, values=[12, 48, 35, 24], cognitive="Application", exams=ALL)


def _c13():
    for a in range(2, 1000, 2):
        if _L(a, a + 2) == 1104:
            return a + a + 2
q("C21-B-013", T, "Consecutive even numbers with a given LCM", "Easy",
  "Inverse/parameter",
  r"Two consecutive even numbers have LCM $1{,}104$. What is their sum?",
  "TITA",
  r"Write the numbers as $2k$ and $2k + 2$. Their HCF is $2$, because $k$ and $k + 1$ are coprime, so their LCM is $\frac{2k(2k+2)}{2} = 2k(k + 1)$. Then $k(k + 1) = 552 = 23 \times 24$, so $k = 23$ and the numbers are $46$ and $48$, with sum $94$.",
  "Treating the HCF of consecutive even numbers as 1, or stopping at k and k + 1.",
  "C21B-consecutive-numbers-lcm", "Uses the HCF of consecutive even numbers to reduce to one quadratic.",
  tita_answer=94, check=_c13,
  tita_traps=[(47, "Finds $k = 23$ and $k + 1 = 24$ and adds them, without doubling."),
              (552, "Stops at $k(k + 1) = 552$ and reports that value.")],
  cognitive="Application", exams=ALL)

# ---------------------------------------------------------------- MEDIUM (21)

def _c14():
    # P from 9:00 every 8 min, Q from 9:04 every 12 min; first common time (minutes after 9:00)
    P = {8 * k for k in range(100)}
    Q = {4 + 12 * k for k in range(100)}
    return 9 * 60 + min(P & Q)
q("C21-B-014", T, "First coincidence of two periodic events with staggered starts", "Medium",
  "Conceptual/application",
  r"A temple bell tolls every $8$ minutes, its first toll being at $9{:}00$ am. A second bell tolls every $12$ minutes, its first toll being at $9{:}04$ am. At what time do the two bells first toll together?",
  "MCQ",
  r"The first bell tolls at $8m$ minutes after $9{:}00$ and the second at $4 + 12n$ minutes. We need $8m = 4 + 12n$, that is $2m = 1 + 3n$, so $n$ is odd; the smallest is $n = 1$, giving $16$ minutes. Listing confirms it: $9{:}00, 9{:}08, 9{:}16$ and $9{:}04, 9{:}16$. They first toll together at $9{:}16$ am.",
  "Assuming the first common toll is one LCM after one of the start times.",
  "C21B-staggered-start-coincidence", "Staggered starts break the usual LCM-from-start method; needs a congruence or a list.",
  correct=r"$9{:}16$ am",
  distractors=[(r"$9{:}24$ am", "Adds $\\mathrm{LCM}(8, 12) = 24$ minutes to $9{:}00$ am, as if both started together."),
               (r"$9{:}28$ am", "Adds the LCM $24$ minutes to the second bell's start, $9{:}04$ am."),
               (r"$9{:}20$ am", "Adds the LCM to $9{:}00$ am and then subtracts the $4$-minute delay.")],
  check=_c14, values=[9 * 60 + 16, 9 * 60 + 24, 9 * 60 + 28, 9 * 60 + 20], cognitive="Analysis", exams=ALL)


def _c15():
    rolls = [84, 126, 210]
    lens = [d for d in range(1, 31) if all(r % d == 0 for r in rolls)]
    return min(sum(r // d for r in rolls) for d in lens)
q("C21-B-015", T, "Fewest equal pieces when the piece length is capped", "Medium",
  "Casework/optimisation",
  r"Three ribbon rolls are $84$ cm, $126$ cm and $210$ cm long. Sneha cuts all of them into pieces of equal length, a whole number of centimetres, using every centimetre of ribbon. No piece may be longer than $30$ cm. What is the least number of pieces she can get?",
  "MCQ",
  r"The piece length must be a common divisor of $84$, $126$ and $210$, that is a divisor of their HCF $42$: $1, 2, 3, 6, 7, 14, 21, 42$. Fewest pieces means the longest allowed length, and $42 > 30$, so the length is $21$ cm. The number of pieces is $\frac{84 + 126 + 210}{21} = \frac{420}{21} = 20$.",
  "Ignoring the cap, or dividing the total length by the cap without checking divisibility.",
  "C21B-capped-common-measure", "Adds a cap so the HCF itself is not allowed and a divisor of it must be chosen.",
  correct=r"$20$",
  distractors=[(r"$10$", "Uses the HCF $42$ cm and ignores the $30$ cm limit."),
               (r"$14$", "Divides the total $420$ cm by $30$ cm, though $30$ does not divide the rolls."),
               (r"$60$", "Uses $7$ cm, a common prime factor, rather than the largest allowed divisor.")],
  check=_c15, values=[20, 10, 14, 60], cognitive="Analysis", exams=ALL)


def _c16():
    return sum(1 for x in range(201, 300) if _G(120, 168, x) == 24)
q("C21-B-016", T, "Counting unknown quantities consistent with a given HCF", "Medium",
  "Inverse/parameter",
  r"A trader stocks three oils: $120$ litres, $168$ litres and $x$ litres, where $x$ is a whole number strictly between $200$ and $300$. The largest jar that can measure each of the three stocks exactly, in a whole number of jarfuls, has a capacity of exactly $24$ litres. How many values of $x$ are possible?",
  "TITA",
  r"Since $\mathrm{HCF}(120, 168) = 24$, the HCF of all three is $\mathrm{HCF}(24, x)$, which equals $24$ exactly when $x$ is a multiple of $24$. The multiples of $24$ strictly between $200$ and $300$ are $216, 240, 264, 288$: $4$ values.",
  "Adding extra conditions that are not needed, such as requiring x / 24 to be coprime to 5 and 7.",
  "C21B-unknown-quantity-given-hcf", "Reverses the usual HCF problem; needs the reduction HCF(120, 168, x) = HCF(24, x).",
  tita_answer=4, check=_c16,
  tita_traps=[(3, "Excludes $240$, wrongly requiring $\\frac{x}{24}$ to be coprime to $\\frac{120}{24} = 5$."),
              (8, "Counts multiples of $12$ strictly between $200$ and $300$.")],
  cognitive="Analysis", exams=ALL)


def _c17():
    s, n = 48, 120
    L = 720
    W = symbols('W', positive=True)
    w = solve(Eq((L / s) * (W / s), n), W)[0]
    assert _G(L, int(w)) == s
    return w
q("C21-B-017", T, "Recovering a floor dimension from the largest-tile data", "Medium",
  "Inverse/parameter",
  r"A rectangular floor is $7$ m $20$ cm long. The largest square tiles that can cover it exactly, without cutting, have side $48$ cm, and exactly $120$ of these tiles are used. What is the width of the floor, in centimetres?",
  "TITA",
  r"Along the length there are $\frac{720}{48} = 15$ tiles, so along the width there are $\frac{120}{15} = 8$ tiles, giving a width of $8 \times 48 = 384$ cm. This is consistent: $\mathrm{HCF}(720, 384) = 48$, so $48$ cm is indeed the largest possible tile.",
  "Reporting the number of tiles along the width, or using the floor length in metres.",
  "C21B-square-tiles-hcf", "Inverse use of the tile model with a consistency check on the HCF.",
  tita_answer=384, check=_c17,
  tita_traps=[(8, "Reports the number of tiles along the width."),
              (5760, "Multiplies $120$ tiles by $48$ cm, as if all tiles lay in a single row.")],
  cognitive="Application", exams=ALL)


def _c18():
    laps = [Rational(3, 2), Rational(9, 4), Rational(15, 4)]
    t = Rational(1, 4)
    k = 1
    while not all((k * t / x).is_integer for x in laps):
        k += 1
    return k * t
q("C21-B-018", T, "LCM of fractional lap times", "Medium",
  "Multi-step word problem",
  r"Three cyclists start together from the start line of a circular track and ride in the same direction at constant speeds. They take $1\frac{1}{2}$ minutes, $2\frac{1}{4}$ minutes and $3\frac{3}{4}$ minutes respectively to complete one lap. After how many minutes are all three next at the start line together?",
  "MCQ",
  r"The lap times are $\frac{3}{2}$, $\frac{9}{4}$ and $\frac{15}{4}$ minutes. The required time is their LCM: $\frac{\mathrm{LCM}(3, 9, 15)}{\mathrm{HCF}(2, 4, 4)} = \frac{45}{2}$ minutes. Check: $\frac{45}{2}$ is $15$, $10$ and $6$ laps respectively, all whole numbers.",
  "Dividing by the LCM of the denominators, or computing the HCF of the lap times.",
  "C21B-hcf-lcm-of-fractions", "LCM of fractions inside a word problem with mixed numbers.",
  correct=r"$\frac{45}{2}$",
  distractors=[(r"$\frac{45}{4}$", "Divides the LCM of numerators by the LCM of denominators."),
               (r"$\frac{3}{4}$", "Computes the HCF of the lap times."),
               (r"$\frac{15}{2}$", "Uses only the first and third cyclists: $\\mathrm{LCM}(\\frac{3}{2}, \\frac{15}{4}) = \\frac{15}{2}$.")],
  check=_c18, values=[Rational(45, 2), Rational(45, 4), Rational(3, 4), Rational(15, 2)], cognitive="Application", exams=ALL)


def _c19():
    for k in range(1, 1000):
        a, b = 4 * k, 6 * k
        if _L(a, b) == 360:
            return a + b
q("C21-B-019", T, "Numbers in a non-reduced ratio with a given LCM", "Medium",
  "Multi-step word problem",
  r"Two numbers are in the ratio $4 : 6$ and their LCM is $360$. What is the sum of the two numbers?",
  "MCQ",
  r"Write the numbers as $4k$ and $6k$. Then $\mathrm{LCM}(4k, 6k) = k \times \mathrm{LCM}(4, 6) = 12k$, so $12k = 360$, $k = 30$, and the numbers are $120$ and $180$ (equivalently, $2j$ and $3j$ with $6j = 360$). Their sum is $300$.",
  "Treating 4 and 6 as coprime so that the LCM is 24k.",
  "C21B-ratio-with-given-lcm", "The ratio is deliberately not in lowest terms, so the usual product shortcut fails.",
  correct=r"$300$",
  distractors=[(r"$150$", "Takes $\\mathrm{LCM}(4k, 6k) = 24k$, as if $4$ and $6$ were coprime, so $k = 15$."),
               (r"$600$", "Takes the LCM as $6k$, the larger term, so $k = 60$."),
               (r"$60$", "Reports the HCF $2k = 60$ of the two numbers.")],
  check=_c19, values=[300, 150, 600, 60], cognitive="Understanding", exams=ALL)


def _c20():
    for k in range(1, 10000):
        if _L(3 * k, 4 * k, 6 * k) == 1440:
            return _G(3 * k, 4 * k, 6 * k)
q("C21-B-020", T, "HCF of three numbers in a ratio with a given LCM", "Easy",
  "Multi-step word problem",
  r"Three numbers are in the ratio $3 : 4 : 6$ and their LCM is $1{,}440$. What is their HCF?",
  "MCQ",
  r"Write the numbers as $3k, 4k, 6k$ with $\mathrm{HCF}(3, 4, 6) = 1$, so their HCF is $k$. Their LCM is $k \times \mathrm{LCM}(3, 4, 6) = 12k = 1440$, so $k = 120$. The HCF is $120$ (the numbers are $360, 480, 720$).",
  "Using the product of the ratio terms as their LCM.",
  "C21B-ratio-with-given-lcm", "One idea: the HCF is the common multiplier k, found from LCM = 12k; the trap is using the product of the ratio terms.",
  correct=r"$120$",
  distractors=[(r"$20$", "Uses the product $3 \\times 4 \\times 6 = 72$ as the LCM of the ratio terms, so $k = 20$."),
               (r"$60$", "Takes $\\mathrm{LCM}(3, 4, 6)$ as $24$, so $k = 60$."),
               (r"$240$", "Takes the LCM of the ratio terms as the largest term $6$, so $k = 240$.")],
  check=_c20, values=[120, 20, 60, 240], cognitive="Application", exams=ALL)


def _c21():
    return sum(1 for a in range(1, 528) for b in range(a, 528) if a + b == 528 and _g(a, b) == 33)
q("C21-B-021", T, "Counting pairs with a given HCF and sum", "Medium",
  "Casework/optimisation",
  r"How many unordered pairs of positive integers have sum $528$ and HCF $33$?",
  "TITA",
  r"Write the numbers as $33a$ and $33b$ with $a, b$ coprime. Then $a + b = \frac{528}{33} = 16$. Coprime pairs with sum $16$ need both odd: $(1, 15), (3, 13), (5, 11), (7, 9)$, and all four are coprime. So there are $4$ pairs.",
  "Counting ordered pairs, or not imposing coprimality on a and b.",
  "C21B-pairs-given-hcf-and-sum", "Reduction to coprime pairs plus a short enumeration.",
  tita_answer=4, check=_c21,
  tita_traps=[(8, "Counts ordered pairs."),
              (7, "Counts all pairs $(a, b)$ with $a < b$ and $a + b = 16$ without checking coprimality.")],
  cognitive="Application", exams=ALL)


def _c22():
    divs = [d for d in range(1, 2521) if 2520 % d == 0]
    return sum(1 for a in divs for b in divs if a <= b and _g(a, b) == 6 and _L(a, b) == 2520)
q("C21-B-022", T, "Counting pairs with a given HCF and LCM", "Medium",
  "Casework/optimisation",
  r"How many unordered pairs of positive integers have HCF $6$ and LCM $2{,}520$?",
  "MCQ",
  r"Write the numbers as $6a$ and $6b$ with $a, b$ coprime and $ab = \frac{2520}{6} = 420 = 2^2 \times 3 \times 5 \times 7$. Each of the $4$ prime powers $2^2, 3, 5, 7$ must go wholly to $a$ or to $b$: $2^4 = 16$ ordered splits, so $8$ unordered pairs.",
  "Counting ordered pairs, or counting all factor pairs of 420 without coprimality.",
  "C21B-pairs-given-hcf-and-lcm", "Needs the coprime-split argument over distinct prime powers.",
  correct=r"$8$",
  distractors=[(r"$16$", "Counts ordered pairs."),
               (r"$12$", "Counts all factor pairs of $420$ ($24$ divisors, so $12$ pairs) without requiring them coprime."),
               (r"$24$", "Counts all divisors of $420$ as possible values of $a$ without requiring coprimality.")],
  check=_c22, values=[8, 16, 12, 24], cognitive="Analysis", exams=ALL)


def _c23():
    return min(x for x in range(13, 1000) if _L(12, x) == 180)
q("C21-B-023", T, "Unknown interval from the time of the first coincidence", "Medium",
  "Inverse/parameter",
  r"Two warning sirens sound together at noon. Siren P then sounds every $12$ minutes and siren Q every $x$ minutes, where $x$ is a whole number greater than $12$. They next sound together at exactly $3{:}00$ pm. What is the smallest possible value of $x$?",
  "MCQ",
  r"The first common time after noon is $\mathrm{LCM}(12, x) = 180$ minutes. With $180 = 2^2 \times 3^2 \times 5$ and $12 = 2^2 \times 3$, the number $x$ must divide $180$ and contain $3^2 \times 5 = 45$. So $x \in \{45, 90, 180\}$, and the smallest is $45$.",
  "Supplying only some of the missing prime powers, or making x even without need.",
  "C21B-lcm-with-fixed-number", "Inverse LCM condition solved by prime powers.",
  correct=r"$45$",
  distractors=[(r"$15$", "Supplies the factor $5$ but only $3^1$, so $\\mathrm{LCM}(12, 15) = 60$."),
               (r"$18$", "Supplies $3^2$ but not the factor $5$, so $\\mathrm{LCM}(12, 18) = 36$."),
               (r"$90$", "Believes $x$ must be even like $12$ and doubles $45$.")],
  check=_c23, values=[45, 15, 18, 90], cognitive="Analysis", exams=ALL)


def _c24():
    nums = [714, 1158, 1935]
    return max(d for d in range(2, 2000) if len({n % d for n in nums}) == 1)
q("C21-B-024", T, "Largest divisor leaving the same remainder (HCF of differences)", "Medium",
  "Conceptual/application",
  r"Kabir notices that when each of $714$, $1{,}158$ and $1{,}935$ is divided by a certain positive integer $N$, all three leave the same remainder. What is the largest possible value of $N$?",
  "MCQ",
  r"If all three leave the same remainder, $N$ divides each difference: $1158 - 714 = 444$, $1935 - 1158 = 777$ and $1935 - 714 = 1221$. Now $444 = 2^2 \times 3 \times 37$, $777 = 3 \times 7 \times 37$ and $1221 = 3 \times 11 \times 37$, so the HCF is $3 \times 37 = 111$. Indeed each number leaves remainder $48$ on division by $111$.",
  "Taking the HCF of the numbers rather than of their differences.",
  "C21B-same-remainder-hcf-differences", "Needs the differences idea and a three-number HCF.",
  correct=r"$111$",
  distractors=[(r"$37$", "Spots the common prime $37$ in the differences but misses the common factor $3$."),
               (r"$3$", "Takes the HCF of $714$, $1158$ and $1935$ themselves."),
               (r"$48$", "Reports the common remainder on division by $111$.")],
  check=_c24, values=[111, 37, 3, 48], cognitive="Application", exams=ALL)


def _c25():
    return max(d for d in range(10, 913) if 607 % d == 5 and 912 % d == 9)
q("C21-B-025", T, "Largest divisor leaving two different given remainders", "Medium",
  "Multi-step word problem",
  r"When $607$ is divided by a positive integer $N$ the remainder is $5$, and when $912$ is divided by the same $N$ the remainder is $9$. What is the largest possible value of $N$?",
  "TITA",
  r"$N$ divides $607 - 5 = 602$ and $912 - 9 = 903$. Since $602 = 2 \times 7 \times 43$ and $903 = 3 \times 7 \times 43$, $\mathrm{HCF}(602, 903) = 7 \times 43 = 301$. It exceeds both remainders, so $N = 301$ works.",
  "Taking the HCF of the original numbers, or stopping at a common factor that is not the highest.",
  "C21B-given-remainders-hcf", "Two subtractions, then an HCF with a check that N exceeds the remainders.",
  tita_answer=301, check=_c25,
  tita_traps=[(43, "Finds the common prime $43$ but misses the common factor $7$."),
              (1, "Takes $\\mathrm{HCF}(607, 912)$ without removing the remainders.")],
  cognitive="Application", exams=ALL)


def _c26():
    n = 1
    while not all(n % d == r for d, r in ((12, 8), (15, 11), (20, 16), (27, 23))):
        n += 1
    return n
q("C21-B-026", T, "Smallest number with remainders each a fixed amount short of the divisor", "Medium",
  "Conceptual/application",
  r"Priya is arranging chairs for a function. If she sets them in rows of $12$, $15$, $20$ or $27$, the last row has $8$, $11$, $16$ or $23$ chairs respectively, all other rows being full. What is the least number of chairs she can have?",
  "MCQ",
  r"In every case the remainder is $4$ less than the divisor ($12 - 8 = 15 - 11 = 20 - 16 = 27 - 23 = 4$), so the number plus $4$ is a common multiple of $12$, $15$, $20$ and $27$. $\mathrm{LCM} = 2^2 \times 3^3 \times 5 = 540$, so the least number is $540 - 4 = 536$.",
  "Adding the common shortfall instead of subtracting it.",
  "C21B-lcm-minus-common-shortfall", "Needs to spot the constant gap between divisors and remainders.",
  correct=r"$536$",
  distractors=[(r"$544$", "Adds the common gap $4$ to the LCM rather than subtracting it."),
               (r"$540$", "Reports the LCM itself, which leaves remainder $0$ in every case."),
               (r"$56$", "Leaves out the divisor $27$ and uses $\\mathrm{LCM}(12, 15, 20) = 60$.")],
  check=_c26, values=[536, 544, 540, 56], cognitive="Understanding", exams=ALL)


def _c27():
    n = 2
    while not (all(n % d == 1 for d in (6, 8, 9, 12)) and n % 7 == 0):
        n += 1
    return n
q("C21-B-027", T, "Common remainder for several divisors plus exact divisibility by another", "Medium",
  "Multi-step word problem",
  r"Ananya has a box of marbles. When she arranges them in rows of $6$, $8$, $9$ or $12$, exactly one marble is left over each time, but when she arranges them in rows of $7$, none is left over. What is the least number of marbles in the box?",
  "TITA",
  r"The number is $72k + 1$, since $\mathrm{LCM}(6, 8, 9, 12) = 72$. It must be divisible by $7$: $72 \equiv 2 \pmod 7$, so $2k + 1 \equiv 0 \pmod 7$, giving $k \equiv 3$. Hence the least number is $72 \times 3 + 1 = 217 = 7 \times 31$.",
  "Ignoring the divisibility by 7, or ignoring the remainder 1.",
  "C21B-lcm-remainder-and-divisible", "Combines an LCM condition with a divisibility condition; needs a short modular step.",
  tita_answer=217, check=_c27,
  tita_traps=[(73, "Uses $72 + 1$ and ignores the rows-of-$7$ condition."),
              (504, "Takes $\\mathrm{LCM}(6, 7, 8, 9, 12) = 504$ and ignores the left-over marble.")],
  cognitive="Application", exams=ALL)


def _c28():
    e = [12, 18, 27]
    s = 1
    while not all(s % x == 0 for x in e):
        s += 1
    return (s // 12) * (s // 18) * (s // 27)
q("C21-B-028", T, "Smallest cube built from identical cuboids", "Medium",
  "Multi-step word problem",
  r"Bricks measuring $12$ cm by $18$ cm by $27$ cm are stacked, all in the same orientation, to form a solid cube with no gaps. What is the least number of bricks needed?",
  "MCQ",
  r"The cube's edge must be a common multiple of $12$, $18$ and $27$; the smallest is $\mathrm{LCM} = 2^2 \times 3^3 = 108$ cm. Along the three edges there are $\frac{108}{12} = 9$, $\frac{108}{18} = 6$ and $\frac{108}{27} = 4$ bricks, so the number of bricks is $9 \times 6 \times 4 = 216$.",
  "Adding the counts along the edges, or using one edge count for all three directions.",
  "C21B-smallest-cube-from-cuboids", "LCM in three dimensions followed by a product.",
  correct=r"$216$",
  distractors=[(r"$108$", "Reports the edge of the cube in cm."),
               (r"$19$", "Adds $9 + 6 + 4$ instead of multiplying."),
               (r"$64$", "Uses the count $4$ along the $27$ cm edge for all three directions, $4^3$.")],
  check=_c28, values=[216, 108, 19, 64], cognitive="Application", exams=ALL)


def _c29():
    best = None
    for a in range(1, 271):
        for b in range(a, 271):
            if _g(a, b) == 9 and _L(a, b) == 270 and b - a == 63:
                best = a + b
    return best
q("C21-B-029", T, "Identifying two numbers from HCF, LCM and difference", "Medium",
  "Multi-step word problem",
  r"Two numbers have HCF $9$ and LCM $270$, and they differ by $63$. What is their sum?",
  "MCQ",
  r"Write them as $9a$ and $9b$ with $a, b$ coprime and $ab = \frac{270}{9} = 30$. The coprime splits are $(1, 30), (2, 15), (3, 10), (5, 6)$, giving differences $9 \times 29, 9 \times 13, 9 \times 7, 9 \times 1$. A difference of $63 = 9 \times 7$ means $(a, b) = (3, 10)$: the numbers are $27$ and $90$, with sum $117$.",
  "Picking the wrong coprime split of LCM / HCF.",
  "C21B-numbers-from-hcf-lcm", "Casework over coprime splits, filtered by a second condition.",
  correct=r"$117$",
  distractors=[(r"$99$", "Uses the split $(5, 6)$, the closest pair, giving $45$ and $54$."),
               (r"$153$", "Uses the split $(2, 15)$, giving $18$ and $135$."),
               (r"$279$", "Uses the split $(1, 30)$, giving $9$ and $270$.")],
  check=_c29, values=[117, 99, 153, 279], cognitive="Application", exams=ALL)


def _c30():
    divs = [d for d in range(1, 217) if 216 % d == 0]
    possible = {a for a in divs for b in divs if _g(a, b) == 18 and _L(a, b) == 216}
    opts = [72, 36, 24, 90]
    good = [o for o in opts if o in possible]
    assert good == [72]
    return good[0]
q("C21-B-030", T, "Which value can be one of two numbers with given HCF and LCM", "Medium",
  "Conceptual/application",
  r"The HCF of two positive integers is $18$ and their LCM is $216$. Which of the following could be one of the two integers?",
  "MCQ",
  r"Write the numbers as $18a$ and $18b$ with $a, b$ coprime and $ab = \frac{216}{18} = 12 = 2^2 \times 3$. The coprime splits are $(1, 12)$ and $(3, 4)$, so the possible numbers are $18, 216, 54, 72$. Of the values offered only $72$ is among them. The value $36$ fails because $a = 2$ would force $b = 6$, and then the HCF would be $36$, not $18$.",
  "Checking only that the value is a multiple of the HCF and a divisor of the LCM.",
  "C21B-hcf-lcm-feasibility", "Needs the coprime-split condition, not just the two obvious divisibility tests.",
  correct=r"$72$",
  distractors=[(r"$36$", "Checks only that $36$ is a multiple of $18$ and a divisor of $216$; the partner $108$ would make the HCF $36$."),
               (r"$24$", "Checks only that $24$ divides $216$, though $24$ is not a multiple of $18$."),
               (r"$90$", "Checks only that $90$ is a multiple of $18$, though it does not divide $216$.")],
  check=_c30, values=[72, 36, 24, 90], cognitive="Analysis", exams=ALL)


def _c31():
    return sum(1 for n in range(1, 201) if _g(n, 200) == 8)
q("C21-B-031", T, "Counting integers up to N with a prescribed HCF with N", "Medium",
  "Casework/optimisation",
  r"How many integers $n$ with $1 \le n \le 200$ satisfy $\mathrm{HCF}(n, 200) = 8$?",
  "TITA",
  r"$n$ must be a multiple of $8$: $n = 8m$ with $1 \le m \le 25$. Then $\mathrm{HCF}(8m, 200) = 8 \times \mathrm{HCF}(m, 25)$, which equals $8$ exactly when $m$ is not a multiple of $5$. Of the $25$ values of $m$, $5$ are multiples of $5$, leaving $20$.",
  "Counting all multiples of 8, forgetting that multiples of 40 have a larger HCF with 200.",
  "C21B-count-given-hcf-with-n", "Reduces to a coprimality count after factoring out the HCF.",
  tita_answer=20, check=_c31,
  tita_traps=[(25, "Counts every multiple of $8$ up to $200$."),
              (24, "Excludes only $n = 200$ among the multiples of $8$.")],
  cognitive="Analysis", exams=ALL)


def _c32():
    # visits every 6, 8, 10 days; together on a Monday (index 0); next together weekday
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    t = 1
    while not (t % 6 == 0 and t % 8 == 0 and t % 10 == 0):
        t += 1
    return days.index(days[t % 7])
q("C21-B-032", T, "Day of the week of the next common event", "Medium",
  "Multi-step word problem",
  r"Harpreet, Arjun and Fatima visit a public library every $6$ days, every $8$ days and every $10$ days respectively, without fail. All three visited it together on a Monday. On which day of the week will all three next visit the library on the same day?",
  "MCQ",
  r"They next coincide after $\mathrm{LCM}(6, 8, 10) = 2^3 \times 3 \times 5 = 120$ days. Since $120 = 7 \times 17 + 1$, that day is $1$ day of the week after Monday, a Tuesday.",
  "Using a common multiple that is not the least, or the LCM of only two intervals.",
  "C21B-lcm-day-of-week", "LCM combined with a remainder modulo 7.",
  correct=r"Tuesday",
  distractors=[(r"Wednesday", "Uses $\\frac{6 \\times 8 \\times 10}{2} = 240$ days, and $240 = 7 \\times 34 + 2$."),
               (r"Friday", "Uses the product $480$ days, and $480 = 7 \\times 68 + 4$."),
               (r"Thursday", "Uses $\\mathrm{LCM}(6, 8) = 24$ days only, and $24 = 7 \\times 3 + 3$.")],
  check=_c32, values=[1, 2, 4, 3], cognitive="Application", exams=ALL)


def _c33():
    f = [391, 323, 289]
    h = max(d for d in range(1, 290) if all(x % d == 0 for x in f))
    return sum(x // h for x in f)
q("C21-B-033", T, "Fewest single-fruit baskets of equal size", "Medium",
  "Multi-step word problem",
  r"A fruit seller has $391$ apples, $323$ oranges and $289$ pears. She packs them into baskets so that every basket holds the same number of fruits, each basket holds only one kind of fruit, and no fruit is left over. What is the least number of baskets she needs?",
  "TITA",
  r"The basket size must divide all three counts, and fewest baskets need the largest size, the HCF. Since $391 = 17 \times 23$, $323 = 17 \times 19$ and $289 = 17^2$, the HCF is $17$. The number of baskets is $23 + 19 + 17 = 59$.",
  "Reporting the basket size, or not spotting the common factor 17.",
  "C21B-equal-groups-hcf", "The HCF is a less familiar prime, so factorising or using differences is needed.",
  tita_answer=59, check=_c33,
  tita_traps=[(17, "Reports the number of fruits in each basket."),
              (1003, "Uses baskets of $1$ fruit, believing the three counts have no common factor.")],
  cognitive="Application", exams=ALL)


def _c34():
    vals = set()
    for a in range(1, 80, 2):
        for b in range(1, a, 2):
            if _g(a, b) == 1:
                vals.add(_g(a + b, a - b))
    assert vals == {2}
    return 2
q("C21-B-034", T, "HCF of the sum and difference of coprime odd numbers", "Medium",
  "Conceptual/application",
  r"$m$ and $n$ are coprime odd positive integers with $m > n$. The HCF of $m + n$ and $m - n$ always equals",
  "MCQ",
  r"Let $d = \mathrm{HCF}(m + n, m - n)$. Then $d$ divides the sum $2m$ and the difference $2n$, so $d$ divides $\mathrm{HCF}(2m, 2n) = 2$. Both $m + n$ and $m - n$ are even, so $2$ divides both, and $d = 2$. For example, $m = 7, n = 3$ gives $\mathrm{HCF}(10, 4) = 2$.",
  "Assuming coprime numbers give coprime sum and difference, or that both being even forces a factor 4.",
  "C21B-hcf-of-linear-combinations", "Needs the idea that a common divisor of two numbers divides their sum and difference.",
  correct=r"$2$",
  distractors=[(r"$1$", "Assumes the sum and difference of coprime numbers are coprime, overlooking that both are even."),
               (r"$4$", "Assumes that two even numbers formed this way share the factor $4$; $m = 5, n = 3$ gives $\\mathrm{HCF}(8, 2) = 2$."),
               (r"$8$", "Tests only $m = 5, n = 3$, where $m + n = 8$ and $m - n = 2$, and finds the LCM of $8$ and $2$, which is $8$, instead of their HCF.")],
  check=_c34, values=[2, 1, 4, 8], cognitive="Analysis", exams=ALL)

# ---------------------------------------------------------------- DIFFICULT (11)

def _c35():
    P = set(range(5, 366, 12))
    Q = set(range(11, 366, 18))
    R = set(range(13, 366, 8))
    return len(P & Q & R)
q("C21-B-035", T, "Counting days on which three staggered schedules coincide", "Difficult",
  "Casework/optimisation",
  r"A factory services machine P every $12$ days, the first service being on day $5$ of the year; machine Q every $18$ days, the first service being on day $11$; and machine R every $8$ days, the first service being on day $13$. Counting day $1$ as the first day of a $365$-day year, on how many days of the year are all three machines serviced?",
  "TITA",
  r"P and Q: P's days $5, 17, 29$ and Q's days $11, 29$ show that they first coincide on day $29$, and then every $\mathrm{LCM}(12, 18) = 36$ days, on days $29 + 36k$. R is serviced on days $13, 21, 29, \ldots$, that is the days from $13$ on that leave remainder $5$ on division by $8$. Since $29 + 36k \equiv 5 + 4k \pmod 8$, this needs $k$ even, so all three coincide on days $29 + 72j$, where $72 = \mathrm{LCM}(12, 18, 8)$. These are $29, 101, 173, 245, 317$; the next, $389$, is beyond day $365$. So all three are serviced together on $5$ days.",
  "Ignoring the third schedule's offset, or taking one schedule's start day as the first common day.",
  "C21B-staggered-start-coincidence", "Three offset schedules: find the first P-Q coincidence by search, combine it with the third schedule by a congruence, then count in steps of the three-way LCM over the year.",
  tita_answer=5, check=_c35,
  tita_traps=[(10, "Counts only the days on which P and Q coincide, $29 + 36k$, and ignores machine R."),
              (6, "Takes day $5$ as the first common day and counts $5, 77, 149, 221, 293, 365$ in steps of $72$."),
              (0, "Concludes that schedules with different start days never coincide.")],
  cognitive="Analysis", exams=CX)


def _c36():
    divs = [d for d in range(1, 721) if 720 % d == 0]
    return sum(1 for a in divs for b in divs if _L(a, b) == 720)
q("C21-B-036", T, "Counting ordered pairs with a given LCM", "Difficult",
  "Casework/optimisation",
  r"How many ordered pairs $(x, y)$ of positive integers satisfy $\mathrm{LCM}(x, y) = 720$?",
  "MCQ",
  r"$720 = 2^4 \times 3^2 \times 5$. For a prime power $p^e$ in the LCM, the exponents of $p$ in $x$ and $y$ must have maximum exactly $e$: there are $(e+1)^2 - e^2 = 2e + 1$ such ordered choices. Multiplying, $(2 \times 4 + 1)(2 \times 2 + 1)(2 \times 1 + 1) = 9 \times 5 \times 3 = 135$.",
  "Counting all pairs of divisors, or halving to unordered pairs.",
  "C21B-pairs-with-given-lcm", "Requires the per-prime counting argument for the maximum of two exponents.",
  correct=r"$135$",
  distractors=[(r"$68$", "Counts unordered pairs, $\\frac{135 + 1}{2}$."),
               (r"$900$", "Counts all ordered pairs of divisors of $720$, $30^2$, without requiring the LCM to be $720$."),
               (r"$30$", "Counts the divisors of $720$, as if $y$ were fixed once $x$ is chosen.")],
  check=_c36, values=[135, 68, 900, 30], cognitive="Analysis", exams=CX)


def _c37():
    nums = [1062, 1307, 1797]
    return sum(1 for d in range(2, 2000) if len({n % d for n in nums}) == 1)
q("C21-B-037", T, "Number of divisors leaving a common remainder", "Difficult",
  "Casework/optimisation",
  r"For how many integers $N > 1$ do $1{,}062$, $1{,}307$ and $1{,}797$ all leave the same remainder when divided by $N$?",
  "MCQ",
  r"The condition holds exactly when $N$ divides all the differences $1307 - 1062 = 245$, $1797 - 1307 = 490$ and $1797 - 1062 = 735$, that is when $N$ divides their HCF $245 = 5 \times 7^2$. The divisors of $245$ are $1, 5, 7, 35, 49, 245$; excluding $1$ leaves $5$ values.",
  "Counting the divisor 1, or only the largest such N.",
  "C21B-same-remainder-hcf-differences", "Turns a same-remainder condition into counting divisors of an HCF.",
  correct=r"$5$",
  distractors=[(r"$6$", "Counts all divisors of $245$, including $N = 1$."),
               (r"$2$", "Counts only the prime divisors $5$ and $7$."),
               (r"$1$", "Gives only the largest such $N$, $245$, as if it were the only one.")],
  check=_c37, values=[5, 6, 2, 1], cognitive="Analysis", exams=CX)


def _c38():
    best = 0
    for h in range(1, 1156):
        if 1155 % h == 0 and 1155 // h >= 15:
            best = max(best, h)
    return best
q("C21-B-038", T, "Maximum HCF of distinct numbers with a fixed sum", "Difficult",
  "Casework/optimisation",
  r"Five distinct positive integers add up to $1{,}155$. What is the largest possible value of their HCF?",
  "MCQ",
  r"If the HCF is $h$, the numbers are $ha_1, \ldots, ha_5$ with distinct positive $a_i$, so $h$ divides $1155$ and $\frac{1155}{h} = a_1 + \cdots + a_5 \ge 1 + 2 + 3 + 4 + 5 = 15$. So $h \le 77$, and $h = 77$ divides $1155 = 3 \times 5 \times 7 \times 11$, with $\frac{1155}{77} = 15$. The numbers $77, 154, 231, 308, 385$ achieve it.",
  "Forgetting that the numbers must be distinct, so the multipliers sum to at least 15.",
  "C21B-max-hcf-with-fixed-sum", "Needs both the divisibility of the sum and the minimum sum of distinct multipliers.",
  correct=r"$77$",
  distractors=[(r"$231$", "Ignores distinctness and uses $\\frac{1155}{5} = 231$ with five equal numbers."),
               (r"$105$", "Uses $1155 = 105 \\times 11$; but $11 < 15$, so five distinct multipliers cannot sum to $11$."),
               (r"$165$", "Requires only that the multipliers are not all equal, and uses $\\frac{1155}{165} = 7$; five distinct multipliers cannot sum to $7$.")],
  check=_c38, values=[77, 231, 105, 165], cognitive="Analysis", exams=CX)


def _c39():
    a = Integer(2) ** 84 - 1
    b = Integer(2) ** 60 - 1
    return igcd(a, b)
q("C21-B-039", T, "HCF of two numbers of the form 2^m - 1", "Difficult",
  "Conceptual/application",
  r"The HCF of $2^{84} - 1$ and $2^{60} - 1$ is",
  "MCQ",
  r"$\mathrm{HCF}(2^m - 1, 2^n - 1) = 2^{\mathrm{HCF}(m, n)} - 1$. The reason: the Euclidean algorithm on the exponents carries over, since $2^{84} - 1 = 2^{24}(2^{60} - 1) + (2^{24} - 1)$, so the HCF equals $\mathrm{HCF}(2^{60} - 1, 2^{24} - 1)$, and so on down to exponent $\mathrm{HCF}(84, 60) = 12$. The answer is $2^{12} - 1$.",
  "Stopping the Euclidean algorithm after one step, or using the LCM of the exponents.",
  "C21B-hcf-of-power-differences", "Needs the exponent HCF property, which is not routine.",
  correct=r"$2^{12} - 1$",
  distractors=[(r"$2^{24} - 1$", "Stops after the first Euclidean step, using the exponent $84 - 60 = 24$."),
               (r"$2^{420} - 1$", "Uses the LCM of the exponents $84$ and $60$."),
               (r"$2^{2} - 1$", "Notes that $2^2 - 1 = 3$ divides both because both exponents are even, and stops there.")],
  check=_c39, values=[Integer(2) ** 12 - 1, Integer(2) ** 24 - 1, Integer(2) ** 420 - 1, Integer(3)], cognitive="Analysis", exams=CX)


def _c40():
    divs = [d for d in range(1, 211) if 210 % d == 0]
    return min(7 * (a + 210 // a) for a in divs if _g(a, 210 // a) == 1)
q("C21-B-040", T, "Minimum sum of two numbers with given HCF and LCM", "Difficult",
  "Casework/optimisation",
  r"Two positive integers have HCF $7$ and LCM $1{,}470$. What is the least possible value of their sum?",
  "MCQ",
  r"Write them as $7a$ and $7b$ with $a, b$ coprime and $ab = \frac{1470}{7} = 210 = 2 \times 3 \times 5 \times 7$. The sum $7(a + b)$ is least when $a$ and $b$ are closest, and since $\sqrt{210} \approx 14.5$, the best coprime split is $14 \times 15$. The numbers are $98$ and $105$, with sum $203$.",
  "Stopping at a nearby split that is not the closest, or taking the numbers as the HCF and LCM.",
  "C21B-numbers-from-hcf-lcm", "Optimisation over all coprime splits of a product of four primes.",
  correct=r"$203$",
  distractors=[(r"$217$", "Uses the split $10 \\times 21$, giving $70$ and $147$."),
               (r"$1{,}477$", "Takes the numbers as the HCF $7$ and the LCM $1470$ themselves."),
               (r"$287$", "Uses the split $6 \\times 35$, giving $42$ and $245$.")],
  check=_c40, values=[203, 217, 1477, 287], cognitive="Analysis", exams=CX)


def _c41():
    sols = [(a, 156 - a) for a in range(1, 78) if _L(a, 156 - a) == 432]
    assert len(sols) == 1
    a, b = sols[0]
    return b - a
q("C21-B-041", T, "Two numbers from their sum and LCM", "Difficult",
  "Conceptual/application",
  r"Two positive integers have sum $156$ and LCM $432$. What is the positive difference between them?",
  "TITA",
  r"Let the numbers be $ha$ and $hb$ with $a, b$ coprime. Then $a + b$ and $ab$ are coprime, so $\mathrm{HCF}(156, 432) = h \times \mathrm{HCF}(a + b, ab) = h$. Here $h = \mathrm{HCF}(156, 432) = 12$, so $a + b = 13$ and $ab = 36$, giving $a = 4$, $b = 9$. The numbers are $48$ and $108$, and their difference is $60$.",
  "Not knowing that the HCF of the sum and the LCM equals the HCF of the numbers.",
  "C21B-sum-and-lcm-given", "Needs the non-obvious fact HCF(sum, LCM) = HCF of the numbers.",
  tita_answer=60, check=_c41,
  tita_traps=[(108, "Reports the larger number."),
              (12, "Reports the HCF of the two numbers.")],
  cognitive="Analysis", exams=CX)


def _c42():
    return max(_L(a, 60 - a) for a in range(1, 60))
q("C21-B-042", T, "Maximum LCM of two numbers with a fixed sum", "Difficult",
  "Casework/optimisation",
  r"Two positive integers add up to $60$. What is the greatest possible value of their LCM?",
  "MCQ",
  r"$\mathrm{LCM}(a, b) \le ab$, and $ab$ is largest when $a, b$ are close to $30$. The pair $(30, 30)$ has LCM only $30$. The pair $(29, 31)$ is coprime, so its LCM is $29 \times 31 = 899$. Any other pair has $ab \le 28 \times 32 = 896 < 899$, so $899$ is the maximum.",
  "Maximising the product without checking that the numbers are coprime.",
  "C21B-extreme-lcm-with-fixed-sum", "Needs the bound LCM <= product and a check of the near-equal pairs.",
  correct=r"$899$",
  distractors=[(r"$900$", "Maximises the product with $30 \\times 30$, though $\\mathrm{LCM}(30, 30) = 30$."),
               (r"$891$", "Takes $27 \\times 33$ as the LCM, though the numbers share the factor $3$ and their LCM is $297$."),
               (r"$59$", "Makes one number as large as possible, $(1, 59)$, believing that maximises the LCM.")],
  check=_c42, values=[899, 900, 891, 59], cognitive="Analysis", exams=CX)


def _c43():
    return min(_L(a, 84 - a) for a in range(1, 84) if a != 84 - a)
q("C21-B-043", T, "Minimum LCM of two distinct numbers with a fixed sum", "Difficult",
  "Casework/optimisation",
  r"Two distinct positive integers add up to $84$. What is the least possible value of their LCM?",
  "TITA",
  r"Let the larger number be $b > 42$. The LCM is a multiple of $b$, so it is either $b$ itself or at least $2b > 84$. The LCM equals $b$ only when the smaller number $a = 84 - b$ divides $b$, which happens exactly when $a$ divides $84$. The largest divisor of $84$ below $42$ is $28$, giving $(28, 56)$ with LCM $56$, the least possible.",
  "Allowing equal numbers, or picking a split that does not minimise the larger number.",
  "C21B-extreme-lcm-with-fixed-sum", "Needs the argument that the LCM is the larger number only when the smaller divides 84.",
  tita_answer=56, check=_c43,
  tita_traps=[(42, "Uses $42 + 42$, ignoring that the numbers must be distinct."),
              (63, "Uses $(21, 63)$, a divisor pair that is not the closest.")],
  cognitive="Analysis", exams=CX)


def _c44():
    sols = [n for n in range(1, 1000) if _g(n, 20) + _L(n, 20) == 182]
    assert len(sols) == 1
    return sols[0]
q("C21-B-044", T, "Unknown number from the sum of its HCF and LCM with a fixed number", "Difficult",
  "Inverse/parameter",
  r"A positive integer $n$ satisfies $\mathrm{HCF}(n, 20) + \mathrm{LCM}(n, 20) = 182$. What is $n$?",
  "TITA",
  r"Let $g = \mathrm{HCF}(n, 20)$, a divisor of $20$. Then $\mathrm{LCM} = \frac{20n}{g}$, so $g + \frac{20n}{g} = 182$, and since the LCM is a multiple of $g$, $g$ must divide $182 = 2 \times 7 \times 13$; with $g \mid 20$, $g \in \{1, 2\}$. If $g = 1$, $20n = 181$, impossible. If $g = 2$, $10n = 180$, so $n = 18$, and indeed $\mathrm{HCF}(18, 20) = 2$ and $\mathrm{LCM}(18, 20) = 180$.",
  "Not checking that the assumed HCF is the actual HCF of n and 20.",
  "C21B-hcf-plus-lcm-equation", "Casework on the possible HCF values with a consistency check.",
  tita_answer=18, check=_c44,
  tita_traps=[(180, "Reports the LCM of $n$ and $20$."),
              (9, "Assumes the LCM is $180$ and that it equals $20n$, so $n = 9$, without checking the HCF.")],
  cognitive="Analysis", exams=CX)


def _c45():
    two = [n for n in range(10, 100) if n % 6 == 0]
    return sum(1 for a, b in itertools.combinations(two, 2) if _g(a, b) == 6)
q("C21-B-045", T, "Counting pairs of bounded numbers with a given HCF", "Difficult",
  "Casework/optimisation",
  r"How many pairs of distinct two-digit numbers have HCF exactly $6$? (A pair is unordered.)",
  "MCQ",
  r"Write the numbers as $6a$ and $6b$ with $a < b$ coprime. Both are two-digit, so $12 \le 6a$ and $6b \le 96$, that is $2 \le a < b \le 16$. For a fixed $b$, the values $a$ from $1$ to $b - 1$ coprime to $b$ number $\varphi(b)$; excluding $a = 1$ leaves $\varphi(b) - 1$. For $b = 3, 4, \ldots, 16$ the values $\varphi(b)$ are $2, 2, 4, 2, 6, 4, 6, 4, 10, 4, 12, 6, 8, 8$, with sum $78$. So the count is $78 - 14 = 64$.",
  "Not requiring the multipliers to be coprime, or letting 6 itself count as a two-digit number.",
  "C21B-pairs-hcf-bounded-range", "Needs the reduction to coprime multipliers in a range and an organised count (by Euler's totient or a careful table) over 14 values of the larger multiplier.",
  correct=r"$64$",
  distractors=[(r"$79$", "Lets the multiplier $a = 1$ in, treating $6$ as a two-digit number, which adds $15$ pairs."),
               (r"$105$", "Counts all $\\binom{15}{2} = 105$ pairs of two-digit multiples of $6$ without requiring the HCF to be exactly $6$."),
               (r"$128$", "Counts ordered pairs.")],
  check=_c45, values=[64, 79, 105, 128], cognitive="Analysis", exams=CX)
