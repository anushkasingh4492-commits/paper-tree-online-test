# -*- coding: utf-8 -*-
"""Authoring helper for the CAT Quantitative Ability bank (Paper Tree Educational Studio).

Every drafting file does:   from qlib import *
and then calls q(...) once per question.
"""
from fractions import Fraction  # noqa: F401
import itertools, math  # noqa: F401
from sympy import *  # noqa: F401,F403

QUESTIONS = []

DIFFICULTIES = ("Easy", "Medium", "Difficult")
FORMATS = ("MCQ", "TITA")
QTYPES = (
    "Single-step computation",
    "Multi-step word problem",
    "Inverse/parameter",
    "Conceptual/application",
    "Casework/optimisation",
)
COGNITIVE = ("Recall", "Understanding", "Application", "Analysis")
EXAMS = ("CAT", "XAT", "NMAT", "SNAP", "CMAT", "MAH-CET")


def q(local_id, topic, subtopic, difficulty, qtype, question, fmt,
      explanation, misconception, family, difficulty_reason,
      correct=None, distractors=None, tita_answer=None,
      check=None, values=None, cognitive="Application",
      assumptions=(), exams=EXAMS, tita_traps=(), figure=None, flags=""):
    """Register one question.

    local_id      e.g. "C08-A-001"
    question      stem, LaTeX inline with $...$. For TITA the stem must state the unit and the
                  exact form of the answer (e.g. "in km/h", "in minutes").
    fmt           "MCQ" or "TITA"
    MCQ:  correct      LaTeX text of the correct option
          distractors  list of exactly 3 tuples (option_latex, rationale_for_reviewer)
          values       list of 4 exact values [key, d1, d2, d3] (int, Fraction or sympy)
    TITA: tita_answer  non-negative int, the only accepted entry
          values       [tita_answer]
          tita_traps   optional list of (wrong_int, rationale) for common wrong entries
    check         zero-argument function that RECOMPUTES the answer from the givens in the stem
                  (sympy solve, or a brute-force/step simulation). Required for every question.
    exams         subset of EXAMS this item suits (CAT core is always in it).
    flags         anything you are unsure about. Leave "" if nothing.
    """
    assert fmt in FORMATS, (local_id, fmt)
    assert difficulty in DIFFICULTIES, (local_id, difficulty)
    assert qtype in QTYPES, (local_id, qtype)
    assert cognitive in COGNITIVE, (local_id, cognitive)
    assert "CAT" in exams and all(e in EXAMS for e in exams), (local_id, exams)
    assert check is not None, (local_id, "every CAT QA item needs a machine check")
    if figure is not None:
        assert isinstance(figure, dict) and set(figure) <= {"svg", "alt", "required"} and "svg" in figure and "alt" in figure, \
            (local_id, "figure must be dict(svg=..., alt=..., required=bool)")
        assert figure["svg"].startswith("<svg") and len(figure["alt"].strip()) >= 20, (local_id, "figure svg/alt")
    if fmt == "MCQ":
        assert correct and distractors and len(distractors) == 3, (local_id, "MCQ needs correct + 3 distractors")
        for d in distractors:
            assert isinstance(d, tuple) and len(d) == 2 and d[1].strip(), (local_id, "distractor needs (text, rationale)")
        texts = [correct] + [d[0] for d in distractors]
        assert len(set(t.strip() for t in texts)) == 4, (local_id, "options not distinct")
        assert values is not None and len(values) == 4, (local_id, "values must have 4 entries")
        assert tita_answer is None, (local_id, "MCQ must not set tita_answer")
    else:
        assert correct is None and not distractors, (local_id, "TITA has no options")
        assert isinstance(tita_answer, int) and not isinstance(tita_answer, bool) and tita_answer >= 0, \
            (local_id, "tita_answer must be a non-negative int")
        if values is None:
            values = [tita_answer]
        assert len(values) == 1, (local_id, "TITA values = [answer]")
        for t in tita_traps:
            assert isinstance(t, tuple) and len(t) == 2 and isinstance(t[0], int), (local_id, "trap = (int, rationale)")
    QUESTIONS.append(dict(
        local_id=local_id, topic=topic, subtopic=subtopic, difficulty=difficulty,
        question_type=qtype, question=question, answer_format=fmt,
        correct=correct, distractors=[dict(text=t, rationale=r) for t, r in (distractors or [])],
        tita_answer=tita_answer, tita_traps=[dict(value=v, rationale=r) for v, r in tita_traps],
        explanation=explanation, common_misconception=misconception,
        concept_family=family, difficulty_reason=difficulty_reason,
        check=check, values=values, cognitive_level=cognitive,
        assumptions=list(assumptions), exams=list(exams), figure=figure, flags=flags,
    ))
