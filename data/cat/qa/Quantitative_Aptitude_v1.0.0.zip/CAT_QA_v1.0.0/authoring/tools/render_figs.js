// node tools/render_figs.js <svgdir> <outdir> : renders every .svg to .png
const { chromium } = require('playwright'); const fs=require('fs'); const path=require('path');
(async()=>{const [,,src,out]=process.argv; fs.mkdirSync(out,{recursive:true});
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'}).catch(()=>chromium.launch());
const p=await b.newPage({viewport:{width:340,height:260}});
for(const f of fs.readdirSync(src).filter(x=>x.endsWith('.svg'))){await p.goto('file://'+path.resolve(src,f));await p.screenshot({path:path.join(out,f.replace('.svg','.png'))});}
await b.close();})();
