# usage: python3 tools/render_batch_figs.py drafts/c15_a.py OUTDIR  -> writes OUTDIR/<local_id>.png for every figure
import os, sys, subprocess, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from harness import load
qs = load(sys.argv[1]); out = sys.argv[2]; tmp = tempfile.mkdtemp()
for x in qs:
    if x["figure"]:
        open(os.path.join(tmp, x["local_id"] + ".svg"), "w").write(x["figure"]["svg"])
here = os.path.dirname(os.path.abspath(__file__))
env = dict(os.environ, NODE_PATH=subprocess.run(["npm", "root", "-g"], capture_output=True, text=True).stdout.strip())
subprocess.run(["node", os.path.join(here, "render_figs.js"), tmp, out], check=True, env=env)
print("rendered to", out, sorted(os.listdir(out)))
