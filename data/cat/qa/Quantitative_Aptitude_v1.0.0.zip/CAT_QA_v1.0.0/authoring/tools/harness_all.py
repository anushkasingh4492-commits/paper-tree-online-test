import json,subprocess,sys
b=json.load(open('config/batch_plan.json'))
chs=set(int(c) for c in sys.argv[1].split(',')) if len(sys.argv)>1 else None
for x in b:
    if chs and x['ch'] not in chs: continue
    f=f"drafts/c{x['ch']:02d}_{x['letter'].lower()}.py"
    r=subprocess.run(['python3','harness.py',f,'--easy',str(x['easy']),'--medium',str(x['medium']),'--difficult',str(x['difficult']),'--tita',str(x['tita'])],capture_output=True,text=True)
    out=r.stdout
    bl=[l for l in out.splitlines() if l.startswith('BLOCKING') or l.startswith('ADVISORY')]
    print(f, ' '.join(bl), r.stderr[-300:] if r.returncode else '')
