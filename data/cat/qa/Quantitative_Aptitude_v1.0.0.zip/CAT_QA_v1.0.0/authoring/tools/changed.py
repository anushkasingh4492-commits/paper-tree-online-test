import json,glob,sys,os
sys.path.insert(0,'/home/claude/catqa')
from harness import load
name=sys.argv[1]; files=sys.argv[2:]
old={}
for f in glob.glob(f'/home/claude/blind_cat/pack_{name}_*.json'):
    for it in json.load(open(f)): old[it['id']]=it
km=json.load(open(f'verify/blind/{name}_keymap.json'))
ch=[]
for f in files:
    for x in load(f):
        o=old.get(x['local_id'])
        if o is None: continue
        if o['question']!=x['question']: ch.append(x['local_id']); continue
        if x['answer_format']=='MCQ':
            if o['format']!='MCQ' or set(o['options'].values())!={x['correct']}|{d['text'] for d in x['distractors']} or o['options'][km[x['local_id']]]!=x['correct']: ch.append(x['local_id'])
        else:
            if o['format']!='TITA' or km[x['local_id']]!=x['tita_answer']: ch.append(x['local_id'])
print(len(ch)); json.dump(sorted(ch),open(f'verify/changed_{name}.json','w'))
