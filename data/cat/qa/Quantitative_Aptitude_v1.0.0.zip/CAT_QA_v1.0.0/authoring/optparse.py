"""Conservative parser: option LaTeX text -> exact number, or None if not a plain number."""
import re
from fractions import Fraction
def parse(t):
    s = t.strip()
    s = re.sub(r"^Rs\.\s*", "", s)
    s = s.replace("{,}", "").replace("\\%", "").replace("\\,", "")
    m = re.fullmatch(r"\$([^$]*)\$\s*([A-Za-z/ .^0-9]*)", s)
    if not m: return None
    unit = m.group(2).strip()
    if unit and not re.fullmatch(r"[A-Za-z/ .]+", unit): return None
    body = m.group(1).strip().replace(" ", "")
    if re.fullmatch(r"-?\d+(\.\d+)?", body): return Fraction(body)
    mm = re.fullmatch(r"(-?)\\[dt]?frac\{(\d+)\}\{(\d+)\}", body)
    if mm: return (-1 if mm.group(1) else 1) * Fraction(int(mm.group(2)), int(mm.group(3)))
    return None
