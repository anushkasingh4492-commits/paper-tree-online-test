# -*- coding: utf-8 -*-
"""CAT QA paper generator (Python standard library only).

Example:
  python generate_paper.py --bank cat_qa_v1.0.0.json --seed 7 --output practice7
Options:
  --questions N     section size (default 22, as in CAT)
  --tita T          number of TITA questions (default 8)
  --chapter K       restrict to one chapter number
  --area NAME       restrict to one area (Arithmetic, Algebra, Geometry, Number System, Modern Maths)
  --exam NAME       restrict to items tagged for an exam (CAT, XAT, NMAT, SNAP, CMAT, MAH-CET)
  --minutes M       time limit printed on the paper (default 40)
Rules (see Generator_Contract.md): difficulty 30/45/25 rounded to the section size, the TITA count
as asked, and never two questions that share any entry of family_dependencies.
"""
import argparse, json, random, sys

DIFFS = ("Easy", "Medium", "Difficult")


def quotas(n):
    e = int(n * 0.30 + 0.5); m = int(n * 0.45 + 0.5)
    return {"Easy": e, "Medium": m, "Difficult": n - e - m}


def pick(bank, n, n_tita, seed, tries=4000):
    q = quotas(n)
    rnd = random.Random(seed)
    for _ in range(tries):
        pool = list(bank); rnd.shuffle(pool)
        used_fams, chosen = set(), []
        need = dict(q); tita_left, mcq_left = n_tita, n - n_tita
        for r in pool:
            if need[r["difficulty"]] == 0:
                continue
            if r["answer_format"] == "TITA" and tita_left == 0:
                continue
            if r["answer_format"] == "MCQ" and mcq_left == 0:
                continue
            if used_fams & set(r["family_dependencies"]):
                continue
            chosen.append(r); used_fams |= set(r["family_dependencies"])
            need[r["difficulty"]] -= 1
            if r["answer_format"] == "TITA":
                tita_left -= 1
            else:
                mcq_left -= 1
            if len(chosen) == n:
                return chosen
    raise SystemExit("Could not build a paper with these constraints; relax --tita or --questions.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bank", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--output", default="paper")
    ap.add_argument("--questions", type=int, default=22)
    ap.add_argument("--tita", type=int, default=8)
    ap.add_argument("--chapter", type=int)
    ap.add_argument("--area")
    ap.add_argument("--exam")
    ap.add_argument("--minutes", type=int, default=40)
    a = ap.parse_args()
    bank = json.load(open(a.bank, encoding="utf-8"))
    bank = [r for r in bank if r.get("generator_eligible", True)]
    if a.chapter:
        bank = [r for r in bank if r["chapter_number"] == a.chapter]
    if a.area:
        bank = [r for r in bank if r["area"] == a.area]
    if a.exam:
        bank = [r for r in bank if a.exam in r["exam_tags"]]
    chosen = pick(bank, a.questions, a.tita, a.seed)
    rnd = random.Random(a.seed + 1)
    rnd.shuffle(chosen)
    paper = dict(seed=a.seed, description=f"CAT-style Quantitative Ability section of {a.questions} questions.",
                 time_minutes=a.minutes, max_marks=3 * a.questions,
                 marking={"MCQ": {"correct": 3, "incorrect": -1, "unattempted": 0},
                          "TITA": {"correct": 3, "incorrect": 0, "unattempted": 0}},
                 questions=[r["id"] for r in chosen])
    key = [dict(number=i + 1, id=r["id"], format=r["answer_format"],
                answer=r["correct_option"] if r["answer_format"] == "MCQ" else r["tita_answer"])
           for i, r in enumerate(chosen)]
    json.dump(paper, open(a.output + "_paper.json", "w"), indent=1)
    json.dump(key, open(a.output + "_answer_key.json", "w"), indent=1)
    from collections import Counter
    print("questions", len(chosen), dict(Counter(r["difficulty"] for r in chosen)),
          dict(Counter(r["answer_format"] for r in chosen)))


if __name__ == "__main__":
    main()
