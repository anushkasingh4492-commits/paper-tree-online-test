# -*- coding: utf-8 -*-
"""Structural verification of a CAT QA release (Python standard library only).

usage: python verify_release.py [bank.json]
Exit code 0 when every check passes.
"""
import glob, json, os, random, re, subprocess, sys, tempfile
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else sorted(glob.glob(os.path.join(HERE, "cat_qa_*.json")))[0]
    bank = json.load(open(path, encoding="utf-8"))
    summary = json.load(open(os.path.join(HERE, "release_summary.json"), encoding="utf-8"))
    n = len(bank)
    check(n == summary["questions"], f"count {n} != summary {summary['questions']}")
    ids = [r["id"] for r in bank]
    check(len(set(ids)) == n, "duplicate ids")
    for r in bank:
        rid = r["id"]
        check(re.fullmatch(r"CAT-QA-C\d{2}-\d{3}", rid) is not None, f"{rid}: id pattern")
        check(r["difficulty"] in ("Easy", "Medium", "Difficult"), f"{rid}: difficulty")
        check("CAT" in r["exam_tags"], f"{rid}: CAT tag missing")
        check(r["answer_format"] in ("MCQ", "TITA"), f"{rid}: format")
        content = [r["question"], r["explanation"]]
        if r["answer_format"] == "MCQ":
            check(set(r["options"]) == set("ABCD"), f"{rid}: options")
            check(len({v.strip() for v in r["options"].values()}) == 4, f"{rid}: options not distinct")
            check(r["correct_option"] in "ABCD", f"{rid}: key letter")
            check(r["options"][r["correct_option"]] == r["correct_answer"], f"{rid}: correct_answer mismatch")
            check(r["tita_answer"] is None and r["marks_incorrect"] == -1, f"{rid}: MCQ fields")
            content += list(r["options"].values())
        else:
            check(r["options"] is None and r["correct_option"] is None, f"{rid}: TITA has options")
            check(isinstance(r["tita_answer"], int) and r["tita_answer"] >= 0, f"{rid}: TITA answer")
            check(r["marks_incorrect"] == 0, f"{rid}: TITA marking")
            check(not re.search(r"\boptions?\b|which of the following", r["question"], re.I), f"{rid}: TITA mentions options")
        check(r["machine_check"]["status"] == "match", f"{rid}: machine check")
        check(r["family_dependencies"][0] == r["concept_family"], f"{rid}: family deps")
        for t in content:
            check(not any(ch in t for ch in "—–"), f"{rid}: dash")
            check(all(ord(ch) < 127 for ch in t), f"{rid}: non-ASCII")
            check(t.count("$") % 2 == 0, f"{rid}: unbalanced $")
            check(not re.search(r"\b(errata|audit|reviewer|erratum)\b", t, re.I), f"{rid}: meta commentary")
    dc = Counter(r["difficulty"] for r in bank)
    check(dict(dc) == summary["difficulty"], f"difficulty {dict(dc)}")
    fc = Counter(r["answer_format"] for r in bank)
    check(dict(fc) == summary["formats"], f"formats {dict(fc)}")
    keys = Counter(r["correct_option"] for r in bank if r["answer_format"] == "MCQ")
    for ch in sorted({r["chapter_number"] for r in bank}):
        cr = [r for r in bank if r["chapter_number"] == ch and r["answer_format"] == "MCQ"]
        ck = Counter(r["correct_option"] for r in cr)
        check(len(ck) == 4 and max(ck.values()) - min(ck.values()) <= 1, f"chapter {ch}: key balance {dict(ck)}")
        seq = "".join(r["correct_option"] for r in cr)
        check(not re.search(r"(.)\1\1\1", seq), f"chapter {ch}: key run longer than 3")
    check(dict(Counter(r["area"] for r in bank)) == summary.get("areas", dict(Counter(r["area"] for r in bank))), "area counts")
    for r in bank:
        for fg in r["figures"]:
            check(os.path.exists(os.path.join(HERE, fg["file"])), f"{r['id']}: figure file missing")
            check(len(fg["alt_text"]) >= 20, f"{r['id']}: figure alt")
    fam = Counter(r["concept_family"] for r in bank)
    check(max(fam.values()) <= 3, "family over 3")
    # student-facing exports must not leak keys
    qo = json.load(open(os.path.join(HERE, "questions_only.json"), encoding="utf-8"))
    check(len(qo) == n and all("correct_option" not in x and "tita_answer" not in x and "explanation" not in x for x in qo), "questions_only leaks")
    for f in glob.glob(os.path.join(HERE, "books", "*Student*.html")) + [os.path.join(HERE, "Sample_Paper.html")]:
        s = open(f, encoding="utf-8").read()
        check("Answer:" not in s and 'class="key"' not in s and "Common wrong entries" not in s, f"{os.path.basename(f)} leaks answers")
    # generator: 200 seeds
    gen = os.path.join(HERE, "generate_paper.py")
    byid = {r["id"]: r for r in bank}
    tmpdir = tempfile.mkdtemp(prefix="cat_qa_verify_")
    tmp = os.path.join(tmpdir, "p")
    for seed in range(1, 201):
        subprocess.run([sys.executable, gen, "--bank", path, "--seed", str(seed), "--output", tmp], check=True, capture_output=True)
        p = json.load(open(tmp + "_paper.json")); k = json.load(open(tmp + "_answer_key.json"))
        qs = [byid[i] for i in p["questions"]]
        check(len(qs) == 22 and len(set(p["questions"])) == 22, f"seed {seed}: size")
        check(sum(1 for r in qs if r["answer_format"] == "TITA") == 8, f"seed {seed}: TITA count")
        check(dict(Counter(r["difficulty"] for r in qs)) == {"Easy": 7, "Medium": 10, "Difficult": 5}, f"seed {seed}: difficulty mix")
        deps = [d for r in qs for d in r["family_dependencies"]]
        check(len(deps) == len(set(deps)), f"seed {seed}: family clash")
        check(all((byid[x["id"]]["correct_option"] if x["format"] == "MCQ" else byid[x["id"]]["tita_answer"]) == x["answer"] for x in k), f"seed {seed}: key")
    import shutil
    shutil.rmtree(tmpdir, ignore_errors=True)
    if FAILS:
        print("FAIL", len(FAILS))
        for f in FAILS[:50]:
            print("  ", f)
        sys.exit(1)
    print(f"PASS: {n} questions, {dict(fc)}, {dict(dc)}, keys {dict(sorted(keys.items()))}, 200 generator seeds valid")


if __name__ == "__main__":
    main()
