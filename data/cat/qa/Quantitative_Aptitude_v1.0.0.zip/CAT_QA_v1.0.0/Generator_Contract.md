# Paper generator contract (CAT QA)

`generate_paper.py` builds one CAT-style Quantitative Ability section from the bank.

Inputs: `--bank` (canonical JSON), `--seed` (integer; the same seed always gives the same paper),
`--output` (file prefix), optional `--questions` (default 22), `--tita` (default 8), `--chapter`, `--area`,
`--exam` and `--minutes` (default 40).

Guarantees:
1. Exactly `--questions` distinct questions, of which exactly `--tita` are TITA.
2. Difficulty mix 30 / 45 / 25 percent rounded to the section size (22 gives 7 Easy, 10 Medium, 5 Difficult).
3. No two questions share any entry of `family_dependencies` (concept family or alias group), so a
   paper never repeats a method.
4. Only `generator_eligible` records are used; `--exam` keeps only records tagged for that exam. `--chapter` and `--area` restrict the pool to one chapter number or one area.
5. Marking written into the paper: MCQ +3 / -1 / 0, TITA +3 / 0 / 0.

Outputs: `<prefix>_paper.json` (seed, description, time, maximum marks, marking, ordered question IDs)
and `<prefix>_answer_key.json` (number, id, format, answer: letter for MCQ, integer for TITA).

`verify_release.py` checks these guarantees for seeds 1 to 200.
