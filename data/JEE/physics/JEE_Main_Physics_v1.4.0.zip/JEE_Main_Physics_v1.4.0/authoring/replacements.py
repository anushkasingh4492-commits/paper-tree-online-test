"""Reviewed replacement tasks for the fourteen R03 IDs; all values are SI unless stated."""
from math import sqrt, pi

def replacements():
    out = {}
    def add(n, stem, request, value, unit, wrong, explanation, reason, family=None):
        out[n] = dict(stem=stem, request=request, value=value, unit=unit,
                      wrong=wrong, explanation=explanation, reason=reason, family=family)

    add(95,
        'A particle starts at (0,0) with velocity (10 i + 20 j) m/s between two smooth vertical walls at x=10 m and x=-2 m. The coefficient of restitution is 0.5 at the right wall and 0.4 at the left wall; each collision changes only the horizontal velocity. Both walls extend above all impacts. Gravity is 10 m/s² downward, the floor is y=0, and air resistance is negligible.',
        'Find the x-coordinate of its first subsequent impact with the floor.', -.8, 'm', [-5, 1.2, -2],
        'Vertical motion is unaffected by the walls: y=20t-5t², so the floor is reached at t=4 s. The right-wall collision occurs at t=1 s and changes vx from +10 to -5 m/s. Reaching the left wall then takes 12/5=2.4 s, so the second collision is at t=3.4 s, when y=10.2 m>0. It changes vx to +2 m/s. In the remaining 0.6 s, x=-2+2(0.6)=-0.8 m. The particle cannot reach the right wall again before landing.',
        'Resolve two successive impact regimes, check both occur before landing, and combine the horizontal timeline with the independent vertical flight time.')

    G=12; m=2; ss=.6; cc=.8; ca=.8; sa=.6; us=.5; uk=.2; d=3
    P=m*G*(ss+us*cc)/(ca+us*sa); N=m*G*cc-P*sa
    a=(P*ca-m*G*ss-uk*N)/m; v=sqrt(2*a*d)
    common='An incline fixed in an elevator has sinθ=0.6 and cosθ=0.8. The elevator accelerates upward at 2 m/s²; take g=10 m/s². A 2 kg block is acted on by a force P whose component up the incline is 0.8P and whose component away from it is 0.6P. Starting from a value that keeps the block in static equilibrium, P is increased quasistatically until upward slip is just impending. No other applied force holds the block. It is then given an arbitrarily small upward nudge. P stays at that threshold during the subsequent upward slide. The kinetic friction coefficient is 0.20, and contact with the incline is maintained.'
    add(235, common+f' After sliding 3.0 m relative to the elevator, its relative speed is {v:.10g} m/s.',
        'Find the coefficient of static friction.', .5, '', [.3,.4,.6],
        f'The measured motion gives a=v²/(2d)={a:.10g} m/s². The normal reaction is N=19.2-0.6P. Kinetic motion requires 2a=0.8P-14.4-0.20(19.2-0.6P), hence P={P:.10g} N and N={N:.10g} N>0. At the static threshold, 0.8P=14.4+μsN, giving μs=0.50. Substitution in the kinetic equation reproduces the measured speed.',
        'Infer acceleration from a measurement, solve the force-dependent normal reaction during kinetic sliding, then reverse the distinct static threshold condition.')
    extra=v*v/(2*G*(ss+uk*cc))
    add(240, common+' The static friction coefficient is 0.50. After the block has slid 3.0 m relative to the elevator, P is switched off instantaneously.',
        'How much farther up the incline does it travel before first coming to rest relative to the elevator?', extra, 'm', [.6029,.384,1.0],
        f'At the upward-slip threshold, 0.8P=14.4+0.50(19.2-0.6P), giving P={P:.10g} N and N={N:.10g} N. Kinetic friction gives a={a:.10g} m/s², so v²=2a(3)={v*v:.10g} m²/s². After P is removed, N rises to 19.2 N and the downward acceleration magnitude is 12(0.6+0.20×0.8)=9.12 m/s². The additional upward distance is v²/(2×9.12)={extra:.10g} m. This is the first stopping point; later reversal is not part of the question.',
        'Use a force-dependent static threshold, transition to kinetic friction, and recompute the normal force and deceleration after the applied force is removed.')

    a=(4*10*.8-2*10*.5-.2*2*10*sqrt(3)/2)/6
    dist=2+4*a/(2*10*(.5+.2*sqrt(3)/2))
    add(260,
        'Two blocks are connected by a light inextensible string over a smooth massless pulley. Block A (2 kg) is on a rough 30° incline, with both static and kinetic friction coefficients 0.20. Block B (4 kg) is on a smooth incline with sinβ=0.8. Both inclines descend away from the pulley. The system is released from rest. After each block has moved 2.0 m, the string is cut without imparting an impulse. The inclines are long enough; take g=10 m/s².',
        'Find the total distance A travels up its incline from its initial position to its first stopping point after the cut.', dist, 'm', [2.5,3.5,4.0],
        f'The downward drive on B exceeds the weight component plus limiting friction on A, so B descends and A ascends. During connected motion, 6a=32-10-2√3, giving a={a:.10g} m/s² and v²=2a(2)={4*a:.10g} m²/s². After cutting, A still moves upward, so both gravity and kinetic friction act downward; its deceleration is 10(0.5+0.20 cos30°). The extra ascent is v²/[20(0.5+0.20 cos30°)], and adding the first 2 m gives {dist:.10g} m.',
        'Determine the admissible initial direction, solve the coupled motion with friction, then change to the independent post-cut stopping regime.')

    x=(-16+sqrt(16**2+4*50*9))/(100)
    add(349,
        'A particle of mass 2 kg moving at 10 m/s along +x collides elastically with an identical particle initially at rest on a smooth horizontal plane. The incident particle emerges at 30° to +x, with positive x and y velocity components. The second particle enters, without energy loss, a rough straight incline aligned with its outgoing direction. On the incline sinθ=0.6, cosθ=0.8 and the kinetic friction coefficient is 0.25. After travelling 1.0 m up the incline it meets an initially uncompressed light spring of force constant 100 N/m, fixed farther up the incline. Friction acts throughout the ascent and compression. Take g=10 m/s².',
        'Find the first maximum compression of the spring.', x, 'm', [.4243,.18,.7071],
        f'For an elastic equal-mass collision with one particle initially stationary, the outgoing velocities are perpendicular. Resolving momentum gives the second speed 10 sin30°=5 m/s, hence its kinetic energy is 25 J. Gravity and friction oppose ascent with constant force 2×10(0.6+0.25×0.8)=16 N. It reaches the spring with 25-16=9 J. During compression, 50x²+16x=9. The sole positive root is x={x:.10g} m.',
        'Use vector momentum and elastic energy to infer the outgoing speed, include rough-incline work before and during compression, and select the physical root of the spring-energy equation.')

    T1=2*pi*sqrt(2/25); T2=2*pi*sqrt(2/sqrt(500))
    add(923,
        f'A pendulum of length 2.0 m is in a vehicle with constant unknown horizontal acceleration a>0 and constant unknown upward acceleration b>0. Its small-oscillation period about the tilted equilibrium is {T1:.10g} s. In a second trial the upward acceleration is set to zero, the horizontal acceleration stays a, and the period is {T2:.10g} s. Take g=10 m/s². The string is light and inextensible; oscillations are small about each equilibrium.',
        'Find the upward acceleration b in the first trial.', 5, 'm/s²', [2,10,15],
        'Each period gives the magnitude of effective gravity, ge=4π²L/T². The two magnitudes are 25 m/s² and √500 m/s². The second trial gives a²+10²=500, hence a=20 m/s². The first then gives (10+b)²+20²=25². Since b>0, 10+b=15, so b=5 m/s².',
        'Invert two period measurements, separate horizontal and vertical components of effective gravity, and select the branch consistent with upward acceleration.')

    temp=300*(418/340)**2
    add(972,
        'At 300 K, a closed-end resonance tube has first and second resonance lengths 16.0 cm and 50.0 cm with a tuning fork. An independent measurement gives sound speed 340 m/s at this temperature. A second fork makes 50 beats per second with the original fork. In air at an unknown temperature between 400 K and 500 K, the first resonance length with the second fork is 18.0 cm. The end correction and tube dimensions are unchanged; sound speed is proportional to the square root of absolute temperature. The two fork frequencies remain fixed during these trials.',
        'Find the unknown air temperature.', temp, 'K', [425,475,490],
        f'At 300 K, λ=2(0.50-0.16)=0.68 m and f=340/0.68=500 Hz. The end correction is (50-3×16)/2=1 cm. Beats allow second-fork frequencies 450 or 550 Hz. The hot first resonance implies λhot=4(0.18+0.01)=0.76 m, giving speeds 342 or 418 m/s. The corresponding temperatures are 300(342/340)²=303.5398 K or 300(418/340)²={temp:.10g} K. Only the latter lies in the specified interval.',
        'Calibrate the end correction and original frequency, retain both beat-frequency branches, then use thermal scaling and the physical interval to resolve the ambiguity.')

    add(1203,
        'A uniform 100 cm metre-bridge wire has total resistance 8.0 Ω. An unknown nonnegative contact resistance e lies only at its left end, before the uniform wire begins. With unknown resistance X in the left gap and 14.0 Ω in the right gap, balance occurs 30.0 cm from the left end of the uniform wire. Interchanging the gap resistances gives balance at 50.0 cm. The contact resistance remains at the same physical end. Temperature is unchanged. The original gap connection is restored and the contact resistance is then removed.',
        'By how many centimetres does the balance point move to the right of its original 30.0 cm position?', 100*10/24-30, 'cm', [5,8,20],
        'The two balance conditions give X/14=(e+2.4)/5.6 and 14/X=(e+4)/4. Multiplying yields (e+2.4)(e+4)=22.4, or e²+6.4e-12.8=0. The roots are 1.6 Ω and -8 Ω; only e=1.6 Ω is allowed. Thus X=10 Ω. With e removed, the original connection balances at 100X/(X+14)=41.6667 cm. The rightward shift is 11.6667 cm.',
        'Solve two nonreciprocal measured wire ratios for a fixed-end parasitic resistance, reject the negative root, and predict the third configuration.')

    add(1276,
        'Two unknown positive resistors R1 and R2 form a series divider across an ideal 18.0 V source, with R1 above R2 and the lower end grounded. A single voltmeter of resistance 6.0 kΩ is first connected across R2 and reads 9.0 V. It is then disconnected from R2 and connected across R1, where it reads 4.5 V. All components are ohmic and the resistors are unchanged between trials.',
        'Find the voltage across R2 when the voltmeter is removed completely.', 12, 'V', [9,10.5,13.5],
        'Write x=R1 and y=R2 in kΩ. In the first trial the loaded lower arm is 6y/(6+y), and a 9 V reading implies x=6y/(6+y). In the second trial the loaded upper arm is 6x/(6+x); its 4.5 V reading gives y=3[6x/(6+x)]. Combining the two positive-resistance conditions gives x=3 kΩ and y=6 kΩ. With the meter removed the lower-arm voltage is 18y/(x+y)=12 V.',
        'Account for two different meter-loading configurations, jointly infer two unknown resistors, and recover the unmeasured unloaded voltage.')

    add(1555,
        'A conducting rod of length 0.50 m moves to the right on horizontal rails in an unknown uniform perpendicular magnetic field B. The total circuit resistance is initially 4.0 Ω, inductance is negligible, and a constant kinetic friction force opposes the motion. A rightward external force of 3.0 N maintains a steady speed of 4.0 m/s; a force of 5.0 N maintains 8.0 m/s. In a third steady-motion trial the total resistance is changed to 8.0 Ω and the applied force is 2.0 N. The magnetic field and kinetic friction force are unchanged, with sufficient rail length for steady motion.',
        'Find the electrical power dissipated in the complete circuit during the third trial.', 4, 'W', [8,2,16],
        'At steady speed, F=f+B²L²v/R. Subtracting the first two trials gives B²L²/4=(5-3)/(8-4)=0.5 N s/m, so B²L²=2 and f=1 N. In the third trial the drag coefficient is 2/8=0.25 N s/m, so v=(2-1)/0.25=4 m/s. Electrical dissipation is magnetic-drag power (F-f)v=1×4=4 W; friction dissipates the other 4 W supplied mechanically.',
        'Infer magnetic drag and kinetic friction separately from two steady states, update the circuit loading, and distinguish electrical dissipation from total mechanical power.',
        'GLOBAL-ROD-MAGNETIC-DRAG')

    u=1.66e-27; mev=1.6e-13; V=2e6; p=sqrt(2*4*mev/(1/(2*u)+1/(4*u)))
    v1=V+p/(2*u); v2=V-p/(4*u); K1=.5*2*u*v1*v1/mev; K2=.5*4*u*v2*v2/mev
    add(1872,
        f'A nucleus moving along +x breaks into two products of masses 2u and 4u. Immediately after breakup, the 2u product travels along +x with laboratory kinetic energy {K1:.10g} MeV, while the 4u product travels along -x with laboratory kinetic energy {K2:.10g} MeV. There is no external impulse. For kinetic-energy and momentum calculations, take the parent mass as 6u; the small mass defect is represented only by the released internal energy Q. Use u=1.66×10⁻²⁷ kg and 1 MeV=1.60×10⁻¹³ J. All speeds are nonrelativistic.',
        'Find the released internal energy Q.', 4, 'MeV', [K1+K2,K1-K2,3.5],
        f'Using the stated directions, v1=+√(2K1/m1)={v1:.10g} m/s and v2=-√(2K2/m2)={v2:.10g} m/s. Momentum conservation gives the parent velocity (m1v1+m2v2)/(6u)=2.0000×10⁶ m/s. Its initial kinetic energy is 0.1245 MeV. The total final laboratory kinetic energy is {K1+K2:.10g} MeV, so Q={K1+K2:.10g}-0.1245=4.0000 MeV. Adding the product energies alone incorrectly includes the parent’s translational energy.',
        'Convert measured energies to signed momenta, infer the unmeasured parent motion, and subtract its laboratory kinetic energy to isolate the internal energy release.')

    add(1994,
        'A source feeds node X through an unknown resistor R. A 100 Ω load joins X to ground. An ideal upper diode conducts from X into a +6.0 V reference, and an ideal lower diode conducts from a +2.0 V reference into X. With both diodes off, a source setting of 6.0 V gives X=3.0 V. The source then repeatedly spends 40% of each cycle at 16.0 V and 60% at 0 V. There is no capacitance or inductance, so the node reaches its static state immediately. The references can absorb or deliver current, and the zero-volt source can absorb current.',
        'Find the mean net power absorbed by the pair of reference supplies, counting delivered power as negative.', .048, 'W', [.144,.096,.080],
        'The off-state divider fixes R=100 Ω. At a 16 V source, the free divider value 8 V exceeds 6 V, so the upper diode clamps X to 6 V. Its reference absorbs current (16-6)/100-6/100=0.04 A, or 0.24 W. At a zero-volt source, the lower diode clamps X to 2 V and supplies both load and source-resistor currents: 2/100+2/100=0.04 A, delivering 0.08 W. The average net absorption is 0.40(0.24)-0.60(0.08)=0.048 W.',
        'Calibrate an unknown resistance, determine two different diode states, apply node-current balances with opposite power signs, and average over the drive cycle.')

    add(2010,
        'An adjustable source feeds node X through an unknown resistor R. An unknown positive load resistance L joins X to ground. An ideal upper diode conducts from X into +8.0 V, and an ideal lower diode conducts from +3.0 V into X. With both diodes off, a source setting of 10.0 V gives X=4.0 V. The source is then alternated between 24.0 V for one-third of each cycle and 0 V for two-thirds. The measured mean power dissipated in R is 0.3044444444 W. There is no capacitance or inductance. The references and source can absorb or deliver current as required.',
        'Find the load resistance L.', 200, 'Ω', [100,150,300],
        'Off-state calibration gives R/L=10/4-1=1.5. The free divider values at 24 V and 0 V are 9.6 V and 0 V; hence X is clamped to 8 V and 3 V respectively. The voltage magnitudes across R are 16 V and 3 V. Its mean power is [(1/3)16²+(2/3)3²]/R=274/(3R). The measurement gives R=300 Ω and L=R/1.5=200 Ω. Both diode states are self-consistent.',
        'Combine an unknown divider ratio with two clipping regimes and a measured mean dissipation to infer two circuit resistances.')

    D=20+(6-2)*.05; di=12+(10-2)*.05
    err=100*(2*.05/(D+di)+2*.025/(D-di))
    add(2103,
        'A vernier has 20 divisions equal to 19 main-scale divisions; one main-scale division is 1 mm. With its jaws closed, the vernier zero lies to the right and division 2 coincides. A hollow cylindrical tube gives outer-diameter main-scale reading 20 mm with division 6 coinciding, and inner-diameter main-scale reading 12 mm with division 10 coinciding. Its mass and length are exact. After subtracting the measured zero error, a possible residual zero offset of at most one least count contributes the SAME additive error to both corrected diameters. Each diameter also has an independent reading error of at most half a least count. Use first-order maximum-error propagation and the tube’s material volume, excluding the bore.',
        'Find the maximum percentage uncertainty in the inferred material density.', err, '%', [1.2821, .6409,1.5894],
        f'The least count is 1-19/20=0.05 mm and the positive zero error is 0.10 mm. Corrected diameters are D={D:g} mm and d={di:g} mm. Density is proportional to 1/(D²-d²). Write the diameter errors as z+εD and z+εd, with |z|≤0.05 mm and |εD|,|εd|≤0.025 mm. The first-order area error is 2(D-d)z+2DεD-2dεd. Its maximum magnitude divided by D²-d² is 2(0.05)/(D+d)+2(0.025)/(D-d). Thus the maximum density uncertainty is {err:.10g}%. The common offset must not be counted as two independent errors.',
        'Read and correct two instrument measurements, use the hollow-cylinder geometry, and propagate a common systematic error separately from independent reading errors.')
    return out
